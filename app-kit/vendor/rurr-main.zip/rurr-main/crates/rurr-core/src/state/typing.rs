use super::{StateError, StateOperation};
use indexmap::IndexMap;
use serde_json::Value;
use std::any::Any;
use std::fmt;

/// Validates and round-trips typed state representations.
pub trait TypingSystem: Send + Sync + fmt::Debug {
    /// Constructs typed data from the raw JSON-like state map.
    fn construct_data(
        &self,
        state: &IndexMap<String, Value>,
    ) -> Result<Box<dyn Any + Send + Sync>, StateError> {
        Ok(Box::new(state.clone()))
    }

    /// Reconstructs a raw state map from previously constructed typed data.
    fn construct_state(
        &self,
        data: &(dyn Any + Send + Sync),
    ) -> Result<IndexMap<String, Value>, StateError> {
        data.downcast_ref::<IndexMap<String, Value>>()
            .cloned()
            .ok_or_else(|| StateError::TypingSystem {
                phase: "construct_state",
                message: "expected IndexMap<String, Value> typed payload".to_string(),
            })
    }

    /// Validates a pending state operation before it runs.
    fn validate_pre_action(
        &self,
        _state: &IndexMap<String, Value>,
        _operation: &StateOperation,
    ) -> Result<(), StateError> {
        Ok(())
    }

    /// Validates the transition from one state snapshot to the next.
    fn validate_post_action(
        &self,
        _previous: &IndexMap<String, Value>,
        _next: &IndexMap<String, Value>,
        _operation: &StateOperation,
    ) -> Result<(), StateError> {
        Ok(())
    }

    /// Validates a full state snapshot.
    fn validate_state(&self, _state: &IndexMap<String, Value>) -> Result<(), StateError> {
        Ok(())
    }

    /// Validates that typed conversion can round-trip the provided state snapshot.
    fn validate_roundtrip(&self, state: &IndexMap<String, Value>) -> Result<(), StateError> {
        let typed_data = self.construct_data(state)?;
        let _ = self.construct_state(typed_data.as_ref())?;
        Ok(())
    }
}

#[derive(Debug, Clone, Default)]
/// Default typing system that accepts the untyped JSON-like state representation.
pub struct DefaultTypingSystem;

impl TypingSystem for DefaultTypingSystem {
    fn validate_roundtrip(&self, _state: &IndexMap<String, Value>) -> Result<(), StateError> {
        Ok(())
    }
}

pub(super) fn validate_full_state<T>(
    typing_system: &T,
    state: &IndexMap<String, Value>,
) -> Result<(), StateError>
where
    T: TypingSystem + ?Sized,
{
    typing_system.validate_state(state)?;
    typing_system.validate_roundtrip(state)
}

pub(super) fn validate_transition<T>(
    typing_system: &T,
    previous: &IndexMap<String, Value>,
    next: &IndexMap<String, Value>,
    operation: &StateOperation,
) -> Result<(), StateError>
where
    T: TypingSystem + ?Sized,
{
    typing_system.validate_post_action(previous, next, operation)?;
    validate_full_state(typing_system, next)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::{Arc, Mutex};

    #[derive(Debug)]
    struct OrderedTypingSystem {
        calls: Arc<Mutex<Vec<&'static str>>>,
    }

    impl TypingSystem for OrderedTypingSystem {
        fn validate_post_action(
            &self,
            _previous: &IndexMap<String, Value>,
            _next: &IndexMap<String, Value>,
            _operation: &StateOperation,
        ) -> Result<(), StateError> {
            self.calls
                .lock()
                .expect("call log lock should not be poisoned")
                .push("validate_post_action");
            Ok(())
        }

        fn validate_state(&self, _state: &IndexMap<String, Value>) -> Result<(), StateError> {
            self.calls
                .lock()
                .expect("call log lock should not be poisoned")
                .push("validate_state");
            Ok(())
        }

        fn validate_roundtrip(&self, _state: &IndexMap<String, Value>) -> Result<(), StateError> {
            self.calls
                .lock()
                .expect("call log lock should not be poisoned")
                .push("validate_roundtrip");
            Ok(())
        }
    }

    #[test]
    fn validate_transition_runs_post_hooks_before_full_state_validation() {
        let calls = Arc::new(Mutex::new(Vec::new()));
        let typing_system = OrderedTypingSystem {
            calls: Arc::clone(&calls),
        };

        validate_transition(
            &typing_system,
            &IndexMap::new(),
            &IndexMap::new(),
            &StateOperation::Update(IndexMap::new()),
        )
        .expect("validation should succeed");

        assert_eq!(
            *calls.lock().expect("call log lock should not be poisoned"),
            vec![
                "validate_post_action",
                "validate_state",
                "validate_roundtrip"
            ]
        );
    }

    #[test]
    fn default_typing_system_accepts_full_state_validation() {
        validate_full_state(&DefaultTypingSystem, &IndexMap::new())
            .expect("default typing validation should succeed");
    }
}
