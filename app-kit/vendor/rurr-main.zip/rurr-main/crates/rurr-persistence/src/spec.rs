use crate::refs::{StateLoaderRef, StatePersisterRef};
use crate::{AsyncBaseStateLoader, AsyncBaseStatePersister, BaseStateLoader, BaseStatePersister};
use indexmap::IndexMap;
use serde_json::Value;
use std::sync::Arc;

/// Persistence execution lane required by a loader or persister.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PersistenceLane {
    /// Synchronous-only persistence lane.
    Sync,
    /// Asynchronous-only persistence lane.
    Async,
}

impl PersistenceLane {
    /// Returns `true` when this lane is asynchronous.
    pub fn is_async(self) -> bool {
        matches!(self, Self::Async)
    }
}

/// Explicit persisted-state lookup target used during resume flows.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PersistenceLoadTarget {
    partition_key: Option<String>,
    app_id: String,
    sequence_id: Option<u64>,
}

impl PersistenceLoadTarget {
    /// Creates a new explicit load target.
    pub fn new(
        app_id: impl Into<String>,
        partition_key: Option<String>,
        sequence_id: Option<u64>,
    ) -> Self {
        Self {
            partition_key,
            app_id: app_id.into(),
            sequence_id,
        }
    }

    /// Returns the optional partition key.
    pub fn partition_key(&self) -> Option<&str> {
        self.partition_key.as_deref()
    }

    /// Clones the optional partition key.
    pub fn partition_key_owned(&self) -> Option<String> {
        self.partition_key.clone()
    }

    /// Returns the target application identifier.
    pub fn app_id(&self) -> &str {
        self.app_id.as_str()
    }

    /// Returns the requested sequence identifier, if any.
    pub fn sequence_id(&self) -> Option<u64> {
        self.sequence_id
    }
}

/// Configuration for restoring initial application state from a loader.
#[derive(Clone)]
pub struct StateInitializerSpec {
    initializer: StateLoaderRef,
    load_target: Option<PersistenceLoadTarget>,
    resume_at_next_action: bool,
    default_state: IndexMap<String, Value>,
    default_entrypoint: String,
    override_state_values: Option<IndexMap<String, Value>>,
}

impl StateInitializerSpec {
    /// Creates a sync initializer specification.
    pub fn sync(
        initializer: Arc<dyn BaseStateLoader>,
        resume_at_next_action: bool,
        default_state: IndexMap<String, Value>,
        default_entrypoint: impl Into<String>,
        override_state_values: Option<IndexMap<String, Value>>,
    ) -> Self {
        Self::from_ref(
            StateLoaderRef::from(initializer),
            resume_at_next_action,
            default_state,
            default_entrypoint,
            override_state_values,
        )
    }

    /// Creates an async initializer specification.
    pub fn async_initializer(
        initializer: Arc<dyn AsyncBaseStateLoader>,
        resume_at_next_action: bool,
        default_state: IndexMap<String, Value>,
        default_entrypoint: impl Into<String>,
        override_state_values: Option<IndexMap<String, Value>>,
    ) -> Self {
        Self::from_ref(
            StateLoaderRef::from(initializer),
            resume_at_next_action,
            default_state,
            default_entrypoint,
            override_state_values,
        )
    }

    /// Creates an initializer spec from an already-erased loader reference.
    pub fn from_ref(
        initializer: StateLoaderRef,
        resume_at_next_action: bool,
        default_state: IndexMap<String, Value>,
        default_entrypoint: impl Into<String>,
        override_state_values: Option<IndexMap<String, Value>>,
    ) -> Self {
        Self {
            initializer,
            load_target: None,
            resume_at_next_action,
            default_state,
            default_entrypoint: default_entrypoint.into(),
            override_state_values,
        }
    }

    /// Sets an explicit load target for resume flows.
    pub fn with_load_target(mut self, load_target: PersistenceLoadTarget) -> Self {
        self.load_target = Some(load_target);
        self
    }

    /// Applies `load_target` only when it is present.
    pub fn with_optional_load_target(self, load_target: Option<PersistenceLoadTarget>) -> Self {
        load_target
            .into_iter()
            .fold(self, StateInitializerSpec::with_load_target)
    }

    /// Returns the required execution lane.
    pub fn lane(&self) -> PersistenceLane {
        self.initializer.lane()
    }

    /// Returns the type-erased initializer reference.
    pub fn initializer_ref(&self) -> &StateLoaderRef {
        &self.initializer
    }

    /// Returns the explicit load target, if configured.
    pub fn load_target(&self) -> Option<&PersistenceLoadTarget> {
        self.load_target.as_ref()
    }

    /// Returns whether resume should continue at the next action.
    pub fn resume_at_next_action(&self) -> bool {
        self.resume_at_next_action
    }

    /// Returns the default state used when no stored state is found.
    pub fn default_state(&self) -> &IndexMap<String, Value> {
        &self.default_state
    }

    /// Returns the default entrypoint used when no stored position is found.
    pub fn default_entrypoint(&self) -> &str {
        self.default_entrypoint.as_str()
    }

    /// Returns state overrides applied after loading, if configured.
    pub fn override_state_values(&self) -> Option<&IndexMap<String, Value>> {
        self.override_state_values.as_ref()
    }
}

/// Configuration for persisting state snapshots during execution.
#[derive(Clone)]
pub struct StatePersisterSpec {
    persister: StatePersisterRef,
}

impl StatePersisterSpec {
    /// Creates a sync persister specification.
    pub fn sync(persister: Arc<dyn BaseStatePersister>) -> Self {
        Self::from_ref(StatePersisterRef::from(persister))
    }

    /// Creates an async persister specification.
    pub fn async_persister(persister: Arc<dyn AsyncBaseStatePersister>) -> Self {
        Self::from_ref(StatePersisterRef::from(persister))
    }

    /// Creates a persister spec from an already-erased persister reference.
    pub fn from_ref(persister: StatePersisterRef) -> Self {
        Self { persister }
    }

    /// Returns the required execution lane.
    pub fn lane(&self) -> PersistenceLane {
        self.persister.lane()
    }

    /// Returns the type-erased persister reference.
    pub fn persister_ref(&self) -> &StatePersisterRef {
        &self.persister
    }
}

/// Combined persistence configuration for an application.
#[derive(Clone, Default)]
pub struct ApplicationPersistenceSpec {
    initializer: Option<StateInitializerSpec>,
    persister: Option<StatePersisterSpec>,
}

impl ApplicationPersistenceSpec {
    /// Creates an empty persistence spec.
    pub fn new() -> Self {
        Self::default()
    }

    /// Sets the state initializer configuration.
    pub fn with_initializer(mut self, initializer: StateInitializerSpec) -> Self {
        self.initializer = Some(initializer);
        self
    }

    /// Sets the state persister configuration.
    pub fn with_persister(mut self, persister: StatePersisterSpec) -> Self {
        self.persister = Some(persister);
        self
    }

    /// Creates a sync resume configuration using the same persister for load and save.
    pub fn sync_resume(
        persister: Arc<dyn BaseStatePersister>,
        resume_at_next_action: bool,
        default_state: IndexMap<String, Value>,
        default_entrypoint: impl Into<String>,
        override_state_values: Option<IndexMap<String, Value>>,
        load_target: Option<PersistenceLoadTarget>,
    ) -> Self {
        let initializer: Arc<dyn BaseStateLoader> = persister.clone();

        Self::new()
            .with_initializer(
                StateInitializerSpec::sync(
                    initializer,
                    resume_at_next_action,
                    default_state,
                    default_entrypoint,
                    override_state_values,
                )
                .with_optional_load_target(load_target),
            )
            .with_persister(StatePersisterSpec::sync(persister))
    }

    /// Creates an async resume configuration using the same persister for load and save.
    pub fn async_resume(
        persister: Arc<dyn AsyncBaseStatePersister>,
        resume_at_next_action: bool,
        default_state: IndexMap<String, Value>,
        default_entrypoint: impl Into<String>,
        override_state_values: Option<IndexMap<String, Value>>,
        load_target: Option<PersistenceLoadTarget>,
    ) -> Self {
        let initializer: Arc<dyn AsyncBaseStateLoader> = persister.clone();

        Self::new()
            .with_initializer(
                StateInitializerSpec::async_initializer(
                    initializer,
                    resume_at_next_action,
                    default_state,
                    default_entrypoint,
                    override_state_values,
                )
                .with_optional_load_target(load_target),
            )
            .with_persister(StatePersisterSpec::async_persister(persister))
    }

    /// Merges `other` into this config, replacing only the populated fields.
    pub fn merge(&mut self, other: Self) {
        if let Some(initializer) = other.initializer {
            self.initializer = Some(initializer);
        }
        if let Some(persister) = other.persister {
            self.persister = Some(persister);
        }
    }

    /// Returns the configured initializer, if any.
    pub fn initializer(&self) -> Option<&StateInitializerSpec> {
        self.initializer.as_ref()
    }

    /// Returns the configured persister, if any.
    pub fn persister(&self) -> Option<&StatePersisterSpec> {
        self.persister.as_ref()
    }

    /// Returns the initializer lane, if an initializer is configured.
    pub fn initializer_lane(&self) -> Option<PersistenceLane> {
        self.initializer.as_ref().map(StateInitializerSpec::lane)
    }

    /// Returns the persister lane, if a persister is configured.
    pub fn persister_lane(&self) -> Option<PersistenceLane> {
        self.persister.as_ref().map(StatePersisterSpec::lane)
    }

    /// Returns `true` when the full spec supports `lane`.
    pub fn supports_lane(&self, lane: PersistenceLane) -> bool {
        self.initializer_lane().is_none_or(|value| value == lane)
            && self.persister_lane().is_none_or(|value| value == lane)
    }
}
