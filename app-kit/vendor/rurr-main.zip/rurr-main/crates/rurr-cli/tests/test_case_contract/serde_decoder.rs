use super::*;

#[test]
fn test_case_create_uses_external_serde_decoder_for_field_and_tagged_payloads() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("decoded-fixture.json");
    let decoder = install_test_serde_decoder(TestSerdeDecoderBehavior::DecodeFixtureState)
        .expect("test serde decoder should be created");

    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            serde_json::json!({
                "custom_field": {"value": "serialized::before"},
                "tagged_payload": {
                    "__burr_serde__": "test_decoder_tag",
                    "value": "before"
                }
            }),
            serde_json::json!({
                "custom_field": {"value": "serialized::after"},
                "tagged_payload": {
                    "__burr_serde__": "test_decoder_tag",
                    "value": "after"
                }
            }),
        ],
    );

    let output = run_test_case_create(&[
        std::ffi::OsStr::new("--storage-dir"),
        storage_dir.path().as_os_str(),
        std::ffi::OsStr::new("--project-name"),
        std::ffi::OsStr::new("demo_counter"),
        std::ffi::OsStr::new("--app-id"),
        std::ffi::OsStr::new("counter-app-0001"),
        std::ffi::OsStr::new("--sequence-id"),
        std::ffi::OsStr::new("1"),
        std::ffi::OsStr::new("--target-file-name"),
        fixture_path.as_os_str(),
        std::ffi::OsStr::new("--serde-decoder"),
        decoder.path().as_os_str(),
    ]);
    assert_success(
        &output,
        "test-case create should succeed with external decoder",
    );

    let fixtures: Value =
        serde_json::from_str(&fs::read_to_string(&fixture_path).expect("fixture should exist"))
            .expect("fixture json should parse");
    let fixtures = fixtures
        .as_array()
        .expect("fixture file should contain an array");
    assert_eq!(fixtures.len(), 1);
    assert_eq!(
        fixtures[0]["input_state"],
        serde_json::json!({
            "custom_field": "before",
            "tagged_payload": "decoded::before"
        })
    );
    assert_eq!(
        fixtures[0]["expected_state"],
        serde_json::json!({
            "custom_field": "after",
            "tagged_payload": "decoded::after"
        })
    );
}

#[test]
fn test_case_create_fails_clearly_when_serde_decoder_executable_is_missing() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("missing-decoder-fixture.json");

    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            serde_json::json!({
                "custom_field": {"value": "serialized::before"},
                "tagged_payload": {
                    "__burr_serde__": "test_decoder_tag",
                    "value": "before"
                }
            }),
            serde_json::json!({
                "custom_field": {"value": "serialized::after"},
                "tagged_payload": {
                    "__burr_serde__": "test_decoder_tag",
                    "value": "after"
                }
            }),
        ],
    );

    let missing_decoder = target_dir.path().join("does-not-exist-decoder");
    let output = run_test_case_create(&[
        std::ffi::OsStr::new("--storage-dir"),
        storage_dir.path().as_os_str(),
        std::ffi::OsStr::new("--project-name"),
        std::ffi::OsStr::new("demo_counter"),
        std::ffi::OsStr::new("--app-id"),
        std::ffi::OsStr::new("counter-app-0001"),
        std::ffi::OsStr::new("--sequence-id"),
        std::ffi::OsStr::new("1"),
        std::ffi::OsStr::new("--target-file-name"),
        fixture_path.as_os_str(),
        std::ffi::OsStr::new("--serde-decoder"),
        missing_decoder.as_os_str(),
    ]);
    assert_failure(&output, "missing serde decoder should fail");
    let stderr = stderr_lossy(&output);
    assert!(
        stderr.contains("spawn serde decoder"),
        "stderr should mention the decoder spawn failure: {stderr}"
    );
    assert!(
        stderr.contains("does-not-exist-decoder"),
        "stderr should mention the missing decoder file name: {stderr}"
    );
    assert!(
        !fixture_path.exists(),
        "fixture file should not be created when decoder startup fails"
    );
}

#[test]
fn test_case_create_fails_clearly_when_serde_decoder_exits_nonzero() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("nonzero-decoder-fixture.json");
    let decoder = install_test_serde_decoder(TestSerdeDecoderBehavior::ExitNonzero)
        .expect("failing serde decoder should be created");

    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            serde_json::json!({
                "custom_field": {"value": "serialized::before"}
            }),
            serde_json::json!({
                "custom_field": {"value": "serialized::after"}
            }),
        ],
    );

    let output = run_test_case_create(&[
        std::ffi::OsStr::new("--storage-dir"),
        storage_dir.path().as_os_str(),
        std::ffi::OsStr::new("--project-name"),
        std::ffi::OsStr::new("demo_counter"),
        std::ffi::OsStr::new("--app-id"),
        std::ffi::OsStr::new("counter-app-0001"),
        std::ffi::OsStr::new("--sequence-id"),
        std::ffi::OsStr::new("1"),
        std::ffi::OsStr::new("--target-file-name"),
        fixture_path.as_os_str(),
        std::ffi::OsStr::new("--serde-decoder"),
        decoder.path().as_os_str(),
    ]);
    assert_failure(&output, "nonzero serde decoder should fail");
    let stderr = stderr_lossy(&output);
    let helper_name = decoder
        .path()
        .file_name()
        .expect("test decoder path should have a file name");
    assert!(
        stderr.contains("exited with status"),
        "stderr should mention the helper exit status: {stderr}"
    );
    assert!(
        stderr.contains("decoder failed on purpose"),
        "stderr should include helper stderr: {stderr}"
    );
    assert!(
        stderr.contains(helper_name.to_string_lossy().as_ref()),
        "stderr should include helper file name: {stderr}"
    );
    assert!(
        !fixture_path.exists(),
        "fixture file should not be created when helper exits nonzero"
    );
}

#[test]
fn test_case_create_leaves_existing_fixture_unchanged_when_serde_decoder_stdout_is_invalid() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("invalid-stdout-fixture.json");
    let decoder = install_test_serde_decoder(TestSerdeDecoderBehavior::InvalidJson)
        .expect("invalid-json serde decoder should be created");
    let original_contents = serde_json::json!([
        {
            "name": "existing_fixture",
            "action": "counter",
            "input_state": {"count": 0},
            "expected_state": {"count": 1}
        }
    ]);
    fs::write(
        &fixture_path,
        serde_json::to_string_pretty(&original_contents)
            .expect("fixture contents should serialize"),
    )
    .expect("fixture path should be seeded");

    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            serde_json::json!({
                "custom_field": {"value": "serialized::before"}
            }),
            serde_json::json!({
                "custom_field": {"value": "serialized::after"}
            }),
        ],
    );

    let output = run_test_case_create(&[
        std::ffi::OsStr::new("--storage-dir"),
        storage_dir.path().as_os_str(),
        std::ffi::OsStr::new("--project-name"),
        std::ffi::OsStr::new("demo_counter"),
        std::ffi::OsStr::new("--app-id"),
        std::ffi::OsStr::new("counter-app-0001"),
        std::ffi::OsStr::new("--sequence-id"),
        std::ffi::OsStr::new("1"),
        std::ffi::OsStr::new("--target-file-name"),
        fixture_path.as_os_str(),
        std::ffi::OsStr::new("--serde-decoder"),
        decoder.path().as_os_str(),
    ]);
    assert_failure(&output, "invalid decoder stdout should fail");
    let stderr = stderr_lossy(&output);
    assert!(
        stderr.contains("invalid"),
        "stderr should mention invalid helper output: {stderr}"
    );

    let fixture_contents =
        fs::read_to_string(&fixture_path).expect("existing fixture should remain readable");
    let fixture_json: Value =
        serde_json::from_str(&fixture_contents).expect("existing fixture should remain valid json");
    assert_eq!(fixture_json, original_contents);
}

#[test]
fn test_case_create_fails_clearly_when_serde_decoder_returns_non_object_json() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("non-object-decoder-fixture.json");
    let decoder = install_test_serde_decoder(TestSerdeDecoderBehavior::NonObject)
        .expect("non-object serde decoder should be created");

    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            serde_json::json!({
                "custom_field": {"value": "serialized::before"}
            }),
            serde_json::json!({
                "custom_field": {"value": "serialized::after"}
            }),
        ],
    );

    let output = run_test_case_create(&[
        std::ffi::OsStr::new("--storage-dir"),
        storage_dir.path().as_os_str(),
        std::ffi::OsStr::new("--project-name"),
        std::ffi::OsStr::new("demo_counter"),
        std::ffi::OsStr::new("--app-id"),
        std::ffi::OsStr::new("counter-app-0001"),
        std::ffi::OsStr::new("--sequence-id"),
        std::ffi::OsStr::new("1"),
        std::ffi::OsStr::new("--target-file-name"),
        fixture_path.as_os_str(),
        std::ffi::OsStr::new("--serde-decoder"),
        decoder.path().as_os_str(),
    ]);
    assert_failure(&output, "non-object decoder stdout should fail");
    let stderr = stderr_lossy(&output);
    assert!(
        stderr.contains("must return a JSON object"),
        "stderr should mention the decoder object contract: {stderr}"
    );
    assert!(
        !fixture_path.exists(),
        "fixture file should not be created when helper returns a non-object"
    );
}
