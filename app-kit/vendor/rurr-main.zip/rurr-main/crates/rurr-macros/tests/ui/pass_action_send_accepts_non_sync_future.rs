use indexmap::IndexMap;
use rurr_core::action::{Action, ActionContext, ActionError, ActionResult};
use rurr_core::state::State;
use serde_json::json;
use std::cell::Cell;

#[derive(Clone)]
struct SendButNotSyncFutureAction;

impl Action for SendButNotSyncFutureAction {
    fn name(&self) -> Option<&str> {
        Some("send_not_sync")
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn with_name(&self, _name: impl Into<String>) -> Result<Self, ActionError> {
        Ok(self.clone())
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
    }

    async fn run_async(
        &self,
        _state: &State,
        _ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        let local = Cell::new(1);
        tokio::task::yield_now().await;
        local.set(local.get() + 1);
        Ok(ActionResult::new(
            IndexMap::from([("value".to_string(), json!(local.get()))]),
            IndexMap::new(),
        ))
    }
}

fn assert_action<T: Action>(action: &T) {
    let _ = action;
}

fn main() {
    assert_action(&SendButNotSyncFutureAction);
}
