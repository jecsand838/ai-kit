pub(crate) use super::super::application::{count_zero_state, ApplicationScenario};
use super::actions::{
    async_run_failing_action, failing_update_action, streaming_count_action,
    update_tracing_non_streaming_action,
};
use indexmap::IndexMap;
use rurr_core::action::{
    Condition, FunctionAction, FunctionActionBuilder, LocalAction, ResultAction,
};
use rurr_core::application::ApplicationError;
use rurr_core::graph::{GraphAction, Transition};
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::parallelism::{CascadeMode, ParallelMap, ParallelTaskSource, RunnableGraph};
use rurr_core::state::State;
use rurr_persistence::{
    BaseStateLoader, BaseStatePersister, BaseStateSaver, PersistedStateData, PersistedStateStatus,
    PersistenceError,
};
use rurr_testkit::application_fixture::{
    map_from_pairs, state_from_pairs, ApplicationFixtureBuilder,
};
use serde_json::{json, Value};
use std::sync::atomic::AtomicUsize;
use std::sync::Arc;

#[derive(Debug, Default)]
pub(crate) struct FailingCommitPersister;

impl BaseStateLoader for FailingCommitPersister {
    fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(None)
    }

    fn list_app_ids(&self, _partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

impl BaseStateSaver for FailingCommitPersister {
    fn save(
        &self,
        _partition_key: Option<&str>,
        _app_id: &str,
        _sequence_id: u64,
        _position: &str,
        _state: IndexMap<String, Value>,
        _status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        Err(PersistenceError::UnsupportedOperation {
            operation: "intentional_stream_commit_failure",
        })
    }
}

pub(crate) fn build_resumed_non_streaming_chain_app(
    state: State,
    actions: Vec<(&str, FunctionAction)>,
    transitions: Vec<Transition>,
    entrypoint: &str,
) -> Result<rurr_core::Application, ApplicationError> {
    let mut builder = ApplicationFixtureBuilder::new(state)?;
    for (name, action) in actions {
        builder = builder.with_action(name, action)?;
    }
    builder
        .with_transitions(transitions)?
        .with_entrypoint(entrypoint)?
        .build()
}

pub(crate) fn build_count_zero_action_app<A: LocalAction + Send + Sync + 'static>(
    action_name: &str,
    action: A,
) -> Result<rurr_core::Application, ApplicationError> {
    ApplicationScenario::single_action(count_zero_state(), action_name, action)
        .and_then(ApplicationScenario::build)
}

pub(crate) fn build_count_zero_action_app_with_hooks<A: LocalAction + Send + Sync + 'static>(
    action_name: &str,
    action: A,
    hooks: LifecycleAdapterSet,
) -> Result<rurr_core::Application, ApplicationError> {
    ApplicationScenario::single_action(count_zero_state(), action_name, action)
        .map(|scenario| scenario.with_hooks(hooks))
        .and_then(ApplicationScenario::build)
}

pub(crate) fn build_count_zero_transition_app<
    A: LocalAction + Send + Sync + 'static,
    B: LocalAction + Send + Sync + 'static,
>(
    first_name: &str,
    first_action: A,
    second_name: &str,
    second_action: B,
    transitions: Vec<Transition>,
) -> Result<rurr_core::Application, ApplicationError> {
    ApplicationScenario::two_action_transition(
        count_zero_state(),
        first_name,
        first_action,
        second_name,
        second_action,
        transitions,
    )
    .and_then(ApplicationScenario::build)
}

pub(crate) fn build_streaming_app<A: LocalAction + Send + Sync + 'static>(
    action: A,
) -> Result<rurr_core::Application, ApplicationError> {
    build_count_zero_action_app("stream", action)
}

pub(crate) fn build_streaming_app_with_hooks(
    action: FunctionAction,
    hooks: LifecycleAdapterSet,
) -> Result<rurr_core::Application, ApplicationError> {
    build_streaming_app_with_hooks_and_optional_persister(action, hooks, None)
}

pub(crate) fn build_streaming_app_with_hooks_and_persister(
    action: FunctionAction,
    hooks: LifecycleAdapterSet,
    persister: Arc<dyn BaseStatePersister>,
) -> Result<rurr_core::Application, ApplicationError> {
    build_streaming_app_with_hooks_and_optional_persister(action, hooks, Some(persister))
}

pub(crate) fn build_streaming_app_with_hooks_and_optional_persister(
    action: FunctionAction,
    hooks: LifecycleAdapterSet,
    persister: Option<Arc<dyn BaseStatePersister>>,
) -> Result<rurr_core::Application, ApplicationError> {
    ApplicationScenario::single_action(count_zero_state(), "stream", action)?
        .with_hooks(hooks)
        .with_optional_sync_persister(persister)?
        .build()
}

pub(crate) fn build_update_tracing_non_streaming_app_with_hooks(
    hooks: LifecycleAdapterSet,
) -> Result<rurr_core::Application, ApplicationError> {
    build_count_zero_action_app_with_hooks(
        "non_stream",
        update_tracing_non_streaming_action(),
        hooks,
    )
}

pub(crate) fn build_async_run_failure_non_streaming_app_with_hooks(
    hooks: LifecycleAdapterSet,
) -> Result<rurr_core::Application, ApplicationError> {
    build_count_zero_action_app_with_hooks("non_stream", async_run_failing_action(), hooks)
}

pub(crate) fn build_map_states_async_child_app() -> Result<rurr_core::Application, ApplicationError>
{
    let child_async = FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .build_async(|state, _ctx| async move {
            let next = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            map_from_pairs([("count", json!(next))])
        })
        .expect("child async action should build")
        .with_name("child_async")
        .expect("child async action should be named");
    let child_result = ResultAction::new(["count"])
        .with_name("result")
        .expect("child result action should be named");
    let child_graph = RunnableGraph::new(
        vec![
            GraphAction::new(child_async).expect("child async graph action should construct"),
            GraphAction::new(child_result).expect("child result graph action should construct"),
        ],
        vec![Transition::new(
            "child_async",
            "result",
            Condition::default(),
        )],
        Some("child_async".to_string()),
    );

    let map_states = ParallelMap::new(
        ParallelTaskSource::states(child_graph, Arc::new(|state, _ctx| Ok(vec![state.clone()]))),
        vec!["count".to_string()],
        vec!["count".to_string()],
        vec![],
        CascadeMode::None,
    );

    ApplicationFixtureBuilder::single_action(
        state_from_pairs([("count", json!(0))]),
        "parallel",
        map_states,
    )?
    .build()
}

pub(crate) fn build_failing_update_non_streaming_app_with_hooks(
    action: FunctionAction,
    hooks: LifecycleAdapterSet,
) -> Result<rurr_core::Application, ApplicationError> {
    build_count_zero_action_app_with_hooks("non_stream", action, hooks)
}

pub(crate) fn build_pending_async_streaming_app(
    action: FunctionAction,
) -> Result<rurr_core::Application, ApplicationError> {
    build_streaming_app(action)
}

pub(crate) fn build_never_ready_async_streaming_app_with_hooks(
    action: FunctionAction,
    hooks: LifecycleAdapterSet,
) -> Result<rurr_core::Application, ApplicationError> {
    build_count_zero_action_app_with_hooks("stream", action, hooks)
}

pub(crate) fn build_pre_target_failure_app(
    failing_calls: Arc<AtomicUsize>,
) -> Result<rurr_core::Application, ApplicationError> {
    let failing = failing_update_action(failing_calls);
    let target_calls = Arc::new(AtomicUsize::new(0));
    let target = streaming_count_action(target_calls, 3, None);
    build_count_zero_transition_app(
        "pre",
        failing,
        "target",
        target,
        vec![Transition::new("pre", "target", Condition::default())],
    )
}

pub(crate) fn build_non_send_streaming_app(
    action: FunctionAction,
) -> Result<rurr_core::Application, ApplicationError> {
    build_streaming_app(action)
}

pub(crate) fn build_error_streaming_app(
    action: FunctionAction,
) -> Result<rurr_core::Application, ApplicationError> {
    build_streaming_app(action)
}

pub(crate) fn build_error_streaming_app_with_hooks(
    action: FunctionAction,
    hooks: LifecycleAdapterSet,
) -> Result<rurr_core::Application, ApplicationError> {
    build_count_zero_action_app_with_hooks("stream", action, hooks)
}

pub(crate) fn build_uncommitted_streaming_app(
    action: FunctionAction,
) -> Result<rurr_core::Application, ApplicationError> {
    build_streaming_app(action)
}

pub(crate) fn build_empty_streaming_source_app(
    action: FunctionAction,
) -> Result<rurr_core::Application, ApplicationError> {
    build_streaming_app(action)
}

pub(crate) fn build_pre_target_stream_guard_app(
    pre_target: FunctionAction,
    target: FunctionAction,
) -> Result<rurr_core::Application, ApplicationError> {
    build_count_zero_transition_app(
        "A",
        pre_target,
        "B",
        target,
        vec![Transition::new("A", "B", Condition::default())],
    )
}
