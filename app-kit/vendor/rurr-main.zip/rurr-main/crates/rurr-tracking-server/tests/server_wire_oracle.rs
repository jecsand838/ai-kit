use axum::body::Body;
use axum::http::{header, Request};
use http_body_util::BodyExt;
use rurr_oracle_test_support::{
    burr_oracle_scenarios, run_oracle_scenario, BurrOracleScenario, BurrOracleScenarioId,
};
use rurr_testkit::test_dir_for_test;
use rurr_tracking_server::backend::local::LocalBackend;
use rurr_tracking_server::router::AppState;
use serde_json::{json, Value};
use std::collections::BTreeSet;
use std::env;
use std::error::Error;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use tower::ServiceExt;

const OUTPUT_ROOT_ENV: &str = "RURR_SERVER_WIRE_OUTPUT_ROOT";
const SCENARIO_FILTER_ENV: &str = "RURR_SERVER_WIRE_SCENARIO_IDS";

#[derive(Clone, Debug)]
struct EndpointRequest {
    id: &'static str,
    path: String,
}

#[tokio::test]
async fn server_wire_oracle_payloads_write_to_requested_root() -> Result<(), Box<dyn Error>> {
    let Some(output_root) = output_root() else {
        return Ok(());
    };

    if output_root.exists() {
        fs::remove_dir_all(&output_root)?;
    }
    fs::create_dir_all(&output_root)?;

    let storage_root = test_dir_for_test()?;
    for definition in selected_scenarios()? {
        let scenario_id = definition.id.as_str();
        let _ = run_oracle_scenario(definition, &storage_root)?;
        let scenario_storage = storage_root.join(scenario_id);
        let app = rurr_tracking_server::app_with_state(AppState::with_embedded_ui(Arc::new(
            LocalBackend::new(&scenario_storage)?,
        )));

        for endpoint in endpoint_requests(definition) {
            let payload = request_payload(&app, &endpoint.path).await?;
            write_payload(&output_root, scenario_id, endpoint.id, payload)?;
        }
    }

    Ok(())
}

fn output_root() -> Option<PathBuf> {
    env::var_os(OUTPUT_ROOT_ENV)
        .filter(|value| !value.is_empty())
        .map(PathBuf::from)
}

fn selected_scenario_ids() -> BTreeSet<&'static str> {
    [
        BurrOracleScenarioId::CounterBasic.as_str(),
        BurrOracleScenarioId::SpansAndAttributes.as_str(),
        BurrOracleScenarioId::StreamingAction.as_str(),
        BurrOracleScenarioId::ForkAndSpawnChildren.as_str(),
    ]
    .into_iter()
    .collect()
}

fn requested_scenario_ids() -> Option<BTreeSet<String>> {
    let raw = env::var(SCENARIO_FILTER_ENV).ok()?;
    let selected: BTreeSet<_> = raw
        .split(',')
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_string)
        .collect();
    (!selected.is_empty()).then_some(selected)
}

fn selected_scenarios() -> Result<Vec<&'static BurrOracleScenario>, Box<dyn Error>> {
    let supported = selected_scenario_ids();
    let requested = requested_scenario_ids();
    let active_ids: BTreeSet<String> = requested.clone().unwrap_or_else(|| {
        supported
            .iter()
            .map(|scenario_id| (*scenario_id).to_string())
            .collect()
    });

    let unsupported: Vec<_> = active_ids
        .iter()
        .filter(|scenario_id| !supported.contains(scenario_id.as_str()))
        .cloned()
        .collect();
    if !unsupported.is_empty() {
        return Err(format!(
            "unknown or unsupported scenario ids in {SCENARIO_FILTER_ENV}: {unsupported:?}"
        )
        .into());
    }

    let scenarios: Vec<_> = burr_oracle_scenarios()
        .iter()
        .filter(|definition| active_ids.contains(definition.id.as_str()))
        .collect();
    let matched: BTreeSet<_> = scenarios
        .iter()
        .map(|definition| definition.id.as_str().to_string())
        .collect();
    let missing: Vec<_> = active_ids.difference(&matched).cloned().collect();
    if !missing.is_empty() {
        return Err(format!("missing server-wire scenario definitions: {missing:?}").into());
    }

    Ok(scenarios)
}

fn endpoint_requests(definition: &BurrOracleScenario) -> Vec<EndpointRequest> {
    let project = definition.project.as_str();
    let app_id = definition.app_id.as_str();
    let partition = partition_path_segment(definition);
    let mut requests = vec![
        EndpointRequest {
            id: "ready",
            path: "/ready".to_string(),
        },
        EndpointRequest {
            id: "api_ready",
            path: "/api/v0/ready".to_string(),
        },
        EndpointRequest {
            id: "projects",
            path: "/api/v0/projects".to_string(),
        },
    ];

    if matches!(
        definition.id,
        BurrOracleScenarioId::CounterBasic
            | BurrOracleScenarioId::SpansAndAttributes
            | BurrOracleScenarioId::StreamingAction
    ) {
        requests.push(EndpointRequest {
            id: "apps",
            path: format!("/api/v0/{project}/{partition}/apps?limit=100&offset=0"),
        });
    }

    requests.push(EndpointRequest {
        id: "app_detail",
        path: format!("/api/v0/{project}/{app_id}/{partition}/apps"),
    });
    requests
}

fn partition_path_segment(definition: &BurrOracleScenario) -> &str {
    if definition.partition_key.is_empty() {
        "__none__"
    } else {
        definition.partition_key.as_str()
    }
}

async fn request_payload(app: &axum::Router, path: &str) -> Result<Value, Box<dyn Error>> {
    let response = app
        .clone()
        .oneshot(Request::builder().uri(path).body(Body::empty())?)
        .await?;
    let status = response.status().as_u16();
    let content_type = response
        .headers()
        .get(header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("")
        .to_string();
    let body_bytes = response.into_body().collect().await?.to_bytes();
    let body: Value = serde_json::from_slice(&body_bytes)?;

    Ok(json!({
        "method": "GET",
        "path": path,
        "status": status,
        "content_type": content_type,
        "body": body,
    }))
}

fn write_payload(
    root: &Path,
    scenario_id: &str,
    endpoint_id: &str,
    payload: Value,
) -> Result<(), Box<dyn Error>> {
    let scenario_dir = root.join(scenario_id);
    fs::create_dir_all(&scenario_dir)?;
    fs::write(
        scenario_dir.join(format!("{endpoint_id}.json")),
        format!("{}\n", serde_json::to_string_pretty(&payload)?),
    )?;
    Ok(())
}
