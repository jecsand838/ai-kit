use super::common::response_item;
use super::sources::{AsyncChunkSource, AsyncChunkStream, AsyncChunkStreamFuture};
use futures::{stream, Stream, StreamExt};
use indexmap::IndexMap;
use rurr_core::{ActionError, RurrError, State};
use serde_json::Value;

pub(super) async fn materialize_async_response<S: AsyncChunkSource>(
    source: &S,
    prompt: &str,
) -> Result<String, ActionError> {
    let mut stream = source
        .stream_chunks_async(prompt)
        .await
        .map_err(|message| ActionError::Internal { message })?;
    let mut response = String::new();
    while let Some(item) = stream.next().await {
        let delta = item.map_err(|message| ActionError::Internal { message })?;
        response.push_str(&delta);
    }
    Ok(response)
}

enum AsyncOutputState {
    Pending {
        future: AsyncChunkStreamFuture,
        buffer: String,
        state: State,
    },
    Streaming {
        stream: AsyncChunkStream,
        buffer: String,
        state: State,
    },
    Done,
}

pub(super) fn async_stream_outputs_from_source<S: AsyncChunkSource>(
    source: S,
    state: State,
    prompt: String,
) -> impl Stream<Item = Result<(IndexMap<String, Value>, Option<State>), RurrError>> + Send {
    stream::unfold(
        AsyncOutputState::Pending {
            future: source.stream_chunks_async(&prompt),
            buffer: String::new(),
            state,
        },
        |phase| async move {
            let mut phase = phase;
            loop {
                match phase {
                    AsyncOutputState::Pending {
                        future,
                        buffer,
                        state,
                    } => match future.await {
                        Ok(stream) => {
                            phase = AsyncOutputState::Streaming {
                                stream,
                                buffer,
                                state,
                            };
                        }
                        Err(message) => {
                            return Some((
                                Err(RurrError::Message(message)),
                                AsyncOutputState::Done,
                            ));
                        }
                    },
                    AsyncOutputState::Streaming {
                        mut stream,
                        mut buffer,
                        state,
                    } => match stream.next().await {
                        Some(Ok(delta)) => {
                            buffer.push_str(&delta);
                            return Some((
                                Ok((response_item(&delta), None)),
                                AsyncOutputState::Streaming {
                                    stream,
                                    buffer,
                                    state,
                                },
                            ));
                        }
                        Some(Err(message)) => {
                            return Some((
                                Err(RurrError::Message(message)),
                                AsyncOutputState::Done,
                            ));
                        }
                        None => {
                            let final_state = match state.update(response_item(&buffer)) {
                                Ok(state) => state,
                                Err(error) => {
                                    return Some((
                                        Err(RurrError::Action(ActionError::from(error))),
                                        AsyncOutputState::Done,
                                    ));
                                }
                            };
                            return Some((
                                Ok((response_item(&buffer), Some(final_state))),
                                AsyncOutputState::Done,
                            ));
                        }
                    },
                    AsyncOutputState::Done => return None,
                }
            }
        },
    )
}
