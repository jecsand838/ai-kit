use super::core::{
    count_action_metadata, increment_count_result, StreamScript, StreamScriptSpecExt,
};
use rurr_core::action::{ActionError, FunctionAction};
use rurr_testkit::action_fixture::{scripted_action, ScriptedActionSpec};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

pub(crate) fn async_run_failing_action() -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|state, _ctx| Ok(increment_count_result(state)))
            .with_async_run(|_state, _ctx| {
                Box::pin(async {
                    Err(ActionError::Internal {
                        message: "intentional async run failure".to_string(),
                    })
                })
            })
            .with_stream_scripts(StreamScript::IncrementOnce, StreamScript::AsyncRunFailure),
    )
}

pub(crate) fn non_send_streaming_action(calls: Arc<AtomicUsize>) -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|state, _ctx| Ok(increment_count_result(state)))
            .with_stream_scripts(
                StreamScript::NonSendTwoStep {
                    calls: Arc::clone(&calls),
                },
                StreamScript::NonSendTwoStep { calls },
            ),
    )
}

pub(crate) fn empty_streaming_source_action(
    run_calls: Arc<AtomicUsize>,
    run_async_calls: Arc<AtomicUsize>,
) -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(move |state, _ctx| {
            run_calls.fetch_add(1, Ordering::SeqCst);
            Ok(increment_count_result(state))
        })
        .with_async_run(move |state, _ctx| {
            let run_async_calls = Arc::clone(&run_async_calls);
            Box::pin(async move {
                run_async_calls.fetch_add(1, Ordering::SeqCst);
                Ok(increment_count_result(state))
            })
        })
        .with_stream_script(StreamScript::Empty),
    )
}

pub(crate) fn pre_target_run_only_action(
    run_calls: Arc<AtomicUsize>,
    stream_attempts: Arc<AtomicUsize>,
) -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(move |state, _ctx| {
            run_calls.fetch_add(1, Ordering::SeqCst);
            Ok(increment_count_result(state))
        })
        .with_stream_scripts(
            StreamScript::PreTargetError {
                attempts: Arc::clone(&stream_attempts),
            },
            StreamScript::PreTargetError {
                attempts: stream_attempts,
            },
        ),
    )
}

pub(crate) fn pending_async_stream_action(
    calls: Arc<AtomicUsize>,
    pending_polls: Arc<AtomicUsize>,
) -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|state, _ctx| Ok(increment_count_result(state)))
            .with_stream_scripts(
                StreamScript::IncrementOnce,
                StreamScript::PendingFirstPoll {
                    calls,
                    pending_polls,
                },
            ),
    )
}

pub(crate) fn never_ready_async_stream_action(pending_polls: Arc<AtomicUsize>) -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|state, _ctx| Ok(increment_count_result(state)))
            .with_stream_scripts(
                StreamScript::IncrementOnce,
                StreamScript::NeverReady { pending_polls },
            ),
    )
}
