# Rustdoc House Style

Use this style for public Rustdocs across the workspace.

## Core rules

- Use `//!` for crate and module docs.
- Use `///` for public items.
- Start with a short summary sentence that is easy to scan in generated docs.
- Explain behavior, invariants, defaults, and edge cases instead of restating the type signature.
- Keep docs on the canonical source item. Keep re-export docs short unless the re-export adds important usage context.

## Section guidance

- Add `# Examples` when runnable examples materially help users.
- Add `# Errors` for fallible APIs.
- Add `# Panics` only when panic conditions are part of the contract.
- Add `# Safety` for unsafe items.
- Add async or runtime notes when examples need setup that users would otherwise miss.

## Coverage guidance

- Document public structs, enums, traits, type aliases, functions, methods, constants, and modules that appear in end-user docs.
- Keep trait-level docs responsible for shared method semantics across implementations.
- Add crate-root docs when the crate exposes a user-facing API surface.

## What not to do

- Do not suppress missing-doc warnings instead of writing docs.
- Do not hide public items just to avoid documenting them.
- Do not use sidecar Markdown in place of Rustdoc comments for public APIs.
