use super::keys::{ActiveSpanKey, OtelContextGuardKey, StepKey};
use super::registry::OtelTrackingRegistry;
use super::{attach_otel_context, detach_otel_context};
use crate::opentelemetry::trace::{SpanContext as OtelSpanContext, TraceContextExt};
use crate::opentelemetry::Context;

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) enum SpanKind {
    Step(StepKey),
    Visibility(ActiveSpanKey),
}

impl SpanKind {
    fn guard_key(&self) -> OtelContextGuardKey {
        match self {
            Self::Step(key) => OtelContextGuardKey::Step(key.clone()),
            Self::Visibility(key) => OtelContextGuardKey::Span(key.clone()),
        }
    }
}

pub(super) struct SpanSlot {
    kind: SpanKind,
    context: Context,
    span_context: OtelSpanContext,
    context_guard_attached: bool,
}

impl SpanSlot {
    pub(super) fn new(kind: SpanKind, context: Context, span_context: OtelSpanContext) -> Self {
        Self {
            kind,
            context,
            span_context,
            context_guard_attached: false,
        }
    }

    pub(super) fn context(&self) -> &Context {
        &self.context
    }

    pub(super) fn span_context(&self) -> &OtelSpanContext {
        &self.span_context
    }

    pub(super) fn attach_sync_guard(&mut self) {
        attach_otel_context(self.kind.guard_key(), self.context.clone());
        self.context_guard_attached = true;
    }

    pub(super) fn finish<F>(self, registry: Option<&OtelTrackingRegistry>, record_missing_guard: F)
    where
        F: FnOnce(OtelContextGuardKey),
    {
        let guard_key = self.kind.guard_key();
        self.context.span().end();
        if let Some(registry) = registry {
            registry.forget_span(self.span_context.span_id());
        }
        if self.context_guard_attached && !detach_otel_context(&guard_key) {
            record_missing_guard(guard_key);
        }
    }
}
