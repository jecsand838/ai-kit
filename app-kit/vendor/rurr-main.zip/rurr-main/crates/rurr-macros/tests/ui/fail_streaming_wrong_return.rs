use rurr_core::action::StreamOutput;
use rurr_core::state::State;

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
fn bad_stream_return(_state: &State) -> Vec<StreamOutput> {
    Vec::new()
}

fn main() {}
