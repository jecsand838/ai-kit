use super::{PersistenceError, OP_CONNECTION_CLOSED};

/// Maps a PostgreSQL SQLSTATE code into the closest persistence-layer error
/// variant.
pub fn map_sqlstate_error(
    sqlstate: Option<&str>,
    fallback_operation: &'static str,
) -> PersistenceError {
    match sqlstate {
        Some("42P01") => PersistenceError::NotInitialized,
        _ => PersistenceError::UnsupportedOperation {
            operation: fallback_operation,
        },
    }
}

/// Maps an async `sqlx` PostgreSQL error into the closest persistence-layer
/// error variant.
pub fn map_sqlx_error(error: sqlx::Error, fallback_operation: &'static str) -> PersistenceError {
    match error {
        sqlx::Error::PoolClosed => PersistenceError::UnsupportedOperation {
            operation: OP_CONNECTION_CLOSED,
        },
        sqlx::Error::Database(db_error) => {
            map_sqlstate_error(db_error.code().as_deref(), fallback_operation)
        }
        _ => map_sqlstate_error(None, fallback_operation),
    }
}

/// Maps a synchronous `postgres` client error into the closest persistence-layer
/// error variant.
pub fn map_postgres_error(
    error: postgres::Error,
    fallback_operation: &'static str,
) -> PersistenceError {
    if error.is_closed() {
        return PersistenceError::UnsupportedOperation {
            operation: OP_CONNECTION_CLOSED,
        };
    }

    map_sqlstate_error(
        error.as_db_error().map(|db_error| db_error.code().code()),
        fallback_operation,
    )
}
