use crate::contract_logic::{
    app_index_exact_sequence_lex_range, persisted_state_from_hash, RecordLoadQuery,
};
use crate::sync_impl::{RedisPersister, SyncConnectionReplayPolicy};
use crate::OP_REDIS_COMMAND_FAILED;
use redis::aio::ConnectionManager;
use redis::{AsyncCommands, Commands, Connection};
use rurr_persistence::{PersistedStateData, PersistenceError};
use std::collections::HashMap;

async fn latest_zset_member_async(
    connection: &mut ConnectionManager,
    key: &str,
) -> Result<Option<String>, PersistenceError> {
    let members: Vec<String> = connection.zrevrange(key, 0, 0).await.map_err(|_| {
        PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_COMMAND_FAILED,
        }
    })?;
    Ok(members.into_iter().next())
}

pub(crate) async fn load_record_key_async(
    connection: &mut ConnectionManager,
    query: &RecordLoadQuery,
) -> Result<Option<String>, PersistenceError> {
    let Some(index_key) = query.index_key() else {
        return Ok(None);
    };
    let member = match query {
        RecordLoadQuery::NoRecord => return Ok(None),
        RecordLoadQuery::LatestPartition { .. } | RecordLoadQuery::LatestApp { .. } => {
            latest_zset_member_async(connection, index_key).await?
        }
        RecordLoadQuery::ExactSequence { sequence_id, .. } => {
            exact_sequence_member_async(connection, index_key, *sequence_id).await?
        }
    };
    query.record_key_from_member(member)
}

async fn exact_sequence_member_async(
    connection: &mut ConnectionManager,
    key: &str,
    sequence_id: u64,
) -> Result<Option<String>, PersistenceError> {
    let (max, min) = app_index_exact_sequence_lex_range(sequence_id);
    let members: Vec<String> = connection
        .zrevrangebylex_limit(key, max, min, 0, 1)
        .await
        .map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_COMMAND_FAILED,
        })?;
    Ok(members.into_iter().next())
}

pub(crate) async fn partition_index_members_batch_async(
    connection: &mut ConnectionManager,
    key: &str,
    start: usize,
    end: usize,
) -> Result<Vec<String>, PersistenceError> {
    connection
        .zrevrange(key, start as isize, end as isize)
        .await
        .map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_COMMAND_FAILED,
        })
}

pub(crate) async fn load_record_async(
    connection: &mut ConnectionManager,
    record_key: &str,
) -> Result<Option<PersistedStateData>, PersistenceError> {
    let fields: HashMap<String, String> = connection.hgetall(record_key).await.map_err(|_| {
        PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_COMMAND_FAILED,
        }
    })?;
    persisted_state_from_hash(fields)
}

fn latest_zset_member(
    connection: &mut Connection,
    key: &str,
) -> redis::RedisResult<Option<String>> {
    let members: Vec<String> = connection.zrevrange(key, 0, 0)?;
    Ok(members.into_iter().next())
}

fn exact_sequence_member(
    connection: &mut Connection,
    key: &str,
    sequence_id: u64,
) -> redis::RedisResult<Option<String>> {
    let (max, min) = app_index_exact_sequence_lex_range(sequence_id);
    let members: Vec<String> = connection.zrevrangebylex_limit(key, max, min, 0, 1)?;
    Ok(members.into_iter().next())
}

pub(crate) fn load_record_key_sync(
    persister: &RedisPersister,
    query: &RecordLoadQuery,
) -> Result<Option<String>, PersistenceError> {
    let Some(index_key) = query.index_key() else {
        return Ok(None);
    };
    let member = match query {
        RecordLoadQuery::NoRecord => return Ok(None),
        RecordLoadQuery::LatestPartition { .. } | RecordLoadQuery::LatestApp { .. } => persister
            .with_connection(
                SyncConnectionReplayPolicy::RetryOnTransportFailure,
                |connection| latest_zset_member(connection, index_key),
            )?,
        RecordLoadQuery::ExactSequence { sequence_id, .. } => persister.with_connection(
            SyncConnectionReplayPolicy::RetryOnTransportFailure,
            |connection| exact_sequence_member(connection, index_key, *sequence_id),
        )?,
    };
    query.record_key_from_member(member)
}

pub(crate) fn partition_index_members_batch_sync(
    persister: &RedisPersister,
    partition_index_key: &str,
    start: usize,
    end: usize,
) -> Result<Vec<String>, PersistenceError> {
    persister.with_connection(
        SyncConnectionReplayPolicy::RetryOnTransportFailure,
        |connection| connection.zrevrange(partition_index_key, start as isize, end as isize),
    )
}

pub(crate) fn load_record_sync(
    persister: &RedisPersister,
    record_key: &str,
) -> Result<Option<PersistedStateData>, PersistenceError> {
    let fields: HashMap<String, String> = persister.with_connection(
        SyncConnectionReplayPolicy::RetryOnTransportFailure,
        |connection| connection.hgetall(record_key),
    )?;
    persisted_state_from_hash(fields)
}
