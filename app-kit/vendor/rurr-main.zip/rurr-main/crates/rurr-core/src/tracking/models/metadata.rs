use crate::application::ParentPointer;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serialized pointer to a parent or child application.
///
/// Pointer models are stored in local metadata JSON and encoded into S3 user
/// metadata for server indexing.
pub struct PointerModel {
    /// Record discriminator used in tracking JSON.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Application identifier.
    pub app_id: String,
    /// Optional sequence id associated with the pointer.
    pub sequence_id: Option<u64>,
    /// Optional partition key associated with the pointer.
    pub partition_key: Option<String>,
}

impl PointerModel {
    pub(crate) fn application(
        app_id: impl Into<String>,
        partition_key: Option<String>,
        sequence_id: Option<u64>,
    ) -> Self {
        Self {
            r#type: "pointer_data".to_string(),
            app_id: app_id.into(),
            sequence_id,
            partition_key,
        }
    }

    /// Builds a pointer model from a runtime parent pointer.
    pub fn from_parent_pointer(pointer: &ParentPointer) -> Self {
        Self::application(
            pointer.app_id.clone(),
            pointer.partition_key.clone(),
            pointer.sequence_id,
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serialized metadata for a tracked application instance.
///
/// This is the `metadata.json` payload written beside graph and log artifacts.
pub struct ApplicationMetadataModel {
    /// Record discriminator used in tracking JSON.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Partition key assigned to the application, if any.
    pub partition_key: Option<String>,
    /// Pointer to the logical parent application, if any.
    pub parent_pointer: Option<PointerModel>,
    /// Pointer to the application that spawned this one, if any.
    pub spawning_parent_pointer: Option<PointerModel>,
}

impl ApplicationMetadataModel {
    /// Builds application metadata from optional partition and parent pointers.
    pub fn new(
        partition_key: Option<String>,
        parent_pointer: Option<ParentPointer>,
        spawning_parent_pointer: Option<ParentPointer>,
    ) -> Self {
        Self {
            r#type: "application_metadata".to_string(),
            partition_key,
            parent_pointer: parent_pointer
                .as_ref()
                .map(PointerModel::from_parent_pointer),
            spawning_parent_pointer: spawning_parent_pointer
                .as_ref()
                .map(PointerModel::from_parent_pointer),
        }
    }
}
