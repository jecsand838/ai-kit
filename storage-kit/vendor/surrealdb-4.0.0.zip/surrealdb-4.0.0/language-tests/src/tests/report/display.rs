use std::fmt::{self, Write};
use std::io::{self, IsTerminal as _};
use std::time::{Duration, Instant};

use similar::{Algorithm, TextDiff};
use surrealdb_types::{ToSql, Value as SurValue};

use super::{
	MatchValueType, MatcherMismatch, Mismatch, MismatchKind, ResultTypeMismatchReport, TestError,
	TestGrade, TestOutputs, TestReport, TestValueExpectation, ValueMismatchKind,
};
use crate::cli::ColorMode;
use crate::format::{IndentFormatter, ansi};

type Fmt<'a> = IndentFormatter<&'a mut String>;

impl TestReport {
	pub fn display(&self, color: ColorMode) {
		if self.grade() == TestGrade::Success && !self.is_wip() {
			// nothing to report
			return;
		}
		if self.grade() == TestGrade::Skipped {
			// Skips are accounted for in the summary count, not printed per-test.
			return;
		}
		let use_color = match color {
			ColorMode::Always => true,
			ColorMode::Never => false,
			ColorMode::Auto => io::stdout().is_terminal(),
		};
		let mut buffer = String::new();
		let mut f = Fmt::new(&mut buffer, 2);
		f.indent(|f| self.display_grade(use_color, f)).unwrap();

		println!("{buffer}");
	}

	fn display_grade(&self, use_color: bool, f: &mut Fmt) -> fmt::Result {
		self.display_grade_header(use_color, f)?;

		f.indent(|f| self.display_kind(&self.kind, use_color, f))
	}

	/// Render one grade. Recursive: a chain failure renders the locating header
	/// and then delegates to the hop's own kind, so a mismatch inside a walk
	/// reads exactly like the same mismatch in a plain pairwise run.
	fn display_kind(
		&self,
		kind: &super::TestReportKind,
		use_color: bool,
		f: &mut Fmt,
	) -> fmt::Result {
		match *kind {
			super::TestReportKind::Error(ref e) => self.display_run_error(e, f),
			super::TestReportKind::NoExpectation {
				ref output,
			} => Self::display_unspecified(output, f),
			super::TestReportKind::Valid => {
				if self.timeout {
					writeln!(
						f,
						"> Test ran longer then the allowed timeout, maybe shrink test or increase allowed timeout"
					)?;
				}
				Ok(())
			}
			super::TestReportKind::MismatchedType(ref mismatch) => {
				Self::display_type_mismatch(mismatch, f)
			}
			super::TestReportKind::MismatchedParsing {
				ref got,
				ref expected,
			} => {
				writeln!(f, "> Test returned invalid parsing error")?;
				f.indent(|f| {
					writeln!(f, "= Expected:")?;
					f.indent(|f| writeln!(f, "- Parsing error: {expected}"))?;
					writeln!(f, "= Got:")?;
					f.indent(|f| writeln!(f, "- Parsing error: {got}"))
				})
			}
			super::TestReportKind::MismatchedSignin {
				ref got,
				ref expected,
			} => {
				writeln!(f, "> Test returned invalid signin error")?;
				f.indent(|f| {
					writeln!(f, "= Expected:")?;
					f.indent(|f| writeln!(f, "- Signin error: {expected}"))?;
					writeln!(f, "= Got:")?;
					f.indent(|f| writeln!(f, "- Signin error: {got}"))
				})
			}
			super::TestReportKind::MismatchedRequest {
				ref got,
				ref expected,
			} => {
				writeln!(f, "> Test returned invalid request error")?;
				f.indent(|f| {
					writeln!(f, "= Expected:")?;
					f.indent(|f| writeln!(f, "- Request error: {expected}"))?;
					writeln!(f, "= Got:")?;
					f.indent(|f| writeln!(f, "- Request error: {got}"))
				})
			}
			super::TestReportKind::MismatchedSignup {
				ref got,
				ref expected,
			} => {
				writeln!(f, "> Test returned invalid signup error")?;
				f.indent(|f| {
					writeln!(f, "= Expected:")?;
					f.indent(|f| writeln!(f, "- Signup error: {expected}"))?;
					writeln!(f, "= Got:")?;
					f.indent(|f| writeln!(f, "- Signup error: {got}"))
				})
			}
			super::TestReportKind::MismatchedValues(ref v) => {
				Self::display_mismatched_values(v, use_color, f)
			}
			super::TestReportKind::ChainHop {
				ref version,
				hop,
				hops,
				outputs: _,
				ref inner,
			} => {
				writeln!(f, "> Chain failed at hop {hop}/{hops}, running version {version}")?;
				writeln!(
					f,
					"> Every earlier version in the walk verified; this is the first that did not."
				)?;
				f.indent(|f| self.display_kind(inner, use_color, f))
			}
			super::TestReportKind::RepairContract(ref explanation) => {
				writeln!(f, "> Declared `[[test.repair]]` does not describe the code")?;
				f.indent(|f| writeln!(f, "{explanation}"))
			}
			// Skips are filtered out before `display_grade` is reached.
			super::TestReportKind::Skipped {
				..
			} => Ok(()),
		}
	}

	fn display_grade_header(&self, use_color: bool, f: &mut Fmt) -> fmt::Result {
		match self.grade() {
			TestGrade::Success => {
				if self.is_wip() {
					if use_color {
						writeln!(
							f,
							ansi!(
								" ==> ",
								green,
								"Success",
								reset_format,
								" for ",
								bold,
								"{}",
								reset_format,
								":"
							),
							self.name
						)?;
					} else {
						writeln!(f, " ==> Success for {}:", self.name)?;
					}
					f.indent(|f| {
						writeln!(f, "> Tests succeeded even though it is marked Work in Progress")
					})?;

					if let Some(issue) = self.case.test.config.parsed.test.issue {
						f.indent(|f| {
							writeln!(f, "> Issue {issue} could maybe be closed.")?;
							f.indent(|f| {
								writeln!(
									f,
									"- https://github.com/surrealdb/surrealdb/issues/{issue}."
								)
							})
						})?;
					}
				} else {
					return Ok(());
				}
			}
			TestGrade::Failed => {
				if use_color {
					writeln!(
						f,
						ansi!(
							" ==> ",
							red,
							"Error",
							reset_format,
							" for ",
							bold,
							"{}",
							reset_format,
							":"
						),
						self.name
					)?;
				} else {
					writeln!(f, " ==> Error for {}:", self.name)?;
				}
				f.increase_depth();
			}
			TestGrade::Warning => {
				if use_color {
					writeln!(
						f,
						ansi!(
							" ==> ",
							yellow,
							"Warning",
							reset_format,
							" for ",
							bold,
							"{}",
							reset_format,
							":"
						),
						self.name
					)?;
				} else {
					writeln!(f, " ==> Warning for {}", self.name)?;
				}
				f.increase_depth();
				if self.is_wip() {
					writeln!(
						f,
						"! Test produces warnings because the test is marked as work in progress."
					)?;
				}
			}
			// Skips are filtered out before the header is rendered.
			TestGrade::Skipped => {}
		}
		Ok(())
	}

	fn display_run_error(&self, err: &TestError, f: &mut Fmt) -> fmt::Result {
		match err {
			TestError::Running(e) => {
				writeln!(f, "> Test failed to run, returning an error before the test could run.")?;
				f.indent(|f| writeln!(f, "- Error: {e}"))
			}
			TestError::Panicked(e) => {
				writeln!(f, "> Test failed, tests caused a panic to occur")?;
				f.indent(|f| writeln!(f, "- Panic payload: {e}"))
			}
			TestError::Import(import, error) => {
				writeln!(f, "> Test failed, running import `{import}` caused an error:")?;
				f.indent(|f| writeln!(f, "- {error}"))
			}
			TestError::LeakedRootState(x) => {
				writeln!(
					f,
					"> Test failed, it created root-level state but is not marked `[env] remote-exclusive`:"
				)?;
				f.indent(|f| {
					for x in x.iter() {
						writeln!(f, "- {x}")?;
					}
					writeln!(
						f,
						"A remote run isolates tests by giving each its own namespace, so anything"
					)?;
					writeln!(
						f,
						"created outside one survives cleanup and is visible to every test running"
					)?;
					writeln!(
						f,
						"alongside. Set `remote-exclusive = true` in the test's `[env]` to run it on"
					)?;
					writeln!(
						f,
						"its own instead. The state above was seen while this test ran; when a"
					)?;
					writeln!(
						f,
						"test running alongside is the one that created it, mark that test."
					)
				})
			}
			TestError::BadCleanup(x) => {
				writeln!(
					f,
					"> Test failed, test was not specified as clean yet it retained database keys:"
				)?;
				f.indent(|f| {
					for x in x.iter() {
						write!(f, "- [")?;
						for (idx, &b) in x.iter().enumerate() {
							if idx != 0 {
								write!(f, ",")?;
							}
							write!(f, "{}", (b as char).escape_debug())?;
						}
						writeln!(f, "]")?;
					}
					Ok(())
				})
			}
		}
	}

	fn display_unspecified(outputs: &TestOutputs, f: &mut Fmt) -> fmt::Result {
		writeln!(f, "> Test does not specify any results")?;
		f.indent(|f| {
			writeln!(f, "= Got:")?;
			f.indent(|f| match outputs {
				TestOutputs::Values(res) => Self::display_value_list(res, f),
				TestOutputs::ParsingError(res) => {
					writeln!(f, "- Parsing error: {res}")
				}
				TestOutputs::SignupError(res) => {
					writeln!(f, "- Signup error: {res}")
				}
				TestOutputs::SigninError(res) => {
					writeln!(f, "- Signin error: {res}")
				}
				TestOutputs::RequestError(res) => {
					writeln!(f, "- Request error: {res}")
				}
			})
		})
	}

	fn display_type_mismatch(mismatch: &ResultTypeMismatchReport, f: &mut Fmt) -> fmt::Result {
		writeln!(f, "> Test returned a different result type then was expected")?;
		f.indent(|f| {
			writeln!(f, "= Expected:")?;
			f.indent(|f| match &mismatch.expected {
				super::TestExpectation::Parsing(e) => match e {
					Some(x) => writeln!(f, "- Parsing Error: {x}"),
					None => writeln!(f, "- Any parsing error"),
				},
				super::TestExpectation::Values(e) => match e {
					Some(e) => Self::display_expectation_list(e, f),
					None => writeln!(f, "- Any list of query result values"),
				},
				super::TestExpectation::Signin(e) => match e {
					Some(x) => writeln!(f, "- Signin Error: {x}"),
					None => writeln!(f, "- Any signin error"),
				},
				super::TestExpectation::Signup(e) => match e {
					Some(x) => writeln!(f, "- Signup Error: {x}"),
					None => writeln!(f, "- Any signup error"),
				},
				super::TestExpectation::Request(e) => match e {
					Some(x) => writeln!(f, "- Request Error: {x}"),
					None => writeln!(f, "- Any request error"),
				},
			})?;
			writeln!(f, "= Got:")?;
			f.indent(|f| match &mismatch.got {
				TestOutputs::Values(values) => Self::display_value_list(values, f),
				TestOutputs::ParsingError(e) => writeln!(f, "- Parsing error: {e}"),
				TestOutputs::SigninError(e) => writeln!(f, "- Signin error: {e}"),
				TestOutputs::SignupError(e) => writeln!(f, "- Signup error: {e}"),
				TestOutputs::RequestError(e) => writeln!(f, "- Request error: {e}"),
			})
		})
	}

	fn display_mismatched_values(values: &[Mismatch], use_color: bool, f: &mut Fmt) -> fmt::Result {
		writeln!(f, "> Some returned values did not meet expectation")?;
		for v in values {
			match v.kind {
				MismatchKind::Unexpected {
					ref got,
				} => f.indent(|f| {
					writeln!(f, "> Value with index `{}` was not expected.", v.index)?;
					writeln!(f, "> Test specified less results than were returned")?;
					f.indent(|f| {
						writeln!(f, "= Got:")?;

						f.indent(|f| Self::display_value(got, f))
					})
				})?,
				MismatchKind::Missing {
					ref expected,
				} => f.indent(|f| {
					writeln!(f, "> Missing value with at index `{}`", v.index)?;
					writeln!(f, "> Test only specified more results than were returned")?;
					f.indent(|f| {
						writeln!(f, "= Expected:")?;
						f.indent(|f| Self::display_expectation(expected, f))
					})
				})?,
				MismatchKind::Trace {
					ref expected,
					ref got,
				} => f.indent(|f| {
					writeln!(
						f,
						"> The trace of the statement at index `{}` did not match expectation.",
						v.index
					)?;
					let shown = |trace: &Option<SurValue>| match trace {
						Some(trace) => trace.clone(),
						None => SurValue::None,
					};
					f.indent(|f| {
						writeln!(f, "= Expected:")?;
						f.indent(|f| Self::display_labelled_value("Trace", &shown(expected), f))?;
						writeln!(f, "= Got:")?;
						f.indent(|f| Self::display_labelled_value("Trace", &shown(got), f))?;
						writeln!(f, "= Diff:")?;
						f.indent(|f| {
							Self::display_diff(
								&Self::diffable(&shown(got)),
								&Self::diffable(&shown(expected)),
								use_color,
								f,
							)
						})
					})
				})?,
				MismatchKind::Value(ref x) => f.indent(|f| {
					writeln!(
						f,
						"> Returned value at index `{}` did not match expectation.",
						v.index
					)?;
					match x {
						ValueMismatchKind::InvalidError {
							expected,
							got,
						} => {
							writeln!(f, "> Got a different error then was expected")?;
							f.indent(|f| {
								writeln!(f, "= Expected:")?;
								f.indent(|f| writeln!(f, "- Error: {expected}"))?;
								writeln!(f, "= Got:")?;
								f.indent(|f| writeln!(f, "- Error: {got}"))?;
								writeln!(f, "= Diff:")?;
								f.indent(|f| Self::display_diff(got, expected, use_color, f))
							})
						}
						ValueMismatchKind::InvalidValue {
							expected,
							got,
						} => {
							writeln!(f, "> Got a different value then was expected")?;
							f.indent(|f| {
								writeln!(f, "= Expected:")?;
								f.indent(|f| Self::display_labelled_value("Value", expected, f))?;
								writeln!(f, "= Got:")?;
								f.indent(|f| Self::display_labelled_value("Value", got, f))?;
								writeln!(f, "= Diff:")?;
								f.indent(|f| {
									// Two strings are diffed as their text, so a
									// plan's lines stay lines in the diff too.
									Self::display_diff(
										&Self::diffable(got),
										&Self::diffable(expected),
										use_color,
										f,
									)
								})
							})
						}
						ValueMismatchKind::ExpectedError {
							expected,
							got,
						} => {
							writeln!(f, "> Expected an error but got a value")?;
							f.indent(|f| {
								writeln!(f, "= Expected:")?;
								if let Some(expected) = expected {
									f.indent(|f| writeln!(f, "- Error: {expected}"))?;
								} else {
									f.indent(|f| writeln!(f, "- Any error"))?;
								}
								writeln!(f, "= Got:")?;
								f.indent(|f| Self::display_labelled_value("Value", got, f))
							})
						}
						ValueMismatchKind::ExpectedValue {
							expected,
							got,
						} => {
							writeln!(f, "> Expected a value but got an error")?;
							f.indent(|f| {
								writeln!(f, "= Expected:")?;
								if let Some(expected) = expected {
									f.indent(|f| {
										Self::display_labelled_value("Value", expected, f)
									})?;
								} else {
									f.indent(|f| writeln!(f, "- Any value"))?;
								}
								writeln!(f, "= Got:")?;
								f.indent(|f| writeln!(f, "- Error: {got}"))
							})
						}
					}
				})?,
				MismatchKind::Matcher(ref m) => match m {
					MatcherMismatch::Error {
						error,
						got,
					} => {
						writeln!(f, "> Running the matching expression resulted in an error")?;
						f.indent(|f| writeln!(f, "- Error: {error}"))?;
						writeln!(f, "> Test returned the following data:")?;
						f.indent(|f| Self::display_value(got, f))?;
					}
					MatcherMismatch::Failed {
						matcher,
						value,
					} => {
						writeln!(f, "> Value failed to match matching expression")?;
						f.indent(|f| {
							writeln!(f, "= Matching expression:")?;
							f.indent(|f| writeln!(f, "- : {matcher}"))?;
							writeln!(f, "= Got:")?;
							f.indent(|f| Self::display_value(value, f))
						})?
					}
					MatcherMismatch::UnexpectedValue {
						got,
					} => {
						writeln!(f, "> Matcher expected a value but got an error")?;
						f.indent(|f| {
							writeln!(f, "= Got:")?;
							f.indent(|f| Self::display_labelled_value("Value", got, f))
						})?
					}
					MatcherMismatch::UnexpectedError {
						got,
					} => {
						writeln!(f, "> Matcher expected a error but got an value ")?;
						f.indent(|f| {
							writeln!(f, "= Got:")?;
							f.indent(|f| writeln!(f, "- Error: {got}"))
						})?
					}
					MatcherMismatch::OutputType {
						got,
					} => {
						writeln!(f, "> Matching expression did not return a boolean.")?;
						f.indent(|f| {
							writeln!(f, "= Matching expression returned value:")?;
							f.indent(|f| Self::display_labelled_value("Value", got, f))
						})?
					}
				},
			}
		}
		Ok(())
	}

	fn display_value_list(values: &[Result<SurValue, String>], f: &mut Fmt) -> fmt::Result {
		for v in values {
			Self::display_value(v, f)?;
		}
		Ok(())
	}
	/// The text a value is diffed as: a string as its own text, so a plan's
	/// lines stay lines, and every other value as the SurrealQL it renders.
	fn diffable(value: &SurValue) -> String {
		match value {
			SurValue::String(text) => text.as_str().to_owned(),
			_ => value.to_sql(),
		}
	}

	/// A value beneath its label: on the label's line, or — for a string
	/// whose text spans lines, which is what an `EXPLAIN` renders — as the
	/// text itself on the lines beneath, so a plan reads as the tree it is.
	fn display_labelled_value(label: &str, value: &SurValue, f: &mut Fmt) -> fmt::Result {
		match value {
			SurValue::String(text) if text.as_str().contains('\n') => {
				writeln!(f, "- {label}:")?;
				// A rendering that already ends in a newline would otherwise show a
				// blank line beneath it.
				let text = text.as_str();
				let text = text.strip_suffix('\n').unwrap_or(text);
				f.indent(|f| writeln!(f, "{text}"))
			}
			_ => writeln!(f, "- {label}: {}", value.to_sql()),
		}
	}

	fn display_value(v: &Result<SurValue, String>, f: &mut Fmt) -> fmt::Result {
		match v {
			Ok(x) => Self::display_labelled_value("Value", x, f),
			Err(e) => {
				writeln!(f, "- Error: {e}")
			}
		}
	}

	fn display_expectation_list(values: &[TestValueExpectation], f: &mut Fmt) -> fmt::Result {
		for v in values {
			Self::display_expectation(v, f)?;
		}
		Ok(())
	}

	fn display_expectation(v: &TestValueExpectation, f: &mut Fmt) -> fmt::Result {
		match v {
			TestValueExpectation::Error(e) => match e {
				Some(e) => writeln!(f, "- Error: {e}"),
				None => writeln!(f, "- Any Error"),
			},
			TestValueExpectation::Value(v) => match v {
				Some(v) => Self::display_labelled_value("Value", &v.expected, f),
				None => writeln!(f, "- Any value"),
			},
			TestValueExpectation::Matcher(m) => match m.matcher_value_type {
				MatchValueType::Both => {
					writeln!(f, "- A result to match matching expression: {}", m.value_str)
				}
				MatchValueType::Error => {
					writeln!(f, "- A error to match matching expression: {}", m.value_str)
				}
				MatchValueType::Value => {
					writeln!(f, "- A value to match matching expression: {}", m.value_str)
				}
			},
		}
	}

	fn display_diff<F: fmt::Display>(
		got: &F,
		expected: &F,
		use_color: bool,
		f: &mut Fmt,
	) -> fmt::Result {
		let got = got.to_string();
		let expected = expected.to_string();

		let diff = TextDiff::configure()
			.algorithm(Algorithm::Myers)
			.deadline(Instant::now() + Duration::from_millis(500))
			.diff_words(got.as_str(), expected.as_str());

		write!(f, "- ")?;
		for op in diff.ops() {
			for change in diff.iter_changes(op) {
				match change.tag() {
					similar::ChangeTag::Equal => {}
					similar::ChangeTag::Delete => {
						if use_color {
							write!(f, ansi!(red))?;
						} else {
							write!(f, "-[")?;
						}
					}
					similar::ChangeTag::Insert => {
						if use_color {
							write!(f, ansi!(green))?;
						} else {
							write!(f, "+[")?;
						}
					}
				}
				if use_color {
					write!(f, ansi!("{}", reset_format), change.to_string_lossy())?;
				} else {
					write!(f, "{}]", change.to_string_lossy())?;
				}
			}
		}
		writeln!(f)
	}
}
