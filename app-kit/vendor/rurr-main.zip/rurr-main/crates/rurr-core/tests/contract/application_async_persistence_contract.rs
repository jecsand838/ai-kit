use super::support::application::{
    assert_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer,
    assert_persistence_spec_rejects_same_app_load_target,
    assert_persistence_spec_resume_path_loads_state_and_resumes_next_action,
    assert_persistence_spec_same_app_exact_sequence_miss_starts_fresh_at_zero,
    assert_persistence_spec_with_uninitialized_recording_persister_surfaces_persistence_error,
    start_finish_counter_builder, FixedAsyncInitializer, FixedAsyncPersister, FixedSyncInitializer,
    FixedSyncPersister, PersistenceMode,
};
use indexmap::IndexMap;
use rurr_core::application::ApplicationError;
use rurr_persistence::{ApplicationPersistenceSpec, StateInitializerSpec, StatePersisterSpec};
use std::sync::Arc;

#[tokio::test]
async fn abuild_with_uninitialized_async_persistence_spec_surfaces_persistence_error() {
    assert_persistence_spec_with_uninitialized_recording_persister_surfaces_persistence_error(
        PersistenceMode::Async,
    )
    .await;
}

#[tokio::test]
async fn async_persistence_spec_resume_path_loads_state_and_resumes_next_action() {
    assert_persistence_spec_resume_path_loads_state_and_resumes_next_action(PersistenceMode::Async)
        .await;
}

#[tokio::test]
async fn async_persistence_spec_same_app_exact_sequence_miss_starts_fresh_at_zero() {
    assert_persistence_spec_same_app_exact_sequence_miss_starts_fresh_at_zero(
        PersistenceMode::Async,
    )
    .await;
}

#[tokio::test]
async fn async_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer() {
    assert_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer(
        PersistenceMode::Async,
    )
    .await;
}

#[tokio::test]
async fn async_persistence_spec_rejects_same_app_load_target() {
    assert_persistence_spec_rejects_same_app_load_target(PersistenceMode::Async).await;
}

#[tokio::test]
async fn abuild_rejects_sync_persistence_spec_components() {
    let sync_persister_spec = ApplicationPersistenceSpec::new()
        .with_persister(StatePersisterSpec::sync(Arc::new(FixedSyncPersister)));
    let persister_error = start_finish_counter_builder()
        .with_persistence_spec(sync_persister_spec)
        .expect("sync spec should configure")
        .abuild()
        .await;
    let persister_error = match persister_error {
        Ok(_) => panic!("abuild should reject sync persister specs"),
        Err(error) => error,
    };
    assert!(matches!(
        persister_error,
        ApplicationError::AsyncBuildUsedSyncPersister
    ));

    let sync_initializer_spec =
        ApplicationPersistenceSpec::new().with_initializer(StateInitializerSpec::sync(
            Arc::new(FixedSyncInitializer::default()),
            true,
            IndexMap::new(),
            "start",
            None,
        ));
    let initializer_error = start_finish_counter_builder()
        .with_persistence_spec(sync_initializer_spec)
        .expect("sync spec should configure")
        .abuild()
        .await;
    let initializer_error = match initializer_error {
        Ok(_) => panic!("abuild should reject sync initializer specs"),
        Err(error) => error,
    };
    assert!(matches!(
        initializer_error,
        ApplicationError::AsyncBuildUsedSyncInitializer
    ));
}

#[test]
fn build_rejects_async_persistence_spec_components_with_specific_errors() {
    let async_persister_spec = ApplicationPersistenceSpec::new().with_persister(
        StatePersisterSpec::async_persister(Arc::new(FixedAsyncPersister)),
    );
    let persister_error = start_finish_counter_builder()
        .with_persistence_spec(async_persister_spec)
        .expect("async spec should configure")
        .build();
    let persister_error = match persister_error {
        Ok(_) => panic!("build should reject async persister specs"),
        Err(error) => error,
    };
    assert!(matches!(
        persister_error,
        ApplicationError::SyncBuildUsedAsyncPersister
    ));

    let async_initializer_spec = ApplicationPersistenceSpec::new().with_initializer(
        StateInitializerSpec::async_initializer(
            Arc::new(FixedAsyncInitializer::default()),
            true,
            IndexMap::new(),
            "start",
            None,
        ),
    );
    let initializer_error = start_finish_counter_builder()
        .with_persistence_spec(async_initializer_spec)
        .expect("async spec should configure")
        .build();
    let initializer_error = match initializer_error {
        Ok(_) => panic!("build should reject async initializer specs"),
        Err(error) => error,
    };
    assert!(matches!(
        initializer_error,
        ApplicationError::SyncBuildUsedAsyncInitializer
    ));
}

#[tokio::test]
async fn async_app_rejects_sync_run_step_and_stream_entrypoints() {
    let mut app = start_finish_counter_builder()
        .with_persistence_spec(ApplicationPersistenceSpec::new().with_persister(
            StatePersisterSpec::async_persister(Arc::new(FixedAsyncPersister)),
        ))
        .expect("async persister spec should configure")
        .abuild()
        .await
        .expect("abuild should succeed");

    assert!(matches!(
        app.step(None).expect_err("step should fail"),
        ApplicationError::AsyncApplicationUsedSyncStep
    ));

    assert!(matches!(
        app.run().expect_err("run should fail"),
        ApplicationError::AsyncApplicationUsedSyncRun
    ));

    let mut run_iter = app.iterate();
    assert!(matches!(
        run_iter.next(),
        Some(Err(ApplicationError::AsyncApplicationUsedSyncRun))
    ));
    assert!(
        run_iter.next().is_none(),
        "failed sync iterate on async apps should terminate after the first error"
    );
    drop(run_iter);

    assert!(matches!(
        app.stream_result(),
        Err(ApplicationError::AsyncApplicationUsedSyncStream)
    ));

    let mut iterate = app.stream_iterate();
    assert!(matches!(
        iterate.next_step(),
        Err(ApplicationError::AsyncApplicationUsedSyncStream)
    ));
}
