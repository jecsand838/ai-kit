use super::*;
use super::{actions::*, assertions::*, fixtures::*, graphs::*, hooks::*, persistence::*};

#[test]
fn task_level_tracker_override_replaces_parent_tracker() {
    let parent_tracker = Arc::new(RecordingTracker::default());
    let child_tracker = Arc::new(RecordingTracker::default());
    let parent_tracker_trait: Arc<dyn Tracker> = parent_tracker.clone();
    let child_tracker_trait: Arc<dyn Tracker> = child_tracker.clone();

    let child_graph = runnable_graph_from_action(
        "child_tracker_probe",
        FunctionActionBuilder::new()
            .writes(["output"])
            .with_source_code("fn child_tracker_probe(_state, _ctx) -> output { output: 1 }")
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_child_app_id("child-tracked")
            .with_tracker(child_tracker_trait.clone())])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = build_parallel_parent_app_with_tracker(action, parent_tracker_trait);

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(parent_tracker.sync_post_run_app_ids(), vec!["parent-app"]);
    assert_eq!(child_tracker.sync_post_run_app_ids(), vec!["child-tracked"]);
}

#[test]
fn task_level_tracker_override_registers_child_in_override_tracker_sync() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let parent_project = "parallelism_tracker_override_parent_sync_contract";
    let child_project = "parallelism_tracker_override_child_sync_contract";
    let parent_tracker = Arc::new(
        LocalTrackingClient::new(parent_project, &storage_root)
            .expect("parent tracking client should initialize"),
    );
    let child_tracker = Arc::new(
        LocalTrackingClient::new(child_project, &storage_root)
            .expect("child tracking client should initialize"),
    );
    let parent_tracker_trait: Arc<dyn Tracker> = parent_tracker.clone();
    let child_tracker_trait: Arc<dyn Tracker> = child_tracker.clone();

    let child_graph = runnable_graph_from_action(
        "child_tracker_override_sync",
        FunctionActionBuilder::new()
            .writes(["output"])
            .with_source_code(
                "fn child_tracker_override_sync(_state, _ctx) -> output { output: 1 }",
            )
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_child_app_id("child-tracker-sync")
            .with_tracker(child_tracker_trait.clone())])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = build_parallel_parent_app_with_tracker(action, parent_tracker_trait);

    parent_tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("parent app registration should succeed");

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    let parent_children_path = project_app_dir(&storage_root, parent_project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let parent_children = read_jsonl(&parent_children_path);
    assert_eq!(parent_children.len(), 1);
    assert_eq!(
        parent_children[0]["child"]["app_id"],
        json!("child-tracker-sync")
    );
    assert_eq!(parent_children[0]["event_type"], json!("spawn_start"));
    assert_eq!(parent_children[0]["child"]["partition_key"], json!("pk"));

    assert_child_tracker_registration_and_logs(
        &storage_root,
        child_project,
        "child-tracker-sync",
        "parent-app",
    );
}

#[tokio::test]
async fn task_level_tracker_override_registers_child_in_override_tracker_async() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let parent_project = "parallelism_tracker_override_parent_async_contract";
    let child_project = "parallelism_tracker_override_child_async_contract";
    let parent_tracker = Arc::new(
        LocalTrackingClient::new(parent_project, &storage_root)
            .expect("parent tracking client should initialize"),
    );
    let child_tracker = Arc::new(
        LocalTrackingClient::new(child_project, &storage_root)
            .expect("child tracking client should initialize"),
    );
    let parent_tracker_trait: Arc<dyn Tracker> = parent_tracker.clone();
    let child_tracker_trait: Arc<dyn Tracker> = child_tracker.clone();

    let child_graph = runnable_graph_from_action(
        "child_tracker_override_async",
        FunctionActionBuilder::new()
            .writes(["output"])
            .with_source_code(
                "async fn child_tracker_override_async(_state, _ctx) -> output { output: 1 }",
            )
            .build_async(|_state, _ctx| async move { map_from_pairs([("output", json!(1))]) })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_child_app_id("child-tracker-async")
            .with_tracker(child_tracker_trait.clone())])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app = build_parallel_parent_async_app_with_tracker(action, parent_tracker_trait).await;

    parent_tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("parent app registration should succeed");

    let _ = app
        .astep(None)
        .await
        .expect("step should succeed")
        .expect("step should execute");

    let parent_children_path = project_app_dir(&storage_root, parent_project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let parent_children = read_jsonl(&parent_children_path);
    assert_eq!(parent_children.len(), 1);
    assert_eq!(
        parent_children[0]["child"]["app_id"],
        json!("child-tracker-async")
    );
    assert_eq!(parent_children[0]["event_type"], json!("spawn_start"));
    assert_eq!(parent_children[0]["child"]["partition_key"], json!("pk"));

    assert_child_tracker_registration_and_logs(
        &storage_root,
        child_project,
        "child-tracker-async",
        "parent-app",
    );
}

#[test]
fn task_level_state_persister_override_replaces_parent_persister() {
    let parent_persister = Arc::new(RecordingKeyPersister::default());
    let child_persister = Arc::new(RecordingKeyPersister::default());
    let parent_persister_trait: Arc<dyn BaseStatePersister> = parent_persister.clone();
    let child_persister_trait: Arc<dyn BaseStatePersister> = child_persister.clone();

    let child_graph = runnable_graph_from_action(
        "child_persister_probe",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(7))]))
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_child_app_id("child-persisted")
            .with_state_persister(StatePersisterRef::from(
                child_persister_trait.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = parallel_parent_builder(action)
        .with_sync_persister(parent_persister_trait)
        .expect("state persister spec should configure")
        .build()
        .expect("application should build");

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    let parent_saved = parent_persister.saved_keys();
    let child_saved = child_persister.saved_keys();
    assert!(
        parent_saved
            .iter()
            .any(|(app_id, _)| app_id == "parent-app"),
        "parent app save should remain on parent persister: {parent_saved:?}"
    );
    assert!(
        child_saved
            .iter()
            .any(|(app_id, _)| app_id == "child-persisted"),
        "child app save should use the task-level persister override: {child_saved:?}"
    );
    assert!(
        !parent_saved
            .iter()
            .any(|(app_id, _)| app_id == "child-persisted"),
        "child app save should not leak to the parent persister: {parent_saved:?}"
    );
}

#[test]
fn task_level_state_persister_override_does_not_rehydrate_child_state_sync() {
    let child_persister = Arc::new(RecordingKeyPersister::default());
    child_persister
        .save(
            Some("pk"),
            "child-persisted",
            41,
            "child_persister_probe",
            map_from_pairs([("seed", json!(41))]),
            PersistedStateStatus::Failed,
        )
        .expect("seed child save should succeed");
    let child_persister_trait: Arc<dyn BaseStatePersister> = child_persister.clone();

    let child_graph = runnable_graph_from_action(
        "child_persister_probe",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|state, _ctx| {
                let seed = state
                    .get("seed")
                    .and_then(Value::as_i64)
                    .unwrap_or_default();
                map_from_pairs([("output", json!(seed + 1))])
            })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                state_from_pairs([("seed", json!(5))]),
                "0-0",
            )
            .with_child_app_id("child-persisted")
            .with_state_persister(StatePersisterRef::from(
                child_persister_trait.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = parallel_parent_builder(action)
        .build()
        .expect("application should build");

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(child_i64_values_in_state(&step.state, "output"), vec![6]);
    assert!(
        child_persister
            .saved_keys()
            .iter()
            .any(|(app_id, _)| app_id == "child-persisted"),
        "child app save should still use the task-level persister override"
    );
}

#[tokio::test]
async fn task_level_state_persister_override_does_not_rehydrate_child_state_async() {
    let child_persister = Arc::new(AsyncRecordingKeyPersister::default());
    child_persister
        .save(
            Some("pk"),
            "child-persisted-async",
            41,
            "child_persister_probe_async",
            map_from_pairs([("seed", json!(41))]),
            PersistedStateStatus::Failed,
        )
        .await
        .expect("seed child save should succeed");
    let child_persister_trait: Arc<dyn AsyncBaseStatePersister> = child_persister.clone();

    let child_graph = runnable_graph_from_action(
        "child_persister_probe_async",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_async(|state, _ctx| async move {
                let seed = state
                    .get("seed")
                    .and_then(Value::as_i64)
                    .unwrap_or_default();
                map_from_pairs([("output", json!(seed + 1))])
            })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                state_from_pairs([("seed", json!(5))]),
                "0-0",
            )
            .with_child_app_id("child-persisted-async")
            .with_state_persister(StatePersisterRef::from(
                child_persister_trait.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app = parallel_parent_builder(action)
        .abuild()
        .await
        .expect("application should build");

    let step = app
        .astep(None)
        .await
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(child_i64_values_in_state(&step.state, "output"), vec![6]);
    assert!(
        child_persister
            .saved_keys()
            .await
            .iter()
            .any(|(app_id, _)| app_id == "child-persisted-async"),
        "child app save should still use the task-level persister override"
    );
}

#[test]
fn task_level_async_state_persister_override_is_rejected_for_sync_children() {
    let child_runs = Arc::new(AtomicUsize::new(0));
    let child_graph = sync_counter_child_graph(
        Arc::clone(&child_runs),
        "child_async_state_persister_rejected_sync",
    );
    let child_persister = Arc::new(AsyncRecordingKeyPersister::default());

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_state_persister(StatePersisterRef::async_persister(
                child_persister.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("sentinel", json!(1))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let error = app
        .step(None)
        .expect_err("sync step should reject async child persister overrides");

    assert_parallel_internal_error_message(
        error,
        &ApplicationError::SyncBuildUsedAsyncPersister.to_string(),
    );
    assert_eq!(child_runs.load(Ordering::SeqCst), 0);
    assert_parallel_failure_keeps_parent_state_clean(&app);
}

#[test]
fn task_level_async_state_initializer_override_is_rejected_for_sync_children() {
    let child_runs = Arc::new(AtomicUsize::new(0));
    let child_graph = sync_counter_child_graph(
        Arc::clone(&child_runs),
        "child_async_state_initializer_rejected_sync",
    );
    let child_initializer = Arc::new(AsyncRecordingKeyPersister::default());

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_state_initializer(StateLoaderRef::async_loader(
                child_initializer.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("sentinel", json!(1))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let error = app
        .step(None)
        .expect_err("sync step should reject async child initializer overrides");

    assert_parallel_internal_error_message(
        error,
        &ApplicationError::SyncBuildUsedAsyncInitializer.to_string(),
    );
    assert_eq!(child_runs.load(Ordering::SeqCst), 0);
    assert_parallel_failure_keeps_parent_state_clean(&app);
}

#[tokio::test]
async fn task_level_sync_state_persister_override_is_rejected_for_async_children() {
    let child_runs = Arc::new(AtomicUsize::new(0));
    let child_graph = async_counter_child_graph(
        Arc::clone(&child_runs),
        "child_sync_state_persister_rejected_async",
    );
    let child_persister = Arc::new(RecordingKeyPersister::default());

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_state_persister(StatePersisterRef::sync(
                child_persister.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app =
        parallel_parent_builder_with_state(state_from_pairs([("sentinel", json!(1))]), action)
            .abuild()
            .await
            .expect("application should build");

    let error = app
        .astep(None)
        .await
        .expect_err("async step should reject sync child persister overrides");

    assert_parallel_internal_error_message(
        error,
        &ApplicationError::AsyncBuildUsedSyncPersister.to_string(),
    );
    assert_eq!(child_runs.load(Ordering::SeqCst), 0);
    assert_parallel_failure_keeps_parent_state_clean(&app);
}

#[tokio::test]
async fn task_level_sync_state_initializer_override_is_rejected_for_async_children() {
    let child_runs = Arc::new(AtomicUsize::new(0));
    let child_graph = async_counter_child_graph(
        Arc::clone(&child_runs),
        "child_sync_state_initializer_rejected_async",
    );
    let child_initializer = Arc::new(FixedStateLoader { persisted: None });

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_state_initializer(StateLoaderRef::sync(
                child_initializer.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app =
        parallel_parent_builder_with_state(state_from_pairs([("sentinel", json!(1))]), action)
            .abuild()
            .await
            .expect("application should build");

    let error = app
        .astep(None)
        .await
        .expect_err("async step should reject sync child initializer overrides");

    assert_parallel_internal_error_message(
        error,
        &ApplicationError::AsyncBuildUsedSyncInitializer.to_string(),
    );
    assert_eq!(child_runs.load(Ordering::SeqCst), 0);
    assert_parallel_failure_keeps_parent_state_clean(&app);
}

#[test]
fn task_level_state_initializer_override_rehydrates_child_state() {
    let child_graph =
        sync_resume_probe_graph("child_initializer_default", "child_initializer_probe");
    let loader = Arc::new(FixedStateLoader::failed_from_state(
        "child-initialized",
        41,
        "child_initializer_probe",
        map_from_pairs([("seed", json!(41))]),
    ));

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_child_app_id("child-initialized")
            .with_state_initializer(StateLoaderRef::sync(loader.clone()))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = parallel_parent_builder(action)
        .build()
        .expect("application should build");

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(child_i64_values_in_state(&step.state, "output"), vec![42]);
}

#[test]
fn parent_state_persister_inheritance_does_not_rehydrate_child_state_sync() {
    let parent_persister = Arc::new(RecordingKeyPersister::default());
    let parent_persister_trait: Arc<dyn BaseStatePersister> = parent_persister.clone();
    let child_app_id = stable_child_app_id("parent-app", "0-0");
    parent_persister
        .save(
            Some("pk"),
            &child_app_id,
            41,
            "child_inherited_persister_probe",
            map_from_pairs([("seed", json!(41))]),
            PersistedStateStatus::Failed,
        )
        .expect("seed child save should succeed");

    let child_graph = runnable_graph_from_action(
        "child_inherited_persister_probe",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|state, _ctx| {
                let seed = state
                    .get("seed")
                    .and_then(Value::as_i64)
                    .unwrap_or_default();
                map_from_pairs([("output", json!(seed + 1))])
            })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                state_from_pairs([("seed", json!(5))]),
                "0-0",
            )])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = parallel_parent_builder(action)
        .with_sync_persister(parent_persister_trait)
        .expect("state persister spec should configure")
        .build()
        .expect("application should build");

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(child_i64_values_in_state(&step.state, "output"), vec![6]);
    assert!(
        parent_persister
            .saved_keys()
            .iter()
            .any(|(app_id, _)| app_id == &child_app_id),
        "child app save should inherit the parent persister"
    );
}

#[test]
fn task_level_child_app_id_override_is_used() {
    let child_graph = runnable_graph_from_action(
        "child_app_id_probe",
        FunctionActionBuilder::new()
            .writes(["seen_app_id"])
            .build_sync(|_state, ctx| {
                let app_id = ctx
                    .app_context
                    .as_ref()
                    .map(|context| context.app_id.clone())
                    .expect("application context should exist in child action");
                map_from_pairs([("seen_app_id", json!(app_id))])
            })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_child_app_id("child-explicit")])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = parallel_parent_builder(action)
        .build()
        .expect("application should build");

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    let child_app_id = child_seen_app_ids_in_state(&step.state)
        .into_iter()
        .next()
        .expect("child state should record the explicit app id");
    assert_eq!(child_app_id, "child-explicit");
}

#[test]
fn task_level_inputs_are_visible_to_sync_child_actions_without_implicit_parent_inheritance() {
    let child_graph = runnable_graph_from_action(
        "child_task_inputs_sync",
        FunctionActionBuilder::new()
            .writes(["task_scale", "inherited_parent_scale"])
            .build_sync(|_state, ctx| {
                let task_scale = ctx
                    .inputs
                    .get("task_scale")
                    .and_then(Value::as_i64)
                    .expect("task_scale should be present in child task inputs");
                map_from_pairs([
                    ("task_scale", json!(task_scale)),
                    (
                        "inherited_parent_scale",
                        json!(ctx.inputs.contains_key("parent_scale")),
                    ),
                ])
            })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec!["parent_scale".to_string()],
        Arc::new(move |_state: &State, ctx: &ActionContext| {
            let parent_scale = ctx
                .inputs
                .get("parent_scale")
                .and_then(Value::as_i64)
                .expect("parent_scale should be present in parent action inputs");
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_inputs(map_from_pairs([(
                "task_scale",
                json!(parent_scale + 4),
            )]))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(Some(map_from_pairs([("parent_scale", json!(3))])))
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        child_i64_values_in_state(&step.state, "task_scale"),
        vec![7]
    );
    let child_states = child_states_in_state(&step.state);
    assert_eq!(child_states.len(), 1);
    assert_eq!(
        child_states[0].get("inherited_parent_scale"),
        Some(&json!(false))
    );
}

#[tokio::test]
async fn task_level_inputs_are_visible_to_async_child_actions_without_implicit_parent_inheritance()
{
    let child_graph = runnable_graph_from_action(
        "child_task_inputs_async",
        FunctionActionBuilder::new()
            .writes(["task_scale", "inherited_parent_scale"])
            .build_async(|_state, ctx| async move {
                let task_scale = ctx
                    .inputs
                    .get("task_scale")
                    .and_then(Value::as_i64)
                    .expect("task_scale should be present in child task inputs");
                map_from_pairs([
                    ("task_scale", json!(task_scale)),
                    (
                        "inherited_parent_scale",
                        json!(ctx.inputs.contains_key("parent_scale")),
                    ),
                ])
            })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec!["parent_scale".to_string()],
        Arc::new(move |_state: &State, ctx: &ActionContext| {
            let parent_scale = ctx
                .inputs
                .get("parent_scale")
                .and_then(Value::as_i64)
                .expect("parent_scale should be present in parent action inputs");
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_inputs(map_from_pairs([(
                "task_scale",
                json!(parent_scale + 4),
            )]))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .astep(Some(map_from_pairs([("parent_scale", json!(3))])))
        .await
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        child_i64_values_in_state(&step.state, "task_scale"),
        vec![7]
    );
    let child_states = child_states_in_state(&step.state);
    assert_eq!(child_states.len(), 1);
    assert_eq!(
        child_states[0].get("inherited_parent_scale"),
        Some(&json!(false))
    );
}

#[test]
fn task_level_reserved_runtime_inputs_are_rejected_for_sync_children() {
    let child_graph = runnable_graph_from_action(
        "child_reserved_inputs_sync",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_inputs(map_from_pairs([
                ("__context", json!({"forged": true})),
                ("__tracer", json!("forged")),
            ]))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("count", json!(0))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let error = app
        .step(None)
        .expect_err("reserved child task runtime inputs should be rejected");

    assert!(matches!(
        error,
        ApplicationError::Action(ActionError::Internal { message })
            if message.contains("inputs starting with '__'")
                && message.contains("__context")
                && message.contains("__tracer")
    ));
    assert_eq!(app.state().get("count"), Some(&json!(0)));
}

#[tokio::test]
async fn task_level_reserved_runtime_inputs_are_rejected_for_async_children() {
    let child_graph = runnable_graph_from_action(
        "child_reserved_inputs_async",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_async(|_state, _ctx| async move { map_from_pairs([("output", json!(1))]) })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_inputs(map_from_pairs([
                ("__context", json!({"forged": true})),
                ("__tracer", json!("forged")),
            ]))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("count", json!(0))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let error = app
        .astep(None)
        .await
        .expect_err("reserved child task runtime inputs should be rejected");

    assert!(matches!(
        error,
        ApplicationError::Action(ActionError::Internal { message })
            if message.contains("inputs starting with '__'")
                && message.contains("__context")
                && message.contains("__tracer")
    ));
    assert_eq!(app.state().get("count"), Some(&json!(0)));
}
