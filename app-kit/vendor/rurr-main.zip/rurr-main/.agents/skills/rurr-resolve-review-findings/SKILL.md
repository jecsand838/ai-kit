---
name: rurr-resolve-review-findings
description: "Use when resolving Codex /review or built-in code-review findings in Rurr, including planning TDD fixes, directly implementing fixes, implementing approved review-finding plans, selecting subsystem guardrail skills, avoiding compatibility bloat, designing deterministic regression tests, handling manifests, and running changed-file-aware completion gates."
---

# Rurr Resolve Review Findings

Use this skill as the orchestrator for planning or directly fixing concrete implementation bugs found by Codex code review. Do not use it for audit-driven large cleanup planning; use `$rurr-delete-first-refactor-plan` for delete-first refactors found by Rurr reduction audits.

## Quick Start

Load, in order:

- the original `/review` findings or inline review comments
- the current user request or approved plan
- `AGENTS.md`
- `.agents/skills/README.md`
- the touched subsystem docs only when the findings require them

Use companion skills by touched behavior:

- anchored filesystem, output paths, or tracking artifact path safety: `$rurr-anchored-filesystem-hardening`
- streaming, sessions, lifecycle hooks, rollback, or lazy iteration: `$rurr-streaming-transaction-safety`
- persistence contracts or adapters: `$rurr-persistence-adapter-parity`
- proc macro diagnostics or generated APIs: `$rurr-proc-macro-ui-contract`
- skill catalog changes: `$rurr-skill-catalog-maintenance`
- closeout, manifests, temp-index, or changed-file gate selection: `$rurr-gate-closeout`

Always use `$use-rust-best-practices-core` for Rust changes. Add only the Rust companion skills that match the finding: architecture, abstractions, async, dependencies/platforms, networking, or testing.

## Planning Phase

Use this phase when the user asks to plan fixes, resolve review findings conceptually, or when Codex is in Plan mode.

1. Do not edit files in Plan mode.
2. Parse every finding into bug scenario, affected subsystem, required proof, expected fix shape, and gate risk.
3. Group the plan by behavior or subsystem, not by review-comment order.
4. Specify a red test for every behavior-sensitive finding before the fix.
5. Prefer public contract tests, and require the named strict live/backend proof lane when a finding concerns provider/backend behavior.
6. Use private `#[cfg(test)]` probes only when needed to make races deterministic.
7. Reject compatibility shims, public hooks, dead fallback paths, hacked live outputs, and duplicated fix logic unless Burr parity requires them.
8. Select subsystem guardrail skills and Rust companion skills explicitly.
9. Define narrow gates, structural checks, manifest handling, and final acceptance gates.
10. Emit a decision-complete `<proposed_plan>` that covers every finding.

## Implementation Phase

Use this phase when the user asks to directly fix review findings, asks to implement an approved review-finding plan, or clicks Implement from a Plan mode result.

1. Load the original review findings and the approved plan when one exists.
2. If there is no approved plan, derive a brief internal checklist that maps every finding to its regression test, fix group, and gate before editing.
3. Add or enable each red regression test first; confirm it fails when feasible.
4. Implement one finding group at a time and keep fixes private unless the reviewed bug requires a public API change.
5. Reuse existing Rurr models, facades, and helper APIs before adding new abstractions.
6. Prefer explicit `Unsupported`, `NotYetImplemented`, or typed configuration/startup errors when that is the truthful fix, rather than adding a synthetic fallback for the reviewed bug.
7. Run the narrow gate after each group before broadening.
8. Use `$rurr-structural-completion-audit` when the plan has negative structural requirements.
9. Use `$rurr-gate-closeout` for final gate selection, manifest refresh, temp-index or private-git fallout, and final reporting.
10. Report every finding as resolved or blocked, with the exact tests and gates that prove it.

## Plan Output Contract

When producing a plan, wrap it in `<proposed_plan>` and include exactly these sections:

- Summary
- Findings Covered
- Key Changes
- Tests/Gates
- Assumptions/Blockers

`Findings Covered` must account for every finding or explicitly mark duplicates. `Tests/Gates` must name the red tests, narrow gates, manifest handling, and final gates.

## Regression Test Rules

- Assert the reviewed failure scenario, not just the final happy path.
- For race findings, make the race deterministic with private test probes or OS-supported handles; do not use sleeps.
- Assert non-mutation for safety bugs, such as outside files unchanged or hooks not called.
- Assert side-effect absence for deferred startup failures, telemetry, lifecycle hooks, transactions, and tracking writes.
- Keep test placement at the narrowest layer that proves the behavior.
- Do not treat a local-only regression test as sufficient proof for provider/backend behavior when
  the workspace expects a named strict proof lane.

## Defaults

- Treat review findings as concrete bugs, not optimization prompts.
- Do not silently drop a finding; call out duplicates explicitly if two findings share one fix.
- Preserve Burr compatibility and documented Rurr guardrails.
- Prefer explicit unsupported/unimplemented/configuration errors over invented fallback behavior
  when a reviewed path is not honestly implemented.
- Run `./scripts/check.sh` before handoff unless the user explicitly waives gates.
- Add `./scripts/check_competition.sh`, `./scripts/check_oracle.sh`, live gates, or private OpenAI gates only when the touched behavior requires them.
