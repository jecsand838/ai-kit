use super::support::{build_registered_app_from_definition, map_from_pairs, state_from_pairs};
use crate::manifest::BurrOracleScenario;
use rurr_core::action::{ActionContext, ActionError, ActionResult, LocalAction, StreamOutput};
use rurr_core::application::ApplicationBuilder;
use rurr_core::graph::Transition;
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::state::State;
use rurr_core::tracking::LocalTrackingClient;
use serde_json::json;
use std::error::Error;
use std::sync::Arc;

const RURR_STREAM_COUNTER_SOURCE: &str = concat!(
    "impl LocalAction for StreamingCounterAction {\n",
    "    fn stream_run(&self, state: State, _ctx: ActionContext) -> Box<dyn Iterator<Item = StreamOutput>> {\n",
    "        let final_state = state.update(map_from_pairs([(\"count\", json!(3))])).expect(\"stream terminal state update should succeed\");\n",
    "        Box::new(vec![\n",
    "            Ok((map_from_pairs([(\"count\", json!(1))]), None)),\n",
    "            Ok((map_from_pairs([(\"count\", json!(2))]), None)),\n",
    "            Ok((map_from_pairs([(\"count\", json!(3))]), None)),\n",
    "            Ok((map_from_pairs([(\"count\", json!(3))]), Some(final_state))),\n",
    "        ].into_iter())\n",
    "    }\n",
    "}\n",
);

pub(super) fn run_04_streaming_action(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<(), Box<dyn Error>> {
    let stream_counter = StreamingCounterAction::new();

    let mut app = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(0))]))?
            .with_actions(vec![("stream_counter", stream_counter)])?
            .with_transitions(Vec::<Transition>::new())?
            .with_entrypoint("stream_counter")?,
        definition,
        tracker,
        hooks,
    )?;

    let halt_after_stream_counter = vec!["stream_counter".to_string()];
    let (_action, mut stream_result) = app.stream_result_with_options(
        rurr_core::ExecutionOptions::new().halt_after(halt_after_stream_counter),
    )?;
    for item in stream_result.by_ref() {
        item?;
    }
    let _terminal = stream_result.get()?;

    Ok(())
}

#[derive(Debug, Clone)]
struct StreamingCounterAction {
    name: Option<String>,
    reads: Vec<String>,
    writes: Vec<String>,
}

impl StreamingCounterAction {
    fn new() -> Self {
        Self {
            name: None,
            reads: vec!["count".to_string()],
            writes: vec!["count".to_string()],
        }
    }
}

impl LocalAction for StreamingCounterAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &self.reads
    }

    fn writes(&self) -> &[String] {
        &self.writes
    }

    fn source_code(&self) -> Option<String> {
        Some(RURR_STREAM_COUNTER_SOURCE.to_string())
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }

        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Err(ActionError::UnsupportedOperation {
            message: "streaming scenario must execute via stream_result".to_string(),
        })
    }

    fn stream_run(
        &self,
        state: State,
        _ctx: ActionContext,
    ) -> Box<dyn Iterator<Item = StreamOutput>> {
        let item_1 = map_from_pairs([("count", json!(1))]);
        let item_2 = map_from_pairs([("count", json!(2))]);
        let item_3 = map_from_pairs([("count", json!(3))]);
        let final_state = state
            .update(map_from_pairs([("count", json!(3))]))
            .expect("stream terminal state update should succeed");
        Box::new(
            vec![
                Ok((item_1, None)),
                Ok((item_2, None)),
                Ok((item_3, None)),
                Ok((map_from_pairs([("count", json!(3))]), Some(final_state))),
            ]
            .into_iter(),
        )
    }
}
