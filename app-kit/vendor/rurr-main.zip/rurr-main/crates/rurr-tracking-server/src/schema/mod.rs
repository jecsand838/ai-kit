//! Public HTTP payload and query models for the tracking server API.
//!
//! These types mirror the JSON exchanged by the local tracking UI and any
//! external tooling that talks to the server over HTTP.

mod annotations;
mod indexing_jobs;
mod metadata;
mod tracking;

use serde::Deserialize;

/// Standard pagination query accepted by list endpoints.
#[derive(Debug, Clone, Copy, Default, Deserialize)]
pub struct PaginationQuery {
    /// Maximum number of rows to return.
    pub limit: Option<usize>,
    /// Zero-based row offset.
    pub offset: Option<usize>,
}

/// Filters used when listing annotations.
#[derive(Debug, Clone, Default, Deserialize)]
pub struct AnnotationQuery {
    /// Optional application id filter.
    pub app_id: Option<String>,
    /// Optional partition key filter.
    pub partition_key: Option<String>,
    /// Optional step sequence id filter.
    pub step_sequence_id: Option<u64>,
}

/// Filters used when listing indexing jobs.
#[derive(Debug, Clone, Copy, Default, Deserialize)]
pub struct IndexingJobsQuery {
    /// Zero-based row offset.
    pub offset: Option<usize>,
    /// Maximum number of rows to return.
    pub limit: Option<usize>,
    /// Whether jobs with no queued work should be omitted.
    pub filter_empty: Option<bool>,
}

pub use annotations::{AnnotationCreate, AnnotationOut, AnnotationUpdate};
pub use indexing_jobs::IndexingJob;
pub use metadata::{
    burr_compat_version, AppSpecResponse, PointerModel, VersionResponse, BURR_COMPAT_VERSION,
};
pub(crate) use tracking::steps_from_projection;
pub use tracking::{
    project_steps, visible_step_count, ApplicationLogs, ApplicationPage, ApplicationSummary,
    Project, ReadyResponse, Span, Step, StreamEvent,
};
