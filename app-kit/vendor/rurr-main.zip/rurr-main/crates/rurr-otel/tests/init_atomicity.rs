use opentelemetry::global;
use opentelemetry::trace::{Span as _, Tracer as _};
use opentelemetry_sdk::trace::{InMemorySpanExporterBuilder, SdkTracerProvider};
use rurr_otel::{init_tracing_with_exporter, OtlpConfig, OtlpError};
use tracing_subscriber::util::SubscriberInitExt;

const SUCCESSFUL_OTLP_PROVIDER_LIVE_PROOF: &str =
    "crates/rurr-otel/tests/collector_file_live.rs::collector_file_export_contains_correlated_trace_and_log";

#[test]
fn init_tracing_with_exporter_is_atomic_before_global_provider_install() {
    let exporter_a = InMemorySpanExporterBuilder::new().build();
    let provider_a = SdkTracerProvider::builder()
        .with_simple_exporter(exporter_a.clone())
        .build();
    global::set_tracer_provider(provider_a.clone());

    // Force install failure for init_tracing_with_exporter.
    tracing_subscriber::registry().try_init().expect(
        "baseline tracing subscriber install should succeed for Rurr's init atomicity probe",
    );

    let exporter_b = InMemorySpanExporterBuilder::new().build();
    let config = OtlpConfig::from_collector_endpoint("http://127.0.0.1:4318");
    let result = init_tracing_with_exporter(exporter_b.clone(), &config);
    assert!(
        matches!(&result, Err(OtlpError::SubscriberInstall(_))),
        "subscriber install should fail before global provider replacement; successful OTLP provider/export behavior is live-proven by {SUCCESSFUL_OTLP_PROVIDER_LIVE_PROOF}, got {result:?}"
    );

    let mut span = global::tracer("init-atomicity").start("baseline-provider-span");
    span.end();
    provider_a.force_flush().unwrap_or_else(|error| {
        panic!(
            "force flush should succeed for the existing-provider observation; successful OTLP provider/export behavior is live-proven by {SUCCESSFUL_OTLP_PROVIDER_LIVE_PROOF}: {error:?}"
        )
    });

    let spans_a = exporter_a
        .get_finished_spans()
        .unwrap_or_else(|error| {
            panic!(
                "existing-provider spans should be readable for this atomicity probe; successful OTLP provider/export behavior is live-proven by {SUCCESSFUL_OTLP_PROVIDER_LIVE_PROOF}: {error:?}"
            )
        });
    assert_eq!(
        spans_a.len(),
        1,
        "failing init_tracing_with_exporter must not replace the existing global provider; successful OTLP provider/export behavior is live-proven by {SUCCESSFUL_OTLP_PROVIDER_LIVE_PROOF}"
    );
    assert_eq!(
        spans_a[0].name.as_ref(),
        "baseline-provider-span",
        "baseline span should remain attached to the original global provider during the atomicity probe; successful OTLP provider/export behavior is live-proven by {SUCCESSFUL_OTLP_PROVIDER_LIVE_PROOF}"
    );

    let spans_b = exporter_b
        .get_finished_spans()
        .unwrap_or_else(|error| {
            panic!(
                "candidate exporter spans should be readable for this atomicity probe; successful OTLP provider/export behavior is live-proven by {SUCCESSFUL_OTLP_PROVIDER_LIVE_PROOF}: {error:?}"
            )
        });
    assert_eq!(
        spans_b.len(),
        0,
        "no spans should be emitted via the candidate exporter when initialization fails before global provider install; successful OTLP provider/export behavior is live-proven by {SUCCESSFUL_OTLP_PROVIDER_LIVE_PROOF}"
    );
}
