use indexmap::IndexMap;
use rurr_core::application::TrackerSpec;

fn main() {
    let _ = TrackerSpec::local("project", IndexMap::new(), false);
}
