use super::scanner::S3ObjectScanner;
use super::S3BackendConfig;
use crate::backend::BackendError;
use rurr_core::tracking::{s3_time, S3Prefix};
use time::OffsetDateTime;
use uuid::Uuid;

pub(super) async fn load_snapshot_to_path(
    client: &aws_sdk_s3::Client,
    config: &S3BackendConfig,
) -> Result<(), BackendError> {
    let scanner = S3ObjectScanner::new(client, config);
    let keys = list_snapshot_keys(&scanner, config).await?;
    let Some(key) = keys.first() else {
        return Ok(());
    };
    if let Some(parent) = config.indexing.db_path.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    let body = scanner
        .get_object_bytes(key, "get_snapshot", "read_snapshot_body")
        .await?;
    tokio::fs::write(&config.indexing.db_path, body).await?;
    Ok(())
}

pub(super) async fn enforce_snapshot_retention(
    client: &aws_sdk_s3::Client,
    config: &S3BackendConfig,
) -> Result<(), BackendError> {
    let scanner = S3ObjectScanner::new(client, config);
    let keys = list_snapshot_keys(&scanner, config).await?;
    for key in keys
        .into_iter()
        .skip(config.indexing.prior_snapshots_to_keep)
    {
        scanner.delete_object(&key, "delete_old_snapshot").await?;
    }
    Ok(())
}

async fn list_snapshot_keys(
    scanner: &S3ObjectScanner<'_>,
    config: &S3BackendConfig,
) -> Result<Vec<String>, BackendError> {
    let mut snapshots = Vec::new();
    for key in scanner.list_snapshot_candidate_keys().await? {
        snapshots.push(SnapshotObjectKey::parse(
            &config.indexing.snapshot_prefix,
            &key,
        )?);
    }
    snapshots.sort();
    Ok(snapshots.into_iter().map(|snapshot| snapshot.key).collect())
}

pub(super) fn snapshot_key(prefix: &S3Prefix, backend_id: &str, now: OffsetDateTime) -> String {
    format!(
        "{}/{:010}-{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:09}Z/{}/{}/snapshot.db",
        prefix,
        reverse_epoch_seconds(now),
        now.year(),
        u8::from(now.month()),
        now.day(),
        now.hour(),
        now.minute(),
        now.second(),
        now.nanosecond(),
        backend_id,
        Uuid::new_v4()
    )
}

fn reverse_epoch_seconds(now: OffsetDateTime) -> u64 {
    (1u64 << 32).saturating_sub(now.unix_timestamp().max(0) as u64)
}

#[derive(Debug, Clone, Eq, PartialEq)]
struct SnapshotObjectKey {
    key: String,
    reverse_seconds: u64,
    timestamp: OffsetDateTime,
}

impl SnapshotObjectKey {
    fn parse(prefix: &S3Prefix, key: &str) -> Result<Self, BackendError> {
        let prefix = format!("{prefix}/");
        let rest = key.strip_prefix(&prefix).ok_or_else(|| {
            malformed_snapshot_key(key, "snapshot key is outside snapshot prefix")
        })?;
        let Some((timestamp_segment, _remaining)) = rest.split_once('/') else {
            return Err(malformed_snapshot_key(
                key,
                "snapshot key is missing backend segment",
            ));
        };
        if timestamp_segment.len() < 12
            || timestamp_segment.as_bytes()[10] != b'-'
            || !timestamp_segment.as_bytes()[..10]
                .iter()
                .all(u8::is_ascii_digit)
        {
            return Err(malformed_snapshot_key(
                key,
                "snapshot timestamp must start with 10 reverse-second digits",
            ));
        }
        let reverse_seconds = timestamp_segment[..10]
            .parse::<u64>()
            .map_err(|error| malformed_snapshot_key(key, error.to_string()))?;
        let timestamp = &timestamp_segment[11..];
        let timestamp = parse_snapshot_timestamp(timestamp)
            .map_err(|message| malformed_snapshot_key(key, message))?;
        let expected_reverse_seconds = reverse_epoch_seconds(timestamp);
        if reverse_seconds != expected_reverse_seconds {
            return Err(malformed_snapshot_key(
                key,
                format!(
                    "reverse-second prefix {reverse_seconds} does not match timestamp {expected_reverse_seconds}"
                ),
            ));
        }
        Ok(Self {
            key: key.to_string(),
            reverse_seconds,
            timestamp,
        })
    }
}

impl Ord for SnapshotObjectKey {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        other
            .timestamp
            .cmp(&self.timestamp)
            .then_with(|| self.key.cmp(&other.key))
    }
}

impl PartialOrd for SnapshotObjectKey {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

fn parse_snapshot_timestamp(timestamp: &str) -> Result<OffsetDateTime, String> {
    s3_time::parse_utc_iso_timestamp(timestamp).map_err(|error| error.to_string())
}

fn malformed_snapshot_key(key: &str, message: impl Into<String>) -> BackendError {
    BackendError::InvalidRequest {
        message: format!("malformed S3 snapshot key '{key}': {}", message.into()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_burr_snapshot_keys_and_rejects_old_rurr_dev_sort_domain() {
        let prefix = S3Prefix::new("snapshots").expect("prefix should parse");
        let burr_key = "snapshots/4294965296-1970-01-01T00:33:20.123456+00:00/backend/snapshot.db";
        let parsed = SnapshotObjectKey::parse(&prefix, burr_key).expect("Burr key should parse");
        assert_eq!(parsed.reverse_seconds, 4_294_965_296);
        assert_eq!(parsed.timestamp.unix_timestamp(), 2_000);
        assert_eq!(parsed.timestamp.nanosecond(), 123_456_000);

        let old_rurr_key = format!(
            "snapshots/{}-1970-01-01T00:00:00.000000000Z/backend/snapshot.db",
            "9".repeat(39)
        );
        let error = SnapshotObjectKey::parse(&prefix, &old_rurr_key)
            .expect_err("old Rurr dev key should not parse");
        assert!(error.to_string().contains("10 reverse-second digits"));
    }

    #[test]
    fn rejects_malformed_and_inconsistent_snapshot_timestamps() {
        let prefix = S3Prefix::new("snapshots").expect("prefix should parse");
        for (key, message) in [
            (
                "snapshots/4294965296-1970-99-01T00:33:20.123456+00:00/backend/snapshot.db",
                "month",
            ),
            (
                "snapshots/4294965296-1970-01-01T00:33:20.123456-05:00/backend/snapshot.db",
                "UTC",
            ),
            (
                "snapshots/4294965295-1970-01-01T00:33:20.123456+00:00/backend/snapshot.db",
                "reverse",
            ),
            (
                "snapshots/4294965296-1970-01-01 00:33:20.123456+00:00/backend/snapshot.db",
                "T",
            ),
        ] {
            let error =
                SnapshotObjectKey::parse(&prefix, key).expect_err("bad snapshot key should fail");
            assert!(
                error.to_string().contains(message),
                "expected '{message}' in error for {key}, got {error}"
            );
        }
    }

    #[test]
    fn snapshot_keys_sort_by_parsed_timestamp_newest_first() {
        let prefix = S3Prefix::new("snapshots").expect("prefix should parse");
        let mut snapshots = [
            SnapshotObjectKey::parse(
                &prefix,
                "snapshots/4294965296-1970-01-01T00:33:20.123456+00:00/backend/snapshot.db",
            )
            .expect("older Burr key should parse"),
            SnapshotObjectKey::parse(
                &prefix,
                "snapshots/4294965295-1970-01-01T00:33:21.000000001Z/backend/snapshot.db",
            )
            .expect("newer Rurr key should parse"),
        ];
        snapshots.sort();
        assert!(snapshots[0].key.contains("00:33:21.000000001Z"));
    }
}
