use indexmap::IndexMap;
use rurr_core::application::{ApplicationBuilder, ApplicationError};
use rurr_persistence::{
    ApplicationPersistenceSpec, AsyncBaseStateLoader, AsyncBaseStatePersister, BaseStateLoader,
    BaseStatePersister, PersistenceLoadTarget, StateInitializerSpec, StatePersisterSpec,
};
use serde_json::Value;
use std::sync::Arc;

pub(crate) fn with_sync_initializer_spec(
    builder: ApplicationBuilder,
    initializer: Arc<dyn BaseStateLoader>,
    resume_at_next_action: bool,
    default_state: IndexMap<String, Value>,
    default_entrypoint: impl Into<String>,
    override_state_values: Option<IndexMap<String, Value>>,
    load_target: Option<PersistenceLoadTarget>,
) -> Result<ApplicationBuilder, ApplicationError> {
    let initializer = StateInitializerSpec::sync(
        initializer,
        resume_at_next_action,
        default_state,
        default_entrypoint,
        override_state_values,
    )
    .with_optional_load_target(load_target);
    builder.with_persistence_spec(ApplicationPersistenceSpec::new().with_initializer(initializer))
}

pub(crate) fn with_async_initializer_spec(
    builder: ApplicationBuilder,
    initializer: Arc<dyn AsyncBaseStateLoader>,
    resume_at_next_action: bool,
    default_state: IndexMap<String, Value>,
    default_entrypoint: impl Into<String>,
    override_state_values: Option<IndexMap<String, Value>>,
    load_target: Option<PersistenceLoadTarget>,
) -> Result<ApplicationBuilder, ApplicationError> {
    let initializer = StateInitializerSpec::async_initializer(
        initializer,
        resume_at_next_action,
        default_state,
        default_entrypoint,
        override_state_values,
    )
    .with_optional_load_target(load_target);
    builder.with_persistence_spec(ApplicationPersistenceSpec::new().with_initializer(initializer))
}

pub(crate) fn with_sync_persister_spec(
    builder: ApplicationBuilder,
    persister: Arc<dyn BaseStatePersister>,
) -> Result<ApplicationBuilder, ApplicationError> {
    builder.with_persistence_spec(
        ApplicationPersistenceSpec::new().with_persister(StatePersisterSpec::sync(persister)),
    )
}

pub(crate) fn with_async_persister_spec(
    builder: ApplicationBuilder,
    persister: Arc<dyn AsyncBaseStatePersister>,
) -> Result<ApplicationBuilder, ApplicationError> {
    builder.with_persistence_spec(
        ApplicationPersistenceSpec::new()
            .with_persister(StatePersisterSpec::async_persister(persister)),
    )
}
