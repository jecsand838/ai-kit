use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_persistence::{
    AsyncBaseStateLoader, AsyncBaseStateSaver, BaseStateLoader, BaseStateSaver, PersistedStateData,
    PersistedStateStatus, PersistenceError,
};
use serde_json::Value;
use std::collections::BTreeSet;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;

pub(crate) const INTENTIONAL_PARALLEL_COMMIT_FAILURE: &str = "intentional_parallel_commit_failure";

fn select_record(
    records: &[PersistedStateData],
    partition_key: Option<&str>,
    app_id: Option<&str>,
    sequence_id: Option<u64>,
) -> Option<PersistedStateData> {
    let partition_key = partition_key.map(str::to_string);
    let mut matching = records.iter().filter(|record| {
        record.partition_key == partition_key
            && app_id
                .map(|candidate| record.app_id == candidate)
                .unwrap_or(true)
            && sequence_id
                .map(|candidate| record.sequence_id == candidate)
                .unwrap_or(true)
    });

    if sequence_id.is_some() {
        matching.next().cloned()
    } else {
        matching.max_by_key(|record| record.sequence_id).cloned()
    }
}

fn partition_app_ids(records: &[PersistedStateData], partition_key: Option<&str>) -> Vec<String> {
    let partition_key = partition_key.map(str::to_string);
    let app_ids: BTreeSet<String> = records
        .iter()
        .filter(|record| record.partition_key == partition_key)
        .map(|record| record.app_id.clone())
        .collect();
    app_ids.into_iter().collect()
}

fn persisted_state_record(
    partition_key: Option<&str>,
    app_id: &str,
    sequence_id: u64,
    position: &str,
    state: IndexMap<String, Value>,
    status: PersistedStateStatus,
) -> PersistedStateData {
    PersistedStateData {
        partition_key: partition_key.map(str::to_string),
        app_id: app_id.to_string(),
        sequence_id,
        position: Some(position.to_string()),
        state: Some(state),
        created_at: None,
        status,
    }
}

#[derive(Debug, Default)]
pub(crate) struct CountingPersister {
    saves: AtomicUsize,
}

impl CountingPersister {
    pub(crate) fn save_count(&self) -> usize {
        self.saves.load(Ordering::SeqCst)
    }
}

impl BaseStateLoader for CountingPersister {
    fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(None)
    }

    fn list_app_ids(&self, _partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

impl BaseStateSaver for CountingPersister {
    fn save(
        &self,
        _partition_key: Option<&str>,
        _app_id: &str,
        _sequence_id: u64,
        _position: &str,
        _state: IndexMap<String, Value>,
        _status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.saves.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct RecordingKeyPersister {
    store: RecordingKeyStore,
}

impl RecordingKeyPersister {
    pub(crate) fn saved_keys(&self) -> Vec<(String, u64)> {
        self.store.saved_keys()
    }
}

impl BaseStateLoader for RecordingKeyPersister {
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(self.store.load(partition_key, app_id, sequence_id))
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        Ok(self.store.list_app_ids(partition_key))
    }
}

impl BaseStateSaver for RecordingKeyPersister {
    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.store
            .save(partition_key, app_id, sequence_id, position, state, status);
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct AsyncRecordingKeyPersister {
    store: RecordingKeyStore,
}

impl AsyncRecordingKeyPersister {
    pub(crate) async fn saved_keys(&self) -> Vec<(String, u64)> {
        self.store.saved_keys()
    }
}

#[async_trait]
impl AsyncBaseStateLoader for AsyncRecordingKeyPersister {
    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(self.store.load(partition_key, app_id, sequence_id))
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        Ok(self.store.list_app_ids(partition_key))
    }
}

#[async_trait]
impl AsyncBaseStateSaver for AsyncRecordingKeyPersister {
    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.store
            .save(partition_key, app_id, sequence_id, position, state, status);
        Ok(())
    }
}

#[derive(Debug, Default)]
struct RecordingKeyStore {
    saves: Mutex<Vec<(String, u64)>>,
    records: Mutex<Vec<PersistedStateData>>,
}

impl RecordingKeyStore {
    fn saved_keys(&self) -> Vec<(String, u64)> {
        self.saves
            .lock()
            .expect("saves lock should not be poisoned")
            .clone()
    }

    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Option<PersistedStateData> {
        let records = self
            .records
            .lock()
            .expect("records lock should not be poisoned");
        select_record(&records, partition_key, app_id, sequence_id)
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Vec<String> {
        let records = self
            .records
            .lock()
            .expect("records lock should not be poisoned");
        partition_app_ids(&records, partition_key)
    }

    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) {
        self.saves
            .lock()
            .expect("saves lock should not be poisoned")
            .push((app_id.to_string(), sequence_id));
        self.records
            .lock()
            .expect("records lock should not be poisoned")
            .push(persisted_state_record(
                partition_key,
                app_id,
                sequence_id,
                position,
                state,
                status,
            ));
    }
}

#[derive(Debug, Default)]
pub(crate) struct AsyncFailingCommitPersister;

#[async_trait]
impl AsyncBaseStateLoader for AsyncFailingCommitPersister {
    async fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(None)
    }

    async fn list_app_ids(
        &self,
        _partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

#[async_trait]
impl AsyncBaseStateSaver for AsyncFailingCommitPersister {
    async fn save(
        &self,
        _partition_key: Option<&str>,
        _app_id: &str,
        _sequence_id: u64,
        _position: &str,
        _state: IndexMap<String, Value>,
        _status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        Err(PersistenceError::UnsupportedOperation {
            operation: INTENTIONAL_PARALLEL_COMMIT_FAILURE,
        })
    }
}

#[derive(Debug, Clone)]
pub(crate) struct FixedStateLoader {
    pub(crate) persisted: Option<PersistedStateData>,
}

impl FixedStateLoader {
    pub(crate) fn failed_from_state(
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
    ) -> Self {
        Self {
            persisted: Some(PersistedStateData {
                partition_key: Some("pk".to_string()),
                app_id: app_id.to_string(),
                sequence_id,
                position: Some(position.to_string()),
                state: Some(state),
                created_at: None,
                status: PersistedStateStatus::Failed,
            }),
        }
    }
}

impl BaseStateLoader for FixedStateLoader {
    fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(self.persisted.clone())
    }

    fn list_app_ids(&self, _partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        Ok(self
            .persisted
            .as_ref()
            .map(|persisted| vec![persisted.app_id.clone()])
            .unwrap_or_default())
    }
}
