use crate::action::api::{ActionContext, ActionInputs, ActionResult};
use crate::action::ActionTracer;
use crate::application::session::ActionExecution;
use crate::application::state_meta::{PRIOR_STEP_KEY, SEQUENCE_ID_KEY};
use crate::application::{
    Application, ApplicationContext, ApplicationError, RuntimeResources, StepOutput,
};
use crate::common::panic::panic_payload_to_string;
use crate::lifecycle::{
    poll_with_lifecycle_contexts, LifecycleExecutionMode, PreStepContext, StepGuard, StepOutcome,
    StreamContext, StreamGuard,
};
use crate::state::State;
use futures::FutureExt;
use indexmap::IndexMap;
use rurr_persistence::{PersistedStateStatus, StatePersisterRef};
use serde_json::Value;
use std::future::Future;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::Arc;
use std::time::SystemTime;

#[derive(Clone)]
struct InvocationScope {
    context: ApplicationContext,
    resources: RuntimeResources,
    tracer: ActionTracer,
}

impl InvocationScope {
    fn new(context: ApplicationContext, resources: RuntimeResources, tracer: ActionTracer) -> Self {
        Self {
            context,
            resources,
            tracer,
        }
    }

    fn action_context(&self, inputs: ActionInputs) -> ActionContext {
        ActionContext::new(inputs, self.tracer.clone(), Some(self.context.clone()))
            .with_engine_resources(self.resources.clone())
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum StepTransactionStatus {
    InProgress,
    Committed,
    RolledBack,
}

#[derive(Debug, Clone)]
pub(crate) struct StepTransaction {
    start_state: State,
    working_state: State,
    start_prior_step: Option<String>,
    reserved_sequence_id: u64,
    status: StepTransactionStatus,
}

impl StepTransaction {
    pub(crate) fn begin_prepared(
        app: &Application,
        start_prior_step: Option<&str>,
        reserved_sequence_id: u64,
    ) -> Result<Self, ApplicationError> {
        let start_state = app.state().clone();
        let mut sequence_update = IndexMap::new();
        sequence_update.insert(
            SEQUENCE_ID_KEY.to_string(),
            Value::from(reserved_sequence_id),
        );
        let working_state = start_state.update(sequence_update)?;
        Ok(Self {
            start_state,
            working_state,
            start_prior_step: start_prior_step.map(str::to_string),
            reserved_sequence_id,
            status: StepTransactionStatus::InProgress,
        })
    }

    pub(crate) fn working_state(&self) -> &State {
        &self.working_state
    }

    pub(crate) fn reserved_sequence_id(&self) -> u64 {
        self.reserved_sequence_id
    }

    pub(crate) fn start_prior_step(&self) -> Option<&str> {
        self.start_prior_step.as_deref()
    }

    pub(crate) fn prepare_commit_state(
        &self,
        action_name: &str,
        final_state: State,
    ) -> Result<Option<State>, ApplicationError> {
        if self.status != StepTransactionStatus::InProgress {
            return Ok(None);
        }

        let mut commit_updates = IndexMap::new();
        commit_updates.insert(
            PRIOR_STEP_KEY.to_string(),
            Value::String(action_name.to_string()),
        );
        commit_updates.insert(
            SEQUENCE_ID_KEY.to_string(),
            Value::from(self.reserved_sequence_id),
        );
        Ok(Some(final_state.update(commit_updates)?))
    }

    pub(crate) fn mark_committed(&mut self) {
        self.status = StepTransactionStatus::Committed;
    }

    pub(crate) fn rollback_state(&mut self) -> Option<State> {
        if self.status != StepTransactionStatus::InProgress {
            return None;
        }

        self.status = StepTransactionStatus::RolledBack;
        Some(self.start_state.clone())
    }
}

pub(crate) struct PreparedInvocation {
    action: crate::graph::GraphAction,
    transaction: StepTransaction,
    scope: InvocationScope,
    app_id: String,
    halted: bool,
}

impl PreparedInvocation {
    pub(crate) fn prepare(
        app: &Application,
        execution: ActionExecution,
        action_inputs: &ActionInputs,
    ) -> Result<(Self, ActionContext), ApplicationError> {
        let invocation = Self::new(app, execution)?;
        let action_context = invocation.action_context(action_inputs.clone());
        Ok((invocation, action_context))
    }

    pub(crate) fn new(
        app: &Application,
        execution: ActionExecution,
    ) -> Result<Self, ApplicationError> {
        let (action, prior_step, reserved_sequence_id, halted) = execution.into_parts();
        let transaction =
            StepTransaction::begin_prepared(app, prior_step.as_deref(), reserved_sequence_id)?;
        let context = app.context_for_step(
            transaction.reserved_sequence_id(),
            transaction.start_prior_step(),
        );
        let scope = InvocationScope::new(
            context,
            app.resources().clone(),
            app.action_tracer_for_action(action.name(), transaction.reserved_sequence_id()),
        );

        Ok(Self {
            action,
            transaction,
            scope,
            app_id: app.uid().to_string(),
            halted,
        })
    }

    pub(crate) fn action(&self) -> &crate::graph::GraphAction {
        &self.action
    }

    pub(crate) fn action_name(&self) -> &str {
        self.action.name()
    }

    pub(crate) fn sequence_id(&self) -> u64 {
        self.transaction.reserved_sequence_id()
    }

    pub(crate) fn halted(&self) -> bool {
        self.halted
    }

    pub(crate) fn app_id(&self) -> &str {
        &self.app_id
    }

    pub(crate) fn transaction_mut(&mut self) -> &mut StepTransaction {
        &mut self.transaction
    }

    pub(crate) fn working_state(&self) -> &State {
        self.transaction.working_state()
    }

    pub(crate) fn action_context(&self, inputs: ActionInputs) -> ActionContext {
        self.scope.action_context(inputs)
    }

    pub(crate) fn pre_step_context(&self, action_inputs: &ActionInputs) -> PreStepContext {
        PreStepContext::new(
            self.action_name(),
            self.sequence_id(),
            self.sequence_id(),
            SystemTime::now(),
        )
        .with_app_id(self.app_id.clone())
        .with_inputs(action_inputs.clone())
    }

    pub(crate) fn stream_context(&self) -> StreamContext {
        StreamContext::new(self.action_name(), self.sequence_id(), self.sequence_id())
            .with_app_id(self.app_id.clone())
    }

    pub(crate) fn start_sync_step_guard(
        &self,
        app: &Application,
        action_inputs: &ActionInputs,
    ) -> Result<StepGuard, ApplicationError> {
        Ok(StepGuard::start_sync(
            app.hooks(),
            self.pre_step_context(action_inputs),
        )?)
    }

    pub(crate) async fn start_async_step_guard(
        &self,
        app: &Application,
        context: PreStepContext,
    ) -> Result<StepGuard, ApplicationError> {
        let hooks = app.hooks().clone();
        Ok(StepGuard::start_async(&hooks, context).await?)
    }

    pub(crate) fn start_sync_stream_guards(
        &self,
        app: &Application,
        action_inputs: &ActionInputs,
    ) -> Result<(StepGuard, StreamGuard), ApplicationError> {
        let step_guard = self.start_sync_step_guard(app, action_inputs)?;
        let stream_guard = match StreamGuard::start_sync(app.hooks(), self.stream_context()) {
            Ok(guard) => guard,
            Err(error) => {
                return Err(self.finish_sync_step_guard_with_error(step_guard, error.into()));
            }
        };
        Ok((step_guard, stream_guard))
    }

    pub(crate) async fn start_async_stream_guards(
        &self,
        app: &Application,
        action_inputs: &ActionInputs,
    ) -> Result<(StepGuard, StreamGuard), ApplicationError> {
        let pre_step_context = self
            .pre_step_context(action_inputs)
            .with_execution_mode(LifecycleExecutionMode::Async);
        let step_guard = self.start_async_step_guard(app, pre_step_context).await?;
        let stream_guard = match StreamGuard::start_async(app.hooks(), self.stream_context()).await
        {
            Ok(guard) => guard,
            Err(error) => {
                return Err(self
                    .finish_async_step_guard_with_error(step_guard, error.into())
                    .await);
            }
        };
        Ok((step_guard, stream_guard))
    }

    pub(crate) fn record_step_error(&self, step_guard: &mut StepGuard, error: &ApplicationError) {
        self.record_step_error_outcome(step_guard, error.to_string());
    }

    pub(crate) fn record_optional_step_error(
        &self,
        step_guard: &mut Option<StepGuard>,
        exception: impl Into<String>,
    ) {
        if let Some(step_guard) = step_guard.as_mut() {
            self.record_step_error_outcome(step_guard, exception);
        }
    }

    fn record_step_error_outcome(&self, step_guard: &mut StepGuard, exception: impl Into<String>) {
        step_guard.record_outcome(step_error_outcome(self.working_state(), exception));
    }

    pub(crate) fn finish_sync_step_guard_with_error(
        &self,
        mut step_guard: StepGuard,
        error: ApplicationError,
    ) -> ApplicationError {
        self.record_step_error(&mut step_guard, &error);
        prefer_finish_error(error, step_guard.finish_sync())
    }

    pub(crate) async fn finish_async_step_guard_with_error(
        &self,
        mut step_guard: StepGuard,
        error: ApplicationError,
    ) -> ApplicationError {
        self.record_step_error(&mut step_guard, &error);
        prefer_finish_error(error, step_guard.finish_async().await)
    }
}

/// Result of running an async action before commit and persistence finalization.
pub struct ExecutedAction {
    action_result: ActionResult,
    final_state: State,
}

impl ExecutedAction {
    fn new(action_result: ActionResult, final_state: State) -> Self {
        Self {
            action_result,
            final_state,
        }
    }

    fn into_parts(self) -> (ActionResult, State) {
        (self.action_result, self.final_state)
    }
}

fn prepare_step_success(
    step_result: Result<ExecutedAction, ApplicationError>,
) -> Result<(IndexMap<String, Value>, State), ApplicationError> {
    let (action_result, final_state) = step_result?.into_parts();
    Ok((action_result.result().clone(), final_state))
}

struct PendingCommit {
    state_meta: State,
    sequence_id: u64,
}

impl PendingCommit {
    fn new(
        transaction: &StepTransaction,
        action_name: &str,
        final_state: State,
    ) -> Result<Option<Self>, ApplicationError> {
        let Some(state_meta) = transaction.prepare_commit_state(action_name, final_state)? else {
            return Ok(None);
        };
        Ok(Some(Self {
            state_meta,
            sequence_id: transaction.reserved_sequence_id(),
        }))
    }

    fn serialize_state(&self) -> Result<IndexMap<String, Value>, ApplicationError> {
        Ok(self.state_meta.serialize()?)
    }

    fn finish(self, app: &mut Application, transaction: &mut StepTransaction) -> State {
        app.replace_state(self.state_meta.clone());
        transaction.mark_committed();
        self.state_meta
    }
}

fn finish_pending_commit(
    pending_commit: PendingCommit,
    persist_result: Result<(), ApplicationError>,
    app: &mut Application,
    transaction: &mut StepTransaction,
) -> Result<State, ApplicationError> {
    persist_result?;
    Ok(pending_commit.finish(app, transaction))
}

#[derive(Clone)]
struct PersistSaveArgs {
    partition_key: Option<String>,
    app_id: String,
    action_name: String,
    sequence_id: u64,
    status: rurr_persistence::PersistedStateStatus,
}

impl PersistSaveArgs {
    fn new(
        app: &Application,
        action_name: &str,
        sequence_id: u64,
        status: rurr_persistence::PersistedStateStatus,
    ) -> Self {
        Self {
            partition_key: app.partition_key().map(str::to_string),
            app_id: app.uid().to_string(),
            action_name: action_name.to_string(),
            sequence_id,
            status,
        }
    }

    fn partition_key(&self) -> Option<&str> {
        self.partition_key.as_deref()
    }

    fn app_id(&self) -> &str {
        &self.app_id
    }

    fn action_name(&self) -> &str {
        &self.action_name
    }
}

struct PreparedStateSave {
    persister: StatePersisterRef,
    args: PersistSaveArgs,
    serialized_state: IndexMap<String, Value>,
}

impl PreparedStateSave {
    fn save_with_sync_persister(
        sync_persister: &Arc<dyn rurr_persistence::BaseStatePersister>,
        args: PersistSaveArgs,
        serialized_state: IndexMap<String, Value>,
    ) -> Result<(), ApplicationError> {
        sync_persister.save(
            args.partition_key(),
            args.app_id(),
            args.sequence_id,
            args.action_name(),
            serialized_state,
            args.status,
        )?;
        Ok(())
    }

    fn save_sync(self) -> Result<(), ApplicationError> {
        let Self {
            persister,
            args,
            serialized_state,
        } = self;
        let Some(sync_persister) = persister.as_sync() else {
            return Err(ApplicationError::SyncRunUsedAsyncPersister);
        };
        Self::save_with_sync_persister(sync_persister, args, serialized_state)
    }

    async fn save_async(self) -> Result<(), ApplicationError> {
        let Self {
            persister,
            args,
            serialized_state,
        } = self;
        if let Some(async_persister) = persister.as_async() {
            async_persister
                .save(
                    args.partition_key(),
                    args.app_id(),
                    args.sequence_id,
                    args.action_name(),
                    serialized_state,
                    args.status,
                )
                .await?;
            return Ok(());
        }
        let Some(sync_persister) = persister.as_sync() else {
            return Err(ApplicationError::InternalInvariant {
                message: "state persister reference missing both sync and async handles",
            });
        };
        Self::save_with_sync_persister(sync_persister, args, serialized_state)
    }
}

struct PreparedCommit {
    pending_commit: PendingCommit,
    persist: Option<PreparedStateSave>,
}

impl PreparedCommit {
    fn new(
        app: &Application,
        transaction: &StepTransaction,
        action_name: &str,
        final_state: State,
    ) -> Result<Option<Self>, ApplicationError> {
        let Some(pending_commit) = PendingCommit::new(transaction, action_name, final_state)?
        else {
            return Ok(None);
        };
        let persist = if let Some(persister) = app.resources().state_persister().cloned() {
            let args = PersistSaveArgs::new(
                app,
                action_name,
                pending_commit.sequence_id,
                PersistedStateStatus::Completed,
            );
            let serialized_state = pending_commit.serialize_state()?;
            Some(PreparedStateSave {
                persister,
                args,
                serialized_state,
            })
        } else {
            None
        };
        Ok(Some(Self {
            pending_commit,
            persist,
        }))
    }

    fn finish_sync(
        self,
        app: &mut Application,
        transaction: &mut StepTransaction,
    ) -> Result<State, ApplicationError> {
        let Self {
            pending_commit,
            persist,
        } = self;
        let persist_result = match persist {
            Some(save) => save.save_sync(),
            None => Ok(()),
        };
        finish_pending_commit(pending_commit, persist_result, app, transaction)
    }

    async fn finish_async(
        self,
        app: &mut Application,
        transaction: &mut StepTransaction,
    ) -> Result<State, ApplicationError> {
        let Self {
            pending_commit,
            persist,
        } = self;
        let persist_result = match persist {
            Some(save) => save.save_async().await,
            None => Ok(()),
        };
        finish_pending_commit(pending_commit, persist_result, app, transaction)
    }
}

#[derive(Clone, Copy)]
pub(crate) enum PanicPolicy {
    Capture,
    Propagate,
}

pub(crate) fn execute_planned_action_sync(
    app: &mut Application,
    execution: ActionExecution,
    action_inputs: &ActionInputs,
) -> Result<StepOutput, ApplicationError> {
    execute_action_sync(app, execution, action_inputs, PanicPolicy::Propagate)
}

pub(crate) async fn execute_planned_action_async(
    app: &mut Application,
    execution: ActionExecution,
    action_inputs: &ActionInputs,
) -> Result<StepOutput, ApplicationError> {
    execute_action_async(app, execution, action_inputs, PanicPolicy::Propagate).await
}

pub(crate) fn execute_action_sync(
    app: &mut Application,
    execution: ActionExecution,
    action_inputs: &ActionInputs,
    panic_policy: PanicPolicy,
) -> Result<StepOutput, ApplicationError> {
    let (mut invocation, action_context) =
        PreparedInvocation::prepare(app, execution, action_inputs)?;
    let step_guard = invocation.start_sync_step_guard(app, &action_context.inputs)?;
    let run_result = run_sync_action(&invocation, &action_context, panic_policy);
    finish_sync_step_execution(app, &mut invocation, step_guard, run_result)
}

pub(crate) async fn execute_action_async(
    app: &mut Application,
    execution: ActionExecution,
    action_inputs: &ActionInputs,
    panic_policy: PanicPolicy,
) -> Result<StepOutput, ApplicationError> {
    let (mut invocation, action_context) =
        PreparedInvocation::prepare(app, execution, action_inputs)?;
    let pre_step_context = invocation
        .pre_step_context(&action_context.inputs)
        .with_execution_mode(LifecycleExecutionMode::Async);
    let step_guard = invocation
        .start_async_step_guard(app, pre_step_context.clone())
        .await?;
    let run_result = run_async_action(
        &invocation,
        &action_context,
        &pre_step_context,
        panic_policy,
    )
    .await;
    finish_async_step_execution(app, &mut invocation, step_guard, run_result).await
}

fn run_sync_action(
    invocation: &PreparedInvocation,
    action_context: &ActionContext,
    panic_policy: PanicPolicy,
) -> Result<ExecutedAction, ApplicationError> {
    let action = invocation.action().action();
    let working_state = invocation.working_state();
    let action_result = match panic_policy {
        PanicPolicy::Capture => capture_sync_panic("action.run", || {
            action.run_erased(working_state, action_context)
        })?
        .map_err(ApplicationError::from),
        PanicPolicy::Propagate => action
            .run_erased(working_state, action_context)
            .map_err(ApplicationError::from),
    }?;

    let final_state = match panic_policy {
        PanicPolicy::Capture => capture_sync_panic("action.update", || {
            action.update_erased(&action_result, working_state, action_context)
        })?
        .map_err(ApplicationError::from),
        PanicPolicy::Propagate => action
            .update_erased(&action_result, working_state, action_context)
            .map_err(ApplicationError::from),
    }?;

    Ok(ExecutedAction::new(action_result, final_state))
}

async fn run_async_action(
    invocation: &PreparedInvocation,
    action_context: &ActionContext,
    pre_step_context: &PreStepContext,
    panic_policy: PanicPolicy,
) -> Result<ExecutedAction, ApplicationError> {
    let hooks = invocation.scope.resources.hooks().clone();
    let future = {
        let action = invocation.action().action();
        let working_state = invocation.working_state();
        async move {
            let action_result = action
                .run_async_erased(working_state, action_context)
                .await?;
            let final_state =
                action.update_erased(&action_result, working_state, action_context)?;
            Ok::<_, ApplicationError>(ExecutedAction::new(action_result, final_state))
        }
    };
    let future =
        poll_with_lifecycle_contexts(future, hooks.async_step_poll_contexts(pre_step_context));

    match panic_policy {
        PanicPolicy::Capture => capture_async_panic("action.run_async_or_update", future).await?,
        PanicPolicy::Propagate => future.await,
    }
}

fn finish_with_rollback<T>(
    app: &mut Application,
    invocation: &mut PreparedInvocation,
    result: Result<T, ApplicationError>,
) -> Result<T, ApplicationError> {
    result.inspect_err(|_| rollback(app, invocation.transaction_mut()))
}

pub(crate) fn commit_sync(
    app: &mut Application,
    transaction: &mut StepTransaction,
    action_name: &str,
    final_state: State,
) -> Result<State, ApplicationError> {
    let Some(commit) = PreparedCommit::new(app, transaction, action_name, final_state)? else {
        return Ok(app.state().clone());
    };
    commit.finish_sync(app, transaction)
}

pub(crate) async fn commit_async(
    app: &mut Application,
    transaction: &mut StepTransaction,
    action_name: &str,
    final_state: State,
) -> Result<State, ApplicationError> {
    let Some(commit) = PreparedCommit::new(app, transaction, action_name, final_state)? else {
        return Ok(app.state().clone());
    };
    commit.finish_async(app, transaction).await
}

fn finish_sync_step_execution(
    app: &mut Application,
    invocation: &mut PreparedInvocation,
    mut step_guard: StepGuard,
    step_result: Result<ExecutedAction, ApplicationError>,
) -> Result<StepOutput, ApplicationError> {
    let step_result = prepare_step_success(step_result).and_then(|(result, final_state)| {
        let action_name = invocation.action_name().to_string();
        commit_sync(app, invocation.transaction_mut(), &action_name, final_state)
            .map(|state_meta| finish_prepared_step(invocation, result, state_meta))
    });
    let step_result = match step_result {
        Ok(output) => {
            record_step_success(&mut step_guard, &output);
            step_guard.finish_sync()?;
            Ok(output)
        }
        Err(error) => Err(invocation.finish_sync_step_guard_with_error(step_guard, error)),
    };
    finish_with_rollback(app, invocation, step_result)
}

async fn finish_async_step_execution(
    app: &mut Application,
    invocation: &mut PreparedInvocation,
    mut step_guard: StepGuard,
    step_result: Result<ExecutedAction, ApplicationError>,
) -> Result<StepOutput, ApplicationError> {
    let step_result = match prepare_step_success(step_result) {
        Ok((result, final_state)) => {
            let action_name = invocation.action_name().to_string();
            commit_async(app, invocation.transaction_mut(), &action_name, final_state)
                .await
                .map(|state_meta| finish_prepared_step(invocation, result, state_meta))
        }
        Err(error) => Err(error),
    };
    let step_result = match step_result {
        Ok(output) => {
            record_step_success(&mut step_guard, &output);
            step_guard.finish_async().await?;
            Ok(output)
        }
        Err(error) => Err(invocation
            .finish_async_step_guard_with_error(step_guard, error)
            .await),
    };
    finish_with_rollback(app, invocation, step_result)
}

fn finish_prepared_step(
    invocation: &PreparedInvocation,
    result: IndexMap<String, Value>,
    state: State,
) -> StepOutput {
    StepOutput {
        action: invocation.action().clone(),
        result,
        state,
        halted: invocation.halted(),
    }
}

fn record_step_success(step_guard: &mut StepGuard, output: &StepOutput) {
    step_guard.record_outcome(StepOutcome::Success {
        result: output.result.clone(),
        state: output.state.clone(),
    });
}

pub(crate) fn rollback(app: &mut Application, transaction: &mut StepTransaction) {
    if let Some(start_state) = transaction.rollback_state() {
        app.replace_state(start_state);
    }
}

fn step_error_outcome(state: &State, exception: impl Into<String>) -> StepOutcome {
    StepOutcome::Error {
        exception: exception.into(),
        state: state.clone(),
    }
}

fn prefer_finish_error<E>(
    primary_error: ApplicationError,
    finish_result: Result<(), E>,
) -> ApplicationError
where
    E: Into<ApplicationError>,
{
    match finish_result {
        Ok(()) => primary_error,
        Err(finish_error) => finish_error.into(),
    }
}

pub(crate) fn capture_sync_panic<T>(
    scope: &'static str,
    f: impl FnOnce() -> T,
) -> Result<T, ApplicationError> {
    match catch_unwind(AssertUnwindSafe(f)) {
        Ok(value) => Ok(value),
        Err(payload) => Err(ApplicationError::PanicCaptured {
            scope,
            message: panic_payload_to_string(payload),
        }),
    }
}

pub(crate) async fn capture_async_panic<T>(
    scope: &'static str,
    future: impl Future<Output = T>,
) -> Result<T, ApplicationError> {
    match AssertUnwindSafe(future).catch_unwind().await {
        Ok(value) => Ok(value),
        Err(payload) => Err(ApplicationError::PanicCaptured {
            scope,
            message: panic_payload_to_string(payload),
        }),
    }
}
