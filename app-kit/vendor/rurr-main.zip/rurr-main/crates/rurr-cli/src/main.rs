#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    rurr_cli::run_cli().await
}
