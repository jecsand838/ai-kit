use crate::{
    wire as persistence_wire, InitializationHint, LoadSelector, PersistedRowTuple,
    PersistedStateData, PersistedStateQueries, PersistedStateSaveRequest, PersistenceError,
};
use serde_json::Value;

use super::tuple_to_persisted_state;

/// SQL initialization operation shared by sync and async executors.
#[derive(Debug, Clone, Copy)]
pub struct SqlInitializationPlan<'a> {
    /// Table whose initialized state should be checked.
    pub table_name: &'a str,
    /// Migration SQL used to create or update the table.
    pub migration_sql: &'a str,
}

impl<'a> SqlInitializationPlan<'a> {
    pub(crate) fn new(table_name: &'a str, migration_sql: &'a str) -> Self {
        Self {
            table_name,
            migration_sql,
        }
    }
}

/// Normalized SQL save operation shared by sync and async executors.
#[derive(Debug)]
pub struct SqlSavePlan<'q, 'v> {
    /// SQL statement to execute.
    pub query: &'q str,
    /// Normalized partition key.
    pub partition_key: String,
    /// Application identifier.
    pub app_id: &'v str,
    /// Signed SQL sequence id.
    pub sequence_id: i64,
    /// Action position.
    pub position: &'v str,
    /// Serialized state JSON payload.
    pub state_json: String,
    /// Typed state JSON payload for drivers that bind JSON values directly.
    pub state_value: Value,
    /// Persisted status string.
    pub status: &'static str,
}

impl<'q, 'v> SqlSavePlan<'q, 'v> {
    pub(crate) fn new(
        queries: &'q PersistedStateQueries,
        request: PersistedStateSaveRequest<'v>,
        serialization_failure_operation: &'static str,
    ) -> Result<Self, PersistenceError> {
        Ok(Self {
            query: queries.insert_state(),
            partition_key: request.normalized_partition_key(),
            app_id: request.app_id(),
            sequence_id: request.signed_sequence_id()?,
            position: request.position(),
            state_json: request.state_json(serialization_failure_operation)?,
            state_value: request.state_value(),
            status: request.status_str(),
        })
    }
}

pub(crate) enum LoadOperation<'q, 'v> {
    NoRecord,
    LatestPartition {
        query: &'q str,
        partition_key: String,
    },
    LatestApp {
        query: &'q str,
        partition_key: String,
        app_id: &'v str,
    },
    ExactSequence {
        query: &'q str,
        partition_key: String,
        app_id: &'v str,
        sequence_id: i64,
    },
}

impl<'q, 'v> LoadOperation<'q, 'v> {
    pub(crate) fn new(
        queries: &'q PersistedStateQueries,
        partition_key: Option<&str>,
        app_id: Option<&'v str>,
        sequence_id: Option<u64>,
    ) -> Result<Self, PersistenceError> {
        Self::from_queries(
            queries,
            LoadSelector::new(partition_key, app_id, sequence_id)?,
        )
    }

    pub(crate) fn from_queries(
        queries: &'q PersistedStateQueries,
        selector: LoadSelector<'v>,
    ) -> Result<Self, PersistenceError> {
        Ok(match selector {
            LoadSelector::NoRecord => LoadOperation::NoRecord,
            LoadSelector::LatestPartition { partition_key } => LoadOperation::LatestPartition {
                query: queries.load_latest_partition(),
                partition_key,
            },
            LoadSelector::LatestApp {
                partition_key,
                app_id,
            } => LoadOperation::LatestApp {
                query: queries.load_latest_app(),
                partition_key,
                app_id,
            },
            LoadSelector::ExactSequence {
                partition_key,
                app_id,
                sequence_id,
            } => LoadOperation::ExactSequence {
                query: queries.load_sequence_app(),
                partition_key,
                app_id,
                sequence_id,
            },
        })
    }
}

pub(crate) fn ensure_initialized_result(
    initialization_hint: &InitializationHint,
    is_initialized: bool,
) -> Result<(), PersistenceError> {
    if initialization_hint.is_set() || is_initialized {
        Ok(())
    } else {
        Err(PersistenceError::NotInitialized)
    }
}

pub(crate) fn list_app_ids_operation<'q>(
    queries: &'q PersistedStateQueries,
    partition_key: Option<&str>,
) -> SqlListAppIdsPlan<'q> {
    SqlListAppIdsPlan {
        query: queries.list_app_ids(),
        partition_key: persistence_wire::normalize_partition_key(partition_key),
    }
}

/// Normalized SQL list-app-ids operation shared by sync and async executors.
#[derive(Debug)]
pub struct SqlListAppIdsPlan<'q> {
    /// SQL statement to execute.
    pub query: &'q str,
    /// Normalized partition key.
    pub partition_key: String,
}

pub(crate) fn persisted_state_from_tuple(
    tuple: PersistedRowTuple,
) -> Result<PersistedStateData, PersistenceError> {
    tuple_to_persisted_state(tuple)
}
