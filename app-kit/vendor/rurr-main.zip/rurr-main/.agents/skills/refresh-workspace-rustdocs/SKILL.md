---
name: refresh-workspace-rustdocs
description: "Use when the user wants a workspace-wide refresh of public Rustdoc comments across all crates, including plan-mode planning and execution, auditing every public item for stale or missing docs, adding runnable doctests where feasible, tightening missing_docs without suppressions, and validating cargo doc, cargo test --doc, example builds, and doc-site flows. Do not use for one-off item docs, single-crate spot fixes, or isolated doctest or lint cleanup."
---

# Refresh Workspace Rustdocs

Use this skill when the task is to plan and execute a workspace-wide refresh of end-user-facing Rustdoc comments.

## Quick start

Load, in order:

- the workspace `Cargo.toml`
- the public crate roots for the crates in scope
- `references/rustdoc-house-style.md`
- `references/doctest-patterns.md`
- `references/rurr-rustdoc-checklist.md`
- `$use-rust-best-practices-testing`

Also load `$use-rust-best-practices-async` or `$use-rust-best-practices-networking` only when doctest examples need async runtime or live-client guidance.

## Planning phase

In Plan Mode, produce a decision-complete `<proposed_plan>` first and use the Implementation phase only after the operator enables execution.

1. Inventory the workspace crates and the public API surfaces that belong in end-user docs.
2. Document canonical source items before re-exports so long-form prose lives with the defining item.
3. Identify stale, missing, or thin Rustdocs on public structs, enums, traits, functions, methods, modules, and crate roots.
4. Decide where runnable doctests are feasible and where a nearby module or type example must stand in instead.
5. Define the validation sequence before editing so doc builds, doctests, example coverage, and doc-site checks are explicit.
6. Decide where `#![deny(missing_docs)]` can be added or tightened only after coverage is complete.
7. Produce a decision-complete `<proposed_plan>` that groups work by crate or API surface instead of dumping symbol inventories.

## Implementation phase

1. Reload the approved plan and the touched crate roots before editing.
2. Add or refresh crate and module docs with `//!`, and item docs with `///`.
3. Keep summaries short and searchable, then explain behavior, invariants, notable inputs or outputs, and failure modes.
4. Add local-only runnable doctests where feasible, using hidden setup and `?`-based flow instead of brittle `unwrap()` examples.
5. Keep full prose on the canonical source item and keep re-export docs concise.
6. Avoid `#[doc(hidden)]`, warning suppressions, or relaxed lints as shortcuts around missing documentation.
7. Tighten `missing_docs` only after the affected crate or module is fully covered.
8. Run validation in order:
   - `cargo doc --workspace --no-deps --all-features`
   - `cargo test --workspace --doc --all-features`
   - `cargo test -p rurr --examples --all-features`
   - `./scripts/doc_site.sh build`
   - `./scripts/doc_site.sh check`
9. If manifest freshness becomes the only blocker, run `./scripts/fix_manifest_freshness.sh` and rerun the failed gate.
10. Report changed crates, doctest additions, lint changes, validation results, and any remaining coverage gaps.

## Default rules

- Use Rust doc comments only; do not move end-user docs into sidecar Markdown as a substitute.
- Prefer self-contained examples that do not require network access or live services.
- Keep public API docs accurate to the current implementation, not the intended future shape.
- Add sections like `# Examples`, `# Errors`, `# Panics`, `# Safety`, or async notes only when they materially clarify behavior.
- Treat doc quality as part of the public API contract.

## Do not use this skill for

- documenting a single public method, type, or module in isolation
- one-crate spot fixes for minor doctest failures or small Rustdoc gaps
- crate layout or workspace architecture work that is not primarily a Rustdoc refresh

## Do not use this skill alone when

- doctest examples need async runtime, shutdown, or concurrency guidance -> also use `$use-rust-best-practices-async`
- doctest examples need HTTP, gRPC, database, or network-client guidance -> also use `$use-rust-best-practices-networking`
- the task is mostly about crate or workspace layout rather than Rustdocs -> also use `$use-rust-best-practices-architecture`
