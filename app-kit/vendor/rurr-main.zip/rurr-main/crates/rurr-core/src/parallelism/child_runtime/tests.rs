use super::{
    child_instance_app_id, run_child_async, run_child_sync, sanitize_task_state, ResolvedChildTask,
};
use crate::{
    action::api::LocalAction,
    action::FunctionActionBuilder,
    application::build::BuildMode,
    application::resources::RuntimeResources,
    application::ParentPointer,
    graph::{GraphAction, Transition},
    lifecycle::{AsyncLifecycleAdapter, LifecycleAdapterSet, LifecycleError, SyncLifecycleAdapter},
    parallelism::{types::SubGraphTask, ParallelRuntimeContext, RunnableGraph},
    state::State,
};
use indexmap::IndexMap;
use rurr_persistence::{
    AsyncBaseStateLoader, BaseStateLoader, PersistedStateData, PersistenceError, StateLoaderRef,
};
use serde_json::json;
use sha2::{Digest, Sha256};
use std::sync::{Arc, Mutex};

const INTENTIONAL_CHILD_SYNC_LOAD_FAILURE: &str = "intentional_child_sync_load_failure";
const INTENTIONAL_CHILD_ASYNC_LOAD_FAILURE: &str = "intentional_child_async_load_failure";

#[derive(Debug, Default)]
struct ChildRegistrationRecorder {
    child_app_ids: Mutex<Vec<String>>,
}

impl ChildRegistrationRecorder {
    fn child_app_ids(&self) -> Vec<String> {
        self.child_app_ids
            .lock()
            .expect("child_app_ids lock should not be poisoned")
            .clone()
    }

    fn record_child_app_id(&self, child_app_id: &str) {
        self.child_app_ids
            .lock()
            .expect("child_app_ids lock should not be poisoned")
            .push(child_app_id.to_string());
    }
}

impl SyncLifecycleAdapter for ChildRegistrationRecorder {
    fn register_child_application(
        &self,
        child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &crate::graph::Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.record_child_app_id(child_app_id);
        Ok(())
    }
}

#[async_trait::async_trait]
impl AsyncLifecycleAdapter for ChildRegistrationRecorder {
    async fn register_child_application(
        &self,
        child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &crate::graph::Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.record_child_app_id(child_app_id);
        Ok(())
    }
}

#[derive(Debug)]
struct FailingSyncContextLoader {
    seen_app_ids: Arc<Mutex<Vec<Option<String>>>>,
}

impl FailingSyncContextLoader {
    fn new(seen_app_ids: Arc<Mutex<Vec<Option<String>>>>) -> Self {
        Self { seen_app_ids }
    }
}

impl BaseStateLoader for FailingSyncContextLoader {
    fn load(
        &self,
        _partition_key: Option<&str>,
        app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.seen_app_ids
            .lock()
            .expect("seen_app_ids lock should not be poisoned")
            .push(app_id.map(str::to_string));
        Err(PersistenceError::UnsupportedOperation {
            operation: INTENTIONAL_CHILD_SYNC_LOAD_FAILURE,
        })
    }

    fn list_app_ids(&self, _partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

#[derive(Debug)]
struct FailingAsyncContextLoader {
    seen_app_ids: Arc<Mutex<Vec<Option<String>>>>,
}

impl FailingAsyncContextLoader {
    fn new(seen_app_ids: Arc<Mutex<Vec<Option<String>>>>) -> Self {
        Self { seen_app_ids }
    }
}

#[async_trait::async_trait]
impl AsyncBaseStateLoader for FailingAsyncContextLoader {
    async fn load(
        &self,
        _partition_key: Option<&str>,
        app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.seen_app_ids
            .lock()
            .expect("seen_app_ids lock should not be poisoned")
            .push(app_id.map(str::to_string));
        Err(PersistenceError::UnsupportedOperation {
            operation: INTENTIONAL_CHILD_ASYNC_LOAD_FAILURE,
        })
    }

    async fn list_app_ids(
        &self,
        _partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

fn runnable_graph_with_sync_app_id_capture(name: &str) -> RunnableGraph {
    let action = FunctionActionBuilder::new()
        .writes(["seen_app_id"])
        .build_sync(|_state, ctx| {
            let app_id = ctx
                .app_context
                .as_ref()
                .map(|context| context.app_id.clone())
                .expect("application context should be present in child");
            IndexMap::from([("seen_app_id".to_string(), json!(app_id))])
        })
        .expect("action should build")
        .with_name(name)
        .expect("action naming should succeed");
    let graph_action = GraphAction::new(action).expect("graph action should build");
    RunnableGraph::new(
        vec![graph_action],
        Vec::<Transition>::new(),
        Some(name.to_string()),
    )
}

fn runnable_graph_with_async_app_id_capture(name: &str) -> RunnableGraph {
    let action = FunctionActionBuilder::new()
        .writes(["seen_app_id"])
        .build_async(|_state, ctx| async move {
            let app_id = ctx
                .app_context
                .as_ref()
                .map(|context| context.app_id.clone())
                .expect("application context should be present in child");
            IndexMap::from([("seen_app_id".to_string(), json!(app_id))])
        })
        .expect("action should build")
        .with_name(name)
        .expect("action naming should succeed");
    let graph_action = GraphAction::new(action).expect("graph action should build");
    RunnableGraph::new(
        vec![graph_action],
        Vec::<Transition>::new(),
        Some(name.to_string()),
    )
}

#[test]
fn run_child_sync_uses_subgraph_task_app_id() {
    let output_state = run_child_sync(
        SubGraphTask::new(
            runnable_graph_with_sync_app_id_capture("capture"),
            State::default(),
            "alpha",
        ),
        &ParallelRuntimeContext::new(
            "parent-app".to_string(),
            Some("pk".to_string()),
            17,
            RuntimeResources::new(LifecycleAdapterSet::default()),
        ),
    )
    .expect("child run should succeed");

    assert_eq!(
        output_state.get("seen_app_id"),
        Some(&json!(child_instance_app_id("parent-app", "alpha")))
    );
}

#[tokio::test]
async fn run_child_async_uses_subgraph_task_app_id() {
    let runtime = ParallelRuntimeContext::new(
        "parent-app".to_string(),
        Some("pk".to_string()),
        17,
        RuntimeResources::new(LifecycleAdapterSet::default()),
    );

    let output_state = run_child_async(
        SubGraphTask::new(
            runnable_graph_with_async_app_id_capture("capture_async"),
            State::default(),
            "beta",
        ),
        &runtime,
    )
    .await
    .expect("child run should succeed");

    assert_eq!(
        output_state.get("seen_app_id"),
        Some(&json!(child_instance_app_id("parent-app", "beta")))
    );
}

#[test]
fn run_child_sync_build_failure_does_not_register_child_and_build_uses_child_context() {
    let seen_app_ids = Arc::new(Mutex::new(Vec::new()));
    let registration_recorder = Arc::new(ChildRegistrationRecorder::default());
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = registration_recorder.clone();
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], Vec::new());
    let loader = Arc::new(FailingSyncContextLoader::new(Arc::clone(&seen_app_ids)));
    let task_key = "gamma";
    let child_app_id = child_instance_app_id("parent-app", task_key);

    let error = run_child_sync(
        SubGraphTask::new(
            runnable_graph_with_sync_app_id_capture("capture_loader_sync"),
            State::default(),
            task_key,
        ),
        &ParallelRuntimeContext::new(
            "parent-app".to_string(),
            Some("pk".to_string()),
            17,
            RuntimeResources::new(hooks).with_state_initializer(StateLoaderRef::sync(loader)),
        ),
    )
    .expect_err("child build should fail when the inherited sync loader errors");

    assert!(
        error
            .to_string()
            .contains(INTENTIONAL_CHILD_SYNC_LOAD_FAILURE),
        "error should include the loader failure marker: {error}"
    );
    assert!(
        registration_recorder.child_app_ids().is_empty(),
        "build failure must not leave a registered phantom child"
    );
    assert_eq!(
        seen_app_ids
            .lock()
            .expect("seen_app_ids lock should not be poisoned")
            .as_slice(),
        &[Some(child_app_id)],
        "sync child build should run under the child current context"
    );
}

#[tokio::test]
async fn run_child_async_build_failure_does_not_register_child_and_build_uses_child_context() {
    let seen_app_ids = Arc::new(Mutex::new(Vec::new()));
    let registration_recorder = Arc::new(ChildRegistrationRecorder::default());
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = registration_recorder.clone();
    let hooks = LifecycleAdapterSet::new(Vec::new(), vec![async_hook]);
    let loader = Arc::new(FailingAsyncContextLoader::new(Arc::clone(&seen_app_ids)));
    let task_key = "delta";
    let child_app_id = child_instance_app_id("parent-app", task_key);

    let error = run_child_async(
        SubGraphTask::new(
            runnable_graph_with_async_app_id_capture("capture_loader_async"),
            State::default(),
            task_key,
        ),
        &ParallelRuntimeContext::new(
            "parent-app".to_string(),
            Some("pk".to_string()),
            17,
            RuntimeResources::new(hooks)
                .with_state_initializer(StateLoaderRef::async_loader(loader)),
        ),
    )
    .await
    .expect_err("child build should fail when the inherited async loader errors");

    assert!(
        error
            .to_string()
            .contains(INTENTIONAL_CHILD_ASYNC_LOAD_FAILURE),
        "error should include the loader failure marker: {error}"
    );
    assert!(
        registration_recorder.child_app_ids().is_empty(),
        "build failure must not leave a registered phantom child"
    );
    assert_eq!(
        seen_app_ids
            .lock()
            .expect("seen_app_ids lock should not be poisoned")
            .as_slice(),
        &[Some(child_app_id)],
        "async child build should run under the child current context"
    );
}

#[test]
fn child_instance_app_id_is_stable_across_parent_sequences() {
    let step0 = child_instance_app_id("parent-app", "0-0");
    let step1 = child_instance_app_id("parent-app", "0-0");
    let step2 = child_instance_app_id("parent-app", "0-0");
    let other_task = child_instance_app_id("parent-app", "0-1");

    assert_eq!(step0, step1);
    assert_eq!(step1, step2);
    assert_ne!(step0, other_task);
}

#[test]
fn child_instance_app_id_uses_parent_app_and_task_key_seed() {
    let actual = child_instance_app_id("parent-app", "0-0");
    let expected = format!("{:x}", Sha256::digest("parent-app:0-0".as_bytes()));
    let namespaced = format!(
        "{:x}",
        Sha256::digest("parent-app:other_action:0-0".as_bytes())
    );

    assert_eq!(actual, expected);
    assert_ne!(actual, namespaced);
}

#[test]
fn sanitize_task_state_drops_reserved_runtime_keys_only() {
    let sanitized = sanitize_task_state(
        State::default()
            .update(IndexMap::from([
                ("__SEQUENCE_ID".to_string(), json!(3)),
                ("__PRIOR_STEP".to_string(), json!("parallel")),
                ("kept".to_string(), json!(1)),
            ]))
            .expect("seed state update should succeed"),
    )
    .expect("sanitizing task state should succeed");

    assert_eq!(sanitized.get("kept"), Some(&json!(1)));
    assert_eq!(sanitized.get("__SEQUENCE_ID"), None);
    assert_eq!(sanitized.get("__PRIOR_STEP"), None);
}

#[test]
fn resolved_child_task_metadata_matches_across_sync_and_async_lanes() {
    fn task() -> SubGraphTask {
        SubGraphTask::new(
            runnable_graph_with_sync_app_id_capture("capture_shared"),
            State::default()
                .update(IndexMap::from([
                    ("kept".to_string(), json!(9)),
                    ("__SEQUENCE_ID".to_string(), json!(44)),
                ]))
                .expect("seed state update should succeed"),
            "shared-task",
        )
        .with_inputs(IndexMap::from([("task_input".to_string(), json!(7))]))
        .with_child_app_id("child-explicit")
    }

    let runtime = ParallelRuntimeContext::new(
        "parent-app".to_string(),
        Some("pk".to_string()),
        17,
        RuntimeResources::new(LifecycleAdapterSet::default()),
    );

    let sync = ResolvedChildTask::resolve(task(), &runtime, BuildMode::Sync)
        .expect("sync resolution should succeed");
    let async_task = ResolvedChildTask::resolve(task(), &runtime, BuildMode::Async)
        .expect("async resolution should succeed");

    assert_eq!(sync.plan.child_app_id, async_task.plan.child_app_id);
    assert_eq!(sync.plan.partition_key, async_task.plan.partition_key);
    assert_eq!(sync.plan.spawning_parent, async_task.plan.spawning_parent);
    assert_eq!(sync.state, async_task.state);
    assert_eq!(sync.inputs, async_task.inputs);
    assert_eq!(sync.graph.entrypoint(), async_task.graph.entrypoint());
    assert_eq!(sync.state.get("__SEQUENCE_ID"), None);
    assert_eq!(sync.state.get("kept"), Some(&json!(9)));
}
