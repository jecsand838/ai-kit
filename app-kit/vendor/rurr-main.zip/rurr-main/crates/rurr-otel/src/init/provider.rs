use super::{build_otlp_log_exporter, build_otlp_span_exporter, OtlpConfig, OtlpError};
use opentelemetry::trace::TracerProvider as _;
use opentelemetry::{global, KeyValue};
use opentelemetry_sdk::logs::{
    log_processor_with_async_runtime::BatchLogProcessor, LogExporter, SdkLoggerProvider,
};
use opentelemetry_sdk::resource::{EnvResourceDetector, TelemetryResourceDetector};
use opentelemetry_sdk::runtime;
use opentelemetry_sdk::trace::{
    span_processor_with_async_runtime::BatchSpanProcessor, SdkTracerProvider, SpanExporter,
    SpanProcessor,
};
use opentelemetry_sdk::Resource;
use tokio::runtime::{Handle, RuntimeFlavor};
use tracing_subscriber::layer::SubscriberExt;
use tracing_subscriber::util::SubscriberInitExt;
use tracing_subscriber::EnvFilter;

const OTEL_SERVICE_NAME: &str = "OTEL_SERVICE_NAME";
const SERVICE_VERSION: &str = "service.version";

/// Configuration for a `tracing-opentelemetry` subscriber.
///
/// The filter is applied before spans are forwarded to the OpenTelemetry layer.
/// Use `EnvFilter::new(...)` for deterministic tests or
/// [`Default::default`] to honor `RUST_LOG`.
#[derive(Debug)]
pub struct TracingSubscriberConfig {
    /// Filter applied before spans are forwarded to OpenTelemetry.
    pub filter: EnvFilter,
}

impl Default for TracingSubscriberConfig {
    fn default() -> Self {
        Self {
            filter: EnvFilter::from_default_env(),
        }
    }
}

/// Builds a `tracing` subscriber that forwards spans to OpenTelemetry.
///
/// This is the direct Rust instrumentation surface for ordinary `tracing` spans.
/// Use instrumentation crates such as `tower-http` directly, then install or scope
/// this subscriber to bridge their `tracing` spans into the configured OTEL tracer.
///
/// # Examples
///
/// ```
/// use rurr_otel::opentelemetry::trace::TracerProvider as _;
/// use rurr_otel::opentelemetry_sdk::trace::SdkTracerProvider;
/// use rurr_otel::{build_tracing_subscriber, TracingSubscriberConfig};
///
/// let provider = SdkTracerProvider::builder().build();
/// let tracer = provider.tracer("docs");
/// let subscriber = build_tracing_subscriber(tracer, TracingSubscriberConfig::default());
/// let _guard = tracing::subscriber::set_default(subscriber);
///
/// let _span = tracing::info_span!("docs-span").entered();
/// ```
pub fn build_tracing_subscriber<Tracer>(
    tracer: Tracer,
    config: TracingSubscriberConfig,
) -> impl tracing::Subscriber + Send + Sync + 'static
where
    Tracer: opentelemetry::trace::Tracer
        + tracing_opentelemetry::PreSampledTracer
        + Send
        + Sync
        + 'static,
{
    let layer = tracing_opentelemetry::layer().with_tracer(tracer);
    tracing_subscriber::registry()
        .with(config.filter)
        .with(layer)
}

/// Builds an OTEL resource with Rurr defaults and official env override precedence.
///
/// `service.name` starts from [`OtlpConfig::service_name`], optional
/// `service.version` comes from the config, and standard OTEL resource
/// environment detectors can override or extend those attributes.
pub fn build_resource(config: &OtlpConfig) -> Resource {
    let mut builder = Resource::builder_empty()
        .with_detector(Box::new(TelemetryResourceDetector))
        .with_attribute(KeyValue::new("service.name", config.service_name.clone()));

    if let Some(version) = &config.service_version {
        builder = builder.with_attribute(KeyValue::new(SERVICE_VERSION, version.clone()));
    }

    builder = builder.with_detector(Box::new(EnvResourceDetector::new()));

    if let Some(service_name) = std::env::var(OTEL_SERVICE_NAME)
        .ok()
        .filter(|value| !value.is_empty())
    {
        builder = builder.with_service_name(service_name);
    }

    builder.build()
}

/// Builds a tracer provider using the configured OTLP exporter.
///
/// This requires a Tokio multi-thread runtime because OTLP batch processors use
/// the Tokio SDK runtime.
///
/// # Errors
///
/// Returns [`OtlpError`] when endpoint/protocol configuration is invalid or the
/// current Tokio runtime cannot drive batch OTLP export.
pub fn build_otlp_tracer_provider(config: &OtlpConfig) -> Result<SdkTracerProvider, OtlpError> {
    let exporter = build_otlp_span_exporter(config)?;
    build_otlp_tracer_provider_with_exporter(exporter, config)
}

/// Builds a tracer provider using the configured OTLP exporter and additional span processors.
///
/// Additional processors are installed alongside the OTLP batch processor. This
/// is the hook used by the Rurr tracking bridge to mirror external child spans
/// into tracking artifacts while still exporting traces.
///
/// # Errors
///
/// Returns the same configuration/runtime errors as
/// [`build_otlp_tracer_provider`].
pub fn build_otlp_tracer_provider_with_span_processors<P, I>(
    config: &OtlpConfig,
    processors: I,
) -> Result<SdkTracerProvider, OtlpError>
where
    P: SpanProcessor + 'static,
    I: IntoIterator<Item = P>,
{
    let exporter = build_otlp_span_exporter(config)?;
    build_otlp_tracer_provider_with_exporter_and_span_processors(exporter, config, processors)
}

/// Builds a logger provider using the configured OTLP exporter.
///
/// This uses the same resource construction and Tokio runtime requirements as
/// the trace provider.
///
/// # Errors
///
/// Returns [`OtlpError`] when logs endpoint/protocol configuration is invalid
/// or the current Tokio runtime cannot drive batch OTLP export.
pub fn build_otlp_logger_provider(config: &OtlpConfig) -> Result<SdkLoggerProvider, OtlpError> {
    let exporter = build_otlp_log_exporter(config)?;
    build_otlp_logger_provider_with_exporter(exporter, config)
}

/// Installs a tracing subscriber layer with an explicit filter configuration.
///
/// Prefer [`build_tracing_subscriber`] plus `tracing::subscriber::set_default`
/// in tests that need scoped subscribers.
///
/// # Errors
///
/// Returns an install error when another global tracing subscriber has already
/// been installed for the process.
pub fn install_tracing_subscriber_with_config<Tracer>(
    tracer: Tracer,
    config: TracingSubscriberConfig,
) -> Result<(), OtlpError>
where
    Tracer: opentelemetry::trace::Tracer
        + tracing_opentelemetry::PreSampledTracer
        + Send
        + Sync
        + 'static,
{
    build_tracing_subscriber(tracer, config)
        .try_init()
        .map_err(|error| OtlpError::SubscriberInstall(error.to_string()))
}

pub(super) fn install_provider_with_exporter<E>(
    exporter: E,
    config: &OtlpConfig,
) -> Result<SdkTracerProvider, OtlpError>
where
    E: SpanExporter + 'static,
{
    let provider = SdkTracerProvider::builder()
        .with_resource(build_resource(config))
        .with_simple_exporter(exporter)
        .build();
    let tracer = provider.tracer("rurr-otel");
    install_tracing_subscriber_with_config(tracer, TracingSubscriberConfig::default())?;
    global::set_tracer_provider(provider.clone());

    Ok(provider)
}

pub(super) fn install_otlp_provider_with_exporter<E>(
    exporter: E,
    config: &OtlpConfig,
) -> Result<SdkTracerProvider, OtlpError>
where
    E: SpanExporter + 'static,
{
    let provider = build_otlp_tracer_provider_with_exporter(exporter, config)?;
    let tracer = provider.tracer("rurr-otel");
    install_tracing_subscriber_with_config(tracer, TracingSubscriberConfig::default())?;
    global::set_tracer_provider(provider.clone());

    Ok(provider)
}

fn build_otlp_tracer_provider_with_exporter<E>(
    exporter: E,
    config: &OtlpConfig,
) -> Result<SdkTracerProvider, OtlpError>
where
    E: SpanExporter + 'static,
{
    ensure_multi_thread_tokio_runtime("building an OTLP trace provider")?;
    let batch = BatchSpanProcessor::builder(exporter, runtime::Tokio).build();
    Ok(SdkTracerProvider::builder()
        .with_resource(build_resource(config))
        .with_span_processor(batch)
        .build())
}

fn build_otlp_tracer_provider_with_exporter_and_span_processors<E, P, I>(
    exporter: E,
    config: &OtlpConfig,
    processors: I,
) -> Result<SdkTracerProvider, OtlpError>
where
    E: SpanExporter + 'static,
    P: SpanProcessor + 'static,
    I: IntoIterator<Item = P>,
{
    ensure_multi_thread_tokio_runtime("building an OTLP trace provider")?;
    let mut builder = SdkTracerProvider::builder().with_resource(build_resource(config));
    for processor in processors {
        builder = builder.with_span_processor(processor);
    }
    let batch = BatchSpanProcessor::builder(exporter, runtime::Tokio).build();
    Ok(builder.with_span_processor(batch).build())
}

fn build_otlp_logger_provider_with_exporter<E>(
    exporter: E,
    config: &OtlpConfig,
) -> Result<SdkLoggerProvider, OtlpError>
where
    E: LogExporter + 'static,
{
    ensure_multi_thread_tokio_runtime("building an OTLP log provider")?;
    let batch = BatchLogProcessor::builder(exporter, runtime::Tokio).build();
    Ok(SdkLoggerProvider::builder()
        .with_log_processor(batch)
        .with_resource(build_resource(config))
        .build())
}

fn ensure_multi_thread_tokio_runtime(operation: &'static str) -> Result<(), OtlpError> {
    let handle = Handle::try_current().map_err(|_| {
        OtlpError::ProviderRuntime("OTLP providers require an active Tokio runtime")
    })?;
    match handle.runtime_flavor() {
        RuntimeFlavor::MultiThread => Ok(()),
        RuntimeFlavor::CurrentThread => Err(OtlpError::ProviderRuntime(
            "OTLP providers require Tokio's multi-thread runtime",
        )),
        _ => Err(OtlpError::ProviderRuntime(operation)),
    }
}
