use crate::UiBuildArgs;
use std::path::PathBuf;

pub(crate) fn build(args: UiBuildArgs) -> Result<(), Box<dyn std::error::Error>> {
    let output = args.out_dir.unwrap_or_else(|| PathBuf::from("rurr-ui"));
    rurr_tracking_server::ui_assets::write_embedded_bundle(&output)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn build_writes_embedded_bundle_to_output_directory() {
        let output = tempfile::tempdir().expect("tempdir should be created");
        build(crate::UiBuildArgs {
            out_dir: Some(output.path().to_path_buf()),
        })
        .expect("build should export embedded bundle");

        assert!(output.path().join("index.html").exists());
        assert!(output.path().join("assets").join("app.js").exists());
    }
}
