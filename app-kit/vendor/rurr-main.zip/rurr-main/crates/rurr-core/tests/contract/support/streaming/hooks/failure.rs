use super::super::assertions::{
    ASYNC_POST_END_STREAM_FAILURE_MARKER, ASYNC_POST_EXECUTE_FAILURE_MARKER,
    ASYNC_POST_RUN_STEP_FAILURE_MARKER, ASYNC_POST_STREAM_ITEM_FAILURE_MARKER,
    ASYNC_PRE_START_STREAM_FAILURE_MARKER, SYNC_POST_END_STREAM_FAILURE_MARKER,
    SYNC_POST_EXECUTE_FAILURE_MARKER, SYNC_POST_RUN_STEP_FAILURE_MARKER,
    SYNC_POST_STREAM_ITEM_FAILURE_MARKER, SYNC_PRE_START_STREAM_FAILURE_MARKER,
};
use super::common::{LifecycleFailure, LifecycleHookLane, LifecycleHookPhase};
use async_trait::async_trait;
use rurr_core::lifecycle::LifecycleError;
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, ExecuteCallContext, PostStepContext, StreamContext, StreamItemContext,
    SyncLifecycleAdapter,
};

#[derive(Debug, Default)]
pub(crate) struct LifecycleFailureHook {
    failures: Vec<LifecycleFailure>,
}

impl LifecycleFailureHook {
    pub(crate) fn new() -> Self {
        Self::default()
    }

    pub(crate) fn sync_post_execute() -> Self {
        Self::new().with_sync_failure(
            LifecycleHookPhase::PostExecuteCall,
            SYNC_POST_EXECUTE_FAILURE_MARKER,
        )
    }

    pub(crate) fn async_post_execute() -> Self {
        Self::new().with_async_failure(
            LifecycleHookPhase::PostExecuteCall,
            ASYNC_POST_EXECUTE_FAILURE_MARKER,
        )
    }

    pub(crate) fn sync_post_run_step() -> Self {
        Self::new().with_sync_failure(
            LifecycleHookPhase::PostRunStep,
            SYNC_POST_RUN_STEP_FAILURE_MARKER,
        )
    }

    pub(crate) fn sync_post_end_stream() -> Self {
        Self::new().with_sync_failure(
            LifecycleHookPhase::PostEndStream,
            SYNC_POST_END_STREAM_FAILURE_MARKER,
        )
    }

    pub(crate) fn sync_post_stream_item_and_post_run_step() -> Self {
        Self::new()
            .with_sync_failure(
                LifecycleHookPhase::PostStreamItem,
                SYNC_POST_STREAM_ITEM_FAILURE_MARKER,
            )
            .with_sync_failure(
                LifecycleHookPhase::PostRunStep,
                SYNC_POST_RUN_STEP_FAILURE_MARKER,
            )
    }

    pub(crate) fn async_post_run_step() -> Self {
        Self::new().with_async_failure(
            LifecycleHookPhase::PostRunStep,
            ASYNC_POST_RUN_STEP_FAILURE_MARKER,
        )
    }

    pub(crate) fn async_post_end_stream() -> Self {
        Self::new().with_async_failure(
            LifecycleHookPhase::PostEndStream,
            ASYNC_POST_END_STREAM_FAILURE_MARKER,
        )
    }

    pub(crate) fn async_post_stream_item_and_post_run_step() -> Self {
        Self::new()
            .with_async_failure(
                LifecycleHookPhase::PostStreamItem,
                ASYNC_POST_STREAM_ITEM_FAILURE_MARKER,
            )
            .with_async_failure(
                LifecycleHookPhase::PostRunStep,
                ASYNC_POST_RUN_STEP_FAILURE_MARKER,
            )
    }

    pub(crate) fn sync_pre_start_stream() -> Self {
        Self::new().with_sync_failure(
            LifecycleHookPhase::PreStartStream,
            SYNC_PRE_START_STREAM_FAILURE_MARKER,
        )
    }

    pub(crate) fn async_pre_start_stream() -> Self {
        Self::new().with_async_failure(
            LifecycleHookPhase::PreStartStream,
            ASYNC_PRE_START_STREAM_FAILURE_MARKER,
        )
    }

    fn with_sync_failure(mut self, phase: LifecycleHookPhase, marker: &'static str) -> Self {
        self.failures.push(LifecycleFailure {
            lane: LifecycleHookLane::Sync,
            phase,
            marker,
        });
        self
    }

    fn with_async_failure(mut self, phase: LifecycleHookPhase, marker: &'static str) -> Self {
        self.failures.push(LifecycleFailure {
            lane: LifecycleHookLane::Async,
            phase,
            marker,
        });
        self
    }

    fn maybe_fail(
        &self,
        lane: LifecycleHookLane,
        phase: LifecycleHookPhase,
    ) -> Result<(), LifecycleError> {
        if let Some(failure) = self
            .failures
            .iter()
            .find(|failure| failure.lane == lane && failure.phase == phase)
        {
            return Err(LifecycleError::hook_failed(
                phase.phase_name(),
                failure.marker,
            ));
        }
        Ok(())
    }
}

impl SyncLifecycleAdapter for LifecycleFailureHook {
    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Sync, LifecycleHookPhase::PostExecuteCall)
    }

    fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Sync, LifecycleHookPhase::PostRunStep)
    }

    fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Sync, LifecycleHookPhase::PreStartStream)
    }

    fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Sync, LifecycleHookPhase::PostEndStream)
    }

    fn post_stream_item(&self, _context: &StreamItemContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Sync, LifecycleHookPhase::PostStreamItem)
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for LifecycleFailureHook {
    async fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.maybe_fail(
            LifecycleHookLane::Async,
            LifecycleHookPhase::PostExecuteCall,
        )
    }

    async fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Async, LifecycleHookPhase::PostRunStep)
    }

    async fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Async, LifecycleHookPhase::PreStartStream)
    }

    async fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Async, LifecycleHookPhase::PostEndStream)
    }

    async fn post_stream_item(&self, _context: &StreamItemContext) -> Result<(), LifecycleError> {
        self.maybe_fail(LifecycleHookLane::Async, LifecycleHookPhase::PostStreamItem)
    }
}
