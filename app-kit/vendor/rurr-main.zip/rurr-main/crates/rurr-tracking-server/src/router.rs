//! Axum router assembly and shared UI state for the tracking server.
//!
//! [`AppState`] binds one [`crate::backend::TrackingBackend`] with either the
//! embedded UI bundle or a caller-provided directory, and [`app`] turns that
//! state into the full HTTP router used by the CLI and tests.

use crate::backend::{BackendError, PartitionSelector, TrackingBackend};
use crate::schema::{PaginationQuery, ReadyResponse};
use crate::ui_assets;
use crate::ui_fs::DirectoryUiFs;
use axum::body::Body;
use axum::extract::{Path, Query, State};
use axum::http::header;
use axum::http::StatusCode;
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::{Json, Router};
use std::path::PathBuf;
use std::sync::Arc;

/// Annotation API routes mounted under `/api/v0`.
pub mod annotations;
/// Indexing-job API routes mounted under `/api/v0`.
pub mod indexing_jobs;
/// Version metadata route mounted under `/api/v0`.
pub mod version;

/// Prepared filesystem-backed UI directory state.
#[derive(Clone, Debug)]
pub struct UiDirectory {
    pub(crate) fs: DirectoryUiFs,
}

/// Source of the HTML and static assets served by the tracking UI.
#[derive(Clone, Debug)]
pub enum UiSource {
    /// Serve the UI bundle embedded into the binary at compile time.
    Embedded,
    /// Serve files from a caller-supplied directory on disk.
    Directory(Box<UiDirectory>),
}

/// Shared Axum application state for the tracking server.
///
/// The state owns the backend behind a trait object so route handlers stay
/// storage-agnostic. Backend-specific behavior, such as S3 indexing jobs, is
/// advertised through backend capability flags instead of leaking provider
/// types through the router API.
#[derive(Clone)]
pub struct AppState {
    backend: Arc<dyn TrackingBackend>,
    ui_source: UiSource,
}

impl AppState {
    /// Creates state backed by the embedded UI bundle.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use std::sync::Arc;
    ///
    /// use rurr_tracking_server::backend::local::LocalBackend;
    /// use rurr_tracking_server::router::{AppState, UiSource};
    ///
    /// let storage_dir = std::env::temp_dir().join("rurr-tracking-server-docs-embedded");
    /// std::fs::create_dir_all(&storage_dir)?;
    /// let state = AppState::with_embedded_ui(Arc::new(LocalBackend::new(&storage_dir)?));
    /// assert!(matches!(state.ui_source(), UiSource::Embedded));
    /// # std::fs::remove_dir_all(&storage_dir)?;
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn with_embedded_ui(backend: Arc<dyn TrackingBackend>) -> Self {
        Self {
            backend,
            ui_source: UiSource::Embedded,
        }
    }

    /// Creates state backed by a caller-managed UI directory on disk.
    ///
    /// The directory must contain `index.html`; an `assets/` directory is
    /// optional.
    ///
    /// # Examples
    ///
    /// ```rust
    /// # fn unique_dir() -> std::path::PathBuf {
    /// #     let nanos = std::time::SystemTime::now()
    /// #         .duration_since(std::time::UNIX_EPOCH)
    /// #         .map(|duration| duration.as_nanos())
    /// #         .unwrap_or(0);
    /// #     std::env::temp_dir().join(format!("rurr-ui-{nanos}"))
    /// # }
    /// use std::sync::Arc;
    ///
    /// use rurr_tracking_server::backend::local::LocalBackend;
    /// use rurr_tracking_server::router::{AppState, UiSource};
    ///
    /// let storage_dir = std::env::temp_dir().join("rurr-tracking-server-docs-directory");
    /// std::fs::create_dir_all(&storage_dir)?;
    /// let ui_dir = unique_dir();
    /// std::fs::create_dir_all(ui_dir.join("assets"))?;
    /// std::fs::write(ui_dir.join("index.html"), "<!doctype html><title>Rurr</title>")?;
    ///
    /// let state =
    ///     AppState::with_ui_dir(Arc::new(LocalBackend::new(&storage_dir)?), &ui_dir)?;
    /// assert!(matches!(state.ui_source(), UiSource::Directory(_)));
    /// # std::fs::remove_dir_all(&storage_dir)?;
    /// # std::fs::remove_dir_all(&ui_dir)?;
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn with_ui_dir(
        backend: Arc<dyn TrackingBackend>,
        ui_dir: impl Into<PathBuf>,
    ) -> Result<Self, BackendError> {
        let ui_source = UiSource::Directory(Box::new(UiDirectory::prepare(ui_dir.into())?));
        Ok(Self { backend, ui_source })
    }

    /// Returns the backend used to answer API requests.
    pub fn backend(&self) -> &Arc<dyn TrackingBackend> {
        &self.backend
    }

    /// Returns the configured UI asset source.
    pub fn ui_source(&self) -> &UiSource {
        &self.ui_source
    }
}

/// Builds the full Axum router for the tracking server.
///
/// # Examples
///
/// ```rust
/// use std::sync::Arc;
///
/// use rurr_tracking_server::backend::local::LocalBackend;
/// use rurr_tracking_server::router::{app, AppState};
///
/// let storage_dir = std::env::temp_dir().join("rurr-tracking-server-docs-router");
/// std::fs::create_dir_all(&storage_dir)?;
/// let state = AppState::with_embedded_ui(Arc::new(LocalBackend::new(&storage_dir)?));
/// let router = app(state);
/// let _ = router.into_make_service();
/// # std::fs::remove_dir_all(&storage_dir)?;
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
pub fn app(state: AppState) -> Router {
    let api = Router::new()
        .route("/ready", get(api_ready))
        .merge(version::routes())
        .merge(annotations::routes())
        .merge(indexing_jobs::routes())
        .route("/metadata/app_spec", get(app_spec))
        .route("/projects", get(projects))
        .route("/{project_id}/{partition_key}/apps", get(apps))
        .route(
            "/{project_id}/{app_id}/{partition_key}/apps",
            get(app_detail),
        )
        .fallback(get(api_not_found));

    Router::new()
        .route("/ready", get(ready))
        .nest("/api/v0", api)
        .route("/api", get(api_not_found))
        .route("/api/{*path}", get(api_not_found))
        .route("/assets", get(ui_asset_root_not_found))
        .route("/assets/{*path}", get(ui_asset))
        .route("/", get(ui_index))
        .fallback(get(ui_index))
        .with_state(state)
}

async fn ready() -> Json<ReadyResponse> {
    Json(ReadyResponse { ready: true })
}

async fn api_ready() -> Json<bool> {
    Json(true)
}

async fn app_spec(State(state): State<AppState>) -> Result<Response, ApiError> {
    let payload = state.backend.app_spec().await?;
    Ok(Json(payload).into_response())
}

async fn projects(State(state): State<AppState>) -> Result<Response, ApiError> {
    let payload = state.backend.list_projects().await?;
    Ok(Json(payload).into_response())
}

async fn apps(
    Path((project_id, partition_key)): Path<(String, String)>,
    Query(pagination): Query<PaginationQuery>,
    State(state): State<AppState>,
) -> Result<Response, ApiError> {
    let partition = PartitionSelector::from_path_segment(&partition_key);
    let limit = pagination.limit.unwrap_or(100).min(1_000);
    let offset = pagination.offset.unwrap_or(0);
    let payload = state
        .backend
        .list_apps(
            &project_id,
            partition.as_specific_partition(),
            limit,
            offset,
        )
        .await?;
    Ok(Json(payload).into_response())
}

async fn app_detail(
    Path((project_id, app_id, partition_key)): Path<(String, String, String)>,
    State(state): State<AppState>,
) -> Result<Response, ApiError> {
    let partition = PartitionSelector::from_path_segment(&partition_key);
    let payload = state
        .backend
        .read_app(&project_id, &app_id, partition.as_specific_partition())
        .await?;
    Ok(Json(payload).into_response())
}

pub(crate) async fn api_not_found() -> Response {
    ApiError(BackendError::NotFound {
        resource: "api route".to_string(),
    })
    .into_response()
}

pub(crate) fn unsupported_feature(feature: &'static str) -> ApiError {
    ApiError(BackendError::UnsupportedFeature { feature })
}

async fn ui_index(State(state): State<AppState>) -> Result<Response, ApiError> {
    match state.ui_source() {
        UiSource::Embedded => Ok((
            [(header::CONTENT_TYPE, "text/html; charset=utf-8")],
            Body::from(ui_assets::embedded_index_html()),
        )
            .into_response()),
        UiSource::Directory(ui_directory) => Ok((
            [(header::CONTENT_TYPE, "text/html; charset=utf-8")],
            ui_directory.read_index_html()?,
        )
            .into_response()),
    }
}

async fn ui_asset_root_not_found() -> Response {
    ApiError(BackendError::NotFound {
        resource: "asset".to_string(),
    })
    .into_response()
}

async fn ui_asset(
    Path(path): Path<String>,
    State(state): State<AppState>,
) -> Result<Response, ApiError> {
    match state.ui_source() {
        UiSource::Embedded => {
            let asset = ui_assets::resolve_embedded_asset(&path)?;
            Ok((
                [(header::CONTENT_TYPE, asset.content_type)],
                Body::from(asset.bytes),
            )
                .into_response())
        }
        UiSource::Directory(ui_directory) => {
            let (content_type, bytes) = ui_directory.read_asset(&path)?;
            Ok(([(header::CONTENT_TYPE, content_type)], bytes).into_response())
        }
    }
}

#[derive(Debug)]
pub(crate) struct ApiError(pub(crate) BackendError);

impl From<BackendError> for ApiError {
    fn from(value: BackendError) -> Self {
        Self(value)
    }
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        let status = match self.0 {
            BackendError::NotFound { .. } | BackendError::UnsupportedFeature { .. } => {
                StatusCode::NOT_FOUND
            }
            BackendError::InvalidRequest { .. } | BackendError::MalformedMetadata { .. } => {
                StatusCode::BAD_REQUEST
            }
            BackendError::Configuration { .. } => StatusCode::BAD_REQUEST,
            BackendError::AnnotationExecutorClosed { .. }
            | BackendError::AnnotationExecutorPanic { .. }
            | BackendError::Io(_)
            | BackendError::SerdeJson(_)
            | BackendError::Provider { .. }
            | BackendError::Timestamp { .. }
            | BackendError::IndexingJobFinalization { .. }
            | BackendError::Sqlx(_) => StatusCode::INTERNAL_SERVER_ERROR,
        };
        let body = Json(serde_json::json!({
            "error": self.0.to_string(),
        }));
        (status, body).into_response()
    }
}
