//! Small shared runtime helpers used across `rurr-core`.

/// Async helper utilities used by runtime-adjacent code.
pub mod async_utils;
/// Copy-on-write registry helpers for process-global dispatch tables.
pub mod cow_registry;
/// Panic-safe finalization helpers for `Drop` implementations.
pub mod drop_finalizer;
/// Utilities for turning panic payloads into readable messages.
pub mod panic;
pub(crate) mod registry_result;
