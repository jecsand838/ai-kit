use quote::format_ident;
use syn::spanned::Spanned;
use syn::{FnArg, GenericArgument, Ident, Pat, PatIdent, PathArguments, Type, TypeParamBound};

#[derive(Clone)]
pub(crate) enum ParamKind {
    State,
    Context,
    User { binding_index: usize },
}

#[derive(Clone)]
pub(crate) struct InputBinding {
    pub(crate) ident: Ident,
    pub(crate) binding_ident: Ident,
    pub(crate) ty: Type,
}

pub(crate) struct SignatureModel {
    pub(crate) ordered_params: Vec<ParamKind>,
    pub(crate) input_bindings: Vec<InputBinding>,
}

pub(crate) fn analyze_signature(signature: &syn::Signature) -> syn::Result<SignatureModel> {
    let mut ordered_params = Vec::new();
    let mut input_bindings = Vec::new();
    let mut has_context_param = false;

    for (index, arg) in signature.inputs.iter().enumerate() {
        let typed = match arg {
            FnArg::Typed(typed) => typed,
            FnArg::Receiver(receiver) => {
                return Err(syn::Error::new(
                    receiver.span(),
                    "method receivers are not supported; use free functions",
                ))
            }
        };

        let pat_ident = extract_ident(&typed.pat)?;
        if pat_ident.by_ref.is_some()
            || pat_ident.mutability.is_some()
            || pat_ident.subpat.is_some()
        {
            return Err(syn::Error::new(
                pat_ident.span(),
                "only simple identifier parameters are supported",
            ));
        }

        let ident = pat_ident.ident.clone();
        let ty = (*typed.ty).clone();

        if index == 0 {
            if !is_state_reference(&ty) {
                return Err(syn::Error::new(
                    typed.span(),
                    "the first parameter must be `&State`",
                ));
            }
            ordered_params.push(ParamKind::State);
            continue;
        }

        if is_reference_to(&ty, "ActionContext") {
            if has_context_param {
                return Err(syn::Error::new(
                    typed.span(),
                    "only one `&ActionContext` parameter is supported",
                ));
            }
            has_context_param = true;
            ordered_params.push(ParamKind::Context);
            continue;
        }

        if type_is_ident(&ty, "ActionContext") {
            return Err(syn::Error::new(
                typed.span(),
                "`ActionContext` parameters must be borrowed as `&ActionContext`",
            ));
        }

        if is_reference_to(&ty, "ActionTracer") || type_is_ident(&ty, "ActionTracer") {
            return Err(syn::Error::new(
                typed.span(),
                "`ActionTracer` is not a special parameter; use `&ActionContext` and access `ctx.tracer`",
            ));
        }

        if is_reserved_runtime_input(&ident) {
            return Err(syn::Error::new(
                ident.span(),
                "user input parameters starting with `__` are reserved for runtime inputs",
            ));
        }

        let binding_index = input_bindings.len();
        input_bindings.push(InputBinding {
            binding_ident: format_ident!("__rurr_input_{}", ident),
            ident,
            ty,
        });
        ordered_params.push(ParamKind::User { binding_index });
    }

    if ordered_params.is_empty() || !matches!(ordered_params[0], ParamKind::State) {
        return Err(syn::Error::new(
            signature.span(),
            "the first parameter must be `&State`",
        ));
    }

    Ok(SignatureModel {
        ordered_params,
        input_bindings,
    })
}

pub(crate) fn type_is_ident(ty: &Type, expected: &str) -> bool {
    let Type::Path(type_path) = ty else {
        return false;
    };
    let Some(segment) = type_path.path.segments.last() else {
        return false;
    };
    segment.ident == expected
}

pub(crate) fn is_reference_to(ty: &Type, target: &str) -> bool {
    let Type::Reference(reference) = ty else {
        return false;
    };
    type_is_ident(&reference.elem, target)
}

pub(crate) fn is_box_iterator_stream_output(ty: &Type, require_owning: bool) -> bool {
    let Type::Path(type_path) = ty else {
        return false;
    };
    let Some(segment) = type_path.path.segments.last() else {
        return false;
    };
    if segment.ident != "Box" {
        return false;
    }
    let PathArguments::AngleBracketed(box_args) = &segment.arguments else {
        return false;
    };
    if box_args.args.len() != 1 {
        return false;
    }

    let Some(GenericArgument::Type(Type::TraitObject(object))) = box_args.args.first() else {
        return false;
    };

    let mut found_iterator = false;
    for bound in &object.bounds {
        match bound {
            TypeParamBound::Lifetime(lifetime) => {
                if require_owning && lifetime.ident != "static" {
                    return false;
                }
            }
            TypeParamBound::Trait(trait_bound) => {
                let Some(trait_segment) = trait_bound.path.segments.last() else {
                    return false;
                };
                if trait_segment.ident != "Iterator" {
                    continue;
                }
                let PathArguments::AngleBracketed(iterator_args) = &trait_segment.arguments else {
                    return false;
                };
                let has_item_stream_output = iterator_args.args.iter().any(|arg| {
                    matches!(
                        arg,
                        GenericArgument::AssocType(assoc)
                            if assoc.ident == "Item" && type_is_ident(&assoc.ty, "StreamOutput")
                    )
                });
                if !has_item_stream_output {
                    return false;
                }
                found_iterator = true;
            }
            _ => return false,
        }
    }

    found_iterator
}

fn extract_ident(pat: &Pat) -> syn::Result<&PatIdent> {
    match pat {
        Pat::Ident(ident) => Ok(ident),
        _ => Err(syn::Error::new(
            pat.span(),
            "only identifier parameters are supported",
        )),
    }
}

fn is_state_reference(ty: &Type) -> bool {
    is_reference_to(ty, "State")
}

fn is_reserved_runtime_input(ident: &Ident) -> bool {
    ident.to_string().starts_with("__")
}
