//! Docker-backed live-service helpers used by strict workspace tests.
//!
//! The helpers in this module validate real local services started by
//! `./scripts/dev_up.sh`, build unique live-test resource names, and read raw
//! OTEL collector file-export JSONL for assertions. They are intentionally
//! opt-in through [`CHECK_LIVE_ENV`] so ordinary unit and doctest runs remain
//! local and deterministic.
//!
//! Provider-specific implementations live in private child modules so the
//! public testkit surface stays small while live proof logic remains grouped by
//! service.

mod common;
mod mongodb;
mod otel;
mod postgres;
mod redis;
mod s3;

pub use common::{
    check_live_tests_enabled, live_service_error_to_persistence, openai_live_tests_enabled,
    unique_live_suffix, LiveServiceError, CHECK_LIVE_ENV, OPENAI_LIVE_ENV,
};
pub use mongodb::{
    drop_mongodb_collection_sync, mongodb_uri_from_env, ready_mongodb_uri_sync,
    unique_mongodb_collection_name, wait_for_mongodb_ready_sync,
};
pub use otel::{
    otel_array_any_values, otel_attribute_value, otel_bool_any_value, otel_double_any_value,
    otel_int_any_value, otel_log_attribute, otel_resource_attribute_value, otel_span_attribute,
    otel_string_any_value, raw_otel_log_records, raw_otel_trace_spans, read_otel_log_exports,
    read_otel_trace_exports, reset_otel_file_exports, wait_for_raw_otel_exports, RawOtelLogRecord,
    RawOtelTraceSpan,
};
pub use postgres::{
    drop_postgres_table, drop_postgres_table_sync, postgres_url_from_env, ready_postgres_url,
    ready_postgres_url_sync, unique_postgres_table_name, wait_for_postgres_ready,
    wait_for_postgres_ready_sync,
};
pub use redis::{
    cleanup_redis_namespace_async, cleanup_redis_namespace_sync, redis_url_from_env,
    unique_redis_namespace, wait_for_redis_ready, wait_for_redis_ready_sync,
};
pub use s3::{S3ArtifactProbe, S3LiveBucketScenario, S3LiveHarness};
