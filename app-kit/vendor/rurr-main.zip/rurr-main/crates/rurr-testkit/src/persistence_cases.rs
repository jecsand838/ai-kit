//! Shared persistence contract helpers used by backend integration tests.
//!
//! The traits in this module let one suite exercise sync and async persistence
//! backends through a common set of scenarios while keeping backend-specific
//! setup and cleanup logic in small lane implementations.

use async_trait::async_trait;
use futures::{future::LocalBoxFuture, Future, FutureExt};
use indexmap::IndexMap;
use rurr_core::action::Condition;
use rurr_core::application::{Application, ApplicationBuilder, StepOutput};
use rurr_core::common::panic::panic_payload_to_string;
use rurr_core::graph::Transition;
use rurr_core::ParentPointer;
use rurr_persistence::{
    ApplicationPersistenceSpec, AsyncBaseStatePersister, BaseStatePersister, PersistedStateData,
    PersistedStateStatus, PersistenceError, PersistenceLoadTarget,
};
use serde_json::{json, Value};
use std::panic::AssertUnwindSafe;
use std::sync::Arc;
use std::task::{Context, Poll, Wake, Waker};

use crate::application_fixture::{async_counter_action, counter_action};

/// Canonical state map type used by persistence contract fixtures.
pub type PersistenceStateMap = IndexMap<String, Value>;

/// Builds a [`PersistenceStateMap`] from a fixed array of key/value pairs.
pub fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> PersistenceStateMap {
    pairs
        .into_iter()
        .map(|(key, value)| (key.to_string(), value))
        .collect()
}

// Shared persistence scenarios normalize sync backends into async functions.
// Sync adapters must only use this for futures that are immediately ready.
/// Polls a fixture future once and returns its output, panicking if it yields `Pending`.
pub fn run_sync_case<T>(future: impl Future<Output = T>) -> T {
    struct NoopWake;

    impl Wake for NoopWake {
        fn wake(self: Arc<Self>) {}
    }

    let waker = Waker::from(Arc::new(NoopWake));
    let mut future = Box::pin(future);
    let mut cx = Context::from_waker(&waker);

    match future.as_mut().poll(&mut cx) {
        Poll::Ready(output) => output,
        Poll::Pending => panic!("sync persistence test future unexpectedly yielded pending"),
    }
}

/// Runs a synchronous test-only operation on a dedicated OS thread.
///
/// This is the sanctioned bridge for sync-only test APIs that must be exercised
/// from async integration tests without using runtime `block_on` bridges.
pub fn run_sync_on_thread<T>(operation: impl FnOnce() -> T + Send + 'static) -> T
where
    T: Send + 'static,
{
    std::thread::spawn(operation)
        .join()
        .expect("sync test thread should not panic")
}

/// Base contract implemented by persistence test lanes.
#[async_trait(?Send)]
pub trait PersistenceLane {
    /// Returns the expected app-id ordering for the empty-partition fixture.
    fn expected_none_partition_app_ids(&self) -> Vec<String> {
        vec!["app_id_none_2".to_string(), "app_id_none".to_string()]
    }

    /// Initializes the backend under test.
    async fn initialize(&self) -> Result<(), PersistenceError>;
    /// Returns whether the backend reports itself as initialized.
    async fn is_initialized(&self) -> Result<bool, PersistenceError>;
    /// Cleans up backend state created by the lane.
    async fn cleanup(&self) -> Result<(), PersistenceError>;
    /// Persists a single state record.
    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError>;
    /// Loads a persisted state record using the lane's backend-specific semantics.
    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError>;
    /// Lists application ids visible in the provided partition.
    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError>;
}

/// Shared persistence contract case builder.
///
/// The builder carries the common partition/app coordinates used by the shared
/// contract scenarios and delegates all behavior to the lane under test.
struct PersistenceCaseBuilder<'a, L>
where
    L: PersistenceLane + ?Sized,
{
    lane: &'a L,
    partition_key: Option<&'a str>,
    app_id: &'a str,
}

impl<'a, L> PersistenceCaseBuilder<'a, L>
where
    L: PersistenceLane + ?Sized,
{
    fn new(lane: &'a L) -> Self {
        Self {
            lane,
            partition_key: Some("partition"),
            app_id: "app_id",
        }
    }

    fn with_partition_key(mut self, partition_key: Option<&'a str>) -> Self {
        self.partition_key = partition_key;
        self
    }

    fn with_app_id(mut self, app_id: &'a str) -> Self {
        self.app_id = app_id;
        self
    }

    async fn save_sequence(
        &self,
        sequence_id: u64,
        position: &str,
        state: PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.save_app_sequence(self.app_id, sequence_id, position, state, status)
            .await
    }

    async fn save_app_sequence(
        &self,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.lane
            .save(
                self.partition_key,
                app_id,
                sequence_id,
                position,
                state,
                status,
            )
            .await
    }

    async fn latest_partition(
        &self,
        missing_message: &'static str,
    ) -> Result<PersistedStateData, PersistenceError> {
        Ok(self
            .load_optional(None, None)
            .await?
            .expect(missing_message))
    }

    async fn latest_app(
        &self,
        missing_message: &'static str,
    ) -> Result<PersistedStateData, PersistenceError> {
        self.latest_app_for(self.app_id, missing_message).await
    }

    async fn latest_app_optional(&self) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.load_optional(Some(self.app_id), None).await
    }

    async fn latest_app_for(
        &self,
        app_id: &str,
        missing_message: &'static str,
    ) -> Result<PersistedStateData, PersistenceError> {
        Ok(self
            .load_optional(Some(app_id), None)
            .await?
            .expect(missing_message))
    }

    async fn exact_sequence(
        &self,
        sequence_id: u64,
        missing_message: &'static str,
    ) -> Result<PersistedStateData, PersistenceError> {
        self.exact_app_sequence(self.app_id, sequence_id, missing_message)
            .await
    }

    async fn exact_app_sequence(
        &self,
        app_id: &str,
        sequence_id: u64,
        missing_message: &'static str,
    ) -> Result<PersistedStateData, PersistenceError> {
        Ok(self
            .load_optional(Some(app_id), Some(sequence_id))
            .await?
            .expect(missing_message))
    }

    async fn load_optional(
        &self,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.lane
            .load(self.partition_key, app_id, sequence_id)
            .await
    }

    async fn list_app_ids(&self) -> Result<Vec<String>, PersistenceError> {
        self.lane.list_app_ids(self.partition_key).await
    }
}

/// Extension lane for backends that can seed deterministic ordering fixtures.
#[async_trait(?Send)]
pub trait PersistenceOrderingLane: PersistenceLane {
    /// Seeds records used to test latest-partition ordering.
    async fn seed_latest_partition_order_fixture(&self) -> Result<(), PersistenceError>;
    /// Seeds records used to test exact-sequence ordering.
    async fn seed_exact_sequence_order_fixture(&self) -> Result<(), PersistenceError>;
    /// Seeds records used to test `list_app_ids` ordering and returns the expected result.
    async fn seed_list_app_ids_order_fixture(&self) -> Result<Vec<String>, PersistenceError>;
}

/// Extension lane for backends that must observe out-of-band initialize/drop events.
#[async_trait(?Send)]
pub trait PersistenceReprobeLane: PersistenceLane {
    /// Initializes the backend from outside the lane's normal control flow.
    async fn external_initialize(&self) -> Result<(), PersistenceError>;
    /// Drops or invalidates the backend storage out of band.
    async fn drop_storage(&self);

    /// Asserts any backend-specific invariants after storage has been dropped.
    async fn assert_post_drop_invariants(&self) {}
}

/// Extension lane for backends that can rebuild themselves from serialized config.
#[async_trait(?Send)]
pub trait PersistenceConfigLane: PersistenceLane + Sized {
    /// Reconstructs a fresh lane instance from the backend's config surface.
    async fn rebuild_from_config(&self) -> Result<Self, PersistenceError>;
}

/// Runs the shared non-application persistence contract suite for one lane family.
pub async fn run_persistence_config_contract_suite<L, MakeLane>(
    make_lane: &MakeLane,
    include_cold_lane: bool,
) where
    L: PersistenceLane + PersistenceConfigLane,
    MakeLane: for<'a> Fn(&'a str) -> LocalBoxFuture<'a, L>,
{
    if include_cold_lane {
        let cold_lane = make_lane("cold").await;
        not_initialized_for_load_save_and_list(&cold_lane).await;
    }

    run_made_lane_result_case(
        make_lane,
        "roundtrip",
        |lane| latest_partition_latest_app_exact_and_list(lane).boxed_local(),
        "roundtrip assertions should succeed",
    )
    .await;
    run_made_lane_result_case(
        make_lane,
        "none_partition",
        |lane| none_partition_key_roundtrip(lane).boxed_local(),
        "none-partition assertions should succeed",
    )
    .await;
    run_made_lane_result_case(
        make_lane,
        "sequence_without_app",
        |lane| load_with_sequence_id_and_no_app_id_returns_none(lane).boxed_local(),
        "missing-app-id assertions should succeed",
    )
    .await;
    run_made_lane_result_case(
        make_lane,
        "config_roundtrip",
        |lane| config_roundtrip_rebuilds_persister_and_loads_saved_state(lane).boxed_local(),
        "config roundtrip assertions should succeed",
    )
    .await;
}

/// Runs the facade-specific persistence-spec resume/fork smoke suite for one lane family.
pub async fn run_persistence_spec_smoke_suite<L, MakeLane, BuildApp, StepApp>(
    make_lane: &MakeLane,
    build_app: BuildApp,
    step_app: StepApp,
) where
    L: PersistenceLane,
    MakeLane: for<'a> Fn(&'a str) -> LocalBoxFuture<'a, L>,
    BuildApp: for<'a> Fn(
        &'a L,
        &'a str,
        Option<String>,
        Option<PersistenceLoadTarget>,
    ) -> LocalBoxFuture<'a, Application>,
    StepApp: for<'a> Fn(&'a L, &'a mut Application) -> LocalBoxFuture<'a, StepOutput>,
{
    let resume_lane = make_lane("resume").await;
    persistence_spec_resume_path_smoke(&resume_lane, &build_app, &step_app)
        .await
        .expect("resume assertions should succeed");

    let fork_lane = make_lane("fork").await;
    persistence_spec_fork_smoke(&fork_lane, &build_app, &step_app)
        .await
        .expect("fork assertions should succeed");
}

async fn run_made_lane_result_case<L, MakeLane, F>(
    make_lane: &MakeLane,
    name: &str,
    case: F,
    expectation: &'static str,
) where
    L: PersistenceLane,
    MakeLane: for<'a> Fn(&'a str) -> LocalBoxFuture<'a, L>,
    F: for<'a> FnOnce(&'a L) -> LocalBoxFuture<'a, Result<(), PersistenceError>>,
{
    let lane = make_lane(name).await;
    case(&lane).await.expect(expectation);
}

fn counter_graph_builder(
    start_action: rurr_core::action::FunctionAction,
    finish_action: rurr_core::action::FunctionAction,
) -> ApplicationBuilder {
    ApplicationBuilder::new()
        .with_actions(vec![("start", start_action), ("finish", finish_action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "start",
            "finish",
            Condition::default(),
        )])
        .expect("transitions should configure")
}

/// Builds the shared sync resume smoke application used by facade persistence tests.
pub fn build_sync_resume_counter_future<'a, P: BaseStatePersister + 'static>(
    persister: Arc<P>,
    app_id: &'a str,
    partition_key: Option<String>,
    load_target: Option<PersistenceLoadTarget>,
) -> LocalBoxFuture<'a, Application> {
    Box::pin(async move {
        let persister: Arc<dyn BaseStatePersister> = persister;
        counter_graph_builder(counter_action(), counter_action())
            .with_identifiers(app_id, partition_key, None)
            .expect("identifiers should configure")
            .with_persistence_spec(ApplicationPersistenceSpec::sync_resume(
                persister,
                true,
                map_from_pairs([("count", json!(0))]),
                "start",
                None,
                load_target,
            ))
            .expect("sync persistence spec should configure")
            .build()
            .expect("sync build should succeed")
    })
}

/// Builds the shared async resume smoke application used by facade persistence tests.
pub fn build_async_resume_counter_future<'a, P: AsyncBaseStatePersister + 'static>(
    persister: Arc<P>,
    app_id: &'a str,
    partition_key: Option<String>,
    load_target: Option<PersistenceLoadTarget>,
) -> LocalBoxFuture<'a, Application> {
    Box::pin(async move {
        let persister: Arc<dyn AsyncBaseStatePersister> = persister;
        counter_graph_builder(async_counter_action(), async_counter_action())
            .with_identifiers(app_id, partition_key, None)
            .expect("identifiers should configure")
            .with_persistence_spec(ApplicationPersistenceSpec::async_resume(
                persister,
                true,
                map_from_pairs([("count", json!(0))]),
                "start",
                None,
                load_target,
            ))
            .expect("async persistence spec should configure")
            .abuild()
            .await
            .expect("async build should succeed")
    })
}

/// Steps the shared sync smoke application once.
pub fn step_sync_counter_app<'a, L>(
    _: &'a L,
    app: &'a mut Application,
) -> LocalBoxFuture<'a, StepOutput> {
    Box::pin(async move {
        app.step(None)
            .expect("sync step should succeed")
            .expect("sync step should execute")
    })
}

/// Steps the shared async smoke application once.
pub fn step_async_counter_app<'a, L>(
    _: &'a L,
    app: &'a mut Application,
) -> LocalBoxFuture<'a, StepOutput> {
    Box::pin(async move {
        app.astep(None)
            .await
            .expect("async step should succeed")
            .expect("async step should execute")
    })
}

/// Runs a persistence test future and always invokes `lane.cleanup()` afterward.
///
/// If the future panics, cleanup still runs before the panic is resumed.
pub async fn run_with_cleanup<L, F>(lane: &L, future: F) -> Result<(), PersistenceError>
where
    L: PersistenceLane,
    F: Future<Output = Result<(), PersistenceError>>,
{
    let result = AssertUnwindSafe(future).catch_unwind().await;
    let cleanup_result = lane.cleanup().await;

    match result {
        Ok(Ok(())) => cleanup_result,
        Ok(Err(body_error)) => match cleanup_result {
            Ok(()) => Err(body_error),
            Err(cleanup_error) => panic!(
                "persistence test body failed and cleanup also failed: body_error={body_error}; cleanup_error={cleanup_error}"
            ),
        },
        Err(payload) => match cleanup_result {
            Ok(()) => std::panic::resume_unwind(payload),
            Err(cleanup_error) => panic!(
                "lane cleanup should succeed after test panic: body_panic={}; cleanup_error={cleanup_error}",
                panic_payload_to_string(payload),
            ),
        },
    }
}

/// Runs a cleanup finalizer after all cleanup attempts have been evaluated.
///
/// The finalizer always runs, even if one or more cleanup steps failed. After the
/// finalizer completes, the first cleanup error is returned.
pub async fn finalize_cleanup_results<I, F>(
    cleanup_results: I,
    finalizer: F,
) -> Result<(), PersistenceError>
where
    I: IntoIterator<Item = Result<(), PersistenceError>>,
    F: Future<Output = Result<(), PersistenceError>>,
{
    let first_error = cleanup_results.into_iter().find_map(Result::err);
    let finalizer_result = finalizer.await;
    match first_error {
        Some(error) => Err(error),
        None => finalizer_result,
    }
}

async fn run_case<L, F>(lane: &L, case: F) -> Result<(), PersistenceError>
where
    L: PersistenceLane,
    F: for<'a> FnOnce(&'a L) -> LocalBoxFuture<'a, Result<(), PersistenceError>>,
{
    run_with_cleanup(lane, case(lane)).await
}

async fn run_initialized_case<L, F>(lane: &L, case: F) -> Result<(), PersistenceError>
where
    L: PersistenceLane,
    F: for<'a> FnOnce(&'a L) -> LocalBoxFuture<'a, Result<(), PersistenceError>> + 'static,
{
    run_case(lane, |lane| {
        Box::pin(async move {
            lane.initialize().await?;
            case(lane).await
        })
    })
    .await
}

/// Verifies that initialize, is-initialized, and cleanup remain explicit backend operations.
pub async fn initialize_is_initialized_and_cleanup_are_explicit<L: PersistenceLane>(
    lane: &L,
    assert_cleanup_error: impl Fn(PersistenceError),
) -> Result<(), PersistenceError> {
    run_with_cleanup(lane, async {
        assert!(!lane
            .is_initialized()
            .await
            .expect("is_initialized should work before initialize"));

        lane.initialize().await?;
        assert!(lane
            .is_initialized()
            .await
            .expect("is_initialized should work after initialize"));

        Ok(())
    })
    .await?;

    let error = PersistenceCaseBuilder::new(lane)
        .latest_app_optional()
        .await
        .expect_err("load should fail after cleanup");
    assert_cleanup_error(error);

    Ok(())
}

/// Verifies latest-partition, latest-app, exact-load, and list-app-id behavior together.
pub async fn latest_partition_latest_app_exact_and_list<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, move |lane| {
        Box::pin(async move {
            let case = PersistenceCaseBuilder::new(lane);

            case.save_app_sequence(
                "app_a",
                1,
                "position_1",
                map_from_pairs([("value", json!("v1"))]),
                PersistedStateStatus::Completed,
            )
            .await?;
            case.save_app_sequence(
                "app_b",
                2,
                "position_2",
                map_from_pairs([("value", json!("v2"))]),
                PersistedStateStatus::Completed,
            )
            .await?;
            case.save_app_sequence(
                "app_a",
                3,
                "position_3",
                map_from_pairs([("value", json!("v3"))]),
                PersistedStateStatus::Failed,
            )
            .await?;

            let latest_partition = case
                .latest_partition("latest partition state should exist")
                .await?;
            let latest_app = case
                .latest_app_for("app_a", "latest app state should exist")
                .await?;
            let exact = case
                .exact_app_sequence("app_a", 1, "exact state should exist")
                .await?;
            let missing = case.load_optional(None, Some(1)).await?;
            let app_ids = case.list_app_ids().await?;

            assert_eq!(latest_partition.app_id, "app_a");
            assert_eq!(latest_partition.sequence_id, 3);
            assert_eq!(latest_partition.position.as_deref(), Some("position_3"));
            assert_eq!(latest_partition.status, PersistedStateStatus::Failed);
            assert_eq!(latest_app.sequence_id, 3);
            assert_eq!(latest_app.position.as_deref(), Some("position_3"));
            assert_eq!(latest_app.status, PersistedStateStatus::Failed);
            assert_eq!(exact.sequence_id, 1);
            assert_eq!(exact.position.as_deref(), Some("position_1"));
            assert_eq!(exact.state, Some(map_from_pairs([("value", json!("v1"))])));
            assert!(missing.is_none());
            assert_eq!(app_ids, vec!["app_a".to_string(), "app_b".to_string()]);

            Ok(())
        })
    })
    .await
}

/// Verifies that duplicate identity tuples are rejected without overwriting stored records.
pub async fn duplicate_identity_behavior<L: PersistenceLane>(
    lane: &L,
    duplicate_error_operation: &'static str,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, move |lane| {
        Box::pin(async move {
            let case = PersistenceCaseBuilder::new(lane);

            case.save_sequence(
                7,
                "position_a",
                map_from_pairs([("marker", json!("first"))]),
                PersistedStateStatus::Completed,
            )
            .await?;
            case.save_sequence(
                7,
                "position_b",
                map_from_pairs([("marker", json!("second"))]),
                PersistedStateStatus::Failed,
            )
            .await?;

            let duplicate_error = case
                .save_sequence(
                    7,
                    "position_b",
                    map_from_pairs([("marker", json!("duplicate"))]),
                    PersistedStateStatus::Completed,
                )
                .await
                .expect_err("exact duplicate tuple should fail");
            assert!(matches!(
                duplicate_error,
                PersistenceError::UnsupportedOperation { operation }
                    if operation == duplicate_error_operation
            ));

            let latest = case.latest_app("latest app state should exist").await?;
            let exact = case.exact_sequence(7, "exact state should exist").await?;

            assert_eq!(latest.sequence_id, 7);
            assert_eq!(latest.position.as_deref(), Some("position_b"));
            assert_eq!(
                latest.state,
                Some(map_from_pairs([("marker", json!("second"))]))
            );
            assert_eq!(latest.status, PersistedStateStatus::Failed);
            assert_eq!(exact.sequence_id, 7);
            assert_eq!(exact.position.as_deref(), Some("position_b"));
            assert_eq!(
                exact.state,
                Some(map_from_pairs([("marker", json!("second"))]))
            );
            assert_eq!(exact.status, PersistedStateStatus::Failed);

            Ok(())
        })
    })
    .await
}

/// Verifies that loading a missing record returns `None`.
pub async fn missing_load_returns_none<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, |lane| {
        Box::pin(async move {
            let loaded = PersistenceCaseBuilder::new(lane)
                .with_app_id("missing_app_id")
                .latest_app_optional()
                .await?;
            assert!(loaded.is_none());
            Ok(())
        })
    })
    .await
}

/// Verifies round-tripping records stored under the empty partition-key bucket.
pub async fn none_partition_key_roundtrip<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, |lane| {
        Box::pin(async move {
            let case = PersistenceCaseBuilder::new(lane).with_partition_key(None);

            case.save_app_sequence(
                "app_id_none",
                1,
                "position_1",
                map_from_pairs([("foo", json!("bar"))]),
                PersistedStateStatus::Failed,
            )
            .await?;
            case.save_app_sequence(
                "app_id_none_2",
                2,
                "position_2",
                map_from_pairs([("hello", json!("world"))]),
                PersistedStateStatus::Completed,
            )
            .await?;

            let loaded_first = case
                .exact_app_sequence("app_id_none", 1, "first state should exist")
                .await?;
            let loaded_second = case
                .exact_app_sequence("app_id_none_2", 2, "second state should exist")
                .await?;
            let app_ids = case.list_app_ids().await?;

            assert_eq!(loaded_first.partition_key.as_deref(), Some(""));
            assert_eq!(
                loaded_first.state,
                Some(map_from_pairs([("foo", json!("bar"))]))
            );
            assert_eq!(loaded_first.status, PersistedStateStatus::Failed);
            assert_eq!(loaded_second.partition_key.as_deref(), Some(""));
            assert_eq!(
                loaded_second.state,
                Some(map_from_pairs([("hello", json!("world"))]))
            );
            assert_eq!(loaded_second.status, PersistedStateStatus::Completed);
            assert_eq!(app_ids, lane.expected_none_partition_app_ids());

            Ok(())
        })
    })
    .await
}

/// Verifies that load, save, and list fail before the backend is initialized.
pub async fn not_initialized_for_load_save_and_list<L: PersistenceLane>(lane: &L) {
    let case = PersistenceCaseBuilder::new(lane);
    let load_error = case
        .load_optional(Some("app_id"), None)
        .await
        .expect_err("load should fail before initialize");
    let save_error = case
        .save_sequence(
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect_err("save should fail before initialize");
    let list_error = case
        .list_app_ids()
        .await
        .expect_err("list_app_ids should fail before initialize");

    assert!(matches!(load_error, PersistenceError::NotInitialized));
    assert!(matches!(save_error, PersistenceError::NotInitialized));
    assert!(matches!(list_error, PersistenceError::NotInitialized));

    let _ = lane.cleanup().await;
}

/// Verifies that `load` ignores `sequence_id` when no `app_id` is provided.
pub async fn load_with_sequence_id_and_no_app_id_returns_none<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, |lane| {
        Box::pin(async move {
            let case = PersistenceCaseBuilder::new(lane);

            case.save_app_sequence(
                "app_id_1",
                1,
                "position_1",
                map_from_pairs([("key", json!("value_1"))]),
                PersistedStateStatus::Completed,
            )
            .await?;
            case.save_app_sequence(
                "app_id_2",
                2,
                "position_2",
                map_from_pairs([("key", json!("value_2"))]),
                PersistedStateStatus::Completed,
            )
            .await?;

            let loaded = case.load_optional(None, Some(1)).await?;
            assert!(
                loaded.is_none(),
                "load with sequence_id but no app_id must not return any record"
            );

            Ok(())
        })
    })
    .await
}

/// Verifies that one lane instance can re-probe backend initialization after external changes.
pub async fn same_instance_reprobes_after_external_initialize_and_recreate<
    L: PersistenceReprobeLane,
>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_case(lane, |lane| {
        Box::pin(async move {
            let case = PersistenceCaseBuilder::new(lane);

            assert!(!lane.is_initialized().await?);

            lane.external_initialize().await?;
            case.save_sequence(
                1,
                "position_1",
                map_from_pairs([("key", json!("value_1"))]),
                PersistedStateStatus::Completed,
            )
            .await?;

            let loaded_after_initialize = case
                .exact_sequence(1, "state should exist after external initialize")
                .await?;
            assert_eq!(
                loaded_after_initialize.state,
                Some(map_from_pairs([("key", json!("value_1"))]))
            );

            lane.drop_storage().await;

            let error = case
                .load_optional(Some("app_id"), None)
                .await
                .expect_err("load should fail after external drop");
            assert!(matches!(error, PersistenceError::NotInitialized));
            lane.assert_post_drop_invariants().await;

            lane.external_initialize().await?;
            case.save_sequence(
                2,
                "position_2",
                map_from_pairs([("key", json!("value_2"))]),
                PersistedStateStatus::Completed,
            )
            .await?;

            let loaded_after_recreate = case
                .exact_sequence(2, "state should exist after external recreate")
                .await?;
            assert_eq!(
                loaded_after_recreate.state,
                Some(map_from_pairs([("key", json!("value_2"))]))
            );

            Ok(())
        })
    })
    .await
}

/// Verifies latest-partition selection prefers the newest `created_at` record.
pub async fn latest_partition_prefers_newest_created_at<L: PersistenceOrderingLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, |lane| {
        Box::pin(async move {
            lane.seed_latest_partition_order_fixture().await?;

            let loaded = PersistenceCaseBuilder::new(lane)
                .latest_partition("state should exist")
                .await?;

            assert_eq!(loaded.app_id, "newer_created_at_lower_seq");
            assert_eq!(loaded.sequence_id, 1);
            assert_eq!(loaded.position.as_deref(), Some("step_new"));
            assert_eq!(
                loaded.state,
                Some(map_from_pairs([("marker", json!("new"))]))
            );

            Ok(())
        })
    })
    .await
}

/// Verifies exact-sequence selection prefers newer `created_at` and then higher position.
pub async fn exact_sequence_prefers_latest_created_at_then_position<L: PersistenceOrderingLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, |lane| {
        Box::pin(async move {
            lane.seed_exact_sequence_order_fixture().await?;

            let loaded = PersistenceCaseBuilder::new(lane)
                .exact_sequence(7, "state should exist")
                .await?;

            assert_eq!(loaded.sequence_id, 7);
            assert_eq!(loaded.position.as_deref(), Some("step_b"));
            assert_eq!(
                loaded.state,
                Some(map_from_pairs([("marker", json!("newer_high_position"))]))
            );

            Ok(())
        })
    })
    .await
}

/// Verifies that `list_app_ids` returns the backend's deterministic ordering.
pub async fn list_app_ids_order<L: PersistenceOrderingLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, |lane| {
        Box::pin(async move {
            let expected = lane.seed_list_app_ids_order_fixture().await?;
            let app_ids = PersistenceCaseBuilder::new(lane).list_app_ids().await?;
            assert_eq!(app_ids, expected);
            Ok(())
        })
    })
    .await
}

/// Verifies config round-tripping rebuilds the backend and preserves saved state.
pub async fn config_roundtrip_rebuilds_persister_and_loads_saved_state<L: PersistenceConfigLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, |lane| {
        Box::pin(async move {
            let case = PersistenceCaseBuilder::new(lane);

            case.save_sequence(
                7,
                "position",
                map_from_pairs([("chat_history", json!([1, 2]))]),
                PersistedStateStatus::Completed,
            )
            .await?;

            let rebuilt = lane.rebuild_from_config().await?;
            let loaded = PersistenceCaseBuilder::new(&rebuilt)
                .exact_sequence(7, "state should exist")
                .await?;

            assert_eq!(loaded.app_id, "app_id");
            assert_eq!(loaded.sequence_id, 7);
            assert_eq!(
                loaded.state,
                Some(map_from_pairs([("chat_history", json!([1, 2]))]))
            );

            rebuilt.cleanup().await?;
            Ok(())
        })
    })
    .await
}

/// Verifies that backends can persist the full `u64` sequence-id range.
pub async fn save_accepts_large_u64_sequence_id<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    run_initialized_case(lane, |lane| {
        Box::pin(async move {
            let sequence_id = u64::MAX;
            let case = PersistenceCaseBuilder::new(lane);

            case.save_sequence(
                sequence_id,
                "position",
                map_from_pairs([("key", json!("value"))]),
                PersistedStateStatus::Completed,
            )
            .await?;

            let loaded = case.latest_app("state should exist").await?;
            assert_eq!(loaded.sequence_id, sequence_id);

            Ok(())
        })
    })
    .await
}

/// Verifies the persistence-spec resume path reloads state and resumes from the next action.
pub async fn persistence_spec_resume_path_smoke<L, BuildApp, StepApp>(
    lane: &L,
    build_app: BuildApp,
    step_app: StepApp,
) -> Result<(), PersistenceError>
where
    L: PersistenceLane,
    BuildApp: for<'a> Fn(
        &'a L,
        &'a str,
        Option<String>,
        Option<PersistenceLoadTarget>,
    ) -> LocalBoxFuture<'a, Application>,
    StepApp: for<'a> Fn(&'a L, &'a mut Application) -> LocalBoxFuture<'a, StepOutput>,
{
    run_with_cleanup(lane, async {
        lane.initialize().await?;

        let mut first_app = build_app(lane, "resume-app", Some("tenant".to_string()), None).await;
        let first_step = step_app(lane, &mut first_app).await;

        let mut resumed_app = build_app(lane, "resume-app", Some("tenant".to_string()), None).await;
        let resumed_count = resumed_app.state().get("count").cloned();
        let resumed_sequence = resumed_app.state().get("__SEQUENCE_ID").cloned();
        let resumed_prior_step = resumed_app.state().get("__PRIOR_STEP").cloned();

        let resumed_step = step_app(lane, &mut resumed_app).await;

        assert_eq!(first_step.action.name(), "start");
        assert_eq!(first_step.state.get("count"), Some(&json!(1)));
        assert_eq!(resumed_count, Some(json!(1)));
        assert_eq!(resumed_sequence, Some(json!(0)));
        assert_eq!(resumed_prior_step, Some(json!("start")));
        assert_eq!(resumed_step.action.name(), "finish");

        Ok(())
    })
    .await
}

/// Verifies persistence-spec forking preserves target ids and parent-pointer metadata.
pub async fn persistence_spec_fork_smoke<L, BuildApp, StepApp>(
    lane: &L,
    build_app: BuildApp,
    step_app: StepApp,
) -> Result<(), PersistenceError>
where
    L: PersistenceLane,
    BuildApp: for<'a> Fn(
        &'a L,
        &'a str,
        Option<String>,
        Option<PersistenceLoadTarget>,
    ) -> LocalBoxFuture<'a, Application>,
    StepApp: for<'a> Fn(&'a L, &'a mut Application) -> LocalBoxFuture<'a, StepOutput>,
{
    run_with_cleanup(lane, async {
        lane.initialize().await?;
        let source_case = PersistenceCaseBuilder::new(lane)
            .with_partition_key(Some("tenant"))
            .with_app_id("source-app");

        source_case
            .save_sequence(
                0,
                "start",
                map_from_pairs([("count", json!(1))]),
                PersistedStateStatus::Completed,
            )
            .await?;
        source_case
            .save_sequence(
                1,
                "finish",
                map_from_pairs([("count", json!(2))]),
                PersistedStateStatus::Completed,
            )
            .await?;

        let mut forked_app = build_app(
            lane,
            "fork-app",
            Some("tenant".to_string()),
            Some(PersistenceLoadTarget::new(
                "source-app",
                Some("tenant".to_string()),
                Some(0),
            )),
        )
        .await;

        let forked_step = step_app(lane, &mut forked_app).await;
        let target_record = PersistenceCaseBuilder::new(lane)
            .with_partition_key(Some("tenant"))
            .with_app_id("fork-app")
            .exact_sequence(1, "target record should exist")
            .await?;
        let source_record = source_case
            .exact_sequence(1, "source record should exist")
            .await?;

        assert_eq!(
            forked_app.parent_pointer(),
            Some(&ParentPointer {
                app_id: "source-app".to_string(),
                partition_key: Some("tenant".to_string()),
                sequence_id: Some(0),
            })
        );
        assert_eq!(forked_app.uid(), "fork-app");
        assert_eq!(forked_app.partition_key(), Some("tenant"));
        assert_eq!(forked_step.action.name(), "finish");
        assert_eq!(target_record.app_id, "fork-app");
        assert_eq!(target_record.sequence_id, 1);
        assert_eq!(
            target_record
                .state
                .as_ref()
                .and_then(|state| state.get("count")),
            Some(&json!(2))
        );
        assert_eq!(source_record.app_id, "source-app");

        Ok(())
    })
    .await
}

#[cfg(test)]
mod tests {
    use super::{
        build_async_resume_counter_future, build_sync_resume_counter_future,
        finalize_cleanup_results, initialize_is_initialized_and_cleanup_are_explicit,
        run_persistence_spec_smoke_suite, run_sync_case, step_async_counter_app,
        step_sync_counter_app, PersistenceLane,
    };
    use async_trait::async_trait;
    use futures::future::LocalBoxFuture;
    use rurr_persistence::{
        AsyncBaseStateLoader, AsyncBaseStateSaver, AsyncInMemoryPersister, BaseStateLoader,
        BaseStateSaver, InMemoryPersister, PersistenceError,
    };
    use std::panic::AssertUnwindSafe;
    use std::sync::{
        atomic::{AtomicBool, AtomicUsize, Ordering},
        Arc,
    };

    struct PanicCleanupLane {
        cleanup_count: AtomicUsize,
        initialized: AtomicBool,
    }

    #[async_trait(?Send)]
    impl super::PersistenceLane for PanicCleanupLane {
        async fn initialize(&self) -> Result<(), PersistenceError> {
            self.initialized.store(true, Ordering::SeqCst);
            Ok(())
        }

        async fn is_initialized(&self) -> Result<bool, PersistenceError> {
            Ok(false)
        }

        async fn cleanup(&self) -> Result<(), PersistenceError> {
            self.initialized.store(false, Ordering::SeqCst);
            self.cleanup_count.fetch_add(1, Ordering::SeqCst);
            Ok(())
        }

        async fn save(
            &self,
            _partition_key: Option<&str>,
            _app_id: &str,
            _sequence_id: u64,
            _position: &str,
            _state: super::PersistenceStateMap,
            _status: rurr_persistence::PersistedStateStatus,
        ) -> Result<(), PersistenceError> {
            Ok(())
        }

        async fn load(
            &self,
            _partition_key: Option<&str>,
            _app_id: Option<&str>,
            _sequence_id: Option<u64>,
        ) -> Result<Option<rurr_persistence::PersistedStateData>, PersistenceError> {
            Err(PersistenceError::NotInitialized)
        }

        async fn list_app_ids(
            &self,
            _partition_key: Option<&str>,
        ) -> Result<Vec<String>, PersistenceError> {
            Ok(Vec::new())
        }
    }

    #[test]
    fn finalize_cleanup_results_runs_finalizer_before_returning_first_error() {
        let finalized = Arc::new(AtomicBool::new(false));
        let finalized_for_future = finalized.clone();

        let result = run_sync_case(finalize_cleanup_results(
            [
                Err(PersistenceError::BackendOperationFailed {
                    operation: "sync_cleanup",
                    message: "sync cleanup failed".to_string(),
                }),
                Err(PersistenceError::BackendOperationFailed {
                    operation: "async_close",
                    message: "async close failed".to_string(),
                }),
            ],
            async move {
                finalized_for_future.store(true, Ordering::SeqCst);
                Ok(())
            },
        ));

        assert!(finalized.load(Ordering::SeqCst));
        assert!(matches!(
            result,
            Err(PersistenceError::BackendOperationFailed { operation, message })
                if operation == "sync_cleanup" && message == "sync cleanup failed"
        ));
    }

    #[test]
    fn finalize_cleanup_results_returns_finalizer_error() {
        let result = run_sync_case(finalize_cleanup_results([Ok(())], async {
            Err(PersistenceError::BackendOperationFailed {
                operation: "postgres_live_cleanup",
                message: "postgres live service is unavailable at postgres://localhost/rurr: probe failed".to_string(),
            })
        }));

        assert!(matches!(
            result,
            Err(PersistenceError::BackendOperationFailed { operation, message })
                if operation == "postgres_live_cleanup"
                    && message.contains("postgres live service is unavailable")
        ));
    }

    #[test]
    fn initialize_cleanup_fixture_runs_cleanup_after_post_init_assertion_panic() {
        let lane = PanicCleanupLane {
            cleanup_count: AtomicUsize::new(0),
            initialized: AtomicBool::new(false),
        };

        let panic = std::panic::catch_unwind(AssertUnwindSafe(|| {
            run_sync_case(initialize_is_initialized_and_cleanup_are_explicit(
                &lane,
                |_| {},
            ))
            .expect("fixture should not return before panic")
        }))
        .expect_err("post-init assertion should panic");

        let message = rurr_core::common::panic::panic_payload_to_string(panic);
        assert!(message.contains("is_initialized should work after initialize"));
        assert_eq!(lane.cleanup_count.load(Ordering::SeqCst), 1);
    }

    struct InMemorySyncLane {
        persister: Arc<InMemoryPersister>,
    }

    #[async_trait(?Send)]
    impl PersistenceLane for InMemorySyncLane {
        async fn initialize(&self) -> Result<(), PersistenceError> {
            self.persister.initialize()
        }

        async fn is_initialized(&self) -> Result<bool, PersistenceError> {
            self.persister.is_initialized()
        }

        async fn cleanup(&self) -> Result<(), PersistenceError> {
            self.persister.cleanup()
        }

        async fn save(
            &self,
            partition_key: Option<&str>,
            app_id: &str,
            sequence_id: u64,
            position: &str,
            state: super::PersistenceStateMap,
            status: rurr_persistence::PersistedStateStatus,
        ) -> Result<(), PersistenceError> {
            self.persister
                .save(partition_key, app_id, sequence_id, position, state, status)
        }

        async fn load(
            &self,
            partition_key: Option<&str>,
            app_id: Option<&str>,
            sequence_id: Option<u64>,
        ) -> Result<Option<rurr_persistence::PersistedStateData>, PersistenceError> {
            self.persister.load(partition_key, app_id, sequence_id)
        }

        async fn list_app_ids(
            &self,
            partition_key: Option<&str>,
        ) -> Result<Vec<String>, PersistenceError> {
            self.persister.list_app_ids(partition_key)
        }
    }

    struct InMemoryAsyncLane {
        persister: Arc<AsyncInMemoryPersister>,
    }

    #[async_trait(?Send)]
    impl PersistenceLane for InMemoryAsyncLane {
        async fn initialize(&self) -> Result<(), PersistenceError> {
            self.persister.initialize().await
        }

        async fn is_initialized(&self) -> Result<bool, PersistenceError> {
            self.persister.is_initialized().await
        }

        async fn cleanup(&self) -> Result<(), PersistenceError> {
            self.persister.cleanup().await
        }

        async fn save(
            &self,
            partition_key: Option<&str>,
            app_id: &str,
            sequence_id: u64,
            position: &str,
            state: super::PersistenceStateMap,
            status: rurr_persistence::PersistedStateStatus,
        ) -> Result<(), PersistenceError> {
            self.persister
                .save(partition_key, app_id, sequence_id, position, state, status)
                .await
        }

        async fn load(
            &self,
            partition_key: Option<&str>,
            app_id: Option<&str>,
            sequence_id: Option<u64>,
        ) -> Result<Option<rurr_persistence::PersistedStateData>, PersistenceError> {
            self.persister
                .load(partition_key, app_id, sequence_id)
                .await
        }

        async fn list_app_ids(
            &self,
            partition_key: Option<&str>,
        ) -> Result<Vec<String>, PersistenceError> {
            self.persister.list_app_ids(partition_key).await
        }
    }

    fn make_sync_in_memory_lane<'a>(_: &'a str) -> LocalBoxFuture<'a, InMemorySyncLane> {
        Box::pin(async move {
            InMemorySyncLane {
                persister: Arc::new(InMemoryPersister::new()),
            }
        })
    }

    fn make_async_in_memory_lane<'a>(_: &'a str) -> LocalBoxFuture<'a, InMemoryAsyncLane> {
        Box::pin(async move {
            InMemoryAsyncLane {
                persister: Arc::new(AsyncInMemoryPersister::new()),
            }
        })
    }

    #[test]
    fn shared_facade_contract_harness_drives_sync_lane_resume_smoke() {
        run_sync_case(run_persistence_spec_smoke_suite(
            &make_sync_in_memory_lane,
            |lane, app_id, partition_key, load_target| {
                build_sync_resume_counter_future(
                    Arc::clone(&lane.persister),
                    app_id,
                    partition_key,
                    load_target,
                )
            },
            step_sync_counter_app::<InMemorySyncLane>,
        ));
    }

    #[tokio::test]
    async fn shared_facade_contract_harness_drives_async_lane_resume_smoke() {
        run_persistence_spec_smoke_suite(
            &make_async_in_memory_lane,
            |lane, app_id, partition_key, load_target| {
                build_async_resume_counter_future(
                    Arc::clone(&lane.persister),
                    app_id,
                    partition_key,
                    load_target,
                )
            },
            step_async_counter_app::<InMemoryAsyncLane>,
        )
        .await;
    }
}
