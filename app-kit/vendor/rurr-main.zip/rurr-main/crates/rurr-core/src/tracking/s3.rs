//! Burr-compatible S3 tracking client.
//!
//! The client writes graph, metadata, child-relationship, and log artifacts under the
//! shared layout in [`crate::tracking::s3_layout`]. Construction and key
//! formatting are local-only; provider I/O happens when registration or
//! lifecycle hooks write objects.
//!
//! Enable the `s3` feature on `rurr-core` or the facade `rurr/s3` feature to
//! compile this client. Both sync and async S3 lanes require explicit static
//! credentials from config or standard AWS environment variables.
//!
//! The lifecycle log lane writes sequence-prefixed object names and S3 user
//! metadata that the tracking server indexes without reordering by event type.
//! Missing stream state is a hook error, not a cue to synthesize a first-item or
//! zero-count end-stream event.
use super::s3_artifact::{self, S3RegistrationArtifactInput, S3TrackedArtifact};
use super::s3_layout::{S3AddressingStyle, S3Prefix, DEFAULT_DATA_PREFIX};
use super::s3_metadata;
use super::s3_transport::{S3ClientSettings, S3TransportError};
use super::TrackingError;
use crate::application::context::ParentPointer;
use crate::application::Tracker;
use crate::graph::GraphRegistrationView;
use crate::lifecycle::{AsyncLifecycleAdapter, LifecycleError, SyncLifecycleAdapter};
use crate::tracking::lifecycle_events::{self, ChildRelationshipMode, TrackingLifecycleLog};
use aws_sdk_s3::primitives::ByteStream;
use aws_sigv4::http_request::{
    sign, PayloadChecksumKind, PercentEncodingMode, SignableBody, SignableRequest, SigningSettings,
    UriPathNormalizationMode,
};
use aws_sigv4::sign::v4;
use indexmap::IndexMap;
use serde_json::Value;
use std::collections::BTreeMap;
use std::future::Future;
use std::pin::Pin;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, SystemTime};
use tokio::sync::OnceCell;
use uuid::Uuid;

/// Typed configuration for Burr-compatible S3 tracking.
///
/// The configuration owns shared [`S3ClientSettings`] plus the Rurr project,
/// data prefix, and tracker id used in object metadata. It can be constructed
/// without contacting S3, which keeps builder and doctest paths deterministic.
///
/// # Examples
///
/// ```
/// use rurr_core::tracking::S3TrackingConfig;
///
/// let config = S3TrackingConfig::new("docs-project", "tracking-bucket", "us-east-1")?
///     .with_tracker_id("docs-tracker")?;
/// assert_eq!(config.transport.bucket(), "tracking-bucket");
/// assert_eq!(config.transport.region(), "us-east-1");
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct S3TrackingConfig {
    project: String,
    /// Shared S3 transport settings used by sync and async clients.
    pub transport: S3ClientSettings,
    data_prefix: S3Prefix,
    tracker_id: String,
}

impl S3TrackingConfig {
    /// Creates S3 tracking configuration for a project, bucket, and region.
    pub fn new(
        project: impl Into<String>,
        bucket: impl Into<String>,
        region: impl Into<String>,
    ) -> Result<Self, TrackingError> {
        let project = project.into();
        validate_project(&project)?;
        let bucket = non_empty(bucket.into(), "bucket")?;
        let region = non_empty(region.into(), "region")?;
        Ok(Self {
            project,
            transport: S3ClientSettings::new(
                bucket,
                region,
                None,
                S3AddressingStyle::VirtualHosted,
                None,
                None,
                None,
            ),
            data_prefix: S3Prefix::new(DEFAULT_DATA_PREFIX).map_err(layout_error)?,
            tracker_id: format!("{}-{}", timestamp_for_tracker_id()?, Uuid::new_v4()),
        })
    }

    /// Sets a deterministic tracker id.
    pub fn with_tracker_id(mut self, tracker_id: impl Into<String>) -> Result<Self, TrackingError> {
        self.tracker_id = non_empty(tracker_id.into(), "tracker_id")?;
        Ok(self)
    }

    async fn build_sdk_client(&self) -> Result<aws_sdk_s3::Client, TrackingError> {
        self.transport
            .sdk_client("rurr-s3-tracking")
            .await
            .map_err(tracking_transport_error)
    }
}

/// S3 tracking client that exposes both sync and async lifecycle lanes.
///
/// The client can be installed as a tracker through [`TrackerSpec`](crate::TrackerSpec)
/// or used directly as a lifecycle adapter. Creating the client does not open a
/// network connection; object writes happen during registration and lifecycle
/// callbacks.
///
/// Sync lifecycle writes use signed HTTP PUT requests. Async lifecycle writes
/// use a lazily constructed AWS SDK client. Both lanes use the same key layout,
/// metadata helpers, and fail-closed stream-state tracking.
///
/// # Examples
///
/// ```
/// use rurr_core::tracking::{S3TrackingClient, S3TrackingConfig};
///
/// let config = S3TrackingConfig::new("docs-project", "tracking-bucket", "us-east-1")?;
/// let client = S3TrackingClient::new(config)?;
/// assert_eq!(client.config().transport.bucket(), "tracking-bucket");
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
pub struct S3TrackingClient {
    config: Arc<S3TrackingConfig>,
    async_client: OnceCell<aws_sdk_s3::Client>,
    sync_agent: ureq::Agent,
    lifecycle_log_sequence: AtomicU64,
    child_event_sequence: AtomicU64,
    lifecycle_log: TrackingLifecycleLog,
    app_partitions: Mutex<IndexMap<String, Option<String>>>,
}

impl S3TrackingClient {
    /// Creates a new S3 tracking client.
    ///
    /// Construction validates local configuration and prepares the sync HTTP
    /// agent. The async AWS SDK client is created lazily on the first async
    /// write.
    pub fn new(config: S3TrackingConfig) -> Result<Self, TrackingError> {
        let sync_agent = ureq::AgentBuilder::new()
            .timeout(Duration::from_secs(30))
            .build();
        Ok(Self {
            config: Arc::new(config),
            async_client: OnceCell::new(),
            sync_agent,
            lifecycle_log_sequence: AtomicU64::new(0),
            child_event_sequence: AtomicU64::new(0),
            lifecycle_log: TrackingLifecycleLog::new(),
            app_partitions: Mutex::new(IndexMap::new()),
        })
    }

    /// Returns this client's configuration.
    pub fn config(&self) -> &S3TrackingConfig {
        &self.config
    }

    /// Builds a Burr-compatible S3 key for one object.
    ///
    /// The key uses the current UTC timestamp and the configured data prefix.
    /// Use [`S3TrackingObjectKey`](crate::tracking::S3TrackingObjectKey) when a
    /// caller needs deterministic key construction for tests or parsing.
    pub fn object_key(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        filename: &str,
    ) -> Result<String, TrackingError> {
        s3_artifact::build_object_key(
            &self.config.data_prefix,
            &self.config.project,
            time::OffsetDateTime::now_utc(),
            partition_key,
            app_id,
            filename,
        )
        .map_err(tracking_artifact_error)
    }

    /// Registers an application by writing graph, metadata, and parent child-event S3 objects.
    pub fn register_application(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &impl GraphRegistrationView,
        parent_pointer: Option<ParentPointer>,
        spawning_parent_pointer: Option<ParentPointer>,
    ) -> Result<(), TrackingError> {
        self.register_application_with_child_relationships(
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            ChildRelationshipMode::Record,
        )
    }

    fn register_application_with_child_relationships(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &impl GraphRegistrationView,
        parent_pointer: Option<ParentPointer>,
        spawning_parent_pointer: Option<ParentPointer>,
        child_relationships: ChildRelationshipMode,
    ) -> Result<(), TrackingError> {
        let artifacts = self.prepare_registration(
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships,
        )?;
        if child_relationships != ChildRelationshipMode::RelationshipOnly {
            self.remember_app_partition(app_id, partition_key)?;
        }
        for artifact in artifacts {
            self.put_object_sync(artifact)?;
        }
        Ok(())
    }

    /// Registers an application asynchronously by writing graph, metadata, and parent child-event S3 objects.
    pub async fn register_application_async(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &impl GraphRegistrationView,
        parent_pointer: Option<ParentPointer>,
        spawning_parent_pointer: Option<ParentPointer>,
    ) -> Result<(), TrackingError> {
        self.register_application_with_child_relationships_async(
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            ChildRelationshipMode::Record,
        )
        .await
    }

    async fn register_application_with_child_relationships_async(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &impl GraphRegistrationView,
        parent_pointer: Option<ParentPointer>,
        spawning_parent_pointer: Option<ParentPointer>,
        child_relationships: ChildRelationshipMode,
    ) -> Result<(), TrackingError> {
        let artifacts = self.prepare_registration(
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships,
        )?;
        if child_relationships != ChildRelationshipMode::RelationshipOnly {
            self.remember_app_partition(app_id, partition_key)?;
        }
        for artifact in artifacts {
            self.put_object_async(artifact).await?;
        }
        Ok(())
    }

    fn prepare_registration(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &impl GraphRegistrationView,
        parent_pointer: Option<ParentPointer>,
        spawning_parent_pointer: Option<ParentPointer>,
        child_relationships: ChildRelationshipMode,
    ) -> Result<Vec<S3TrackedArtifact>, TrackingError> {
        let record_application_artifacts =
            child_relationships != ChildRelationshipMode::RelationshipOnly;
        let record_child_relationships =
            child_relationships != ChildRelationshipMode::ApplicationOnly;
        let child_event_count = if record_child_relationships {
            usize::from(parent_pointer.is_some()) + usize::from(spawning_parent_pointer.is_some())
        } else {
            0
        };
        let child_sequence_start = self
            .child_event_sequence
            .fetch_add(child_event_count as u64, Ordering::Relaxed);
        s3_artifact::registration_artifacts(S3RegistrationArtifactInput {
            data_prefix: &self.config.data_prefix,
            project: &self.config.project,
            tracker_id: &self.config.tracker_id,
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            record_application_artifacts,
            record_child_relationships,
            child_sequence_start,
        })
        .map_err(tracking_artifact_error)
    }

    async fn sdk_client(&self) -> Result<&aws_sdk_s3::Client, TrackingError> {
        self.async_client
            .get_or_try_init(|| async { self.config.build_sdk_client().await })
            .await
    }

    fn lifecycle_log(&self) -> &TrackingLifecycleLog {
        &self.lifecycle_log
    }

    fn put_object_sync(&self, object: S3TrackedArtifact) -> Result<(), TrackingError> {
        let S3TrackedArtifact {
            key,
            body,
            metadata,
        } = object;
        let signed = SignedPutRequest::new(&self.config, &key, &body, metadata)?;
        let mut request = self.sync_agent.put(&signed.url);
        for (name, value) in signed.headers {
            request = request.set(&name, &value);
        }
        let response = request
            .send_bytes(&body)
            .map_err(|error| TrackingError::S3Transport {
                operation: "sync_put_object",
                message: error.to_string(),
            })?;
        if !(200..300).contains(&response.status()) {
            return Err(TrackingError::S3Transport {
                operation: "sync_put_object",
                message: format!("s3 returned status {}", response.status()),
            });
        }
        Ok(())
    }

    async fn put_object_async(&self, object: S3TrackedArtifact) -> Result<(), TrackingError> {
        let S3TrackedArtifact {
            key,
            body,
            metadata,
        } = object;
        self.sdk_client()
            .await?
            .put_object()
            .bucket(self.config.transport.bucket())
            .key(key)
            .set_metadata(Some(metadata.into_iter().collect()))
            .body(ByteStream::from(body))
            .send()
            .await
            .map_err(|error| TrackingError::S3Transport {
                operation: "async_put_object",
                message: error.to_string(),
            })?;
        Ok(())
    }

    fn write_lifecycle_log_entry(
        &self,
        app_id: Option<&str>,
        partition_key: Option<&str>,
        event: &Value,
        operation: &'static str,
    ) -> Result<(), LifecycleError> {
        let artifact =
            self.prepare_lifecycle_log_object(app_id, partition_key, event, operation)?;
        self.put_object_sync(artifact)
            .map_err(|error| lifecycle_tracking_error(operation, error))
    }

    async fn write_lifecycle_log_entry_async(
        &self,
        app_id: Option<&str>,
        partition_key: Option<&str>,
        event: &Value,
        operation: &'static str,
    ) -> Result<(), LifecycleError> {
        let artifact =
            self.prepare_lifecycle_log_object(app_id, partition_key, event, operation)?;
        self.put_object_async(artifact)
            .await
            .map_err(|error| lifecycle_tracking_error(operation, error))
    }

    fn prepare_lifecycle_log_object(
        &self,
        app_id: Option<&str>,
        partition_key: Option<&str>,
        event: &Value,
        operation: &'static str,
    ) -> Result<S3TrackedArtifact, LifecycleError> {
        let app_id = required_app_id(app_id, operation)?;
        let sequence = self.lifecycle_log_sequence.fetch_add(1, Ordering::Relaxed);
        let partition_key = self.resolve_partition_for_app(&app_id, partition_key, operation)?;
        s3_artifact::lifecycle_log_artifact(
            &self.config.data_prefix,
            &self.config.project,
            &self.config.tracker_id,
            sequence,
            partition_key.as_deref(),
            &app_id,
            event,
        )
        .map_err(|error| lifecycle_artifact_error(operation, error))
    }

    fn remember_app_partition(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
    ) -> Result<(), TrackingError> {
        self.app_partitions
            .lock()
            .map_err(|_| TrackingError::LockPoisoned {
                lock: "s3_app_partitions",
            })?
            .insert(app_id.to_string(), partition_key.map(str::to_string));
        Ok(())
    }

    fn resolve_partition_for_app(
        &self,
        app_id: &str,
        explicit_partition_key: Option<&str>,
        operation: &'static str,
    ) -> Result<Option<String>, LifecycleError> {
        if explicit_partition_key.is_some() {
            return Ok(explicit_partition_key.map(str::to_string));
        }
        self.app_partitions
            .lock()
            .map_err(|_| LifecycleError::hook_failed(operation, "S3 app partition lock poisoned"))
            .and_then(|partitions| {
                partitions.get(app_id).cloned().ok_or_else(|| {
                    LifecycleError::hook_failed(
                        operation,
                        format!("S3 lifecycle event for unregistered app id: {app_id}"),
                    )
                })
            })
    }
}

impl lifecycle_events::TrackingLifecycleSink for S3TrackingClient {
    fn write_lifecycle_event(
        &self,
        app_id: Option<&str>,
        event: &Value,
        operation: &'static str,
    ) -> Result<String, LifecycleError> {
        let app_id = required_app_id(app_id, operation)?;
        self.write_lifecycle_log_entry(Some(&app_id), None, event, operation)?;
        Ok(app_id)
    }
}

#[async_trait::async_trait]
impl lifecycle_events::AsyncTrackingLifecycleSink for S3TrackingClient {
    async fn write_lifecycle_event_async(
        &self,
        app_id: Option<&str>,
        event: &Value,
        operation: &'static str,
    ) -> Result<String, LifecycleError> {
        let app_id = required_app_id(app_id, operation)?;
        self.write_lifecycle_log_entry_async(Some(&app_id), None, event, operation)
            .await?;
        Ok(app_id)
    }
}

impl lifecycle_events::TrackingLifecycleAdapter for S3TrackingClient {
    fn tracking_log(&self) -> &TrackingLifecycleLog {
        self.lifecycle_log()
    }

    fn register_tracking_application(
        &self,
        registration: lifecycle_events::TrackingRegistration<'_>,
    ) -> Result<(), LifecycleError> {
        self.register_application_with_child_relationships(
            registration.app_id,
            registration.partition_key,
            registration.graph,
            registration.parent_pointer.cloned(),
            registration.spawning_parent_pointer.cloned(),
            registration.child_relationships,
        )
        .map_err(|error| lifecycle_tracking_error(registration.operation, error))
    }

    fn register_tracking_application_async<'a>(
        &'a self,
        registration: lifecycle_events::TrackingRegistration<'a>,
    ) -> Pin<Box<dyn Future<Output = Result<(), LifecycleError>> + Send + 'a>> {
        Box::pin(async move {
            self.register_application_with_child_relationships_async(
                registration.app_id,
                registration.partition_key,
                registration.graph,
                registration.parent_pointer.cloned(),
                registration.spawning_parent_pointer.cloned(),
                registration.child_relationships,
            )
            .await
            .map_err(|error| lifecycle_tracking_error(registration.operation, error))
        })
    }
}

impl Tracker for S3TrackingClient {
    fn sync_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn SyncLifecycleAdapter>> {
        Some(self)
    }

    fn async_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn AsyncLifecycleAdapter>> {
        Some(self)
    }
}

fn validate_project(project: &str) -> Result<(), TrackingError> {
    if super::allowed_project_name(project, cfg!(windows)) {
        Ok(())
    } else {
        Err(TrackingError::InvalidProjectName {
            project: project.to_string(),
        })
    }
}

fn non_empty(value: String, field: &'static str) -> Result<String, TrackingError> {
    if value.trim().is_empty() {
        Err(TrackingError::MissingS3TrackerConfig { field })
    } else {
        Ok(value)
    }
}

fn layout_error(error: super::s3_layout::S3LayoutError) -> TrackingError {
    TrackingError::S3Layout {
        message: error.to_string(),
    }
}

fn timestamp_for_tracker_id() -> Result<String, TrackingError> {
    rurr_persistence::wire::sortable_rfc3339_utc_string(std::time::SystemTime::now()).map_err(
        |error| TrackingError::Timestamp {
            operation: "s3_tracker_id",
            message: error.to_string(),
        },
    )
}

fn required_app_id(
    app_id: Option<&str>,
    operation: &'static str,
) -> Result<String, LifecycleError> {
    app_id
        .map(str::to_string)
        .ok_or_else(|| LifecycleError::hook_failed(operation, "missing app id for S3 tracking"))
}

fn lifecycle_tracking_error(operation: &'static str, error: TrackingError) -> LifecycleError {
    LifecycleError::hook_failed(operation, error.to_string())
}

fn lifecycle_artifact_error(
    operation: &'static str,
    error: s3_artifact::S3TrackingArtifactError,
) -> LifecycleError {
    LifecycleError::hook_failed(operation, tracking_artifact_error(error).to_string())
}

fn tracking_transport_error(error: S3TransportError) -> TrackingError {
    match error {
        S3TransportError::MissingConfig(field) => TrackingError::MissingS3TrackerConfig { field },
        S3TransportError::InvalidAddressing(message) => TrackingError::S3Layout { message },
        S3TransportError::InvalidEndpoint(message) => TrackingError::S3Transport {
            operation: "s3_endpoint",
            message,
        },
    }
}

fn metadata_error(error: s3_metadata::S3MetadataError) -> TrackingError {
    match error {
        s3_metadata::S3MetadataError::SerializePointer(error) => TrackingError::SerdeJson(error),
        other => TrackingError::S3Layout {
            message: other.to_string(),
        },
    }
}

fn tracking_artifact_error(error: s3_artifact::S3TrackingArtifactError) -> TrackingError {
    match error {
        s3_artifact::S3TrackingArtifactError::InvalidAppId(app_id) => {
            TrackingError::InvalidAppId { app_id }
        }
        s3_artifact::S3TrackingArtifactError::Layout(error) => layout_error(error),
        s3_artifact::S3TrackingArtifactError::Metadata(error) => metadata_error(error),
        s3_artifact::S3TrackingArtifactError::Json(error) => TrackingError::SerdeJson(error),
        s3_artifact::S3TrackingArtifactError::Io(error) => TrackingError::Io(error),
        s3_artifact::S3TrackingArtifactError::GraphModel(message) => {
            TrackingError::S3Layout { message }
        }
        s3_artifact::S3TrackingArtifactError::UnexpectedKind(key, expected, actual) => {
            TrackingError::S3Layout {
                message: format!("S3 object '{key}' is a {actual:?} object, expected {expected:?}"),
            }
        }
        s3_artifact::S3TrackingArtifactError::MissingSequenceId => TrackingError::S3Layout {
            message: "S3 log event is missing sequence_id/action_sequence_id".to_string(),
        },
        s3_artifact::S3TrackingArtifactError::MissingBody { key, kind } => {
            TrackingError::S3Layout {
                message: format!(
                    "S3 object '{key}' requires a {kind:?} body for artifact decoding"
                ),
            }
        }
        s3_artifact::S3TrackingArtifactError::Timestamp { operation, message } => {
            TrackingError::Timestamp { operation, message }
        }
    }
}

struct SignedPutRequest {
    url: String,
    headers: BTreeMap<String, String>,
}

impl SignedPutRequest {
    fn new(
        config: &S3TrackingConfig,
        key: &str,
        body: &[u8],
        metadata: BTreeMap<String, String>,
    ) -> Result<Self, TrackingError> {
        let settings = &config.transport;
        let credentials = settings
            .credentials("rurr-s3-tracking")
            .map_err(tracking_transport_error)?;
        let address = settings
            .put_address(key)
            .map_err(tracking_transport_error)?;
        let mut header_values = vec![("host".to_string(), address.host.clone())];
        for (key, value) in metadata {
            header_values.push((format!("x-amz-meta-{key}"), value));
        }
        let signable_request = SignableRequest::new(
            "PUT",
            &address.url,
            header_values
                .iter()
                .map(|(name, value)| (name.as_str(), value.as_str())),
            SignableBody::Bytes(body),
        )
        .map_err(|error| TrackingError::S3Transport {
            operation: "sign_sync_put",
            message: error.to_string(),
        })?;
        let identity: aws_smithy_runtime_api::client::identity::Identity = credentials.into();
        let mut signing_settings = SigningSettings::default();
        signing_settings.payload_checksum_kind = PayloadChecksumKind::XAmzSha256;
        signing_settings.uri_path_normalization_mode = UriPathNormalizationMode::Disabled;
        signing_settings.percent_encoding_mode = PercentEncodingMode::Single;
        let signing_params = v4::SigningParams::builder()
            .identity(&identity)
            .region(config.transport.region())
            .name("s3")
            .time(SystemTime::now())
            .settings(signing_settings)
            .build()
            .map_err(|error| TrackingError::S3Transport {
                operation: "sign_sync_put",
                message: error.to_string(),
            })?
            .into();
        let (instructions, _signature) = sign(signable_request, &signing_params)
            .map_err(|error| TrackingError::S3Transport {
                operation: "sign_sync_put",
                message: error.to_string(),
            })?
            .into_parts();
        let (signed_headers, signed_params) = instructions.into_parts();
        if !signed_params.is_empty() {
            return Err(TrackingError::S3Transport {
                operation: "sign_sync_put",
                message: "unexpected query parameters from header-based S3 SigV4 signing"
                    .to_string(),
            });
        }
        let mut headers = header_values.into_iter().collect::<BTreeMap<_, _>>();
        for header in signed_headers {
            headers.insert(header.name().to_string(), header.value().to_string());
        }
        Ok(Self {
            url: address.url,
            headers,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn config_rejects_missing_s3_required_fields() {
        let error = S3TrackingConfig::new("project", "", "us-east-1")
            .expect_err("empty bucket should fail");
        assert!(matches!(
            error,
            TrackingError::MissingS3TrackerConfig { field: "bucket" }
        ));
    }

    #[test]
    fn key_builder_uses_burr_s3_layout_shape() {
        let config = S3TrackingConfig::new("demo", "bucket", "us-east-1")
            .expect("config should parse")
            .with_tracker_id("tracker-1")
            .expect("tracker id should parse");
        let client = S3TrackingClient::new(config).expect("client should build");
        let key = client
            .object_key(Some("pk"), "app-1", "metadata.json")
            .expect("key should build");
        assert!(key.starts_with("data/demo/"));
        assert!(key.ends_with("/pk/app-1/metadata.json"));
    }

    #[test]
    fn metadata_matches_burr_s3_user_metadata_names() {
        let parent = ParentPointer {
            app_id: "parent".to_string(),
            partition_key: Some("pk".to_string()),
            sequence_id: Some(7),
        };
        let metadata = s3_metadata::application_metadata("tracker-1", Some(&parent), None)
            .expect("metadata should serialize");
        assert_eq!(metadata.get("tracker_id"), Some(&"tracker-1".to_string()));
        assert_eq!(
            metadata.get("spawning_parent_pointer"),
            Some(&"None".to_string())
        );
        let parent_value: Value = serde_json::from_str(
            metadata
                .get("parent_pointer")
                .expect("parent metadata exists"),
        )
        .expect("parent metadata should be json");
        assert_eq!(parent_value["app_id"], json!("parent"));
    }

    #[test]
    fn shared_s3_metadata_helpers_roundtrip_writer_contract() {
        let parent = ParentPointer {
            app_id: "parent".to_string(),
            partition_key: Some("pk".to_string()),
            sequence_id: Some(7),
        };
        let metadata =
            crate::tracking::s3_metadata::application_metadata("tracker", Some(&parent), None)
                .expect("metadata should encode");

        assert_eq!(
            metadata.get(crate::tracking::s3_metadata::TRACKER_ID),
            Some(&"tracker".to_string())
        );
        assert_eq!(
            metadata.get(crate::tracking::s3_metadata::SPAWNING_PARENT_POINTER),
            Some(&"None".to_string())
        );
    }

    #[test]
    fn sync_sigv4_request_includes_metadata_headers_and_signed_payload() {
        let mut config =
            S3TrackingConfig::new("demo", "bucket", "us-east-1").expect("config should build");
        config.transport = config
            .transport
            .with_endpoint_url("http://127.0.0.1:9000")
            .expect("endpoint should parse")
            .with_addressing_style(S3AddressingStyle::PathStyle)
            .with_credentials("minioadmin", "minioadmin", None)
            .expect("credentials should parse");
        let signed = SignedPutRequest::new(
            &config,
            "data/demo/path/log.jsonl",
            br#"{"type":"begin_entry"}"#,
            BTreeMap::from([("tracker_id".to_string(), "tracker-1".to_string())]),
        )
        .expect("request should sign");
        assert_eq!(
            signed.headers.get("x-amz-meta-tracker_id"),
            Some(&"tracker-1".to_string())
        );
        assert!(signed.headers.contains_key("x-amz-content-sha256"));
        assert!(signed
            .headers
            .get("authorization")
            .expect("authorization should exist")
            .contains("SignedHeaders="));
    }

    #[test]
    fn custom_endpoint_virtual_hosted_addressing_keeps_bucket_in_host() {
        let mut config =
            S3TrackingConfig::new("demo", "bucket", "us-east-1").expect("config should build");
        config.transport = config
            .transport
            .with_endpoint_url("http://s3.test.local:9000")
            .expect("endpoint should parse")
            .with_addressing_style(S3AddressingStyle::VirtualHosted);
        assert_eq!(config.transport.bucket(), "bucket");
        assert_eq!(config.transport.region(), "us-east-1");
        let address = config
            .transport
            .put_address("data/demo/a b/graph.json")
            .expect("address should build");

        assert_eq!(address.host, "bucket.s3.test.local:9000");
        assert_eq!(
            address.url,
            "http://bucket.s3.test.local:9000/data/demo/a%20b/graph.json"
        );
    }

    #[test]
    fn custom_endpoint_path_style_addressing_keeps_bucket_in_path() {
        let mut config =
            S3TrackingConfig::new("demo", "bucket", "us-east-1").expect("config should build");
        config.transport = config
            .transport
            .with_endpoint_url("http://127.0.0.1:9000")
            .expect("endpoint should parse")
            .with_addressing_style(S3AddressingStyle::PathStyle);
        let address = config
            .transport
            .put_address("data/demo/app/metadata.json")
            .expect("address should build");

        assert_eq!(address.host, "127.0.0.1:9000");
        assert_eq!(
            address.url,
            "http://127.0.0.1:9000/bucket/data/demo/app/metadata.json"
        );
    }

    #[test]
    fn virtual_hosted_https_rejects_dotted_bucket_names() {
        let config = S3TrackingConfig::new("demo", "bucket.with.dot", "us-east-1").expect("config");
        let error = config
            .transport
            .put_address("data/demo/app/metadata.json")
            .map_err(tracking_transport_error)
            .expect_err("dotted bucket should require path-style or http");

        assert!(matches!(error, TrackingError::S3Layout { .. }));
    }
}
