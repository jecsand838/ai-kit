use std::io;
use std::ops::Deref;
use std::path::{Path, PathBuf};

/// Ephemeral filesystem root for contract and integration tests.
#[derive(Debug)]
pub struct TestDir {
    inner: tempfile::TempDir,
}

impl TestDir {
    /// Creates a new temporary directory.
    pub fn new() -> io::Result<Self> {
        Ok(Self {
            inner: tempfile::tempdir()?,
        })
    }

    /// Returns the root directory path.
    pub fn path(&self) -> &Path {
        self.inner.path()
    }

    /// Appends a relative path to the tempdir root.
    pub fn join(&self, path: impl AsRef<Path>) -> PathBuf {
        self.path().join(path)
    }
}

impl AsRef<Path> for TestDir {
    fn as_ref(&self) -> &Path {
        self.path()
    }
}

impl Deref for TestDir {
    type Target = Path;

    fn deref(&self) -> &Self::Target {
        self.path()
    }
}

/// Creates a new [`TestDir`].
pub fn test_dir() -> io::Result<TestDir> {
    TestDir::new()
}

/// Creates a new [`TestDir`] for use directly inside a test body.
#[track_caller]
pub fn test_dir_for_test() -> io::Result<TestDir> {
    TestDir::new()
}
