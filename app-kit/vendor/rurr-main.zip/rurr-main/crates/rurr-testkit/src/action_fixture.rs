//! Concrete metadata-backed action fixtures for workspace tests.
//!
//! These helpers replace macro-generated `LocalAction` boilerplate with
//! ordinary structs, closures, and builder-style methods.

use futures::Future;
use rurr_core::action::{
    ActionContext, ActionError, ActionKind, ActionResult, FunctionAction,
    FunctionActionUpdatePolicy, LocalAction, LocalAsyncStreamOutput, StreamOutput,
};
use rurr_core::state::State;
use std::fmt;
use std::pin::Pin;
use std::sync::Arc;

use crate::action_metadata::NamedActionMetadata;

type RunFn = dyn Fn(&State, &ActionContext) -> Result<ActionResult, ActionError> + Send + Sync;
type AsyncRunFn = dyn for<'a> Fn(
        &'a State,
        &'a ActionContext,
    ) -> Pin<Box<dyn Future<Output = Result<ActionResult, ActionError>> + 'a>>
    + Send
    + Sync;
type SyncStreamFn =
    dyn Fn(State, ActionContext) -> Box<dyn Iterator<Item = StreamOutput>> + Send + Sync;
type AsyncStreamFn = dyn Fn(State, ActionContext) -> LocalAsyncStreamOutput + Send + Sync;

/// Builds a closure-backed action from fixture metadata and scripted behavior.
pub fn scripted_action(metadata: NamedActionMetadata, spec: ScriptedActionSpec) -> FunctionAction {
    spec.into_function_action(metadata)
        .expect("scripted action spec should build")
}

/// Builder-style behavior spec for concrete scripted fixture actions.
#[derive(Clone)]
pub struct ScriptedActionSpec {
    source_code: Option<String>,
    kind: ActionKind,
    run: Arc<RunFn>,
    async_run: Option<Arc<AsyncRunFn>>,
    update_policy: FunctionActionUpdatePolicy,
    sync_stream: Option<Arc<SyncStreamFn>>,
    async_stream: Option<Arc<AsyncStreamFn>>,
}

impl ScriptedActionSpec {
    /// Creates a spec whose sync lane is explicit unsupported until configured.
    pub fn new() -> Self {
        Self {
            source_code: None,
            kind: ActionKind::Sync,
            run: Arc::new(|_state, _ctx| {
                Err(ActionError::UnsupportedOperation {
                    message: "scripted action has no sync run behavior".to_string(),
                })
            }),
            async_run: None,
            update_policy: FunctionActionUpdatePolicy::DefaultWrites,
            sync_stream: None,
            async_stream: None,
        }
    }

    /// Creates a spec from one sync run behavior.
    pub fn from_run(
        run: impl Fn(&State, &ActionContext) -> Result<ActionResult, ActionError>
            + Send
            + Sync
            + 'static,
    ) -> Self {
        Self::new().with_run(run)
    }

    /// Sets source text for tracking/debug output.
    pub fn with_source_code(mut self, source_code: impl Into<String>) -> Self {
        self.source_code = Some(source_code.into());
        self
    }

    /// Sets whether the fixture should run on the sync or async lane.
    pub fn with_kind(mut self, kind: ActionKind) -> Self {
        self.kind = kind;
        self
    }

    /// Sets the sync run behavior.
    pub fn with_run(
        mut self,
        run: impl Fn(&State, &ActionContext) -> Result<ActionResult, ActionError>
            + Send
            + Sync
            + 'static,
    ) -> Self {
        self.run = Arc::new(run);
        self
    }

    /// Sets the async run behavior.
    pub fn with_async_run(
        mut self,
        run: impl for<'a> Fn(
                &'a State,
                &'a ActionContext,
            )
                -> Pin<Box<dyn Future<Output = Result<ActionResult, ActionError>> + 'a>>
            + Send
            + Sync
            + 'static,
    ) -> Self {
        self.async_run = Some(Arc::new(run));
        self
    }

    /// Sets custom update behavior.
    pub fn with_update(
        mut self,
        update: impl Fn(&ActionResult, &State, &ActionContext) -> Result<State, ActionError>
            + Send
            + Sync
            + 'static,
    ) -> Self {
        self.update_policy = FunctionActionUpdatePolicy::Custom(Arc::new(update));
        self
    }

    /// Sets paired sync and async streaming behavior.
    pub fn with_streams(
        mut self,
        sync_stream: impl Fn(State, ActionContext) -> Box<dyn Iterator<Item = StreamOutput>>
            + Send
            + Sync
            + 'static,
        async_stream: impl Fn(State, ActionContext) -> LocalAsyncStreamOutput + Send + Sync + 'static,
    ) -> Self {
        self.sync_stream = Some(Arc::new(sync_stream));
        self.async_stream = Some(Arc::new(async_stream));
        self
    }

    /// Converts this fixture spec into the shared [`FunctionAction`] runtime path.
    pub fn into_function_action(
        self,
        metadata: NamedActionMetadata,
    ) -> Result<FunctionAction, ActionError> {
        let name = metadata.name().map(str::to_owned);
        let mut builder = FunctionAction::builder()
            .reads(metadata.reads().iter().cloned())
            .writes(metadata.writes().iter().cloned())
            .inputs(metadata.inputs().iter().cloned())
            .tags(metadata.tags().iter().cloned())
            .with_update_policy(self.update_policy);

        if let Some(source_code) = self.source_code {
            builder = builder.with_source_code(source_code);
        }

        let sync_run = self.run;
        let async_run = self.async_run;
        let kind = self.kind;
        let sync_handler = {
            let sync_run = Arc::clone(&sync_run);
            move |state: &State, ctx: &ActionContext| sync_run(state, ctx)
        };
        let async_handler = move |state: State, ctx: ActionContext| {
            let sync_run = Arc::clone(&sync_run);
            let async_run = async_run.clone();
            async move {
                match async_run {
                    Some(run) => run(&state, &ctx).await,
                    None => sync_run(&state, &ctx),
                }
            }
        };

        let action = match (self.sync_stream, self.async_stream) {
            (Some(sync_stream), Some(async_stream)) => builder
                .build_dual_action_result_with_streams(
                    sync_handler,
                    async_handler,
                    move |state, ctx| sync_stream(state, ctx),
                    move |state, ctx| async_stream(state, ctx),
                    kind,
                )?,
            (None, None) => builder.build_dual_action_result(sync_handler, async_handler, kind)?,
            _ => {
                return Err(ActionError::Internal {
                    message: "scripted action streams must configure sync and async lanes together"
                        .to_string(),
                });
            }
        };

        if let Some(name) = name {
            action.with_name(name)
        } else {
            Ok(action)
        }
    }
}

impl Default for ScriptedActionSpec {
    fn default() -> Self {
        Self::new()
    }
}

impl fmt::Debug for ScriptedActionSpec {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ScriptedActionSpec")
            .field("source_code", &self.source_code)
            .field("kind", &self.kind)
            .field("update_policy", &self.update_policy)
            .field("has_async_run", &self.async_run.is_some())
            .field("has_sync_stream", &self.sync_stream.is_some())
            .field("has_async_stream", &self.async_stream.is_some())
            .finish()
    }
}
