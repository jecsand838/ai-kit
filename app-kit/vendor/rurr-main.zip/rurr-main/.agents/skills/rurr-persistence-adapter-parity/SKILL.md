---
name: rurr-persistence-adapter-parity
description: "Use when editing Rurr persistence contracts or SQLite, Postgres, Redis, or Mongo adapters to preserve sync/async boundaries, deterministic ordering, v1 persistence layout, scan exhaustion behavior, and adapter-local concrete simplification."
---

# Rurr Persistence Adapter Parity

Use this skill when persistence adapter cleanup could change stored layout, ordering, scan behavior, or sync/async contracts.

## Quick start

Load, in order:

- `AGENTS.md`
- `README.md`
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- current persistence code and tests found with `rg "Persistence|list_app_ids|PartitionAppIdScan|persisted row"`

Load these companion skills:

- `$rurr-burr-source-parity-walk`
- `$use-rust-best-practices-core`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-dependencies-platforms`

## Workflow

1. Identify the adapter lane and behavior: save, load, list IDs, scan, error mapping, or layout serialization.
2. Add or request characterization tests for ordering, empty results, exhausted scans, and driver-specific error behavior.
3. Keep sync and async persistence traits separate.
4. Extract only adapter-local concrete helpers when multiple queries in the same adapter duplicate shape.
5. Share pure contract logic, such as Redis save result handling or scan state policy, outside lane adapters.
6. Preserve driver-specific parameter binding and connection behavior.
7. Verify no new generic DB abstraction or dependency was added without a real multi-adapter need.

## Output contract

Return:

- the persistence behavior under review
- the deterministic ordering or layout invariant
- the characterization tests required
- the concrete simplification or deletion target
- the narrow adapter gates and any live-provider gate decision

## Default rules

- Preserve the v1 persistence layout and deterministic list ordering.
- Preserve raw adapter behavior that is covered by tests, docs, or oracle artifacts.
- Do not merge sync and async persistence traits.
- Do not add a generic database abstraction over `rusqlite`, `postgres`, `sqlx`, Redis, or Mongo just to remove superficial duplication.
- Avoid new crates and new feature flags.

## Do not use this skill alone when

- the user needs a branch-wide reduction audit: also use `$rurr-branch-diff-reduction-audit`
- adapter behavior must be compared to Burr or oracle artifacts first: also use `$rurr-burr-source-parity-walk`
- implementation is requested for an approved delete-first refactor: also use `$rurr-delete-first-refactor-plan` in implementation mode
- final handoff requires gate selection: also use `$rurr-gate-closeout`
