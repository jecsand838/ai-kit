use crate::sequence_id_u64_to_i64;
use crate::{wire as persistence_wire, PersistedStateStatus, PersistenceError};
use indexmap::IndexMap;
use serde_json::Value;

/// High-level save request before state serialization and partition normalization.
#[derive(Clone, Debug)]
pub struct PersistedStateSaveRequest<'a> {
    partition_key: Option<&'a str>,
    app_id: &'a str,
    sequence_id: u64,
    position: &'a str,
    state: IndexMap<String, Value>,
    status: PersistedStateStatus,
}

impl<'a> PersistedStateSaveRequest<'a> {
    /// Creates a new high-level save request.
    pub fn new(
        partition_key: Option<&'a str>,
        app_id: &'a str,
        sequence_id: u64,
        position: &'a str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Self {
        Self {
            partition_key,
            app_id,
            sequence_id,
            position,
            state,
            status,
        }
    }

    /// Returns the optional partition key supplied by the caller.
    pub fn partition_key(&self) -> Option<&'a str> {
        self.partition_key
    }

    /// Returns the target application identifier.
    pub fn app_id(&self) -> &'a str {
        self.app_id
    }

    /// Returns the sequence identifier to persist.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }

    /// Returns the workflow position being saved.
    pub fn position(&self) -> &'a str {
        self.position
    }

    /// Returns the un-serialized state payload.
    pub fn state(&self) -> &IndexMap<String, Value> {
        &self.state
    }

    /// Returns the persisted-state status for this request.
    pub fn status(&self) -> PersistedStateStatus {
        self.status
    }

    /// Returns the normalized partition key used by SQL backends.
    pub fn normalized_partition_key(&self) -> String {
        persistence_wire::normalize_partition_key(self.partition_key)
    }

    /// Returns the signed SQL sequence identifier for this request.
    pub fn signed_sequence_id(&self) -> Result<i64, PersistenceError> {
        sequence_id_u64_to_i64(self.sequence_id)
    }

    /// Serializes the state payload into the JSON string expected by text-binding backends.
    pub fn state_json(
        &self,
        serialization_failure_operation: &'static str,
    ) -> Result<String, PersistenceError> {
        persistence_wire::serialize_state_json(&self.state, serialization_failure_operation)
    }

    /// Returns the typed JSON payload expected by value-binding backends.
    pub fn state_value(&self) -> Value {
        Value::Object(self.state.clone().into_iter().collect())
    }

    /// Returns the serialized persisted-state status string for this request.
    pub fn status_str(&self) -> &'static str {
        persistence_wire::persisted_status_as_str(self.status)
    }
}

/// Normalized persisted-state lookup selector for sync and async SQL backends.
pub enum LoadSelector<'a> {
    /// The request cannot produce a record lookup.
    NoRecord,
    /// Load the newest record in a partition.
    LatestPartition {
        /// Normalized partition key.
        partition_key: String,
    },
    /// Load the newest record for a specific app.
    LatestApp {
        /// Normalized partition key.
        partition_key: String,
        /// Requested app identifier.
        app_id: &'a str,
    },
    /// Load the newest record matching an exact sequence for a specific app.
    ExactSequence {
        /// Normalized partition key.
        partition_key: String,
        /// Requested app identifier.
        app_id: &'a str,
        /// Normalized signed SQL sequence identifier.
        sequence_id: i64,
    },
}

impl<'a> LoadSelector<'a> {
    /// Creates a normalized selector from the optional public lookup fields.
    pub fn new(
        partition_key: Option<&str>,
        app_id: Option<&'a str>,
        sequence_id: Option<u64>,
    ) -> Result<Self, PersistenceError> {
        let partition_key = persistence_wire::normalize_partition_key(partition_key);
        Ok(match (app_id, sequence_id) {
            (None, Some(_)) => Self::NoRecord,
            (None, None) => Self::LatestPartition { partition_key },
            (Some(app_id), None) => Self::LatestApp {
                partition_key,
                app_id,
            },
            (Some(app_id), Some(sequence_id)) => Self::ExactSequence {
                partition_key,
                app_id,
                sequence_id: sequence_id_u64_to_i64(sequence_id)?,
            },
        })
    }
}
