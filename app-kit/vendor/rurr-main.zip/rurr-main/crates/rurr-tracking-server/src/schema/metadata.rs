use serde::{Deserialize, Serialize};

pub use rurr_core::tracking::PointerModel;

/// Burr compatibility version exposed by the tracking API layer.
pub const BURR_COMPAT_VERSION: &str = "0.41.0";

/// Returns the Burr compatibility version exposed by this API surface.
pub fn burr_compat_version() -> &'static str {
    BURR_COMPAT_VERSION
}

/// Response returned by tracking backends that expose their high-level capabilities.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AppSpecResponse {
    /// Backend identifier.
    pub backend: String,
    /// Storage layout version expected by the backend.
    pub storage_layout_version: String,
    /// Whether indexing endpoints are available.
    pub indexing: bool,
    /// Whether snapshotting endpoints are available.
    pub snapshotting: bool,
    /// Whether demo-data generation is supported.
    pub supports_demos: bool,
    /// Whether annotation endpoints are supported.
    pub supports_annotations: bool,
}

/// Response returned by version endpoints.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct VersionResponse {
    /// Version string for the service or package.
    pub version: String,
}
