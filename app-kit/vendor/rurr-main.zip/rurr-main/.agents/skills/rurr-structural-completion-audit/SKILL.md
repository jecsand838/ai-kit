---
name: rurr-structural-completion-audit
description: "Use before final handoff of a Rurr cleanup or parity-sensitive refactor to verify negative structural requirements, stale exports, dead code, panic paths, forbidden runtime patterns, duplicated helper loops, and manifest-sensitive tracked-file fallout."
---

# Rurr Structural Completion Audit

Use this skill after a cleanup or parity-sensitive refactor is implemented, but before final gate closeout.

## Quick start

Load, in order:

- `AGENTS.md`
- `README.md`
- `docs/00_overview.md`
- the approved plan or audit findings, if present
- the current changed-file list and diff

Load these companion skills:

- `$rurr-gate-closeout`
- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-testing`

Add subsystem guardrail skills when touched files require them.

Use this skill as an audit-only readiness check when it is invoked alone. When paired with `$rurr-delete-first-refactor-plan` in implementation mode, every failed structural check returns to the implementation loop for fixes before gate closeout.

## Workflow

1. Reconstruct the structural promises from the plan, audit findings, and changed files.
2. Run targeted searches for forbidden leftovers, stale exports, dead compatibility layers, and warning suppressions.
3. Check touched production paths for avoidable `expect`, `unwrap`, panic strings, or generated panic paths.
4. Check core runtime paths for `realize_stream`, `spawn_blocking`, `block_on`, `block_in_place`, temporary runtimes, and `std::thread::spawn`.
5. Check planned private modules are not still publicly exported.
6. Check duplicate helper loops or old helper families named in the plan no longer exist.
7. Check that cleanup work did not introduce helper macros or macro helper crates to hide
   duplication that should have become structs, enums, methods, or traits.
8. Hand results to `$rurr-gate-closeout` for final gate selection and manifest handling.

## Common structural searches

Adapt these to the changed files and approved plan:

- `rg -n "expect\\(|unwrap\\(|panic!" <touched-production-paths>`
- `rg -n "realize_stream|spawn_blocking|block_on|block_in_place|Runtime::new|std::thread::spawn" crates`
- `rg -n "allow\\((dead_code|unused|warnings)" crates .agents`
- `rg -n "macro_rules!|enum_dispatch|derive_more|paste::|seq_macro" crates tests`
- `rg -n "pub mod (ops|platform|resolve|target|validation)" crates`
- `rg -n "macro-generated action should be valid|PartitionAppIdScan|ActionEntrypointResolution|GraphEntrypointResolution" crates`

## Output contract

Return:

- a pass/fail list of structural checks actually performed
- exact remaining files, symbols, or patterns for every failure
- whether any failure blocks closeout
- the cleanup needed before final gates
- the gate-closeout handoff recommendation

## Default rules

- Do not claim a structural check passed unless the search or inspection actually ran.
- Prefer changed-file-scoped inspection, then widen only for plan-wide negative requirements.
- Treat leftover wrappers, aliases, stale re-exports, warning suppressions, or duplicated helper loops as incomplete cleanup.
- Do not mutate files; this skill audits readiness before closeout.
- Do not hand edit `MANIFEST.files.txt`, `MANIFEST.sha256`, or `FULL_CONTENT.md`.

## Do not use this skill alone when

- the user still needs approved delete-first refactor implementation: also use `$rurr-delete-first-refactor-plan` in implementation mode
- the user needs final gate execution or manifest refresh: also use `$rurr-gate-closeout`
- the user needs a fresh audit or plan rather than completion verification: also use `$rurr-branch-diff-reduction-audit` or `$rurr-delete-first-refactor-plan`
