use mongodb::error::{Error as MongoError, ErrorKind as MongoErrorKind, WriteFailure};
use rurr_persistence::PersistenceError;

use crate::{OP_CONNECTION_CLOSED, OP_RECORD_ALREADY_EXISTS};

pub(crate) fn connection_closed_error() -> PersistenceError {
    PersistenceError::UnsupportedOperation {
        operation: OP_CONNECTION_CLOSED,
    }
}

pub(crate) fn duplicate_save_error() -> PersistenceError {
    PersistenceError::UnsupportedOperation {
        operation: OP_RECORD_ALREADY_EXISTS,
    }
}

fn mongo_command_code(error: &MongoError) -> Option<i32> {
    match error.kind.as_ref() {
        MongoErrorKind::Command(command_error) => Some(command_error.code),
        _ => None,
    }
}

pub(crate) fn mongo_error_details(error: &MongoError) -> (Option<i32>, Option<&str>, Option<&str>) {
    match error.kind.as_ref() {
        MongoErrorKind::Command(command_error) => (
            Some(command_error.code),
            Some(command_error.code_name.as_str()),
            Some(command_error.message.as_str()),
        ),
        MongoErrorKind::Write(WriteFailure::WriteError(write_error)) => (
            Some(write_error.code),
            write_error.code_name.as_deref(),
            Some(write_error.message.as_str()),
        ),
        MongoErrorKind::Write(WriteFailure::WriteConcernError(write_error)) => (
            Some(write_error.code),
            Some(write_error.code_name.as_str()),
            Some(write_error.message.as_str()),
        ),
        _ => (None, None, None),
    }
}

pub(crate) fn classify_mongo_server_error(
    code: Option<i32>,
    code_name: Option<&str>,
    message: Option<&str>,
) -> Option<PersistenceError> {
    let code = code?;
    let message = message.unwrap_or_default();

    if code == 361 || code_name == Some("CollectionUUIDMismatch") {
        return Some(PersistenceError::NotInitialized);
    }

    if code == 2 && is_missing_hinted_index_message(message) {
        return Some(PersistenceError::NotInitialized);
    }

    if code == 11000 {
        return Some(duplicate_save_error());
    }

    None
}

fn is_missing_hinted_index_message(message: &str) -> bool {
    message.contains("hint provided does not correspond to an existing index")
}

pub(crate) fn is_namespace_exists_error(error: &MongoError) -> bool {
    mongo_command_code(error) == Some(48)
}

pub(crate) fn is_namespace_not_found_error(error: &MongoError) -> bool {
    mongo_command_code(error) == Some(26)
}
