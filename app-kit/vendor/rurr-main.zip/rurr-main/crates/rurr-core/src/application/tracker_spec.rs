use super::Tracker;
#[cfg(feature = "s3")]
use crate::tracking::S3TrackingConfig;
use indexmap::IndexMap;
use serde_json::Value;
use std::sync::Arc;

/// Configures how an application should obtain its tracking client.
///
/// A tracker spec is resolved by [`ApplicationBuilder`](crate::ApplicationBuilder)
/// while building an application. Local specs create a
/// [`LocalTrackingClient`](crate::tracking::LocalTrackingClient), feature-gated
/// S3 specs create an S3 client from typed configuration, and provided specs
/// reuse a caller-owned tracker without exposing backend details through the
/// application API.
///
/// Local tracking is the provider-neutral default. S3 tracking is available only
/// when the `s3` feature is enabled and must be requested explicitly; no
/// application build silently falls back between local and provider-backed
/// tracking.
///
/// # Examples
///
/// ```
/// use indexmap::IndexMap;
/// use rurr_core::TrackerSpec;
///
/// let spec = TrackerSpec::local("docs-project", IndexMap::new());
/// assert!(matches!(spec, TrackerSpec::Local { .. }));
/// ```
#[derive(Clone)]
pub enum TrackerSpec {
    /// Build a local tracker for `project` with backend-specific parameters.
    Local {
        /// Tracking project id.
        project: String,
        /// Backend-specific configuration parameters.
        params: IndexMap<String, Value>,
    },
    /// Build an S3 tracker from typed Burr-compatible configuration.
    #[cfg(feature = "s3")]
    S3 {
        /// S3 tracker configuration.
        config: S3TrackingConfig,
    },
    /// Reuse a caller-provided tracker instance.
    Provided(Arc<dyn Tracker>),
}

impl TrackerSpec {
    /// Creates a specification for a locally constructed tracker.
    ///
    /// `params` accepts only the local tracking parameters supported by the
    /// resolver, such as an explicit storage directory. Unknown values are
    /// rejected during application build rather than ignored.
    pub fn local(project: impl Into<String>, params: IndexMap<String, Value>) -> Self {
        Self::Local {
            project: project.into(),
            params,
        }
    }

    /// Creates a specification for a Burr-compatible S3 tracker.
    ///
    /// Construction remains local-only; provider clients are created lazily by
    /// the S3 tracking client when registration or lifecycle hooks write
    /// objects. Provider failures are returned through tracking/lifecycle
    /// errors instead of falling back to local artifacts.
    ///
    /// # Examples
    ///
    /// ```
    /// use rurr_core::tracking::S3TrackingConfig;
    /// use rurr_core::TrackerSpec;
    ///
    /// let config = S3TrackingConfig::new("docs-project", "tracking-bucket", "us-east-1")?;
    /// let spec = TrackerSpec::s3(config);
    /// assert!(matches!(spec, TrackerSpec::S3 { .. }));
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    #[cfg(feature = "s3")]
    pub fn s3(config: S3TrackingConfig) -> Self {
        Self::S3 { config }
    }

    /// Creates a specification that reuses an existing tracker instance.
    ///
    /// Use this when an application should share a tracker, wrap one with
    /// additional behavior, or inject a test tracker through the same
    /// backend-agnostic builder surface.
    pub fn provided(tracker: Arc<dyn Tracker>) -> Self {
        Self::Provided(tracker)
    }
}
