use crate::ExprError;
use rustpython_parser::ast;

/// Validates that an AST expression stays within Rurr's supported condition subset.
pub fn validate_expr(expr: &ast::Expr) -> Result<(), ExprError> {
    match expr {
        ast::Expr::BoolOp(node) => {
            match node.op {
                ast::BoolOp::And | ast::BoolOp::Or => {}
            }
            if node.values.len() < 2 {
                return Err(ExprError::InvalidCall {
                    message: "boolean operation must contain at least two operands".to_string(),
                });
            }
            for value in &node.values {
                validate_expr(value)?;
            }
            Ok(())
        }
        ast::Expr::UnaryOp(node) => {
            match node.op {
                ast::UnaryOp::Not | ast::UnaryOp::UAdd | ast::UnaryOp::USub => {}
                _ => {
                    return Err(ExprError::UnsupportedOperator {
                        operator: format!("{:#?}", node.op),
                    });
                }
            }
            validate_expr(&node.operand)
        }
        ast::Expr::BinOp(node) => {
            match node.op {
                ast::Operator::Add
                | ast::Operator::Sub
                | ast::Operator::Mult
                | ast::Operator::Div
                | ast::Operator::Mod
                | ast::Operator::FloorDiv
                | ast::Operator::Pow => {}
                _ => {
                    return Err(ExprError::UnsupportedOperator {
                        operator: format!("{:#?}", node.op),
                    });
                }
            }
            validate_expr(&node.left)?;
            validate_expr(&node.right)
        }
        ast::Expr::IfExp(node) => {
            validate_expr(&node.test)?;
            validate_expr(&node.body)?;
            validate_expr(&node.orelse)
        }
        ast::Expr::Compare(node) => {
            validate_expr(&node.left)?;
            if node.ops.len() != node.comparators.len() {
                return Err(ExprError::Parse {
                    message: "invalid comparison chain".to_string(),
                });
            }
            for op in &node.ops {
                match op {
                    ast::CmpOp::Eq
                    | ast::CmpOp::NotEq
                    | ast::CmpOp::Lt
                    | ast::CmpOp::LtE
                    | ast::CmpOp::Gt
                    | ast::CmpOp::GtE
                    | ast::CmpOp::In
                    | ast::CmpOp::NotIn
                    | ast::CmpOp::Is
                    | ast::CmpOp::IsNot => {}
                }
            }
            for comparator in &node.comparators {
                validate_expr(comparator)?;
            }
            Ok(())
        }
        ast::Expr::Call(node) => validate_call(node),
        ast::Expr::Name(node) => match node.ctx {
            ast::ExprContext::Load => Ok(()),
            _ => Err(ExprError::UnsupportedNode {
                node: "Name (non-load context)".to_string(),
            }),
        },
        ast::Expr::Constant(node) => validate_constant(&node.value),
        ast::Expr::Subscript(node) => {
            match node.ctx {
                ast::ExprContext::Load => {}
                _ => {
                    return Err(ExprError::UnsupportedNode {
                        node: "Subscript (non-load context)".to_string(),
                    });
                }
            }
            validate_expr(&node.value)?;
            match node.slice.as_ref() {
                ast::Expr::Slice(slice) => {
                    if let Some(lower) = &slice.lower {
                        validate_expr(lower)?;
                    }
                    if let Some(upper) = &slice.upper {
                        validate_expr(upper)?;
                    }
                    if let Some(step) = &slice.step {
                        validate_expr(step)?;
                    }
                    Ok(())
                }
                other => validate_expr(other),
            }
        }
        ast::Expr::Attribute(node) => {
            if node.ctx != ast::ExprContext::Load {
                return Err(ExprError::UnsupportedNode {
                    node: "Attribute (non-load context)".to_string(),
                });
            }
            validate_expr(&node.value)
        }
        _ => Err(ExprError::UnsupportedNode {
            node: expr_variant_name(expr).to_string(),
        }),
    }
}

fn validate_call(call: &ast::ExprCall) -> Result<(), ExprError> {
    if !call.keywords.is_empty() {
        return Err(ExprError::InvalidCall {
            message: "keyword arguments are not supported".to_string(),
        });
    }
    if call.args.len() != 1 {
        return Err(ExprError::InvalidCall {
            message: "call expressions must have exactly one positional argument".to_string(),
        });
    }
    match call.func.as_ref() {
        ast::Expr::Name(name)
            if name.id.as_str() == "len" && name.ctx == ast::ExprContext::Load =>
        {
            validate_expr(&call.args[0])
        }
        _ => Err(ExprError::InvalidCall {
            message: "only len(...) is supported".to_string(),
        }),
    }
}

fn validate_constant(constant: &ast::Constant) -> Result<(), ExprError> {
    match constant {
        ast::Constant::None
        | ast::Constant::Bool(_)
        | ast::Constant::Str(_)
        | ast::Constant::Int(_)
        | ast::Constant::Float(_) => Ok(()),
        _ => Err(ExprError::UnsupportedConstant {
            constant: format!("{constant:?}"),
        }),
    }
}

/// Returns `true` when `call` is a supported `len(...)` invocation.
pub fn is_len_call(call: &ast::ExprCall) -> bool {
    if call.args.len() != 1 || !call.keywords.is_empty() {
        return false;
    }

    match call.func.as_ref() {
        ast::Expr::Name(name) => name.id.as_str() == "len" && name.ctx == ast::ExprContext::Load,
        _ => false,
    }
}

/// Returns a stable variant name for diagnostics built from a RustPython AST node.
pub fn expr_variant_name(expr: &ast::Expr) -> &'static str {
    match expr {
        ast::Expr::BoolOp(_) => "BoolOp",
        ast::Expr::NamedExpr(_) => "NamedExpr",
        ast::Expr::BinOp(_) => "BinOp",
        ast::Expr::UnaryOp(_) => "UnaryOp",
        ast::Expr::Lambda(_) => "Lambda",
        ast::Expr::IfExp(_) => "IfExp",
        ast::Expr::Dict(_) => "Dict",
        ast::Expr::Set(_) => "Set",
        ast::Expr::ListComp(_) => "ListComp",
        ast::Expr::SetComp(_) => "SetComp",
        ast::Expr::DictComp(_) => "DictComp",
        ast::Expr::GeneratorExp(_) => "GeneratorExp",
        ast::Expr::Await(_) => "Await",
        ast::Expr::Yield(_) => "Yield",
        ast::Expr::YieldFrom(_) => "YieldFrom",
        ast::Expr::Compare(_) => "Compare",
        ast::Expr::Call(_) => "Call",
        ast::Expr::FormattedValue(_) => "FormattedValue",
        ast::Expr::JoinedStr(_) => "JoinedStr",
        ast::Expr::Constant(_) => "Constant",
        ast::Expr::Attribute(_) => "Attribute",
        ast::Expr::Subscript(_) => "Subscript",
        ast::Expr::Starred(_) => "Starred",
        ast::Expr::Name(_) => "Name",
        ast::Expr::List(_) => "List",
        ast::Expr::Tuple(_) => "Tuple",
        ast::Expr::Slice(_) => "Slice",
    }
}
