use super::*;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum AppIdOperation {
    Register,
    Load,
}

#[cfg(unix)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum PinnedRootOperation {
    Register,
    Load,
}

fn assert_traversal_app_id_rejected(
    storage_root: &std::path::Path,
    project: &str,
    operation: AppIdOperation,
) {
    let tracker = tracker(project, storage_root);

    match operation {
        AppIdOperation::Register => {
            let template_app = build_counter_template_app("template");
            let error = tracker
                .register_application("../escape", Some("pk"), template_app.graph(), None, None)
                .expect_err("traversal app id should be rejected");
            assert!(matches!(error, TrackingError::InvalidAppId { .. }));
        }
        AppIdOperation::Load => {
            let error = tracker
                .load(Some("pk"), Some("../escape"), None)
                .expect_err("traversal app id should fail");
            assert!(matches!(
                error,
                PersistenceError::UnsupportedOperation {
                    operation: "invalid_app_id"
                }
            ));
        }
    }
}

#[cfg(unix)]
fn assert_parent_project_swap_rejected(
    storage_root: &std::path::Path,
    outside: &std::path::Path,
    project: &str,
    operation: PinnedRootOperation,
) {
    use std::os::unix::fs as unix_fs;

    let tracker = tracker(project, storage_root);
    let requested_project_dir = storage_root.join(project);
    let moved_project_dir = storage_root.join(format!("{project}-real"));

    match operation {
        PinnedRootOperation::Register => {
            let template_app = build_counter_template_app("template");
            fs::rename(&requested_project_dir, &moved_project_dir)
                .expect("project dir should move out of the original path");
            unix_fs::symlink(outside, &requested_project_dir)
                .expect("project symlink replacement should be created");

            let error = tracker
                .register_application(
                    "requested-app",
                    Some("pk"),
                    template_app.graph(),
                    None,
                    None,
                )
                .expect_err("swapped project directories must fail closed");
            assert_invalid_input_tracking_io(error);
            assert!(
                !outside.join("requested-app").exists(),
                "registration must not create app directories through the swapped project path"
            );
        }
        PinnedRootOperation::Load => {
            let _ =
                seeded_counter_app_dir(storage_root, project, "requested-app", Some("pk"), 1, 1);

            fs::rename(storage_root.join(project), &moved_project_dir)
                .expect("project dir should move out of the original path");
            unix_fs::symlink(outside, storage_root.join(project))
                .expect("project symlink replacement should be created");

            let error = tracker
                .load(Some("pk"), Some("requested-app"), None)
                .expect_err("swapped project directories must fail closed");
            assert!(matches!(
                error,
                PersistenceError::UnsupportedOperation {
                    operation: "local_tracking_client_io"
                }
            ));
        }
    }
}

#[test]
fn traversal_app_ids_are_rejected_for_register_and_load() {
    for (project, operation) in [
        ("test_reject_traversal_app_id", AppIdOperation::Register),
        ("test_load_rejects_traversal_app_id", AppIdOperation::Load),
    ] {
        let storage_root = rurr_testkit::tempdir::test_dir().expect("temp dir should build");
        assert_traversal_app_id_rejected(&storage_root, project, operation);
    }
}

#[cfg(unix)]
#[test]
fn tracker_initialization_rejects_same_root_project_alias() {
    use std::os::unix::fs as unix_fs;

    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_tracker_init_rejects_same_root_project_alias";
    let real_project_dir = storage_root.join("real-project");
    fs::create_dir_all(&real_project_dir).expect("real project directory should exist");
    unix_fs::symlink(&real_project_dir, storage_root.join(project))
        .expect("project alias should be created");

    let error = match LocalTrackingClient::new(project, &storage_root) {
        Ok(_) => panic!("same-root project aliases must fail closed at initialization"),
        Err(error) => error,
    };
    assert_invalid_input_tracking_io(error);
    assert!(
        !real_project_dir.join("alias-app").exists(),
        "tracker initialization must not write through an aliased project directory"
    );
}

#[cfg(unix)]
#[test]
fn tracker_initialization_accepts_symlinked_storage_root_and_pins_canonical_storage_dir() {
    use std::os::unix::fs as unix_fs;

    let storage_root = test_dir_for_test().expect("temp dir should build");
    let requested_root = storage_root.join("requested-root");
    let real_root = storage_root.join("real-root");
    fs::create_dir_all(&real_root).expect("real storage root should exist");
    unix_fs::symlink(&real_root, &requested_root).expect("storage-root symlink should be created");
    let canonical_root = fs::canonicalize(&real_root).expect("real root should canonicalize");

    let tracker = LocalTrackingClient::new(
        "test_tracker_initialization_accepts_symlinked_storage_root",
        &requested_root,
    )
    .expect("symlinked storage roots should initialize");

    assert_eq!(
        tracker.storage_dir(),
        canonical_root
            .join("test_tracker_initialization_accepts_symlinked_storage_root")
            .as_path()
    );
}

#[cfg(unix)]
#[test]
fn symlinked_storage_root_tracker_stays_pinned_after_requested_path_retarget() {
    use std::os::unix::fs as unix_fs;

    let storage_root = test_dir_for_test().expect("temp dir should build");
    let requested_root = storage_root.join("requested-root");
    let real_root = storage_root.join("real-root");
    let outside_root = storage_root.join("outside-root");
    fs::create_dir_all(&real_root).expect("real storage root should exist");
    fs::create_dir_all(&outside_root).expect("outside storage root should exist");
    unix_fs::symlink(&real_root, &requested_root).expect("storage-root symlink should be created");

    let project = "test_symlinked_storage_root_tracker_stays_pinned";
    let tracker = tracker(project, &requested_root);
    let template_app = build_counter_template_app("template");

    let _ = seeded_counter_app_dir(&requested_root, project, "requested-app", Some("pk"), 1, 1);

    let outside_project_dir = outside_root.join(project);
    let _ = seeded_counter_app_dir(&outside_root, project, "outside-app", Some("pk"), 9, 9);

    fs::remove_file(&requested_root).expect("requested root symlink should be removable");
    unix_fs::symlink(&outside_root, &requested_root).expect("storage-root symlink should retarget");

    tracker
        .register_application("second-app", Some("pk"), template_app.graph(), None, None)
        .expect("tracker should keep writing through the pinned canonical root");

    let loaded = tracker
        .load(Some("pk"), Some("requested-app"), None)
        .expect("load should succeed against the pinned canonical root")
        .expect("requested app should still load");
    let app_ids = tracker
        .list_app_ids(Some("pk"))
        .expect("list_app_ids should succeed against the pinned canonical root");

    assert_eq!(
        loaded
            .state
            .as_ref()
            .expect("loaded state should be present")
            .get("count"),
        Some(&json!(1)),
        "load must stay pinned to the original canonical root"
    );
    assert_eq!(
        app_ids,
        vec!["requested-app".to_string(), "second-app".to_string()],
        "list_app_ids must not switch over to the retargeted symlink root"
    );
    assert!(
        real_root.join(project).join("second-app").is_dir(),
        "new registrations should still materialize under the pinned canonical root"
    );
    assert!(
        !outside_project_dir.join("second-app").exists(),
        "retargeted symlink roots must not receive new tracker writes"
    );
}

#[cfg(unix)]
#[test]
fn parent_project_swaps_after_tracker_initialization_are_rejected_for_register_and_load() {
    for (project, _outside_name, operation) in [
        (
            "test_register_rejects_parent_project_swap_after_tracker_initialization",
            "test_register_rejects_parent_project_swap_after_tracker_initialization-outside",
            PinnedRootOperation::Register,
        ),
        (
            "test_load_rejects_parent_project_swap_after_tracker_initialization",
            "test_load_rejects_parent_project_swap_after_tracker_initialization-outside",
            PinnedRootOperation::Load,
        ),
    ] {
        let storage_root = rurr_testkit::tempdir::test_dir().expect("temp dir should build");
        let outside = rurr_testkit::tempdir::test_dir().expect("outside temp dir should build");
        assert_parent_project_swap_rejected(&storage_root, &outside, project, operation);
    }
}
