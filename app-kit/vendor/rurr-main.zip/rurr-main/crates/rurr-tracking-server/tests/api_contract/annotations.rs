use super::*;

#[derive(Default)]
struct NoAnnotationsBackendStub;

#[async_trait]
impl TrackingBackend for NoAnnotationsBackendStub {
    fn backend_name(&self) -> &'static str {
        "stub"
    }

    async fn list_projects(&self) -> Result<Vec<Project>, BackendError> {
        Ok(Vec::new())
    }

    async fn list_apps(
        &self,
        _project_id: &str,
        _partition_key: Option<&str>,
        limit: usize,
        offset: usize,
    ) -> Result<ApplicationPage, BackendError> {
        Ok(ApplicationPage {
            applications: Vec::new(),
            total: 0,
            has_another_page: total_has_another_page(0, limit, offset),
        })
    }

    async fn read_app(
        &self,
        project_id: &str,
        app_id: &str,
        partition_key: Option<&str>,
    ) -> Result<ApplicationLogs, BackendError> {
        Err(BackendError::NotFound {
            resource: match partition_key {
                Some(partition_key) => format!("app:{project_id}/{app_id}/{partition_key}"),
                None => format!("app:{project_id}/{app_id}"),
            },
        })
    }
}

fn total_has_another_page(total: usize, limit: usize, offset: usize) -> bool {
    total > offset.saturating_add(limit)
}

#[tokio::test]
async fn unsupported_annotation_backend_returns_explicit_errors() {
    let app = rurr_tracking_server::app_with_state(AppState::with_embedded_ui(Arc::new(
        NoAnnotationsBackendStub,
    )));

    let list = annotation_list_request(&app, "proj1", Some("app1"), Some("pk"), Some(0)).await;
    for response in [
        list,
        annotation_create_request(
            &app,
            "proj1",
            "app1",
            "pk",
            0,
            &pointerless_annotation_body("seed", "initial", Some(true)),
        )
        .await,
        annotation_update_request(
            &app,
            "proj1",
            0,
            &pointerless_annotation_body("updated", "updated", Some(false)),
        )
        .await,
    ] {
        let payload = assert_json_error_response(
            response,
            StatusCode::NOT_FOUND,
            "unsupported annotation routes should return json 404 errors",
        )
        .await;
        assert!(
            payload["error"]
                .as_str()
                .is_some_and(|value| value.contains("annotations")),
            "unsupported annotation routes should return a descriptive json error"
        );
    }
}

#[tokio::test]
async fn annotations_routes_create_read_and_update_local_annotations() {
    let (_tempdir, app) = fixture_tempdir_app();

    let create = annotation_create_request(
        &app,
        "proj1",
        "app1",
        "pk",
        0,
        &annotation_body("seed", "initial"),
    )
    .await;
    assert_eq!(create.status(), StatusCode::OK);
    let created = response_json(create).await;
    assert_eq!(created["id"], json!(0));
    assert_eq!(created["project_id"], json!("proj1"));
    assert_eq!(created["app_id"], json!("app1"));
    assert_eq!(created["partition_key"], json!("pk"));
    assert_eq!(created["step_sequence_id"], json!(0));
    assert_eq!(created["tags"], json!(["seed"]));
    assert_eq!(
        created["observations"][0]["data_fields"]["note"],
        json!("initial")
    );
    assert!(
        created["created"]
            .as_str()
            .is_some_and(|value| value.ends_with('Z')),
        "created timestamp should be RFC3339 UTC"
    );
    assert!(
        created["updated"]
            .as_str()
            .is_some_and(|value| value.ends_with('Z')),
        "updated timestamp should be RFC3339 UTC"
    );

    let list = annotation_list_request(&app, "proj1", Some("app1"), Some("pk"), Some(0)).await;
    assert_eq!(list.status(), StatusCode::OK);
    let listed = response_json(list).await;
    let listed_annotations: Vec<AnnotationOut> =
        serde_json::from_value(listed.clone()).expect("annotations should deserialize");
    assert_eq!(listed_annotations.len(), 1);
    assert_eq!(listed_annotations[0].id, 0);
    assert_eq!(listed_annotations[0].project_id, "proj1");
    assert_eq!(listed_annotations[0].app_id, "app1");
    assert_eq!(listed_annotations[0].partition_key.as_deref(), Some("pk"));

    let mut update_body = pointerless_annotation_body("updated", "updated", Some(false));
    update_body["span_id"] = json!("span-1");
    update_body["observations"][0]["data_fields"]["ground_truth"] = json!("expected");
    update_body["observations"][0]["data_pointers"] = json!([{
        "type": "attribute",
        "field_name": "score",
        "span_id": "span-1"
    }]);
    let update = annotation_update_request(&app, "proj1", 0, &update_body).await;
    assert_eq!(update.status(), StatusCode::OK);
    let updated = response_json(update).await;
    assert_eq!(updated["id"], json!(0));
    assert_eq!(updated["tags"], json!(["updated"]));
    assert_eq!(updated["span_id"], json!("span-1"));
    assert_eq!(
        updated["observations"][0]["data_fields"]["ground_truth"],
        json!("expected")
    );

    let list_after_update =
        annotation_list_request(&app, "proj1", Some("app1"), Some("pk"), Some(0)).await;
    assert_eq!(list_after_update.status(), StatusCode::OK);
    let payload = response_json(list_after_update).await;
    assert_eq!(payload.as_array().map(Vec::len), Some(1));
    assert_eq!(payload[0]["tags"], json!(["updated"]));
    assert_eq!(payload[0]["span_id"], json!("span-1"));
}

#[tokio::test]
async fn annotation_update_missing_or_null_tags_normalizes_to_empty_list() {
    for (note, span_id, remove_tags) in [
        ("updated without tags", None, true),
        ("updated with null tags", Some("span-2"), false),
    ] {
        let (_tempdir, app) = fixture_tempdir_app();

        let create = annotation_create_request(
            &app,
            "proj1",
            "app1",
            "pk",
            0,
            &pointerless_annotation_body("seed", "initial", Some(true)),
        )
        .await;
        assert_eq!(create.status(), StatusCode::OK);

        let mut update_body = pointerless_annotation_body("updated", note, Some(false));
        match span_id {
            Some(span_id) => update_body["span_id"] = json!(span_id),
            None => {
                update_body
                    .as_object_mut()
                    .expect("annotation body should be an object")
                    .remove("span_id");
            }
        }
        if remove_tags {
            update_body
                .as_object_mut()
                .expect("annotation body should be an object")
                .remove("tags");
        } else {
            update_body["tags"] = Value::Null;
        }

        let update = annotation_update_request(&app, "proj1", 0, &update_body).await;
        assert_eq!(update.status(), StatusCode::OK);
        let updated = response_json(update).await;
        assert_eq!(updated["tags"], json!([]));
        if let Some(span_id) = span_id {
            assert_eq!(updated["span_id"], json!(span_id));
        }

        let list = annotation_list_request(&app, "proj1", Some("app1"), Some("pk"), Some(0)).await;
        assert_eq!(list.status(), StatusCode::OK);
        let payload = response_json(list).await;
        assert_eq!(payload[0]["tags"], json!([]));
        if let Some(span_id) = span_id {
            assert_eq!(payload[0]["span_id"], json!(span_id));
        }
    }
}

#[tokio::test]
async fn annotation_routes_map_none_partition_sentinel_to_null() {
    let (_tempdir, app) = single_app_tempdir_app("proj_none", "app_none", None);

    let mut create_body = pointerless_annotation_body("seed", "null partition", None);
    create_body["tags"] = json!([]);
    let create =
        annotation_create_request(&app, "proj_none", "app_none", "__none__", 0, &create_body).await;
    assert_eq!(create.status(), StatusCode::OK);
    let created = response_json(create).await;
    assert_eq!(created["partition_key"], Value::Null);

    let list = annotation_list_request(
        &app,
        "proj_none",
        Some("app_none"),
        Some("__none__"),
        Some(0),
    )
    .await;
    assert_eq!(list.status(), StatusCode::OK);
    let payload = response_json(list).await;
    assert_eq!(payload.as_array().map(Vec::len), Some(1));
    assert_eq!(payload[0]["partition_key"], Value::Null);
}

#[tokio::test]
async fn create_annotation_rejects_metadata_missing_type_field() {
    let (_tempdir, app) = local_backend_tempdir_app(|root| {
        build_single_app_fixture(root, "proj_invalid", "app_invalid", Some("pk"));
        write_json(
            &root
                .join("proj_invalid")
                .join("app_invalid")
                .join("metadata.json"),
            &json!({
                "partition_key": "pk",
                "parent_pointer": null,
                "spawning_parent_pointer": null
            }),
        );
    });

    let mut create_body = pointerless_annotation_body("seed", "invalid metadata", None);
    create_body["tags"] = json!([]);
    let create =
        annotation_create_request(&app, "proj_invalid", "app_invalid", "pk", 0, &create_body).await;
    assert_eq!(create.status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn get_annotations_distinguishes_none_partition_filter_from_no_filter() {
    let (_tempdir, app) = local_backend_tempdir_app(|root| {
        build_single_app_fixture(root, "proj_mix", "app_none", None);
        build_single_app_fixture(root, "proj_mix", "app_pk", Some("pk"));
        rurr_testkit::tracking_fixture::write_project_annotations(
            root,
            "proj_mix",
            &[
                annotation_out_json(0, "proj_mix", "app_none", None, 0, "none"),
                annotation_out_json(1, "proj_mix", "app_pk", Some("pk"), 1, "pk"),
            ],
        );
    });

    for (partition_key, expected_app_id, expected_partition_key) in [
        (Some("__none__"), "app_none", Value::Null),
        (Some("pk"), "app_pk", json!("pk")),
    ] {
        let response = annotation_list_request(&app, "proj_mix", None, partition_key, None).await;
        assert_eq!(response.status(), StatusCode::OK);
        let payload = response_json(response).await;
        assert_eq!(payload.as_array().map(Vec::len), Some(1));
        assert_eq!(payload[0]["app_id"], json!(expected_app_id));
        assert_eq!(payload[0]["partition_key"], expected_partition_key);
    }

    let all_annotations = annotation_list_request(&app, "proj_mix", None, None, None).await;
    assert_eq!(all_annotations.status(), StatusCode::OK);
    let all_annotations_payload = response_json(all_annotations).await;
    assert_eq!(all_annotations_payload.as_array().map(Vec::len), Some(2));
}

#[tokio::test]
async fn create_annotation_accepts_valid_final_json_without_trailing_newline() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    build_single_app_fixture(
        tempdir.path(),
        DEFAULT_PROJECT_ID,
        DEFAULT_APP_ID,
        Some(DEFAULT_PARTITION_KEY),
    );
    let annotation_path = default_annotation_path(tempdir.path());
    fs::write(
        &annotation_path,
        serde_json::to_string(&annotation_out_json(
            0,
            DEFAULT_PROJECT_ID,
            DEFAULT_APP_ID,
            Some(DEFAULT_PARTITION_KEY),
            0,
            "seed",
        ))
        .expect("seed annotation should serialize"),
    )
    .expect("annotation file should be written");

    let app = local_backend_app(tempdir.path());
    let create = annotation_create_request(
        &app,
        DEFAULT_PROJECT_ID,
        DEFAULT_APP_ID,
        DEFAULT_PARTITION_KEY,
        0,
        &pointerless_annotation_body("new", "created", Some(true)),
    )
    .await;
    assert_eq!(create.status(), StatusCode::OK);
    let created = response_json(create).await;
    assert_eq!(created["id"], json!(1));

    let persisted = fs::read_to_string(&annotation_path).expect("annotation file should read");
    assert!(persisted.ends_with('\n'));
    let parsed = persisted
        .lines()
        .map(|line| serde_json::from_str::<AnnotationOut>(line).expect("line should parse"))
        .collect::<Vec<_>>();
    assert_eq!(parsed.len(), 2);
    assert_eq!(parsed[0].id, 0);
    assert_eq!(parsed[1].id, 1);
}

#[tokio::test]
async fn annotation_routes_reject_truncated_final_json_and_preserve_file() {
    for kind in [
        AnnotationRequestKind::List,
        AnnotationRequestKind::Create,
        AnnotationRequestKind::Update,
    ] {
        let tempdir = tempfile::tempdir().expect("tempdir should be created");
        build_single_app_fixture(
            tempdir.path(),
            DEFAULT_PROJECT_ID,
            DEFAULT_APP_ID,
            Some(DEFAULT_PARTITION_KEY),
        );
        rurr_testkit::tracking_fixture::write_project_annotations(
            tempdir.path(),
            DEFAULT_PROJECT_ID,
            &[annotation_out_json(
                DEFAULT_ANNOTATION_ID,
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
                DEFAULT_STEP_SEQUENCE_ID,
                "seed",
            )],
        );
        let annotation_path = default_annotation_path(tempdir.path());
        let mut annotations_file = fs::OpenOptions::new()
            .append(true)
            .open(&annotation_path)
            .expect("annotation file should open");
        annotations_file
            .write_all(br#"{"id":99,"project_id":"proj1","app_id":"app1""#)
            .expect("truncated annotation should append");
        drop(annotations_file);
        let before = fs::read_to_string(&annotation_path).expect("annotation file should read");

        let app = local_backend_app(tempdir.path());
        let response = default_annotation_request(&app, kind).await;
        assert_json_error_response(
            response,
            StatusCode::BAD_REQUEST,
            "truncated annotation JSONL should be rejected",
        )
        .await;

        let after = fs::read_to_string(&annotation_path).expect("annotation file should read");
        assert_eq!(
            after, before,
            "rejected annotation request must not rewrite the file"
        );
    }
}

#[cfg(unix)]
#[tokio::test]
#[allow(clippy::await_holding_lock)]
async fn annotation_requests_reject_unsafe_filesystem_mutations() {
    for (mutation, kinds) in [
        (
            AnnotationFilesystemMutation::SymlinkEscape,
            &[
                AnnotationRequestKind::Create,
                AnnotationRequestKind::List,
                AnnotationRequestKind::Update,
            ][..],
        ),
        (
            AnnotationFilesystemMutation::CrossProjectAlias,
            &[AnnotationRequestKind::List, AnnotationRequestKind::Create],
        ),
        (
            AnnotationFilesystemMutation::ParentProjectSwap,
            &[
                AnnotationRequestKind::List,
                AnnotationRequestKind::Create,
                AnnotationRequestKind::Update,
            ][..],
        ),
    ] {
        for kind in kinds {
            assert_annotation_filesystem_mutation_rejected(*kind, mutation).await;
        }
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn local_annotation_creates_wait_for_locked_file_and_allocate_distinct_ids() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    build_single_app_fixture(tempdir.path(), "proj1", "app1", Some("pk"));
    let backend = Arc::new(LocalBackend::new(tempdir.path()).expect("local backend should build"));
    let annotation_path = tempdir.path().join("proj1").join("annotations.jsonl");
    fs::write(&annotation_path, "").expect("annotation file should be created");

    let lock_file = fs::OpenOptions::new()
        .create(true)
        .read(true)
        .write(true)
        .truncate(false)
        .open(&annotation_path)
        .expect("annotation file should open");
    lock_file
        .lock_exclusive()
        .expect("annotation file should lock exclusively");

    let backend_one = backend.clone();
    let (attempt_one_tx, attempt_one_rx) = tokio::sync::oneshot::channel();
    let create_one = tokio::spawn(async move {
        let _ = attempt_one_tx.send(());
        backend_one
            .create_annotation(
                sample_annotation("first", "note-1"),
                "proj1",
                Some("pk"),
                "app1",
                0,
            )
            .await
    });
    let backend_two = backend.clone();
    let (attempt_two_tx, attempt_two_rx) = tokio::sync::oneshot::channel();
    let create_two = tokio::spawn(async move {
        let _ = attempt_two_tx.send(());
        backend_two
            .create_annotation(
                sample_annotation("second", "note-2"),
                "proj1",
                Some("pk"),
                "app1",
                0,
            )
            .await
    });

    attempt_one_rx
        .await
        .expect("first create task should signal request start");
    attempt_two_rx
        .await
        .expect("second create task should signal request start");
    assert!(
        !create_one.is_finished() && !create_two.is_finished(),
        "annotation creation should participate in the project annotation file lock"
    );

    lock_file
        .unlock()
        .expect("annotation file lock should release cleanly");

    let created_one = create_one
        .await
        .expect("first task should join")
        .expect("first annotation create should succeed");
    let created_two = create_two
        .await
        .expect("second task should join")
        .expect("second annotation create should succeed");

    let mut ids = vec![created_one.id, created_two.id];
    ids.sort_unstable();
    assert_eq!(
        ids,
        vec![0, 1],
        "concurrent creates must allocate unique ids"
    );

    let persisted = fs::read_to_string(&annotation_path).expect("annotation file should read");
    assert_eq!(
        persisted.lines().count(),
        2,
        "concurrent creates must not drop annotation lines"
    );
}

#[tokio::test(flavor = "multi_thread", worker_threads = 4)]
async fn local_annotation_reads_wait_for_exclusive_writer_and_return_complete_file() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    build_single_app_fixture(tempdir.path(), "proj1", "app1", Some("pk"));
    let backend = Arc::new(LocalBackend::new(tempdir.path()).expect("local backend should build"));
    let annotation_path = tempdir.path().join("proj1").join("annotations.jsonl");
    write_jsonl(
        &annotation_path,
        &[
            annotation_out_json(0, "proj1", "app1", Some("pk"), 0, "one"),
            annotation_out_json(1, "proj1", "app1", Some("pk"), 0, "two"),
        ],
    );

    let lock_file = fs::OpenOptions::new()
        .create(false)
        .read(true)
        .write(true)
        .truncate(false)
        .open(&annotation_path)
        .expect("annotation file should open");
    lock_file
        .lock_exclusive()
        .expect("annotation file should lock exclusively");

    let backend_reader = backend.clone();
    let (attempt_tx, attempt_rx) = tokio::sync::oneshot::channel();
    let read_task = tokio::spawn(async move {
        let _ = attempt_tx.send(());
        backend_reader
            .get_annotations(
                "proj1",
                PartitionSelector::Exact("pk".to_string()),
                Some("app1"),
                Some(0),
            )
            .await
    });

    attempt_rx
        .await
        .expect("read task should signal request start");
    assert!(
        !read_task.is_finished(),
        "annotation reads should wait for the same file lock used by writers"
    );

    lock_file
        .unlock()
        .expect("annotation file lock should release cleanly");

    let annotations = read_task
        .await
        .expect("read task should join")
        .expect("annotation read should succeed");
    assert_eq!(annotations.len(), 2);
    assert_eq!(annotations[0].id, 0);
    assert_eq!(annotations[1].id, 1);
}

#[test]
fn annotation_lock_wait_does_not_stall_single_worker_runtime() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    build_single_app_fixture(tempdir.path(), "proj1", "app1", Some("pk"));
    let app = local_backend_app(tempdir.path());
    let annotation_path = tempdir.path().join("proj1").join("annotations.jsonl");
    fs::write(&annotation_path, "").expect("annotation file should be created");

    let lock_file = fs::OpenOptions::new()
        .create(true)
        .read(true)
        .write(true)
        .truncate(false)
        .open(&annotation_path)
        .expect("annotation file should open");
    lock_file
        .lock_exclusive()
        .expect("annotation file should lock exclusively");

    let runtime = tokio::runtime::Builder::new_multi_thread()
        .worker_threads(1)
        .enable_all()
        .build()
        .expect("runtime should build");
    let runtime_handle = runtime.handle().clone();

    let (blocked_tx, blocked_rx) = mpsc::channel();
    let (request_started_tx, request_started_rx) = mpsc::channel();
    runtime_handle.spawn({
        let app = app.clone();
        let blocked_tx = blocked_tx.clone();
        let request_started_tx = request_started_tx.clone();
        async move {
            request_started_tx
                .send(())
                .expect("blocked request start signal should send");
            let response = annotation_create_request(
                &app,
                "proj1",
                "app1",
                "pk",
                0,
                &pointerless_annotation_body("seed", "initial", Some(true)),
            )
            .await;
            blocked_tx
                .send(response.status())
                .expect("blocked request result should send");
        }
    });

    request_started_rx
        .recv_timeout(Duration::from_secs(1))
        .expect("blocked request should start before ready probe");

    let (ready_tx, ready_rx) = mpsc::channel();
    runtime_handle.spawn(async move {
        let response = app
            .oneshot(
                Request::builder()
                    .uri("/ready")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await;
        ready_tx
            .send(response.map(|response| response.status()))
            .expect("ready request result should send");
    });

    let ready_result = ready_rx.recv_timeout(Duration::from_millis(200));

    lock_file
        .unlock()
        .expect("annotation file lock should release cleanly");

    let blocked_response = blocked_rx
        .recv_timeout(Duration::from_secs(1))
        .expect("blocked request should finish after the lock releases");
    assert_eq!(blocked_response, StatusCode::OK);

    let ready_response = ready_result
        .expect("ready endpoint should stay responsive while the annotation request waits")
        .expect("ready request should succeed");
    assert_eq!(ready_response, StatusCode::OK);
}
