use super::api::{RurrError, StreamItem, StreamOutput};
use crate::state::State;
use futures::stream::BoxStream;
use futures::{Stream, StreamExt};
use std::pin::Pin;
use std::task::{Context, Poll};

type FinalizePayload = (Option<StreamItem>, State);
type FinalizeCallback<'a> = Box<dyn FnMut(Option<StreamItem>, State, Option<RurrError>) + 'a>;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ContainerPhase {
    Streaming,
    Done,
}

#[derive(Debug, Clone, PartialEq)]
enum ContainerTerminal {
    Missing,
    Ready(FinalizePayload),
}

struct ContainerState<'a> {
    initial_state: State,
    terminal: ContainerTerminal,
    callback: Option<FinalizeCallback<'a>>,
    error: Option<RurrError>,
    phase: ContainerPhase,
}

impl<'a> ContainerState<'a> {
    fn new(
        initial_state: State,
        callback: impl FnMut(Option<StreamItem>, State, Option<RurrError>) + 'a,
    ) -> Self {
        Self {
            initial_state,
            terminal: ContainerTerminal::Missing,
            callback: Some(Box::new(callback)),
            error: None,
            phase: ContainerPhase::Streaming,
        }
    }

    fn is_done(&self) -> bool {
        matches!(self.phase, ContainerPhase::Done)
    }

    fn terminal_or_initial(&self) -> FinalizePayload {
        match &self.terminal {
            ContainerTerminal::Ready(terminal) => terminal.clone(),
            ContainerTerminal::Missing => (None, self.initial_state.clone()),
        }
    }

    fn mark_done_with_terminal(&mut self, terminal: FinalizePayload) {
        self.terminal = ContainerTerminal::Ready(terminal);
        self.phase = ContainerPhase::Done;
    }

    fn mark_done_with_error(&mut self, error: RurrError) {
        self.error = Some(error);
        self.phase = ContainerPhase::Done;
    }

    fn mark_done_without_terminal(&mut self) {
        self.phase = ContainerPhase::Done;
    }

    fn finish_get(&mut self) -> Result<FinalizePayload, RurrError> {
        self.finalize_once(self.error.clone());
        if let Some(error) = &self.error {
            return Err(error.clone());
        }
        Ok(self.terminal_or_initial())
    }

    fn consume_output(
        &mut self,
        output: Option<StreamOutput>,
    ) -> Option<Result<StreamItem, RurrError>> {
        match output {
            Some(Ok((item, None))) => Some(Ok(item)),
            Some(Ok((item, Some(state)))) => {
                self.mark_done_with_terminal((Some(item), state));
                self.finalize_once(None);
                None
            }
            Some(Err(error)) => {
                self.mark_done_with_error(error.clone());
                self.finalize_once(Some(error.clone()));
                Some(Err(error))
            }
            None => {
                self.mark_done_without_terminal();
                self.finalize_once(None);
                None
            }
        }
    }

    fn finalize_once(&mut self, error: Option<RurrError>) {
        if matches!(self.terminal, ContainerTerminal::Missing) {
            self.terminal = ContainerTerminal::Ready((None, self.initial_state.clone()));
        }

        if let Some(mut callback) = self.callback.take() {
            let (result, state) = self.terminal_or_initial();
            callback(result, state, error);
        }
    }
}

/// Iterator adapter that finalizes a sync streaming action exactly once.
pub struct StreamingResultContainer<'a, I>
where
    I: Iterator<Item = StreamOutput>,
{
    stream: I,
    state: ContainerState<'a>,
}

impl<'a, I> StreamingResultContainer<'a, I>
where
    I: Iterator<Item = StreamOutput>,
{
    /// Wraps a sync stream with terminal-state tracking and a finalize callback.
    pub fn new(
        stream: I,
        initial_state: State,
        callback: impl FnMut(Option<StreamItem>, State, Option<RurrError>) + 'a,
    ) -> Self {
        Self {
            stream,
            state: ContainerState::new(initial_state, callback),
        }
    }

    /// Drains the stream and returns the terminal `(last_item, state)` payload.
    pub fn get(&mut self) -> Result<FinalizePayload, RurrError> {
        for item in self.by_ref() {
            item?;
        }
        self.state.finish_get()
    }
}

impl<'a, I> Iterator for StreamingResultContainer<'a, I>
where
    I: Iterator<Item = StreamOutput>,
{
    type Item = Result<StreamItem, RurrError>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.state.is_done() {
            return None;
        }
        self.state.consume_output(self.stream.next())
    }
}

impl<'a, I> Drop for StreamingResultContainer<'a, I>
where
    I: Iterator<Item = StreamOutput>,
{
    fn drop(&mut self) {
        self.state.finalize_once(None);
    }
}

/// Stream adapter that finalizes an async streaming action exactly once.
#[must_use]
pub struct AsyncStreamingResultContainer<'a> {
    stream: BoxStream<'a, StreamOutput>,
    state: ContainerState<'a>,
}

impl<'a> AsyncStreamingResultContainer<'a> {
    /// Wraps an async stream with terminal-state tracking and a finalize
    /// callback.
    pub fn new(
        stream: BoxStream<'a, StreamOutput>,
        initial_state: State,
        callback: impl FnMut(Option<StreamItem>, State, Option<RurrError>) + 'a,
    ) -> Self {
        Self {
            stream,
            state: ContainerState::new(initial_state, callback),
        }
    }

    /// Drains the async stream and returns the terminal `(last_item, state)`
    /// payload.
    pub async fn get(&mut self) -> Result<FinalizePayload, RurrError> {
        while let Some(item) = self.next().await {
            item?;
        }
        self.state.finish_get()
    }
}

impl<'a> Stream for AsyncStreamingResultContainer<'a> {
    type Item = Result<StreamItem, RurrError>;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let this = self.get_mut();

        if this.state.is_done() {
            return Poll::Ready(None);
        }

        match this.stream.as_mut().poll_next(cx) {
            Poll::Pending => Poll::Pending,
            Poll::Ready(output) => Poll::Ready(this.state.consume_output(output)),
        }
    }
}

impl Drop for AsyncStreamingResultContainer<'_> {
    fn drop(&mut self) {
        self.state.finalize_once(None);
    }
}
