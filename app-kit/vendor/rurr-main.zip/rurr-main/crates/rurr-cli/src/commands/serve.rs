use crate::{ServeArgs, ServeBackend, ServeS3AddressingStyle};
use rurr_core::tracking::{S3AddressingStyle, S3Prefix};
use rurr_telemetry::capture_cli_command;
use rurr_tracking_server::backend::local::LocalBackend;
use rurr_tracking_server::backend::s3::{S3Backend, S3BackendConfig, S3BackendConfigOverrides};
use rurr_tracking_server::backend::{BackendError, TrackingBackend};
use rurr_tracking_server::router::AppState;
use std::io::{self, Write};
use std::net::{SocketAddr, ToSocketAddrs};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::watch;
use tokio::task::JoinHandle;

pub(crate) async fn run(args: ServeArgs) -> Result<(), Box<dyn std::error::Error>> {
    let running = start_server(args, |_| capture_cli_command("serve")).await?;
    running.wait().await
}

async fn start_server(
    args: ServeArgs,
    on_started: impl FnOnce(&str),
) -> Result<RunningServe, Box<dyn std::error::Error>> {
    let should_open = should_open_browser(&args);
    let BuiltBackend {
        backend,
        maintenance,
    } = build_backend(&args).await?;
    let ui_dir_override = resolve_ui_dir_override(args.ui_dir);
    let state = match ui_dir_override {
        Some(ui_dir) => AppState::with_ui_dir(backend, ui_dir)?,
        None => AppState::with_embedded_ui(backend),
    };
    let app = rurr_tracking_server::app_with_state(state);

    let addresses = resolve_bind_addresses(&args.host, args.port)?;
    let listener = bind_listener_for_addresses(&addresses).await?;
    let local_addr = listener.local_addr()?;
    let url = format!("http://{local_addr}");
    println!("rurr serve listening at {url}");
    io::stdout().flush()?;
    let server = tokio::spawn(async move { axum::serve(listener, app).await });
    on_started(&url);

    if should_open {
        let _ = webbrowser::open(&url);
    }

    Ok(RunningServe {
        server,
        _maintenance: maintenance,
    })
}

struct RunningServe {
    server: JoinHandle<io::Result<()>>,
    _maintenance: BackendMaintenance,
}

impl RunningServe {
    async fn wait(self) -> Result<(), Box<dyn std::error::Error>> {
        self.server.await??;
        Ok(())
    }

    #[cfg(test)]
    async fn abort(self) {
        let Self {
            server,
            _maintenance,
        } = self;
        server.abort();
        let _ = server.await;
    }
}

async fn build_backend(args: &ServeArgs) -> Result<BuiltBackend, Box<dyn std::error::Error>> {
    match resolve_backend_kind(args)? {
        ServeBackend::Local => {
            let storage_dir = match &args.storage_dir {
                Some(storage_dir) => storage_dir.clone(),
                None => rurr_tracking_server::default_storage_dir()?,
            };
            Ok(BuiltBackend {
                backend: Arc::new(LocalBackend::new(storage_dir)?),
                maintenance: BackendMaintenance::empty(),
            })
        }
        ServeBackend::S3 => {
            let config = resolve_s3_config(args)?;
            let backend = Arc::new(S3Backend::new(config).await?);
            backend.update_index().await?;
            backend.snapshot().await?;
            let maintenance = start_s3_maintenance(Arc::clone(&backend));
            Ok(BuiltBackend {
                backend,
                maintenance,
            })
        }
    }
}

fn resolve_backend_kind(args: &ServeArgs) -> Result<ServeBackend, BackendError> {
    if let Some(backend) = args.backend {
        return Ok(backend);
    }
    let value = std::env::var("RURR_TRACKING_BACKEND")
        .ok()
        .or_else(|| std::env::var("BURR_BACKEND_IMPL").ok())
        .unwrap_or_else(|| "local".to_string());
    parse_backend_kind(&value)
}

fn parse_backend_kind(value: &str) -> Result<ServeBackend, BackendError> {
    match value {
        "local" | "burr.tracking.server.backend.LocalBackend" => Ok(ServeBackend::Local),
        "s3" | "burr.tracking.server.s3.backend.SQLiteS3Backend" => Ok(ServeBackend::S3),
        other => Err(BackendError::Configuration {
            message: format!("unsupported tracking backend '{other}'"),
        }),
    }
}

fn resolve_s3_config(args: &ServeArgs) -> Result<S3BackendConfig, BackendError> {
    let default_db_path = args
        .storage_dir
        .as_ref()
        .map(|path| path.join("s3-index.sqlite3"))
        .unwrap_or(
            rurr_tracking_server::default_storage_dir()
                .map_err(|error| BackendError::Configuration {
                    message: error.to_string(),
                })?
                .join("s3-index.sqlite3"),
        );
    S3BackendConfig::from_env_and_overrides(
        default_db_path,
        S3BackendConfigOverrides {
            db_path: args.s3_db_path.clone(),
            bucket: args.s3_bucket.clone(),
            region: args.s3_region.clone(),
            endpoint_url: args.s3_endpoint_url.clone(),
            addressing_style: args.s3_addressing_style.map(S3AddressingStyle::from),
            data_prefix: args
                .s3_data_prefix
                .clone()
                .map(S3Prefix::new)
                .transpose()
                .map_err(config_layout_error)?,
            snapshot_prefix: args
                .s3_snapshot_prefix
                .clone()
                .map(S3Prefix::new)
                .transpose()
                .map_err(config_layout_error)?,
            load_snapshot_on_start: args.s3_load_snapshot_on_start,
            prior_snapshots_to_keep: args.s3_prior_snapshots_to_keep,
            max_paths_per_project: args.s3_max_paths_per_project,
            aws_max_concurrency: args.s3_aws_max_concurrency,
            list_page_size: args.s3_list_page_size.map(Some),
            update_interval: args.s3_update_interval_ms.map(Duration::from_millis),
            snapshot_interval: args.s3_snapshot_interval_ms.map(Duration::from_millis),
            access_key_id: args.s3_access_key_id.clone(),
            secret_access_key: args.s3_secret_access_key.clone(),
            session_token: args.s3_session_token.clone(),
        },
    )
}

impl From<ServeS3AddressingStyle> for S3AddressingStyle {
    fn from(value: ServeS3AddressingStyle) -> Self {
        match value {
            ServeS3AddressingStyle::VirtualHosted => Self::VirtualHosted,
            ServeS3AddressingStyle::PathStyle => Self::PathStyle,
        }
    }
}

fn config_layout_error(error: rurr_core::tracking::S3LayoutError) -> BackendError {
    BackendError::Configuration {
        message: error.to_string(),
    }
}

struct BuiltBackend {
    backend: Arc<dyn TrackingBackend>,
    maintenance: BackendMaintenance,
}

struct BackendMaintenance {
    shutdown: Option<watch::Sender<bool>>,
    handle: Option<JoinHandle<()>>,
}

impl BackendMaintenance {
    fn empty() -> Self {
        Self {
            shutdown: None,
            handle: None,
        }
    }
}

impl Drop for BackendMaintenance {
    fn drop(&mut self) {
        if let Some(shutdown) = self.shutdown.take() {
            let _ = shutdown.send(true);
        }
        if let Some(handle) = &self.handle {
            handle.abort();
        }
    }
}

fn start_s3_maintenance(backend: Arc<S3Backend>) -> BackendMaintenance {
    let (shutdown, shutdown_rx) = watch::channel(false);
    let update_interval = backend.config().indexing.update_interval;
    let snapshot_interval = backend.config().indexing.snapshot_interval;
    let handle = tokio::spawn(periodic_s3_maintenance_loop(
        backend,
        shutdown_rx,
        update_interval,
        snapshot_interval,
    ));
    BackendMaintenance {
        shutdown: Some(shutdown),
        handle: Some(handle),
    }
}

async fn periodic_s3_maintenance_loop(
    backend: Arc<S3Backend>,
    mut shutdown: watch::Receiver<bool>,
    update_interval: Duration,
    snapshot_interval: Duration,
) {
    let mut update_tick = tokio::time::interval(update_interval);
    update_tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
    update_tick.tick().await;
    let mut snapshot_tick = tokio::time::interval(snapshot_interval);
    snapshot_tick.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Delay);
    snapshot_tick.tick().await;
    loop {
        tokio::select! {
            changed = shutdown.changed() => {
                if changed.is_err() || *shutdown.borrow() {
                    break;
                }
            }
            _ = update_tick.tick() => {
                if let Err(error) = backend.update_index().await {
                    eprintln!("periodic S3 index failed: {error}");
                }
            }
            _ = snapshot_tick.tick() => {
                if let Err(error) = backend.snapshot().await {
                    eprintln!("periodic S3 snapshot failed: {error}");
                }
            }
        }
    }
}

fn should_open_browser(args: &ServeArgs) -> bool {
    args.open || !args.no_open
}

fn resolve_ui_dir_override(ui_dir: Option<PathBuf>) -> Option<PathBuf> {
    ui_dir
}

fn resolve_bind_addresses(host: &str, port: u16) -> Result<Vec<SocketAddr>, io::Error> {
    let candidates = (host, port).to_socket_addrs()?.collect::<Vec<_>>();
    if candidates.is_empty() {
        return Err(io::Error::new(
            io::ErrorKind::AddrNotAvailable,
            format!("no socket addresses resolved for host '{host}' and port {port}"),
        ));
    }
    Ok(candidates)
}

async fn bind_listener_for_addresses(
    addresses: &[SocketAddr],
) -> Result<tokio::net::TcpListener, io::Error> {
    let mut last_error = None;
    for address in addresses {
        match tokio::net::TcpListener::bind(address).await {
            Ok(listener) => return Ok(listener),
            Err(error) => last_error = Some((address, error)),
        }
    }

    match last_error {
        Some((address, error)) => Err(io::Error::new(
            error.kind(),
            format!("failed to bind any resolved address; last failure on {address}: {error}"),
        )),
        None => Err(io::Error::new(
            io::ErrorKind::AddrNotAvailable,
            "no candidate bind addresses were provided",
        )),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rurr_testkit::env::EnvVarGuard;
    use std::sync::atomic::{AtomicBool, Ordering};

    fn default_serve_args() -> ServeArgs {
        ServeArgs {
            backend: None,
            host: "127.0.0.1".to_string(),
            port: 7241,
            storage_dir: None,
            ui_dir: None,
            s3_bucket: None,
            s3_region: None,
            s3_endpoint_url: None,
            s3_addressing_style: None,
            s3_db_path: None,
            s3_access_key_id: None,
            s3_secret_access_key: None,
            s3_session_token: None,
            s3_data_prefix: None,
            s3_snapshot_prefix: None,
            s3_load_snapshot_on_start: None,
            s3_prior_snapshots_to_keep: None,
            s3_update_interval_ms: None,
            s3_snapshot_interval_ms: None,
            s3_max_paths_per_project: None,
            s3_aws_max_concurrency: None,
            s3_list_page_size: None,
            open: false,
            no_open: false,
        }
    }

    #[test]
    fn resolves_ipv6_loopback_bind_target() {
        let resolved = resolve_bind_addresses("::1", 7241)
            .expect("ipv6 bind target should resolve")
            .into_iter()
            .find(|candidate| candidate.is_ipv6())
            .expect("resolved list should include ipv6");
        assert!(
            resolved.is_ipv6(),
            "resolved address should be ipv6: {resolved}"
        );
        assert_eq!(resolved.port(), 7241);
    }

    #[test]
    fn resolves_ipv4_loopback_bind_target() {
        let resolved = resolve_bind_addresses("127.0.0.1", 7241)
            .expect("ipv4 bind target should resolve")
            .into_iter()
            .find(|candidate| candidate.is_ipv4())
            .expect("resolved list should include ipv4");
        assert!(
            resolved.is_ipv4(),
            "resolved address should be ipv4: {resolved}"
        );
        assert_eq!(resolved.port(), 7241);
    }

    #[tokio::test]
    async fn bind_falls_back_to_next_candidate_when_first_fails() {
        let reserved = match std::net::TcpListener::bind(("127.0.0.1", 0)) {
            Ok(listener) => listener,
            Err(error) if error.kind() == std::io::ErrorKind::PermissionDenied => {
                // Some sandboxed environments deny opening listeners in tests.
                // Skip this environment-specific bind assertion in that case.
                return;
            }
            Err(error) => panic!("reserved listener should bind: {error}"),
        };
        let reserved_addr = reserved
            .local_addr()
            .expect("reserved listener should expose local address");
        let secondary = SocketAddr::from(([127, 0, 0, 1], 0));

        let listener = bind_listener_for_addresses(&[reserved_addr, secondary])
            .await
            .expect("bind should select the second candidate");
        assert_ne!(
            listener
                .local_addr()
                .expect("listener should expose local address"),
            reserved_addr,
            "secondary listener should not use the reserved first address"
        );
    }

    #[tokio::test]
    async fn startup_callback_runs_after_successful_bind_without_waiting_for_shutdown() {
        let _env = EnvVarGuard::set([("RURR_TRACKING_BACKEND", None), ("BURR_BACKEND_IMPL", None)]);
        let storage_dir = tempfile::tempdir().expect("serve storage dir should exist");
        let called = Arc::new(AtomicBool::new(false));
        let observed_url = Arc::new(std::sync::Mutex::new(None::<String>));
        let args = ServeArgs {
            port: 0,
            storage_dir: Some(storage_dir.path().join("tracking")),
            no_open: true,
            ..default_serve_args()
        };

        let running = start_server(args, {
            let called = Arc::clone(&called);
            let observed_url = Arc::clone(&observed_url);
            move |url| {
                called.store(true, Ordering::SeqCst);
                *observed_url
                    .lock()
                    .expect("observed_url lock should not be poisoned") = Some(url.to_string());
            }
        })
        .await
        .expect("server should bind and run startup callback");

        assert!(
            called.load(Ordering::SeqCst),
            "startup callback should run before waiting for server shutdown"
        );
        let url = observed_url
            .lock()
            .expect("observed_url lock should not be poisoned")
            .clone()
            .expect("startup callback should receive the listening URL");
        assert!(
            url.starts_with("http://127.0.0.1:"),
            "startup URL should use the actual ephemeral listener address: {url}"
        );
        running.abort().await;
    }

    #[test]
    fn resolve_ui_source_defaults_to_embedded() {
        assert!(resolve_ui_dir_override(None).is_none());
    }

    #[test]
    fn browser_open_defaults_to_true_and_honors_overrides() {
        let defaults = default_serve_args();
        assert!(
            should_open_browser(&defaults),
            "browser open should default to true when no explicit flag is provided"
        );

        let open_explicit = ServeArgs {
            open: true,
            ..defaults.clone()
        };
        assert!(should_open_browser(&open_explicit));

        let no_open_explicit = ServeArgs {
            no_open: true,
            ..defaults
        };
        assert!(!should_open_browser(&no_open_explicit));
    }

    #[test]
    fn backend_env_accepts_burr_class_paths() {
        for (backend, expected) in [
            (
                "burr.tracking.server.s3.backend.SQLiteS3Backend",
                ServeBackend::S3,
            ),
            (
                "burr.tracking.server.backend.LocalBackend",
                ServeBackend::Local,
            ),
        ] {
            let _env = EnvVarGuard::set([
                ("RURR_TRACKING_BACKEND", None),
                ("BURR_BACKEND_IMPL", Some(backend)),
            ]);
            assert_eq!(
                resolve_backend_kind(&default_serve_args()).expect("class path should parse"),
                expected
            );
        }
    }

    #[test]
    fn s3_config_uses_cli_over_env() {
        let _env = EnvVarGuard::set([
            ("RURR_S3_BUCKET", Some("env-bucket")),
            ("RURR_S3_REGION", Some("env-region")),
            ("RURR_S3_ACCESS_KEY_ID", Some("env-access")),
            ("RURR_S3_SECRET_ACCESS_KEY", Some("env-secret")),
            ("RURR_S3_SESSION_TOKEN", None),
            ("RURR_S3_LIST_PAGE_SIZE", Some("0")),
        ]);
        let storage_dir = tempfile::tempdir().expect("tempdir should exist");
        let args = ServeArgs {
            backend: Some(ServeBackend::S3),
            storage_dir: Some(storage_dir.path().to_path_buf()),
            s3_bucket: Some("cli-bucket".to_string()),
            s3_region: Some("cli-region".to_string()),
            s3_access_key_id: Some("cli-access".to_string()),
            s3_secret_access_key: Some("cli-secret".to_string()),
            s3_addressing_style: Some(ServeS3AddressingStyle::PathStyle),
            s3_list_page_size: Some(2),
            ..default_serve_args()
        };

        let config = resolve_s3_config(&args).expect("CLI overrides should parse");

        assert_eq!(config.transport.bucket(), "cli-bucket");
        assert_eq!(config.transport.region(), "cli-region");
        let credentials = config
            .transport
            .credentials("test")
            .expect("CLI credentials should parse");
        assert_eq!(credentials.access_key_id(), "cli-access");
        assert_eq!(credentials.secret_access_key(), "cli-secret");
        assert_eq!(
            config.transport.addressing_style(),
            S3AddressingStyle::PathStyle
        );
        assert_eq!(config.indexing.list_page_size, Some(2));
    }

    #[test]
    fn s3_config_reports_missing_required_values() {
        let _env = EnvVarGuard::set([
            ("RURR_S3_BUCKET", None),
            ("BURR_S3_BUCKET", None),
            ("RURR_S3_REGION", None),
            ("AWS_REGION", None),
            ("AWS_DEFAULT_REGION", None),
            ("RURR_S3_ACCESS_KEY_ID", None),
            ("RURR_S3_SECRET_ACCESS_KEY", None),
            ("RURR_S3_SESSION_TOKEN", None),
            ("AWS_ACCESS_KEY_ID", None),
            ("AWS_SECRET_ACCESS_KEY", None),
            ("AWS_SESSION_TOKEN", None),
        ]);
        let args = ServeArgs {
            backend: Some(ServeBackend::S3),
            ..default_serve_args()
        };

        let error = resolve_s3_config(&args).expect_err("missing config should fail");

        assert!(error.to_string().contains("missing S3 bucket"));
    }
}
