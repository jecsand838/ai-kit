use super::*;
use super::{actions::*, fixtures::*, graphs::*, hooks::*};

#[test]
fn cascade_none_keeps_parent_state_unmodified() {
    let graph = runnable_graph_from_action(
        "child",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(9))]))
            .expect("action should build"),
    );

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(vec![graph], Arc::new(|state, _ctx| Ok(state.clone()))),
        vec!["sentinel".to_string()],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("sentinel", json!("keep"))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(output.state.get("sentinel"), Some(&json!("keep")));
    assert!(output.state.get("merged_outputs").is_none());
}

#[test]
fn cascade_fixed_merges_all_child_outputs() {
    let graphs = three_constant_output_sync_child_graphs(("g1", 5), ("g2", 6), ("g3", 7));

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec!["fixed_values".to_string()],
        vec![],
        CascadeMode::Fixed(Arc::new(|states: Vec<State>| {
            Ok(state_from_pairs([(
                "fixed_values",
                Value::Array(
                    states
                        .iter()
                        .map(|state| state.get("output").cloned().expect("output should exist"))
                        .collect(),
                ),
            )]))
        })),
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(output.state.get("fixed_values"), Some(&json!([5, 6, 7])));
}

#[test]
fn cascade_pipeline_feeds_each_output_into_next_sync_only() {
    let graph = runnable_graph_from_action(
        "pipeline_child",
        FunctionActionBuilder::new()
            .reads(["pipeline_value"])
            .writes(["pipeline_value"])
            .build_sync(|state, _ctx| {
                let current = state
                    .get("pipeline_value")
                    .and_then(Value::as_i64)
                    .unwrap_or(0);
                map_from_pairs([("pipeline_value", json!(current + 1))])
            })
            .expect("action should build"),
    );

    let action = ParallelMap::new(
        ParallelTaskSource::pairs(Arc::new(move |_state, _ctx| {
            Ok(vec![
                (
                    graph.clone(),
                    state_from_pairs([("pipeline_value", json!(0))]),
                ),
                (
                    graph.clone(),
                    state_from_pairs([("pipeline_value", json!(100))]),
                ),
                (
                    graph.clone(),
                    state_from_pairs([("pipeline_value", json!(200))]),
                ),
            ])
        })),
        vec!["pipeline_value".to_string()],
        vec!["pipeline_value".to_string()],
        vec![],
        CascadeMode::Pipeline,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("pipeline_value", json!(0))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(output.state.get("pipeline_value"), Some(&json!(3)));
    assert_eq!(
        child_i64_values(&output.result, "pipeline_value"),
        vec![1, 2, 3]
    );
}

#[test]
fn cascade_pipeline_empty_task_source_fails_without_mutating_parent_state() {
    let action = ParallelMap::new(
        ParallelTaskSource::pairs(Arc::new(|_state, _ctx| Ok(Vec::new()))),
        vec!["pipeline_value".to_string()],
        vec!["pipeline_value".to_string()],
        vec![],
        CascadeMode::Pipeline,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("pipeline_value", json!(7))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let error = app
        .step(None)
        .expect_err("empty pipeline should fail explicitly");

    match error {
        ApplicationError::Action(ActionError::UnsupportedOperation { message }) => {
            assert!(message.contains("CascadeMode::Pipeline requires at least one child task"));
        }
        other => panic!("expected typed empty pipeline error, got {other:?}"),
    }

    assert_eq!(app.state().get("pipeline_value"), Some(&json!(7)));
}

#[test]
fn parallel_child_sanitization_surfaces_typed_errors_instead_of_panicking() {
    let graph = runnable_graph_from_action(
        "child",
        FunctionActionBuilder::new()
            .build_sync(|_state, _ctx| IndexMap::new())
            .expect("action should build"),
    );
    let child_state = State::new(map_from_pairs([("__SEQUENCE_ID", json!(0))]))
        .with_typing_system(Arc::new(RejectSequenceDeletionTypingSystem))
        .expect("typing system should attach");
    let action = ParallelMap::new(
        ParallelTaskSource::pairs(Arc::new(move |_state, _ctx| {
            Ok(vec![(graph.clone(), child_state.clone())])
        })),
        Vec::new(),
        Vec::new(),
        Vec::new(),
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let error = app
        .step(None)
        .expect_err("step should surface sanitization errors");

    match error {
        ApplicationError::Action(ActionError::State(StateError::TypingSystem {
            phase,
            message,
        })) => {
            assert_eq!(phase, "validate_post_action");
            assert!(message.contains("__SEQUENCE_ID"));
        }
        other => panic!("expected typed sanitization error, got {other:?}"),
    }
}

#[test]
fn cascade_pipeline_sanitization_surfaces_typed_errors_instead_of_panicking() {
    let graph = runnable_graph_from_action(
        "pipeline_child",
        FunctionActionBuilder::new()
            .writes(["pipeline_value"])
            .build_sync(|state, _ctx| {
                let current = state
                    .get("pipeline_value")
                    .and_then(Value::as_i64)
                    .unwrap_or(0);
                map_from_pairs([("pipeline_value", json!(current + 1))])
            })
            .expect("action should build"),
    );

    let child_state = State::new(map_from_pairs([("pipeline_value", json!(0))]))
        .with_typing_system(Arc::new(RejectSequenceDeletionTypingSystem))
        .expect("typing system should attach");
    let action = ParallelMap::new(
        ParallelTaskSource::pairs(Arc::new(move |_state, _ctx| {
            Ok(vec![
                (graph.clone(), child_state.clone()),
                (
                    graph.clone(),
                    state_from_pairs([("pipeline_value", json!(100))]),
                ),
            ])
        })),
        vec!["pipeline_value".to_string()],
        vec!["pipeline_value".to_string()],
        vec![],
        CascadeMode::Pipeline,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("pipeline_value", json!(0))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let error = app
        .step(None)
        .expect_err("pipeline step should surface sanitization errors");

    match error {
        ApplicationError::Action(ActionError::State(StateError::TypingSystem {
            phase,
            message,
        })) => {
            assert_eq!(phase, "validate_post_action");
            assert!(message.contains("__SEQUENCE_ID"));
        }
        other => panic!("expected typed pipeline sanitization error, got {other:?}"),
    }
}

#[test]
fn lifecycle_hooks_are_shared_and_fire_for_children() {
    let pre_step_count = Arc::new(AtomicUsize::new(0));
    let hook: Arc<dyn SyncLifecycleAdapter> =
        Arc::new(PreStepCounter::new(Arc::clone(&pre_step_count)));
    let hooks = LifecycleAdapterSet::new(vec![hook], Vec::new());

    let graphs = two_constant_output_sync_child_graphs(("child_a", 1), ("child_b", 2));

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        hooks,
        None,
    );

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        pre_step_count.load(Ordering::SeqCst),
        3,
        "expected parent step + 2 child steps"
    );
}

#[tokio::test]
async fn async_only_lifecycle_hooks_receive_child_registration_events() {
    let recorder = Arc::new(ChildRegistrationRecorder::default());
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = recorder.clone();
    let hooks = LifecycleAdapterSet::new(Vec::new(), vec![async_hook]);

    let graphs = vec![
        constant_output_async_child_graph("child_a", 1),
        constant_output_async_child_graph("child_b", 2),
    ];

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );
    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        hooks,
        None,
    );

    let _ = app
        .astep(None)
        .await
        .expect("astep should succeed")
        .expect("astep should execute");

    let child_ids = recorder.child_app_ids();
    assert_eq!(
        child_ids.len(),
        2,
        "async-only adapters should observe child registrations for each child app"
    );
    let unique_child_ids: BTreeSet<String> = child_ids.into_iter().collect();
    assert_eq!(unique_child_ids.len(), 2);
}

#[test]
fn child_error_propagates_to_parent() {
    let good_graph = runnable_graph_from_action(
        "good",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
            .expect("action should build"),
    );
    let failing_graph = runnable_graph_from_action("bad", failing_action());

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![good_graph, failing_graph],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec!["sentinel".to_string()],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("sentinel", json!(1))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let error = app
        .step(None)
        .expect_err("step should fail when a child fails");

    assert!(
        error.to_string().contains("child failure"),
        "error should include child failure message: {error}"
    );
    assert_eq!(app.state().get("sentinel"), Some(&json!(1)));
}
