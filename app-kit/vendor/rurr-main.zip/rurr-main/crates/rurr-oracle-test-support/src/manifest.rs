//! Burr-oracle scenario manifest parsing and stable scenario identifiers.
//!
//! The workspace keeps the authoritative scenario list in
//! `tools/burr_oracle/scenarios.json`. This module parses that manifest into
//! stable Rust types so tests and audit helpers can enumerate scenarios without
//! duplicating manifest logic.

use serde::Deserialize;
use std::fmt;
use std::sync::LazyLock;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Deserialize)]
enum ScenarioKind {
    #[serde(rename = "burr_oracle")]
    BurrOracle,
    #[serde(rename = "rurr_only")]
    RurrOnly,
}

/// Stable identifiers for the Burr-oracle scenarios that Rurr tracks publicly.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum BurrOracleScenarioId {
    /// Minimal application creation flow.
    CreateOnly,
    /// Basic counter graph execution.
    CounterBasic,
    /// Conditional branching driven by the expression engine.
    BranchingExpr,
    /// Span and attribute emission through the tracking layer.
    SpansAndAttributes,
    /// Streaming action execution and finalization.
    StreamingAction,
    /// Condition routing driven by expression identity operators.
    ConditionIdentityExpr,
    /// Child application spawning and tracking.
    ForkAndSpawnChildren,
    /// SQLite-backed resume behavior.
    SqlitePersistenceResume,
}

impl BurrOracleScenarioId {
    /// Returns the manifest identifier string used on disk and in golden artifacts.
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::CreateOnly => "00_create_only",
            Self::CounterBasic => "01_counter_basic",
            Self::BranchingExpr => "02_branching_expr",
            Self::SpansAndAttributes => "03_spans_and_attributes",
            Self::StreamingAction => "04_streaming_action",
            Self::ConditionIdentityExpr => "05_condition_identity_expr",
            Self::ForkAndSpawnChildren => "06_fork_and_spawn_children",
            Self::SqlitePersistenceResume => "07_sqlite_persistence_resume",
        }
    }

    fn parse(value: &str) -> Result<Self, String> {
        match value {
            "00_create_only" => Ok(Self::CreateOnly),
            "01_counter_basic" => Ok(Self::CounterBasic),
            "02_branching_expr" => Ok(Self::BranchingExpr),
            "03_spans_and_attributes" => Ok(Self::SpansAndAttributes),
            "04_streaming_action" => Ok(Self::StreamingAction),
            "05_condition_identity_expr" => Ok(Self::ConditionIdentityExpr),
            "06_fork_and_spawn_children" => Ok(Self::ForkAndSpawnChildren),
            "07_sqlite_persistence_resume" => Ok(Self::SqlitePersistenceResume),
            _ => Err(format!("scenario {value} has unsupported burr_oracle id")),
        }
    }
}

impl fmt::Display for BurrOracleScenarioId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Parsed oracle scenario definition used by the runner.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BurrOracleScenario {
    /// Stable manifest identifier for this scenario.
    pub id: BurrOracleScenarioId,
    /// Human-readable scenario summary.
    pub description: String,
    /// Tracking project name created by the scenario.
    pub project: String,
    /// Application identifier used during the run.
    pub app_id: String,
    /// Partition key used during the run.
    pub partition_key: String,
    /// Whether the scenario is expected to emit a `children.jsonl` artifact.
    pub expects_children_file: bool,
}

#[derive(Debug, Deserialize)]
struct RawScenarioDefinition {
    id: String,
    kind: ScenarioKind,
    description: String,
    project: String,
    app_id: String,
    partition_key: String,
    expects_children_file: bool,
    #[serde(default)]
    rurr_command: Option<Vec<String>>,
}

impl RawScenarioDefinition {
    fn into_burr_oracle(self) -> Result<Option<BurrOracleScenario>, String> {
        if self.rurr_command.as_ref().is_some_and(Vec::is_empty) {
            return Err(format!(
                "scenario {} has invalid rurr_command: expected a non-empty string array",
                self.id
            ));
        }

        match (self.kind, self.rurr_command) {
            (ScenarioKind::BurrOracle, Some(_)) => Err(format!(
                "scenario {} must not define rurr_command for burr_oracle",
                self.id
            )),
            (ScenarioKind::BurrOracle, None) => Ok(Some(BurrOracleScenario {
                id: BurrOracleScenarioId::parse(&self.id)?,
                description: self.description,
                project: self.project,
                app_id: self.app_id,
                partition_key: self.partition_key,
                expects_children_file: self.expects_children_file,
            })),
            (ScenarioKind::RurrOnly, None) => {
                Err(format!("scenario {} is missing rurr_command", self.id))
            }
            (ScenarioKind::RurrOnly, Some(_)) => Ok(None),
        }
    }
}

static ORACLE_SCENARIOS: LazyLock<Vec<BurrOracleScenario>> = LazyLock::new(load_oracle_scenarios);

/// Returns the parsed list of Burr-oracle scenarios from the workspace manifest.
pub fn oracle_scenarios() -> &'static [BurrOracleScenario] {
    ORACLE_SCENARIOS.as_slice()
}

/// Alias for [`oracle_scenarios`] kept for parity with older audit helpers.
pub fn burr_oracle_scenarios() -> &'static [BurrOracleScenario] {
    oracle_scenarios()
}

fn parse_oracle_scenarios_json(raw_manifest: &str) -> Result<Vec<BurrOracleScenario>, String> {
    let raw_manifest: Vec<RawScenarioDefinition> =
        serde_json::from_str(raw_manifest).map_err(|error| error.to_string())?;

    raw_manifest
        .into_iter()
        .filter_map(|scenario| scenario.into_burr_oracle().transpose())
        .collect()
}

fn load_oracle_scenarios() -> Vec<BurrOracleScenario> {
    parse_oracle_scenarios_json(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../tools/burr_oracle/scenarios.json"
    )))
    .expect("oracle scenarios manifest should validate")
}

#[cfg(test)]
mod tests {
    use super::{
        parse_oracle_scenarios_json, BurrOracleScenarioId, RawScenarioDefinition, ScenarioKind,
    };

    fn scenario_json(entries: &[&str]) -> String {
        format!("[{}]", entries.join(","))
    }

    #[test]
    fn parse_oracle_scenarios_json_filters_rurr_only_entries() {
        let parsed = parse_oracle_scenarios_json(&scenario_json(&[
            r#"{"id":"00_create_only","kind":"burr_oracle","description":"create","project":"proj","app_id":"app","partition_key":"pk","expects_children_file":false}"#,
            r#"{"id":"custom_rurr_only","kind":"rurr_only","description":"extra","project":"proj","app_id":"app","partition_key":"pk","expects_children_file":false,"rurr_command":["cargo","test"]}"#,
        ]))
        .expect("manifest should parse");

        assert_eq!(parsed.len(), 1);
        assert_eq!(parsed[0].id, BurrOracleScenarioId::CreateOnly);
    }

    #[test]
    fn raw_scenario_definition_rejects_empty_rurr_command() {
        let scenario = RawScenarioDefinition {
            id: "custom_rurr_only".to_string(),
            kind: ScenarioKind::RurrOnly,
            description: "extra".to_string(),
            project: "proj".to_string(),
            app_id: "app".to_string(),
            partition_key: "pk".to_string(),
            expects_children_file: false,
            rurr_command: Some(Vec::new()),
        };

        let error = scenario
            .into_burr_oracle()
            .expect_err("empty rurr_command should fail");
        assert_eq!(
            error,
            "scenario custom_rurr_only has invalid rurr_command: expected a non-empty string array"
        );
    }

    #[test]
    fn raw_scenario_definition_rejects_missing_rurr_only_command() {
        let scenario = RawScenarioDefinition {
            id: "custom_rurr_only".to_string(),
            kind: ScenarioKind::RurrOnly,
            description: "extra".to_string(),
            project: "proj".to_string(),
            app_id: "app".to_string(),
            partition_key: "pk".to_string(),
            expects_children_file: false,
            rurr_command: None,
        };

        let error = scenario
            .into_burr_oracle()
            .expect_err("missing rurr_command should fail");
        assert_eq!(error, "scenario custom_rurr_only is missing rurr_command");
    }

    #[test]
    fn raw_scenario_definition_rejects_burr_oracle_commands() {
        let scenario = RawScenarioDefinition {
            id: "00_create_only".to_string(),
            kind: ScenarioKind::BurrOracle,
            description: "create".to_string(),
            project: "proj".to_string(),
            app_id: "app".to_string(),
            partition_key: "pk".to_string(),
            expects_children_file: false,
            rurr_command: Some(vec!["cargo".to_string(), "test".to_string()]),
        };

        let error = scenario
            .into_burr_oracle()
            .expect_err("burr_oracle scenarios must not define rurr_command");
        assert_eq!(
            error,
            "scenario 00_create_only must not define rurr_command for burr_oracle"
        );
    }

    #[test]
    fn parse_oracle_scenarios_json_rejects_unsupported_ids() {
        let error = parse_oracle_scenarios_json(&scenario_json(&[
            r#"{"id":"99_unknown","kind":"burr_oracle","description":"unknown","project":"proj","app_id":"app","partition_key":"pk","expects_children_file":false}"#,
        ]))
        .expect_err("unsupported ids should fail");

        assert_eq!(error, "scenario 99_unknown has unsupported burr_oracle id");
    }

    #[test]
    fn condition_identity_expr_id_roundtrips_manifest_string() {
        assert_eq!(
            BurrOracleScenarioId::ConditionIdentityExpr.as_str(),
            "05_condition_identity_expr"
        );
        assert_eq!(
            BurrOracleScenarioId::parse("05_condition_identity_expr")
                .expect("condition identity id should parse"),
            BurrOracleScenarioId::ConditionIdentityExpr
        );
    }
}
