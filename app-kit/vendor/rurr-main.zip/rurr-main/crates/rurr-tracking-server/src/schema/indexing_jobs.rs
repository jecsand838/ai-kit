use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

/// Tracking-server indexing job summary.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct IndexingJob {
    /// Stable job identifier.
    pub id: u64,
    /// RFC3339 timestamp for the start of the job.
    pub start_time: String,
    /// RFC3339 timestamp for completion, if the job has finished.
    pub end_time: Option<String>,
    /// Backend-defined status string.
    pub status: String,
    /// Number of records processed so far.
    pub records_processed: u64,
    /// Backend-defined structured metadata for the job.
    pub metadata: Map<String, Value>,
}
