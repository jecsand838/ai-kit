//! Lifecycle hook traits, context objects, and guard types for application
//! execution.
//!
//! The runtime keeps sync and async hooks distinct so step execution can remain
//! explicit about when callbacks run, when cleanup is guaranteed, and which
//! APIs are safe to use from each lane.

mod adapter;
mod context;
mod default;
mod guard;

pub(crate) use adapter::poll_with_lifecycle_contexts;
pub use adapter::{
    AsyncLifecycleAdapter, AsyncLifecycleContextPropagator, AsyncLifecyclePollContext,
    AsyncLifecyclePollGuard, LifecycleAdapterSet, LifecycleError, SyncLifecycleAdapter,
};
pub use context::{
    ExecuteCallContext, LifecycleExecutionMode, PostStepContext, PreStepContext, SpanContext,
    StreamContext, StreamItemContext, VisibilityRootContext,
};
pub use default::{SlowDownHook, StateAndResultsFullLogger, StateAndResultsLogMode};
pub use guard::{ExecuteCallGuard, StepGuard, StepOutcome, StreamGuard};
