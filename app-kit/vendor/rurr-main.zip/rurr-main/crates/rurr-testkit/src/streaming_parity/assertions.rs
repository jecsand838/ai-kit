use super::observation::StreamingObservation;

/// Asserts the streaming contract while ignoring chunk boundaries.
pub fn assert_chunk_agnostic_observation(observation: &StreamingObservation) {
    assert_eq!(observation.starts_before_first_poll, 0);
    assert_eq!(observation.starts_after_first_poll, 1);
    assert!(
        !observation.streamed_deltas.is_empty(),
        "streaming observation should contain at least one delta"
    );
    assert_eq!(
        observation.streamed_deltas.concat(),
        observation.terminal_response
    );
    assert_eq!(
        observation.final_state_response,
        observation.terminal_response
    );
}
