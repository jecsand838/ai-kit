use rurr_testkit::command_fixture::assert_success;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;

pub(crate) fn workspace_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .expect("crate dir should have crates parent")
        .parent()
        .expect("crates dir should have workspace root")
        .to_path_buf()
}

pub(crate) fn tempdir_in_workspace(prefix: &str) -> tempfile::TempDir {
    let tmp_root = workspace_root().join(".tmp");
    fs::create_dir_all(&tmp_root).expect(".tmp root should be created");
    tempfile::Builder::new()
        .prefix(prefix)
        .tempdir_in(tmp_root)
        .expect("tempdir should be created")
}

fn tracked_workspace_files(root: &Path) -> Vec<PathBuf> {
    let output = Command::new("git")
        .current_dir(root)
        .args([
            "ls-files",
            "-z",
            "--cached",
            "--others",
            "--exclude-standard",
        ])
        .output()
        .expect("git ls-files should run");
    assert_success(&output, "git ls-files should succeed");
    String::from_utf8(output.stdout)
        .expect("tracked file list should be utf-8")
        .split('\0')
        .filter(|entry| !entry.is_empty())
        .map(PathBuf::from)
        .collect()
}

pub(crate) fn copy_tracked_workspace(root: &Path, snapshot_root: &Path) {
    for relative_path in tracked_workspace_files(root) {
        let source = root.join(&relative_path);
        if !source.is_file() {
            continue;
        }

        let destination = snapshot_root.join(&relative_path);
        if let Some(parent) = destination.parent() {
            fs::create_dir_all(parent).expect("snapshot parent directories should be created");
        }
        fs::copy(&source, &destination).unwrap_or_else(|error| {
            panic!(
                "copying tracked file {} into snapshot failed: {error}",
                relative_path.display()
            )
        });
    }
}
