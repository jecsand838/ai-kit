use super::*;

fn assert_missing_stream_state_error(error: LifecycleError, phase: &'static str) {
    assert_eq!(error.phase(), phase);
    assert!(
        error.message().contains("missing stream state"),
        "missing stream state error should be explicit: {error}"
    );
    assert!(
        error.message().contains("pre_start_stream"),
        "missing stream state error should identify the required pre_start_stream hook: {error}"
    );
}

fn registered_stream_state_client(
    project: &str,
    app_id: &str,
) -> (rurr_testkit::tempdir::TestDir, LocalTrackingClient) {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let client = LocalTrackingClient::new(project, &storage_root)
        .expect("local tracking client should build");
    let template_app = build_counter_template_app(app_id);
    client
        .register_application(app_id, Some("pk"), template_app.graph(), None, None)
        .expect("application should register");
    (storage_root, client)
}

#[test]
fn sync_stream_hooks_fail_when_pre_start_stream_is_missing() {
    let project = "test_sync_missing_stream_state";
    let app_id = "sync-missing-stream-state";
    let (storage_root, client) = registered_stream_state_client(project, app_id);

    let item_error = SyncLifecycleAdapter::post_stream_item(
        &client,
        &StreamItemContext::new("counter", 0, 99, 0).with_app_id(app_id),
    )
    .expect_err("missing pre_start_stream should reject stream item");
    assert_missing_stream_state_error(item_error, "post_stream_item");

    let end_error = SyncLifecycleAdapter::post_end_stream(
        &client,
        &StreamContext::new("counter", 0, 100).with_app_id(app_id),
    )
    .expect_err("missing pre_start_stream should reject stream end");
    assert_missing_stream_state_error(end_error, "post_end_stream");

    assert!(
        read_app_log_if_exists(&storage_root, project, app_id).is_empty(),
        "missing stream state must not synthesize stream lifecycle log entries"
    );
}

#[tokio::test]
async fn async_stream_hooks_fail_when_pre_start_stream_is_missing() {
    let project = "test_async_missing_stream_state";
    let app_id = "async-missing-stream-state";
    let (storage_root, client) = registered_stream_state_client(project, app_id);

    let item_error = AsyncLifecycleAdapter::post_stream_item(
        &client,
        &StreamItemContext::new("counter", 0, 99, 0).with_app_id(app_id),
    )
    .await
    .expect_err("missing pre_start_stream should reject async stream item");
    assert_missing_stream_state_error(item_error, "post_stream_item");

    let end_error = AsyncLifecycleAdapter::post_end_stream(
        &client,
        &StreamContext::new("counter", 0, 100).with_app_id(app_id),
    )
    .await
    .expect_err("missing pre_start_stream should reject async stream end");
    assert_missing_stream_state_error(end_error, "post_end_stream");

    assert!(
        read_app_log_if_exists(&storage_root, project, app_id).is_empty(),
        "missing stream state must not synthesize async stream lifecycle log entries"
    );
}

#[tokio::test]
async fn async_streaming_logs_step_and_stream_lifecycle_entries_once() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let log_lines = assert_stream_case(
        &storage_root,
        StreamFixture::TwoStepCommit,
        "test_async_streaming_parity",
        "async-stream-app",
        TrackingMode::Async,
    )
    .await;

    assert_log_event_counts(
        &log_lines,
        &[
            ("begin_entry", 1),
            ("end_entry", 1),
            ("begin_stream", 1),
            ("first_item_stream", 1),
            ("end_stream", 1),
        ],
    );
}

#[test]
fn sync_streaming_orders_end_entry_before_end_stream_and_counts_items() {
    for (fixture, project, app_id) in [
        (
            StreamFixture::TwoStepCommit,
            "test_sync_streaming_order_success",
            "sync-stream-success",
        ),
        (
            StreamFixture::TerminalOnly { final_count: 9 },
            "test_sync_streaming_order_terminal_only",
            "sync-stream-terminal-only",
        ),
        (
            StreamFixture::ErrorAfterIntermediate {
                message: "boom-stream-sync",
            },
            "test_sync_streaming_order_error",
            "sync-stream-error",
        ),
    ] {
        let storage_root = rurr_testkit::tempdir::test_dir().expect("temp dir should build");
        futures::executor::block_on(assert_stream_case(
            &storage_root,
            fixture,
            project,
            app_id,
            TrackingMode::Sync,
        ));
    }
}

#[tokio::test]
async fn async_streaming_orders_end_entry_before_end_stream_and_counts_items() {
    for (fixture, project, app_id) in [
        (
            StreamFixture::TwoStepCommit,
            "test_async_streaming_order_success",
            "async-stream-success",
        ),
        (
            StreamFixture::TerminalOnly { final_count: 9 },
            "test_async_streaming_order_terminal_only",
            "async-stream-terminal-only",
        ),
        (
            StreamFixture::ErrorAfterIntermediate {
                message: "boom-stream-async",
            },
            "test_async_streaming_order_error",
            "async-stream-error",
        ),
    ] {
        let storage_root = rurr_testkit::tempdir::test_dir().expect("temp dir should build");
        assert_stream_case(&storage_root, fixture, project, app_id, TrackingMode::Async).await;
    }
}

#[tokio::test]
async fn async_non_stream_step_logs_begin_and_end_entries() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_async_non_streaming_parity";
    let async_action = FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .with_source_code(
            "async fn async_non_stream_step_action(state, _ctx) { let next_count = state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1; map_from_pairs([(\"count\", json!(next_count))]) }",
        )
        .build_async(|state, _ctx| async move {
            let next_count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            map_from_pairs([("count", json!(next_count))])
        })
        .expect("async action should build");
    let (_tracker, mut app) = registered_async_app(
        project,
        &storage_root,
        "async-step-app",
        "counter",
        async_action,
    );

    let output = app.astep(None).await.expect("astep should succeed");
    assert!(output.is_some(), "astep should execute one step");

    let log_lines = read_app_log(&storage_root, project, "async-step-app");
    assert_log_event_counts(
        &log_lines,
        &[
            ("begin_entry", 1),
            ("end_entry", 1),
            ("begin_stream", 0),
            ("first_item_stream", 0),
            ("end_stream", 0),
        ],
    );
    assert_eq!(count_log_entries(&log_lines, "begin_stream"), 0);
}
