use super::map_common::{build_task, Reducer, TaskBuilder};
use super::{ParallelMap, ParallelTaskSource, RunnableGraph};
use crate::{
    action::{ActionContext, ActionResult},
    application::ApplicationError,
    state::State,
};
use std::sync::Arc;

/// Builds a [`ParallelMap`] over a graph/state cross-product plus a custom reducer.
pub fn map_reduce_action<I, R, E>(
    graphs: I,
    state_splitter: Arc<super::parallel_map::ParallelStateSplitter>,
    reducer: Arc<R>,
    reads: Vec<String>,
    writes: Vec<String>,
    inputs: Vec<String>,
) -> ParallelMap
where
    I: IntoIterator<Item = RunnableGraph>,
    R: Fn(&State, Vec<State>) -> Result<State, E> + Send + Sync + 'static,
    ApplicationError: From<E>,
{
    let graphs = graphs.into_iter().collect::<Vec<_>>();
    let task_builder: Arc<TaskBuilder> = Arc::new(move |state: &State, ctx: &ActionContext| {
        let states = state_splitter(state, ctx)?;
        let mut tasks = Vec::with_capacity(graphs.len().saturating_mul(states.len()));
        for (graph_index, graph) in graphs.iter().enumerate() {
            for (state_index, task_state) in states.iter().enumerate() {
                tasks.push(build_task(
                    graph.clone(),
                    task_state.clone(),
                    graph_index,
                    state_index,
                ));
            }
        }
        Ok(tasks)
    });
    let result_reducer: Arc<Reducer> =
        Arc::new(move |parent_state: &State, child_states: Vec<State>| {
            let final_state =
                reducer(parent_state, child_states).map_err(ApplicationError::from)?;
            Ok(ActionResult::new(Default::default(), final_state.get_all()))
        });

    ParallelMap::with_reducer(
        ParallelTaskSource::explicit(task_builder),
        reads,
        writes,
        inputs,
        super::CascadeMode::None,
        result_reducer,
    )
}
