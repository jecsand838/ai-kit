mod support_common;
pub(crate) mod test_support {
    pub(crate) use crate::support_common::field_serde::register_prefixed_string_field_serde;
    pub(crate) use crate::support_common::persistence::{
        with_async_initializer_spec, with_async_persister_spec, with_sync_initializer_spec,
        with_sync_persister_spec,
    };
    pub(crate) use crate::support_common::registry::{registry_test_guard, unique_registry_name};
    pub(crate) use crate::support_common::subprocess::{
        run_subprocess_fixture, subprocess_fixture_enabled,
    };
    pub(crate) use crate::support_common::typing::{
        DeleteOnlyPostActionTypingSystem, DeleteOnlyRoundTripCountTypingSystem,
        NoRoundTripSpyTypingSystem, NonNegativeCountTypingSystem, PassthroughTypingSystem,
        RequireKeyTypingSystem, ResumeRoundTripTypingSystem, ResumeStateTypingSystem,
        RoundTripCountTypingSystem, StringListTypingSystem,
    };
}

mod contract {
    mod action_contract;
    mod action_source_contract;
    mod application_async_contract;
    mod application_async_persistence_contract;
    mod application_builder_contract;
    mod application_context_contract;
    mod application_inspection_contract;
    mod application_persistence_contract;
    mod application_run_contract;
    mod application_step_contract;
    pub(crate) mod application_streaming_contract;
    mod async_utils_contract;
    mod condition_contract;
    mod drop_async_cleanup_contract;
    mod graph_contract;
    mod graphviz_contract;
    mod lifecycle_contract;
    mod lifecycle_guard_contract;
    mod parallelism_contract;
    mod serde_contract;
    mod state_contract;
    mod streaming_container_contract;
    pub(crate) mod support;
    mod validation_contract;
    mod visibility_tracing_contract;
}
