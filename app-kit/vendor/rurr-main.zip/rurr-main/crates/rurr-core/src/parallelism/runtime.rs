use super::{executor::ParallelRuntimeContext, types::SubGraphTask};
use crate::parallelism::ParallelExecutor;
use crate::{
    action::api::{is_reserved_runtime_input, ActionContext, ActionError, ActionInputs},
    application::{
        build::{
            assemble_resources, build_graph_with_resources_async, build_graph_with_resources_sync,
            resolve_child_hook_topology, BuildMode, ChildHookTopology,
        },
        builder::ApplicationError,
        context::ParentPointer,
        ExecutionOptions, RuntimeResources, Tracker,
    },
    graph::Graph,
    lifecycle::LifecycleAdapterSet,
    state::State,
    tracking::ResolvedTrackerSpec,
};
use sha2::{Digest, Sha256};
use std::sync::Arc;

pub(super) fn runtime_context_for_parallel(
    ctx: &ActionContext,
) -> Result<ParallelRuntimeContext, ApplicationError> {
    let Some(parent_context) = ctx.app_context.clone() else {
        return Err(ApplicationError::Action(
            ActionError::RuntimeContextUnavailable {
                message: "parallel action requires current application context".to_string(),
            },
        ));
    };
    let Some(resources) = ctx.engine_resources().cloned() else {
        return Err(ApplicationError::Action(
            ActionError::RuntimeContextUnavailable {
                message: "parallel action requires application-managed execution scope".to_string(),
            },
        ));
    };
    let Some(parent_sequence_id) = parent_context.sequence_id else {
        return Err(ApplicationError::Action(
            ActionError::RuntimeContextUnavailable {
                message:
                    "parallel action requires parent sequence id in current application context"
                        .to_string(),
            },
        ));
    };

    Ok(ParallelRuntimeContext::new(
        parent_context.app_id,
        parent_context.partition_key,
        parent_sequence_id,
        resources,
    ))
}

pub(super) fn app_error_to_action_error(error: ApplicationError) -> ActionError {
    match error {
        ApplicationError::Action(action_error) => action_error,
        ApplicationError::State(state_error) => ActionError::State(state_error),
        other => ActionError::Internal {
            message: other.to_string(),
        },
    }
}

pub(super) struct ChildRuntimePlan {
    pub(super) child_app_id: String,
    pub(super) partition_key: Option<String>,
    pub(super) spawning_parent: ParentPointer,
}

pub(super) struct ResolvedChildTask {
    pub(super) plan: ChildRuntimePlan,
    pub(super) graph: Graph,
    pub(super) state: State,
    pub(super) inputs: ActionInputs,
    registration_hooks: LifecycleAdapterSet,
    execution_hooks: LifecycleAdapterSet,
    tracker: Option<Arc<dyn Tracker>>,
    parallel_executor: Option<Arc<dyn ParallelExecutor>>,
    state_persister: Option<rurr_persistence::StatePersisterRef>,
    state_initializer: Option<rurr_persistence::StateLoaderRef>,
}

struct ChildBuildRequest {
    plan: ChildRuntimePlan,
    inputs: ActionInputs,
    registration_hooks: LifecycleAdapterSet,
    graph: Graph,
    state: State,
    execution_resources: RuntimeResources,
    requested_entrypoint: Option<String>,
}

struct PreparedChildRun {
    plan: ChildRuntimePlan,
    inputs: ActionInputs,
    registration_hooks: LifecycleAdapterSet,
    child_app: crate::application::Application,
}

pub(super) fn child_instance_app_id(parent_app_id: &str, task_key: &str) -> String {
    let seed = format!("{parent_app_id}:{task_key}");
    let digest = Sha256::digest(seed.as_bytes());
    format!("{digest:x}")
}

pub(super) fn sanitize_task_state(state: State) -> Result<State, ApplicationError> {
    let runtime_keys: Vec<String> = state
        .entries()
        .filter(|(key, _)| is_reserved_runtime_input(key))
        .map(|(key, _)| key.clone())
        .collect();
    if runtime_keys.is_empty() {
        Ok(state)
    } else {
        Ok(state.delete_owned_keys(runtime_keys)?)
    }
}

impl ChildRuntimePlan {
    fn new(runtime: &ParallelRuntimeContext, task_key: &str, child_app_id: Option<&str>) -> Self {
        let child_app_id = child_app_id
            .map(str::to_string)
            .unwrap_or_else(|| child_instance_app_id(runtime.parent_app_id(), task_key));
        let partition_key = runtime.parent_partition_key().map(str::to_string);
        let spawning_parent = ParentPointer {
            app_id: runtime.parent_app_id().to_string(),
            partition_key: partition_key.clone(),
            sequence_id: Some(runtime.parent_sequence_id()),
        };

        Self {
            child_app_id,
            partition_key,
            spawning_parent,
        }
    }

    fn child_identity(&self) -> (String, Option<String>, ParentPointer) {
        (
            self.child_app_id.clone(),
            self.partition_key.clone(),
            self.spawning_parent.clone(),
        )
    }

    fn register_sync(
        &self,
        registration_hooks: &LifecycleAdapterSet,
        child_app: &crate::application::Application,
    ) -> Result<(), ApplicationError> {
        registration_hooks.register_child_application_sync(
            &self.child_app_id,
            self.partition_key.as_deref(),
            child_app.graph_definition(),
            None,
            Some(&self.spawning_parent),
        )?;
        Ok(())
    }

    async fn register_async(
        &self,
        registration_hooks: &LifecycleAdapterSet,
        child_app: &crate::application::Application,
    ) -> Result<(), ApplicationError> {
        registration_hooks
            .register_child_application_async(
                &self.child_app_id,
                self.partition_key.as_deref(),
                child_app.graph_definition(),
                None,
                Some(&self.spawning_parent),
            )
            .await?;
        Ok(())
    }
}

impl ResolvedChildTask {
    pub(super) fn resolve(
        task: SubGraphTask,
        runtime: &ParallelRuntimeContext,
        build_mode: BuildMode,
    ) -> Result<Self, ApplicationError> {
        let SubGraphTask {
            graph,
            state,
            task_key,
            inputs,
            tracker,
            state_persister,
            state_initializer,
            child_app_id,
        } = task;
        let plan = ChildRuntimePlan::new(runtime, &task_key, child_app_id.as_deref());
        let graph = graph.build_graph()?;
        let state = sanitize_task_state(state)?;
        let ChildHookTopology {
            tracker,
            execution_hooks,
            registration_hooks,
        } = resolve_child_hook_topology(runtime.hooks(), runtime.tracker(), tracker, build_mode);

        Ok(Self {
            plan,
            graph,
            state,
            inputs,
            registration_hooks,
            execution_hooks,
            tracker,
            parallel_executor: runtime.parallel_executor().cloned(),
            state_persister: state_persister.or_else(|| runtime.state_persister().cloned()),
            state_initializer: state_initializer.or_else(|| runtime.state_initializer().cloned()),
        })
    }

    fn into_build_request(self, build_mode: BuildMode) -> ChildBuildRequest {
        let ResolvedChildTask {
            plan,
            graph,
            state,
            inputs,
            registration_hooks,
            execution_hooks,
            tracker,
            parallel_executor,
            state_persister,
            state_initializer,
        } = self;
        let requested_entrypoint = Some(graph.entrypoint().to_string());
        ChildBuildRequest {
            plan,
            inputs,
            registration_hooks,
            graph,
            state,
            execution_resources: assemble_resources(
                build_mode,
                execution_hooks,
                tracker.map(ResolvedTrackerSpec::caller_provided),
                parallel_executor,
                state_persister,
                state_initializer,
            ),
            requested_entrypoint,
        }
    }

    fn prepare_sync(self) -> Result<PreparedChildRun, ApplicationError> {
        let ChildBuildRequest {
            plan,
            inputs,
            registration_hooks,
            graph,
            state,
            execution_resources,
            requested_entrypoint,
        } = self.into_build_request(BuildMode::Sync);
        let (child_app_id, partition_key, spawning_parent) = plan.child_identity();
        Ok(PreparedChildRun {
            plan,
            inputs,
            registration_hooks,
            child_app: build_graph_with_resources_sync(
                graph,
                state,
                child_app_id,
                partition_key,
                Some(spawning_parent),
                execution_resources,
                requested_entrypoint,
            )?,
        })
    }

    async fn prepare_async(self) -> Result<PreparedChildRun, ApplicationError> {
        let ChildBuildRequest {
            plan,
            graph,
            state,
            inputs,
            registration_hooks,
            execution_resources,
            requested_entrypoint,
        } = self.into_build_request(BuildMode::Async);
        let (child_app_id, partition_key, spawning_parent) = plan.child_identity();
        Ok(PreparedChildRun {
            plan,
            inputs,
            registration_hooks,
            child_app: build_graph_with_resources_async(
                graph,
                state,
                child_app_id,
                partition_key,
                Some(spawning_parent),
                execution_resources,
                requested_entrypoint,
            )
            .await?,
        })
    }

    fn run_sync(self) -> Result<State, ApplicationError> {
        self.prepare_sync()?.run_sync()
    }

    async fn run_async(self) -> Result<State, ApplicationError> {
        self.prepare_async().await?.run_async().await
    }
}

impl PreparedChildRun {
    fn into_execution_options(inputs: ActionInputs) -> ExecutionOptions {
        ExecutionOptions::new().with_inputs(inputs)
    }

    fn run_sync(self) -> Result<State, ApplicationError> {
        let Self {
            plan,
            inputs,
            registration_hooks,
            mut child_app,
        } = self;
        plan.register_sync(&registration_hooks, &child_app)?;
        let output = child_app.run_with_options(Self::into_execution_options(inputs))?;
        Ok(output.state)
    }

    async fn run_async(self) -> Result<State, ApplicationError> {
        let Self {
            plan,
            inputs,
            registration_hooks,
            mut child_app,
        } = self;
        plan.register_async(&registration_hooks, &child_app).await?;
        let output = child_app
            .arun_with_options(Self::into_execution_options(inputs))
            .await?;
        Ok(output.state)
    }
}

pub(super) fn run_child_sync(
    task: SubGraphTask,
    runtime: &ParallelRuntimeContext,
) -> Result<State, ApplicationError> {
    ResolvedChildTask::resolve(task, runtime, BuildMode::Sync)?.run_sync()
}

pub(super) async fn run_child_async(
    task: SubGraphTask,
    runtime: &ParallelRuntimeContext,
) -> Result<State, ApplicationError> {
    ResolvedChildTask::resolve(task, runtime, BuildMode::Async)?
        .run_async()
        .await
}
