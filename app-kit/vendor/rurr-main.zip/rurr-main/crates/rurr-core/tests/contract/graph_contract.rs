use indexmap::IndexMap;
use rurr_core::action::{ActionContext, ActionError, ActionResult, Condition, LocalAction};
use rurr_core::graph::{
    validate_actions, validate_transitions, GraphAction, GraphBuilder, GraphError, Transition,
};
use rurr_core::state::State;
use serde_json::json;
use std::collections::HashSet;

use super::support::pairs::state_from_pairs;

#[derive(Debug, Clone)]
struct ContractAction {
    name: Option<String>,
    tags: Vec<String>,
    inputs: Vec<String>,
    optional_inputs: Vec<String>,
}

impl ContractAction {
    fn tagged(tags: &[&str]) -> Self {
        Self {
            name: None,
            tags: tags.iter().map(|tag| (*tag).to_string()).collect(),
            inputs: Vec::new(),
            optional_inputs: Vec::new(),
        }
    }

    fn with_inputs<I, S>(mut self, inputs: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.inputs = inputs.into_iter().map(Into::into).collect();
        self
    }

    fn with_optional_inputs<I, S>(mut self, optional_inputs: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.optional_inputs = optional_inputs.into_iter().map(Into::into).collect();
        self
    }
}

impl LocalAction for ContractAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn inputs(&self) -> &[String] {
        &self.inputs
    }

    fn optional_inputs(&self) -> &[String] {
        &self.optional_inputs
    }

    fn tags(&self) -> &[String] {
        &self.tags
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }
        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
    }
}

fn graph_action(name: &str, tags: &[&str]) -> GraphAction {
    let named = ContractAction::tagged(tags)
        .with_name(name)
        .expect("test action naming should succeed");
    GraphAction::new(named).expect("named action should create graph action")
}

#[test]
fn graph_action_new_rejects_missing_name() {
    let error = GraphAction::new(ContractAction::tagged(&[]))
        .expect_err("graph action without name should fail");
    assert!(matches!(error, GraphError::UnnamedAction));
}

#[test]
fn graph_action_new_rejects_empty_name() {
    let named = ContractAction::tagged(&[])
        .with_name("")
        .expect("empty name assignment should still construct action");
    let error = GraphAction::new(named).expect_err("graph action with empty name should fail");
    assert!(matches!(error, GraphError::UnnamedAction));
}

#[test]
fn graph_action_new_rejects_whitespace_only_name() {
    let named = ContractAction::tagged(&[])
        .with_name(" \t\n ")
        .expect("whitespace-only name assignment should still construct action");
    let error =
        GraphAction::new(named).expect_err("graph action with whitespace-only name should fail");
    assert!(matches!(error, GraphError::UnnamedAction));
}

#[test]
fn graph_action_new_accepts_non_blank_name() {
    let named = ContractAction::tagged(&[])
        .with_name("counter")
        .expect("valid name assignment should construct action");
    let graph_action = GraphAction::new(named).expect("non-blank name should be accepted");
    assert_eq!(graph_action.name(), "counter");
}

#[test]
fn graph_action_new_rejects_reserved_required_inputs() {
    let named = ContractAction::tagged(&[])
        .with_inputs(["count", "__tracer", "__context", "__tracer"])
        .with_name("counter")
        .expect("valid name assignment should construct action");
    let error = GraphAction::new(named).expect_err("reserved required inputs should fail");
    assert!(matches!(
        error,
        GraphError::ReservedRuntimeInputDeclaration {
            action_name,
            keys
        } if action_name == "counter" && keys == vec!["__context".to_string(), "__tracer".to_string()]
    ));
}

#[test]
fn graph_action_new_rejects_reserved_optional_inputs() {
    let named = ContractAction::tagged(&[])
        .with_optional_inputs(["step", "__tracer", "__context", "__context"])
        .with_name("counter")
        .expect("valid name assignment should construct action");
    let error = GraphAction::new(named).expect_err("reserved optional inputs should fail");
    assert!(matches!(
        error,
        GraphError::ReservedRuntimeInputDeclaration { action_name, keys }
            if action_name == "counter" && keys == vec!["__context".to_string(), "__tracer".to_string()]
    ));
}

#[test]
fn graph_action_new_rejects_unknown_reserved_optional_inputs() {
    let named = ContractAction::tagged(&[])
        .with_optional_inputs(["step", "__foo"])
        .with_name("counter")
        .expect("valid name assignment should construct action");
    let error = GraphAction::new(named).expect_err("unknown reserved optional inputs should fail");
    assert!(matches!(
        error,
        GraphError::ReservedRuntimeInputDeclaration { action_name, keys }
            if action_name == "counter" && keys == vec!["__foo".to_string()]
    ));
}

#[test]
fn validate_transitions_correct() {
    let transitions = vec![
        Transition::new("counter", "counter", Condition::expr("count < 10")),
        Transition::new("counter", "result", Condition::default()),
    ];
    let actions = HashSet::from(["counter".to_string(), "result".to_string()]);

    validate_transitions(&transitions, &actions).expect("transition validation should succeed");
}

#[test]
fn validate_transitions_missing_action() {
    let transitions = vec![
        Transition::new("counter", "counter", Condition::expr("count < 10")),
        Transition::new("counter", "result", Condition::default()),
    ];
    let actions = HashSet::from(["counter".to_string()]);

    let error = validate_transitions(&transitions, &actions)
        .expect_err("missing transition target should fail");
    assert!(matches!(error, GraphError::TransitionTargetNotFound { .. }));
}

#[test]
fn validate_transitions_redundant_transition() {
    let transitions = vec![
        Transition::new("counter", "counter", Condition::expr("count < 10")),
        Transition::new("counter", "result", Condition::default()),
        Transition::new("counter", "counter", Condition::default()),
    ];
    let actions = HashSet::from(["counter".to_string(), "result".to_string()]);

    let error =
        validate_transitions(&transitions, &actions).expect_err("redundant default should fail");
    assert!(matches!(error, GraphError::RedundantTransition { .. }));
}

#[test]
fn validate_actions_valid() {
    let actions = vec![graph_action("test", &[])];

    validate_actions(&actions).expect("actions should validate");
}

#[test]
fn validate_actions_empty() {
    let error = validate_actions(&[]).expect_err("empty action list should fail");
    assert!(matches!(error, GraphError::EmptyActions));
}

#[test]
fn validate_actions_duplicated() {
    let actions = vec![graph_action("test", &[]), graph_action("test", &[])];

    let error = validate_actions(&actions).expect_err("duplicate action names should fail");
    assert!(matches!(error, GraphError::DuplicateActionName { .. }));
}

#[test]
fn graph_builder_builds() {
    let graph = GraphBuilder::new()
        .with_actions(vec![
            graph_action("counter", &["tag1", "tag2"]),
            graph_action("result", &[]),
        ])
        .with_transition_when("counter", "counter", Condition::expr("count < 10"))
        .with_transition("counter", "result")
        .build()
        .expect("graph build should succeed");

    assert_eq!(graph.actions().len(), 2);
    assert_eq!(graph.transitions().len(), 2);
}

#[test]
fn graph_builder_with_graph_merges_actions_and_transitions() {
    let graph1 = GraphBuilder::new()
        .with_action(graph_action("counter", &[]))
        .with_transition_when("counter", "counter", Condition::expr("count < 10"))
        .build()
        .expect("graph1 build should succeed");
    let graph2 = GraphBuilder::new()
        .with_action(graph_action("counter2", &[]))
        .with_transition_when("counter2", "counter2", Condition::expr("count < 20"))
        .build()
        .expect("graph2 build should succeed");

    let graph = GraphBuilder::new()
        .with_graph(&graph1)
        .with_graph(&graph2)
        .with_action(graph_action("result", &[]))
        .with_transition("counter", "counter2")
        .with_transition("counter2", "result")
        .build()
        .expect("merged graph build should succeed");

    assert_eq!(graph.actions().len(), 3);
    assert_eq!(graph.transitions().len(), 4);
}

#[test]
fn graph_builder_get_next_node() {
    let graph = GraphBuilder::new()
        .with_actions(vec![
            graph_action("counter", &[]),
            graph_action("result", &[]),
        ])
        .with_transition_when("counter", "counter", Condition::expr("count < 10"))
        .with_transition("counter", "result")
        .build()
        .expect("graph build should succeed");

    assert_eq!(
        graph
            .get_next_node(None, &state_from_pairs([("count", json!(0))]))
            .expect("entrypoint lookup should succeed"),
        Some("counter".to_string())
    );
    assert_eq!(
        graph
            .get_next_node(Some("counter"), &state_from_pairs([("count", json!(0))]))
            .expect("transition lookup should succeed"),
        Some("counter".to_string())
    );
    assert_eq!(
        graph
            .get_next_node(Some("counter"), &state_from_pairs([("count", json!(10))]))
            .expect("transition lookup should succeed"),
        Some("result".to_string())
    );
}

#[test]
fn graph_get_next_node_prefers_first_matching_transition_in_definition_order() {
    let graph = GraphBuilder::new()
        .with_actions(vec![
            graph_action("counter", &[]),
            graph_action("result_a", &[]),
            graph_action("result_b", &[]),
        ])
        .with_transition_when("counter", "result_a", Condition::expr("count >= 0"))
        .with_transition_when("counter", "result_b", Condition::expr("count < 10"))
        .build()
        .expect("graph build should succeed");

    assert_eq!(
        graph
            .get_next_node(Some("counter"), &state_from_pairs([("count", json!(5))]))
            .expect("transition lookup should succeed"),
        Some("result_a".to_string())
    );
}

#[test]
fn graph_get_next_node_unknown_current_action_errors() {
    let graph = GraphBuilder::new()
        .with_actions(vec![
            graph_action("counter", &[]),
            graph_action("result", &[]),
        ])
        .with_transition_when("counter", "counter", Condition::expr("count < 10"))
        .with_transition("counter", "result")
        .build()
        .expect("graph build should succeed");

    let error = graph
        .get_next_node(
            Some("unknown_step"),
            &state_from_pairs([("count", json!(0))]),
        )
        .expect_err("unknown current action should surface an error");

    assert!(matches!(
        error,
        GraphError::ActionNotFound {
            action_name,
            available_actions
        } if action_name == "unknown_step"
            && available_actions == vec!["counter".to_string(), "result".to_string()]
    ));
}

#[test]
fn graph_get_action_unknown_action_errors() {
    let graph = GraphBuilder::new()
        .with_actions(vec![
            graph_action("counter", &[]),
            graph_action("result", &[]),
        ])
        .with_transition_when("counter", "counter", Condition::expr("count < 10"))
        .with_transition("counter", "result")
        .build()
        .expect("graph build should succeed");

    let error = graph
        .get_action("unknown_step")
        .expect_err("unknown action lookup should fail");
    assert!(matches!(error, GraphError::ActionNotFound { .. }));
}

#[test]
fn get_actions_by_tag() {
    let graph = GraphBuilder::new()
        .with_actions(vec![
            graph_action("counter1", &["tag1", "tag2"]),
            graph_action("counter2", &["tag1", "tag3"]),
        ])
        .with_transition("counter1", "counter2")
        .with_transition("counter2", "counter1")
        .build()
        .expect("graph build should succeed");

    assert_eq!(
        graph
            .get_actions_by_tag("tag1")
            .expect("tag1 should exist")
            .len(),
        2
    );
    assert_eq!(
        graph
            .get_actions_by_tag("tag2")
            .expect("tag2 should exist")
            .len(),
        1
    );
    assert_eq!(
        graph
            .get_actions_by_tag("tag3")
            .expect("tag3 should exist")
            .len(),
        1
    );
    let error = graph
        .get_actions_by_tag("tag4")
        .expect_err("missing tag should fail");
    assert!(matches!(error, GraphError::TagNotFound { .. }));
}

#[test]
fn with_graph_does_not_overwrite_explicit_builder_entrypoint() {
    let imported = GraphBuilder::new()
        .with_actions(vec![
            graph_action("first", &[]),
            graph_action("second", &[]),
        ])
        .with_transition("first", "second")
        .with_entrypoint("first")
        .build()
        .expect("imported graph build should succeed");

    let graph = GraphBuilder::new()
        .with_action(graph_action("local", &[]))
        .with_entrypoint("local")
        .with_graph(&imported)
        .build()
        .expect("graph build should succeed");

    assert_eq!(graph.entrypoint(), "local");
}

#[test]
fn build_uses_first_inserted_action_when_entrypoint_not_set_after_graph_import() {
    let imported = GraphBuilder::new()
        .with_actions(vec![
            graph_action("imported_a", &[]),
            graph_action("imported_b", &[]),
        ])
        .with_transition("imported_a", "imported_b")
        .with_entrypoint("imported_b")
        .build()
        .expect("imported graph build should succeed");

    let graph = GraphBuilder::new()
        .with_action(graph_action("local_first", &[]))
        .with_graph(&imported)
        .build()
        .expect("graph build should succeed");

    assert_eq!(graph.entrypoint(), "local_first");
}
