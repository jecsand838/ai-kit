use crate::AdminPublishArgs;
use rurr_tracking_store::anchored_fs::{
    ManagedDirectoryMarker, OutputRootMode, OutputRootPolicy, PreparedOutputDirectory,
};
use serde::Deserialize;
use serde_json::to_string as json_string;
use std::env;
use std::error::Error;
use std::ffi::{OsStr, OsString};
use std::io;
use std::path::{Path, PathBuf};
use std::process::Command;

pub(crate) fn publish(args: AdminPublishArgs) -> Result<(), Box<dyn Error>> {
    let current_dir = env::current_dir()?;
    let cargo_binary = resolved_cargo_binary();
    let workspace = WorkspaceMetadata::discover(&cargo_binary, &current_dir)?;
    let dist_dir = prepare_dist_dir(&workspace, &current_dir, args.dist_dir)?;
    export_ui_bundle(&dist_dir)?;
    workspace.run_package_dry_run(&cargo_binary)?;

    println!(
        "Prepared dry-run publish artifacts in {}",
        dist_dir.path().display()
    );
    Ok(())
}

fn resolved_cargo_binary() -> OsString {
    env::var_os("CARGO").unwrap_or_else(|| OsString::from("cargo"))
}

#[derive(Debug, Deserialize)]
struct CargoMetadata {
    packages: Vec<CargoMetadataPackage>,
    workspace_root: PathBuf,
}

#[derive(Debug, Deserialize)]
struct CargoMetadataPackage {
    name: String,
    manifest_path: PathBuf,
}

#[derive(Debug)]
struct WorkspaceMetadata {
    workspace_root: PathBuf,
    packages: Vec<WorkspacePackage>,
}

#[derive(Debug)]
struct WorkspacePackage {
    name: String,
    manifest_dir: PathBuf,
}

fn prepare_dist_dir(
    workspace: &WorkspaceMetadata,
    current_dir: &Path,
    requested_dist_dir: Option<PathBuf>,
) -> io::Result<PreparedOutputDirectory> {
    let dist_dir = workspace.resolve_dist_dir(current_dir, requested_dist_dir)?;
    dist_dir.recreate()
}

impl WorkspaceMetadata {
    fn discover(cargo_binary: &OsStr, start_dir: &Path) -> io::Result<Self> {
        let output = Command::new(cargo_binary)
            .current_dir(start_dir)
            .arg("metadata")
            .arg("--format-version")
            .arg("1")
            .arg("--no-deps")
            .output()?;
        if !output.status.success() {
            return Err(io::Error::other(format!(
                "cargo metadata failed with status {}: {}",
                output.status,
                String::from_utf8_lossy(&output.stderr)
            )));
        }

        let metadata: CargoMetadata = serde_json::from_slice(&output.stdout)
            .map_err(|error| io::Error::other(format!("parse cargo metadata output: {error}")))?;
        let mut packages = metadata
            .packages
            .into_iter()
            .filter_map(|package| {
                let manifest_dir = package.manifest_path.parent()?.to_path_buf();
                Some(WorkspacePackage {
                    name: package.name,
                    manifest_dir,
                })
            })
            .collect::<Vec<_>>();
        packages.sort_by(|left, right| left.name.cmp(&right.name));

        Ok(Self {
            workspace_root: metadata.workspace_root,
            packages,
        })
    }

    fn resolve_dist_dir(
        &self,
        current_dir: &Path,
        requested_dist_dir: Option<PathBuf>,
    ) -> io::Result<PreparedOutputDirectory> {
        let requested_dist_dir =
            requested_dist_dir.unwrap_or_else(|| self.workspace_root.join("dist"));
        let dist_root = self.workspace_root.join("dist");
        let protected_roots = [current_dir, self.workspace_root.as_path()];
        let allowed_roots = [dist_root.as_path()];
        let policy = OutputRootPolicy::new(&protected_roots)
            .allow_only_within_scope(self.workspace_root.as_path(), &allowed_roots);
        PreparedOutputDirectory::prepare(
            current_dir,
            &requested_dist_dir,
            "dist_dir",
            &policy,
            OutputRootMode::Managed(ManagedDirectoryMarker::rurr_cli()),
        )
    }

    fn run_package_dry_run(&self, cargo_binary: &OsStr) -> io::Result<()> {
        let mut command = Command::new(cargo_binary);
        command.current_dir(&self.workspace_root);
        for arg in package_dry_run_args(&self.packages)? {
            command.arg(arg);
        }

        let output = command.output()?;
        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            let stderr = stderr.trim();
            let message = if stderr.is_empty() {
                format!("cargo package dry-run failed with status {}", output.status)
            } else {
                format!(
                    "cargo package dry-run failed with status {}: {stderr}",
                    output.status
                )
            };
            return Err(io::Error::other(message));
        }
        Ok(())
    }
}

fn package_dry_run_args(packages: &[WorkspacePackage]) -> io::Result<Vec<String>> {
    let mut args = vec![
        "package".to_string(),
        "--workspace".to_string(),
        "--all-features".to_string(),
        "--allow-dirty".to_string(),
        "--no-verify".to_string(),
        "--frozen".to_string(),
    ];
    for config in workspace_patch_configs(packages)? {
        args.push("--config".to_string());
        args.push(config);
    }
    Ok(args)
}

fn export_ui_bundle(dist_dir: &PreparedOutputDirectory) -> io::Result<()> {
    let ui_dir_path = dist_dir.path().join("rurr-ui");
    rurr_tracking_server::ui_assets::write_embedded_bundle(&ui_dir_path).map_err(|error| {
        io::Error::new(
            error.kind(),
            format!(
                "export embedded UI bundle into {}: {error}",
                ui_dir_path.display()
            ),
        )
    })
}

fn workspace_patch_configs(packages: &[WorkspacePackage]) -> io::Result<Vec<String>> {
    let mut configs = Vec::with_capacity(packages.len());
    for package in packages {
        let quoted_path = json_string(&package.manifest_dir.to_string_lossy().into_owned())
            .map_err(io::Error::other)?;
        configs.push(format!(
            "patch.crates-io.{}.path={quoted_path}",
            package.name
        ));
    }
    Ok(configs)
}

#[cfg(test)]
mod tests {
    use super::{
        package_dry_run_args, prepare_dist_dir, workspace_patch_configs, WorkspaceMetadata,
        WorkspacePackage,
    };
    use std::fs;
    use std::path::PathBuf;

    #[test]
    fn package_dry_run_args_include_patch_pairs_for_each_workspace_package() {
        let args = package_dry_run_args(&[
            WorkspacePackage {
                name: "rurr-tracking-store".to_string(),
                manifest_dir: PathBuf::from("/workspace/crates/rurr-tracking-store"),
            },
            WorkspacePackage {
                name: "rurr-core".to_string(),
                manifest_dir: PathBuf::from("/workspace/crates/rurr-core"),
            },
        ])
        .expect("package args should build");

        assert_eq!(
            &args[..6],
            &[
                "package",
                "--workspace",
                "--all-features",
                "--allow-dirty",
                "--no-verify",
                "--frozen",
            ]
        );
        assert_eq!(
            args[6..],
            vec![
                "--config",
                "patch.crates-io.rurr-tracking-store.path=\"/workspace/crates/rurr-tracking-store\"",
                "--config",
                "patch.crates-io.rurr-core.path=\"/workspace/crates/rurr-core\"",
            ]
        );
    }

    #[test]
    fn prepare_dist_dir_recreates_existing_workspace_dist_dir() {
        let scratch = tempfile::tempdir().expect("scratch tempdir should be created");
        let workspace_root = scratch
            .path()
            .canonicalize()
            .expect("scratch tempdir should canonicalize")
            .join("workspace");
        let nested_cwd = workspace_root.join("crates").join("rurr-cli").join("src");
        let dist_dir = workspace_root.join("dist");
        let stale_file = dist_dir.join("stale").join("old.txt");
        fs::create_dir_all(&nested_cwd).expect("nested cwd should be created");
        fs::create_dir_all(
            stale_file
                .parent()
                .expect("stale file should have a parent directory"),
        )
        .expect("stale directory should be created");
        fs::write(&stale_file, "stale").expect("stale file should be written");

        let workspace = WorkspaceMetadata {
            workspace_root: workspace_root.clone(),
            packages: Vec::new(),
        };

        let prepared =
            prepare_dist_dir(&workspace, &nested_cwd, None).expect("dist dir should prepare");

        assert_eq!(prepared.path(), dist_dir.as_path());
        assert!(
            !stale_file.exists(),
            "preparing the default workspace dist dir should clear stale contents"
        );
    }

    #[test]
    fn workspace_patch_configs_preserve_workspace_package_order() {
        let configs = workspace_patch_configs(&[
            WorkspacePackage {
                name: "alpha".to_string(),
                manifest_dir: PathBuf::from("/workspace/alpha"),
            },
            WorkspacePackage {
                name: "omega".to_string(),
                manifest_dir: PathBuf::from("/workspace/omega"),
            },
        ])
        .expect("patch configs should build");

        assert_eq!(
            configs,
            vec![
                "patch.crates-io.alpha.path=\"/workspace/alpha\"".to_string(),
                "patch.crates-io.omega.path=\"/workspace/omega\"".to_string(),
            ]
        );
    }
}
