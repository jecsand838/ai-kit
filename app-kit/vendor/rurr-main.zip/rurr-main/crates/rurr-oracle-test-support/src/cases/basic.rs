use super::support::{
    build_counter_action, build_registered_app_from_definition, map_from_pairs, state_from_pairs,
};
use crate::manifest::BurrOracleScenario;
use indexmap::IndexMap;
use rurr_core::action::{Condition, FunctionActionBuilder};
use rurr_core::application::ApplicationBuilder;
use rurr_core::graph::Transition;
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::tracking::LocalTrackingClient;
use rurr_core::visibility::{trace, TraceOptions, TraceSpanHandle};
use serde_json::{json, Value};
use std::error::Error;
use std::sync::Arc;

const RURR_CREATE_ONLY_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"count\"])\n",
    "    .writes([\"count\"])\n",
    "    .build_sync(|state, _ctx| {\n",
    "        map_from_pairs([(\"count\", state.get(\"count\").cloned().unwrap_or_else(|| json!(0)))])\n",
    "    })\n",
);

const RURR_DECIDE_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"count\"])\n",
    "    .writes([\"count\"])\n",
    "    .build_sync(|state, _ctx| {\n",
    "        map_from_pairs([(\"count\", state.get(\"count\").cloned().unwrap_or_else(|| json!(0)))])\n",
    "    })\n",
);

const RURR_EVEN_BRANCH_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"count\"])\n",
    "    .writes([\"parity\"])\n",
    "    .build_sync(|_state, _ctx| map_from_pairs([(\"parity\", json!(\"even\"))]))\n",
);

const RURR_ODD_BRANCH_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"count\"])\n",
    "    .writes([\"parity\"])\n",
    "    .build_sync(|_state, _ctx| map_from_pairs([(\"parity\", json!(\"odd\"))]))\n",
);

const RURR_IDENTITY_CREATOR_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"generated_topic\"])\n",
    "    .writes([\"generated_topic\"])\n",
    "    .build_sync(|state, _ctx| {\n",
    "        map_from_pairs([(\"generated_topic\", state.get(\"generated_topic\").cloned().unwrap_or(Value::Null))])\n",
    "    })\n",
);

const RURR_IDENTITY_RETRY_CREATOR_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"generated_topic\"])\n",
    "    .writes([\"generated_topic\", \"topic_feedback\"])\n",
    "    .build_sync(|_state, _ctx| {\n",
    "        map_from_pairs([\n",
    "            (\"generated_topic\", json!(\"condition parity\")),\n",
    "            (\"topic_feedback\", json!(\"needs review\")),\n",
    "        ])\n",
    "    })\n",
);

const RURR_IDENTITY_REVIEW_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"topic_feedback\"])\n",
    "    .writes([\"outcome\"])\n",
    "    .build_sync(|state, _ctx| {\n",
    "        map_from_pairs([(\"outcome\", state.get(\"topic_feedback\").cloned().unwrap_or(Value::Null))])\n",
    "    })\n",
);

const RURR_TRACED_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"count\"])\n",
    "    .writes([\"count\"])\n",
    "    .build_sync(|state, ctx| {\n",
    "        let next_count = state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1;\n",
    "        trace(&ctx.tracer, \"increment\", &IndexMap::new(), &TraceOptions::new(), |outer| {\n",
    "            outer.trace_child_with_dependencies(\"inner\", vec![\"counter_dep\".to_string()], |inner| {\n",
    "                inner.log_attribute(\"counter\", json!(next_count)).expect(\"attribute logging should succeed\");\n",
    "            }).expect(\"nested span should succeed\");\n",
    "            map_from_pairs([(\"count\", json!(next_count))])\n",
    "        }).expect(\"trace should succeed\")\n",
    "    })\n",
);

pub(super) fn run_00_create_only(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<(), Box<dyn Error>> {
    let create_only = FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .with_source_code(RURR_CREATE_ONLY_SOURCE)
        .build_sync(|state, _ctx| {
            map_from_pairs([(
                "count",
                state.get("count").cloned().unwrap_or_else(|| json!(0)),
            )])
        })?;

    let _app = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(0))]))?
            .with_actions(vec![("create_only", create_only)])?
            .with_transitions(Vec::<Transition>::new())?
            .with_entrypoint("create_only")?,
        definition,
        tracker,
        hooks,
    )?;
    Ok(())
}

pub(super) fn run_01_counter_basic(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<(), Box<dyn Error>> {
    let counter = build_counter_action()?;

    let mut app = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(0))]))?
            .with_actions(vec![("counter", counter)])?
            .with_transitions(vec![Transition::new(
                "counter",
                "counter",
                Condition::default(),
            )])?
            .with_entrypoint("counter")?,
        definition,
        tracker,
        hooks,
    )?;

    for _ in 0..3 {
        app.step(None)?;
    }

    Ok(())
}

pub(super) fn run_02_branching_expr(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<(), Box<dyn Error>> {
    let decide = FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .with_source_code(RURR_DECIDE_SOURCE)
        .build_sync(|state, _ctx| {
            map_from_pairs([(
                "count",
                state.get("count").cloned().unwrap_or_else(|| json!(0)),
            )])
        })?;

    let even_branch = FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["parity"])
        .with_source_code(RURR_EVEN_BRANCH_SOURCE)
        .build_sync(|_state, _ctx| map_from_pairs([("parity", json!("even"))]))?;

    let odd_branch = FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["parity"])
        .with_source_code(RURR_ODD_BRANCH_SOURCE)
        .build_sync(|_state, _ctx| map_from_pairs([("parity", json!("odd"))]))?;

    let mut app = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(2))]))?
            .with_actions(vec![
                ("decide", decide),
                ("even_branch", even_branch),
                ("odd_branch", odd_branch),
            ])?
            .with_transitions(vec![
                Transition::new("decide", "even_branch", Condition::expr("count % 2 == 0")),
                Transition::new("decide", "odd_branch", Condition::default()),
            ])?
            .with_entrypoint("decide")?,
        definition,
        tracker,
        hooks,
    )?;

    let halt_after = vec!["even_branch".to_string(), "odd_branch".to_string()];
    app.run_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))?;

    Ok(())
}

pub(super) fn run_05_condition_identity_expr(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<(), Box<dyn Error>> {
    let creator = FunctionActionBuilder::new()
        .reads(["generated_topic"])
        .writes(["generated_topic"])
        .with_source_code(RURR_IDENTITY_CREATOR_SOURCE)
        .build_sync(|state, _ctx| {
            map_from_pairs([(
                "generated_topic",
                state.get("generated_topic").cloned().unwrap_or(Value::Null),
            )])
        })?;

    let retry_creator = FunctionActionBuilder::new()
        .reads(["generated_topic"])
        .writes(["generated_topic", "topic_feedback"])
        .with_source_code(RURR_IDENTITY_RETRY_CREATOR_SOURCE)
        .build_sync(|_state, _ctx| {
            map_from_pairs([
                ("generated_topic", json!("condition parity")),
                ("topic_feedback", json!("needs review")),
            ])
        })?;

    let review = FunctionActionBuilder::new()
        .reads(["topic_feedback"])
        .writes(["outcome"])
        .with_source_code(RURR_IDENTITY_REVIEW_SOURCE)
        .build_sync(|state, _ctx| {
            map_from_pairs([(
                "outcome",
                state.get("topic_feedback").cloned().unwrap_or(Value::Null),
            )])
        })?;

    let mut app = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([
                ("generated_topic", Value::Null),
                ("topic_feedback", Value::Null),
            ]))?
            .with_actions(vec![
                ("creator", creator),
                ("retry_creator", retry_creator),
                ("review", review),
            ])?
            .with_transitions(vec![
                Transition::new(
                    "creator",
                    "retry_creator",
                    Condition::expr("generated_topic is None"),
                ),
                Transition::new(
                    "retry_creator",
                    "review",
                    Condition::expr("topic_feedback is not None"),
                ),
            ])?
            .with_entrypoint("creator")?,
        definition,
        tracker,
        hooks,
    )?;

    let halt_after = vec!["review".to_string()];
    app.run_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))?;

    Ok(())
}

pub(super) fn run_03_spans_and_attributes(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<(), Box<dyn Error>> {
    let traced = FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .with_source_code(RURR_TRACED_SOURCE)
        .build_sync(|state, ctx| {
            let next_count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            trace(
                &ctx.tracer,
                "increment",
                &IndexMap::new(),
                &TraceOptions::new()
                    .with_capture_inputs(false)
                    .with_capture_auto_attributes(false)
                    .with_capture_outputs(false),
                |outer: TraceSpanHandle| {
                    outer
                        .trace_child_with_dependencies(
                            "inner",
                            vec!["counter_dep".to_string()],
                            |inner: TraceSpanHandle| {
                                inner
                                    .log_attribute("counter", json!(next_count))
                                    .expect("attribute logging should succeed");
                            },
                        )
                        .expect("nested span should succeed");
                    map_from_pairs([("count", json!(next_count))])
                },
            )
            .expect("trace should succeed")
        })?;

    let mut app = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(0))]))?
            .with_actions(vec![("traced", traced)])?
            .with_transitions(Vec::<Transition>::new())?
            .with_entrypoint("traced")?,
        definition,
        tracker,
        hooks,
    )?;

    app.step(None)?;
    Ok(())
}
