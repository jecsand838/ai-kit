use async_trait::async_trait;
use indexmap::IndexMap;
use mongodb::bson::{doc, Document};
use mongodb::sync::Client as MongoClient;
use mongodb::IndexModel;
use rurr_core::action::{Condition, FunctionActionBuilder};
use rurr_core::application::ApplicationBuilder;
use rurr_core::graph::Transition;
use rurr_mongodb::{MongoPersister, MongoPersisterConfig};
use rurr_persistence::{
    ApplicationPersistenceSpec, BaseStateLoader, BaseStateSaver, PersistedStateStatus,
    PersistenceError, PersistenceLoadTarget,
};
use rurr_testkit::application_fixture::register_prefixed_string_field_serde;
use rurr_testkit::persistence_cases::{
    self, map_from_pairs, run_sync_case, PersistenceConfigLane, PersistenceLane,
    PersistenceOrderingLane, PersistenceReprobeLane,
};
use rurr_testkit::{
    drop_mongodb_collection_sync, ready_mongodb_uri_sync, unique_mongodb_collection_name,
};
use serde_json::{json, Value};
use std::sync::Arc;
const TEST_DB_NAME: &str = "rurr_mongodb_integration";
const UNIQUE_RECORD_INDEX_NAME: &str = "unique_record";
const LATEST_PARTITION_INDEX_NAME: &str = "latest_partition";
const LATEST_APP_INDEX_NAME: &str = "latest_app";
const LIST_APP_IDS_INDEX_NAME: &str = "list_app_ids";
const SUB_MILLISECOND_OLDER_CREATED_AT: &str = "2026-03-18T12:34:56.123456700Z";
const SUB_MILLISECOND_NEWER_CREATED_AT: &str = "2026-03-18T12:34:56.123456900Z";

fn completed_state_document(
    partition_key: &'static str,
    app_id: &'static str,
    sequence_id: i64,
    position: &'static str,
    marker: &'static str,
    created_at: &'static str,
) -> Document {
    doc! {
        "partition_key": partition_key,
        "app_id": app_id,
        "sequence_id": sequence_id,
        "position": position,
        "status": "completed",
        "state": format!(r#"{{"marker":"{marker}"}}"#),
        "created_at": created_at,
    }
}

fn live_config(prefix: &str) -> MongoPersisterConfig {
    MongoPersisterConfig {
        uri: ready_mongodb_uri_sync().expect("mongodb must be reachable for live tests"),
        db_name: TEST_DB_NAME.to_string(),
        collection_name: unique_mongodb_collection_name(prefix),
    }
}

fn with_live_persister<T>(
    prefix: &str,
    test: impl FnOnce(Arc<MongoPersister>, &MongoPersisterConfig) -> T,
) -> T {
    let config = live_config(prefix);
    let persister = Arc::new(MongoPersister::new(config.clone()).expect("persister should create"));
    persister.initialize().expect("initialize should succeed");

    let output = test(Arc::clone(&persister), &config);

    let _ = persister.cleanup();
    cleanup_collection(&config);
    output
}

struct LiveMongoLane {
    config: MongoPersisterConfig,
    persister: Arc<MongoPersister>,
}

impl LiveMongoLane {
    fn new(prefix: &str) -> Self {
        let config = live_config(prefix);
        let persister =
            Arc::new(MongoPersister::new(config.clone()).expect("persister should create"));
        Self { config, persister }
    }
}

#[async_trait(?Send)]
impl PersistenceLane for LiveMongoLane {
    async fn initialize(&self) -> Result<(), PersistenceError> {
        self.persister.initialize()
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.persister.is_initialized()
    }

    async fn cleanup(&self) -> Result<(), PersistenceError> {
        let cleanup_result = self.persister.cleanup();
        cleanup_collection(&self.config);
        cleanup_result
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: persistence_cases::PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.persister
            .save(partition_key, app_id, sequence_id, position, state, status)
    }

    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<rurr_persistence::PersistedStateData>, PersistenceError> {
        self.persister.load(partition_key, app_id, sequence_id)
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        self.persister.list_app_ids(partition_key)
    }
}

#[async_trait(?Send)]
impl PersistenceConfigLane for LiveMongoLane {
    async fn rebuild_from_config(&self) -> Result<Self, PersistenceError> {
        let config = self.config.clone();
        Ok(Self {
            persister: Arc::new(MongoPersister::new(config.clone())?),
            config,
        })
    }
}

#[async_trait(?Send)]
impl PersistenceOrderingLane for LiveMongoLane {
    async fn seed_latest_partition_order_fixture(&self) -> Result<(), PersistenceError> {
        insert_raw_documents(
            &self.config,
            vec![
                completed_state_document(
                    "partition",
                    "older_created_at_higher_seq",
                    99,
                    "step_old",
                    "old",
                    SUB_MILLISECOND_OLDER_CREATED_AT,
                ),
                completed_state_document(
                    "partition",
                    "newer_created_at_lower_seq",
                    1,
                    "step_new",
                    "new",
                    SUB_MILLISECOND_NEWER_CREATED_AT,
                ),
            ],
        );
        Ok(())
    }

    async fn seed_exact_sequence_order_fixture(&self) -> Result<(), PersistenceError> {
        insert_raw_documents(
            &self.config,
            vec![
                completed_state_document(
                    "partition",
                    "app_id",
                    7,
                    "step_z",
                    "older",
                    "2026-02-20T00:00:00.000000000Z",
                ),
                completed_state_document(
                    "partition",
                    "app_id",
                    7,
                    "step_a",
                    "newer_low_position",
                    "2026-02-21T00:00:00.000000000Z",
                ),
                completed_state_document(
                    "partition",
                    "app_id",
                    7,
                    "step_b",
                    "newer_high_position",
                    "2026-02-21T00:00:00.000000001Z",
                ),
            ],
        );
        Ok(())
    }

    async fn seed_list_app_ids_order_fixture(&self) -> Result<Vec<String>, PersistenceError> {
        insert_raw_documents(
            &self.config,
            vec![
                completed_state_document(
                    "partition",
                    "older_created_at_higher_seq",
                    99,
                    "step_old",
                    "old",
                    SUB_MILLISECOND_OLDER_CREATED_AT,
                ),
                completed_state_document(
                    "partition",
                    "newer_created_at_lower_seq",
                    1,
                    "step_new",
                    "new",
                    SUB_MILLISECOND_NEWER_CREATED_AT,
                ),
            ],
        );
        Ok(vec![
            "newer_created_at_lower_seq".to_string(),
            "older_created_at_higher_seq".to_string(),
        ])
    }
}

#[async_trait(?Send)]
impl PersistenceReprobeLane for LiveMongoLane {
    async fn external_initialize(&self) -> Result<(), PersistenceError> {
        external_initialize_collection(&self.config);
        Ok(())
    }

    async fn drop_storage(&self) {
        drop_collection(&self.config);
    }

    async fn assert_post_drop_invariants(&self) {
        assert!(
            !collection_exists(&self.config),
            "failed operations must not recreate a dropped collection"
        );
    }
}

#[test]
fn persistence_spec_resume_roundtrips_registered_field_serde() {
    rurr_testkit::require_check_live_tests!();

    let lane = LiveMongoLane::new("serde_resume");
    let field_name = unique_mongodb_collection_name("serde_field");
    let app_id = "mongo_serde_resume_app".to_string();
    register_prefixed_string_field_serde(&field_name, "serialized::")
        .expect("field serde registration should succeed");

    let result = run_sync_case(persistence_cases::run_with_cleanup(&lane, async {
        lane.initialize().await?;

        let mut first_app = build_serde_resume_app(&lane, &field_name, &app_id);
        let first_step = first_app
            .step(None)
            .expect("step should succeed")
            .expect("step should execute");
        assert_eq!(first_step.action.name(), "start");
        assert_eq!(
            first_step.state.get(&field_name),
            Some(&json!("persisted via serde"))
        );

        let stored = lane
            .load(Some("tenant"), Some(&app_id), Some(0))
            .await?
            .expect("stored state should exist");
        assert_eq!(
            stored
                .state
                .as_ref()
                .and_then(|state| state.get(&field_name)),
            Some(&json!({"value": "serialized::persisted via serde"}))
        );

        let mut resumed_app = build_serde_resume_app(&lane, &field_name, &app_id);
        assert_eq!(
            resumed_app.state().get(&field_name),
            Some(&json!("persisted via serde"))
        );
        assert_eq!(resumed_app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
        assert_eq!(
            resumed_app.state().get("__PRIOR_STEP"),
            Some(&json!("start"))
        );

        let resumed_step = resumed_app
            .step(None)
            .expect("resumed step should succeed")
            .expect("resumed step should execute");
        assert_eq!(resumed_step.action.name(), "finish");
        assert_eq!(
            resumed_step.state.get("output"),
            Some(&json!("persisted via serde"))
        );

        Ok::<(), PersistenceError>(())
    }));

    result.expect("serde resume assertions should succeed");
}

#[test]
fn panic_cleanup_drops_mongodb_collection() {
    rurr_testkit::require_check_live_tests!();

    let lane = LiveMongoLane::new("panic_cleanup");
    let config = lane.config.clone();

    let panic_result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        run_sync_case(persistence_cases::run_with_cleanup(&lane, async {
            lane.initialize().await?;
            lane.save(
                Some("tenant"),
                "panic_cleanup_app",
                0,
                "start",
                map_from_pairs([("value", json!("panic"))]),
                PersistedStateStatus::Completed,
            )
            .await?;
            panic!("synthetic mongo panic")
        }))
    }));

    assert!(panic_result.is_err(), "panic fixture should unwind");

    let verification = MongoPersister::new(config).expect("verification persister should create");
    let load_error = verification
        .load(Some("tenant"), Some("panic_cleanup_app"), Some(0))
        .expect_err("panic cleanup should drop the live test collection");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

fn external_initialize_collection(config: &MongoPersisterConfig) {
    let persister = MongoPersister::new(config.clone()).expect("external persister should create");
    persister
        .initialize()
        .expect("external initialize should succeed");
    persister
        .cleanup()
        .expect("external cleanup should succeed");
}

fn drop_collection(config: &MongoPersisterConfig) {
    raw_collection(config)
        .drop()
        .run()
        .expect("collection drop should succeed");
}

fn cleanup_collection(config: &MongoPersisterConfig) {
    let _ = drop_mongodb_collection_sync(
        config.uri.as_str(),
        config.db_name.as_str(),
        config.collection_name.as_str(),
    );
}

fn counter_builder() -> ApplicationBuilder {
    let start_action = FunctionActionBuilder::new()
        .writes(vec!["count".to_string()])
        .build_sync(|state, _ctx| {
            let next = state
                .get("count")
                .and_then(Value::as_i64)
                .unwrap_or_default()
                + 1;
            IndexMap::from([(String::from("count"), Value::from(next))])
        })
        .expect("action should build");
    let finish_action = FunctionActionBuilder::new()
        .writes(vec!["count".to_string()])
        .build_sync(|state, _ctx| {
            let next = state
                .get("count")
                .and_then(Value::as_i64)
                .unwrap_or_default()
                + 1;
            IndexMap::from([(String::from("count"), Value::from(next))])
        })
        .expect("action should build");

    ApplicationBuilder::new()
        .with_actions(vec![("start", start_action), ("finish", finish_action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "start",
            "finish",
            Condition::default(),
        )])
        .expect("transitions should configure")
}

fn build_counter_app(
    lane: &LiveMongoLane,
    app_id: &str,
    partition_key: Option<String>,
    load_target: Option<PersistenceLoadTarget>,
) -> rurr_core::application::Application {
    counter_builder()
        .with_identifiers(app_id, partition_key, None)
        .expect("identifiers should configure")
        .with_persistence_spec(persistence_spec(lane.persister.clone(), load_target))
        .expect("persistence spec should configure")
        .build()
        .expect("build should succeed")
}

fn step_counter_app(
    app: &mut rurr_core::application::Application,
) -> rurr_core::application::StepOutput {
    app.step(None)
        .expect("step should succeed")
        .expect("step should execute")
}

fn persistence_spec(
    persister: Arc<MongoPersister>,
    load_target: Option<PersistenceLoadTarget>,
) -> ApplicationPersistenceSpec {
    ApplicationPersistenceSpec::sync_resume(
        persister,
        true,
        map_from_pairs([("count", json!(0))]),
        "start",
        None,
        load_target,
    )
}

fn serde_resume_builder(
    field_name: &str,
    app_id: &str,
    persister: Arc<MongoPersister>,
) -> ApplicationBuilder {
    let start_field = field_name.to_string();
    let finish_field = field_name.to_string();

    let start_action = FunctionActionBuilder::new()
        .writes(vec![start_field.clone()])
        .build_sync(move |_state, _ctx| {
            IndexMap::from([(start_field.clone(), json!("persisted via serde"))])
        })
        .expect("start action should build");
    let finish_action = FunctionActionBuilder::new()
        .reads(vec![finish_field.clone()])
        .writes(["output"])
        .build_sync(move |state, _ctx| {
            IndexMap::from([(
                "output".to_string(),
                state.get(&finish_field).cloned().unwrap_or(Value::Null),
            )])
        })
        .expect("finish action should build");

    ApplicationBuilder::new()
        .with_actions(vec![("start", start_action), ("finish", finish_action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "start",
            "finish",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_identifiers(app_id, Some("tenant".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(ApplicationPersistenceSpec::sync_resume(
            persister,
            true,
            IndexMap::new(),
            "start",
            None,
            None,
        ))
        .expect("persistence spec should configure")
}

fn build_serde_resume_app(
    lane: &LiveMongoLane,
    field_name: &str,
    app_id: &str,
) -> rurr_core::application::Application {
    serde_resume_builder(field_name, app_id, lane.persister.clone())
        .build()
        .expect("build should succeed")
}

fn assert_connection_closed(error: PersistenceError) {
    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation { operation } if operation == "connection_closed"
    ));
}

fn assert_not_initialized(error: PersistenceError) {
    assert!(
        matches!(error, PersistenceError::NotInitialized),
        "expected NotInitialized, got {error:?}"
    );
}

fn collection_exists(config: &MongoPersisterConfig) -> bool {
    let client =
        MongoClient::with_uri_str(config.uri.as_str()).expect("inspection client should construct");
    client
        .database(config.db_name.as_str())
        .list_collection_names()
        .run()
        .expect("collection names should load")
        .into_iter()
        .any(|name| name == config.collection_name)
}

fn collection_index_names(config: &MongoPersisterConfig) -> Vec<String> {
    let client =
        MongoClient::with_uri_str(config.uri.as_str()).expect("inspection client should construct");
    let collection = client
        .database(config.db_name.as_str())
        .collection::<Document>(config.collection_name.as_str());
    let mut cursor = collection
        .list_indexes()
        .run()
        .expect("index listing should succeed");
    let mut names = Vec::new();

    while cursor.advance().expect("index cursor should advance") {
        let model: IndexModel = cursor
            .deserialize_current()
            .expect("index model should deserialize");
        names.push(
            model
                .options
                .and_then(|options| options.name)
                .expect("index should have a name"),
        );
    }

    names
}

fn drop_required_index(config: &MongoPersisterConfig, index_name: &str) {
    let client =
        MongoClient::with_uri_str(config.uri.as_str()).expect("inspection client should construct");
    client
        .database(config.db_name.as_str())
        .collection::<Document>(config.collection_name.as_str())
        .drop_index(index_name)
        .run()
        .expect("index drop should succeed");
}

fn raw_collection(config: &MongoPersisterConfig) -> mongodb::sync::Collection<Document> {
    let client =
        MongoClient::with_uri_str(config.uri.as_str()).expect("inspection client should construct");
    client
        .database(config.db_name.as_str())
        .collection::<Document>(config.collection_name.as_str())
}

fn insert_raw_documents(config: &MongoPersisterConfig, documents: Vec<Document>) {
    raw_collection(config)
        .insert_many(documents)
        .run()
        .expect("raw insert should succeed");
}

fn load_raw_document(config: &MongoPersisterConfig, filter: Document) -> Document {
    raw_collection(config)
        .find_one(filter)
        .run()
        .expect("raw find_one should succeed")
        .expect("raw document should exist")
}

fn assert_fixed_width_rfc3339_nanos(value: &str) {
    let without_suffix = value
        .strip_suffix('Z')
        .expect("created_at should use a UTC Z suffix");
    let (base, fractional) = without_suffix
        .rsplit_once('.')
        .expect("created_at should include a fractional second component");

    assert!(
        base.contains('T'),
        "created_at should keep RFC3339 date/time structure"
    );
    assert_eq!(
        fractional.len(),
        9,
        "created_at should preserve nanosecond precision with fixed-width fractional digits"
    );
    assert!(
        fractional.chars().all(|ch| ch.is_ascii_digit()),
        "created_at fractional digits should be numeric"
    );
}

fn seed_partition_records(persister: &MongoPersister) {
    persister
        .save(
            Some("partition"),
            "app_a",
            1,
            "position_1",
            map_from_pairs([("value", json!("v1"))]),
            PersistedStateStatus::Completed,
        )
        .expect("first save should succeed");
    persister
        .save(
            Some("partition"),
            "app_b",
            2,
            "position_2",
            map_from_pairs([("value", json!("v2"))]),
            PersistedStateStatus::Completed,
        )
        .expect("second save should succeed");
    persister
        .save(
            Some("partition"),
            "app_a",
            3,
            "position_3",
            map_from_pairs([("value", json!("v3"))]),
            PersistedStateStatus::Failed,
        )
        .expect("third save should succeed");
}

macro_rules! mongo_live_case_tests {
    ($(($name:ident, $prefix:literal, $body:expr, $message:literal)),+ $(,)?) => {
        $(
            #[test]
            fn $name() {
                rurr_testkit::require_check_live_tests!();
                let lane = LiveMongoLane::new($prefix);
                run_sync_case($body(&lane)).expect($message);
            }
        )+
    };
}

#[test]
fn config_roundtrip_preserves_values() {
    let config = MongoPersisterConfig {
        uri: "mongodb://127.0.0.1:27017".to_string(),
        db_name: "db_name".to_string(),
        collection_name: "collection_name".to_string(),
    };

    let persister = MongoPersister::new(config.clone()).expect("persister should build");

    assert_eq!(persister.config(), config);
}

#[test]
fn invalid_uri_is_rejected_without_contacting_a_server() {
    let error = match MongoPersister::new(rurr_mongodb::MongoPersisterConfig::new(
        "not-a-valid-uri",
        TEST_DB_NAME,
        "states",
    )) {
        Ok(_) => panic!("invalid URIs must fail fast"),
        Err(error) => error,
    };

    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation {
            operation: "mongodb_connect_failed"
        }
    ));
}

#[test]
fn cleanup_is_idempotent_and_terminal_for_public_entrypoints() {
    let persister = MongoPersister::new(rurr_mongodb::MongoPersisterConfig::new(
        "mongodb://127.0.0.1:27017",
        TEST_DB_NAME,
        "cleanup_terminal",
    ))
    .expect("persister should build without contacting the server");

    persister.cleanup().expect("first cleanup should succeed");
    persister
        .cleanup()
        .expect("second cleanup should also succeed");

    assert_connection_closed(
        persister
            .initialize()
            .expect_err("initialize should fail after cleanup"),
    );
    assert_connection_closed(
        persister
            .load(Some("partition"), Some("app_id"), None)
            .expect_err("load should fail after cleanup"),
    );
    assert_connection_closed(
        persister
            .list_app_ids(Some("partition"))
            .expect_err("list_app_ids should fail after cleanup"),
    );
    assert_connection_closed(
        persister
            .save(
                Some("partition"),
                "app_id",
                1,
                "position_1",
                map_from_pairs([("value", json!("cleanup"))]),
                PersistedStateStatus::Completed,
            )
            .expect_err("save should fail after cleanup"),
    );
}

#[test]
fn initialize_is_initialized_and_cleanup_are_explicit() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("initialize", |persister, _config| {
        assert!(persister
            .is_initialized()
            .expect("is_initialized should succeed after initialize"));

        persister.cleanup().expect("cleanup should succeed");
        let error = persister
            .load(Some("partition"), Some("app_id"), None)
            .expect_err("load should fail after cleanup");
        assert_connection_closed(error);
    });
}

#[test]
fn sub_millisecond_ordering_fixture_timestamps_stay_within_one_second_and_increase() {
    assert_eq!(
        &SUB_MILLISECOND_OLDER_CREATED_AT[..19],
        &SUB_MILLISECOND_NEWER_CREATED_AT[..19],
        "sub-millisecond fixture timestamps must share the same second",
    );
    assert!(
        SUB_MILLISECOND_OLDER_CREATED_AT < SUB_MILLISECOND_NEWER_CREATED_AT,
        "fixture timestamps must increase lexicographically",
    );
}

#[test]
fn save_persists_fixed_width_nanosecond_created_at() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("created_at_precision", |persister, config| {
        persister
            .save(
                Some("partition"),
                "app_id",
                1,
                "position_1",
                map_from_pairs([("value", json!("saved"))]),
                PersistedStateStatus::Completed,
            )
            .expect("save should succeed");

        let document = load_raw_document(
            config,
            doc! {
                "partition_key": "partition",
                "app_id": "app_id",
                "sequence_id": 1_i64,
                "position": "position_1",
            },
        );
        let created_at = document
            .get_str("created_at")
            .expect("raw document should contain created_at");

        assert_fixed_width_rfc3339_nanos(created_at);
    });
}

#[test]
fn initialize_is_idempotent_for_a_second_persister_instance() {
    rurr_testkit::require_check_live_tests!();

    let config = live_config("reinitialize");

    let persister_one = MongoPersister::new(config.clone()).expect("first persister should create");
    persister_one
        .initialize()
        .expect("first initialize should succeed");

    let persister_two =
        MongoPersister::new(config.clone()).expect("second persister should create");
    persister_two
        .initialize()
        .expect("second initialize should also succeed");

    assert!(
        persister_two
            .is_initialized()
            .expect("second persister should report initialized"),
        "second persister should observe the already-created collection and indexes"
    );

    assert!(
        collection_index_names(&config)
            .iter()
            .any(|name| name == UNIQUE_RECORD_INDEX_NAME),
        "re-initialize should preserve the required indexes"
    );

    persister_two.cleanup().expect("cleanup should succeed");
    persister_one.cleanup().expect("cleanup should succeed");
    cleanup_collection(&config);
}

#[test]
fn external_collection_drop_forces_not_initialized_and_does_not_recreate_collection() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("collection_drop", |persister, config| {
        assert!(
            collection_exists(config),
            "initialized collection should exist"
        );

        drop_collection(config);
        assert!(
            !collection_exists(config),
            "external drop should remove the collection before runtime calls"
        );

        assert_not_initialized(
            persister
                .load(Some("partition"), Some("app_id"), None)
                .expect_err("load should fail after external collection drop"),
        );
        assert_not_initialized(
            persister
                .list_app_ids(Some("partition"))
                .expect_err("list_app_ids should fail after external collection drop"),
        );
        assert_not_initialized(
            persister
                .save(
                    Some("partition"),
                    "app_id",
                    1,
                    "position_1",
                    map_from_pairs([("value", json!("recreate"))]),
                    PersistedStateStatus::Completed,
                )
                .expect_err("save should fail after external collection drop"),
        );
        assert!(
            !collection_exists(config),
            "failed operations must not recreate a dropped collection"
        );
    });
}

#[test]
fn external_unique_index_drop_only_blocks_save() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("unique_index_drop", |persister, config| {
        seed_partition_records(&persister);

        assert!(
            collection_index_names(config)
                .iter()
                .any(|name| name == UNIQUE_RECORD_INDEX_NAME),
            "initialize should create the required unique index"
        );

        drop_required_index(config, UNIQUE_RECORD_INDEX_NAME);
        assert!(
            !collection_index_names(config)
                .iter()
                .any(|name| name == UNIQUE_RECORD_INDEX_NAME),
            "external drop should remove the required index before runtime calls"
        );

        let latest_app = persister
            .load(Some("partition"), Some("app_a"), None)
            .expect("latest-app load should still succeed with its own index")
            .expect("latest-app state should still exist");
        assert_eq!(latest_app.sequence_id, 3);

        let app_ids = persister
            .list_app_ids(Some("partition"))
            .expect("list_app_ids should still succeed with its own index");
        assert_eq!(app_ids, vec!["app_a".to_string(), "app_b".to_string()]);

        assert_not_initialized(
            persister
                .save(
                    Some("partition"),
                    "app_c",
                    4,
                    "position_4",
                    map_from_pairs([("value", json!("recreate"))]),
                    PersistedStateStatus::Completed,
                )
                .expect_err("save should fail after unique index drop"),
        );
        assert!(
            !persister
                .is_initialized()
                .expect("is_initialized should reflect missing required indexes"),
            "persister should report not initialized after a required index is removed"
        );
    });
}

#[test]
fn external_latest_partition_index_drop_only_blocks_latest_partition_load() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("latest_partition_index_drop", |persister, config| {
        seed_partition_records(&persister);

        drop_required_index(config, LATEST_PARTITION_INDEX_NAME);

        assert_not_initialized(
            persister
                .load(Some("partition"), None, None)
                .expect_err("latest-partition load should fail after its index is dropped"),
        );

        let latest_app = persister
            .load(Some("partition"), Some("app_a"), None)
            .expect("latest-app load should still succeed")
            .expect("latest-app state should still exist");
        assert_eq!(latest_app.sequence_id, 3);

        persister
            .save(
                Some("partition"),
                "app_c",
                4,
                "position_4",
                map_from_pairs([("value", json!("v4"))]),
                PersistedStateStatus::Completed,
            )
            .expect("save should still succeed with the unique index intact");
        assert!(!persister
            .is_initialized()
            .expect("is_initialized should reflect missing required indexes"));
    });
}

#[test]
fn external_latest_app_index_drop_only_blocks_app_targeted_loads() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("latest_app_index_drop", |persister, config| {
        seed_partition_records(&persister);

        drop_required_index(config, LATEST_APP_INDEX_NAME);

        assert_not_initialized(
            persister
                .load(Some("partition"), Some("app_a"), None)
                .expect_err("latest-app load should fail after its index is dropped"),
        );
        assert_not_initialized(
            persister
                .load(Some("partition"), Some("app_a"), Some(1))
                .expect_err("exact-sequence load should fail after the app index is dropped"),
        );

        let latest_partition = persister
            .load(Some("partition"), None, None)
            .expect("latest-partition load should still succeed")
            .expect("latest-partition state should still exist");
        assert_eq!(latest_partition.app_id, "app_a");
        assert_eq!(latest_partition.sequence_id, 3);
        assert!(!persister
            .is_initialized()
            .expect("is_initialized should reflect missing required indexes"));
    });
}

#[test]
fn external_list_app_ids_index_drop_only_blocks_list_app_ids() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("list_app_ids_index_drop", |persister, config| {
        seed_partition_records(&persister);

        drop_required_index(config, LIST_APP_IDS_INDEX_NAME);

        assert_not_initialized(
            persister
                .list_app_ids(Some("partition"))
                .expect_err("list_app_ids should fail after its index is dropped"),
        );

        let latest_app = persister
            .load(Some("partition"), Some("app_a"), None)
            .expect("latest-app load should still succeed")
            .expect("latest-app state should still exist");
        assert_eq!(latest_app.sequence_id, 3);
        persister
            .save(
                Some("partition"),
                "app_c",
                4,
                "position_4",
                map_from_pairs([("value", json!("v4"))]),
                PersistedStateStatus::Completed,
            )
            .expect("save should still succeed with the unique index intact");
        assert!(!persister
            .is_initialized()
            .expect("is_initialized should reflect missing required indexes"));
    });
}

#[test]
fn save_rejects_duplicate_partition_app_sequence_without_overwrite() {
    rurr_testkit::require_check_live_tests!();

    let lane = LiveMongoLane::new("duplicate");
    run_sync_case(persistence_cases::duplicate_identity_behavior(
        &lane,
        "record_already_exists",
    ))
    .expect("duplicate assertions should succeed");
}

mongo_live_case_tests!(
    (
        load_without_app_id_orders_by_sub_millisecond_created_at_not_sequence_id,
        "sub_ms_latest_partition",
        persistence_cases::latest_partition_prefers_newest_created_at,
        "latest-partition ordering assertions should succeed"
    ),
    (
        list_app_ids_orders_by_sub_millisecond_created_at_before_app_id,
        "sub_ms_list_app_ids",
        persistence_cases::list_app_ids_order,
        "app-id ordering assertions should succeed"
    ),
    (
        same_instance_reprobes_after_external_initialize_and_recreate,
        "same_instance_reprobe",
        persistence_cases::same_instance_reprobes_after_external_initialize_and_recreate,
        "reprobe assertions should succeed"
    ),
    (
        save_load_latest_exact_and_list_app_ids_roundtrip,
        "roundtrip",
        persistence_cases::latest_partition_latest_app_exact_and_list,
        "roundtrip assertions should succeed"
    ),
    (
        config_roundtrip_rebuilds_persister_and_loads_saved_state,
        "config_roundtrip",
        persistence_cases::config_roundtrip_rebuilds_persister_and_loads_saved_state,
        "config roundtrip assertions should succeed"
    ),
    (
        load_nonexistent_key_returns_none,
        "nonexistent",
        persistence_cases::missing_load_returns_none,
        "missing-load assertions should succeed"
    ),
    (
        optional_partition_key_roundtrips_as_empty_string,
        "partition_optional",
        persistence_cases::none_partition_key_roundtrip,
        "none-partition assertions should succeed"
    ),
    (
        resume_path_loads_state_and_resumes_next_action,
        "resume",
        |lane| persistence_cases::persistence_spec_resume_path_smoke(
            lane,
            |lane, app_id, partition_key, load_target| {
                Box::pin(async move { build_counter_app(lane, app_id, partition_key, load_target) })
            },
            |_, app| Box::pin(async move { step_counter_app(app) }),
        ),
        "resume assertions should succeed"
    ),
    (
        fork_from_exact_sequence_preserves_target_ids_and_parent_pointer,
        "fork",
        |lane| persistence_cases::persistence_spec_fork_smoke(
            lane,
            |lane, app_id, partition_key, load_target| {
                Box::pin(async move { build_counter_app(lane, app_id, partition_key, load_target) })
            },
            |_, app| Box::pin(async move { step_counter_app(app) }),
        ),
        "fork assertions should succeed"
    )
);

#[test]
fn methods_before_initialize_return_not_initialized() {
    rurr_testkit::require_check_live_tests!();

    let lane = LiveMongoLane::new("cold");
    run_sync_case(persistence_cases::not_initialized_for_load_save_and_list(
        &lane,
    ));
}
