use super::keys::ActionRootKey;
use super::{rurr_owned_span_start_active, OtelTrackingError};
use crate::opentelemetry::trace::{SpanContext as OtelSpanContext, SpanId, TraceContextExt};
use crate::opentelemetry::{Array as OtelArray, Context, Value as OtelValue};
use crate::opentelemetry_sdk::error::OTelSdkResult;
use crate::opentelemetry_sdk::trace::{Span as SdkSpan, SpanData, SpanProcessor};
use indexmap::IndexMap;
use rurr_core::lifecycle::SpanContext;
use rurr_core::{application::Tracker, visibility::ActionSpan};
use serde_json::Value;
use std::collections::HashMap;
use std::fmt;
use std::sync::{Arc, Mutex, MutexGuard};

fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
    mutex
        .lock()
        .unwrap_or_else(|poisoned| poisoned.into_inner())
}

#[derive(Clone)]
struct TrackedSpanContext {
    action_span: ActionSpan,
    app_id: String,
    partition_key: Option<String>,
    mirrored: bool,
}

impl TrackedSpanContext {
    fn lifecycle_context(&self) -> SpanContext {
        let mut context = SpanContext::new(
            self.action_span.action(),
            self.action_span.action_sequence_id(),
            self.action_span.uid(),
        )
        .with_app_id(self.app_id.clone())
        .with_span_name(self.action_span.span_name().to_string())
        .with_span_dependencies(self.action_span.span_dependencies().to_vec());

        if let Some(parent) = self.action_span.parent() {
            context = context.with_parent_span_id(parent.uid());
        }
        if let Some(partition_key) = &self.partition_key {
            context = context.with_partition_key(partition_key.clone());
        }

        context
    }
}

/// Shared registry that connects live OTEL span ids to Rurr tracking spans.
///
/// The registry is intentionally separate from exporter/provider setup. It
/// keeps only short-lived span identity maps and records hook failures for
/// callers to inspect through [`take_errors`](Self::take_errors).
pub struct OtelTrackingRegistry {
    tracker: Arc<dyn Tracker>,
    action_roots: Mutex<HashMap<ActionRootKey, TrackedSpanContext>>,
    spans: Mutex<HashMap<SpanId, TrackedSpanContext>>,
    errors: Mutex<Vec<OtelTrackingError>>,
}

impl OtelTrackingRegistry {
    /// Creates a registry that mirrors external child spans into `tracker`.
    ///
    /// The tracker must provide a sync lifecycle adapter when external child
    /// spans should be mirrored into tracking artifacts. Missing adapters are
    /// recorded as bridge errors instead of panicking inside the span processor.
    pub fn new(tracker: Arc<dyn Tracker>) -> Self {
        Self {
            tracker,
            action_roots: Mutex::new(HashMap::new()),
            spans: Mutex::new(HashMap::new()),
            errors: Mutex::new(Vec::new()),
        }
    }

    /// Returns and clears bridge errors observed since the previous call.
    pub fn take_errors(&self) -> Vec<OtelTrackingError> {
        lock(&self.errors).drain(..).collect()
    }

    pub(super) fn record_error(&self, error: OtelTrackingError) {
        lock(&self.errors).push(error);
    }

    fn record_hook_error(&self, phase: &'static str, span_id: String, message: impl ToString) {
        self.record_error(OtelTrackingError::TrackerHookFailed {
            phase,
            span_id,
            message: message.to_string(),
        });
    }

    pub(super) fn ensure_action_root(
        &self,
        key: ActionRootKey,
        action: String,
        span_name: String,
        sequence_id: u64,
        app_id: String,
        partition_key: Option<String>,
    ) -> ActionSpan {
        let mut roots = lock(&self.action_roots);
        if let Some(root) = roots.get(&key) {
            return root.action_span.clone();
        }

        let action_span = ActionSpan::create_initial(action, span_name, 0, sequence_id);
        roots.insert(
            key,
            TrackedSpanContext {
                action_span: action_span.clone(),
                app_id,
                partition_key,
                mirrored: false,
            },
        );
        action_span
    }

    pub(super) fn forget_action_root(&self, key: &ActionRootKey) {
        lock(&self.action_roots).remove(key);
    }

    pub(super) fn seed_span(
        &self,
        span_context: &OtelSpanContext,
        action_span: ActionSpan,
        app_id: String,
        partition_key: Option<String>,
    ) {
        lock(&self.spans).insert(
            span_context.span_id(),
            TrackedSpanContext {
                action_span,
                app_id,
                partition_key,
                mirrored: false,
            },
        );
    }

    pub(super) fn forget_span(&self, span_id: SpanId) {
        lock(&self.spans).remove(&span_id);
    }

    fn start_external_child(&self, parent_span_id: SpanId, child_span: &SpanData) {
        if parent_span_id == SpanId::INVALID {
            return;
        }

        let parent = lock(&self.spans).get(&parent_span_id).cloned();
        let Some(parent) = parent else {
            return;
        };

        let child = TrackedSpanContext {
            action_span: parent.action_span.spawn(child_span.name.to_string()),
            app_id: parent.app_id,
            partition_key: parent.partition_key,
            mirrored: true,
        };
        let context = child.lifecycle_context();
        let span_id = child_span.span_context.span_id();
        let span_uid = context.span_id().to_string();

        let Some(tracker) = self.tracker.clone().sync_lifecycle_adapter() else {
            self.record_hook_error(
                "pre_start_span",
                span_uid,
                "tracker does not provide a sync lifecycle adapter",
            );
            return;
        };
        if let Err(error) = tracker.pre_start_span(&context) {
            self.record_hook_error(error.phase(), span_uid, error.message());
            return;
        }

        lock(&self.spans).insert(span_id, child);
    }

    fn end_span(&self, span: SpanData) {
        let span_id = span.span_context.span_id();
        let tracked = lock(&self.spans).remove(&span_id);
        let Some(tracked) = tracked else {
            return;
        };
        if !tracked.mirrored {
            return;
        }

        let context = tracked.lifecycle_context();
        let span_uid = context.span_id().to_string();
        let Some(tracker) = self.tracker.clone().sync_lifecycle_adapter() else {
            self.record_hook_error(
                "post_end_span",
                span_uid,
                "tracker does not provide a sync lifecycle adapter",
            );
            return;
        };

        if !span.attributes.is_empty() {
            let mut attributes = IndexMap::new();
            for attribute in &span.attributes {
                let key = String::from(attribute.key.clone());
                let Some(value) = otel_attribute_to_json(&attribute.value) else {
                    self.record_error(OtelTrackingError::UnsupportedAttributeValue {
                        span_id: span_uid.clone(),
                        key,
                    });
                    continue;
                };
                attributes.insert(key, value);
            }
            if !attributes.is_empty() {
                if let Err(error) = tracker.log_attributes(&context, &attributes) {
                    self.record_hook_error(error.phase(), span_uid.clone(), error.message());
                }
            }
        }

        if let Err(error) = tracker.post_end_span(&context) {
            self.record_hook_error(error.phase(), span_uid, error.message());
        }
    }
}

/// Span processor that mirrors external OTEL child spans into Rurr tracking.
///
/// Install this processor on the same tracer provider that exports application
/// spans. Spans started by Rurr's own lifecycle adapter are ignored so the
/// bridge does not duplicate root lifecycle spans.
#[derive(Clone)]
pub struct RurrTrackingSpanProcessor {
    registry: Arc<OtelTrackingRegistry>,
}

impl RurrTrackingSpanProcessor {
    /// Creates a processor backed by `registry`.
    pub fn new(registry: Arc<OtelTrackingRegistry>) -> Self {
        Self { registry }
    }
}

impl fmt::Debug for RurrTrackingSpanProcessor {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("RurrTrackingSpanProcessor").finish()
    }
}

impl SpanProcessor for RurrTrackingSpanProcessor {
    fn on_start(&self, span: &mut SdkSpan, cx: &Context) {
        if rurr_owned_span_start_active() {
            return;
        }
        let Some(span_data) = span.exported_data() else {
            self.registry
                .record_error(OtelTrackingError::MissingSpanData);
            return;
        };
        let parent_span_id = cx.span().span_context().span_id();
        self.registry
            .start_external_child(parent_span_id, &span_data);
    }

    fn on_end(&self, span: SpanData) {
        self.registry.end_span(span);
    }

    fn force_flush(&self) -> OTelSdkResult {
        Ok(())
    }

    fn shutdown(&self) -> OTelSdkResult {
        Ok(())
    }
}

fn otel_attribute_to_json(value: &OtelValue) -> Option<Value> {
    match value {
        OtelValue::Bool(value) => Some(Value::Bool(*value)),
        OtelValue::I64(value) => Some(Value::from(*value)),
        OtelValue::F64(value) => Some(Value::from(*value)),
        OtelValue::String(value) => Some(Value::String(value.to_string())),
        OtelValue::Array(OtelArray::Bool(values)) => Some(Value::Array(
            values.iter().copied().map(Value::Bool).collect(),
        )),
        OtelValue::Array(OtelArray::I64(values)) => Some(Value::Array(
            values.iter().copied().map(Value::from).collect(),
        )),
        OtelValue::Array(OtelArray::F64(values)) => Some(Value::Array(
            values.iter().copied().map(Value::from).collect(),
        )),
        OtelValue::Array(OtelArray::String(values)) => Some(Value::Array(
            values
                .iter()
                .map(|value| Value::String(value.to_string()))
                .collect(),
        )),
        _ => None,
    }
}
