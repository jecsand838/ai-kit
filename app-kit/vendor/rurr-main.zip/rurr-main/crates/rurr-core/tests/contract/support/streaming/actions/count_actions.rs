use super::core::{
    count_action_metadata, increment_count_result, CountStreamPlan, StreamScript,
    StreamScriptSpecExt,
};
use rurr_core::action::{ActionError, ActionResult, FunctionAction};
use rurr_testkit::action_fixture::{scripted_action, ScriptedActionSpec};
use rurr_testkit::application_fixture::map_from_pairs;
use serde_json::json;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

pub(crate) fn non_streaming_count_action(calls: Arc<AtomicUsize>) -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(move |state, _ctx| {
            calls.fetch_add(1, Ordering::SeqCst);
            Ok(increment_count_result(state))
        }),
    )
}

pub(crate) fn update_tracing_non_streaming_action() -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|state, _ctx| Ok(increment_count_result(state))).with_update(
            |result, state, ctx| {
                let _ = rurr_core::visibility::trace(
                    &ctx.tracer,
                    "update_trace",
                    result.result(),
                    &rurr_core::visibility::TraceOptions::new(),
                    |_span| "update_trace_ran",
                );
                state
                    .update(result.result().clone())
                    .map_err(ActionError::from)
            },
        ),
    )
}

pub(crate) fn streaming_count_action(
    calls: Arc<AtomicUsize>,
    terminal_after: usize,
    panic_at: Option<usize>,
) -> FunctionAction {
    let plan = CountStreamPlan::Steps {
        terminal_after,
        panic_at,
    };
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|state, _ctx| Ok(increment_count_result(state)))
            .with_stream_script(StreamScript::count(Some(calls), plan)),
    )
}

pub(crate) fn failing_update_action(calls: Arc<AtomicUsize>) -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(move |state, _ctx| {
            calls.fetch_add(1, Ordering::SeqCst);
            Ok(increment_count_result(state))
        })
        .with_update(|_result, _state, _ctx| {
            Err(ActionError::Internal {
                message: "intentional update failure".to_string(),
            })
        }),
    )
}

pub(crate) fn error_first_item_streaming_action() -> FunctionAction {
    let plan = CountStreamPlan::FirstItemError {
        message: "intentional stream item failure",
    };
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|state, _ctx| {
            let result = map_from_pairs([(
                "count",
                state.get("count").cloned().unwrap_or_else(|| json!(0)),
            )]);
            Ok(ActionResult::new(result.clone(), result))
        })
        .with_stream_script(StreamScript::count(None, plan)),
    )
}

pub(crate) fn uncommitted_streaming_action(calls: Arc<AtomicUsize>) -> FunctionAction {
    let plan = CountStreamPlan::IntermediateOnly { emitted: 1 };
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|state, _ctx| Ok(increment_count_result(state)))
            .with_stream_script(StreamScript::count(Some(calls), plan)),
    )
}
