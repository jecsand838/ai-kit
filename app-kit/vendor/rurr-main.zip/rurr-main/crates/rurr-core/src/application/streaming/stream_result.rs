use super::step_core::{AsyncStepExecution, SyncStepExecution};
use super::{combine_optional_primary_with_hook, stream_invariant, SessionCore};
use crate::action::api::StreamItem;
use crate::application::session::{ActionExecution, ExecutionLane, ExecutionStart, SyncLane};
use crate::application::{Application, ApplicationError, ExecutionOptions};
use crate::common::drop_finalizer::run_drop_finalizer;
use crate::graph::GraphAction;
use crate::state::State;
use futures::Stream;
use std::pin::Pin;
use std::task::{Context, Poll};

mod pending;
use pending::{
    cancel_pending_and_restore_core, poll_next_item, take_and_abort_pending, AStreamPendingNext,
};

type AStreamNextResult = Result<Option<StreamItem>, ApplicationError>;

/// Synchronous streaming result handle returned by result-streaming APIs.
///
/// The handle streams the selected result action lazily. State is committed only
/// after the terminal item is consumed by [`get`](Self::get) or by draining the
/// iterator to completion.
/// When constructed through `stream_result_with_options`, halt controls are
/// resolved before any fast-forward action executes and before the target
/// stream starts.
///
/// Dropping the handle early aborts the in-flight step and restores the
/// pre-step application state through the sync lifecycle path.
pub struct StreamResult<'a> {
    state: SessionCore<'a>,
    target_execution: Option<ActionExecution>,
    active_step: Option<SyncStepExecution<'a>>,
}

impl<'a> StreamResult<'a> {
    fn new(
        app: &'a mut Application,
        start: ExecutionStart,
    ) -> Result<(GraphAction, Self), ApplicationError> {
        let (returned_action, state, target_execution) =
            SessionCore::open_result_session(app, start.start_sync(app))?;
        Ok((
            returned_action,
            Self {
                state,
                target_execution,
                active_step: None,
            },
        ))
    }

    /// Advances the result stream by one item.
    ///
    /// Intermediate items are returned without committing application state.
    pub fn next_item(&mut self) -> Result<Option<StreamItem>, ApplicationError> {
        if self.state.is_done() {
            return Ok(None);
        }
        self.state
            .advance_sync_result_stream(&mut self.target_execution, &mut self.active_step)
    }

    /// Fully drains the stream and returns the terminal state snapshot.
    ///
    /// This is the committing path for result streaming.
    pub fn get(&mut self) -> Result<(Option<StreamItem>, State), ApplicationError> {
        while self.next_item()?.is_some() {}
        self.state.result_terminal_sync()
    }
}

impl Iterator for StreamResult<'_> {
    type Item = Result<StreamItem, ApplicationError>;

    fn next(&mut self) -> Option<Self::Item> {
        match self.next_item() {
            Ok(Some(item)) => Some(Ok(item)),
            Ok(None) => None,
            Err(error) => Some(Err(error)),
        }
    }
}

impl Drop for StreamResult<'_> {
    fn drop(&mut self) {
        run_drop_finalizer(|| {
            if let Some(step) = self.active_step.take() {
                let (app_result, abort_hook_result) = step.abort_and_take_app_with_hook_result();
                let _ = self.state.settle_abort(app_result, abort_hook_result);
            }
            let _ = self.state.close_session_sync();
        });
    }
}

/// Asynchronous streaming result handle returned by async result-streaming APIs.
///
/// `AStreamResult` implements [`futures::Stream`] while preserving the same
/// rollback rules as the sync result stream. Use [`abort`](Self::abort) when a
/// caller stops early and needs async lifecycle hooks to observe the abort.
/// Drop performs only synchronous rollback bookkeeping and never blocks on a
/// runtime. Halt selectors supplied through async result-streaming options are
/// resolved before streaming starts and are owned by the session core.
#[must_use]
pub struct AStreamResult<'a> {
    core: Option<AStreamResultCore<'a>>,
    pending_next: Option<AStreamPendingNext<'a>>,
}

struct AStreamResultCore<'a> {
    state: SessionCore<'a>,
    target_execution: Option<ActionExecution>,
    active_step: Option<AsyncStepExecution<'a>>,
}

impl<'a> AStreamResultCore<'a> {
    async fn new(
        app: &'a mut Application,
        start: ExecutionStart,
    ) -> Result<(GraphAction, Self), ApplicationError> {
        let (returned_action, state, target_execution) =
            SessionCore::open_result_session_async(app, start.start_async(app).await).await?;
        Ok((
            returned_action,
            Self {
                state,
                target_execution,
                active_step: None,
            },
        ))
    }

    async fn next_item(&mut self) -> AStreamNextResult {
        if self.state.is_done() {
            return Ok(None);
        }
        self.state
            .advance_async_result_stream(&mut self.target_execution, &mut self.active_step)
            .await
    }

    async fn abort(&mut self) -> Result<(), ApplicationError> {
        let mut primary_error = None;
        if let Some(step) = self.active_step.take() {
            let (app_result, abort_hook_result) = step.abort_and_take_app_with_hook_result().await;
            if let Err(error) = self.state.settle_abort(app_result, abort_hook_result) {
                primary_error = Some(error);
            }
        }
        combine_optional_primary_with_hook(primary_error, self.state.close_session_async().await)
    }
}

impl Drop for AStreamResultCore<'_> {
    fn drop(&mut self) {
        if let Some(step) = self.active_step.take() {
            let _ = self
                .state
                .settle_abort_sync_only(step.abort_sync_only_and_take_app());
        }
        self.state.close_session_sync_only();
    }
}

impl<'a> AStreamResult<'a> {
    async fn construct(
        app: &'a mut Application,
        start: ExecutionStart,
    ) -> Result<(GraphAction, Self), ApplicationError> {
        let (preview_action, core) = AStreamResultCore::new(app, start).await?;
        Ok((
            preview_action,
            Self {
                core: Some(core),
                pending_next: None,
            },
        ))
    }

    /// Advances the async result stream by one item.
    ///
    /// The returned item is still uncommitted unless it is the terminal stream
    /// result later observed by [`get`](Self::get).
    pub async fn next_item(&mut self) -> AStreamNextResult {
        std::future::poll_fn(|cx| poll_next_item(&mut self.core, &mut self.pending_next, cx)).await
    }

    /// Fully drains the async stream and returns the terminal state snapshot.
    ///
    /// Await this method when async lifecycle adapters must see normal stream
    /// completion.
    pub async fn get(&mut self) -> Result<(Option<StreamItem>, State), ApplicationError> {
        while self.next_item().await?.is_some() {}
        let core = self.core.as_ref().ok_or_else(|| {
            stream_invariant("astream_result core missing while getting terminal")
        })?;
        core.state.result_terminal_async()
    }

    /// Aborts the async stream and rolls the session back if needed.
    ///
    /// Await this method when async lifecycle adapters must observe early
    /// termination. Plain drop keeps the state safe but cannot await async hooks.
    pub async fn abort(&mut self) -> Result<(), ApplicationError> {
        cancel_pending_and_restore_core(&mut self.core, &mut self.pending_next).await;
        if let Some(core) = self.core.as_mut() {
            core.abort().await?;
        }
        Ok(())
    }
}

impl Stream for AStreamResult<'_> {
    type Item = Result<StreamItem, ApplicationError>;

    fn poll_next(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        let this = self.get_mut();
        match poll_next_item(&mut this.core, &mut this.pending_next, cx) {
            Poll::Ready(Ok(Some(item))) => Poll::Ready(Some(Ok(item))),
            Poll::Ready(Ok(None)) => Poll::Ready(None),
            Poll::Ready(Err(error)) => Poll::Ready(Some(Err(error))),
            Poll::Pending => Poll::Pending,
        }
    }
}

impl Drop for AStreamResult<'_> {
    fn drop(&mut self) {
        let _ = take_and_abort_pending(&mut self.pending_next);
        let _ = self.core.take();
    }
}

pub(crate) fn stream_result<'a>(
    app: &'a mut Application,
    options: ExecutionOptions,
) -> Result<(GraphAction, StreamResult<'a>), ApplicationError> {
    StreamResult::new(
        app,
        ExecutionStart::new(app, ExecutionLane::Sync(SyncLane::Stream), options),
    )
}

pub(crate) async fn astream_result<'a>(
    app: &'a mut Application,
    options: ExecutionOptions,
) -> Result<(GraphAction, AStreamResult<'a>), ApplicationError> {
    AStreamResult::construct(app, ExecutionStart::new(app, ExecutionLane::Async, options)).await
}
