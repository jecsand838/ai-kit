use super::Tracker;
use crate::lifecycle::LifecycleAdapterSet;
use crate::parallelism::ParallelExecutor;
use rurr_persistence::{StateLoaderRef, StatePersisterRef};
use std::sync::Arc;

#[derive(Clone)]
pub(crate) struct RuntimeResources {
    hooks: LifecycleAdapterSet,
    tracker: Option<Arc<dyn Tracker>>,
    register_root_application: bool,
    parallel_executor: Option<Arc<dyn ParallelExecutor>>,
    state_persister: Option<StatePersisterRef>,
    state_initializer: Option<StateLoaderRef>,
}

impl RuntimeResources {
    pub(crate) fn new(hooks: LifecycleAdapterSet) -> Self {
        Self {
            hooks,
            tracker: None,
            register_root_application: false,
            parallel_executor: None,
            state_persister: None,
            state_initializer: None,
        }
    }

    pub(crate) fn hooks(&self) -> &LifecycleAdapterSet {
        &self.hooks
    }

    pub(crate) fn tracker(&self) -> Option<&Arc<dyn Tracker>> {
        self.tracker.as_ref()
    }

    pub(crate) fn should_register_root_application(&self) -> bool {
        self.register_root_application
    }

    pub(crate) fn parallel_executor(&self) -> Option<&Arc<dyn ParallelExecutor>> {
        self.parallel_executor.as_ref()
    }

    pub(crate) fn state_persister(&self) -> Option<&StatePersisterRef> {
        self.state_persister.as_ref()
    }

    pub(crate) fn state_initializer(&self) -> Option<&StateLoaderRef> {
        self.state_initializer.as_ref()
    }

    pub(crate) fn with_optional_tracker(
        mut self,
        tracker: Option<Arc<dyn Tracker>>,
        register_root_application: bool,
    ) -> Self {
        self.tracker = tracker;
        self.register_root_application = register_root_application;
        self
    }

    pub(crate) fn with_optional_parallel_executor(
        mut self,
        parallel_executor: Option<Arc<dyn ParallelExecutor>>,
    ) -> Self {
        self.parallel_executor = parallel_executor;
        self
    }

    pub(crate) fn with_optional_state_persister(
        mut self,
        state_persister: Option<StatePersisterRef>,
    ) -> Self {
        self.state_persister = state_persister;
        self
    }

    #[cfg(test)]
    pub(crate) fn with_state_initializer(mut self, state_initializer: StateLoaderRef) -> Self {
        self.state_initializer = Some(state_initializer);
        self
    }

    pub(crate) fn with_optional_state_initializer(
        mut self,
        state_initializer: Option<StateLoaderRef>,
    ) -> Self {
        self.state_initializer = state_initializer;
        self
    }
}
