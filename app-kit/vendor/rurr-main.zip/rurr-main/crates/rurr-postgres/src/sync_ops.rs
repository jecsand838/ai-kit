use super::{
    shared::{
        connect_sync_client, connection_closed_error, is_connection_closed,
        row_tuple_from_postgres, validate_sync_database_url, SyncClientState,
    },
    PersistedStateData, PersistedStateStatus, PersistenceError, PostgresPersister,
    PostgresPersisterConfig, OP_CONNECTION_LOCK_POISONED, OP_POSTGRES_MIGRATION_FAILED,
    OP_POSTGRES_QUERY_FAILED, OP_STATE_SERIALIZATION_FAILED,
};
use indexmap::IndexMap;
use postgres::{types::ToSql, Client};
use rurr_persistence::{
    BaseStateLoader, BaseStateSaver, PersistedStateSaveRequest, PostgresDialect, SqlDialect,
    SqlInitializationPlan, SqlListAppIdsPlan, SqlSavePlan, SyncSqlBackend, SyncSqlPersistenceCore,
};
use serde_json::Value;
use std::sync::{Mutex, MutexGuard};

struct PostgresSyncBackend<'a> {
    persister: &'a PostgresPersister,
}

impl<'a> PostgresSyncBackend<'a> {
    fn query_optional_persisted_row(
        &self,
        query: &str,
        params: &[&(dyn ToSql + Sync)],
    ) -> Result<Option<rurr_persistence::PersistedRowTuple>, PersistenceError> {
        self.persister.with_client(|client| {
            client
                .query_opt(query, params)
                .map(|row| row.map(row_tuple_from_postgres))
                .map_err(|error| self.query_failed(error))
        })
    }

    fn query_app_id_list(
        &self,
        query: &str,
        params: &[&(dyn ToSql + Sync)],
    ) -> Result<Vec<String>, PersistenceError> {
        self.persister.with_client(|client| {
            client
                .query(query, params)
                .map(|rows| {
                    rows.into_iter()
                        .map(|row| row.get::<_, String>(0))
                        .collect()
                })
                .map_err(|error| self.query_failed(error))
        })
    }

    fn query_failed(&self, error: postgres::Error) -> PersistenceError {
        self.persister
            .map_query_error(error, OP_POSTGRES_QUERY_FAILED)
    }
}

impl<'a> SyncSqlBackend for PostgresSyncBackend<'a> {
    fn ensure_open(&self) -> Result<(), PersistenceError> {
        self.persister.ensure_open()
    }

    fn run_migration(&self, plan: &SqlInitializationPlan<'_>) -> Result<(), PersistenceError> {
        self.persister.with_client(|client| {
            client.batch_execute(plan.migration_sql).map_err(|error| {
                self.persister
                    .map_query_error(error, OP_POSTGRES_MIGRATION_FAILED)
            })
        })
    }

    fn table_exists(&self, plan: &SqlInitializationPlan<'_>) -> Result<bool, PersistenceError> {
        self.persister.with_client(|client| {
            let row = client
                .query_one(
                    PostgresDialect::table_exists_sql(),
                    &[&plan.table_name as &(dyn ToSql + Sync)],
                )
                .map_err(|error| {
                    self.persister
                        .map_query_error(error, OP_POSTGRES_QUERY_FAILED)
                })?;
            Ok(row.get::<_, bool>(0))
        })
    }

    fn save(&self, plan: &SqlSavePlan<'_, '_>) -> Result<(), PersistenceError> {
        self.persister.with_client(|client| {
            client
                .execute(
                    plan.query,
                    &[
                        &plan.partition_key as &(dyn ToSql + Sync),
                        &plan.app_id,
                        &plan.sequence_id,
                        &plan.position,
                        &plan.state_value,
                        &plan.status,
                    ],
                )
                .map_err(|error| {
                    self.persister
                        .map_query_error(error, OP_POSTGRES_QUERY_FAILED)
                })?;
            Ok(())
        })
    }

    fn load_latest_partition(
        &self,
        query: &str,
        partition_key: &str,
    ) -> Result<Option<rurr_persistence::PersistedRowTuple>, PersistenceError> {
        self.query_optional_persisted_row(query, &[&partition_key as &(dyn ToSql + Sync)])
    }

    fn load_latest_app(
        &self,
        query: &str,
        partition_key: &str,
        app_id: &str,
    ) -> Result<Option<rurr_persistence::PersistedRowTuple>, PersistenceError> {
        self.query_optional_persisted_row(query, &[&partition_key as &(dyn ToSql + Sync), &app_id])
    }

    fn load_exact_sequence(
        &self,
        query: &str,
        partition_key: &str,
        app_id: &str,
        sequence_id: i64,
    ) -> Result<Option<rurr_persistence::PersistedRowTuple>, PersistenceError> {
        self.query_optional_persisted_row(
            query,
            &[&partition_key as &(dyn ToSql + Sync), &app_id, &sequence_id],
        )
    }

    fn list_app_ids(&self, plan: &SqlListAppIdsPlan<'_>) -> Result<Vec<String>, PersistenceError> {
        self.query_app_id_list(plan.query, &[&plan.partition_key as &(dyn ToSql + Sync)])
    }
}

impl PostgresPersister {
    /// Creates a synchronous PostgreSQL persister from a serialized config
    /// value.
    pub fn new(config: PostgresPersisterConfig) -> Result<Self, PersistenceError> {
        validate_sync_database_url(&config.database_url)?;

        Ok(Self {
            client_state: Mutex::new(SyncClientState::Unopened),
            shared: super::shared::PostgresShared::new(config.database_url, config.table_name)?,
        })
    }

    /// Returns the configuration originally used to construct this persister.
    pub fn config(&self) -> PostgresPersisterConfig {
        self.shared.config()
    }

    /// Closes the current client, if any, and clears the initialization hint.
    pub fn cleanup(&self) -> Result<(), PersistenceError> {
        self.shutdown()
    }

    fn sync_core(&self) -> SyncSqlPersistenceCore<'_, PostgresSyncBackend<'_>> {
        SyncSqlPersistenceCore::new(
            PostgresSyncBackend { persister: self },
            self.shared.query_plan(),
            self.shared.table_name(),
            self.shared.migration_sql(),
            self.shared.initialization_hint(),
        )
    }

    fn shutdown(&self) -> Result<(), PersistenceError> {
        *self.lock_client_state()? = SyncClientState::Closed;
        self.shared.initialization_hint().clear();
        Ok(())
    }

    fn ensure_open(&self) -> Result<(), PersistenceError> {
        if matches!(*self.lock_client_state()?, SyncClientState::Closed) {
            Err(connection_closed_error())
        } else {
            Ok(())
        }
    }

    fn lock_client_state(&self) -> Result<MutexGuard<'_, SyncClientState>, PersistenceError> {
        self.client_state
            .lock()
            .map_err(|_| PersistenceError::UnsupportedOperation {
                operation: OP_CONNECTION_LOCK_POISONED,
            })
    }

    fn with_client<T>(
        &self,
        operation: impl FnOnce(&mut Client) -> Result<T, PersistenceError>,
    ) -> Result<T, PersistenceError> {
        let mut client_state = self.lock_client_state()?;
        if matches!(&*client_state, SyncClientState::Closed) {
            return Err(connection_closed_error());
        }

        let should_close_existing = matches!(
            &*client_state,
            SyncClientState::Open(client) if client.is_closed()
        );
        if should_close_existing {
            *client_state = SyncClientState::Closed;
            self.shared.initialization_hint().clear();
            return Err(connection_closed_error());
        }

        if matches!(&*client_state, SyncClientState::Unopened) {
            *client_state =
                SyncClientState::Open(Box::new(connect_sync_client(self.shared.database_url())?));
        }

        let SyncClientState::Open(client) = &mut *client_state else {
            unreachable!("client state should be open after connecting");
        };

        let (result, should_close) = {
            let result = operation(client);
            let should_close =
                client.is_closed() || result.as_ref().err().is_some_and(is_connection_closed);
            (result, should_close)
        };

        if should_close {
            *client_state = SyncClientState::Closed;
            self.shared.initialization_hint().clear();
        }

        result
    }

    fn map_query_error(&self, error: postgres::Error, operation: &'static str) -> PersistenceError {
        self.shared
            .initialization_hint()
            .track_error(super::error_map::map_postgres_error(error, operation))
    }
}

impl BaseStateSaver for PostgresPersister {
    fn initialize(&self) -> Result<(), PersistenceError> {
        self.sync_core().initialize()
    }

    fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.sync_core().is_initialized()
    }

    fn cleanup(&self) -> Result<(), PersistenceError> {
        self.shutdown()
    }

    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.sync_core().save(
            PersistedStateSaveRequest::new(
                partition_key,
                app_id,
                sequence_id,
                position,
                state,
                status,
            ),
            OP_STATE_SERIALIZATION_FAILED,
        )
    }
}

impl BaseStateLoader for PostgresPersister {
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.sync_core().load(partition_key, app_id, sequence_id)
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        self.sync_core().list_app_ids(partition_key)
    }
}
