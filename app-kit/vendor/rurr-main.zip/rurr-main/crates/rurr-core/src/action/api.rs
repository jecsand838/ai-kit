use crate::application::context::ApplicationContext;
use crate::application::RuntimeResources;
use crate::lifecycle::VisibilityRootContext;
use crate::state::{State, StateError};
use crate::visibility::{TraceSession, TraceSpanHandle, VisibilityError};
use futures::future::LocalBoxFuture;
use futures::{stream, Stream};
use indexmap::IndexMap;
use serde_json::Value;
use std::fmt;
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use thiserror::Error;

/// Runtime inputs passed into an action invocation.
///
/// User-supplied keys must not use Rurr's reserved `__*` namespace. Runtime
/// metadata is carried through [`ActionContext`] instead of being injected into
/// this map.
pub type ActionInputs = IndexMap<String, Value>;
/// One streamed delta emitted by a streaming action.
///
/// Intermediate stream items are observable deltas only; application state is
/// committed by the terminal stream output that carries a [`State`].
pub type StreamItem = IndexMap<String, Value>;
/// One item produced by a streaming action plus its optional terminal state.
///
/// `None` marks an intermediate item. `Some(State)` marks the terminal item
/// whose state snapshot is committed atomically by the application runtime.
pub type StreamOutput = Result<(StreamItem, Option<State>), RurrError>;
/// Owning boxed local stream returned by async streaming actions.
///
/// Local streams may hold non-`Send` values across `.await` points. The graph
/// still stores the action object behind a `Send + Sync` boundary; only the
/// returned future/stream is local to the current task.
pub type LocalAsyncStreamOutput = Pin<Box<dyn Stream<Item = StreamOutput>>>;
/// Owning boxed Send stream for action implementations that need Send streams.
///
/// This alias is available for action helpers that want an explicitly sendable
/// stream return type. Core runtime dispatch accepts local async streams by
/// default and does not require thread-pool escapes to execute them.
pub type SendAsyncStreamOutput = Pin<Box<dyn Stream<Item = StreamOutput> + Send>>;

/// Boxes a concrete async stream into the local async streaming return type.
///
/// # Examples
///
/// ```rust
/// use futures::StreamExt;
/// use rurr_core::action::{boxed_local_async_stream, StreamOutput};
///
/// # #[tokio::main(flavor = "current_thread")]
/// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
/// let mut stream = boxed_local_async_stream(futures::stream::iter(vec![
///     Ok::<_, rurr_core::RurrError>((indexmap::IndexMap::new(), None)),
/// ]));
/// let item: StreamOutput = stream
///     .next()
///     .await
///     .ok_or_else(|| std::io::Error::other("stream should yield one item"))?;
/// assert!(item.is_ok());
/// # Ok(())
/// # }
/// ```
pub fn boxed_local_async_stream<S>(stream: S) -> LocalAsyncStreamOutput
where
    S: Stream<Item = StreamOutput> + 'static,
{
    Box::pin(stream)
}

/// Boxes a concrete Send async stream into the Send async streaming return type.
///
/// Use this helper when an action implementation naturally produces a `Send`
/// stream and wants to advertise that stronger bound. Application dispatch does
/// not require it; [`boxed_local_async_stream`] is the default async streaming
/// shape.
pub fn boxed_send_async_stream<S>(stream: S) -> SendAsyncStreamOutput
where
    S: Stream<Item = StreamOutput> + Send + 'static,
{
    Box::pin(stream)
}

/// Declares whether an action runs on the sync or async lane.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ActionKind {
    /// The action implements [`Action::run`].
    Sync,
    /// The action implements [`Action::run_async`].
    Async,
}

/// Visibility/tracing helper passed through [`ActionContext`].
#[derive(Clone, Default)]
pub struct ActionTracer {
    session: Option<Arc<TraceSession>>,
}

/// Per-invocation context passed to an [`Action`].
#[derive(Clone, Default)]
pub struct ActionContext {
    /// Runtime input payload supplied for this action invocation.
    pub inputs: ActionInputs,
    /// Tracing helper used to emit visibility spans.
    pub tracer: ActionTracer,
    /// Application identifiers and parent pointers for the current run.
    pub app_context: Option<ApplicationContext>,
    engine_resources: Option<RuntimeResources>,
}

impl ActionContext {
    /// Creates an explicit action context from runtime inputs, tracing state,
    /// and optional application metadata.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use indexmap::IndexMap;
    /// use rurr_core::action::{ActionContext, ActionTracer};
    /// use serde_json::json;
    ///
    /// let context = ActionContext::new(
    ///     IndexMap::from([("question".to_string(), json!("hello"))]),
    ///     ActionTracer::default(),
    ///     None,
    /// );
    /// assert_eq!(context.inputs.get("question"), Some(&json!("hello")));
    /// ```
    pub fn new(
        inputs: ActionInputs,
        tracer: ActionTracer,
        app_context: Option<ApplicationContext>,
    ) -> Self {
        Self {
            inputs,
            tracer,
            app_context,
            engine_resources: None,
        }
    }

    pub(crate) fn with_engine_resources(mut self, engine_resources: RuntimeResources) -> Self {
        self.engine_resources = Some(engine_resources);
        self
    }

    pub(crate) fn clone_with_inputs(&self, inputs: ActionInputs) -> Self {
        Self {
            inputs,
            tracer: self.tracer.clone(),
            app_context: self.app_context.clone(),
            engine_resources: self.engine_resources.clone(),
        }
    }

    pub(crate) fn engine_resources(&self) -> Option<&RuntimeResources> {
        self.engine_resources.as_ref()
    }
}

impl fmt::Debug for ActionContext {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ActionContext")
            .field("inputs", &self.inputs)
            .field("tracer", &self.tracer)
            .field("app_context", &self.app_context)
            .finish()
    }
}

impl PartialEq for ActionContext {
    fn eq(&self, other: &Self) -> bool {
        self.inputs == other.inputs
            && self.tracer == other.tracer
            && self.app_context == other.app_context
    }
}

impl fmt::Debug for ActionTracer {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("ActionTracer")
            .field("active", &self.session.is_some())
            .finish()
    }
}

impl PartialEq for ActionTracer {
    fn eq(&self, other: &Self) -> bool {
        match (&self.session, &other.session) {
            (None, None) => true,
            (Some(left), Some(right)) => Arc::ptr_eq(left, right),
            _ => false,
        }
    }
}

impl Eq for ActionTracer {}

impl ActionTracer {
    /// Creates an active tracer for one action execution.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use rurr_core::action::ActionTracer;
    /// use rurr_core::lifecycle::LifecycleAdapterSet;
    ///
    /// let tracer = ActionTracer::new(
    ///     "answer",
    ///     7,
    ///     LifecycleAdapterSet::default(),
    ///     "docs-app",
    ///     Some("tenant-a".to_string()),
    /// );
    /// assert_ne!(tracer, ActionTracer::default());
    /// ```
    pub fn new(
        action: impl Into<String>,
        sequence_id: u64,
        hooks: crate::lifecycle::LifecycleAdapterSet,
        app_id: impl Into<String>,
        partition_key: Option<String>,
    ) -> Self {
        Self::active(action, sequence_id, app_id, partition_key, hooks)
    }

    pub(crate) fn active(
        action: impl Into<String>,
        sequence_id: u64,
        app_id: impl Into<String>,
        partition_key: Option<String>,
        hooks: crate::lifecycle::LifecycleAdapterSet,
    ) -> Self {
        let action = action.into();
        let app_id = app_id.into();
        let mut root_context =
            VisibilityRootContext::new(app_id.clone(), action.clone(), sequence_id);
        if let Some(partition_key) = &partition_key {
            root_context = root_context.with_partition_key(partition_key.clone());
        }
        let root_span_parent = hooks.visibility_root_span_parent(&root_context);
        Self {
            session: Some(Arc::new(TraceSession::new(
                action,
                sequence_id,
                app_id,
                partition_key,
                root_span_parent,
                hooks,
            ))),
        }
    }

    pub(crate) fn enter_root_span(
        &self,
        span_name: impl Into<String>,
    ) -> Result<TraceSpanHandle, VisibilityError> {
        match &self.session {
            Some(session) => session.start_root_handle_sync(span_name),
            None => Ok(TraceSpanHandle::default()),
        }
    }

    pub(crate) async fn enter_root_span_async(
        &self,
        span_name: impl Into<String>,
    ) -> Result<TraceSpanHandle, VisibilityError> {
        match &self.session {
            Some(session) => session.start_root_handle_async(span_name).await,
            None => Ok(TraceSpanHandle::default()),
        }
    }

    pub(crate) fn is_active(&self) -> bool {
        self.session.is_some()
    }
}

/// Returns whether `key` is reserved for runtime-owned inputs.
///
/// Runtime-reserved inputs start with `__`.
///
/// # Examples
///
/// ```rust
/// assert!(rurr_core::action::is_reserved_runtime_input("__SEQUENCE_ID"));
/// assert!(!rurr_core::action::is_reserved_runtime_input("question"));
/// ```
pub fn is_reserved_runtime_input(key: &str) -> bool {
    key.starts_with("__")
}

/// Result payload returned by one action execution.
#[derive(Debug, Clone, PartialEq)]
pub struct ActionResult {
    result: IndexMap<String, Value>,
    writes: IndexMap<String, Value>,
}

impl ActionResult {
    /// Creates an action result from explicit result and state-write maps.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use indexmap::IndexMap;
    /// use rurr_core::action::ActionResult;
    /// use serde_json::json;
    ///
    /// let result = ActionResult::new(
    ///     IndexMap::from([("message".to_string(), json!("ok"))]),
    ///     IndexMap::from([("count".to_string(), json!(1))]),
    /// );
    /// assert_eq!(result.result().get("message"), Some(&json!("ok")));
    /// ```
    pub fn new(result: IndexMap<String, Value>, writes: IndexMap<String, Value>) -> Self {
        Self { result, writes }
    }

    /// Returns the result payload exposed to downstream steps or callers.
    pub fn result(&self) -> &IndexMap<String, Value> {
        &self.result
    }

    /// Returns the state updates produced by the action.
    pub fn writes(&self) -> &IndexMap<String, Value> {
        &self.writes
    }

    /// Splits the result into owned `(result, writes)` maps.
    pub fn into_parts(self) -> (IndexMap<String, Value>, IndexMap<String, Value>) {
        (self.result, self.writes)
    }
}

/// Error raised while configuring or executing an action.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum ActionError {
    /// Returned when a generated or helper action is renamed more than once.
    #[error("action name already set to '{current_name}', cannot rename to '{attempted_name}'")]
    NameAlreadySet {
        /// Previously assigned action name.
        current_name: String,
        /// Newly requested name that conflicted with the existing one.
        attempted_name: String,
    },
    /// Required runtime input was absent from the invocation payload.
    #[error("missing required input '{key}'")]
    MissingInput {
        /// Missing input key.
        key: String,
    },
    /// Runtime input could not be deserialized into the requested type.
    #[error("input '{key}' deserialization failed: {message}")]
    InputDeserializationFailed {
        /// Input key that failed deserialization.
        key: String,
        /// Human-readable serde failure message.
        message: String,
    },
    /// A defaulted input was also marked required.
    #[error("default input '{key}' must be declared optional and not required")]
    DefaultInputMustBeOptional {
        /// Input key with inconsistent required/default configuration.
        key: String,
    },
    /// A bound input attempted to override a runtime-supplied input.
    #[error("runtime input '{key}' cannot override bound input")]
    BoundInputOverride {
        /// Conflicting input key.
        key: String,
    },
    /// Reserved runtime input was bound or defaulted by user configuration.
    #[error("reserved runtime input '{key}' cannot be bound or defaulted")]
    ReservedRuntimeInputBinding {
        /// Reserved runtime input key.
        key: String,
    },
    /// Reserved runtime input was declared as a user-facing input.
    #[error("reserved runtime input '{key}' cannot be declared")]
    ReservedRuntimeInputDeclaration {
        /// Reserved runtime input key.
        key: String,
    },
    /// Async-only action was executed through the sync path.
    #[error("async action requires run_async")]
    AsyncActionRequiresRunAsync,
    /// An action requested runtime-only context that was unavailable.
    #[error("runtime context unavailable: {message}")]
    RuntimeContextUnavailable {
        /// Description of the missing runtime context.
        message: String,
    },
    /// Action operation is not supported for the current action kind.
    #[error("unsupported operation: {message}")]
    UnsupportedOperation {
        /// Description of the unsupported operation.
        message: String,
    },
    /// Internal invariant violation raised from an action helper.
    #[error("internal action error: {message}")]
    Internal {
        /// Human-readable invariant message.
        message: String,
    },
    /// State update or validation failure surfaced from [`State`].
    #[error(transparent)]
    State(#[from] StateError),
    /// Visibility or tracing failure raised while emitting spans.
    #[error("visibility error: {message}")]
    Visibility {
        /// Human-readable visibility error.
        message: String,
    },
    /// Panic captured and converted into a typed action error.
    #[error("captured panic in {scope}: {message}")]
    PanicCaptured {
        /// Logical scope that captured the panic.
        scope: &'static str,
        /// Panic payload rendered as a string.
        message: String,
    },
}

impl From<VisibilityError> for ActionError {
    fn from(value: VisibilityError) -> Self {
        Self::Visibility {
            message: value.to_string(),
        }
    }
}

/// Top-level runtime error used by streaming action helpers.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum RurrError {
    /// Action-level failure.
    #[error(transparent)]
    Action(#[from] ActionError),
    /// Opaque runtime message.
    #[error("{0}")]
    Message(String),
}

/// Core trait implemented by executable local actions.
///
/// This is the primary action trait for user implementations. It supports local
/// async futures and streams so an action can await non-`Send` work without
/// pretending to move across threads. The companion [`Action`] trait is the
/// generated `Send` variant for users who need that stricter contract, and
/// [`ErasedAction`] is the object-safe runtime layer stored by graphs.
#[trait_variant::make(Action: Send)]
pub trait LocalAction {
    /// Returns the configured action name when one has been assigned.
    fn name(&self) -> Option<&str>;

    /// Returns the state keys read by the action.
    fn reads(&self) -> &[String];

    /// Returns the state keys written by the action.
    fn writes(&self) -> &[String];

    /// Returns the required runtime input names for the action.
    fn inputs(&self) -> &[String] {
        &[]
    }

    /// Returns optional runtime input names for the action.
    fn optional_inputs(&self) -> &[String] {
        &[]
    }

    /// Returns free-form tags associated with the action.
    fn tags(&self) -> &[String] {
        &[]
    }

    /// Returns the source representation used in tracking/debugging output when one is available.
    fn source_code(&self) -> Option<String> {
        None
    }

    /// Returns whether the action is sync or async.
    fn kind(&self) -> ActionKind {
        ActionKind::Sync
    }

    /// Convenience helper that returns `true` for async actions.
    fn is_async(&self) -> bool {
        matches!(self.kind(), ActionKind::Async)
    }

    /// Returns a copy of the action with a stable name assigned.
    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError>
    where
        Self: Sized;

    /// Executes the action on the sync lane.
    fn run(&self, state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError>;

    /// Executes the action on the async lane.
    ///
    /// The default implementation forwards to [`LocalAction::run`].
    fn run_async(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> impl Future<Output = Result<ActionResult, ActionError>>
    where
        Self: Sync,
    {
        async move { self.run(state, ctx) }
    }

    /// Streaming contract: return an owning boxed iterator.
    ///
    /// The iterator owns its state and context rather than borrowing from the
    /// application. Yield `(item, None)` for intermediate deltas and one
    /// terminal `(item, Some(state))` when the action has a final committed
    /// state. The default implementation adapts a non-streaming action into a
    /// single terminal item.
    fn stream_run(
        &self,
        state: State,
        ctx: ActionContext,
    ) -> Box<dyn Iterator<Item = StreamOutput>> {
        let output = self
            .run(&state, &ctx)
            .map_err(RurrError::from)
            .and_then(|result| {
                self.update(&result, &state, &ctx)
                    .map_err(RurrError::from)
                    .map(|next_state| (result.result().clone(), Some(next_state)))
            });
        Box::new(std::iter::once(output))
    }

    /// Async streaming contract: return an owning local boxed stream.
    ///
    /// The returned stream is polled by the caller's task. It should use the
    /// same terminal-state convention as [`LocalAction::stream_run`] and should
    /// avoid spawning or buffering work just to satisfy a `Send` bound.
    fn stream_run_async(&self, state: State, ctx: ActionContext) -> LocalAsyncStreamOutput {
        boxed_local_async_stream(stream::iter(self.stream_run(state, ctx)))
    }

    /// Applies the action result to state and returns the next state snapshot.
    ///
    /// The default implementation writes `result.writes()` into the current
    /// state.
    fn update(
        &self,
        result: &ActionResult,
        state: &State,
        _ctx: &ActionContext,
    ) -> Result<State, ActionError> {
        state
            .update(result.writes().clone())
            .map_err(ActionError::from)
    }
}

/// Object-safe runtime action interface stored by graphs.
///
/// Most users should implement [`LocalAction`] or use
/// [`FunctionActionBuilder`](crate::action::FunctionActionBuilder).
/// This trait is the runtime erasure boundary: it lets graphs store heterogeneous
/// actions while preserving local async futures/streams and the same update
/// semantics as the source action.
pub trait ErasedAction: Send + Sync {
    /// Returns the configured action name when one has been assigned.
    fn name(&self) -> Option<&str>;

    /// Returns the state keys read by the action.
    fn reads(&self) -> &[String];

    /// Returns the state keys written by the action.
    fn writes(&self) -> &[String];

    /// Returns the required runtime input names for the action.
    fn inputs(&self) -> &[String];

    /// Returns optional runtime input names for the action.
    fn optional_inputs(&self) -> &[String];

    /// Returns free-form tags associated with the action.
    fn tags(&self) -> &[String];

    /// Returns the source representation used in tracking/debugging output when one is available.
    fn source_code(&self) -> Option<String>;

    /// Returns whether the action is sync or async.
    fn kind(&self) -> ActionKind;

    /// Executes the action on the sync lane.
    fn run_erased(&self, state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError>;

    /// Executes the action on the async lane.
    fn run_async_erased<'a>(
        &'a self,
        state: &'a State,
        ctx: &'a ActionContext,
    ) -> LocalBoxFuture<'a, Result<ActionResult, ActionError>>;

    /// Runs the action as a sync stream.
    fn stream_run_erased(
        &self,
        state: State,
        ctx: ActionContext,
    ) -> Box<dyn Iterator<Item = StreamOutput>>;

    /// Runs the action as a local async stream.
    fn stream_run_async_erased(&self, state: State, ctx: ActionContext) -> LocalAsyncStreamOutput;

    /// Applies the action result to state and returns the next state snapshot.
    fn update_erased(
        &self,
        result: &ActionResult,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<State, ActionError>;
}

impl<T> ErasedAction for T
where
    T: LocalAction + Send + Sync + 'static,
{
    fn name(&self) -> Option<&str> {
        LocalAction::name(self)
    }

    fn reads(&self) -> &[String] {
        LocalAction::reads(self)
    }

    fn writes(&self) -> &[String] {
        LocalAction::writes(self)
    }

    fn inputs(&self) -> &[String] {
        LocalAction::inputs(self)
    }

    fn optional_inputs(&self) -> &[String] {
        LocalAction::optional_inputs(self)
    }

    fn tags(&self) -> &[String] {
        LocalAction::tags(self)
    }

    fn source_code(&self) -> Option<String> {
        LocalAction::source_code(self)
    }

    fn kind(&self) -> ActionKind {
        LocalAction::kind(self)
    }

    fn run_erased(&self, state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        LocalAction::run(self, state, ctx)
    }

    fn run_async_erased<'a>(
        &'a self,
        state: &'a State,
        ctx: &'a ActionContext,
    ) -> LocalBoxFuture<'a, Result<ActionResult, ActionError>> {
        Box::pin(LocalAction::run_async(self, state, ctx))
    }

    fn stream_run_erased(
        &self,
        state: State,
        ctx: ActionContext,
    ) -> Box<dyn Iterator<Item = StreamOutput>> {
        LocalAction::stream_run(self, state, ctx)
    }

    fn stream_run_async_erased(&self, state: State, ctx: ActionContext) -> LocalAsyncStreamOutput {
        LocalAction::stream_run_async(self, state, ctx)
    }

    fn update_erased(
        &self,
        result: &ActionResult,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<State, ActionError> {
        LocalAction::update(self, result, state, ctx)
    }
}
