use rurr_core::action::{ActionError, ActionResult, ActionTracer};
use rurr_core::state::State;

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
#[rustfmt::skip]
fn wrong_tracer_param(
    state: &State,
    tracer: &ActionTracer,
) -> Result<ActionResult, ActionError> {
    let _ = (state, tracer);
    Ok(ActionResult::new(Default::default(), Default::default()))
}

fn main() {}
