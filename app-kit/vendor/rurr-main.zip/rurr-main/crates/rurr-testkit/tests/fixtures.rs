use futures::StreamExt;
use rurr_testkit::fixtures::{
    branching_expr_app_fixture, counter_app_async_fixture, counter_app_sync_fixture, read_count,
    state_with_count, streaming_counter_app_fixture,
};
use rurr_testkit::test_dir;

#[test]
fn test_dir_creates_distinct_ephemeral_roots() -> std::io::Result<()> {
    let first = test_dir()?;
    let second = test_dir()?;

    assert_ne!(first.path(), second.path());
    assert!(first.exists());
    assert!(second.exists());
    Ok(())
}

#[test]
fn test_dir_keeps_writes_scoped_to_each_root() -> std::io::Result<()> {
    let dir = test_dir()?;
    let stale_file = dir.join("stale.txt");
    std::fs::write(&stale_file, b"stale-data")?;
    assert!(stale_file.exists());

    let refreshed = test_dir()?;

    assert_ne!(dir.path(), refreshed.path());
    assert!(!refreshed.join("stale.txt").exists());
    Ok(())
}

#[test]
fn sync_counter_increments_count() {
    let fixture = counter_app_sync_fixture();
    let next = fixture.action.run_logic(&fixture.initial_state);

    assert_eq!(read_count(&next), 1);
}

#[tokio::test]
async fn async_counter_increments_count() {
    let fixture = counter_app_async_fixture();
    let next = fixture.action.run_logic(&fixture.initial_state).await;

    assert_eq!(read_count(&next), 1);
}

#[test]
fn sync_streaming_counter_yields_intermediate_counts_in_order() {
    let fixture = streaming_counter_app_fixture();
    let counts: Vec<i64> = fixture
        .sync_action
        .stream_logic(&fixture.initial_state)
        .map(|state| read_count(&state))
        .collect();

    assert_eq!(counts, vec![1, 2, 3]);
}

#[tokio::test]
async fn async_streaming_counter_yields_intermediate_counts_in_order() {
    let fixture = streaming_counter_app_fixture();
    let counts: Vec<i64> = fixture
        .async_action
        .stream_logic(&fixture.initial_state)
        .map(|state| read_count(&state))
        .collect()
        .await;

    assert_eq!(counts, vec![1, 2, 3]);
}

#[test]
fn branching_conditions_choose_expected_start_transitions() {
    let fixture = branching_expr_app_fixture();
    let low_state = state_with_count(2);
    let high_state = state_with_count(3);

    let low_targets: Vec<&str> = fixture
        .transitions
        .iter()
        .filter(|transition| transition.from == "start" && transition.condition.eval(&low_state))
        .map(|transition| transition.to)
        .collect();
    let high_targets: Vec<&str> = fixture
        .transitions
        .iter()
        .filter(|transition| transition.from == "start" && transition.condition.eval(&high_state))
        .map(|transition| transition.to)
        .collect();

    assert_eq!(low_targets, vec!["lt_three"]);
    assert_eq!(high_targets, vec!["gte_three"]);
}
