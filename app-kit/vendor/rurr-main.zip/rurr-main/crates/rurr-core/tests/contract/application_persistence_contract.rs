use super::support::application::{
    assert_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer,
    assert_persistence_spec_rejects_same_app_load_target,
    assert_persistence_spec_resume_path_loads_state_and_resumes_next_action,
    assert_persistence_spec_same_app_exact_sequence_miss_starts_fresh_at_zero,
    assert_persistence_spec_with_uninitialized_recording_persister_surfaces_persistence_error,
    start_finish_counter_builder, sync_resume_persistence_spec, PersistenceMode,
};
use rurr_core::common::panic::panic_payload_to_string;
use rurr_mongodb::MongoPersister;
use rurr_persistence::{
    BaseStateLoader, BaseStatePersister, BaseStateSaver, PersistedStateStatus, PersistenceError,
    PersistenceLoadTarget,
};
#[cfg(feature = "postgres")]
use rurr_postgres::PostgresPersister;
#[cfg(feature = "redis")]
use rurr_redis::RedisPersister;
use rurr_testkit::{
    application_fixture::map_from_pairs, drop_mongodb_collection_sync, ready_mongodb_uri_sync,
    unique_mongodb_collection_name,
};
#[cfg(feature = "redis")]
use rurr_testkit::{cleanup_redis_namespace_sync, redis_url_from_env, wait_for_redis_ready_sync};
#[cfg(feature = "postgres")]
use rurr_testkit::{drop_postgres_table_sync, ready_postgres_url_sync, unique_postgres_table_name};
use serde_json::json;
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::Arc;
#[cfg(feature = "redis")]
use uuid::Uuid;

fn initialize_sync_persister<P: BaseStateSaver>(persister: Arc<P>) -> Arc<P> {
    persister.initialize().expect("init should succeed");
    persister
}

#[cfg(feature = "postgres")]
fn live_postgres_persister_sync(prefix: &str) -> Arc<PostgresPersister> {
    let database_url =
        ready_postgres_url_sync().expect("postgres must be reachable for live tests");
    initialize_sync_persister(Arc::new(
        PostgresPersister::new(rurr_postgres::PostgresPersisterConfig::new(
            database_url,
            unique_postgres_table_name(prefix),
        ))
        .expect("persister should create"),
    ))
}

#[cfg(feature = "redis")]
fn unique_redis_namespace(prefix: &str) -> String {
    format!(
        "rurr_core_contract_{prefix}_{}",
        &Uuid::new_v4().simple().to_string()[..8]
    )
}

#[cfg(feature = "redis")]
fn live_redis_persister_sync(prefix: &str) -> Arc<RedisPersister> {
    let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
    wait_for_redis_ready_sync(&redis_url).expect("redis must be reachable for live tests");
    initialize_sync_persister(Arc::new(
        RedisPersister::new(rurr_redis::RedisPersisterConfig::new(
            redis_url,
            unique_redis_namespace(prefix),
        ))
        .expect("persister should create"),
    ))
}

#[cfg(feature = "redis")]
fn cleanup_live_redis_namespace(
    config: &rurr_redis::RedisPersisterConfig,
) -> Result<(), rurr_testkit::LiveServiceError> {
    cleanup_redis_namespace_sync(&config.redis_url, &config.namespace)
}

#[cfg(feature = "postgres")]
fn cleanup_live_postgres_table(
    config: &rurr_postgres::PostgresPersisterConfig,
) -> Result<(), rurr_testkit::LiveServiceError> {
    drop_postgres_table_sync(&config.database_url, &config.table_name)
}

#[cfg(feature = "postgres")]
fn assert_postgres_cleanup_removed_state(
    config: &rurr_postgres::PostgresPersisterConfig,
    app_id: &str,
    sequence_id: u64,
) {
    let verification =
        PostgresPersister::new(config.clone()).expect("verification persister should create");
    let load_error = verification
        .load(Some("tenant"), Some(app_id), Some(sequence_id))
        .expect_err("cleanup should drop the live test postgres table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

fn live_mongodb_persister_sync(prefix: &str) -> Arc<MongoPersister> {
    let mongodb_uri = ready_mongodb_uri_sync().expect("mongodb must be reachable for live tests");
    initialize_sync_persister(Arc::new(
        MongoPersister::new(rurr_mongodb::MongoPersisterConfig::new(
            mongodb_uri,
            "rurr_core_contract",
            unique_mongodb_collection_name(prefix),
        ))
        .expect("persister should create"),
    ))
}

fn cleanup_live_mongodb_collection(
    config: &rurr_mongodb::MongoPersisterConfig,
) -> Result<(), rurr_testkit::LiveServiceError> {
    drop_mongodb_collection_sync(&config.uri, &config.db_name, &config.collection_name)
}

fn assert_mongodb_cleanup_removed_state(
    config: &rurr_mongodb::MongoPersisterConfig,
    app_id: &str,
    sequence_id: u64,
) {
    let verification =
        MongoPersister::new(config.clone()).expect("verification persister should create");
    let load_error = verification
        .load(Some("tenant"), Some(app_id), Some(sequence_id))
        .expect_err("cleanup should drop the live test mongodb collection");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

#[cfg(feature = "redis")]
fn assert_redis_cleanup_removed_state(
    config: &rurr_redis::RedisPersisterConfig,
    app_id: &str,
    sequence_id: u64,
) {
    let verification =
        RedisPersister::new(config.clone()).expect("verification persister should create");
    let loaded = verification
        .load(Some("tenant"), Some(app_id), Some(sequence_id))
        .expect("cleanup should make the persisted redis state disappear");
    assert!(loaded.is_none());
}

fn assert_sync_resume_flow<P>(persister: Arc<P>)
where
    P: BaseStatePersister + 'static,
{
    let spec = sync_resume_persistence_spec(
        persister,
        None,
        map_from_pairs([("count", json!(0))]),
        "start",
    );
    let mut first_app = start_finish_counter_builder()
        .with_identifiers("resume-app", Some("tenant".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(spec.clone())
        .expect("persistence spec should configure")
        .build()
        .expect("initial build should use default state");

    let first_step = first_app
        .step(None)
        .expect("first step should succeed")
        .expect("first step should execute");
    assert_eq!(first_step.action.name(), "start");
    assert_eq!(first_step.state.get("count"), Some(&json!(1)));

    let mut resumed_app = start_finish_counter_builder()
        .with_identifiers("resume-app", Some("tenant".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(spec)
        .expect("persistence spec should configure")
        .build()
        .expect("second build should load persisted state");

    assert_eq!(resumed_app.state().get("count"), Some(&json!(1)));
    assert_eq!(resumed_app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
    assert_eq!(
        resumed_app.state().get("__PRIOR_STEP"),
        Some(&json!("start"))
    );

    let resumed_step = resumed_app
        .step(None)
        .expect("resumed step should succeed")
        .expect("resumed step should execute");
    assert_eq!(resumed_step.action.name(), "finish");
}

fn assert_sync_fork_flow<P>(persister: Arc<P>)
where
    P: BaseStatePersister + 'static,
{
    persister
        .save(
            Some("tenant"),
            "source-app",
            0,
            "start",
            map_from_pairs([("count", json!(1))]),
            PersistedStateStatus::Completed,
        )
        .expect("seed save should succeed");
    persister
        .save(
            Some("tenant"),
            "source-app",
            1,
            "finish",
            map_from_pairs([("count", json!(2))]),
            PersistedStateStatus::Completed,
        )
        .expect("seed save should succeed");

    let mut forked_app = start_finish_counter_builder()
        .with_identifiers("fork-app", Some("tenant".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(sync_resume_persistence_spec(
            persister.clone(),
            Some(PersistenceLoadTarget::new(
                "source-app",
                Some("tenant".to_string()),
                Some(0),
            )),
            map_from_pairs([("count", json!(0))]),
            "start",
        ))
        .expect("persistence spec should configure")
        .build()
        .expect("fork build should succeed");

    assert_eq!(
        forked_app.parent_pointer(),
        Some(&rurr_core::application::ParentPointer {
            app_id: "source-app".to_string(),
            partition_key: Some("tenant".to_string()),
            sequence_id: Some(0),
        })
    );
    assert_eq!(forked_app.uid(), "fork-app");
    assert_eq!(forked_app.partition_key(), Some("tenant"));
    assert_eq!(forked_app.state().get("count"), Some(&json!(1)));
    assert_eq!(forked_app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
    assert_eq!(
        forked_app.state().get("__PRIOR_STEP"),
        Some(&json!("start"))
    );

    let forked_step = forked_app
        .step(None)
        .expect("forked step should succeed")
        .expect("forked step should execute");
    assert_eq!(forked_step.action.name(), "finish");

    let target_record = persister
        .load(Some("tenant"), Some("fork-app"), Some(1))
        .expect("target load should succeed")
        .expect("target record should exist");
    let source_record = persister
        .load(Some("tenant"), Some("source-app"), Some(1))
        .expect("source load should succeed")
        .expect("source record should still exist");

    assert_eq!(target_record.app_id, "fork-app");
    assert_eq!(target_record.sequence_id, 1);
    assert_eq!(
        target_record
            .state
            .as_ref()
            .and_then(|state| state.get("count")),
        Some(&json!(2))
    );
    assert_eq!(source_record.app_id, "source-app");
}

fn run_live_sync_contract_case_with_cleanup<P, Body, Cleanup, Verify, E>(
    persister: Arc<P>,
    body: Body,
    cleanup: Cleanup,
    verify_cleanup: Verify,
) where
    Body: FnOnce(Arc<P>),
    Cleanup: FnOnce() -> Result<(), E>,
    Verify: FnOnce(),
    E: std::fmt::Display,
{
    let result = catch_unwind(AssertUnwindSafe(|| body(persister)));
    let cleanup_result = cleanup();

    match result {
        Ok(()) => {
            cleanup_result.unwrap_or_else(|error| panic!("live cleanup should succeed: {error}"));
            verify_cleanup();
        }
        Err(payload) => match cleanup_result {
            Ok(()) => std::panic::resume_unwind(payload),
            Err(cleanup_error) => panic!(
                "live cleanup should succeed: body_panic={}; cleanup_error={cleanup_error}",
                panic_payload_to_string(payload),
            ),
        },
    }
}

#[test]
fn live_sync_cleanup_reports_body_panic_and_cleanup_error_together() {
    use std::sync::atomic::{AtomicBool, Ordering};

    let verified = Arc::new(AtomicBool::new(false));
    let verified_for_cleanup = verified.clone();

    let panic = catch_unwind(AssertUnwindSafe(|| {
        run_live_sync_contract_case_with_cleanup(
            Arc::new(()),
            |_| panic!("synthetic contract panic"),
            || {
                Err(PersistenceError::BackendOperationFailed {
                    operation: "contract_live_cleanup",
                    message: "cleanup provider detail".to_string(),
                })
            },
            move || verified_for_cleanup.store(true, Ordering::SeqCst),
        );
    }))
    .expect_err("body panic plus cleanup failure should panic loudly");

    let message = rurr_core::common::panic::panic_payload_to_string(panic);
    assert!(message.contains("body_panic=synthetic contract panic"));
    assert!(
        message.contains(
            "cleanup_error=backend operation failed during contract_live_cleanup: cleanup provider detail"
        )
    );
    assert!(!verified.load(Ordering::SeqCst));
}

#[test]
fn build_with_uninitialized_sync_persistence_spec_surfaces_persistence_error() {
    futures::executor::block_on(
        assert_persistence_spec_with_uninitialized_recording_persister_surfaces_persistence_error(
            PersistenceMode::Sync,
        ),
    );
}

#[test]
fn sync_persistence_spec_rejects_same_app_load_target() {
    futures::executor::block_on(assert_persistence_spec_rejects_same_app_load_target(
        PersistenceMode::Sync,
    ));
}

#[test]
fn sync_persistence_spec_resume_path_loads_state_and_resumes_next_action() {
    futures::executor::block_on(
        assert_persistence_spec_resume_path_loads_state_and_resumes_next_action(
            PersistenceMode::Sync,
        ),
    );
}

#[test]
fn sync_persistence_spec_same_app_exact_sequence_miss_starts_fresh_at_zero() {
    futures::executor::block_on(
        assert_persistence_spec_same_app_exact_sequence_miss_starts_fresh_at_zero(
            PersistenceMode::Sync,
        ),
    );
}

#[test]
fn sync_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer() {
    futures::executor::block_on(
        assert_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer(
            PersistenceMode::Sync,
        ),
    );
}

#[cfg(feature = "postgres")]
#[test]
fn postgres_sync_persistence_spec_resume_path_loads_state_and_resumes_next_action() {
    rurr_testkit::require_check_live_tests!();

    let persister = live_postgres_persister_sync("contract_sync_resume");
    let config = persister.config();
    let cleanup_config = config.clone();

    run_live_sync_contract_case_with_cleanup(
        persister,
        assert_sync_resume_flow,
        || cleanup_live_postgres_table(&cleanup_config),
        || assert_postgres_cleanup_removed_state(&config, "resume-app", 0),
    );
}

#[cfg(feature = "postgres")]
#[test]
fn postgres_sync_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer()
{
    rurr_testkit::require_check_live_tests!();

    let persister = live_postgres_persister_sync("contract_sync_fork");
    let config = persister.config();
    let cleanup_config = config.clone();

    run_live_sync_contract_case_with_cleanup(
        persister,
        assert_sync_fork_flow,
        || cleanup_live_postgres_table(&cleanup_config),
        || assert_postgres_cleanup_removed_state(&config, "source-app", 1),
    );
}

#[cfg(feature = "postgres")]
#[test]
fn postgres_sync_persistence_spec_panic_cleanup_drops_table() {
    rurr_testkit::require_check_live_tests!();

    let persister = live_postgres_persister_sync("contract_sync_panic_cleanup");
    let config = persister.config();
    let cleanup_config = config.clone();

    let panic_result = catch_unwind(AssertUnwindSafe(|| {
        run_live_sync_contract_case_with_cleanup(
            persister,
            |persister| {
                assert_sync_resume_flow(persister);
                panic!("synthetic postgres contract panic");
            },
            || cleanup_live_postgres_table(&cleanup_config),
            || {},
        );
    }));

    assert!(panic_result.is_err(), "panic fixture should unwind");
    assert_postgres_cleanup_removed_state(&config, "resume-app", 0);
}

#[cfg(feature = "redis")]
#[test]
fn redis_sync_persistence_spec_resume_path_loads_state_and_resumes_next_action() {
    rurr_testkit::require_check_live_tests!();

    let persister = live_redis_persister_sync("sync_resume");
    let config = persister.config();
    let cleanup_config = config.clone();

    run_live_sync_contract_case_with_cleanup(
        persister,
        assert_sync_resume_flow,
        || cleanup_live_redis_namespace(&cleanup_config),
        || assert_redis_cleanup_removed_state(&config, "resume-app", 0),
    );
}

#[cfg(feature = "redis")]
#[test]
fn redis_sync_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer() {
    rurr_testkit::require_check_live_tests!();

    let persister = live_redis_persister_sync("sync_fork");
    let config = persister.config();
    let cleanup_config = config.clone();

    run_live_sync_contract_case_with_cleanup(
        persister,
        assert_sync_fork_flow,
        || cleanup_live_redis_namespace(&cleanup_config),
        || assert_redis_cleanup_removed_state(&config, "source-app", 0),
    );
}

#[cfg(feature = "redis")]
#[test]
fn redis_sync_persistence_spec_panic_cleanup_reclaims_namespace() {
    rurr_testkit::require_check_live_tests!();

    let persister = live_redis_persister_sync("sync_panic_cleanup");
    let config = persister.config();
    let cleanup_config = config.clone();

    let panic_result = catch_unwind(AssertUnwindSafe(|| {
        run_live_sync_contract_case_with_cleanup(
            persister,
            |persister| {
                assert_sync_resume_flow(persister);
                panic!("synthetic redis contract panic");
            },
            || cleanup_live_redis_namespace(&cleanup_config),
            || {},
        );
    }));

    assert!(panic_result.is_err(), "panic fixture should unwind");
    assert_redis_cleanup_removed_state(&config, "resume-app", 0);
}

#[test]
fn mongodb_sync_persistence_spec_resume_path_loads_state_and_resumes_next_action() {
    rurr_testkit::require_check_live_tests!();

    let persister = live_mongodb_persister_sync("sync_resume");
    let config = persister.config();
    let cleanup_config = config.clone();

    run_live_sync_contract_case_with_cleanup(
        persister,
        assert_sync_resume_flow,
        || cleanup_live_mongodb_collection(&cleanup_config),
        || assert_mongodb_cleanup_removed_state(&config, "resume-app", 0),
    );
}

#[test]
fn mongodb_sync_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer()
{
    rurr_testkit::require_check_live_tests!();

    let persister = live_mongodb_persister_sync("sync_fork");
    let config = persister.config();
    let cleanup_config = config.clone();

    run_live_sync_contract_case_with_cleanup(
        persister,
        assert_sync_fork_flow,
        || cleanup_live_mongodb_collection(&cleanup_config),
        || assert_mongodb_cleanup_removed_state(&config, "source-app", 1),
    );
}

#[test]
fn mongodb_sync_persistence_spec_panic_cleanup_drops_collection() {
    rurr_testkit::require_check_live_tests!();

    let persister = live_mongodb_persister_sync("sync_panic_cleanup");
    let config = persister.config();
    let cleanup_config = config.clone();

    let panic_result = catch_unwind(AssertUnwindSafe(|| {
        run_live_sync_contract_case_with_cleanup(
            persister,
            |persister| {
                assert_sync_resume_flow(persister);
                panic!("synthetic mongodb contract panic");
            },
            || cleanup_live_mongodb_collection(&cleanup_config),
            || {},
        );
    }));

    assert!(panic_result.is_err(), "panic fixture should unwind");
    assert_mongodb_cleanup_removed_state(&config, "resume-app", 0);
}
