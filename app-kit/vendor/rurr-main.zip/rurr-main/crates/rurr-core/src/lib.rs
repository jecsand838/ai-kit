//! Core runtime crate for Rurr.
//!
//! `rurr-core` owns provider-neutral application execution, action wiring,
//! lifecycle dispatch, local tracking models, and visibility spans. Optional
//! provider integrations sit behind features or sibling crates: S3 tracking is
//! enabled with the `s3` feature, while OTEL lifecycle adapters and anonymous
//! telemetry live in `rurr-otel` and `rurr-telemetry`.
//!
//! Default builds do not compile AWS, OTEL, or anonymous telemetry providers.
//! Enable `rurr-core/s3` only when constructing S3 tracking clients or parsing
//! Burr-compatible S3 keys and metadata.
//!
//! Execution options support Burr-compatible halt selectors: action names and
//! `@tag:<tag>` values are resolved before run, iterate, and streaming APIs
//! execute any action. Local tracking readers are similarly fail-closed: once
//! an app directory exists, missing required artifacts are reported as typed
//! errors instead of being summarized as empty state.
//!
//! Module overview:
//! - [`state`]: immutable state container, serde wiring, and typing registry.
//! - [`action`]: action traits, function actions, conditions, and streaming action APIs.
//! - [`graph`]: graph/action topology, transitions, and graph validation.
//! - [`application`]: builder, run/step/stream execution APIs, and runtime context types.
//! - [`lifecycle`]: sync/async lifecycle hook traits, typed contexts, and guards.
//! - [`parallelism`]: map-style parallel task actions and supporting runtime types.
//! - [`visibility`]: tracing spans and trace helpers.
//! - [`serde`]: recursive state serialization and string dispatch helpers.
//! - [`common`]: shared runtime utilities.
//! - [`tracking`]: local tracking client, tracking models, JSONL helpers, and
//!   feature-gated S3 tracking helpers.
//! - [`validation`]: reusable validation helpers.
//!
//! Persistence backends live in sibling crates: `rurr-sqlite`,
//! `rurr-postgres`, `rurr-redis`, and `rurr-mongodb`.
//!
//! ```rust
//! use indexmap::IndexMap;
//! use rurr_core::{ApplicationBuilder, FunctionActionBuilder};
//! use serde_json::json;
//!
//! let increment = FunctionActionBuilder::new()
//!     .reads(["count"])
//!     .writes(["count"])
//!     .build_sync(|state, _ctx| {
//!         let count = state.get("count").and_then(|value| value.as_i64()).unwrap_or(0) + 1;
//!         IndexMap::from([("count".to_string(), json!(count))])
//!     })?;
//!
//! let mut app = ApplicationBuilder::new()
//!     .with_actions(vec![("increment", increment)])?
//!     .with_entrypoint("increment")?
//!     .build()?;
//!
//! let output = app.run()?;
//! assert_eq!(output.state.get("count").and_then(|value| value.as_i64()), Some(1));
//! # Ok::<(), rurr_core::ApplicationError>(())
//! ```

#![deny(missing_docs)]

/// Action traits, builders, builtin actions, and streaming result containers.
pub mod action;
/// Application builder, runtime execution, context, and runtime assembly logic.
pub mod application;
/// Shared runtime helpers used across application, tracking, and visibility code.
pub mod common;
/// Graph topology types and validation helpers.
pub mod graph;
/// Lifecycle adapter traits, contexts, defaults, and guard helpers.
pub mod lifecycle;
/// Parallel execution traits, task graph types, and map/reduce helpers.
pub mod parallelism;
/// State serialization helpers and string-based serde dispatch.
pub mod serde;
/// Immutable state container, typing hooks, and mutation operations.
pub mod state;
/// Local tracking client, JSONL helpers, and tracking model types.
pub mod tracking;
/// Reusable validation utilities for builder-style APIs.
pub mod validation;
/// Trace spans, tracer factories, and convenience trace wrappers.
pub mod visibility;

pub use action::{
    Action, ActionContext, ActionError, ActionInputs, ActionKind, ActionResult, ActionTracer,
    AsyncStreamingResultContainer, Condition, ConditionError, ConditionOperator, ConditionRule,
    ErasedAction, FunctionAction, FunctionActionBuilder, FunctionActionUpdateFn,
    FunctionActionUpdatePolicy, InputAction, LocalAction, LocalAsyncStreamOutput, ResultAction,
    RurrError, SendAsyncStreamOutput, StreamItem, StreamingResultContainer,
};
pub use application::{
    adjust_single_step_output, normalize_single_step_output, AStreamIterate, AStreamResult,
    AStreamStepHandle, Application, ApplicationBuilder, ApplicationContext, ApplicationError,
    ApplicationGraph, AsyncStepExecutedAction, ExecutedAction, ExecutionOptions, ExecutionSession,
    InitializeFromSpec, ParentPointer, RunOutput, SingleStepOutput, StepOutput, StreamIterate,
    StreamResult, StreamStepHandle, Tracker, TrackerSpec,
};
pub use graph::{
    validate_actions, validate_transitions, Graph, GraphAction, GraphBuilder, GraphError,
    Transition,
};
pub use lifecycle::{
    AsyncLifecycleAdapter, AsyncLifecycleContextPropagator, AsyncLifecyclePollContext,
    AsyncLifecyclePollGuard, ExecuteCallContext, ExecuteCallGuard, LifecycleAdapterSet,
    LifecycleExecutionMode, PostStepContext, PreStepContext, SlowDownHook, SpanContext,
    StateAndResultsFullLogger, StateAndResultsLogMode, StepGuard, StepOutcome, StreamContext,
    StreamGuard, StreamItemContext, SyncLifecycleAdapter,
};
pub use parallelism::{
    map_reduce_action, CascadeMode, ParallelExecutor, ParallelMap, ParallelRuntimeContext,
    ParallelTaskSource, RunnableGraph, SubGraphTask, TaskBasedParallelAction,
};
pub use serde::register_serde_deserializer;
pub use state::{
    register_field_serde, DefaultTypingSystem, State, StateError, StateOperation, TypingSystem,
};
pub use visibility::{
    trace, trace_async, ActionSpan, TraceOptions, TraceSpanHandle, VisibilityError,
};
