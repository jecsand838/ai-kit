rootProject.name = "example"

