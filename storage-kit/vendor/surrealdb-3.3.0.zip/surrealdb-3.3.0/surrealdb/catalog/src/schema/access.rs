use std::fmt;
use std::time::Duration;

use anyhow::Context as _;
use revision::revisioned;
use surrealdb_kvs::impl_kv_value_revisioned;
use surrealdb_strand::Strand;
use surrealdb_types::{SqlFormat, ToSql};

use crate::catalog::schema::base::Base;
use crate::catalog::{ExprText, FromStored};
use crate::expr::Expr;
use crate::expr::statements::info::InfoStructure;
use crate::sql;
use crate::val::Value;

/// The type of access methods available
#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Eq, PartialEq)]
pub enum AccessType {
	Record(RecordAccess),
	Jwt(JwtAccess),
	Bearer(BearerAccess),
}

impl AccessType {
	/// Returns whether or not the access method can issue non-token grants
	/// In this context, token refers exclusively to JWT
	pub fn can_issue_grants(&self) -> bool {
		match self {
			// The JWT access method cannot issue stateful grants.
			AccessType::Jwt(_) => false,
			// The record access method can be used to issue grants if defined with bearer AKA
			// refresh.
			AccessType::Record(ac) => ac.bearer.is_some(),
			AccessType::Bearer(_) => true,
		}
	}
	/// Returns whether or not the access method can issue tokens
	/// In this context, tokens refers exclusively to JWT
	pub fn can_issue_tokens(&self) -> bool {
		match self {
			// The JWT access method can only issue tokens if an issuer is set
			AccessType::Jwt(jwt) => jwt.issue.is_some(),
			_ => true,
		}
	}
}

impl InfoStructure for AccessType {
	fn structure(self) -> Value {
		match self {
			AccessType::Jwt(v) => Value::from(map! {
				"kind" => "JWT".into(),
				"jwt" => v.structure(),
			}),
			AccessType::Record(v) => Value::from(map! {
				"kind" => "RECORD".into(),
				"jwt" => v.jwt.structure(),
				"signup", if let Some(v) = v.signup => v.into(),
				"signin", if let Some(v) = v.signin => v.into(),
				"refresh", if v.bearer.is_some() => true.into(),
			}),
			AccessType::Bearer(ac) => Value::from(map! {
				"kind" => "BEARER".into(),
				"subject" => match ac.subject {
					BearerAccessSubject::Record => "RECORD".into(),
					BearerAccessSubject::User => "USER".into(),
				},
				"jwt" => ac.jwt.structure(),
			}),
		}
	}
}

#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Eq, PartialEq)]
pub struct RecordAccess {
	/// Canonical SurrealQL text of the `SIGNUP` clause's expression.
	pub signup: Option<ExprText>,
	/// Canonical SurrealQL text of the `SIGNIN` clause's expression.
	pub signin: Option<ExprText>,
	pub jwt: JwtAccess,
	pub bearer: Option<BearerAccess>,
}

#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Eq, PartialEq)]
pub struct BearerAccess {
	pub kind: BearerAccessType,
	pub subject: BearerAccessSubject,
	pub jwt: JwtAccess,
}

#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Copy, Eq, PartialEq)]
pub enum BearerAccessType {
	Bearer,
	Refresh,
}

#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Copy, Eq, PartialEq)]
pub enum BearerAccessSubject {
	Record,
	User,
}

#[revisioned(revision = 2)]
#[derive(Debug, Hash, Clone, Eq, PartialEq)]
pub struct JwtAccess {
	// Verify is required
	pub verify: JwtAccessVerify,
	// Issue is optional
	// It is possible to only verify externally issued tokens
	pub issue: Option<JwtAccessIssue>,
	/// Accepted values for the token `aud` claim. When set, tokens verified
	/// against this access method must carry an `aud` claim that intersects
	/// this list. `None` disables audience validation.
	#[revision(start = 2)]
	pub audience: Option<Vec<String>>,
}

impl InfoStructure for JwtAccess {
	fn structure(self) -> Value {
		Value::from(map! {
			"verify" => match self.verify {
				JwtAccessVerify::Jwks(v) => Value::from(map!{
					"url" => v.url.into(),
				}),
				JwtAccessVerify::Key(v) => {
					if v.alg.is_symmetric(){
						Value::from(map!{
							"alg" => v.alg.to_string().into(),
							"key" => super::REDACTED.into(),
						})
					}else{
						Value::from(map!{
							"alg" => v.alg.to_string().into(),
							"key" => v.key.into(),
						})
					}
				},
			},
			"issuer", if let Some(v) = self.issue => Value::from(map!{
				"alg" => v.alg.to_string().into(),
				"key" => super::REDACTED.into(),
			}),
			"audience", if let Some(v) = self.audience => v.into_iter().map(Value::from).collect::<Vec<_>>().into(),
		})
	}
}

#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Eq, PartialEq)]
pub enum JwtAccessVerify {
	Key(JwtAccessVerifyKey),
	Jwks(JwtAccessVerifyJwks),
}

#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Eq, PartialEq)]
pub struct JwtAccessVerifyKey {
	pub alg: Algorithm,
	pub key: String,
}

#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Eq, PartialEq)]
pub struct JwtAccessVerifyJwks {
	pub url: String,
}

#[revisioned(revision = 1)]
#[derive(Debug, Hash, Clone, Eq, PartialEq)]
pub struct JwtAccessIssue {
	pub alg: Algorithm,
	pub key: String,
}

#[revisioned(revision = 1)]
#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub enum Algorithm {
	EdDSA,
	Es256,
	Es384,
	Es512,
	Hs256,
	Hs384,
	Hs512,
	Ps256,
	Ps384,
	Ps512,
	Rs256,
	Rs384,
	Rs512,
}

impl Algorithm {
	// Does the algorithm use the same key for signing and verification?
	pub fn is_symmetric(self) -> bool {
		matches!(self, Algorithm::Hs256 | Algorithm::Hs384 | Algorithm::Hs512)
	}
}

impl fmt::Display for Algorithm {
	fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
		f.write_str(match self {
			Self::EdDSA => "EDDSA",
			Self::Es256 => "ES256",
			Self::Es384 => "ES384",
			Self::Es512 => "ES512",
			Self::Hs256 => "HS256",
			Self::Hs384 => "HS384",
			Self::Hs512 => "HS512",
			Self::Ps256 => "PS256",
			Self::Ps384 => "PS384",
			Self::Ps512 => "PS512",
			Self::Rs256 => "RS256",
			Self::Rs384 => "RS384",
			Self::Rs512 => "RS512",
		})
	}
}

impl ToSql for Algorithm {
	fn fmt_sql(&self, f: &mut String, sql_fmt: SqlFormat) {
		self.to_string().fmt_sql(f, sql_fmt)
	}
}

#[revisioned(revision = 2)]
#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub struct StoredAccessDefinition {
	pub name: Strand,
	pub access_type: AccessType,
	pub base: Base,
	/// Canonical SurrealQL text of the `AUTHENTICATE` clause's expression.
	pub authenticate: Option<ExprText>,
	/// Canonical SurrealQL text of the `CONTEXT` clause's expression.
	///
	/// Added in revision 2. `Option` defaults to `None`, so revision-1 bytes
	/// decode to an access method without a context clause — which is exactly
	/// the pre-feature behaviour.
	#[revision(start = 2)]
	pub context: Option<ExprText>,
	pub grant_duration: Option<Duration>,
	pub token_duration: Option<Duration>,
	pub session_duration: Option<Duration>,
	pub comment: Option<String>,
}
impl_kv_value_revisioned!(StoredAccessDefinition);

impl AccessDefinition {
	fn to_sql_definition(&self) -> sql::statements::define::DefineAccessStatement {
		// Redact and lower the stored-form structure; the record-access
		// signup/signin expressions come from the compiled side fields (the
		// stored texts inside `access_type` are cleared first so the lowering
		// never re-parses them).
		let mut redacted_access_type = self.access_type.clone().redacted();
		if let AccessType::Record(rec) = &mut redacted_access_type {
			rec.signup = None;
			rec.signin = None;
		}
		let mut access_type = crate::expr::AccessType::from(redacted_access_type);
		if let crate::expr::AccessType::Record(rec) = &mut access_type {
			rec.signup.clone_from(&self.signup);
			rec.signin.clone_from(&self.signin);
		}

		sql::statements::define::DefineAccessStatement {
			kind: sql::statements::define::DefineKind::Default,
			name: sql::Expr::Idiom(sql::Idiom::field(self.name.clone())),
			access_type: sql::AccessType::from(access_type),
			authenticate: self.authenticate.clone().map(Into::into),
			context: self.context.clone().map(Into::into),
			duration: sql::access::AccessDuration {
				grant: self
					.grant_duration
					.map(|d| sql::Expr::Literal(sql::Literal::Duration(d)))
					.unwrap_or(sql::Expr::Literal(sql::Literal::None)),
				token: self
					.token_duration
					.map(|d| sql::Expr::Literal(sql::Literal::Duration(d)))
					.unwrap_or(sql::Expr::Literal(sql::Literal::None)),
				session: self
					.session_duration
					.map(|d| sql::Expr::Literal(sql::Literal::Duration(d)))
					.unwrap_or(sql::Expr::Literal(sql::Literal::None)),
			},
			comment: self
				.comment
				.clone()
				.map(|c| sql::Expr::Literal(sql::Literal::String(c.into())))
				.unwrap_or(sql::Expr::Literal(sql::Literal::None)),
			base: sql::Base::from(crate::expr::Base::from(self.base.clone())),
		}
	}
}

// Redaction methods for access types
impl AccessType {
	fn redacted(self) -> Self {
		match self {
			AccessType::Jwt(jwt) => AccessType::Jwt(jwt.redacted()),
			AccessType::Record(mut rec) => {
				rec.jwt = rec.jwt.redacted();
				if let Some(bearer) = rec.bearer {
					rec.bearer = Some(bearer.redacted());
				}
				AccessType::Record(rec)
			}
			AccessType::Bearer(mut bearer) => {
				bearer.jwt = bearer.jwt.redacted();
				AccessType::Bearer(bearer)
			}
		}
	}
}

impl JwtAccess {
	fn redacted(self) -> Self {
		Self {
			verify: self.verify.redacted(),
			issue: self.issue.map(|i| i.redacted()),
			// Audience values are not secrets.
			audience: self.audience,
		}
	}
}

impl JwtAccessVerify {
	fn redacted(self) -> Self {
		match self {
			Self::Key(mut k) => {
				// Redact symmetric keys
				if k.alg.is_symmetric() {
					k.key = super::REDACTED.to_string();
				}
				Self::Key(k)
			}
			Self::Jwks(j) => Self::Jwks(j),
		}
	}
}

impl JwtAccessIssue {
	fn redacted(self) -> Self {
		Self {
			alg: self.alg,
			// Always redact issuer keys as they're private keys
			key: super::REDACTED.to_string(),
		}
	}
}

impl BearerAccess {
	fn redacted(self) -> Self {
		Self {
			kind: self.kind,
			subject: self.subject,
			jwt: self.jwt.redacted(),
		}
	}
}

impl InfoStructure for AccessDefinition {
	fn structure(self) -> Value {
		// The record-access signup/signin expressions come from the compiled
		// side fields: re-render them into the stored-form structure before
		// serialising it (mirrors `AccessDefinition::to_stored`).
		let mut access_type = self.access_type.clone();
		if let AccessType::Record(rec) = &mut access_type {
			rec.signup = self.signup.as_ref().map(ExprText::new);
			rec.signin = self.signin.as_ref().map(ExprText::new);
		}
		Value::from(map! {
			"name" => Value::String(self.name.clone()),
			"authenticate", if let Some(v) = self.authenticate => Value::from(v.to_stored_sql()),
			"context", if let Some(v) = self.context => Value::from(v.to_stored_sql()),
			"duration" => Value::from(map!{
				"session" => self.session_duration.map(Value::from).unwrap_or(Value::None),
				"grant", if access_type.can_issue_grants() => self.grant_duration.map(Value::from).unwrap_or(Value::None),
				"token", if access_type.can_issue_tokens() => self.token_duration.map(Value::from).unwrap_or(Value::None),
			}),
			"kind" => access_type.structure(),
			"comment", if let Some(v) = self.comment => v.into(),
		})
	}
}

impl ToSql for AccessDefinition {
	fn fmt_sql(&self, f: &mut String, sql_fmt: SqlFormat) {
		self.to_sql_definition().fmt_sql(f, sql_fmt)
	}
}

// Conversions between catalog and expr types
impl From<AccessType> for crate::expr::AccessType {
	fn from(v: AccessType) -> Self {
		match v {
			AccessType::Record(v) => Self::Record(Box::new(v.into())),
			AccessType::Jwt(v) => Self::Jwt(v.into()),
			AccessType::Bearer(v) => Self::Bearer(v.into()),
		}
	}
}

impl From<crate::expr::AccessType> for AccessType {
	fn from(v: crate::expr::AccessType) -> Self {
		match v {
			crate::expr::AccessType::Record(v) => AccessType::Record((*v).into()),
			crate::expr::AccessType::Jwt(v) => AccessType::Jwt(v.into()),
			crate::expr::AccessType::Bearer(v) => AccessType::Bearer(v.into()),
		}
	}
}

impl From<RecordAccess> for crate::expr::RecordAccess {
	fn from(v: RecordAccess) -> Self {
		// The stored text was already successfully parsed once, when the
		// DEFINE that produced it ran, so a failure here is a stored-catalog
		// invariant violation; drop the clause (fail closed: no signup/signin
		// expression means that flow is unavailable) rather than panicking.
		let compile_clause = |text: crate::catalog::ExprText, clause: &str| match text.compile() {
			Ok(expr) => Some(expr),
			Err(err) => {
				debug_assert!(false, "stored access {clause} clause failed to parse: {text:?}");
				// Warn, not silence: dropping the clause makes that
				// authentication flow unavailable, and without a line here an
				// operator sees only "signin stopped working" — no log, no
				// metric, no error text. The clause name and the parse error
				// are what makes it diagnosable; the clause text itself is
				// left out, since it can carry credentials.
				warn!(
					target: "surrealdb::core::catalog",
					clause = %clause,
					error = %err,
					"Stored access clause no longer parses; that authentication flow is disabled"
				);
				None
			}
		};
		Self {
			signup: v.signup.and_then(|text| compile_clause(text, "signup")),
			signin: v.signin.and_then(|text| compile_clause(text, "signin")),
			jwt: v.jwt.into(),
			bearer: v.bearer.map(|b| b.into()),
		}
	}
}

impl From<crate::expr::RecordAccess> for RecordAccess {
	fn from(v: crate::expr::RecordAccess) -> Self {
		Self {
			signup: v.signup.map(|e| ExprText::new(&e)),
			signin: v.signin.map(|e| ExprText::new(&e)),
			jwt: v.jwt.into(),
			bearer: v.bearer.map(|b| b.into()),
		}
	}
}

impl From<JwtAccess> for crate::expr::JwtAccess {
	fn from(v: JwtAccess) -> Self {
		Self {
			verify: v.verify.into(),
			issue: v.issue.map(|i| i.into()),
			audience: v.audience.map(|a| {
				a.into_iter()
					.map(|s| crate::expr::Expr::Literal(crate::expr::Literal::String(s.into())))
					.collect()
			}),
		}
	}
}

impl From<crate::expr::JwtAccess> for JwtAccess {
	fn from(v: crate::expr::JwtAccess) -> Self {
		Self {
			verify: v.verify.into(),
			issue: v.issue.map(|i| i.into()),
			audience: v.audience.map(|a| {
				a.into_iter()
					.map(|e| match e {
						crate::expr::Expr::Literal(crate::expr::Literal::String(s)) => {
							s.into_string()
						}
						e => e.to_sql(),
					})
					.collect()
			}),
		}
	}
}

impl From<JwtAccessVerify> for crate::expr::access_type::JwtAccessVerify {
	fn from(v: JwtAccessVerify) -> Self {
		match v {
			JwtAccessVerify::Key(k) => Self::Key(k.into()),
			JwtAccessVerify::Jwks(j) => Self::Jwks(j.into()),
		}
	}
}

impl From<crate::expr::access_type::JwtAccessVerify> for JwtAccessVerify {
	fn from(v: crate::expr::access_type::JwtAccessVerify) -> Self {
		match v {
			crate::expr::access_type::JwtAccessVerify::Key(k) => JwtAccessVerify::Key(k.into()),
			crate::expr::access_type::JwtAccessVerify::Jwks(j) => JwtAccessVerify::Jwks(j.into()),
		}
	}
}

impl From<JwtAccessVerifyKey> for crate::expr::access_type::JwtAccessVerifyKey {
	fn from(v: JwtAccessVerifyKey) -> Self {
		Self {
			alg: v.alg.into(),
			key: crate::expr::Expr::Literal(crate::expr::Literal::String(v.key.into())),
		}
	}
}

impl From<crate::expr::access_type::JwtAccessVerifyKey> for JwtAccessVerifyKey {
	fn from(v: crate::expr::access_type::JwtAccessVerifyKey) -> Self {
		Self {
			alg: v.alg.into(),
			key: match v.key {
				crate::expr::Expr::Literal(crate::expr::Literal::String(s)) => s.into_string(),
				_ => v.key.to_sql(),
			},
		}
	}
}

impl From<JwtAccessVerifyJwks> for crate::expr::access_type::JwtAccessVerifyJwks {
	fn from(v: JwtAccessVerifyJwks) -> Self {
		Self {
			url: crate::expr::Expr::Literal(crate::expr::Literal::String(v.url.into())),
		}
	}
}

impl From<crate::expr::access_type::JwtAccessVerifyJwks> for JwtAccessVerifyJwks {
	fn from(v: crate::expr::access_type::JwtAccessVerifyJwks) -> Self {
		Self {
			url: match v.url {
				crate::expr::Expr::Literal(crate::expr::Literal::String(s)) => s.into_string(),
				_ => v.url.to_sql(),
			},
		}
	}
}

impl From<JwtAccessIssue> for crate::expr::access_type::JwtAccessIssue {
	fn from(v: JwtAccessIssue) -> Self {
		Self {
			alg: v.alg.into(),
			key: crate::expr::Expr::Literal(crate::expr::Literal::String(v.key.into())),
		}
	}
}

impl From<crate::expr::access_type::JwtAccessIssue> for JwtAccessIssue {
	fn from(v: crate::expr::access_type::JwtAccessIssue) -> Self {
		Self {
			alg: v.alg.into(),
			key: match v.key {
				crate::expr::Expr::Literal(crate::expr::Literal::String(s)) => s.into_string(),
				_ => v.key.to_sql(),
			},
		}
	}
}

impl From<BearerAccess> for crate::expr::access_type::BearerAccess {
	fn from(v: BearerAccess) -> Self {
		Self {
			kind: v.kind.into(),
			subject: v.subject.into(),
			jwt: v.jwt.into(),
		}
	}
}

impl From<crate::expr::access_type::BearerAccess> for BearerAccess {
	fn from(v: crate::expr::access_type::BearerAccess) -> Self {
		Self {
			kind: v.kind.into(),
			subject: v.subject.into(),
			jwt: v.jwt.into(),
		}
	}
}

impl From<BearerAccessType> for crate::expr::access_type::BearerAccessType {
	fn from(v: BearerAccessType) -> Self {
		match v {
			BearerAccessType::Bearer => Self::Bearer,
			BearerAccessType::Refresh => Self::Refresh,
		}
	}
}

impl From<crate::expr::access_type::BearerAccessType> for BearerAccessType {
	fn from(v: crate::expr::access_type::BearerAccessType) -> Self {
		match v {
			crate::expr::access_type::BearerAccessType::Bearer => Self::Bearer,
			crate::expr::access_type::BearerAccessType::Refresh => Self::Refresh,
		}
	}
}

impl From<BearerAccessSubject> for crate::expr::access_type::BearerAccessSubject {
	fn from(v: BearerAccessSubject) -> Self {
		match v {
			BearerAccessSubject::Record => Self::Record,
			BearerAccessSubject::User => Self::User,
		}
	}
}

impl From<crate::expr::access_type::BearerAccessSubject> for BearerAccessSubject {
	fn from(v: crate::expr::access_type::BearerAccessSubject) -> Self {
		match v {
			crate::expr::access_type::BearerAccessSubject::Record => Self::Record,
			crate::expr::access_type::BearerAccessSubject::User => Self::User,
		}
	}
}

impl From<Algorithm> for crate::expr::Algorithm {
	fn from(v: Algorithm) -> Self {
		match v {
			Algorithm::EdDSA => Self::EdDSA,
			Algorithm::Es256 => Self::Es256,
			Algorithm::Es384 => Self::Es384,
			Algorithm::Es512 => Self::Es512,
			Algorithm::Hs256 => Self::Hs256,
			Algorithm::Hs384 => Self::Hs384,
			Algorithm::Hs512 => Self::Hs512,
			Algorithm::Ps256 => Self::Ps256,
			Algorithm::Ps384 => Self::Ps384,
			Algorithm::Ps512 => Self::Ps512,
			Algorithm::Rs256 => Self::Rs256,
			Algorithm::Rs384 => Self::Rs384,
			Algorithm::Rs512 => Self::Rs512,
		}
	}
}

impl From<crate::expr::Algorithm> for Algorithm {
	fn from(v: crate::expr::Algorithm) -> Self {
		match v {
			crate::expr::Algorithm::EdDSA => Self::EdDSA,
			crate::expr::Algorithm::Es256 => Self::Es256,
			crate::expr::Algorithm::Es384 => Self::Es384,
			crate::expr::Algorithm::Es512 => Self::Es512,
			crate::expr::Algorithm::Hs256 => Self::Hs256,
			crate::expr::Algorithm::Hs384 => Self::Hs384,
			crate::expr::Algorithm::Hs512 => Self::Hs512,
			crate::expr::Algorithm::Ps256 => Self::Ps256,
			crate::expr::Algorithm::Ps384 => Self::Ps384,
			crate::expr::Algorithm::Ps512 => Self::Ps512,
			crate::expr::Algorithm::Rs256 => Self::Rs256,
			crate::expr::Algorithm::Rs384 => Self::Rs384,
			crate::expr::Algorithm::Rs512 => Self::Rs512,
		}
	}
}

/// Runtime form of [`StoredAccessDefinition`].
///
/// `access_type` stays in its stored form (JWT and bearer configuration is
/// plain data); the expressions it may carry (record-access signup/signin)
/// are compiled into the side fields here, which are `None` for non-record
/// access types. Read structure from `access_type`, expressions from the
/// side fields.
#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub struct AccessDefinition {
	pub name: Strand,
	pub base: Base,
	pub access_type: AccessType,
	pub authenticate: Option<Expr>,
	/// Compiled `CONTEXT` clause. Evaluated once, at authentication time,
	/// after the identity has been settled, and its whole result is stored on
	/// the session and read back as `$session.data`.
	///
	/// What it buys: a permission written as
	/// `WHERE org IN (SELECT VALUE org FROM grant WHERE owner = $auth)` costs
	/// O(rows x grant_rows) — the subquery re-scans the inner table for every
	/// row it filters. Moving that lookup into a `CONTEXT` clause makes it
	/// O(rows x payload_size), because the payload is materialised once.
	///
	/// It does NOT reach O(rows). Resolving `$session.<constant path>` to a
	/// literal happens in `exec/planner/idiom.rs`, during physical-expression
	/// construction — after index analysis has chosen the plan — so the
	/// predicate cannot drive an index and `IN` still walks the payload once
	/// per row. What that fold removes is a per-row deep clone of the whole
	/// `$session` object, which is worth having and is not the same thing.
	/// See the ALTITUDE note on `plan_idiom` for why the fold sits there and
	/// what it would take to lift it.
	///
	/// The payload size is therefore a first-order term: a clause that
	/// materialises thousands of entries trades one problem for another.
	///
	/// What it costs: the value is a snapshot taken at authentication and goes
	/// stale for the life of the session, bounded by `DURATION FOR SESSION`. A
	/// grant revoked in the table is not seen until the session re-authenticates
	/// — which, for a refresh-token flow, is every rotation. `$auth` is
	/// deliberately left alone and keeps its fetch semantics, so a definition
	/// can choose per-value which side of that trade it wants.
	///
	/// This field is the *compiled* clause: `from_stored` below re-parses the
	/// stored text under `ParserSettings::STORED_TEXT`, which is a different
	/// parse from the one `DEFINE`/`ALTER` validated. The read-only rule that
	/// makes the clause safe to run on every authentication is therefore
	/// re-checked on this value, at the point it is evaluated
	/// (`core/src/iam/access.rs`, `session_data_for_record`), rather than
	/// trusted from definition time.
	pub context: Option<Expr>,
	pub signup: Option<Expr>,
	pub signin: Option<Expr>,
	pub grant_duration: Option<Duration>,
	pub token_duration: Option<Duration>,
	pub session_duration: Option<Duration>,
	pub comment: Option<String>,
}

impl FromStored for AccessDefinition {
	type Stored = StoredAccessDefinition;

	fn from_stored(stored: &StoredAccessDefinition) -> anyhow::Result<AccessDefinition> {
		fn build(stored: &StoredAccessDefinition) -> anyhow::Result<AccessDefinition> {
			let (signup, signin) = match &stored.access_type {
				AccessType::Record(record) => (
					record.signup.as_ref().map(|t| t.compile()).transpose()?,
					record.signin.as_ref().map(|t| t.compile()).transpose()?,
				),
				_ => (None, None),
			};
			Ok(AccessDefinition {
				name: stored.name.clone(),
				base: stored.base.clone(),
				access_type: stored.access_type.clone(),
				authenticate: stored.authenticate.as_ref().map(|t| t.compile()).transpose()?,
				context: stored.context.as_ref().map(|t| t.compile()).transpose()?,
				signup,
				signin,
				grant_duration: stored.grant_duration,
				token_duration: stored.token_duration,
				session_duration: stored.session_duration,
				comment: stored.comment.clone(),
			})
		}
		build(stored).with_context(|| {
			format!("the stored definition of access method `{}` no longer compiles", stored.name)
		})
	}
}

impl AccessDefinition {
	pub fn to_stored(&self) -> StoredAccessDefinition {
		// The stored-form clone in `access_type` may be stale if the compiled
		// signup/signin expressions were mutated, so re-render them into it.
		let mut access_type = self.access_type.clone();
		if let AccessType::Record(record) = &mut access_type {
			record.signup = self.signup.as_ref().map(ExprText::new);
			record.signin = self.signin.as_ref().map(ExprText::new);
		}
		StoredAccessDefinition {
			name: self.name.clone(),
			access_type,
			base: self.base.clone(),
			authenticate: self.authenticate.as_ref().map(ExprText::new),
			context: self.context.as_ref().map(ExprText::new),
			grant_duration: self.grant_duration,
			token_duration: self.token_duration,
			session_duration: self.session_duration,
			comment: self.comment.clone(),
		}
	}
}
