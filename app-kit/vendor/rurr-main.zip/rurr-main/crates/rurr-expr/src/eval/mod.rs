mod compare;
mod numeric;
mod slice;

use crate::validate::{expr_variant_name, is_len_call};
use crate::value::{
    coerce_number, constant_to_eval_value, is_truthy, json_to_eval_value, EvalValue,
};
use crate::{ExprAst, ExprError, StateView};
pub use compare::{
    compare_eval_values, compare_json_values, condition_rule_name, python_repr,
    python_repr_with_mode, ComparisonOperator, PythonReprMode,
};
use numeric::{
    numeric_add, numeric_div, numeric_floor_div, numeric_mod, numeric_mul, numeric_pow, numeric_sub,
};
use rustpython_parser::ast;

/// Evaluates `ast` against `state` and returns the final truthiness result.
pub fn evaluate_bool<S: StateView>(ast: &ExprAst, state: &S) -> Result<bool, ExprError> {
    let value = evaluate_expr(&ast.expr, state)?;
    Ok(is_truthy(&value))
}

fn evaluate_expr<S: StateView>(expr: &ast::Expr, state: &S) -> Result<EvalValue, ExprError> {
    match expr {
        ast::Expr::BoolOp(node) => evaluate_bool_op(node, state),
        ast::Expr::UnaryOp(node) => evaluate_unary_op(node, state),
        ast::Expr::BinOp(node) => evaluate_bin_op(node, state),
        ast::Expr::IfExp(node) => evaluate_if_exp(node, state),
        ast::Expr::Compare(node) => evaluate_compare(node, state),
        ast::Expr::Call(node) => evaluate_call(node, state),
        ast::Expr::Name(node) => {
            let value =
                state
                    .get_value(node.id.as_str())
                    .ok_or_else(|| ExprError::UnknownName {
                        name: node.id.to_string(),
                    })?;
            json_to_eval_value(value)
        }
        ast::Expr::Constant(node) => constant_to_eval_value(&node.value),
        ast::Expr::Attribute(node) => evaluate_attribute(node, state),
        ast::Expr::Subscript(node) => evaluate_subscript(node, state),
        ast::Expr::Slice(_) => Err(ExprError::UnsupportedNode {
            node: "Slice".to_string(),
        }),
        _ => Err(ExprError::UnsupportedNode {
            node: expr_variant_name(expr).to_string(),
        }),
    }
}

fn evaluate_bool_op<S: StateView>(
    node: &ast::ExprBoolOp,
    state: &S,
) -> Result<EvalValue, ExprError> {
    let (first, rest) = node.values.split_first().ok_or_else(|| ExprError::Parse {
        message: "boolean operation cannot be empty".to_string(),
    })?;

    let mut current = evaluate_expr(first, state)?;
    match node.op {
        ast::BoolOp::And => {
            for value in rest {
                if !is_truthy(&current) {
                    return Ok(current);
                }
                current = evaluate_expr(value, state)?;
            }
            Ok(current)
        }
        ast::BoolOp::Or => {
            for value in rest {
                if is_truthy(&current) {
                    return Ok(current);
                }
                current = evaluate_expr(value, state)?;
            }
            Ok(current)
        }
    }
}

fn evaluate_unary_op<S: StateView>(
    node: &ast::ExprUnaryOp,
    state: &S,
) -> Result<EvalValue, ExprError> {
    let operand = evaluate_expr(&node.operand, state)?;
    match node.op {
        ast::UnaryOp::Not => Ok(EvalValue::Bool(!is_truthy(&operand))),
        ast::UnaryOp::UAdd => match coerce_number(&operand)? {
            crate::value::NumberValue::Int(value) => Ok(EvalValue::Int(value)),
            crate::value::NumberValue::Float(value) => Ok(EvalValue::Float(value)),
        },
        ast::UnaryOp::USub => match coerce_number(&operand)? {
            crate::value::NumberValue::Int(value) => {
                let negated = value.checked_neg().ok_or(ExprError::IntegerOverflow)?;
                Ok(EvalValue::Int(negated))
            }
            crate::value::NumberValue::Float(value) => Ok(EvalValue::Float(-value)),
        },
        _ => Err(ExprError::UnsupportedOperator {
            operator: format!("{:#?}", node.op),
        }),
    }
}

fn evaluate_if_exp<S: StateView>(node: &ast::ExprIfExp, state: &S) -> Result<EvalValue, ExprError> {
    let test = evaluate_expr(&node.test, state)?;
    if is_truthy(&test) {
        evaluate_expr(&node.body, state)
    } else {
        evaluate_expr(&node.orelse, state)
    }
}

fn evaluate_bin_op<S: StateView>(node: &ast::ExprBinOp, state: &S) -> Result<EvalValue, ExprError> {
    let left = evaluate_expr(&node.left, state)?;
    let right = evaluate_expr(&node.right, state)?;
    let left_num = coerce_number(&left)?;
    let right_num = coerce_number(&right)?;

    match node.op {
        ast::Operator::Add => numeric_add(left_num, right_num),
        ast::Operator::Sub => numeric_sub(left_num, right_num),
        ast::Operator::Mult => numeric_mul(left_num, right_num),
        ast::Operator::Div => numeric_div(left_num, right_num),
        ast::Operator::Mod => numeric_mod(left_num, right_num),
        ast::Operator::FloorDiv => numeric_floor_div(left_num, right_num),
        ast::Operator::Pow => numeric_pow(left_num, right_num),
        _ => Err(ExprError::UnsupportedOperator {
            operator: format!("{:#?}", node.op),
        }),
    }
}

fn evaluate_compare<S: StateView>(
    node: &ast::ExprCompare,
    state: &S,
) -> Result<EvalValue, ExprError> {
    let mut left = evaluate_expr(&node.left, state)?;
    for (op, comparator_expr) in node.ops.iter().zip(node.comparators.iter()) {
        let right = evaluate_expr(comparator_expr, state)?;
        let is_match = evaluate_single_comparison(*op, &left, &right)?;
        if !is_match {
            return Ok(EvalValue::Bool(false));
        }
        left = right;
    }
    Ok(EvalValue::Bool(true))
}

fn evaluate_call<S: StateView>(node: &ast::ExprCall, state: &S) -> Result<EvalValue, ExprError> {
    if !is_len_call(node) {
        return Err(ExprError::InvalidCall {
            message: "only len(...) is supported".to_string(),
        });
    }
    let value = evaluate_expr(&node.args[0], state)?;
    let length = match value {
        EvalValue::String(text) => text.chars().count() as i128,
        EvalValue::Array(items) => items.len() as i128,
        EvalValue::Object(values) => values.len() as i128,
        _ => {
            return Err(ExprError::TypeError {
                message: "len(...) argument must be a string, list, or dict".to_string(),
            })
        }
    };
    Ok(EvalValue::Int(length))
}

fn evaluate_attribute<S: StateView>(
    node: &ast::ExprAttribute,
    state: &S,
) -> Result<EvalValue, ExprError> {
    let value = evaluate_expr(&node.value, state)?;
    match value {
        EvalValue::Object(values) => {
            values
                .get(node.attr.as_str())
                .cloned()
                .ok_or_else(|| ExprError::InvalidSubscript {
                    message: format!("attribute '{}' does not exist", node.attr.as_str()),
                })
        }
        other => Err(ExprError::TypeError {
            message: format!(
                "cannot access attribute '{}' on {other:?}",
                node.attr.as_str()
            ),
        }),
    }
}

fn evaluate_subscript<S: StateView>(
    node: &ast::ExprSubscript,
    state: &S,
) -> Result<EvalValue, ExprError> {
    let container = evaluate_expr(&node.value, state)?;
    if let ast::Expr::Slice(slice) = node.slice.as_ref() {
        return slice::evaluate_slice_subscript(container, slice, state);
    }
    let index = evaluate_expr(&node.slice, state)?;

    match container {
        EvalValue::Object(values) => {
            let key = match index {
                EvalValue::String(value) => value,
                other => {
                    return Err(ExprError::InvalidSubscript {
                        message: format!("dict indices must be strings, got {other:?}"),
                    })
                }
            };
            values
                .get(&key)
                .cloned()
                .ok_or_else(|| ExprError::InvalidSubscript {
                    message: format!("key '{key}' does not exist"),
                })
        }
        EvalValue::Array(items) => {
            let mut idx = crate::value::coerce_index(&index)?;
            let len = i128::try_from(items.len()).map_err(|_| ExprError::IntegerOverflow)?;
            if idx < 0 {
                idx = idx.checked_add(len).ok_or(ExprError::IntegerOverflow)?;
            }
            if idx < 0 || idx >= len {
                return Err(ExprError::InvalidSubscript {
                    message: format!("list index {idx} out of range"),
                });
            }
            Ok(items[idx as usize].clone())
        }
        other => Err(ExprError::InvalidSubscript {
            message: format!("cannot subscript value {other:?}"),
        }),
    }
}

fn evaluate_single_comparison(
    op: ast::CmpOp,
    left: &EvalValue,
    right: &EvalValue,
) -> Result<bool, ExprError> {
    match op {
        ast::CmpOp::Eq => compare_eval_values(left, ComparisonOperator::Eq, right),
        ast::CmpOp::NotEq => compare_eval_values(left, ComparisonOperator::NotEq, right),
        ast::CmpOp::Lt => compare_eval_values(left, ComparisonOperator::Lt, right),
        ast::CmpOp::LtE => compare_eval_values(left, ComparisonOperator::LtE, right),
        ast::CmpOp::Gt => compare_eval_values(left, ComparisonOperator::Gt, right),
        ast::CmpOp::GtE => compare_eval_values(left, ComparisonOperator::GtE, right),
        ast::CmpOp::In => compare_eval_values(left, ComparisonOperator::In, right),
        ast::CmpOp::NotIn => compare_eval_values(left, ComparisonOperator::NotIn, right),
        ast::CmpOp::Is => compare_eval_values(left, ComparisonOperator::Is, right),
        ast::CmpOp::IsNot => compare_eval_values(left, ComparisonOperator::IsNot, right),
    }
}

#[cfg(test)]
mod tests {
    use super::evaluate_expr;
    use crate::parse::parse;
    use crate::value::EvalValue;
    use crate::{ExprError, StateView};
    use serde_json::{json, Value};
    use std::collections::HashMap;

    struct TestState {
        values: HashMap<String, Value>,
    }

    impl TestState {
        fn from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> Self {
            Self {
                values: pairs
                    .into_iter()
                    .map(|(key, value)| (key.to_string(), value))
                    .collect(),
            }
        }
    }

    impl StateView for TestState {
        fn get_value(&self, key: &str) -> Option<&Value> {
            self.values.get(key)
        }
    }

    fn evaluate(expression: &str, state: &TestState) -> Result<EvalValue, ExprError> {
        let ast = parse(expression).expect("expression should parse");
        evaluate_expr(&ast.expr, state)
    }

    #[test]
    fn attribute_access_reports_missing_attributes() {
        let state = TestState::from_pairs([("obj", json!({"score": 9}))]);
        let error = evaluate("obj.missing", &state).expect_err("missing attributes should fail");

        assert_eq!(
            error,
            ExprError::InvalidSubscript {
                message: "attribute 'missing' does not exist".to_string(),
            }
        );
    }

    #[test]
    fn dict_subscripts_require_string_keys() {
        let state = TestState::from_pairs([("obj", json!({"score": 9}))]);
        let error = evaluate("obj[1]", &state).expect_err("numeric dict keys should fail");

        assert_eq!(
            error,
            ExprError::InvalidSubscript {
                message: "dict indices must be strings, got Int(1)".to_string(),
            }
        );
    }

    #[test]
    fn list_subscripts_report_out_of_range_indices() {
        let state = TestState::from_pairs([("items", json!([1, 2, 3]))]);
        let error = evaluate("items[5]", &state).expect_err("out-of-range list index should fail");

        assert_eq!(
            error,
            ExprError::InvalidSubscript {
                message: "list index 5 out of range".to_string(),
            }
        );
    }

    #[test]
    fn membership_tests_reject_invalid_string_operands() {
        let error = evaluate("'a' in 7", &TestState::from_pairs([]))
            .expect_err("membership on unsupported rhs should fail");
        assert_eq!(
            error,
            ExprError::InvalidMembership {
                message: "value Int(7) does not support membership tests".to_string(),
            }
        );

        let state = TestState::from_pairs([("text", json!("alphabet"))]);
        let error =
            evaluate("1 in text", &state).expect_err("non-string lhs against string should fail");
        assert_eq!(
            error,
            ExprError::InvalidMembership {
                message: "left operand must be a string when right operand is a string".to_string(),
            }
        );
    }
}
