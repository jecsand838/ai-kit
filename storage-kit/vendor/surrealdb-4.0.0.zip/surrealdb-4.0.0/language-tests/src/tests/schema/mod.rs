use std::collections::BTreeMap;
use std::fmt;
use std::str::FromStr;
use std::time::Duration;

use semver::VersionReq;
use serde::{Deserialize, Serialize, de};
use surrealdb_core::syn::runtime::ParserSettings;
use surrealdb_rpc::capabilities::{
	ArbitraryQueryTarget, EvalQueryTarget, ExperimentalTarget, FuncTarget, MethodTarget, NetTarget,
	RouteTarget,
};
use surrealdb_types::{Object, RecordId, ToSql, Value};

use crate::cli::{Backend, RunMode};
use crate::tests::feature::Feature;

fn bool_or_f<T>() -> BoolOr<T> {
	BoolOr::Bool(false)
}

fn t() -> bool {
	true
}

fn default_duration<const V: u64>() -> TestDuration {
	TestDuration(Duration::from_millis(V))
}

fn default_usize<const V: usize>() -> usize {
	V
}

pub const ENV_DEFAULT_TIMEOUT: Duration = Duration::from_secs(1);
pub const ENV_DEFAULT_NAMESPACE: &str = "test";
pub const ENV_DEFAULT_DATABASE: &str = "test";

/// Root test config struct.
#[derive(Default, Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct TestConfig {
	#[serde(default)]
	pub env: TestEnv,
	#[serde(default)]
	pub test: TestDetails,
	#[serde(default)]
	pub bench: BenchDetails,
	#[serde(default)]
	pub graphql: GraphQlDetails,
	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

impl TestConfig {
	/// Returns a list of keys which are not in the schema but still defined.
	pub fn unused_keys(&self) -> Vec<String> {
		let mut res: Vec<_> = self._unused_keys.keys().cloned().collect();
		res.append(&mut self.env.unused_keys());
		res.append(&mut self.test.unused_keys());
		res.extend(self.bench._unused_keys.keys().cloned());
		res.extend(self.graphql._unused_keys.keys().map(|x| format!("graphql.{x}")));
		res
	}
}

/// Request options for GraphQL (`.graphql`) test cases.
///
/// Only consulted when the test's dialect is GraphQL; for SurrealQL tests the
/// section is unused (and flagged by the unused-key warning if present).
#[derive(Default, Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct GraphQlDetails {
	/// Variables sent with the GraphQL request, e.g.
	/// `variables = { id = "person:1", min = 2 }`.
	#[serde(default)]
	pub variables: Option<toml::Table>,
	/// The operation to execute when the document defines multiple named
	/// operations (the GraphQL `operationName` request field).
	#[serde(default)]
	pub operation: Option<String>,
	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

#[derive(Clone, Debug, Deserialize, Serialize, Default)]
#[serde(rename_all = "kebab-case")]
pub struct TestEnv {
	/// Should the test be run sequentially
	#[serde(default)]
	pub sequential: bool,
	/// Does the test keep values around in the datastore which can't be removed with a REMOVE NS
	#[serde(default)]
	pub clean: bool,
	/// Does the test make no modification to the datastore itself.
	#[serde(default)]
	pub readonly: bool,

	#[serde(default)]
	pub namespace: BoolOr<String>,
	#[serde(default)]
	pub database: BoolOr<String>,

	pub auth: Option<TestAuth>,
	pub signup: Option<SurrealObject>,
	pub signin: Option<SurrealObject>,

	#[serde(default)]
	pub imports: Vec<String>,
	#[serde(default)]
	pub timeout: BoolOr<TestDuration>,
	#[serde(default)]
	pub capabilities: BoolOr<Capabilities>,

	/// Specifies which backends this test should run on.
	/// If empty, the test runs on all backends.
	/// If specified, the test only runs when the selected backend is in this list.
	/// Valid values: "mem", "surrealkv", "tikv"
	#[serde(default)]
	pub backend: Vec<Backend>,

	/// Whether the test requires MVCC versioning to be enabled on the datastore.
	/// When true, the datastore is created with `?versioned=true` in the
	/// connection string, and the test runs only on the backends that accept it
	/// (see [`Backend::supports_versioning`]).
	#[serde(default)]
	pub versioned: bool,
	/// The compatibility level of the test's database: `3` or `4`. The
	/// runner defines the database with `COMPATIBILITY` set to it; without
	/// it the database takes the datastore's default, level 4. Upgrade tests
	/// accept only `3`, the level every released binary's databases stand
	/// at.
	pub compatibility: Option<u8>,
	/// Datastore configuration keys the test needs, as `--config KEY=VALUE` gives them to a run:
	/// `[env.config] morsel_split_rows = "18446744073709551615"`. Each takes the place of the same
	/// key given to the run, and a test that names any gets a datastore of its own. Values are
	/// strings, since a count can exceed what TOML integers hold.
	#[serde(default)]
	pub config: BTreeMap<String, String>,
	/// Whether EXPLAIN ANALYZE output omits elapsed durations, making
	/// output deterministic for test assertions. Defaults to true in the
	/// language test framework. Set to `false` explicitly if you need
	/// actual elapsed times.
	pub redact_volatile_explain_attrs: Option<bool>,

	/// When set, the test is skipped on remote (`--endpoint`) runs, with this
	/// string reported as the reason. For the handful of tests that assert
	/// behaviour which only holds for an embedded, in-process datastore — a
	/// connection-less `$session`, the absence of a bootstrap root user, or
	/// process-relative file paths — and so can't be reproduced faithfully over
	/// the API. Ignored by embedded runs.
	pub remote_skip: Option<String>,

	/// The test reaches outside its own namespace — it creates a root user,
	/// access method or namespace, changes a system setting, or asserts on the
	/// literal name of the namespace it runs in. Remote (`--endpoint`) runs give
	/// it the endpoint to itself and the namespace name its config asks for;
	/// every other test runs concurrently in a namespace named for the run.
	///
	/// Embedded runs ignore it: every test there already has a private
	/// datastore, so there is nothing to share.
	///
	/// A test that needs this and does not declare it fails rather than races —
	/// see [`crate::cmd::run::executor::Executor::check_root_leak`].
	#[serde(default)]
	pub remote_exclusive: bool,

	/// The trace kinds the query asks for, as a `query` call's `trace` option
	/// names them: `trace = ["relations", "references", "links", "variables",
	/// "subscriptions"]`. Each statement's trace is then graded beside its value
	/// ([`crate::tests::trace`]). Empty asks for none.
	#[serde(default)]
	pub trace: Vec<String>,

	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

impl TestEnv {
	/// Returns the namespace if the environment specifies one, none otherwise
	///
	/// Defaults to "test"
	pub fn namespace(&self) -> Option<&str> {
		self.namespace.as_ref().map(|x| x.as_str()).into_value(ENV_DEFAULT_NAMESPACE)
	}

	/// Returns the namespace if the environment specifies one, none otherwise
	///
	/// Defaults to "test"
	pub fn database(&self) -> Option<&str> {
		self.database.as_ref().map(|x| x.as_str()).into_value(ENV_DEFAULT_DATABASE)
	}

	/// Whether a remote run has to give this test the endpoint to itself.
	///
	/// Either it says so, or it asked not to run beside anything at all, or it
	/// declares no namespace — in which case it has nowhere but root to write
	/// and cannot be isolated by one.
	#[cfg_attr(not(feature = "remote"), allow(dead_code))]
	pub fn needs_exclusive_endpoint(&self) -> bool {
		self.remote_exclusive || self.sequential || self.namespace().is_none()
	}

	pub fn unused_keys(&self) -> Vec<String> {
		let mut res: Vec<_> = self._unused_keys.keys().map(|x| format!("env.{x}")).collect();

		if let BoolOr::Value(x) = self.capabilities.as_ref() {
			res.append(&mut x.unused_keys());
		}

		res
	}
}

#[derive(Clone, Debug, Serialize)]
#[serde(untagged)]
pub enum TestExpectation {
	// NOTE! Ordering of variants here is important.
	// Match must come before Error so that they are deserialized correctly.
	// Swapping match with error causes the error variant to be chosen when
	// match specifies if it expects an error.
	/// The result is a normal value
	Plain(SurrealConfigValue),
	/// The result is a value but specified as a table.
	Match(MatchTestResult),
	/// The result should be an error.
	Error(ErrorTestResult),
	/// The result is a value but specified as a table.
	Value(ValueTestResult),
}

fn to_deser_error<T: std::fmt::Display, D: serde::de::Error>(e: T) -> D {
	D::custom(e)
}

impl<'de> Deserialize<'de> for TestExpectation {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: de::Deserializer<'de>,
	{
		let v = toml::Value::deserialize(deserializer)?;
		if v.is_str() {
			SurrealConfigValue::deserialize(v).map_err(to_deser_error).map(TestExpectation::Plain)
		} else if let Some(x) = v.as_table() {
			if x.contains_key("match") {
				MatchTestResult::deserialize(v).map_err(to_deser_error).map(TestExpectation::Match)
			} else if x.contains_key("value") {
				ValueTestResult::deserialize(v).map_err(to_deser_error).map(TestExpectation::Value)
			} else if x.contains_key("error") {
				ErrorTestResult::deserialize(v).map_err(to_deser_error).map(TestExpectation::Error)
			} else {
				Err(to_deser_error(
					"Table does not match any the options, expected table to contain at least one `match`, `value` or `error` field",
				))
			}
		} else {
			Err(to_deser_error("Expected a string or a table"))
		}
	}
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct ErrorTestResult {
	pub error: BoolOr<String>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct ValueTestResult {
	pub value: SurrealConfigValue,
	/// The trace the statement sends, for a test that asks for one; none when
	/// absent ([`crate::tests::trace`]).
	#[serde(default)]
	pub trace: Option<SurrealConfigValue>,
	#[serde(default)]
	pub skip_datetime: Option<bool>,
	#[serde(default)]
	pub skip_record_id_key: Option<bool>,
	#[serde(default)]
	pub skip_uuid: Option<bool>,
	#[serde(default)]
	pub skip_api_request_id: Option<bool>,
	#[serde(default)]
	pub float_roughly_eq: Option<bool>,
	#[serde(default)]
	pub decimal_roughly_eq: Option<bool>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct MatchTestResult {
	#[serde(rename = "match")]
	pub _match: SurrealExpr,
	#[serde(default)]
	pub error: Option<bool>,
	/// The trace the statement sends, for a test that asks for one; none when
	/// absent ([`crate::tests::trace`]).
	#[serde(default)]
	pub trace: Option<SurrealConfigValue>,
}

/// Duration which deserializes from both a string as well as a number.
#[derive(Clone, Copy, Debug, Default)]
pub struct TestDuration(pub Duration);

impl<'de> Deserialize<'de> for TestDuration {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: serde::Deserializer<'de>,
	{
		#[derive(Deserialize)]
		#[serde(untagged)]
		enum NumberOrString {
			String(String),
			Number(u64),
		}

		match NumberOrString::deserialize(deserializer)? {
			NumberOrString::Number(x) => Ok(Self(Duration::from_millis(x))),
			NumberOrString::String(x) => {
				let settings = ParserSettings {
					object_recursion_limit: 100,
					query_recursion_limit: 100,
					expr_recursion_limit: 100,
					legacy_strands: false,
					flexible_record_id: true,
					surrealism_enabled: true,
					json_string_escapes: false,
					import: false,
				};

				let v = surrealdb_core::syn::runtime::value_with_settings(&x, settings)
					.map_err(<D::Error as serde::de::Error>::custom)?;
				let Value::Duration(x) = v else {
					return Err(<D::Error as serde::de::Error>::custom("Invalid duration"));
				};
				Ok(Self(x.into_inner()))
			}
		}
	}
}

impl Serialize for TestDuration {
	fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
	where
		S: serde::Serializer,
	{
		format!("{:?}", self.0).serialize(serializer)
	}
}

/// A enum for when configuration which can be disabled, enabled or configured to have a specific
/// value.
///
/// # Example
/// ```toml
/// # Sets the timeout enabled to the default value
/// [env]
/// timeout = true
///
/// # Set the timeout as enabled with the value of 1000ms
/// [env]
/// timeout = 1000
/// ```
#[derive(Copy, Clone, Debug, Serialize)]
#[serde(untagged)]
pub enum BoolOr<T> {
	Bool(bool),
	Value(T),
}

impl<T> Default for BoolOr<T> {
	fn default() -> Self {
		BoolOr::Bool(true)
	}
}

impl<'d, T: Deserialize<'d>> Deserialize<'d> for BoolOr<T> {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: de::Deserializer<'d>,
	{
		let v = toml::Value::deserialize(deserializer)?;
		if v.is_bool() {
			bool::deserialize(v).map(BoolOr::Bool).map_err(to_deser_error)
		} else {
			T::deserialize(v).map(BoolOr::Value).map_err(to_deser_error)
		}
	}
}

impl<T> BoolOr<T> {
	pub fn as_ref(&self) -> BoolOr<&T> {
		match *self {
			BoolOr::Bool(x) => BoolOr::Bool(x),
			BoolOr::Value(ref x) => BoolOr::Value(x),
		}
	}

	pub fn map<R, F: FnOnce(T) -> R>(self, m: F) -> BoolOr<R> {
		match self {
			BoolOr::Bool(x) => BoolOr::Bool(x),
			BoolOr::Value(v) => BoolOr::Value(m(v)),
		}
	}

	/// Returns the value of this bool/or returning the default in case of BoolOr::Bool(true), the
	/// value in case of BoolOr::Value(_) or None in case of BoolOr::Bool(false)
	pub fn into_value(self, default: T) -> Option<T> {
		match self {
			BoolOr::Bool(false) => None,
			BoolOr::Bool(true) => Some(default),
			BoolOr::Value(x) => Some(x),
		}
	}
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct TestDetails {
	#[serde(default)]
	pub reason: Option<String>,
	#[serde(default = "t")]
	pub run: bool,
	#[serde(default)]
	pub issue: Option<u64>,
	#[serde(default)]
	pub wip: bool,

	/// Engine features the test cannot pass without. A run started with `--without <feature>`
	/// reports the test as skipped. See [`crate::tests::feature`].
	#[serde(default, skip_serializing_if = "Vec::is_empty")]
	pub requires: Vec<Feature>,

	#[serde(default)]
	pub upgrade: bool,

	/// Marks an upgrade test written for the RocksDB-to-SurrealKV migration
	/// axis (`upgrade --backend rocksdb-migration`), where the source binary
	/// writes a `rocksdb://` store and the target opens it as `surrealkv://`.
	/// Such a test runs on that axis only; every other axis skips it. With
	/// `[env] versioned = true` it runs only when the axis is versioned.
	#[serde(default)]
	pub migration: bool,

	/// The run modes this test is valid in. Absent means every mode; a present
	/// list restricts the file to the modes it names, so an empty list runs
	/// the file in none. See [`TestDetails::runs_in_mode`].
	#[serde(default)]
	pub modes: Option<Vec<RunMode>>,

	/// Marks a script written in the SurrealQL of the released binary that runs
	/// it, in a spelling the current parser no longer accepts.
	///
	/// Only an upgrade helper can be one: it is replayed against a spawned
	/// released binary and never against the current checkout, so the syntax it
	/// needs is that binary's, not this build's. The current parser's
	/// language-test corpus check reads this flag and leaves such a file alone,
	/// which is why it is a declared key rather than a comment.
	///
	/// A test body may not set it — the body executes on the upgrade target, so
	/// its syntax must be the one that build parses.
	#[serde(default)]
	pub legacy_syntax: bool,

	#[serde(default)]
	pub version: Option<VersionReq>,
	#[serde(default)]
	pub importing_version: Option<VersionRanges>,

	/// The release that introduced the feature under test — the earliest binary
	/// able to *create* the state the test asserts on.
	///
	/// Distinct from `importing-version`, which excludes a hop because a released
	/// binary is defective. Both bound the source side, so nothing but intent
	/// separates them, and that intent is what the filename prefix mirrors and
	/// the walk reads: a pairwise run skips hops whose source predates this, and
	/// a chain run uses it as the default `[test.chain] since`.
	#[serde(default)]
	pub introduced: Option<VersionReq>,

	/// Opts the test into the cumulative chain runner (`upgrade --chain`).
	#[serde(default)]
	pub chain: Option<TestChain>,

	/// Manual steps this upgrade is documented to require, in the sense of a
	/// release note's "after upgrading, run X". See [`TestRepair`].
	#[serde(default)]
	pub repair: Vec<TestRepair>,

	#[serde(default)]
	pub results: Option<TestDetailsResults>,

	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

impl Default for TestDetails {
	fn default() -> Self {
		Self {
			reason: Default::default(),
			run: true,
			issue: Default::default(),
			wip: false,
			requires: Default::default(),
			upgrade: Default::default(),
			migration: Default::default(),
			modes: Default::default(),
			legacy_syntax: Default::default(),
			version: Default::default(),
			importing_version: Default::default(),
			introduced: Default::default(),
			chain: Default::default(),
			repair: Default::default(),
			results: Default::default(),
			_unused_keys: Default::default(),
		}
	}
}

/// Cumulative-chain configuration for an upgrade test.
///
/// The chain runner walks one datastore through every version passed to
/// `--chain`, which CI populates from `LANG_UPGRADE_CHAIN` — a list that omits
/// any release demanding a manual repair, and so is deliberately not the same
/// as the adjacent-pair `LANG_UPGRADE_VERSIONS`. `setup` runs exactly once, on the first
/// version satisfying `since`; from that version onwards the test body is run
/// as the per-hop verification, so a feature introduced at 3.1.0 is created by
/// 3.1.0 and re-verified by 3.1.1, 3.1.2, ... and the current checkout, against
/// the data the earlier binaries left behind.
///
/// The body must be idempotent: it is executed once per remaining version and
/// graded against the same `[[test.results]]` every time. `mutate` is the place
/// for per-hop writes — it runs before the body on every version at or after
/// `setup`, which is what makes each release write *through* a structure an
/// older release created.
///
/// Matcher expressions in `[[test.results]]` may reference the chain position
/// through the `$hop`, `$hops`, `$version` and `$chain` parameters, so a body
/// whose result set grows with each `mutate` can still assert exactly.
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct TestChain {
	/// Version requirement the walked version must satisfy before this feature
	/// exists. `setup` runs on the first chain version that matches, and the
	/// test is skipped entirely when no version in the chain does.
	///
	/// Defaults to the test's `[test] introduced`, which is the same fact stated
	/// once; set it only to override the walk independently of that.
	#[serde(default)]
	pub since: Option<VersionReq>,
	/// Test-root-relative path of the script that creates the feature. Resolved
	/// exactly like an `[env] imports` entry, transitive imports included.
	pub setup: String,
	/// Test-root-relative path of a script run on every version at or after
	/// `setup`, before the body. Its statements' results are not graded; a
	/// statement that errors fails the hop.
	#[serde(default)]
	pub mutate: Option<String>,
	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

/// A manual step an upgrade is documented to require — the SurrealQL equivalent
/// of a release note's "after upgrading, run `REBUILD INDEX ...`".
///
/// The runner brackets the declaration rather than trusting it. The body is run
/// once before the repair, and its outcome must equal `unrepaired`; the repair
/// script then runs, and the body is run again and graded normally. Both
/// directions are therefore falsifiable: a requirement nobody declared fails
/// because the first run was supposed to succeed, and a declaration that has
/// stopped reproducing fails because the pre-repair run no longer reports the
/// damage it claims.
///
/// Without this, a repair statement written straight into a test body is
/// indistinguishable from a silent breakage that someone patched until the
/// suite went green.
///
/// Because the body runs twice against the same store, it must be idempotent:
/// a `CREATE` that succeeds on the first pass fails as "already exists" on the
/// second. Writes in a bracketed body belong in an `UPSERT`.
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct TestRepair {
	/// First upgrade *target* requiring the step. Matched as `>= since`, so a
	/// declaration for `3.3.0` also covers `3.3.0-beta.3`.
	pub since: VersionReq,
	/// Test-root-relative path of the script performing the repair.
	pub script: String,
	/// What the body does before the repair has run.
	pub unrepaired: Unrepaired,
	/// Why an operator has to do this. A step with no stated reason cannot be
	/// told apart from a bug someone worked around.
	pub reason: String,
	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

/// Observed behaviour of a test body before its declared repair has run.
#[derive(Copy, Clone, Debug, Eq, PartialEq, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum Unrepaired {
	/// A statement errors in a way the expectations do not allow.
	Broken,
	/// Every statement completes but at least one result differs.
	Degraded,
}

impl TestDetails {
	/// Whether the test is valid in `mode`: always when `modes` is absent,
	/// otherwise only when the list names it.
	pub fn runs_in_mode(&self, mode: RunMode) -> bool {
		self.modes.as_ref().is_none_or(|modes| modes.contains(&mode))
	}

	pub fn unused_keys(&self) -> Vec<String> {
		let mut res: Vec<_> = self._unused_keys.keys().map(|x| format!("test.{x}")).collect();

		if let Some(chain) = self.chain.as_ref() {
			res.extend(chain._unused_keys.keys().map(|x| format!("test.chain.{x}")));
		}
		for (i, repair) in self.repair.iter().enumerate() {
			res.extend(repair._unused_keys.keys().map(|x| format!("test.repair[{i}].{x}")));
		}

		if let Some(results) = self.results.as_ref() {
			match results {
				TestDetailsResults::QueryResult(_) => {}
				TestDetailsResults::ParserError(x) => res.append(
					&mut x._unused_keys.keys().map(|x| format!("test.results.{x}")).collect(),
				),
				TestDetailsResults::SignupError(x) => res.append(
					&mut x._unused_keys.keys().map(|x| format!("test.results.{x}")).collect(),
				),
				TestDetailsResults::SigninError(x) => res.append(
					&mut x._unused_keys.keys().map(|x| format!("test.results.{x}")).collect(),
				),
				TestDetailsResults::RequestError(x) => res.append(
					&mut x._unused_keys.keys().map(|x| format!("test.results.{x}")).collect(),
				),
			}
		}
		res
	}
}

/// One or more version requirements, any of which admits a version.
///
/// Written as a single requirement string, or as an array of them when the
/// versions to admit are not one contiguous range. Release order is not version
/// order: a patch on an older line can ship after a newer line and carry a fix
/// the newer line's early releases lack, so the releases still carrying a
/// defect can sit on both sides of those that fixed it. Comparators within one
/// requirement are ANDed, as semver defines; the requirements are ORed.
#[derive(Clone, Debug, Serialize)]
#[serde(untagged)]
pub enum VersionRanges {
	One(VersionReq),
	Any(Vec<VersionReq>),
}

impl VersionRanges {
	fn requirements(&self) -> &[VersionReq] {
		match self {
			VersionRanges::One(req) => std::slice::from_ref(req),
			VersionRanges::Any(reqs) => reqs,
		}
	}

	/// Whether any requirement admits `version` under strict semver matching.
	pub fn matches(&self, version: &semver::Version) -> bool {
		self.requirements().iter().any(|req| req.matches(version))
	}

	/// Whether any requirement admits `version` under
	/// [`crate::version::version_matches`], which lets a prerelease satisfy a
	/// requirement that does not name its own release.
	#[cfg(any(feature = "upgrade", test))]
	pub fn version_matches(&self, version: &semver::Version) -> bool {
		self.requirements().iter().any(|req| crate::version::version_matches(req, version))
	}
}

impl<'de> Deserialize<'de> for VersionRanges {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: de::Deserializer<'de>,
	{
		let value = toml::Value::deserialize(deserializer)?;
		if value.is_array() {
			let reqs: Vec<VersionReq> = Deserialize::deserialize(value).map_err(to_deser_error)?;
			if reqs.is_empty() {
				// An empty list would admit no version at all, which silently
				// removes the test from every run.
				return Err(to_deser_error("expected at least one version requirement"));
			}
			Ok(VersionRanges::Any(reqs))
		} else {
			Deserialize::deserialize(value).map_err(to_deser_error).map(VersionRanges::One)
		}
	}
}

#[derive(Clone, Debug, Serialize)]
#[serde(untagged)]
#[serde(rename_all = "kebab-case")]
pub enum TestDetailsResults {
	QueryResult(Vec<TestExpectation>),
	ParserError(ParsingTestResult),
	SigninError(SigninErrorResult),
	SignupError(SignupErrorResult),
	/// The whole request was refused: the `dbs.process` call itself returned an error, so no
	/// statement produced a result.
	RequestError(RequestErrorResult),
}

impl<'de> Deserialize<'de> for TestDetailsResults {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: de::Deserializer<'de>,
	{
		let value = toml::Value::deserialize(deserializer)?;
		if value.is_array() {
			Deserialize::deserialize(value)
				.map_err(to_deser_error)
				.map(TestDetailsResults::QueryResult)
		} else if let Some(t) = value.as_table() {
			if t.contains_key("signin-error") {
				Deserialize::deserialize(value)
					.map_err(to_deser_error)
					.map(TestDetailsResults::SigninError)
			} else if t.contains_key("signup-error") {
				Deserialize::deserialize(value)
					.map_err(to_deser_error)
					.map(TestDetailsResults::SignupError)
			} else if t.contains_key("request-error") {
				Deserialize::deserialize(value)
					.map_err(to_deser_error)
					.map(TestDetailsResults::RequestError)
			} else {
				Deserialize::deserialize(value)
					.map_err(to_deser_error)
					.map(TestDetailsResults::ParserError)
			}
		} else {
			Err(to_deser_error("Expected table or array"))
		}
	}
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct ParsingTestResult {
	pub parsing_error: BoolOr<String>,
	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct SigninErrorResult {
	pub signin_error: BoolOr<String>,
	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct SignupErrorResult {
	pub signup_error: BoolOr<String>,
	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct RequestErrorResult {
	pub request_error: BoolOr<String>,
	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

/// A wrapper around the `Value` type for SurrealDB in order to support parsing from toml.
#[derive(Clone, Debug)]
pub struct SurrealConfigValue(pub Value);

impl Serialize for SurrealConfigValue {
	fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
	where
		S: serde::Serializer,
	{
		let v = self.0.to_sql();
		v.serialize(serializer)
	}
}

impl<'de> Deserialize<'de> for SurrealConfigValue {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: serde::Deserializer<'de>,
	{
		let source = String::deserialize(deserializer)?;
		let settings = ParserSettings {
			object_recursion_limit: 100,
			query_recursion_limit: 100,
			expr_recursion_limit: 100,
			legacy_strands: false,
			flexible_record_id: true,
			surrealism_enabled: true,
			json_string_escapes: false,
			import: false,
		};

		let v = surrealdb_core::syn::runtime::value_with_settings(&source, settings)
			.map_err(<D::Error as serde::de::Error>::custom)?;

		Ok(SurrealConfigValue(v))
	}
}

#[derive(Clone, Debug)]
pub struct SurrealExpr(pub String);

impl Serialize for SurrealExpr {
	fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
	where
		S: serde::Serializer,
	{
		self.0.serialize(serializer)
	}
}

impl<'de> Deserialize<'de> for SurrealExpr {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: serde::Deserializer<'de>,
	{
		let source = String::deserialize(deserializer)?;
		// We can't validate the expression anymore since parse_expr_start is private
		// and parse_value doesn't handle variables like $error
		// We'll rely on runtime validation when the expression is executed
		Ok(SurrealExpr(source))
	}
}

#[derive(Clone, Debug)]
pub struct SurrealRecordId(pub RecordId);

impl Serialize for SurrealRecordId {
	fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
	where
		S: serde::Serializer,
	{
		let v = self.0.to_sql();
		v.serialize(serializer)
	}
}

impl<'de> Deserialize<'de> for SurrealRecordId {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: serde::Deserializer<'de>,
	{
		let source = String::deserialize(deserializer)?;
		let settings = ParserSettings {
			object_recursion_limit: 100,
			query_recursion_limit: 100,
			expr_recursion_limit: 100,
			legacy_strands: false,
			flexible_record_id: true,
			surrealism_enabled: true,
			json_string_escapes: false,
			import: false,
		};

		let v = surrealdb_core::syn::runtime::value_with_settings(&source, settings)
			.map_err(<D::Error as serde::de::Error>::custom)?;
		if let Value::RecordId(x) = v {
			Ok(SurrealRecordId(x))
		} else {
			Err(<D::Error as serde::de::Error>::custom(format_args!(
				"Expected a record-id, found '{source}'"
			)))
		}
	}
}

#[derive(Clone, Debug)]
pub struct SurrealObject(pub Object);

impl Serialize for SurrealObject {
	fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
	where
		S: serde::Serializer,
	{
		let v = self.0.to_sql();
		v.serialize(serializer)
	}
}

impl<'de> Deserialize<'de> for SurrealObject {
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: serde::Deserializer<'de>,
	{
		let source = String::deserialize(deserializer)?;
		let settings = ParserSettings {
			object_recursion_limit: 100,
			query_recursion_limit: 100,
			expr_recursion_limit: 100,
			legacy_strands: false,
			flexible_record_id: true,
			surrealism_enabled: true,
			json_string_escapes: false,
			import: false,
		};

		let v = surrealdb_core::syn::runtime::value_with_settings(&source, settings)
			.map_err(<D::Error as serde::de::Error>::custom)?;

		v.into_object().map(SurrealObject).map_err(|err| {
			<D::Error as serde::de::Error>::custom(format_args!(
				"Expected a object, found '{source}': {err}"
			))
		})
	}
}

#[derive(Clone, Debug, Serialize, Deserialize, Default)]
#[serde(rename_all = "kebab-case")]
pub enum AuthLevel {
	#[default]
	Owner,
	Editor,
	Viewer,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case", untagged)]
pub enum TestAuth {
	Record {
		namespace: String,
		database: String,
		access: String,
		rid: SurrealRecordId,
	},
	Database {
		namespace: String,
		database: String,
		#[serde(default)]
		level: AuthLevel,
	},
	Namespace {
		namespace: String,
		#[serde(default)]
		level: AuthLevel,
	},
	Root {
		level: AuthLevel,
	},
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(rename_all = "kebab-case")]
pub struct Capabilities {
	#[serde(default = "t")]
	pub scripting: bool,
	#[serde(default = "t")]
	pub quest_access: bool,
	#[serde(default = "t")]
	pub live_query_notifications: bool,

	#[serde(default)]
	pub allow_functions: BoolOr<Vec<SchemaTarget<FuncTarget>>>,
	#[serde(default = "bool_or_f")]
	pub deny_functions: BoolOr<Vec<SchemaTarget<FuncTarget>>>,

	#[serde(default)]
	pub allow_net: BoolOr<Vec<SchemaTarget<NetTarget>>>,
	#[serde(default = "bool_or_f")]
	pub deny_net: BoolOr<Vec<SchemaTarget<NetTarget>>>,

	#[serde(default)]
	pub allow_rpc: BoolOr<Vec<SchemaTarget<MethodTarget>>>,
	#[serde(default = "bool_or_f")]
	pub deny_rpc: BoolOr<Vec<SchemaTarget<MethodTarget>>>,

	#[serde(default)]
	pub allow_http: BoolOr<Vec<SchemaTarget<RouteTarget>>>,
	#[serde(default = "bool_or_f")]
	pub deny_http: BoolOr<Vec<SchemaTarget<RouteTarget>>>,

	#[serde(default)]
	pub allow_experimental: BoolOr<Vec<SchemaTarget<ExperimentalTarget>>>,
	#[serde(default = "bool_or_f")]
	pub deny_experimental: BoolOr<Vec<SchemaTarget<ExperimentalTarget>>>,

	#[serde(default)]
	pub allow_arbitrary_query: BoolOr<Vec<SchemaTarget<ArbitraryQueryTarget>>>,
	#[serde(default = "bool_or_f")]
	pub deny_arbitrary_query: BoolOr<Vec<SchemaTarget<ArbitraryQueryTarget>>>,

	#[serde(default = "bool_or_f")]
	pub allow_eval_query: BoolOr<Vec<SchemaTarget<EvalQueryTarget>>>,
	#[serde(default = "bool_or_f")]
	pub deny_eval_query: BoolOr<Vec<SchemaTarget<EvalQueryTarget>>>,

	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

impl Default for Capabilities {
	fn default() -> Self {
		Self {
			scripting: true,
			quest_access: true,
			live_query_notifications: true,

			allow_functions: Default::default(),
			deny_functions: BoolOr::Bool(false),

			allow_net: Default::default(),
			deny_net: BoolOr::Bool(false),
			allow_rpc: Default::default(),
			deny_rpc: BoolOr::Bool(false),
			allow_http: Default::default(),
			deny_http: BoolOr::Bool(false),
			allow_experimental: Default::default(),
			deny_experimental: BoolOr::Bool(false),
			allow_arbitrary_query: BoolOr::Bool(true),
			deny_arbitrary_query: BoolOr::Bool(false),
			allow_eval_query: BoolOr::Bool(false),
			deny_eval_query: BoolOr::Bool(false),
			_unused_keys: Default::default(),
		}
	}
}

#[derive(Clone, Debug)]
pub struct SchemaTarget<T>(pub T);

impl<'de, T: FromStr> Deserialize<'de> for SchemaTarget<T>
where
	T: FromStr,
	<T as FromStr>::Err: fmt::Display,
{
	fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
	where
		D: serde::Deserializer<'de>,
	{
		let v = String::deserialize(deserializer)?;
		v.parse().map(SchemaTarget).map_err(<D::Error as serde::de::Error>::custom)
	}
}

impl<T: fmt::Display> Serialize for SchemaTarget<T> {
	fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
	where
		S: serde::Serializer,
	{
		self.0.to_string().serialize(serializer)
	}
}

impl Capabilities {
	pub fn unused_keys(&self) -> Vec<String> {
		self._unused_keys.keys().map(|x| format!("env.capabilities.{x}")).collect()
	}
}

#[derive(Clone, Debug, Deserialize, Serialize, Default)]
#[serde(rename_all = "kebab-case")]
pub struct BenchDetails {
	/// Whether to include this file in the benchmark suite (`bench run`). The
	/// bench equivalent of `[test].run`; set to `false` for files that exist
	/// only to be imported by other benches. Defaults to `true`.
	#[serde(default = "t")]
	pub run: bool,
	/// Whether to rebuild the datastore (and rerun imports) before every
	/// measured iteration.
	///
	/// Defaults to `false`, which builds the datastore and runs imports once
	/// before the warmup/measurement loops, so a read-only bench measures only
	/// the timed statement against a stable, pre-populated dataset. Set to
	/// `true` for mutating benches (CREATE/UPDATE/DELETE) which require a clean
	/// slate per iteration.
	#[serde(default)]
	pub rebuild: bool,
	/// Lets a `rebuild = true` bench also run on the file-backed engines
	/// (`--backend surrealkv`), not just on `mem`.
	///
	/// Rebuilding re-imports the dataset before every measured iteration, and on
	/// a file backend that writes the whole dataset to disk each time — so
	/// expensive for most mutating benches that the file backends skip them.
	/// A bench whose subject is the storage layer itself measures the wrong thing
	/// on `mem` and opts in here; each iteration then builds a fresh datastore
	/// in a directory of its own, and shuts it down and reclaims the directory
	/// once its statement has been timed, so the run holds one dataset on disk
	/// rather than one per sample.
	#[serde(default)]
	pub rebuild_file_backend: bool,
	/// Whether `bench run --quick` includes this bench. Defaults to `true`.
	///
	/// Quick mode caps a bench's measurement at `QUICK_MAX_TIME` (in
	/// `cmd/bench/run.rs`) and needs two samples for statistics, so a bench
	/// whose single iteration, re-import included, takes longer can only ever
	/// be reported as skipped there, after paying for a warmup and a sample.
	/// Set `false` on such a bench so quick runs skip it up front, by name;
	/// full runs are unaffected.
	#[serde(default = "t")]
	pub quick: bool,
	/// Folds the imported graph adjacency into packed blocks before the warmup,
	/// so the timed statement reads the folded layout. The datastore is built
	/// with `graph_fold_threshold = 1`, the bench statement is executed once as
	/// a priming pass — the fold queue is observation-driven, so exactly the
	/// scopes the statement traverses are folded — and the fold queue is then
	/// drained by the same routine the background task runs. Requires
	/// `rebuild = false` (the priming pass would execute a mutating statement
	/// an extra, unmeasured time) and a SurrealQL bench statement.
	#[serde(default)]
	pub graph_fold: bool,
	/// Encodes folded block entries as numeric doc-ids instead of record keys
	/// (`graph_numeric_ids = true`). Implies the same fold pass as
	/// `graph-fold`, under the same constraints.
	#[serde(default)]
	pub graph_numeric_ids: bool,
	/// Run this bench once per named dataset, each resolved (transitively) as the
	/// bench's import for that run. Lets a single read-only scan be measured
	/// against multiple datasets — e.g. one without indexes and one with — from a
	/// single file. The key is a short variant name (shown in the run label and
	/// selectable with `--dataset <name>`); the value is the import path. When
	/// empty (default) the bench runs once using `[env].imports`.
	///
	/// ```toml
	/// datasets = { unindexed = "../_dataset.surql", indexed = "../_dataset_indexed.surql" }
	/// ```
	#[serde(default)]
	pub datasets: BTreeMap<String, String>,
	/// How long to warm up before measuring — the statement is run in a loop for
	/// this duration to stabilise caches before timing begins. Defaults to 3s.
	#[serde(default = "default_duration::<3000>")]
	pub warmup: TestDuration,
	/// Number of timed samples to collect; the reported mean / median / std-dev /
	/// MAD are computed over these. Defaults to 100.
	#[serde(default = "default_usize::<100>")]
	pub sample_size: usize,
	/// Target total time to spend collecting the samples. The harness sizes the
	/// per-sample iteration count from the warmup estimate so the measurement run
	/// takes roughly this long. Defaults to 100s.
	#[serde(default = "default_duration::<100000>")]
	pub measurement_time: TestDuration,
	/// Hard wall-clock backstop on the sample-collection loop. `measurement_time`
	/// only sizes the iteration count from the warmup estimate; it does not cap
	/// the loop, so a mis-scoped bench whose per-iteration cost dwarfs the warmup
	/// estimate (e.g. an O(n²) query) collects all `sample_size` samples no matter
	/// how long that takes. This caps the collection so no single bench can consume
	/// the whole run: the harness always keeps at least one sample, then stops once
	/// cumulative measured time exceeds this. Defaults to 600s.
	#[serde(default = "default_duration::<600000>")]
	pub max_time: TestDuration,

	#[serde(skip_serializing)]
	#[serde(flatten)]
	_unused_keys: BTreeMap<String, toml::Value>,
}

#[cfg(test)]
mod request_error_tests {
	use super::*;

	#[test]
	fn request_error_table_is_not_sent_to_parser_error() {
		let cfg: TestConfig =
			toml::from_str("[test.results]\nrequest-error = \"refused\"").expect("parses");
		match cfg.test.results {
			Some(TestDetailsResults::RequestError(x)) => {
				assert!(matches!(x.request_error, BoolOr::Value(ref t) if t == "refused"));
			}
			other => panic!("expected RequestError, got {other:?}"),
		}
	}

	#[test]
	fn unrecognised_table_still_parses_as_parser_error() {
		let result = toml::from_str::<TestConfig>("[test.results]\nparsing-error = true");
		assert!(matches!(result.unwrap().test.results, Some(TestDetailsResults::ParserError(_))));
	}

	#[test]
	fn unknown_keys_beside_request_error_are_reported() {
		let cfg: TestConfig =
			toml::from_str("[test.results]\nrequest-error = true\nextra = 1").expect("parses");
		assert_eq!(cfg.unused_keys(), vec!["test.results.extra".to_owned()]);
	}
}

#[cfg(test)]
mod bench_quick_tests {
	use super::*;

	#[test]
	fn a_bench_runs_in_quick_mode_unless_it_opts_out() {
		// The default is load-bearing: were it `false`, every bench would drop
		// out of `--quick` and the PR workflow would compare nothing, green.
		let config = toml::from_str::<TestConfig>("[bench]\nrun = true").expect("parses");
		assert!(config.bench.quick);
		let config = toml::from_str::<TestConfig>("[bench]\nquick = false").expect("parses");
		assert!(!config.bench.quick);
		assert!(config.unused_keys().is_empty(), "{:?}", config.unused_keys());
	}
}

#[cfg(test)]
mod modes_tests {
	use super::*;

	fn details(toml: &str) -> TestDetails {
		toml::from_str::<TestConfig>(toml).expect("parses").test
	}

	#[test]
	fn absent_modes_run_in_both_modes() {
		let d = details("[test]\nrun = true");
		assert!(d.modes.is_none());
		assert!(d.runs_in_mode(RunMode::Request));
		assert!(d.runs_in_mode(RunMode::Fragments));
	}

	#[test]
	fn modes_parse_and_restrict_the_file() {
		let d = details("[test]\nmodes = [\"request\"]");
		assert_eq!(d.modes, Some(vec![RunMode::Request]));
		assert!(d.runs_in_mode(RunMode::Request));
		assert!(!d.runs_in_mode(RunMode::Fragments));

		let d = details("[test]\nmodes = [\"fragments\"]");
		assert!(!d.runs_in_mode(RunMode::Request));
		assert!(d.runs_in_mode(RunMode::Fragments));
	}

	#[test]
	fn both_modes_listed_run_in_both() {
		let d = details("[test]\nmodes = [\"request\", \"fragments\"]");
		assert!(d.runs_in_mode(RunMode::Request));
		assert!(d.runs_in_mode(RunMode::Fragments));
	}

	#[test]
	fn an_empty_list_runs_in_no_mode() {
		let d = details("[test]\nmodes = []");
		assert!(!d.runs_in_mode(RunMode::Request));
		assert!(!d.runs_in_mode(RunMode::Fragments));
	}

	#[test]
	fn an_unknown_mode_is_rejected() {
		assert!(toml::from_str::<TestConfig>("[test]\nmodes = [\"streaming\"]").is_err());
	}

	#[test]
	fn modes_is_a_declared_key_not_an_unused_one() {
		let d = details("[test]\nmodes = [\"request\"]");
		assert!(d.unused_keys().is_empty());
	}
}

#[cfg(test)]
mod version_ranges_tests {
	use semver::Version;

	use super::*;

	fn importing(toml: &str) -> Option<VersionRanges> {
		toml::from_str::<TestConfig>(toml).expect("parses").test.importing_version
	}

	fn v(s: &str) -> Version {
		Version::parse(s).unwrap()
	}

	#[test]
	fn a_single_string_is_one_range() {
		let r = importing("[test]\nimporting-version = \">=3.0.1\"").unwrap();
		assert!(matches!(r, VersionRanges::One(_)));
		assert!(!r.version_matches(&v("3.0.0")));
		assert!(r.version_matches(&v("3.3.0-beta.3")));
	}

	#[test]
	fn an_array_admits_a_version_any_range_admits() {
		// A defect fixed on 3.2 in 3.2.5 and on 3.3 before 3.3.0 leaves the
		// damaged writers on both sides of the fixed 3.2 patches.
		let r = importing(
			"[test]\nimporting-version = [\"<3.2.5\", \">=3.3.0-beta.1, <3.3.0-beta.5\"]",
		)
		.unwrap();
		for damaged in ["3.1.0", "3.2.4", "3.3.0-beta.3"] {
			assert!(r.version_matches(&v(damaged)), "{damaged} should be admitted");
		}
		for fixed in ["3.2.5", "3.2.6", "3.3.0", "3.3.4", "3.4.0-nightly"] {
			assert!(!r.version_matches(&v(fixed)), "{fixed} should be excluded");
		}
	}

	#[test]
	fn an_empty_array_is_refused() {
		assert!(toml::from_str::<TestConfig>("[test]\nimporting-version = []").is_err());
	}
}
