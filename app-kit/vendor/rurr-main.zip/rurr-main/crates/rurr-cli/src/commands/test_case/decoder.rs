use crate::TestCaseCreateArgs;
use indexmap::IndexMap;
use rurr_core::State;
use serde_json::Value;
use std::io::{self, Write};
use std::path::Path;
use std::process::{Command, Stdio};

pub(super) enum TrackedStateDecoder<'a> {
    InProcess,
    ExternalCommand { path: &'a Path, args: &'a [String] },
}

impl<'a> TrackedStateDecoder<'a> {
    pub(super) fn from_args(args: &'a TestCaseCreateArgs) -> Self {
        match args.serde_decoder.as_deref() {
            Some(path) => Self::ExternalCommand {
                path,
                args: &args.serde_decoder_arg,
            },
            None => Self::InProcess,
        }
    }

    pub(super) fn decode(
        &self,
        values: IndexMap<String, Value>,
    ) -> io::Result<IndexMap<String, Value>> {
        match self {
            Self::InProcess => decode_tracked_state_in_process(values),
            Self::ExternalCommand { path, args } => {
                decode_tracked_state_with_external_command(path, args, values)
            }
        }
    }
}

fn decode_tracked_state_in_process(
    values: IndexMap<String, Value>,
) -> io::Result<IndexMap<String, Value>> {
    State::decode_serialized_values(values)
        .map_err(|error| io::Error::new(io::ErrorKind::InvalidData, error))
}

fn decode_tracked_state_with_external_command(
    path: &Path,
    args: &[String],
    values: IndexMap<String, Value>,
) -> io::Result<IndexMap<String, Value>> {
    let stdin_payload = serde_json::to_vec(&values).map_err(|error| {
        io::Error::other(format!(
            "serialize tracked state for serde decoder {}: {error}",
            path.display()
        ))
    })?;

    let mut child = Command::new(path)
        .args(args)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|error| {
            io::Error::new(
                error.kind(),
                format!("spawn serde decoder {}: {error}", path.display()),
            )
        })?;

    {
        let stdin = child.stdin.as_mut().ok_or_else(|| {
            io::Error::other(format!(
                "serde decoder {} did not provide stdin",
                path.display()
            ))
        })?;
        stdin.write_all(&stdin_payload).map_err(|error| {
            io::Error::new(
                error.kind(),
                format!(
                    "write tracked state to serde decoder {}: {error}",
                    path.display()
                ),
            )
        })?;
    }

    let output = child.wait_with_output().map_err(|error| {
        io::Error::new(
            error.kind(),
            format!("wait for serde decoder {}: {error}", path.display()),
        )
    })?;

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "serde decoder {} exited with status {}: {}",
                path.display(),
                output.status,
                stderr.trim()
            ),
        ));
    }

    let stdout_value: Value = serde_json::from_slice(&output.stdout).map_err(|error| {
        io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "serde decoder {} returned invalid JSON: {error}",
                path.display()
            ),
        )
    })?;
    if !stdout_value.is_object() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("serde decoder {} must return a JSON object", path.display()),
        ));
    }

    serde_json::from_value(stdout_value).map_err(|error| {
        io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "serde decoder {} returned an invalid decoded state object: {error}",
                path.display()
            ),
        )
    })
}
