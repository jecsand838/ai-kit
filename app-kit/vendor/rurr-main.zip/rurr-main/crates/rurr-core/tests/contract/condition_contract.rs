use indexmap::IndexMap;
use rurr_core::action::{Condition, ConditionError, ConditionOperator, ConditionRule};
use rurr_core::{ApplicationBuilder, FunctionActionBuilder, Transition};
use serde_json::{json, Value};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;

use super::support::pairs::state_from_pairs;

#[test]
fn new_condition_uses_explicit_name_reads_and_predicate() {
    let condition = Condition::new(
        ["foo"],
        |state| state.get("foo") == Some(&json!("bar")),
        "foo_check",
    );

    assert_eq!(condition.name(), "foo_check");
    assert_eq!(condition.reads(), &["foo".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([("foo", json!("bar"))]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([("foo", json!("baz"))]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn default_condition_is_always_true() {
    let condition = Condition::default();
    let state = state_from_pairs([("foo", json!("bar"))]);

    assert_eq!(condition.name(), "default");
    assert!(condition.reads().is_empty());
    assert!(condition.evaluate(&state).expect("default should evaluate"));
    assert_eq!(
        condition.run(&state).expect("default run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}

#[test]
fn when_condition_uses_burr_style_equality_rules() {
    let condition = Condition::when([("foo", json!("bar"))]);

    assert_eq!(condition.name(), "foo=bar");
    assert_eq!(condition.reads(), &["foo".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([("foo", json!("bar"))]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([("foo", json!("baz"))]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn when_condition_uses_python_like_nested_equality() {
    let condition = Condition::when([(
        "payload",
        json!([1, {"nested": [true, 0]}, {"flag": false}]),
    )]);

    assert_eq!(condition.reads(), &["payload".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([(
                "payload",
                json!([true, {"nested": [1, false]}, {"flag": 0}])
            )]))
            .expect("nested equality condition should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([(
                "payload",
                json!([true, {"nested": [1, false]}, {"flag": true}])
            )]))
            .expect("nested equality condition should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn when_condition_ands_multiple_rules_and_sorts_names_by_key() {
    let condition = Condition::when([("foo", json!("bar")), ("baz", json!("qux"))]);

    assert_eq!(condition.name(), "baz=qux, foo=bar");
    assert_eq!(condition.reads(), &["foo".to_string(), "baz".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("bar")),
                ("baz", json!("qux"))
            ]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("bar")),
                ("baz", json!("nope"))
            ]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn when_condition_supports_burr_operator_rules() {
    let cases = [
        (ConditionRule::eq("age", json!(18)), json!(18), true),
        (ConditionRule::ne("age", json!(0)), json!(5), true),
        (ConditionRule::gt("age", json!(18)), json!(19), true),
        (ConditionRule::gte("age", json!(18)), json!(18), true),
        (ConditionRule::lt("age", json!(18)), json!(17), true),
        (ConditionRule::lte("age", json!(18)), json!(18), true),
        (
            ConditionRule::in_("status", json!(["active", "pending"])),
            json!("active"),
            true,
        ),
        (
            ConditionRule::not_in("status", json!(["banned", "suspended"])),
            json!("active"),
            true,
        ),
        (
            ConditionRule::contains("tags", json!("python")),
            json!(["python", "java"]),
            true,
        ),
        (
            ConditionRule::contains("text", json!("hello")),
            json!("say hello"),
            true,
        ),
        (ConditionRule::is("value", Value::Null), Value::Null, true),
        (
            ConditionRule::is_not("value", Value::Null),
            json!("hello"),
            true,
        ),
    ];

    for (rule, state_value, expected) in cases {
        let key = rule.key().to_string();
        let condition = Condition::when([rule]);
        assert_eq!(
            condition
                .run(&state_from_pairs([(key.as_str(), state_value)]))
                .expect("operator condition should run"),
            IndexMap::from([(Condition::KEY.to_string(), json!(expected))])
        );
    }
}

#[test]
fn when_condition_names_operator_rules_like_burr() {
    let cases = [
        (ConditionRule::eq("foo", json!("bar")), "foo=bar"),
        (ConditionRule::gte("age", json!(18)), "age>=18"),
        (ConditionRule::lt("age", json!(5)), "age<5"),
        (ConditionRule::ne("age", json!(0)), "age!=0"),
        (
            ConditionRule::in_("status", json!(["a", "b"])),
            "status in ['a', 'b']",
        ),
        (
            ConditionRule::not_in("status", json!(["x"])),
            "status not in ['x']",
        ),
        (
            ConditionRule::contains("tags", json!("py")),
            "tags contains 'py'",
        ),
        (ConditionRule::is("value", Value::Null), "value is None"),
        (
            ConditionRule::is_not("value", Value::Null),
            "value is not None",
        ),
    ];

    for (rule, expected_name) in cases {
        assert_eq!(Condition::when([rule]).name(), expected_name);
    }
}

#[test]
fn when_condition_deduplicates_reads_for_same_key_operator_rules() {
    let condition = Condition::when([
        ConditionRule::gte("age", json!(18)),
        ConditionRule::lt("age", json!(65)),
    ]);

    assert_eq!(condition.name(), "age>=18, age<65");
    assert_eq!(condition.reads(), &["age".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([("age", json!(30))]))
            .expect("same-key rules should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}

#[test]
fn when_condition_reports_typed_operator_errors() {
    let condition = Condition::when([ConditionRule::gt("age", json!(18))]);
    let error = condition
        .evaluate(&state_from_pairs([("age", json!({"years": 19}))]))
        .expect_err("invalid comparison should fail");

    match error {
        ConditionError::When {
            condition_name,
            key,
            operator,
            source,
        } => {
            assert_eq!(condition_name, "age>18");
            assert_eq!(key, "age");
            assert_eq!(operator, ConditionOperator::Gt);
            assert!(source.to_string().contains("cannot compare values"));
        }
        other => panic!("expected When error, got {other:?}"),
    }
}

#[test]
fn when_operator_rules_work_with_invert_and_or_and_and() {
    let inverted = !Condition::when([ConditionRule::gte("age", json!(18))]);
    assert_eq!(
        inverted
            .run(&state_from_pairs([("age", json!(17))]))
            .expect("inverted condition should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );

    let or_condition = Condition::when([ConditionRule::lt("age", json!(13))])
        | Condition::when([ConditionRule::gte("age", json!(65))]);
    assert_eq!(
        or_condition
            .run(&state_from_pairs([("age", json!(70))]))
            .expect("or condition should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );

    let and_condition = Condition::when([ConditionRule::gte("age", json!(18))])
        & Condition::when([ConditionRule::lt("age", json!(65))]);
    assert_eq!(
        and_condition
            .run(&state_from_pairs([("age", json!(30))]))
            .expect("and condition should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}

#[test]
fn ordered_transition_selection_uses_when_operator_rules() {
    let passthrough = FunctionActionBuilder::new()
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("passthrough action should build");
    let adult = FunctionActionBuilder::new()
        .writes(["route"])
        .build_sync(|_state, _ctx| IndexMap::from([("route".to_string(), json!("adult"))]))
        .expect("adult action should build");
    let fallback = FunctionActionBuilder::new()
        .writes(["route"])
        .build_sync(|_state, _ctx| IndexMap::from([("route".to_string(), json!("fallback"))]))
        .expect("fallback action should build");

    let mut app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("age", json!(20))]))
        .expect("state should configure")
        .with_actions(vec![
            ("check", passthrough),
            ("adult", adult),
            ("fallback", fallback),
        ])
        .expect("actions should configure")
        .with_transitions(vec![
            Transition::new(
                "check",
                "adult",
                Condition::when([ConditionRule::gte("age", json!(18))]),
            ),
            Transition::new("check", "fallback", Condition::default()),
        ])
        .expect("transitions should configure")
        .with_entrypoint("check")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");

    let output = app.run().expect("run should succeed");
    assert_eq!(output.state.get("route"), Some(&json!("adult")));
}

#[test]
fn validate_succeeds_when_required_keys_are_present() {
    let condition = Condition::when([("foo", json!("bar"))]);
    let state = state_from_pairs([("foo", json!("bar"))]);

    condition
        .validate(&state)
        .expect("validation should succeed with all required keys");
}

#[test]
fn validate_fails_when_required_keys_are_missing() {
    let condition = Condition::when([("foo", json!("bar")), ("bar", json!("baz"))]);
    let state = state_from_pairs([("baz", json!("qux"))]);

    let error = condition
        .validate(&state)
        .expect_err("validation should fail when required keys are missing");

    match error {
        ConditionError::MissingRequiredKeys {
            condition_name,
            missing_keys,
            available_keys,
        } => {
            assert_eq!(condition_name, "bar=baz, foo=bar");
            assert_eq!(missing_keys, vec!["foo".to_string(), "bar".to_string()]);
            assert_eq!(available_keys, vec!["baz".to_string()]);
        }
        other => panic!("expected MissingRequiredKeys error, got {other:?}"),
    }
}

#[test]
fn run_fails_with_missing_required_keys() {
    let condition = Condition::when([("foo", json!("bar"))]);
    let state = state_from_pairs([("bar", json!("baz"))]);

    let error = condition
        .run(&state)
        .expect_err("run should fail when required keys are missing");

    match error {
        ConditionError::MissingRequiredKeys {
            condition_name,
            missing_keys,
            available_keys,
        } => {
            assert_eq!(condition_name, "foo=bar");
            assert_eq!(missing_keys, vec!["foo".to_string()]);
            assert_eq!(available_keys, vec!["bar".to_string()]);
        }
        other => panic!("expected MissingRequiredKeys error, got {other:?}"),
    }
}

#[test]
fn evaluate_validates_before_resolver_executes() {
    let resolver_executed = Arc::new(AtomicBool::new(false));
    let resolver_executed_in_closure = Arc::clone(&resolver_executed);
    let condition = Condition::new(
        ["required"],
        move |_state| {
            resolver_executed_in_closure.store(true, Ordering::SeqCst);
            true
        },
        "validate_first",
    );

    let state = state_from_pairs([("other", json!(1))]);
    let error = condition
        .evaluate(&state)
        .expect_err("evaluate should fail on missing required keys");

    match error {
        ConditionError::MissingRequiredKeys { missing_keys, .. } => {
            assert_eq!(missing_keys, vec!["required".to_string()]);
        }
        other => panic!("expected MissingRequiredKeys error, got {other:?}"),
    }
    assert!(
        !resolver_executed.load(Ordering::SeqCst),
        "resolver should not execute when validation fails"
    );
}

#[test]
fn invert_condition_flips_boolean_result() {
    let condition = Condition::when([("foo", json!("bar"))]);
    let inverted = !condition;

    assert_eq!(inverted.name(), "~foo=bar");
    assert_eq!(inverted.reads(), &["foo".to_string()]);
    assert_eq!(
        inverted
            .run(&state_from_pairs([("foo", json!("bar"))]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
    assert_eq!(
        inverted
            .run(&state_from_pairs([("foo", json!("baz"))]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}

#[test]
fn and_condition_combines_reads_name_and_predicate() {
    let condition =
        Condition::when([("foo", json!("bar"))]) & Condition::when([("baz", json!("qux"))]);

    assert_eq!(condition.name(), "foo=bar & baz=qux");
    assert_eq!(condition.reads(), &["foo".to_string(), "baz".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("bar")),
                ("baz", json!("qux"))
            ]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("baz")),
                ("baz", json!("qux"))
            ]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn or_condition_combines_reads_name_and_predicate() {
    let condition =
        Condition::when([("foo", json!("bar"))]) | Condition::when([("baz", json!("qux"))]);

    assert_eq!(condition.name(), "foo=bar | baz=qux");
    assert_eq!(condition.reads(), &["foo".to_string(), "baz".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("bar")),
                ("baz", json!("qux"))
            ]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("bar")),
                ("baz", json!("corge"))
            ]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("baz")),
                ("baz", json!("corge"))
            ]))
            .expect("run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn and_or_preserve_validate_before_eval_semantics() {
    let right_resolver_executed_for_and = Arc::new(AtomicBool::new(false));
    let right_resolver_executed_for_or = Arc::new(AtomicBool::new(false));

    let and_condition = Condition::new(["left"], |_state| true, "left_check")
        & Condition::new(
            ["right"],
            {
                let executed = Arc::clone(&right_resolver_executed_for_and);
                move |_state| {
                    executed.store(true, Ordering::SeqCst);
                    true
                }
            },
            "right_check",
        );

    let or_condition = Condition::new(["left"], |_state| false, "left_check")
        | Condition::new(
            ["right"],
            {
                let executed = Arc::clone(&right_resolver_executed_for_or);
                move |_state| {
                    executed.store(true, Ordering::SeqCst);
                    true
                }
            },
            "right_check",
        );

    let state_missing_right = state_from_pairs([("left", json!(1))]);

    let and_error = and_condition
        .evaluate(&state_missing_right)
        .expect_err("and condition should fail validation when right key is missing");
    let or_error = or_condition
        .evaluate(&state_missing_right)
        .expect_err("or condition should fail validation when right key is missing");

    match and_error {
        ConditionError::MissingRequiredKeys {
            condition_name,
            missing_keys,
            ..
        } => {
            assert_eq!(condition_name, "left_check & right_check");
            assert_eq!(missing_keys, vec!["right".to_string()]);
        }
        other => panic!("expected MissingRequiredKeys for and, got {other:?}"),
    }
    match or_error {
        ConditionError::MissingRequiredKeys {
            condition_name,
            missing_keys,
            ..
        } => {
            assert_eq!(condition_name, "left_check | right_check");
            assert_eq!(missing_keys, vec!["right".to_string()]);
        }
        other => panic!("expected MissingRequiredKeys for or, got {other:?}"),
    }

    assert!(
        !right_resolver_executed_for_and.load(Ordering::SeqCst),
        "and right resolver should not execute when validation fails"
    );
    assert!(
        !right_resolver_executed_for_or.load(Ordering::SeqCst),
        "or right resolver should not execute when validation fails"
    );
}

#[test]
fn expr_simple_parity() {
    let condition = Condition::expr("foo == 'bar'");
    assert_eq!(condition.reads(), &["foo".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([("foo", json!("bar"))]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([("foo", json!("baz"))]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn expr_supports_python_identity_conditions() {
    let generated_topic_missing = Condition::expr("generated_topic is None");
    assert_eq!(
        generated_topic_missing.reads(),
        &["generated_topic".to_string()]
    );
    assert_eq!(
        generated_topic_missing
            .run(&state_from_pairs([("generated_topic", Value::Null)]))
            .expect("identity expr should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        generated_topic_missing
            .run(&state_from_pairs([("generated_topic", json!("topic"))]))
            .expect("identity expr should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );

    let topic_feedback_present = Condition::expr("topic_feedback is not None");
    assert_eq!(
        topic_feedback_present.reads(),
        &["topic_feedback".to_string()]
    );
    assert_eq!(
        topic_feedback_present
            .run(&state_from_pairs([("topic_feedback", json!("approved"))]))
            .expect("negated identity expr should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        topic_feedback_present
            .run(&state_from_pairs([("topic_feedback", Value::Null)]))
            .expect("negated identity expr should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn expr_identity_conditions_validate_all_referenced_keys_before_evaluation() {
    let condition = Condition::expr("truthy or missing_name is None");
    let error = condition
        .evaluate(&state_from_pairs([("truthy", json!(true))]))
        .expect_err("missing referenced key should fail before short-circuit evaluation");

    match error {
        ConditionError::MissingRequiredKeys {
            condition_name,
            missing_keys,
            available_keys,
        } => {
            assert_eq!(condition_name, "truthy or missing_name is None");
            assert_eq!(missing_keys, vec!["missing_name".to_string()]);
            assert_eq!(available_keys, vec!["truthy".to_string()]);
        }
        other => panic!("expected MissingRequiredKeys error, got {other:?}"),
    }
}

#[test]
fn expr_complex_parity() {
    let condition = Condition::expr("foo == 'bar' and len(baz) == 3");
    assert_eq!(condition.reads(), &["foo".to_string(), "baz".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("bar")),
                ("baz", json!("qux"))
            ]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("baz")),
                ("baz", json!("qux"))
            ]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("foo", json!("bar")),
                ("baz", json!("corge"))
            ]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn expr_comparisons_and_modulo() {
    let condition = Condition::expr("n == 1 and count < 10 and n % 2 == 1");
    assert_eq!(condition.reads(), &["n".to_string(), "count".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([("n", json!(1)), ("count", json!(9))]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([("n", json!(2)), ("count", json!(9))]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn expr_boolean_ops_and_or_not() {
    let condition = Condition::expr("a and b or not c");
    assert_eq!(
        condition.reads(),
        &["a".to_string(), "b".to_string(), "c".to_string()]
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("a", json!(true)),
                ("b", json!(false)),
                ("c", json!(false))
            ]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([
                ("a", json!(true)),
                ("b", json!(false)),
                ("c", json!(true))
            ]))
            .expect("expr run should succeed"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );
}

#[test]
fn expr_membership_and_len_and_subscript() {
    let membership = Condition::expr("\"exit\" in question");
    assert_eq!(membership.reads(), &["question".to_string()]);
    assert_eq!(
        membership
            .run(&state_from_pairs([(
                "question",
                json!("type exit to quit")
            )]))
            .expect("membership expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        membership
            .run(&state_from_pairs([("question", json!("continue"))]))
            .expect("membership expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );

    let len_condition = Condition::expr("len(list_key) == 3");
    assert_eq!(len_condition.reads(), &["list_key".to_string()]);
    assert_eq!(
        len_condition
            .run(&state_from_pairs([("list_key", json!([1, 2, 3]))]))
            .expect("len expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
    assert_eq!(
        len_condition
            .run(&state_from_pairs([("list_key", json!([1, 2]))]))
            .expect("len expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(false))])
    );

    let dict_subscript = Condition::expr("dict_key[\"foo\"] == 0");
    assert_eq!(dict_subscript.reads(), &["dict_key".to_string()]);
    assert_eq!(
        dict_subscript
            .run(&state_from_pairs([("dict_key", json!({"foo": 0}))]))
            .expect("dict subscript expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );

    let list_subscript = Condition::expr("list_key[0] == 1");
    assert_eq!(list_subscript.reads(), &["list_key".to_string()]);
    assert_eq!(
        list_subscript
            .run(&state_from_pairs([("list_key", json!([1, 2, 3]))]))
            .expect("list subscript expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}

#[test]
fn expr_treats_len_identifier_as_normal_name_when_not_called() {
    let condition = Condition::expr("len == 3");
    assert_eq!(condition.reads(), &["len".to_string()]);
    assert_eq!(
        condition
            .run(&state_from_pairs([("len", json!(3))]))
            .expect("len identifier expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}

#[test]
fn expr_reports_parse_error_during_evaluate() {
    let condition = Condition::expr("foo +");
    let error = condition
        .evaluate(&state_from_pairs([("foo", json!(1))]))
        .expect_err("invalid expression should error");

    match error {
        ConditionError::Expr { expression, .. } => {
            assert_eq!(expression, "foo +");
        }
        other => panic!("expected Expr error, got {other:?}"),
    }
}

#[test]
fn expr_modulo_i128_min_negative_one_edge_case() {
    let condition = Condition::expr("(-170141183460469231731687303715884105727 - 1) % -1 == 0");
    assert!(
        condition.reads().is_empty(),
        "expression only uses constants"
    );
    assert_eq!(
        condition
            .run(&state_from_pairs([]))
            .expect("edge expression should evaluate without panic"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}

#[test]
fn expr_ifexp_floor_div_pow_slice_and_attribute() {
    let ifexp = Condition::expr("(alt if flag else fallback) == 1");
    assert_eq!(
        ifexp.reads(),
        &[
            "flag".to_string(),
            "alt".to_string(),
            "fallback".to_string()
        ]
    );
    assert_eq!(
        ifexp
            .run(&state_from_pairs([
                ("flag", json!(false)),
                ("alt", json!(0)),
                ("fallback", json!(1))
            ]))
            .expect("if expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );

    let floor_div = Condition::expr("5 // 2 == 2");
    assert_eq!(floor_div.reads(), &[] as &[String]);
    assert_eq!(
        floor_div
            .run(&state_from_pairs([]))
            .expect("floor division expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );

    let power = Condition::expr("2 ** 5 == 32");
    assert_eq!(power.reads(), &[] as &[String]);
    assert_eq!(
        power
            .run(&state_from_pairs([]))
            .expect("power expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );

    let list_slice = Condition::expr("arr[1:][0] == 2");
    assert_eq!(list_slice.reads(), &["arr".to_string()]);
    assert_eq!(
        list_slice
            .run(&state_from_pairs([("arr", json!([1, 2, 3, 4]))]))
            .expect("slice expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );

    let attribute = Condition::expr("obj.score >= threshold");
    assert_eq!(
        attribute.reads(),
        &["obj".to_string(), "threshold".to_string()]
    );
    assert_eq!(
        attribute
            .run(&state_from_pairs([
                ("obj", json!({"score": 9})),
                ("threshold", json!(9))
            ]))
            .expect("attribute expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}

#[test]
fn expr_negative_step_slice_omitted_upper_bound() {
    let reverse_slice = Condition::expr("arr[::-1][0] == 4");
    assert_eq!(reverse_slice.reads(), &["arr".to_string()]);
    assert_eq!(
        reverse_slice
            .run(&state_from_pairs([("arr", json!([1, 2, 3, 4]))]))
            .expect("reverse slice expression should run"),
        IndexMap::from([(Condition::KEY.to_string(), json!(true))])
    );
}
