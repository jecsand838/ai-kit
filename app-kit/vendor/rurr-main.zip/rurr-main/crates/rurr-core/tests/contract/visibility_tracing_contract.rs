use crate::support_common::tracing::{
    tracer_with_recording_hooks, FailOnceHook, RecordedSpanEvent, RecordingHooks,
};
use async_trait::async_trait;
use futures::FutureExt;
use indexmap::IndexMap;
use rurr_core::action::ActionTracer;
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, LifecycleAdapterSet, LifecycleError, SpanContext, SyncLifecycleAdapter,
};
use rurr_core::visibility::{trace, trace_async, TraceOptions, TraceSpanHandle, VisibilityError};
use serde::ser::Error as _;
use serde_json::json;
use serde_json::Value;
use std::panic::{self, AssertUnwindSafe};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::Duration;
use tokio::sync::Notify;

fn event_triples(events: Vec<RecordedSpanEvent>) -> Vec<(&'static str, String, String)> {
    events
        .into_iter()
        .map(|event| {
            (
                event.phase(),
                event.span_name().to_string(),
                event.span_id().to_string(),
            )
        })
        .collect()
}

#[derive(Debug, Default)]
struct AsyncSignal {
    raised: AtomicBool,
    notify: Notify,
}

impl AsyncSignal {
    fn raise(&self) {
        self.raised.store(true, Ordering::SeqCst);
        self.notify.notify_waiters();
    }

    async fn wait(&self) {
        if self.raised.load(Ordering::SeqCst) {
            return;
        }
        let notified = self.notify.notified();
        if self.raised.load(Ordering::SeqCst) {
            return;
        }
        notified.await;
    }
}

#[derive(Debug, Default)]
struct BlockingAsyncAttributeHook {
    events: Mutex<Vec<String>>,
    entered: AsyncSignal,
    release: AsyncSignal,
}

impl BlockingAsyncAttributeHook {
    fn events(&self) -> Vec<String> {
        self.events
            .lock()
            .expect("events lock should not be poisoned")
            .clone()
    }

    fn record(&self, phase: &str, context: &SpanContext) {
        self.events
            .lock()
            .expect("events lock should not be poisoned")
            .push(format!(
                "{phase}:{}",
                context.span_name().unwrap_or("<unnamed>")
            ));
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for BlockingAsyncAttributeHook {
    async fn pre_start_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.record("start", context);
        Ok(())
    }

    async fn post_end_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.record("end", context);
        Ok(())
    }

    async fn log_attributes(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        if attributes.contains_key("blocked") {
            self.entered.raise();
            self.release.wait().await;
            self.record("log", context);
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Copy)]
struct FailingTraceOutput;

impl serde::Serialize for FailingTraceOutput {
    fn serialize<S>(&self, _serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        Err(S::Error::custom("intentional output serialization failure"))
    }
}

#[test]
fn explicit_tracer_tracks_sync_nested_spans() {
    let recorder = Arc::new(RecordingHooks::default());
    let result = trace(
        &tracer_with_recording_hooks(41, Arc::clone(&recorder)),
        "outer",
        &IndexMap::new(),
        &TraceOptions::new(),
        |outer: TraceSpanHandle| {
            assert_eq!(
                outer.span().map(|span| span.uid()),
                Some("41:0".to_string())
            );
            outer
                .trace_child("inner", |inner: TraceSpanHandle| {
                    assert_eq!(
                        inner.span().map(|span| span.uid()),
                        Some("41:0.0".to_string())
                    );
                    inner
                        .log_attribute("seen", json!(1))
                        .expect("attribute should log");
                })
                .expect("nested child trace should succeed");
            outer
                .trace_child("sibling", |sibling: TraceSpanHandle| {
                    assert_eq!(
                        sibling.span().map(|span| span.uid()),
                        Some("41:0.1".to_string())
                    );
                })
                .expect("sibling child trace should succeed");
            7
        },
    )
    .expect("root trace should succeed");

    let events = recorder.events();
    assert_eq!(result, 7);
    assert!(events
        .iter()
        .all(|event| event.app_id() == Some("test-app")));
    assert_eq!(
        event_triples(events),
        vec![
            ("sync:start", "outer".to_string(), "41:0".to_string()),
            ("sync:start", "inner".to_string(), "41:0.0".to_string()),
            ("sync:end", "inner".to_string(), "41:0.0".to_string()),
            ("sync:start", "sibling".to_string(), "41:0.1".to_string()),
            ("sync:end", "sibling".to_string(), "41:0.1".to_string()),
            ("sync:end", "outer".to_string(), "41:0".to_string()),
        ]
    );
}

#[tokio::test]
async fn explicit_tracer_tracks_async_nested_spans() {
    let recorder = Arc::new(RecordingHooks::default());
    let result = trace_async(
        &tracer_with_recording_hooks(41, Arc::clone(&recorder)),
        "outer_async",
        &IndexMap::new(),
        &TraceOptions::new(),
        |outer: TraceSpanHandle| async move {
            assert_eq!(
                outer.span().map(|span| span.uid()),
                Some("41:0".to_string())
            );
            outer
                .trace_child_async("inner_async", |inner: TraceSpanHandle| async move {
                    assert_eq!(
                        inner.span().map(|span| span.uid()),
                        Some("41:0.0".to_string())
                    );
                    inner
                        .log_attribute_async("seen_async", json!(2))
                        .await
                        .expect("attribute should log");
                })
                .await
                .expect("nested child trace should succeed");
            outer
                .trace_child_async("sibling_async", |sibling: TraceSpanHandle| async move {
                    assert_eq!(
                        sibling.span().map(|span| span.uid()),
                        Some("41:0.1".to_string())
                    );
                })
                .await
                .expect("sibling child trace should succeed");
            11
        },
    )
    .await
    .expect("root async trace should succeed");

    assert_eq!(result, 11);
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            ("sync:start", "outer_async".to_string(), "41:0".to_string()),
            ("async:start", "outer_async".to_string(), "41:0".to_string()),
            (
                "sync:start",
                "inner_async".to_string(),
                "41:0.0".to_string()
            ),
            (
                "async:start",
                "inner_async".to_string(),
                "41:0.0".to_string()
            ),
            ("sync:end", "inner_async".to_string(), "41:0.0".to_string()),
            ("async:end", "inner_async".to_string(), "41:0.0".to_string()),
            (
                "sync:start",
                "sibling_async".to_string(),
                "41:0.1".to_string()
            ),
            (
                "async:start",
                "sibling_async".to_string(),
                "41:0.1".to_string()
            ),
            (
                "sync:end",
                "sibling_async".to_string(),
                "41:0.1".to_string()
            ),
            (
                "async:end",
                "sibling_async".to_string(),
                "41:0.1".to_string()
            ),
            ("sync:end", "outer_async".to_string(), "41:0".to_string()),
            ("async:end", "outer_async".to_string(), "41:0".to_string()),
        ]
    );
}

#[tokio::test]
async fn trace_child_async_captures_pre_future_panic_and_closes_child_span() {
    let recorder = Arc::new(RecordingHooks::default());
    let tracer = tracer_with_recording_hooks(41, Arc::clone(&recorder));
    let child_error = Arc::new(Mutex::new(None));

    let result = trace_async(
        &tracer,
        "outer_panic_async",
        &IndexMap::new(),
        &TraceOptions::new(),
        {
            let child_error = Arc::clone(&child_error);
            |outer: TraceSpanHandle| async move {
                let error = outer
                    .trace_child_async(
                        "panic_child",
                        |_child: TraceSpanHandle| -> futures::future::Ready<i32> {
                            panic!("intentional panic before future construction")
                        },
                    )
                    .await
                    .expect_err("child trace should convert the panic into a typed error");
                *child_error
                    .lock()
                    .expect("child_error lock should not be poisoned") = Some(error);
                1
            }
        },
    )
    .await
    .expect("outer async trace should remain usable after the child panic");

    assert_eq!(result, 1);
    assert!(matches!(
        child_error
            .lock()
            .expect("child_error lock should not be poisoned")
            .clone(),
        Some(VisibilityError::CapturedPanic {
            operation: "trace_child_async",
            ..
        })
    ));

    let recovered = trace_async(
        &tracer,
        "outer_recovered_async",
        &IndexMap::new(),
        &TraceOptions::new(),
        |outer: TraceSpanHandle| async move {
            outer
                .trace_child_async(
                    "recovered_child",
                    |_child: TraceSpanHandle| async move { 7 },
                )
                .await
                .expect("recovered child trace should succeed");
            2
        },
    )
    .await
    .expect("tracer should remain reusable after the child panic");

    assert_eq!(recovered, 2);
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            (
                "sync:start",
                "outer_panic_async".to_string(),
                "41:0".to_string()
            ),
            (
                "async:start",
                "outer_panic_async".to_string(),
                "41:0".to_string()
            ),
            (
                "sync:start",
                "panic_child".to_string(),
                "41:0.0".to_string()
            ),
            (
                "async:start",
                "panic_child".to_string(),
                "41:0.0".to_string()
            ),
            ("sync:end", "panic_child".to_string(), "41:0.0".to_string()),
            ("async:end", "panic_child".to_string(), "41:0.0".to_string()),
            (
                "sync:end",
                "outer_panic_async".to_string(),
                "41:0".to_string()
            ),
            (
                "async:end",
                "outer_panic_async".to_string(),
                "41:0".to_string()
            ),
            (
                "sync:start",
                "outer_recovered_async".to_string(),
                "41:1".to_string()
            ),
            (
                "async:start",
                "outer_recovered_async".to_string(),
                "41:1".to_string()
            ),
            (
                "sync:start",
                "recovered_child".to_string(),
                "41:1.0".to_string()
            ),
            (
                "async:start",
                "recovered_child".to_string(),
                "41:1.0".to_string()
            ),
            (
                "sync:end",
                "recovered_child".to_string(),
                "41:1.0".to_string()
            ),
            (
                "async:end",
                "recovered_child".to_string(),
                "41:1.0".to_string()
            ),
            (
                "sync:end",
                "outer_recovered_async".to_string(),
                "41:1".to_string()
            ),
            (
                "async:end",
                "outer_recovered_async".to_string(),
                "41:1".to_string()
            ),
        ]
    );
}

#[tokio::test]
async fn concurrent_async_sibling_traces_are_isolated() {
    let recorder = Arc::new(RecordingHooks::default());
    trace_async(
        &tracer_with_recording_hooks(41, Arc::clone(&recorder)),
        "root_async",
        &IndexMap::new(),
        &TraceOptions::new(),
        |outer: TraceSpanHandle| async move {
            let left = outer.trace_child_async("left", |left: TraceSpanHandle| async move {
                assert_eq!(
                    left.span().map(|span| span.uid()),
                    Some("41:0.0".to_string())
                );
                left.log_attribute_async("side", json!("left"))
                    .await
                    .expect("left attribute should log");
            });
            let right = outer.trace_child_async("right", |right: TraceSpanHandle| async move {
                assert_eq!(
                    right.span().map(|span| span.uid()),
                    Some("41:0.1".to_string())
                );
                right
                    .log_attribute_async("side", json!("right"))
                    .await
                    .expect("right attribute should log");
            });
            let (left_result, right_result) = tokio::join!(left, right);
            left_result.expect("left sibling should complete");
            right_result.expect("right sibling should complete");
        },
    )
    .await
    .expect("root trace should succeed");

    let attributes = recorder.attributes();
    assert!(attributes
        .iter()
        .any(|(span_id, attrs)| span_id == "41:0.0" && attrs.get("side") == Some(&json!("left"))));
    assert!(attributes
        .iter()
        .any(|(span_id, attrs)| span_id == "41:0.1" && attrs.get("side") == Some(&json!("right"))));
}

#[test]
fn trace_wrapper_sync_recursively_nests_same_tracer_calls() {
    let recorder = Arc::new(RecordingHooks::default());
    let tracer = tracer_with_recording_hooks(41, Arc::clone(&recorder));

    let result = trace(
        &tracer,
        "foo",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_outer: TraceSpanHandle| {
            trace(
                &tracer,
                "bar",
                &IndexMap::new(),
                &TraceOptions::new(),
                |inner: TraceSpanHandle| {
                    let inner_span = inner.span().expect("inner span should be active");
                    assert_eq!(inner_span.span_name(), "bar");
                    assert_eq!(
                        inner_span
                            .parent()
                            .expect("recursive trace should adopt the outer span")
                            .span_name(),
                        "foo"
                    );
                    6
                },
            )
            .expect("recursive nested trace should succeed")
                + 3
        },
    )
    .expect("outer trace should succeed");

    assert_eq!(result, 9);
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            ("sync:start", "foo".to_string(), "41:0".to_string()),
            ("sync:start", "bar".to_string(), "41:0.0".to_string()),
            ("sync:end", "bar".to_string(), "41:0.0".to_string()),
            ("sync:end", "foo".to_string(), "41:0".to_string()),
        ]
    );
}

#[tokio::test]
async fn trace_wrapper_async_recursively_nests_same_tracer_calls() {
    let recorder = Arc::new(RecordingHooks::default());
    let tracer = tracer_with_recording_hooks(41, Arc::clone(&recorder));

    let result = trace_async(
        &tracer,
        "foo_async",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_outer: TraceSpanHandle| async {
            trace_async(
                &tracer,
                "bar_async",
                &IndexMap::new(),
                &TraceOptions::new(),
                |inner: TraceSpanHandle| async move {
                    let inner_span = inner.span().expect("inner span should be active");
                    assert_eq!(inner_span.span_name(), "bar_async");
                    assert_eq!(
                        inner_span
                            .parent()
                            .expect("recursive async trace should adopt the outer span")
                            .span_name(),
                        "foo_async"
                    );
                    6
                },
            )
            .await
            .expect("recursive nested async trace should succeed")
                + 3
        },
    )
    .await
    .expect("outer async trace should succeed");

    assert_eq!(result, 9);
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            ("sync:start", "foo_async".to_string(), "41:0".to_string()),
            ("async:start", "foo_async".to_string(), "41:0".to_string()),
            ("sync:start", "bar_async".to_string(), "41:0.0".to_string()),
            ("async:start", "bar_async".to_string(), "41:0.0".to_string()),
            ("sync:end", "bar_async".to_string(), "41:0.0".to_string()),
            ("async:end", "bar_async".to_string(), "41:0.0".to_string()),
            ("sync:end", "foo_async".to_string(), "41:0".to_string()),
            ("async:end", "foo_async".to_string(), "41:0".to_string()),
        ]
    );
}

#[test]
fn nested_trace_with_different_tracer_stays_a_root_span() {
    let recorder = Arc::new(RecordingHooks::default());
    let outer = tracer_with_recording_hooks(41, Arc::clone(&recorder));
    let inner = tracer_with_recording_hooks(41, Arc::clone(&recorder));

    trace(
        &outer,
        "outer",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_outer: TraceSpanHandle| {
            trace(
                &inner,
                "inner_other_tracer",
                &IndexMap::new(),
                &TraceOptions::new(),
                |inner_span: TraceSpanHandle| {
                    assert!(
                        inner_span
                            .span()
                            .expect("inner span should be active")
                            .parent()
                            .is_none(),
                        "a different tracer session must start a new root span"
                    );
                },
            )
            .expect("inner trace should succeed");
        },
    )
    .expect("outer trace should succeed");

    assert_eq!(
        event_triples(recorder.events()),
        vec![
            ("sync:start", "outer".to_string(), "41:0".to_string()),
            (
                "sync:start",
                "inner_other_tracer".to_string(),
                "41:0".to_string()
            ),
            (
                "sync:end",
                "inner_other_tracer".to_string(),
                "41:0".to_string()
            ),
            ("sync:end", "outer".to_string(), "41:0".to_string()),
        ]
    );
}

#[tokio::test]
async fn trace_async_waits_for_in_flight_attribute_ops_before_end_hook() {
    let hook = Arc::new(BlockingAsyncAttributeHook::default());
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = hook.clone();
    let tracer = ActionTracer::new(
        "test_action",
        41,
        LifecycleAdapterSet::new(vec![], vec![async_hook]),
        "test-app",
        Some("pk".to_string()),
    );
    let body_returned = Arc::new(AsyncSignal::default());
    let worker_handle = Arc::new(Mutex::new(None));

    let trace_task = tokio::spawn({
        let tracer = tracer.clone();
        let hook = Arc::clone(&hook);
        let body_returned = Arc::clone(&body_returned);
        let worker_handle = Arc::clone(&worker_handle);
        async move {
            trace_async(
                &tracer,
                "barrier_async",
                &IndexMap::new(),
                &TraceOptions::new()
                    .with_capture_inputs(false)
                    .with_capture_outputs(false)
                    .with_capture_auto_attributes(false),
                move |span: TraceSpanHandle| async move {
                    let worker = tokio::spawn({
                        let span = span.clone();
                        async move {
                            span.log_attribute_async("blocked", json!(1))
                                .await
                                .expect("blocked attribute should eventually log");
                        }
                    });
                    *worker_handle
                        .lock()
                        .expect("worker handle lock should not be poisoned") = Some(worker);
                    hook.entered.wait().await;
                    body_returned.raise();
                    5
                },
            )
            .await
        }
    });

    hook.entered.wait().await;
    body_returned.wait().await;
    tokio::task::yield_now().await;

    assert!(
        !trace_task.is_finished(),
        "trace should stay pending while an in-flight async attribute op is blocked"
    );
    assert_eq!(hook.events(), vec!["start:barrier_async".to_string()]);
    assert!(
        tokio::time::timeout(Duration::from_millis(50), async {
            while !trace_task.is_finished() {
                tokio::task::yield_now().await;
            }
        })
        .await
        .is_err(),
        "trace should not finish before the blocked attribute operation is released"
    );

    hook.release.raise();

    let trace_result = trace_task
        .await
        .expect("trace task should join cleanly")
        .expect("trace should succeed after the attribute operation completes");
    assert_eq!(trace_result, 5);

    let worker = worker_handle
        .lock()
        .expect("worker handle lock should not be poisoned")
        .take()
        .expect("worker handle should be captured");
    worker.await.expect("worker task should join cleanly");

    assert_eq!(
        hook.events(),
        vec![
            "start:barrier_async".to_string(),
            "log:barrier_async".to_string(),
            "end:barrier_async".to_string(),
        ]
    );
}

#[test]
fn trace_sync_captures_inputs_and_outputs_with_filterlist() {
    let recorder = Arc::new(RecordingHooks::default());
    let result = trace(
        &tracer_with_recording_hooks(41, Arc::clone(&recorder)),
        "foo",
        &IndexMap::from([
            ("visible".to_string(), json!("kept")),
            ("secret".to_string(), json!("filtered")),
        ]),
        &TraceOptions::new().with_input_filterlist(["secret"]),
        |span: TraceSpanHandle| {
            assert_eq!(span.span().map(|span| span.span_name()), Some("foo"));
            7
        },
    )
    .expect("trace should succeed");

    let attributes = recorder.attributes();
    assert_eq!(result, 7);
    assert!(attributes
        .iter()
        .any(|(_, attrs)| attrs.get("visible") == Some(&json!("kept"))));
    assert!(attributes
        .iter()
        .all(|(_, attrs)| !attrs.contains_key("secret")));
    assert!(attributes
        .iter()
        .any(|(_, attrs)| attrs.get("return") == Some(&json!(7))));
}

#[test]
fn trace_sync_fails_closed_when_output_serialization_fails() {
    let recorder = Arc::new(RecordingHooks::default());
    let error = trace(
        &tracer_with_recording_hooks(41, Arc::clone(&recorder)),
        "serialize_sync_failure",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_span: TraceSpanHandle| FailingTraceOutput,
    )
    .expect_err("trace should fail closed when output serialization fails");

    assert_eq!(
        error,
        VisibilityError::OutputSerializationFailed {
            operation: "trace",
            message: "intentional output serialization failure".to_string(),
        }
    );
    assert!(recorder
        .attributes()
        .iter()
        .all(|(_, attrs)| !attrs.contains_key("return")));
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            (
                "sync:start",
                "serialize_sync_failure".to_string(),
                "41:0".to_string()
            ),
            (
                "sync:end",
                "serialize_sync_failure".to_string(),
                "41:0".to_string()
            ),
        ]
    );
}

#[tokio::test]
async fn trace_async_captures_inputs_outputs_and_dependencies() {
    let recorder = Arc::new(RecordingHooks::default());
    let result = trace_async(
        &tracer_with_recording_hooks(41, Arc::clone(&recorder)),
        "ignored_function_name",
        &IndexMap::from([("visible".to_string(), json!("kept"))]),
        &TraceOptions::new().with_span_name("foo_async"),
        |span: TraceSpanHandle| async move {
            span.trace_child_with_dependencies_async(
                "dep_child",
                vec!["dep_a".to_string(), "dep_b".to_string()],
                |_child: TraceSpanHandle| async move { 11 },
            )
            .await
            .expect("dependency child trace should succeed")
        },
    )
    .await
    .expect("trace should succeed");

    let events = recorder.events();
    let child_event = events
        .into_iter()
        .find(|event| event.span_name() == "dep_child" && event.phase() == "async:start")
        .expect("dependency child event should exist");
    let child_attributes = recorder
        .attributes()
        .into_iter()
        .find(|(span_id, _)| span_id == child_event.span_id())
        .map(|(_, attrs)| attrs)
        .unwrap_or_default();

    assert_eq!(result, 11);
    assert!(child_attributes.is_empty() || !child_attributes.contains_key("return"));
}

#[tokio::test]
async fn trace_async_fails_closed_when_output_serialization_fails() {
    let recorder = Arc::new(RecordingHooks::default());
    let error = trace_async(
        &tracer_with_recording_hooks(41, Arc::clone(&recorder)),
        "serialize_async_failure",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_span: TraceSpanHandle| async move { FailingTraceOutput },
    )
    .await
    .expect_err("trace_async should fail closed when output serialization fails");

    assert_eq!(
        error,
        VisibilityError::OutputSerializationFailed {
            operation: "trace_async",
            message: "intentional output serialization failure".to_string(),
        }
    );
    assert!(recorder
        .attributes()
        .iter()
        .all(|(_, attrs)| !attrs.contains_key("return")));
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            (
                "sync:start",
                "serialize_async_failure".to_string(),
                "41:0".to_string()
            ),
            (
                "async:start",
                "serialize_async_failure".to_string(),
                "41:0".to_string()
            ),
            (
                "sync:end",
                "serialize_async_failure".to_string(),
                "41:0".to_string()
            ),
            (
                "async:end",
                "serialize_async_failure".to_string(),
                "41:0".to_string()
            ),
        ]
    );
}

#[test]
fn inactive_tracer_trace_provides_noop_span_handle() {
    let result = trace(
        &ActionTracer::default(),
        "inactive",
        &IndexMap::new(),
        &TraceOptions::new(),
        |span: TraceSpanHandle| {
            assert!(span.span().is_none());
            span.log_attribute("unused", json!(1))
                .expect("inactive log should no-op");
            5
        },
    )
    .expect("inactive trace should succeed");

    assert_eq!(result, 5);
}

#[test]
fn active_sync_trace_rejects_log_attribute_async() {
    let recorder = Arc::new(RecordingHooks::default());
    let tracer = tracer_with_recording_hooks(41, Arc::clone(&recorder));
    let async_result = Arc::new(Mutex::new(None));

    let result = trace(
        &tracer,
        "sync_only_root",
        &IndexMap::new(),
        &TraceOptions::new(),
        {
            let async_result = Arc::clone(&async_result);
            move |span: TraceSpanHandle| {
                *async_result
                    .lock()
                    .expect("async_result lock should not be poisoned") = Some(
                    futures::executor::block_on(span.log_attribute_async("mixed_lane", json!(1))),
                );
                5
            }
        },
    )
    .expect("root trace should stay usable");

    assert_eq!(result, 5);
    assert_eq!(
        async_result
            .lock()
            .expect("async_result lock should not be poisoned")
            .clone(),
        Some(Err(VisibilityError::AsyncOperationRequiresAsyncTrace {
            operation: "log_attribute_async",
        }))
    );
    assert!(recorder
        .attributes()
        .iter()
        .all(|(_, attrs)| !attrs.contains_key("mixed_lane")));
}

#[test]
fn active_sync_trace_rejects_trace_child_async_without_running_callback() {
    let recorder = Arc::new(RecordingHooks::default());
    let tracer = tracer_with_recording_hooks(41, Arc::clone(&recorder));
    let child_ran = Arc::new(AtomicBool::new(false));
    let child_result = Arc::new(Mutex::new(None));

    let result = trace(
        &tracer,
        "sync_only_parent",
        &IndexMap::new(),
        &TraceOptions::new(),
        {
            let child_ran = Arc::clone(&child_ran);
            let child_result = Arc::clone(&child_result);
            move |span: TraceSpanHandle| {
                *child_result
                    .lock()
                    .expect("child_result lock should not be poisoned") = Some(
                    futures::executor::block_on(span.trace_child_async("should_not_run", {
                        let child_ran = Arc::clone(&child_ran);
                        move |_child: TraceSpanHandle| async move {
                            child_ran.store(true, Ordering::SeqCst);
                            9
                        }
                    })),
                );
                7
            }
        },
    )
    .expect("root trace should stay usable");

    assert_eq!(result, 7);
    assert_eq!(
        child_result
            .lock()
            .expect("child_result lock should not be poisoned")
            .clone(),
        Some(Err(VisibilityError::AsyncOperationRequiresAsyncTrace {
            operation: "trace_child_async",
        }))
    );
    assert!(
        !child_ran.load(Ordering::SeqCst),
        "async child callback must not run for an active sync-only handle"
    );
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            (
                "sync:start",
                "sync_only_parent".to_string(),
                "41:0".to_string()
            ),
            (
                "sync:end",
                "sync_only_parent".to_string(),
                "41:0".to_string()
            ),
        ]
    );
}

#[test]
fn inactive_tracer_trace_propagates_panic() {
    let result = panic::catch_unwind(AssertUnwindSafe(|| {
        let _ = trace(
            &ActionTracer::default(),
            "inactive_panic",
            &IndexMap::new(),
            &TraceOptions::new(),
            |_span: TraceSpanHandle| -> i32 {
                panic!("panic should propagate when tracing is disabled");
            },
        );
    }));

    assert!(
        result.is_err(),
        "inactive sync tracing must not capture panics"
    );
}

#[tokio::test]
async fn inactive_tracer_trace_async_propagates_panic() {
    let result = AssertUnwindSafe(async {
        let _ = trace_async::<_, _, ()>(
            &ActionTracer::default(),
            "inactive_async_panic",
            &IndexMap::new(),
            &TraceOptions::new(),
            |_span: TraceSpanHandle| async move {
                panic!("panic should propagate when async tracing is disabled");
            },
        )
        .await;
    })
    .catch_unwind()
    .await;

    assert!(
        result.is_err(),
        "inactive async tracing must not capture panics"
    );
}

#[test]
fn finished_sync_handle_becomes_inactive_across_clones() {
    let recorder = Arc::new(RecordingHooks::default());
    let tracer = tracer_with_recording_hooks(41, Arc::clone(&recorder));
    let retained = Arc::new(Mutex::new(None));

    let result = trace(
        &tracer,
        "retained_sync",
        &IndexMap::new(),
        &TraceOptions::new(),
        {
            let retained = Arc::clone(&retained);
            move |span: TraceSpanHandle| {
                *retained
                    .lock()
                    .expect("retained handle lock should not be poisoned") = Some(span.clone());
                5
            }
        },
    )
    .expect("trace should succeed");

    assert_eq!(result, 5);
    let retained = retained
        .lock()
        .expect("retained handle lock should not be poisoned")
        .clone()
        .expect("retained handle should be captured");
    assert!(retained.span().is_none());

    retained
        .log_attribute("late", json!(1))
        .expect("finished handle log should no-op");
    let child_result = retained
        .trace_child("late_child", |child: TraceSpanHandle| {
            assert!(child.span().is_none());
            child
                .log_attribute("ignored", json!(2))
                .expect("inactive child log should no-op");
            9
        })
        .expect("finished handle child trace should behave like an inactive handle");

    assert_eq!(child_result, 9);
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            (
                "sync:start",
                "retained_sync".to_string(),
                "41:0".to_string()
            ),
            ("sync:end", "retained_sync".to_string(), "41:0".to_string()),
        ]
    );
    assert!(recorder
        .attributes()
        .iter()
        .all(|(_, attrs)| !attrs.contains_key("late") && !attrs.contains_key("ignored")));
}

#[tokio::test]
async fn finished_async_handle_becomes_inactive_across_clones() {
    let recorder = Arc::new(RecordingHooks::default());
    let tracer = tracer_with_recording_hooks(41, Arc::clone(&recorder));
    let retained = Arc::new(Mutex::new(None));

    let result = trace_async(
        &tracer,
        "retained_async",
        &IndexMap::new(),
        &TraceOptions::new(),
        {
            let retained = Arc::clone(&retained);
            move |span: TraceSpanHandle| async move {
                *retained
                    .lock()
                    .expect("retained handle lock should not be poisoned") = Some(span.clone());
                7
            }
        },
    )
    .await
    .expect("async trace should succeed");

    assert_eq!(result, 7);
    let retained = retained
        .lock()
        .expect("retained handle lock should not be poisoned")
        .clone()
        .expect("retained handle should be captured");
    assert!(retained.span().is_none());

    retained
        .log_attribute_async("late_async", json!(1))
        .await
        .expect("finished handle log should no-op");
    let child_result = retained
        .trace_child_async("late_child_async", |child: TraceSpanHandle| async move {
            assert!(child.span().is_none());
            child
                .log_attribute_async("ignored_async", json!(2))
                .await
                .expect("inactive child log should no-op");
            11
        })
        .await
        .expect("finished handle child trace should behave like an inactive handle");

    assert_eq!(child_result, 11);
    assert_eq!(
        event_triples(recorder.events()),
        vec![
            (
                "sync:start",
                "retained_async".to_string(),
                "41:0".to_string()
            ),
            (
                "async:start",
                "retained_async".to_string(),
                "41:0".to_string()
            ),
            ("sync:end", "retained_async".to_string(), "41:0".to_string()),
            (
                "async:end",
                "retained_async".to_string(),
                "41:0".to_string()
            ),
        ]
    );
    assert!(recorder.attributes().iter().all(
        |(_, attrs)| !attrs.contains_key("late_async") && !attrs.contains_key("ignored_async")
    ));
}

#[test]
fn hook_failure_allows_reuse_after_failed_sync_trace() {
    let recorder = Arc::new(FailOnceHook::default());
    let sync_recorder: Arc<dyn SyncLifecycleAdapter> = recorder;
    let tracer = ActionTracer::new(
        "test_action",
        41,
        LifecycleAdapterSet::new(vec![sync_recorder], Vec::new()),
        "test-app",
        Some("pk".to_string()),
    );

    let error = trace(
        &tracer,
        "flaky",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_span: TraceSpanHandle| 1,
    )
    .expect_err("first trace should fail");
    assert!(matches!(error, VisibilityError::HookFailed { .. }));

    let recovered = trace(
        &tracer,
        "recovered",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_span: TraceSpanHandle| 2,
    )
    .expect("second trace should recover");
    assert_eq!(recovered, 2);
}

#[tokio::test]
async fn hook_failure_allows_reuse_after_failed_async_trace() {
    let recorder = Arc::new(FailOnceHook::default());
    let sync_recorder: Arc<dyn SyncLifecycleAdapter> = recorder.clone();
    let async_recorder: Arc<dyn AsyncLifecycleAdapter> = recorder;
    let tracer = ActionTracer::new(
        "test_action",
        41,
        LifecycleAdapterSet::new(vec![sync_recorder], vec![async_recorder]),
        "test-app",
        Some("pk".to_string()),
    );

    let error = trace_async(
        &tracer,
        "flaky_async",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_span: TraceSpanHandle| async move { 1 },
    )
    .await
    .expect_err("first async trace should fail");
    assert!(matches!(error, VisibilityError::HookFailed { .. }));

    let recovered = trace_async(
        &tracer,
        "recovered_async",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_span: TraceSpanHandle| async move { 2 },
    )
    .await
    .expect("second async trace should recover");
    assert_eq!(recovered, 2);
}
