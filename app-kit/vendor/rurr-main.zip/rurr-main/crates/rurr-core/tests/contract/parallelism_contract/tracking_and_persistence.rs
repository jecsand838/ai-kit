use super::*;
use super::{assertions::*, fixtures::*, graphs::*, persistence::*};

#[test]
fn tracking_spawn_writes_children_and_child_metadata_schema_fields() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "parallelism_tracking_contract";
    let tracker = Arc::new(
        LocalTrackingClient::new(project, &storage_root)
            .expect("tracking client should initialize"),
    );

    let tracker_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![tracker_hook], Vec::new());

    let graphs = vec![
        runnable_graph_from_action(
            "child_a",
            FunctionActionBuilder::new()
                .writes(["output"])
                .with_source_code("fn child_a(_state, _ctx) -> output { output: 1 }")
                .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
                .expect("action should build"),
        ),
        runnable_graph_from_action(
            "child_b",
            FunctionActionBuilder::new()
                .writes(["output"])
                .with_source_code("fn child_b(_state, _ctx) -> output { output: 2 }")
                .build_sync(|_state, _ctx| map_from_pairs([("output", json!(2))]))
                .expect("action should build"),
        ),
    ];

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    )
    .with_source_code(
        "fn parallel(state, _ctx) -> child_states { ParallelTaskSource::graphs(graphs, state.clone()) }",
    );
    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        hooks,
        None,
    );

    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("parent app registration should succeed");

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    let children_path = project_app_dir(&storage_root, project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let children = read_jsonl(&children_path);
    assert_eq!(children.len(), 2);

    for entry in &children {
        let child_id = entry["child"]["app_id"]
            .as_str()
            .expect("child app_id should exist")
            .to_string();
        assert!(is_lower_hex_64(&child_id));
        assert_eq!(entry["type"], "child_application_data");
        assert_eq!(entry["event_type"], "spawn_start");
        assert_eq!(entry["child"]["type"], "pointer_data");
        assert_eq!(entry["child"]["partition_key"], json!("pk"));
        assert_eq!(entry["sequence_id"], json!(0));

        let metadata_path = project_app_dir(&storage_root, project, &child_id)
            .join(LocalTrackingClient::METADATA_FILENAME);
        let metadata = read_json(&metadata_path);
        assert_eq!(metadata["type"], "application_metadata");
        assert_eq!(
            metadata["spawning_parent_pointer"]["type"],
            json!("pointer_data")
        );
        assert_eq!(
            metadata["spawning_parent_pointer"]["app_id"],
            json!("parent-app")
        );
        assert_eq!(metadata["spawning_parent_pointer"]["sequence_id"], json!(0));
        assert_eq!(
            metadata["spawning_parent_pointer"]["partition_key"],
            json!("pk")
        );
    }
}

#[test]
fn tracking_spawn_reuses_stable_child_ids_across_repeated_parent_runs() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "parallelism_tracking_unique_children_contract";
    let tracker = Arc::new(
        LocalTrackingClient::new(project, &storage_root)
            .expect("tracking client should initialize"),
    );

    let tracker_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![tracker_hook], Vec::new());

    let graphs = two_constant_output_sync_child_graphs(("child_a", 1), ("child_b", 2));

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    )
    .with_source_code(
        "fn parallel(state, _ctx) -> child_states { ParallelTaskSource::graphs(graphs, state.clone()) }",
    );
    let mut app = build_looping_parent_app(action, "parent-app", hooks);

    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("parent app registration should succeed");

    let _ = app
        .step(None)
        .expect("first step should succeed")
        .expect("first step should execute");
    let _ = app
        .step(None)
        .expect("second step should succeed")
        .expect("second step should execute");

    let children_path = project_app_dir(&storage_root, project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let children = read_jsonl(&children_path);
    assert_eq!(
        children.len(),
        2,
        "stable child ids should avoid duplicate spawn_start events across repeated parent runs"
    );

    let child_ids: Vec<String> = children
        .iter()
        .map(|entry| {
            entry["child"]["app_id"]
                .as_str()
                .expect("child app_id should exist")
                .to_string()
        })
        .collect();
    let unique_child_ids: BTreeSet<String> = child_ids.iter().cloned().collect();
    assert_eq!(
        unique_child_ids.len(),
        2,
        "expected stable child app ids across repeated parent runs"
    );
    let expected_child_ids = BTreeSet::from([
        stable_child_app_id("parent-app", "0-0"),
        stable_child_app_id("parent-app", "1-0"),
    ]);
    assert_eq!(unique_child_ids, expected_child_ids);

    let mut per_sequence = IndexMap::new();
    for entry in &children {
        let sequence_id = entry["sequence_id"]
            .as_u64()
            .expect("sequence_id should be an unsigned integer");
        *per_sequence.entry(sequence_id).or_insert(0usize) += 1;
    }
    assert_eq!(per_sequence.get(&0), Some(&2));
    assert!(
        per_sequence.get(&1).is_none(),
        "duplicate child registrations should not be re-emitted for later parent sequences"
    );
}

#[test]
fn map_states_tracking_preserves_real_child_order_without_reserved_context_logging() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "parallelism_map_states_tracking_contract";
    let tracker = Arc::new(
        LocalTrackingClient::new(project, &storage_root)
            .expect("tracking client should initialize"),
    );

    let tracker_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![tracker_hook], Vec::new());

    let child_graph = runnable_graph_from_action(
        "child_action",
        FunctionActionBuilder::new()
            .reads(["value"])
            .writes(["value"])
            .with_source_code("fn child_action(state, _ctx) -> value { state[\"value\"] + 1 }")
            .build_sync(|state, _ctx| {
                let next_value = state.get("value").and_then(Value::as_i64).unwrap_or(0) + 1;
                map_from_pairs([("value", json!(next_value))])
            })
            .expect("action should build"),
    );
    let splitter = Arc::new(
        |state: &State, _ctx: &ActionContext| -> Result<Vec<State>, ApplicationError> {
            let values = state
                .get("values")
                .and_then(Value::as_array)
                .expect("values should be an array");
            Ok(values
                .iter()
                .map(|value| {
                    state_from_pairs([(
                        "value",
                        json!(value.as_i64().expect("values should contain integers")),
                    )])
                })
                .collect())
        },
    );
    let action = ParallelMap::new(
        ParallelTaskSource::states(child_graph, splitter),
        vec!["values".to_string()],
        vec!["child_states".to_string()],
        vec![],
        CascadeMode::None,
    )
    .with_source_code(
        "fn parallel(state, _ctx) -> child_states { state[\"values\"].map(|value| child_action(value)) }",
    );
    let mut app = build_single_action_app(
        state_from_pairs([("values", json!([1, 2]))]),
        "parallel",
        action,
        "parent-app",
        hooks,
        None,
    );

    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("parent app registration should succeed");

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");
    assert_eq!(child_i64_values_in_state(&step.state, "value"), vec![2, 3]);

    let expected_child_ids = vec![
        stable_child_app_id("parent-app", "0-0"),
        stable_child_app_id("parent-app", "0-1"),
    ];
    let children_path = project_app_dir(&storage_root, project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let children = read_jsonl(&children_path);
    let actual_child_ids: Vec<String> = children
        .iter()
        .map(|entry| {
            entry["child"]["app_id"]
                .as_str()
                .expect("child app_id should exist")
                .to_string()
        })
        .collect();
    assert_eq!(actual_child_ids, expected_child_ids);
    assert!(children
        .iter()
        .all(|entry| entry["child"]["partition_key"] == json!("pk")));

    let parent_log_path = project_app_dir(&storage_root, project, "parent-app")
        .join(LocalTrackingClient::LOG_FILENAME);
    let parent_log = read_jsonl(&parent_log_path);
    let begin_inputs = parent_log
        .iter()
        .find(|entry| entry["type"] == "begin_entry")
        .and_then(|entry| entry["inputs"].as_object())
        .expect("parent begin_entry should include an input object");
    assert!(!begin_inputs.contains_key("__context"));
    assert!(!begin_inputs.contains_key("__tracer"));
}

#[test]
fn cross_action_overlapping_task_keys_reuse_child_identity() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "parallelism_tracking_parity_overlap_contract";
    let tracker = Arc::new(
        LocalTrackingClient::new(project, &storage_root)
            .expect("tracking client should initialize"),
    );
    let tracker_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![tracker_hook], Vec::new());

    let probe_graph = |name: &'static str| {
        runnable_graph_from_action(
            name,
            FunctionActionBuilder::new()
                .writes(["seen_app_id"])
                .with_source_code(format!(
                    "fn {name}(_state, ctx) -> seen_app_id {{ seen_app_id: ctx.app_context.app_id }}"
                ))
                .build_sync(|_state, ctx| {
                    let app_id = ctx
                        .app_context
                        .as_ref()
                        .map(|context| context.app_id.clone())
                        .expect("application context should exist in child action");
                    map_from_pairs([("seen_app_id", json!(app_id))])
                })
                .expect("action should build"),
        )
    };

    let parallel_one = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![probe_graph("child_probe_one")],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    )
    .with_source_code(
        "fn parallel_one(state, _ctx) -> child_states { ParallelTaskSource::graphs([child_probe_one], state.clone()) }",
    );
    let parallel_two = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![probe_graph("child_probe_two")],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    )
    .with_source_code(
        "fn parallel_two(state, _ctx) -> child_states { ParallelTaskSource::graphs([child_probe_two], state.clone()) }",
    );

    let mut app = ApplicationBuilder::new()
        .with_state(State::default())
        .expect("state should configure")
        .with_actions(vec![
            ("parallel_one", parallel_one),
            ("parallel_two", parallel_two),
        ])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "parallel_one",
            "parallel_two",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_entrypoint("parallel_one")
        .expect("entrypoint should configure")
        .with_identifiers("parent-app", Some("pk".to_string()), None)
        .expect("identifiers should configure")
        .with_hooks(hooks)
        .expect("hooks should configure")
        .build()
        .expect("application should build");

    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("parent app registration should succeed");

    let first_step = app
        .step(None)
        .expect("first step should succeed")
        .expect("first step should execute");
    let second_step = app
        .step(None)
        .expect("second step should succeed")
        .expect("second step should execute");

    let first_child_id = child_seen_app_ids_in_state(&first_step.state)
        .into_iter()
        .next()
        .expect("first step should emit one child id");
    let second_child_id = child_seen_app_ids_in_state(&second_step.state)
        .into_iter()
        .next()
        .expect("second step should emit one child id");
    assert_eq!(
        first_child_id, second_child_id,
        "overlapping task key 0-0 across parent actions should reuse the Burr child id seed"
    );
    assert_eq!(first_child_id, stable_child_app_id("parent-app", "0-0"));
    assert_eq!(second_child_id, stable_child_app_id("parent-app", "0-0"));
    assert_eq!(first_child_id, second_child_id);

    let children_path = project_app_dir(&storage_root, project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let children = read_jsonl(&children_path);
    assert_eq!(
        children.len(),
        1,
        "reused child ids should suppress duplicate registration events"
    );
    let tracked_child_ids: BTreeSet<String> = children
        .iter()
        .map(|entry| {
            entry["child"]["app_id"]
                .as_str()
                .expect("child app_id should exist")
                .to_string()
        })
        .collect();
    assert_eq!(tracked_child_ids, BTreeSet::from([first_child_id.clone()]));
    let sequence_ids: BTreeSet<u64> = children
        .iter()
        .filter_map(|entry| entry["sequence_id"].as_u64())
        .collect();
    assert_eq!(sequence_ids, BTreeSet::from([0]));
    assert_eq!(children[0]["child"]["partition_key"], json!("pk"));
}

#[test]
fn repeated_parent_steps_reuse_same_child_id_sets() {
    let probe_graph = |name: &'static str| {
        runnable_graph_from_action(
            name,
            FunctionActionBuilder::new()
                .writes(["seen_app_id"])
                .build_sync(|_state, ctx| {
                    let app_id = ctx
                        .app_context
                        .as_ref()
                        .map(|context| context.app_id.clone())
                        .expect("application context should exist in child action");
                    map_from_pairs([("seen_app_id", json!(app_id))])
                })
                .expect("action should build"),
        )
    };

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![probe_graph("child_a"), probe_graph("child_b")],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );
    let mut app = build_looping_parent_app(action, "parent-app", LifecycleAdapterSet::default());

    let first_step = app
        .step(None)
        .expect("first step should succeed")
        .expect("first step should execute");
    let second_step = app
        .step(None)
        .expect("second step should succeed")
        .expect("second step should execute");

    let first_child_ids = child_seen_app_ids_in_state(&first_step.state);
    let second_child_ids = child_seen_app_ids_in_state(&second_step.state);

    assert_eq!(first_child_ids.len(), 2);
    assert_eq!(second_child_ids.len(), 2);
    assert_eq!(
        first_child_ids, second_child_ids,
        "repeated parent steps should reuse the same child app id set"
    );
}

#[test]
fn shared_persister_counts_parent_and_child_saves() {
    let counting_persister = Arc::new(CountingPersister::default());
    let persister_trait: Arc<dyn BaseStatePersister> = counting_persister.clone();

    let graphs = vec![
        runnable_graph_from_action(
            "child_a",
            FunctionActionBuilder::new()
                .writes(["output"])
                .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
                .expect("action should build"),
        ),
        runnable_graph_from_action(
            "child_b",
            FunctionActionBuilder::new()
                .writes(["output"])
                .build_sync(|_state, _ctx| map_from_pairs([("output", json!(2))]))
                .expect("action should build"),
        ),
    ];

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        Some(persister_trait),
    );

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        counting_persister.save_count(),
        3,
        "expected one parent save + two child saves"
    );
}

#[test]
fn parallel_child_reruns_from_parent_inputs_on_parent_reentry_without_initializer() {
    let recording_persister = Arc::new(RecordingKeyPersister::default());
    let persister_trait: Arc<dyn BaseStatePersister> = recording_persister.clone();

    let child_graph = runnable_graph_from_action(
        "child",
        FunctionActionBuilder::new()
            .reads(["value"])
            .writes(["seen_value"])
            .build_sync(|state, _ctx| {
                let value = state
                    .get("value")
                    .and_then(Value::as_i64)
                    .expect("value should be an i64");
                map_from_pairs([("seen_value", json!(value))])
            })
            .expect("action should build"),
    );

    let splitter = Arc::new(
        |state: &State, _ctx: &ActionContext| -> Result<Vec<State>, ApplicationError> {
            let inputs = state
                .get("inputs")
                .and_then(Value::as_array)
                .ok_or_else(|| app_error("inputs must be an array"))?;
            Ok(inputs
                .iter()
                .cloned()
                .map(|value| state_from_pairs([("value", value)]))
                .collect())
        },
    );
    let reducer = Arc::new(|states: Vec<State>| -> Result<State, ApplicationError> {
        let seen_values = states
            .iter()
            .map(|state| {
                state
                    .get("seen_value")
                    .cloned()
                    .expect("seen_value should be present")
            })
            .collect::<Vec<_>>();
        Ok(state_from_pairs([(
            "seen_values",
            Value::Array(seen_values),
        )]))
    });
    let parallel = ParallelMap::new(
        ParallelTaskSource::states(child_graph, splitter),
        vec!["inputs".to_string()],
        vec!["seen_values".to_string()],
        vec![],
        CascadeMode::Fixed(reducer),
    );

    let set_inputs = FunctionActionBuilder::new()
        .inputs(["base"])
        .writes(["inputs"])
        .build_sync(|_state, ctx| {
            let base = ctx
                .inputs
                .get("base")
                .and_then(Value::as_i64)
                .expect("base runtime input should be an i64");
            map_from_pairs([("inputs", json!([base, base + 1]))])
        })
        .expect("set_inputs action should build");

    let mut app =
        rurr_testkit::application_fixture::ApplicationFixtureBuilder::new(State::default())
            .expect("state should configure")
            .with_action("set_inputs", set_inputs)
            .expect("set_inputs should configure")
            .with_action("parallel", parallel)
            .expect("parallel should configure")
            .with_transitions(vec![
                Transition::new("set_inputs", "parallel", Condition::default()),
                Transition::new("parallel", "set_inputs", Condition::default()),
            ])
            .expect("transitions should configure")
            .with_entrypoint("set_inputs")
            .expect("entrypoint should configure")
            .with_identifiers("parent-app", Some("pk".to_string()), None)
            .expect("identifiers should configure")
            .with_hooks(LifecycleAdapterSet::default())
            .expect("hooks should configure")
            .with_sync_persister(persister_trait)
            .expect("state persister spec should configure")
            .build()
            .expect("application should build");

    let first = app
        .run_with_options(
            rurr_core::ExecutionOptions::new()
                .with_inputs(map_from_pairs([("base", json!(1))]))
                .halt_after(["parallel"]),
        )
        .expect("first run should succeed");
    assert_eq!(first.state.get("seen_values"), Some(&json!([1, 2])));

    let second = app
        .run_with_options(
            rurr_core::ExecutionOptions::new()
                .with_inputs(map_from_pairs([("base", json!(7))]))
                .halt_after(["parallel"]),
        )
        .expect("second run should succeed");
    assert_eq!(
        second.state.get("seen_values"),
        Some(&json!([7, 8])),
        "second run should rerun child tasks from the new parent inputs when no initializer is configured"
    );
}

#[test]
fn repeated_parallel_runs_reuse_child_persistence_app_ids() {
    let recording_persister = Arc::new(RecordingKeyPersister::default());
    let persister_trait: Arc<dyn BaseStatePersister> = recording_persister.clone();

    let graphs = two_constant_output_sync_child_graphs(("child_a", 1), ("child_b", 2));

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );
    let mut app = build_sync_persister_parent_app(
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        persister_trait,
    );

    let _ = app
        .step(None)
        .expect("first step should succeed")
        .expect("first step should execute");
    let _ = app
        .step(None)
        .expect("second step should succeed")
        .expect("second step should execute");

    let child_keys: Vec<(String, u64)> = recording_persister
        .saved_keys()
        .into_iter()
        .filter(|(app_id, _)| app_id != "parent-app")
        .collect();
    assert_eq!(
        child_keys.len(),
        4,
        "completed child runs should persist again on repeated parent executions when no initializer is configured"
    );
    let unique_child_app_ids: BTreeSet<String> = child_keys
        .iter()
        .map(|(app_id, _)| app_id.clone())
        .collect();
    assert_eq!(
        unique_child_app_ids.len(),
        2,
        "child persistence app ids should be reused across repeated parent runs"
    );

    let mut sequence_ids_by_app: IndexMap<String, Vec<u64>> = IndexMap::new();
    for (app_id, sequence_id) in child_keys {
        sequence_ids_by_app
            .entry(app_id)
            .or_default()
            .push(sequence_id);
    }
    assert_eq!(sequence_ids_by_app.len(), 2);
    for (app_id, sequence_ids) in &sequence_ids_by_app {
        assert_eq!(
            sequence_ids.len(),
            2,
            "each reused child app id should persist each completed rerun separately: {app_id}"
        );
        assert!(
            sequence_ids.iter().all(|sequence_id| *sequence_id == 0),
            "fresh child reruns without initialization should start at sequence id 0 for {app_id}: {sequence_ids:?}"
        );
    }
}
