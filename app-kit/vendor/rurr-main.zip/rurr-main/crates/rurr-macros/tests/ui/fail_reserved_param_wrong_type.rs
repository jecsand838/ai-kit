use rurr_core::action::{ActionContext, ActionError, ActionResult};
use rurr_core::state::State;

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
fn wrong_context_type(state: &State, ctx: ActionContext) -> Result<ActionResult, ActionError> {
    let _ = (state, ctx);
    Ok(ActionResult::new(Default::default(), Default::default()))
}

fn main() {}
