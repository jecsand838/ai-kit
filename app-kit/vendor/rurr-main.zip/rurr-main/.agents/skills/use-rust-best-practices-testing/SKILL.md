---
name: use-rust-best-practices-testing
description: "Apply this when adding, moving, fixing, or reviewing Rust tests. Use it to choose between unit, integration, doctest, binary-smoke, and end-to-end tests; to place tests correctly in source files, crate-level tests/, or dedicated workspace e2e crates; and to build test flows that use fakes for unit tests but live dependencies for integration and e2e tests via testcontainers, Docker Compose, dev containers, or test credentials."
---

# Rust testing best practices

Use this skill when the task changes Rust tests or test strategy.

## When to use

Use it when the task:

- adds or fixes tests
- asks where a test should live
- needs doctests or rustdoc lint guidance
- exercises a compiled binary
- needs Docker/testcontainers/dev-container/live-dependency coverage
- needs an e2e strategy across multiple crates or services

## Do not use this skill alone when

- the task is mostly about crate/workspace structure → also load `$use-rust-best-practices-architecture`
- the task is mostly about async scheduling/shutdown/races → also load `$use-rust-best-practices-async`
- the task is mostly about HTTP/gRPC/database clients → also load `$use-rust-best-practices-networking`

## Testing model

1. Prefer the **narrowest test level** that proves the behavior.
2. Keep **unit tests** in the same source file and use fakes or mocks.
3. Keep **integration tests** under the crate being tested and use the public API with real dependencies.
4. Add **doctests** for public APIs that benefit from executable examples.
5. Add **binary smoke tests** in `tests/` when CLI behavior matters.
6. Keep **workspace e2e tests** in a dedicated e2e crate or app boundary package, and boot the actual system.

Rurr workspace carve-out:

- For provider/backend behavior and production fallback semantics, do not let a fake-backed unit
  test become the authoritative proof. In Rurr, that behavior needs a named strict
  live/backend/provider or contract proof lane.
- If the honest current behavior is "not implemented" or "not supported", prefer explicit
  `Unsupported`, `NotYetImplemented`, or typed configuration/startup errors over synthetic
  fallbacks.

## Default rules

- Unit tests should not require the network or real infrastructure.
- Integration tests should not mock dependencies you do not own.
- E2E tests should validate the full external contract, not internal implementation.
- Async tests should avoid timing flakiness and race-prone sleeps when deterministic alternatives exist.
- Prefer `testcontainers-modules` when a maintained module exists; otherwise fall back to `GenericImage` or Docker Compose.
- In Rurr, route proof gaps for external/provider behavior to the named strict proof lane or to
  `$audit-workspace-for-shims`; do not paper over them with fake local expectations.

## Load these references directly when needed

- `references/testing.md` — unit/integration/doctest/binary/e2e placement, live dependency patterns, and bad-vs-best examples.

## Load these templates when useful

- `assets/templates/unit_test_with_fake.rs`
- `assets/templates/bin_smoke_test.rs`
- `assets/templates/doctest_examples.rs`

## Companion skills

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
