use crate::backend::BackendError;
use rurr_core::tracking::{
    S3AddressingStyle, S3ClientSettings, S3LayoutError, S3Prefix, S3TransportError,
    DEFAULT_DATA_PREFIX, DEFAULT_SNAPSHOT_PREFIX,
};
use std::path::PathBuf;
use std::time::Duration;

const DEFAULT_PRIOR_SNAPSHOTS_TO_KEEP: usize = 5;
const DEFAULT_MAX_PATHS_PER_PROJECT: usize = 200;
const DEFAULT_AWS_MAX_CONCURRENCY: usize = 100;
const DEFAULT_UPDATE_INTERVAL: Duration = Duration::from_secs(120);
const DEFAULT_SNAPSHOT_INTERVAL: Duration = Duration::from_secs(3600);

/// Typed S3 tracking-server backend configuration.
///
/// This config embeds shared [`S3ClientSettings`] so the server and S3 tracking
/// client agree on bucket, region, endpoint, addressing, and credential
/// validation. [`S3IndexingPolicy`] owns the local SQLite index, snapshot
/// retention, provider fanout, and CLI maintenance cadence.
///
/// # Examples
///
/// ```
/// use rurr_tracking_server::backend::s3::S3BackendConfig;
///
/// let config = S3BackendConfig::new(
///     "tracking-bucket",
///     "us-east-1",
///     std::env::temp_dir().join("rurr-s3-doc-index.sqlite"),
/// )?;
///
/// assert_eq!(config.transport.bucket(), "tracking-bucket");
/// assert_eq!(config.data_prefix.as_str(), "data");
/// assert_eq!(config.indexing.snapshot_prefix.as_str(), "snapshots");
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct S3BackendConfig {
    /// S3 transport settings used for SDK clients and object operations.
    pub transport: S3ClientSettings,
    /// Prefix containing tracking data objects.
    pub data_prefix: S3Prefix,
    /// Local indexing, snapshot, and periodic job policy.
    pub indexing: S3IndexingPolicy,
}

/// Local index, snapshot, listing, and periodic-job policy for the S3 backend.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct S3IndexingPolicy {
    /// Prefix containing SQLite snapshot objects.
    pub snapshot_prefix: S3Prefix,
    /// Local SQLite index path.
    pub db_path: PathBuf,
    /// Whether startup should restore a snapshot when the local DB is absent.
    pub load_snapshot_on_start: bool,
    /// Number of prior snapshots to retain.
    pub prior_snapshots_to_keep: usize,
    /// Maximum S3 object keys to process per project per index update.
    pub max_paths_per_project: usize,
    /// Maximum concurrent S3 HEAD/GET provider operations during indexing
    /// and app detail reads.
    pub aws_max_concurrency: usize,
    /// Optional S3 ListObjectsV2 page size. `None` uses the provider default.
    pub list_page_size: Option<i32>,
    /// Interval between periodic index updates when served by the CLI.
    pub update_interval: Duration,
    /// Interval between periodic SQLite snapshot uploads when served by the CLI.
    pub snapshot_interval: Duration,
}

impl S3IndexingPolicy {
    /// Creates default S3 backend indexing policy for the local SQLite path.
    pub fn new(db_path: impl Into<PathBuf>) -> Result<Self, BackendError> {
        Ok(Self {
            snapshot_prefix: S3Prefix::new(DEFAULT_SNAPSHOT_PREFIX).map_err(layout_error)?,
            db_path: db_path.into(),
            load_snapshot_on_start: true,
            prior_snapshots_to_keep: DEFAULT_PRIOR_SNAPSHOTS_TO_KEEP,
            max_paths_per_project: DEFAULT_MAX_PATHS_PER_PROJECT,
            aws_max_concurrency: DEFAULT_AWS_MAX_CONCURRENCY,
            list_page_size: None,
            update_interval: DEFAULT_UPDATE_INTERVAL,
            snapshot_interval: DEFAULT_SNAPSHOT_INTERVAL,
        })
    }

    pub(super) fn validate(&self) -> Result<(), BackendError> {
        if self.prior_snapshots_to_keep == 0 {
            return Err(config_error(
                "prior_snapshots_to_keep must be greater than zero",
            ));
        }
        if self.max_paths_per_project == 0 {
            return Err(config_error(
                "max_paths_per_project must be greater than zero",
            ));
        }
        if self.aws_max_concurrency == 0 {
            return Err(config_error(
                "aws_max_concurrency must be greater than zero",
            ));
        }
        if self.update_interval.is_zero() {
            return Err(config_error("update_interval must be greater than zero"));
        }
        if self.snapshot_interval.is_zero() {
            return Err(config_error("snapshot_interval must be greater than zero"));
        }
        if let Some(page_size) = self.list_page_size {
            if !(1..=1000).contains(&page_size) {
                return Err(config_error("list_page_size must be in 1..=1000"));
            }
        }
        Ok(())
    }
}

/// Explicit S3 backend configuration overrides, usually sourced from CLI flags.
///
/// Fields left as `None` are resolved by
/// [`S3BackendConfig::from_env_and_overrides`] using Rurr-specific environment
/// variables, then compatible AWS/Burr aliases where supported. Nested
/// `Option<Option<T>>` values distinguish "no override" from "explicitly clear
/// this optional setting".
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct S3BackendConfigOverrides {
    /// Local SQLite index path override.
    pub db_path: Option<PathBuf>,
    /// S3 bucket override.
    pub bucket: Option<String>,
    /// AWS region override.
    pub region: Option<String>,
    /// Custom endpoint URL override.
    pub endpoint_url: Option<String>,
    /// S3 addressing style override.
    pub addressing_style: Option<S3AddressingStyle>,
    /// Tracking data prefix override.
    pub data_prefix: Option<S3Prefix>,
    /// Snapshot prefix override.
    pub snapshot_prefix: Option<S3Prefix>,
    /// Snapshot restore-on-start override.
    pub load_snapshot_on_start: Option<bool>,
    /// Snapshot retention count override.
    pub prior_snapshots_to_keep: Option<usize>,
    /// Maximum paths per project override.
    pub max_paths_per_project: Option<usize>,
    /// Maximum concurrent AWS operations override.
    pub aws_max_concurrency: Option<usize>,
    /// Optional ListObjectsV2 page size override.
    pub list_page_size: Option<Option<i32>>,
    /// Periodic index update interval override.
    pub update_interval: Option<Duration>,
    /// Periodic snapshot interval override.
    pub snapshot_interval: Option<Duration>,
    /// Static access key override.
    pub access_key_id: Option<String>,
    /// Static secret access key override.
    pub secret_access_key: Option<String>,
    /// Static session token override.
    pub session_token: Option<String>,
}

impl S3BackendConfig {
    /// Creates backend configuration for `bucket`, `region`, and local `db_path`.
    ///
    /// Construction is local-only. Provider clients are created by
    /// `S3Backend::new`, and snapshots/indexing happen only through backend
    /// operations.
    pub fn new(
        bucket: impl Into<String>,
        region: impl Into<String>,
        db_path: impl Into<PathBuf>,
    ) -> Result<Self, BackendError> {
        let bucket = non_empty(bucket.into(), "bucket")?;
        let region = non_empty(region.into(), "region")?;
        Ok(Self {
            transport: S3ClientSettings::new(
                bucket,
                region,
                None,
                S3AddressingStyle::VirtualHosted,
                None,
                None,
                None,
            ),
            data_prefix: S3Prefix::new(DEFAULT_DATA_PREFIX).map_err(layout_error)?,
            indexing: S3IndexingPolicy::new(db_path)?,
        })
    }

    /// Builds config from environment values plus explicit overrides.
    ///
    /// Explicit overrides win over Rurr-specific environment variables, which
    /// win over AWS-compatible environment variables where applicable. Missing
    /// bucket, region, or static credential values return a configuration
    /// error.
    ///
    /// # Errors
    ///
    /// Returns a backend configuration error for missing required bucket,
    /// region, or static credential values, malformed prefixes, invalid
    /// booleans or integers, unsafe addressing choices, and zero-valued
    /// operational limits.
    pub fn from_env_and_overrides(
        default_db_path: impl Into<PathBuf>,
        overrides: S3BackendConfigOverrides,
    ) -> Result<Self, BackendError> {
        let source = ConfigSource::new(default_db_path.into(), overrides);
        let bucket = source.required_string(
            source.overrides.bucket.as_deref(),
            &["RURR_S3_BUCKET", "BURR_S3_BUCKET"],
            "missing S3 bucket: set --s3-bucket, RURR_S3_BUCKET, or BURR_S3_BUCKET",
        )?;
        let region = source.required_string(
            source.overrides.region.as_deref(),
            &["RURR_S3_REGION", "AWS_REGION", "AWS_DEFAULT_REGION"],
            "missing S3 region: set --s3-region, RURR_S3_REGION, AWS_REGION, or AWS_DEFAULT_REGION",
        )?;
        let mut config = Self::new(bucket.clone(), region.clone(), source.db_path()?)?;
        config.transport = S3ClientSettings::new(
            bucket,
            region,
            source.optional_string(
                source.overrides.endpoint_url.as_deref(),
                &["RURR_S3_ENDPOINT_URL", "AWS_ENDPOINT_URL_S3"],
                "endpoint_url",
            )?,
            source.addressing_style()?,
            source.optional_string(
                source.overrides.access_key_id.as_deref(),
                &["RURR_S3_ACCESS_KEY_ID", "AWS_ACCESS_KEY_ID"],
                "access_key_id",
            )?,
            source.optional_string(
                source.overrides.secret_access_key.as_deref(),
                &["RURR_S3_SECRET_ACCESS_KEY", "AWS_SECRET_ACCESS_KEY"],
                "secret_access_key",
            )?,
            source.optional_string(
                source.overrides.session_token.as_deref(),
                &["RURR_S3_SESSION_TOKEN", "AWS_SESSION_TOKEN"],
                "session_token",
            )?,
        );
        config.data_prefix = source.prefix(
            source.overrides.data_prefix.as_ref(),
            &["RURR_S3_DATA_PREFIX"],
            config.data_prefix.clone(),
        )?;
        config.indexing.snapshot_prefix = source.prefix(
            source.overrides.snapshot_prefix.as_ref(),
            &["RURR_S3_SNAPSHOT_PREFIX"],
            config.indexing.snapshot_prefix.clone(),
        )?;
        config.indexing.load_snapshot_on_start = source.bool(
            source.overrides.load_snapshot_on_start,
            &[
                "RURR_S3_LOAD_SNAPSHOT_ON_START",
                "BURR_LOAD_SNAPSHOT_ON_START",
            ],
            config.indexing.load_snapshot_on_start,
        )?;
        config.indexing.prior_snapshots_to_keep = source.positive_usize(
            source.overrides.prior_snapshots_to_keep,
            &[
                "RURR_S3_PRIOR_SNAPSHOTS_TO_KEEP",
                "BURR_PRIOR_SNAPSHOTS_TO_KEEP",
            ],
            config.indexing.prior_snapshots_to_keep,
            "prior_snapshots_to_keep",
        )?;
        config.indexing.max_paths_per_project = source.positive_usize(
            source.overrides.max_paths_per_project,
            &["RURR_S3_MAX_PATHS_PER_PROJECT"],
            config.indexing.max_paths_per_project,
            "max_paths_per_project",
        )?;
        config.indexing.aws_max_concurrency = source.positive_usize(
            source.overrides.aws_max_concurrency,
            &["RURR_S3_AWS_MAX_CONCURRENCY", "BURR_AWS_MAX_CONCURRENCY"],
            config.indexing.aws_max_concurrency,
            "aws_max_concurrency",
        )?;
        config.indexing.list_page_size =
            source.list_page_size(source.overrides.list_page_size, &["RURR_S3_LIST_PAGE_SIZE"])?;
        config.indexing.update_interval = source.positive_duration_ms(
            source.overrides.update_interval,
            &[
                "RURR_S3_UPDATE_INTERVAL_MS",
                "BURR_UPDATE_INTERVAL_MILLISECONDS",
            ],
            config.indexing.update_interval,
            "update_interval",
        )?;
        config.indexing.snapshot_interval = source.positive_duration_ms(
            source.overrides.snapshot_interval,
            &[
                "RURR_S3_SNAPSHOT_INTERVAL_MS",
                "BURR_SNAPSHOT_INTERVAL_MILLISECONDS",
            ],
            config.indexing.snapshot_interval,
            "snapshot_interval",
        )?;
        config.validate()?;
        Ok(config)
    }

    pub(super) fn validate(&self) -> Result<(), BackendError> {
        self.indexing.validate()?;
        self.transport.validate().map_err(transport_config_error)?;
        Ok(())
    }

    pub(super) async fn sdk_client(&self) -> Result<aws_sdk_s3::Client, BackendError> {
        self.transport
            .sdk_client("rurr-s3-backend")
            .await
            .map_err(transport_config_error)
    }
}

fn non_empty(value: String, field: &'static str) -> Result<String, BackendError> {
    if value.trim().is_empty() {
        Err(config_error(format!("missing {field}")))
    } else {
        Ok(value)
    }
}

fn layout_error(error: S3LayoutError) -> BackendError {
    config_error(error.to_string())
}

fn transport_config_error(error: S3TransportError) -> BackendError {
    config_error(match error {
        S3TransportError::MissingConfig(field) => format!("missing {field} for S3 backend"),
        S3TransportError::InvalidEndpoint(message)
        | S3TransportError::InvalidAddressing(message) => message,
    })
}

fn config_error(message: impl Into<String>) -> BackendError {
    BackendError::Configuration {
        message: message.into(),
    }
}

struct ConfigSource {
    env: EnvSource,
    overrides: S3BackendConfigOverrides,
    default_db_path: PathBuf,
}

impl ConfigSource {
    fn new(default_db_path: PathBuf, overrides: S3BackendConfigOverrides) -> Self {
        Self {
            env: EnvSource,
            overrides,
            default_db_path,
        }
    }

    fn required_string(
        &self,
        override_: Option<&str>,
        keys: &[&'static str],
        missing_message: &'static str,
    ) -> Result<String, BackendError> {
        self.value(override_, keys)?
            .map(|value| {
                if value.trim().is_empty() {
                    Err(config_error(missing_message))
                } else {
                    Ok(value)
                }
            })
            .transpose()?
            .ok_or_else(|| config_error(missing_message))
    }

    fn optional_string(
        &self,
        override_: Option<&str>,
        keys: &[&'static str],
        field: &'static str,
    ) -> Result<Option<String>, BackendError> {
        self.value(override_, keys)?
            .map(|value| non_empty(value, field))
            .transpose()
    }

    fn db_path(&self) -> Result<PathBuf, BackendError> {
        if let Some(path) = self.overrides.db_path.as_ref() {
            return Ok(path.clone());
        }
        self.optional_string(None, &["RURR_S3_DB_PATH"], "db_path")
            .map(|value| {
                value
                    .map(PathBuf::from)
                    .unwrap_or_else(|| self.default_db_path.clone())
            })
    }

    fn addressing_style(&self) -> Result<S3AddressingStyle, BackendError> {
        if let Some(value) = self.overrides.addressing_style {
            return Ok(value);
        }
        self.value(None, &["RURR_S3_ADDRESSING_STYLE"])?
            .map(|value| S3AddressingStyle::parse(&value).map_err(layout_error))
            .transpose()
            .map(|value| value.unwrap_or(S3AddressingStyle::VirtualHosted))
    }

    fn prefix(
        &self,
        override_: Option<&S3Prefix>,
        keys: &[&'static str],
        default: S3Prefix,
    ) -> Result<S3Prefix, BackendError> {
        match override_ {
            Some(value) => Ok(value.clone()),
            None => self
                .value(None, keys)?
                .map(|value| S3Prefix::new(value).map_err(layout_error))
                .transpose()
                .map(|value| value.unwrap_or(default)),
        }
    }

    fn bool(
        &self,
        override_: Option<bool>,
        keys: &[&'static str],
        default: bool,
    ) -> Result<bool, BackendError> {
        match override_ {
            Some(value) => Ok(value),
            None => self
                .named_value(keys)?
                .map(|value| parse_bool(value.name, &value.value))
                .transpose()
                .map(|value| value.unwrap_or(default)),
        }
    }

    fn positive_usize(
        &self,
        override_: Option<usize>,
        keys: &[&'static str],
        default: usize,
        field: &'static str,
    ) -> Result<usize, BackendError> {
        let value = match override_ {
            Some(value) => value,
            None => self
                .named_value(keys)?
                .map(|value| parse_usize(value.name, &value.value))
                .transpose()?
                .unwrap_or(default),
        };
        positive(value, field)
    }

    fn positive_duration_ms(
        &self,
        override_: Option<Duration>,
        keys: &[&'static str],
        default: Duration,
        field: &'static str,
    ) -> Result<Duration, BackendError> {
        let value = match override_ {
            Some(value) => value,
            None => self
                .named_value(keys)?
                .map(|value| parse_duration_ms(value.name, &value.value))
                .transpose()?
                .unwrap_or(default),
        };
        if value.is_zero() {
            Err(config_error(format!("{field} must be greater than zero")))
        } else {
            Ok(value)
        }
    }

    fn list_page_size(
        &self,
        override_: Option<Option<i32>>,
        keys: &[&'static str],
    ) -> Result<Option<i32>, BackendError> {
        match override_ {
            Some(value) => Ok(value),
            None => self
                .named_value(keys)?
                .map(|value| parse_i32(value.name, &value.value))
                .transpose(),
        }
    }

    fn value(
        &self,
        override_: Option<&str>,
        keys: &[&'static str],
    ) -> Result<Option<String>, BackendError> {
        match override_ {
            Some(value) => Ok(Some(value.to_string())),
            None => self
                .named_value(keys)
                .map(|value| value.map(|value| value.value)),
        }
    }

    fn named_value(&self, keys: &[&'static str]) -> Result<Option<EnvValue>, BackendError> {
        self.env.first(keys)
    }
}

struct EnvSource;

struct EnvValue {
    name: &'static str,
    value: String,
}

impl EnvSource {
    fn first(&self, keys: &[&'static str]) -> Result<Option<EnvValue>, BackendError> {
        for name in keys {
            let Some(value) = std::env::var_os(name) else {
                continue;
            };
            let value = value
                .into_string()
                .map_err(|_| config_error(format!("{name} must be valid UTF-8")))?;
            return Ok(Some(EnvValue { name, value }));
        }
        Ok(None)
    }
}

fn positive(value: usize, field: &'static str) -> Result<usize, BackendError> {
    if value == 0 {
        Err(config_error(format!("{field} must be greater than zero")))
    } else {
        Ok(value)
    }
}

fn parse_bool(name: &'static str, raw: &str) -> Result<bool, BackendError> {
    match raw {
        "1" | "true" | "TRUE" | "yes" | "YES" => Ok(true),
        "0" | "false" | "FALSE" | "no" | "NO" => Ok(false),
        other => Err(config_error(format!(
            "{name} must be boolean, got '{other}'"
        ))),
    }
}

fn parse_usize(name: &'static str, raw: &str) -> Result<usize, BackendError> {
    raw.parse::<usize>()
        .map_err(|error| config_error(format!("{name} must be an unsigned integer: {error}")))
}

fn parse_i32(name: &'static str, raw: &str) -> Result<i32, BackendError> {
    raw.parse::<i32>()
        .map_err(|error| config_error(format!("{name} must be an integer: {error}")))
}

fn parse_duration_ms(name: &'static str, raw: &str) -> Result<Duration, BackendError> {
    let millis = raw
        .parse::<u64>()
        .map_err(|error| config_error(format!("{name} must be milliseconds: {error}")))?;
    Ok(Duration::from_millis(millis))
}
