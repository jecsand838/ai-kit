use opentelemetry_otlp::{
    LogExporter, Protocol, SpanExporter, OTEL_EXPORTER_OTLP_ENDPOINT,
    OTEL_EXPORTER_OTLP_LOGS_ENDPOINT, OTEL_EXPORTER_OTLP_TRACES_ENDPOINT,
};
use opentelemetry_sdk::trace::SdkTracerProvider;
use std::fmt::{Display, Formatter};

mod export;
mod provider;

use provider::install_provider_with_exporter;
pub use provider::{
    build_otlp_logger_provider, build_otlp_tracer_provider,
    build_otlp_tracer_provider_with_span_processors, build_resource, build_tracing_subscriber,
    install_tracing_subscriber_with_config, TracingSubscriberConfig,
};

const DEFAULT_SERVICE_NAME: &str = "rurr";

const OTEL_EXPORTER_OTLP_LOGS_PROTOCOL: &str = "OTEL_EXPORTER_OTLP_LOGS_PROTOCOL";
const OTEL_EXPORTER_OTLP_TRACES_PROTOCOL: &str = "OTEL_EXPORTER_OTLP_TRACES_PROTOCOL";

pub(crate) trait OtlpEnv {
    fn var(&self, key: &str) -> Option<String>;

    fn contains_key(&self, key: &str) -> bool;
}

struct ProcessOtlpEnv;

impl OtlpEnv for ProcessOtlpEnv {
    fn var(&self, key: &str) -> Option<String> {
        std::env::var(key).ok()
    }

    fn contains_key(&self, key: &str) -> bool {
        std::env::var_os(key).is_some()
    }
}

/// OTLP signal kinds supported by this crate.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OtlpSignal {
    /// Trace signal.
    Traces,
    /// Log signal.
    Logs,
}

impl OtlpSignal {
    fn protocol_env_var(self) -> &'static str {
        match self {
            Self::Traces => OTEL_EXPORTER_OTLP_TRACES_PROTOCOL,
            Self::Logs => OTEL_EXPORTER_OTLP_LOGS_PROTOCOL,
        }
    }

    fn endpoint_env_var(self) -> &'static str {
        match self {
            Self::Traces => OTEL_EXPORTER_OTLP_TRACES_ENDPOINT,
            Self::Logs => OTEL_EXPORTER_OTLP_LOGS_ENDPOINT,
        }
    }
}

/// Describes how to interpret OTLP endpoint configuration.
///
/// `CollectorBaseUrl` follows the OTLP convention where the signal-specific
/// `/v1/traces` or `/v1/logs` path is appended for HTTP/protobuf export.
/// `SignalUrl` is used as-is for the requested signal.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OtlpEndpoint {
    /// Collector base URL that still needs the standard signal path appended for OTLP/HTTP.
    CollectorBaseUrl(String),
    /// Fully qualified signal endpoint URL.
    SignalUrl(String),
}

impl OtlpEndpoint {
    pub(crate) fn from_env_reader(
        signal: OtlpSignal,
        env: &impl OtlpEnv,
    ) -> Result<Self, OtlpError> {
        if let Some(endpoint) = env.var(signal.endpoint_env_var()) {
            return Ok(Self::SignalUrl(endpoint));
        }
        if let Some(endpoint) = env.var(OTEL_EXPORTER_OTLP_ENDPOINT) {
            return Ok(Self::CollectorBaseUrl(endpoint));
        }
        Err(OtlpError::MissingEndpointConfiguration(signal))
    }
}

/// Configuration used to bootstrap OTLP traces and logs exports.
///
/// The config follows OTLP endpoint precedence: explicit signal endpoints win,
/// then collector base URLs, then standard environment variables when an
/// exporter is built. It does not install global providers by itself; use the
/// exporter or provider builders when the process is ready to initialize OTEL.
///
/// # Examples
///
/// ```
/// use rurr_otel::OtlpConfig;
///
/// let mut config = OtlpConfig::from_collector_endpoint("http://127.0.0.1:4318")
///     .with_logs_collector_endpoint("http://127.0.0.1:4318");
/// config.service_name = "docs-worker".to_string();
/// config.service_version = Some("1.2.3".to_string());
/// config = config.with_protocol(opentelemetry_otlp::Protocol::HttpBinary);
///
/// assert_eq!(config.service_name, "docs-worker");
/// assert_eq!(config.service_version.as_deref(), Some("1.2.3"));
/// ```
#[derive(Debug, Clone)]
pub struct OtlpConfig {
    /// Logical service name reported through OTEL resources.
    pub service_name: String,
    /// Optional service version reported through OTEL resources.
    pub service_version: Option<String>,
    /// Optional explicit protocol override. When absent, signal-specific OTLP
    /// protocol env vars are honored and otherwise default to `http/protobuf`.
    pub protocol: Option<Protocol>,
    pub(crate) traces_endpoint: Option<OtlpEndpoint>,
    pub(crate) logs_endpoint: Option<OtlpEndpoint>,
}

impl Default for OtlpConfig {
    fn default() -> Self {
        Self {
            service_name: DEFAULT_SERVICE_NAME.to_string(),
            service_version: option_env!("CARGO_PKG_VERSION").map(str::to_string),
            protocol: None,
            traces_endpoint: None,
            logs_endpoint: None,
        }
    }
}

impl OtlpConfig {
    /// Builds an OTLP config from the standard trace endpoint environment variables.
    ///
    /// This reads process environment and returns an error when neither the
    /// generic collector endpoint nor the traces endpoint is configured.
    ///
    /// # Errors
    ///
    /// Returns [`OtlpError::MissingEndpointConfiguration`] when no trace
    /// endpoint is available from `OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` or
    /// `OTEL_EXPORTER_OTLP_ENDPOINT`.
    pub fn from_env() -> Result<Self, OtlpError> {
        Self::from_env_reader(&ProcessOtlpEnv)
    }

    pub(crate) fn from_env_reader(env: &impl OtlpEnv) -> Result<Self, OtlpError> {
        Ok(Self::default().with_endpoint_config(
            OtlpSignal::Traces,
            OtlpEndpoint::from_env_reader(OtlpSignal::Traces, env)?,
        ))
    }

    /// Builds an OTLP config from an explicit collector base URL for traces.
    ///
    /// Add [`with_logs_collector_endpoint`](Self::with_logs_collector_endpoint)
    /// when logs should use the same collector.
    pub fn from_collector_endpoint<T>(endpoint: T) -> Self
    where
        T: Into<String>,
    {
        Self::default().with_traces_collector_endpoint(endpoint)
    }

    /// Builds an OTLP config from an explicit traces endpoint URL.
    ///
    /// The endpoint is used as-is for trace export rather than appending an
    /// OTLP signal path.
    pub fn from_traces_endpoint<T>(endpoint: T) -> Self
    where
        T: Into<String>,
    {
        Self::default().with_traces_endpoint(endpoint)
    }

    /// Sets an explicit traces collector base URL.
    pub fn with_traces_collector_endpoint<T>(mut self, endpoint: T) -> Self
    where
        T: Into<String>,
    {
        self.traces_endpoint = Some(OtlpEndpoint::CollectorBaseUrl(endpoint.into()));
        self
    }

    /// Sets an explicit traces endpoint URL.
    ///
    /// Use this when the caller already has a fully qualified `/v1/traces`
    /// endpoint.
    pub fn with_traces_endpoint<T>(mut self, endpoint: T) -> Self
    where
        T: Into<String>,
    {
        self.traces_endpoint = Some(OtlpEndpoint::SignalUrl(endpoint.into()));
        self
    }

    /// Sets an explicit logs collector base URL.
    pub fn with_logs_collector_endpoint<T>(mut self, endpoint: T) -> Self
    where
        T: Into<String>,
    {
        self.logs_endpoint = Some(OtlpEndpoint::CollectorBaseUrl(endpoint.into()));
        self
    }

    /// Sets an explicit logs endpoint URL.
    ///
    /// Use this when the caller already has a fully qualified `/v1/logs`
    /// endpoint.
    pub fn with_logs_endpoint<T>(mut self, endpoint: T) -> Self
    where
        T: Into<String>,
    {
        self.logs_endpoint = Some(OtlpEndpoint::SignalUrl(endpoint.into()));
        self
    }

    /// Sets one explicit protocol for both traces and logs.
    ///
    /// When this is absent, signal-specific OTLP protocol environment variables
    /// are honored, then HTTP/protobuf is used by default.
    pub fn with_protocol(mut self, protocol: Protocol) -> Self {
        self.protocol = Some(protocol);
        self
    }

    pub(crate) fn endpoint(&self, signal: OtlpSignal) -> Result<OtlpEndpoint, OtlpError> {
        self.endpoint_with_env(signal, &ProcessOtlpEnv)
    }

    pub(crate) fn endpoint_with_env(
        &self,
        signal: OtlpSignal,
        env: &impl OtlpEnv,
    ) -> Result<OtlpEndpoint, OtlpError> {
        match signal {
            OtlpSignal::Traces => &self.traces_endpoint,
            OtlpSignal::Logs => &self.logs_endpoint,
        }
        .clone()
        .map(Ok)
        .unwrap_or_else(|| OtlpEndpoint::from_env_reader(signal, env))
    }

    pub(crate) fn protocol_for(&self, signal: OtlpSignal) -> Result<Protocol, OtlpError> {
        self.protocol_for_with_env(signal, &ProcessOtlpEnv)
    }

    pub(crate) fn protocol_for_with_env(
        &self,
        signal: OtlpSignal,
        env: &impl OtlpEnv,
    ) -> Result<Protocol, OtlpError> {
        self.protocol
            .map(Ok)
            .unwrap_or_else(|| protocol_from_env_reader(signal, env))
    }

    fn with_endpoint_config(mut self, signal: OtlpSignal, endpoint: OtlpEndpoint) -> Self {
        match signal {
            OtlpSignal::Traces => self.traces_endpoint = Some(endpoint),
            OtlpSignal::Logs => self.logs_endpoint = Some(endpoint),
        }
        self
    }
}

/// Errors returned while initializing OTLP traces or logs exporters/providers.
#[derive(Debug, Clone)]
pub enum OtlpError {
    /// No OTLP endpoint configuration was provided for the requested signal.
    MissingEndpointConfiguration(OtlpSignal),
    /// An OTLP protocol environment value could not be parsed.
    InvalidProtocol {
        /// Signal whose protocol resolution failed.
        signal: OtlpSignal,
        /// Raw environment value that was rejected.
        value: String,
    },
    /// Building the exporter failed.
    ExporterBuild(String),
    /// The current runtime cannot safely run OTLP batch processors.
    ProviderRuntime(&'static str),
    /// Installing the tracing subscriber failed.
    SubscriberInstall(String),
}

impl Display for OtlpError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::MissingEndpointConfiguration(OtlpSignal::Traces) => write!(
                f,
                "OTLP tracing requires OTEL_EXPORTER_OTLP_ENDPOINT or OTEL_EXPORTER_OTLP_TRACES_ENDPOINT"
            ),
            Self::MissingEndpointConfiguration(OtlpSignal::Logs) => write!(
                f,
                "OTLP logging requires OTEL_EXPORTER_OTLP_ENDPOINT or OTEL_EXPORTER_OTLP_LOGS_ENDPOINT"
            ),
            Self::InvalidProtocol { signal, value } => write!(
                f,
                "invalid OTLP protocol `{value}` configured for {:?}; expected one of grpc, http/protobuf, or http/json",
                signal
            ),
            Self::ExporterBuild(message) => write!(f, "failed to build OTLP exporter: {message}"),
            Self::ProviderRuntime(message) => write!(f, "{message}"),
            Self::SubscriberInstall(message) => {
                write!(f, "failed to install tracing subscriber: {message}")
            }
        }
    }
}

impl std::error::Error for OtlpError {}

/// Returns whether any OTLP traces/logs endpoint configuration is present.
pub fn has_any_otlp_endpoint_configuration() -> bool {
    has_any_otlp_endpoint_configuration_reader(&ProcessOtlpEnv)
}

pub(crate) fn has_any_otlp_endpoint_configuration_reader(env: &impl OtlpEnv) -> bool {
    env.contains_key(OTEL_EXPORTER_OTLP_ENDPOINT)
        || env.contains_key(OTEL_EXPORTER_OTLP_TRACES_ENDPOINT)
        || env.contains_key(OTEL_EXPORTER_OTLP_LOGS_ENDPOINT)
}

/// Builds the default OTLP traces exporter from configuration.
pub fn build_otlp_span_exporter(config: &OtlpConfig) -> Result<SpanExporter, OtlpError> {
    export::build_otlp_span_exporter(config)
}

/// Builds the default OTLP logs exporter from configuration.
pub fn build_otlp_log_exporter(config: &OtlpConfig) -> Result<LogExporter, OtlpError> {
    export::build_otlp_log_exporter(config)
}

/// Builds the default OTLP traces exporter from environment and installs a tracing subscriber.
pub fn init_tracing() -> Result<SdkTracerProvider, OtlpError> {
    let config = OtlpConfig::from_env()?;
    let exporter = build_otlp_span_exporter(&config)?;
    provider::install_otlp_provider_with_exporter(exporter, &config)
}

/// Installs a tracing subscriber backed by a caller-supplied span exporter.
pub fn init_tracing_with_exporter<E>(
    exporter: E,
    config: &OtlpConfig,
) -> Result<SdkTracerProvider, OtlpError>
where
    E: opentelemetry_sdk::trace::SpanExporter + 'static,
{
    install_provider_with_exporter(exporter, config)
}

pub(crate) fn protocol_from_env_reader(
    signal: OtlpSignal,
    env: &impl OtlpEnv,
) -> Result<Protocol, OtlpError> {
    let value = env
        .var(signal.protocol_env_var())
        .or_else(|| env.var(opentelemetry_otlp::OTEL_EXPORTER_OTLP_PROTOCOL));

    match value.as_deref() {
        None => Ok(Protocol::HttpBinary),
        Some("http/protobuf") => Ok(Protocol::HttpBinary),
        Some("http/json") => Ok(Protocol::HttpJson),
        Some("grpc") => Ok(Protocol::Grpc),
        Some(other) => Err(OtlpError::InvalidProtocol {
            signal,
            value: other.to_string(),
        }),
    }
}

#[cfg(test)]
mod tests;
