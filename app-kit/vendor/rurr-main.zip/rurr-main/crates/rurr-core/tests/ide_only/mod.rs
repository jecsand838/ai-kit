mod removed_builder_initialize_from_async_fail {
    include!("../ui/removed_builder_initialize_from_async_fail.rs");
}

mod removed_builder_initialize_from_fail {
    include!("../ui/removed_builder_initialize_from_fail.rs");
}

mod removed_builder_with_async_state_persister_fail {
    include!("../ui/removed_builder_with_async_state_persister_fail.rs");
}

mod removed_builder_with_state_persister_fail {
    include!("../ui/removed_builder_with_state_persister_fail.rs");
}

mod removed_tracker_spec_local_use_otel_fail {
    include!("../ui/removed_tracker_spec_local_use_otel_fail.rs");
}

mod removed_serde_serialize_opaque_fail {
    include!("../ui/removed_serde_serialize_opaque_fail.rs");
}

mod stream_iterate_exclusive_fail {
    include!("../ui/stream_iterate_exclusive_fail.rs");
}

mod stream_iterate_inflight_step_fail {
    include!("../ui/stream_iterate_inflight_step_fail.rs");
}

mod stream_result_exclusive_fail {
    include!("../ui/stream_result_exclusive_fail.rs");
}

mod stream_result_exclusive_run_fail {
    include!("../ui/stream_result_exclusive_run_fail.rs");
}
