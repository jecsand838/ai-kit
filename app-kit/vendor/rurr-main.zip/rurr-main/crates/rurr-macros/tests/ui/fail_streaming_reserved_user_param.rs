use indexmap::IndexMap;
use rurr_core::action::StreamOutput;
use rurr_core::state::State;

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
fn reserved_stream_input(state: &State, __count: i64) -> Box<dyn Iterator<Item = StreamOutput>> {
    let _ = (state, __count);
    Box::new(Vec::<Result<(IndexMap<String, serde_json::Value>, Option<State>), _>>::new().into_iter())
}

fn main() {}
