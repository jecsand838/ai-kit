use crate::support::response_body::response_body_bytes;
use serde_json::Value;

pub(crate) async fn response_json(response: axum::response::Response) -> Value {
    let bytes = response_body_bytes(response).await;
    serde_json::from_slice(&bytes).expect("response should be valid json")
}
