use super::{
    contract_logic::{drive_partition_app_id_scan, finish_save_result, RedisPersistencePlan},
    redis_impl::{
        commands::{invoke_save_if_not_exists_sync, open_client},
        load::{load_record_key_sync, load_record_sync, partition_index_members_batch_sync},
    },
    RedisPersisterConfig, OP_CONNECTION_LOCK_POISONED, OP_RECORD_ALREADY_EXISTS,
    OP_REDIS_COMMAND_FAILED, OP_REDIS_CONNECT_FAILED, OP_REDIS_WRITE_OUTCOME_UNKNOWN,
};
use indexmap::IndexMap;
use redis::{Client, Commands, Connection};
use rurr_persistence::{
    BaseStateLoader, BaseStateSaver, PersistedStateData, PersistedStateStatus, PersistenceError,
};
use serde_json::Value;
use std::sync::{Mutex, MutexGuard};

#[derive(Debug)]
enum SyncConnectionState<C> {
    Unopened,
    Open(C),
}

#[derive(Debug)]
enum SyncConnectionError {
    Connect,
    Command,
    WriteOutcomeUnknown,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum SyncConnectionReplayPolicy {
    RetryOnTransportFailure,
    DoNotReplayOnTransportFailure,
}

/// Synchronous Redis persister backed by a lazily opened `redis::Connection`.
pub struct RedisPersister {
    client: Client,
    config: RedisPersisterConfig,
    connection_state: Mutex<SyncConnectionState<Connection>>,
}

impl RedisPersister {
    /// Creates a synchronous Redis persister from a serialized config value.
    pub fn new(config: RedisPersisterConfig) -> Result<Self, PersistenceError> {
        let (client, config) = open_client(config.redis_url, config.namespace)?;
        Ok(Self {
            client,
            config,
            connection_state: Mutex::new(SyncConnectionState::Unopened),
        })
    }

    /// Returns the configuration originally used to construct this persister.
    pub fn config(&self) -> RedisPersisterConfig {
        self.config.clone()
    }

    fn lock_connection_state(
        &self,
    ) -> Result<MutexGuard<'_, SyncConnectionState<Connection>>, PersistenceError> {
        self.connection_state
            .lock()
            .map_err(|_| PersistenceError::UnsupportedOperation {
                operation: OP_CONNECTION_LOCK_POISONED,
            })
    }

    pub(super) fn with_connection<T>(
        &self,
        policy: SyncConnectionReplayPolicy,
        operation: impl FnMut(&mut Connection) -> redis::RedisResult<T>,
    ) -> Result<T, PersistenceError> {
        let mut guard = self.lock_connection_state()?;
        with_connection_policy(
            &mut *guard,
            policy,
            || self.client.get_connection(),
            operation,
        )
        .map_err(map_sync_connection_error)
    }

    fn ping(&self) -> Result<(), PersistenceError> {
        self.with_connection(
            SyncConnectionReplayPolicy::RetryOnTransportFailure,
            |connection| redis::cmd("PING").query::<String>(connection).map(|_| ()),
        )
    }
}

impl BaseStateSaver for RedisPersister {
    fn initialize(&self) -> Result<(), PersistenceError> {
        self.ping()
    }

    fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.ping()?;
        Ok(true)
    }

    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        let prepared_save = RedisPersistencePlan::save(
            &self.config.namespace,
            partition_key,
            app_id,
            sequence_id,
            position,
            &state,
            status,
        )?;
        let save_invocation = prepared_save.invocation();

        let result: i32 = self.with_connection(
            SyncConnectionReplayPolicy::DoNotReplayOnTransportFailure,
            |connection| invoke_save_if_not_exists_sync(connection, &save_invocation),
        )?;

        finish_save_result(result, OP_RECORD_ALREADY_EXISTS)
    }
}

impl BaseStateLoader for RedisPersister {
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        let query =
            RedisPersistencePlan::load(&self.config.namespace, partition_key, app_id, sequence_id)?;
        let Some(record_key) = load_record_key_sync(self, &query)? else {
            return Ok(None);
        };
        load_record_sync(self, &record_key)
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        let plan = RedisPersistencePlan::list_app_ids(&self.config.namespace, partition_key);
        let app_ids: Vec<String> = self.with_connection(
            SyncConnectionReplayPolicy::RetryOnTransportFailure,
            |connection| connection.smembers(plan.app_members_key()),
        )?;
        let scan = plan.scan(app_ids);
        drive_partition_app_id_scan(scan, |partition_index_key, start, end| {
            partition_index_members_batch_sync(self, partition_index_key, start, end)
        })
    }
}

fn with_connection_policy<C, T>(
    connection_state: &mut SyncConnectionState<C>,
    policy: SyncConnectionReplayPolicy,
    mut connect: impl FnMut() -> redis::RedisResult<C>,
    mut operation: impl FnMut(&mut C) -> redis::RedisResult<T>,
) -> Result<T, SyncConnectionError> {
    ensure_connection_open(connection_state, &mut connect)?;

    match run_operation(connection_state, &mut operation) {
        Ok(value) => Ok(value),
        Err(error) => handle_operation_error(
            connection_state,
            policy,
            error,
            &mut connect,
            &mut operation,
        ),
    }
}

fn handle_operation_error<C, T>(
    connection_state: &mut SyncConnectionState<C>,
    policy: SyncConnectionReplayPolicy,
    error: redis::RedisError,
    connect: &mut impl FnMut() -> redis::RedisResult<C>,
    operation: &mut impl FnMut(&mut C) -> redis::RedisResult<T>,
) -> Result<T, SyncConnectionError> {
    match policy {
        SyncConnectionReplayPolicy::RetryOnTransportFailure if should_reconnect(&error) => {
            retry_after_reconnect(connection_state, connect, operation)
        }
        SyncConnectionReplayPolicy::RetryOnTransportFailure => Err(SyncConnectionError::Command),
        SyncConnectionReplayPolicy::DoNotReplayOnTransportFailure if should_reconnect(&error) => {
            *connection_state = SyncConnectionState::Unopened;
            Err(SyncConnectionError::WriteOutcomeUnknown)
        }
        SyncConnectionReplayPolicy::DoNotReplayOnTransportFailure => {
            Err(SyncConnectionError::Command)
        }
    }
}

fn ensure_connection_open<C>(
    connection_state: &mut SyncConnectionState<C>,
    connect: &mut impl FnMut() -> redis::RedisResult<C>,
) -> Result<(), SyncConnectionError> {
    if matches!(connection_state, SyncConnectionState::Unopened) {
        *connection_state =
            SyncConnectionState::Open(connect().map_err(|_| SyncConnectionError::Connect)?);
    }
    Ok(())
}

fn run_operation<C, T>(
    connection_state: &mut SyncConnectionState<C>,
    operation: &mut impl FnMut(&mut C) -> redis::RedisResult<T>,
) -> redis::RedisResult<T> {
    match connection_state {
        SyncConnectionState::Open(connection) => operation(connection),
        SyncConnectionState::Unopened => unreachable!("connection must be open before use"),
    }
}

fn retry_after_reconnect<C, T>(
    connection_state: &mut SyncConnectionState<C>,
    connect: &mut impl FnMut() -> redis::RedisResult<C>,
    operation: &mut impl FnMut(&mut C) -> redis::RedisResult<T>,
) -> Result<T, SyncConnectionError> {
    *connection_state = SyncConnectionState::Unopened;

    let mut fresh_connection = connect().map_err(|_| SyncConnectionError::Connect)?;
    match operation(&mut fresh_connection) {
        Ok(value) => {
            *connection_state = SyncConnectionState::Open(fresh_connection);
            Ok(value)
        }
        Err(error) => {
            if should_reconnect(&error) {
                *connection_state = SyncConnectionState::Unopened;
            } else {
                *connection_state = SyncConnectionState::Open(fresh_connection);
            }
            Err(SyncConnectionError::Command)
        }
    }
}

fn should_reconnect(error: &redis::RedisError) -> bool {
    error.is_connection_dropped() || error.is_unrecoverable_error()
}

fn map_sync_connection_error(error: SyncConnectionError) -> PersistenceError {
    match error {
        SyncConnectionError::Connect => PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_CONNECT_FAILED,
        },
        SyncConnectionError::Command => PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_COMMAND_FAILED,
        },
        SyncConnectionError::WriteOutcomeUnknown => PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_WRITE_OUTCOME_UNKNOWN,
        },
    }
}

#[cfg(test)]
mod tests {
    use super::{
        map_sync_connection_error, with_connection_policy, RedisPersister, RedisPersisterConfig,
        SyncConnectionError, SyncConnectionReplayPolicy, SyncConnectionState,
        OP_REDIS_COMMAND_FAILED, OP_REDIS_CONNECT_FAILED, OP_REDIS_WRITE_OUTCOME_UNKNOWN,
    };
    use indexmap::IndexMap;
    use redis::{Client, Connection};
    use rurr_persistence::{
        BaseStateLoader, BaseStateSaver, PersistedStateStatus, PersistenceError,
    };
    use rurr_testkit::{redis_url_from_env, wait_for_redis_ready_sync};
    use serde_json::{json, Value};
    use uuid::Uuid;

    #[test]
    fn sync_connection_error_mapping_preserves_connect_vs_command_operations() {
        let connect_error = map_sync_connection_error(SyncConnectionError::Connect);
        let command_error = map_sync_connection_error(SyncConnectionError::Command);
        let ambiguous_write_error =
            map_sync_connection_error(SyncConnectionError::WriteOutcomeUnknown);

        assert!(matches!(
            connect_error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_REDIS_CONNECT_FAILED
        ));
        assert!(matches!(
            command_error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_REDIS_COMMAND_FAILED
        ));
        assert!(matches!(
            ambiguous_write_error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_REDIS_WRITE_OUTCOME_UNKNOWN
        ));
    }

    #[test]
    fn sync_same_instance_retries_read_after_client_kill() {
        rurr_testkit::require_check_live_tests!();

        let redis_url = live_redis_url();
        let mut admin_connection = open_admin_connection(&redis_url);
        let persister = live_persister(redis_url.clone(), "sync_read_retry");
        persister
            .save(
                Some("partition"),
                "app_id",
                1,
                "position_1",
                map_from_pairs([("key", json!("value_1"))]),
                PersistedStateStatus::Completed,
            )
            .expect("initial save should succeed");

        let client_id = cached_client_id(&persister);
        assert_eq!(kill_client(&mut admin_connection, client_id), 1);

        let loaded = persister
            .load(Some("partition"), Some("app_id"), Some(1))
            .expect("load should retry after the cached socket is killed")
            .expect("saved state should still exist");

        assert_eq!(loaded.position.as_deref(), Some("position_1"));
        assert_eq!(
            loaded.state,
            Some(map_from_pairs([("key", json!("value_1"))]))
        );
        assert_ne!(
            cached_client_id(&persister),
            client_id,
            "read retry should reopen the dropped cached connection"
        );
    }

    #[test]
    fn sync_same_instance_does_not_reconnect_after_live_non_transport_command_error() {
        rurr_testkit::require_check_live_tests!();

        let redis_url = live_redis_url();
        let persister = live_persister(redis_url, "sync_non_transport_command");
        let client_id = cached_client_id(&persister);

        let error = persister
            .with_connection(
                SyncConnectionReplayPolicy::RetryOnTransportFailure,
                |connection| redis::cmd("INVALIDCOMMAND").query::<String>(connection),
            )
            .expect_err("real Redis command errors should surface without reconnect");

        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_REDIS_COMMAND_FAILED
        ));
        assert_eq!(
            cached_client_id(&persister),
            client_id,
            "non-transport command failures should keep the same cached connection"
        );
        assert_eq!(
            persister
                .with_connection(
                    SyncConnectionReplayPolicy::RetryOnTransportFailure,
                    |connection| redis::cmd("PING").query::<String>(connection),
                )
                .expect("same cached connection should remain usable after a command failure"),
            "PONG"
        );
        assert_eq!(cached_client_id(&persister), client_id);
    }

    #[test]
    fn sync_connection_policy_stops_after_second_live_transport_failure_and_later_recovers() {
        rurr_testkit::require_check_live_tests!();

        let redis_url = live_redis_url();
        let client = Client::open(redis_url.as_str()).expect("redis client should open");
        let mut admin_connection = open_admin_connection(&redis_url);
        let mut connection_state = SyncConnectionState::Unopened;
        let mut connect_attempts = 0;
        let mut operation_attempts = 0;

        let error = with_connection_policy(
            &mut connection_state,
            SyncConnectionReplayPolicy::RetryOnTransportFailure,
            || {
                connect_attempts += 1;
                client.get_connection()
            },
            |connection| {
                operation_attempts += 1;
                let client_id: isize = redis::cmd("CLIENT").arg("ID").query(connection)?;
                assert_eq!(kill_client(&mut admin_connection, client_id), 1);
                redis::cmd("PING").query::<String>(connection)
            },
        )
        .expect_err("retry should stop after a second live transport failure");

        assert!(matches!(error, SyncConnectionError::Command));
        assert_eq!(connect_attempts, 2);
        assert_eq!(operation_attempts, 2);
        assert!(matches!(connection_state, SyncConnectionState::Unopened));

        let recovered = with_connection_policy(
            &mut connection_state,
            SyncConnectionReplayPolicy::RetryOnTransportFailure,
            || {
                connect_attempts += 1;
                client.get_connection()
            },
            |connection| redis::cmd("PING").query::<String>(connection),
        )
        .expect("later call should recover from unopened state");

        assert_eq!(recovered, "PONG");
        assert_eq!(connect_attempts, 3);
        assert!(matches!(connection_state, SyncConnectionState::Open(_)));
    }

    #[test]
    fn sync_same_instance_marks_write_outcome_unknown_after_client_kill_and_later_recovers() {
        rurr_testkit::require_check_live_tests!();

        let redis_url = live_redis_url();
        let mut admin_connection = open_admin_connection(&redis_url);

        let namespace = unique_namespace("sync_reconnect_recovery");
        let persister =
            RedisPersister::new(RedisPersisterConfig::new(redis_url.clone(), namespace))
                .expect("persister should create");
        persister
            .initialize()
            .expect("sync redis persister should initialize");

        let client_id: isize = persister
            .with_connection(
                SyncConnectionReplayPolicy::RetryOnTransportFailure,
                |connection| redis::cmd("CLIENT").arg("ID").query(connection),
            )
            .expect("cached connection should expose its client id");
        assert_eq!(kill_client(&mut admin_connection, client_id), 1);

        let error = persister
            .save(
                Some("partition"),
                "app_id",
                1,
                "position_1",
                map_from_pairs([("key", json!("value_1"))]),
                PersistedStateStatus::Completed,
            )
            .expect_err("sync save should not replay after the cached socket is killed");

        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_REDIS_WRITE_OUTCOME_UNKNOWN
        ));

        persister
            .save(
                Some("partition"),
                "app_id",
                2,
                "position_2",
                map_from_pairs([("key", json!("value_2"))]),
                PersistedStateStatus::Completed,
            )
            .expect("later save should reconnect successfully");

        assert!(
            persister
                .load(Some("partition"), Some("app_id"), Some(1))
                .expect("load after reconnect should succeed")
                .is_none(),
            "ambiguous write failures must not replay the dropped write implicitly"
        );

        let loaded = persister
            .load(Some("partition"), Some("app_id"), Some(2))
            .expect("load should succeed after reconnect")
            .expect("saved state should exist after reconnect");

        assert_eq!(loaded.position.as_deref(), Some("position_2"));
        assert_eq!(
            loaded.state,
            Some(map_from_pairs([("key", json!("value_2"))]))
        );
    }

    fn live_redis_url() -> String {
        let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
        wait_for_redis_ready_sync(&redis_url).expect("redis must be reachable for live tests");
        redis_url
    }

    fn live_persister(redis_url: String, prefix: &str) -> RedisPersister {
        let persister = RedisPersister::new(RedisPersisterConfig::new(
            redis_url,
            unique_namespace(prefix),
        ))
        .expect("persister should create");
        persister
            .initialize()
            .expect("sync redis persister should initialize");
        persister
    }

    fn cached_client_id(persister: &RedisPersister) -> isize {
        persister
            .with_connection(
                SyncConnectionReplayPolicy::RetryOnTransportFailure,
                |connection| redis::cmd("CLIENT").arg("ID").query(connection),
            )
            .expect("cached connection should expose its client id")
    }

    fn open_admin_connection(redis_url: &str) -> Connection {
        Client::open(redis_url)
            .expect("redis client should open")
            .get_connection()
            .expect("admin connection should open")
    }

    fn kill_client(connection: &mut Connection, client_id: isize) -> usize {
        redis::cmd("CLIENT")
            .arg("KILL")
            .arg("ID")
            .arg(client_id)
            .query(connection)
            .expect("client kill should succeed")
    }

    fn unique_namespace(prefix: &str) -> String {
        let suffix = Uuid::new_v4().simple().to_string();
        let suffix = &suffix[..8];
        format!("rurr_redis_{prefix}_{suffix}")
    }

    fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
        pairs
            .into_iter()
            .map(|(key, value)| (key.to_string(), value))
            .collect()
    }
}
