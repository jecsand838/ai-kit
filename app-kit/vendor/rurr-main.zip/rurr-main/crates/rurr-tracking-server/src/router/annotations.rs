use super::{unsupported_feature, ApiError, AppState};
use crate::backend::PartitionSelector;
use crate::schema::{AnnotationCreate, AnnotationQuery, AnnotationUpdate};
use axum::extract::{Path, Query, State};
use axum::response::{IntoResponse, Response};
use axum::routing::{get, post, put};
use axum::{Json, Router};

/// Builds the annotation routes mounted under `/api/v0`.
///
/// All annotation routes require a backend that advertises annotation support.
/// Unsupported backends fail closed with a typed unsupported-feature API error
/// for create, update, and list requests.
pub fn routes() -> Router<AppState> {
    Router::new()
        .route(
            "/{project_id}/{app_id}/{partition_key}/{sequence_id}/annotations",
            post(create_annotation),
        )
        .route(
            "/{project_id}/{annotation_id}/update_annotations",
            put(update_annotation),
        )
        .route("/{project_id}/annotations", get(get_annotations))
}

async fn create_annotation(
    Path((project_id, app_id, partition_key, sequence_id)): Path<(String, String, String, u64)>,
    State(state): State<AppState>,
    Json(annotation): Json<AnnotationCreate>,
) -> Result<Response, ApiError> {
    require_annotations(&state)?;
    let partition = PartitionSelector::from_path_segment(&partition_key);
    let payload = state
        .backend()
        .create_annotation(
            annotation,
            &project_id,
            partition.as_specific_partition(),
            &app_id,
            sequence_id,
        )
        .await?;
    Ok(Json(payload).into_response())
}

async fn update_annotation(
    Path((project_id, annotation_id)): Path<(String, u64)>,
    State(state): State<AppState>,
    Json(annotation): Json<AnnotationUpdate>,
) -> Result<Response, ApiError> {
    require_annotations(&state)?;
    let payload = state
        .backend()
        .update_annotation(annotation, &project_id, annotation_id)
        .await?;
    Ok(Json(payload).into_response())
}

async fn get_annotations(
    Path(project_id): Path<String>,
    Query(query): Query<AnnotationQuery>,
    State(state): State<AppState>,
) -> Result<Response, ApiError> {
    require_annotations(&state)?;
    let partition_selector = PartitionSelector::from_optional_query(query.partition_key.as_deref());
    let payload = state
        .backend()
        .get_annotations(
            &project_id,
            partition_selector,
            query.app_id.as_deref(),
            query.step_sequence_id,
        )
        .await?;
    Ok(Json(payload).into_response())
}

fn require_annotations(state: &AppState) -> Result<(), ApiError> {
    state
        .backend()
        .backend_capabilities()
        .supports_annotations
        .then_some(())
        .ok_or_else(|| unsupported_feature("annotations"))
}
