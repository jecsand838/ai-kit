use super::super::TrackingError;
use crate::action::ErasedAction;
use crate::graph::{GraphAction, GraphRegistrationView, Transition};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serialized action metadata written to tracking artifacts.
///
/// This mirrors Burr's graph JSON shape and is written by local and S3 trackers
/// during application registration.
pub struct ActionModel {
    /// Record discriminator used in tracking JSON.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Action name.
    pub name: String,
    /// State fields read by the action.
    pub reads: Vec<String>,
    /// State fields written by the action.
    pub writes: Vec<String>,
    /// Source code associated with the action.
    pub code: String,
    /// Required runtime input names.
    pub inputs: Vec<String>,
    /// Optional runtime input names.
    pub optional_inputs: Vec<String>,
}

impl ActionModel {
    /// Builds a tracking action model from an action implementation.
    pub fn from_action(action: &dyn ErasedAction) -> Result<Self, TrackingError> {
        let name = action
            .name()
            .ok_or(TrackingError::UnnamedAction)?
            .to_string();
        Ok(Self {
            r#type: "action".to_string(),
            name: name.clone(),
            reads: action.reads().to_vec(),
            writes: action.writes().to_vec(),
            code: action
                .source_code()
                .ok_or_else(|| TrackingError::MissingActionSource {
                    action: name.clone(),
                })?,
            inputs: action.inputs().to_vec(),
            optional_inputs: action.optional_inputs().to_vec(),
        })
    }

    /// Builds a tracking action model from a registered graph action.
    pub fn from_graph_action(action: &GraphAction) -> Result<Self, TrackingError> {
        Self::from_action(action.action())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serialized transition metadata written to tracking artifacts.
///
/// Conditions are stored by display/name form so the tracking UI can reconstruct
/// the graph without evaluating runtime state.
pub struct TransitionModel {
    /// Record discriminator used in tracking JSON.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Source action name.
    pub from_: String,
    /// Destination action name.
    pub to: String,
    /// Transition condition name.
    pub condition: String,
}

impl TransitionModel {
    /// Builds a tracking transition model from a graph transition.
    pub fn from_transition(transition: &Transition) -> Self {
        Self {
            r#type: "transition".to_string(),
            from_: transition.from().to_string(),
            to: transition.to().to_string(),
            condition: transition.condition().name().to_string(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serialized application graph metadata written to tracking artifacts.
///
/// The model is shared by local JSON files and S3 `graph.json` objects.
pub struct ApplicationModel {
    /// Record discriminator used in tracking JSON.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Entry action for the graph.
    pub entrypoint: String,
    /// Registered actions.
    pub actions: Vec<ActionModel>,
    /// Registered transitions.
    pub transitions: Vec<TransitionModel>,
}

impl ApplicationModel {
    /// Builds a tracking application model from a registered graph.
    pub fn from_graph(graph: &impl GraphRegistrationView) -> Result<Self, TrackingError> {
        let actions = graph
            .actions()
            .iter()
            .map(ActionModel::from_graph_action)
            .collect::<Result<Vec<_>, _>>()?;
        let transitions = graph
            .transitions()
            .iter()
            .map(TransitionModel::from_transition)
            .collect();
        Ok(Self {
            r#type: "application".to_string(),
            entrypoint: graph.entrypoint().to_string(),
            actions,
            transitions,
        })
    }
}
