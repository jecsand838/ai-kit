use std::collections::BTreeMap;

use http::HeaderMap;
use surrealdb_types::SurrealValue;

use crate::catalog::ApiMethod;
use crate::types::{PublicObject, PublicValue};
use crate::val::convert_public::convert_public_value_to_internal;
use crate::val::{Value, convert_value_to_public_value};

#[derive(Clone, Default, SurrealValue)]
#[surreal(crate = "surrealdb_types")]
#[surreal(default)]
pub struct ApiRequest {
	// Request
	pub body: PublicValue,
	pub headers: HeaderMap,
	pub params: PublicObject,
	pub method: ApiMethod,
	pub query: BTreeMap<String, String>,
	pub context: PublicObject,
	/// Server-generated request ID for tracing and logging
	pub request_id: String,
}

impl TryFrom<Value> for ApiRequest {
	type Error = surrealdb_types::Error;

	fn try_from(value: Value) -> std::result::Result<Self, Self::Error> {
		convert_value_to_public_value(value)
			.map_err(|e| surrealdb_types::Error::internal(e.to_string()))?
			.into_t()
	}
}

impl From<ApiRequest> for Value {
	fn from(value: ApiRequest) -> Self {
		convert_public_value_to_internal(value.into_value())
	}
}
