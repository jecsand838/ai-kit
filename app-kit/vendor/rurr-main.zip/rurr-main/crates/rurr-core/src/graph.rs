//! Graph registration, transition validation, and visualization helpers.
//!
//! [`Graph`] and [`GraphBuilder`] hold named actions plus ordered transitions.
//! Validation keeps the public graph surface deterministic by rejecting
//! duplicate actions, unreachable defaults, and references to unknown actions
//! before an [`Application`](crate::application::Application) is ever built.

use crate::action::api::{is_reserved_runtime_input, ErasedAction, LocalAction};
use crate::action::condition::{Condition, ConditionError};
use crate::state::State;
use indexmap::IndexSet;
use std::collections::{HashMap, HashSet};
use std::fmt;
use std::fs;
use std::path::Path;
use std::sync::Arc;
use thiserror::Error;

/// Error returned while validating or traversing a graph.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum GraphError {
    /// The graph was constructed without any actions.
    #[error("must have at least one action in the graph")]
    EmptyActions,
    /// Two graph actions shared the same name.
    #[error("action '{name}' is duplicated in the actions list")]
    DuplicateActionName {
        /// Duplicated action name.
        name: String,
    },
    /// A transition referenced an unknown source action.
    #[error(
        "transition source '{from}' not found in actions. available actions: {available_actions:?}"
    )]
    TransitionSourceNotFound {
        /// Transition source name.
        from: String,
        /// Known action names in the graph.
        available_actions: Vec<String>,
    },
    /// A transition referenced an unknown destination action.
    #[error(
        "transition target '{to}' not found in actions. available actions: {available_actions:?}"
    )]
    TransitionTargetNotFound {
        /// Transition destination name.
        to: String,
        /// Known action names in the graph.
        available_actions: Vec<String>,
    },
    /// A later transition was unreachable because a default transition for the
    /// same source was already defined.
    #[error(
        "transition '{from}' -> '{to}' is redundant: a default transition is already set for '{from}'"
    )]
    RedundantTransition {
        /// Transition source name.
        from: String,
        /// Transition destination name.
        to: String,
    },
    /// The requested entrypoint was not present in the action set.
    #[error(
        "entrypoint '{entrypoint}' not found in actions. available actions: {available_actions:?}"
    )]
    EntrypointNotFound {
        /// Requested entrypoint name.
        entrypoint: String,
        /// Known action names in the graph.
        available_actions: Vec<String>,
    },
    /// A requested action name was not present in the graph.
    #[error("action '{action_name}' not found in graph. available actions: {available_actions:?}")]
    ActionNotFound {
        /// Missing action name.
        action_name: String,
        /// Known action names in the graph.
        available_actions: Vec<String>,
    },
    /// A requested tag was not present in the graph.
    ///
    /// This is also the error returned when execution options contain a
    /// `@tag:<tag>` halt selector that does not match any registered action.
    #[error("tag '{tag}' not found in graph. available tags: {available_tags:?}")]
    TagNotFound {
        /// Missing tag name.
        tag: String,
        /// Known tags in the graph.
        available_tags: Vec<String>,
    },
    /// Evaluating a transition condition failed.
    #[error("failed to evaluate transition '{from}' -> '{to}': {source}")]
    ConditionEvaluation {
        /// Transition source name.
        from: String,
        /// Transition destination name.
        to: String,
        /// Condition evaluation error.
        source: Box<ConditionError>,
    },
    /// An action without a stable name was registered in the graph.
    #[error("graph action must have a name")]
    UnnamedAction,
    /// A graph action declared reserved runtime input names.
    #[error("action '{action_name}' declares reserved runtime inputs: {keys:?}")]
    ReservedRuntimeInputDeclaration {
        /// Action name that declared the reserved keys.
        action_name: String,
        /// Reserved runtime keys that were declared.
        keys: Vec<String>,
    },
}

/// Named action registered in a graph.
#[derive(Clone)]
pub struct GraphAction {
    name: String,
    action: Arc<dyn ErasedAction>,
}

impl GraphAction {
    /// Wraps a named action so it can be registered in a graph.
    pub fn new<A>(action: A) -> Result<Self, GraphError>
    where
        A: LocalAction + Send + Sync + 'static,
    {
        let name = LocalAction::name(&action).ok_or(GraphError::UnnamedAction)?;
        if name.trim().is_empty() {
            return Err(GraphError::UnnamedAction);
        }
        let mut reserved_runtime_keys = LocalAction::inputs(&action)
            .iter()
            .filter(|key| is_reserved_runtime_input(key))
            .chain(
                LocalAction::optional_inputs(&action)
                    .iter()
                    .filter(|key| is_reserved_runtime_input(key)),
            )
            .cloned()
            .collect::<Vec<_>>();
        reserved_runtime_keys.sort();
        reserved_runtime_keys.dedup();
        if !reserved_runtime_keys.is_empty() {
            return Err(GraphError::ReservedRuntimeInputDeclaration {
                action_name: name.to_string(),
                keys: reserved_runtime_keys,
            });
        }
        Ok(Self {
            name: name.to_string(),
            action: Arc::new(action),
        })
    }

    /// Returns the registered action name.
    pub fn name(&self) -> &str {
        &self.name
    }

    /// Returns the underlying erased action trait object.
    pub fn action(&self) -> &dyn ErasedAction {
        self.action.as_ref()
    }

    /// Returns the action tags used for graph queries, metadata, and halt
    /// selector expansion.
    ///
    /// Tags preserve the order declared by the underlying action.
    pub fn tags(&self) -> &[String] {
        self.action.tags()
    }
}

impl fmt::Debug for GraphAction {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("GraphAction")
            .field("name", &self.name)
            .field("reads", &self.action.reads())
            .field("writes", &self.action.writes())
            .field("tags", &self.action.tags())
            .finish()
    }
}

/// Directed edge between two actions.
#[derive(Debug, Clone)]
pub struct Transition {
    from: String,
    to: String,
    condition: Condition,
}

impl Transition {
    /// Creates a transition from `from` to `to` guarded by `condition`.
    pub fn new(from: impl Into<String>, to: impl Into<String>, condition: Condition) -> Self {
        Self {
            from: from.into(),
            to: to.into(),
            condition,
        }
    }

    /// Returns the source action name.
    pub fn from(&self) -> &str {
        &self.from
    }

    /// Returns the destination action name.
    pub fn to(&self) -> &str {
        &self.to
    }

    /// Returns the guard condition for the transition.
    pub fn condition(&self) -> &Condition {
        &self.condition
    }
}

/// Read-only view of graph registration data.
pub trait GraphRegistrationView {
    /// Returns all registered actions.
    fn actions(&self) -> &[GraphAction];
    /// Returns all registered transitions.
    fn transitions(&self) -> &[Transition];
    /// Returns the entrypoint action name.
    fn entrypoint(&self) -> &str;
}

/// Validated application graph with indexed actions and transitions.
#[derive(Debug, Clone)]
pub struct Graph {
    actions: Vec<GraphAction>,
    transitions: Vec<Transition>,
    entrypoint: String,
    action_index: HashMap<String, usize>,
    transitions_from: Vec<Vec<usize>>,
}

impl Graph {
    /// Validates and constructs a graph.
    pub fn new(
        actions: Vec<GraphAction>,
        transitions: Vec<Transition>,
        entrypoint: impl Into<String>,
    ) -> Result<Self, GraphError> {
        validate_actions(&actions)?;
        let action_names = action_name_set(&actions);
        validate_transitions(&transitions, &action_names)?;

        let entrypoint = entrypoint.into();
        if !action_names.contains(&entrypoint) {
            return Err(GraphError::EntrypointNotFound {
                entrypoint,
                available_actions: actions
                    .iter()
                    .map(|action| action.name().to_string())
                    .collect(),
            });
        }

        let action_index = actions
            .iter()
            .enumerate()
            .map(|(index, action)| (action.name().to_string(), index))
            .collect::<HashMap<_, _>>();
        let mut transitions_from = vec![Vec::new(); actions.len()];
        for (index, transition) in transitions.iter().enumerate() {
            let from_action_index = *action_index
                .get(transition.from())
                .expect("validated transitions should only reference known source actions");
            transitions_from[from_action_index].push(index);
        }
        Ok(Self {
            actions,
            transitions,
            entrypoint,
            action_index,
            transitions_from,
        })
    }

    /// Returns all registered actions.
    pub fn actions(&self) -> &[GraphAction] {
        &self.actions
    }

    pub(crate) fn contains_action(&self, action_name: &str) -> bool {
        self.action_index.contains_key(action_name)
    }

    pub(crate) fn action_names_in_order(&self) -> impl Iterator<Item = &str> {
        self.actions.iter().map(|action| action.name())
    }

    /// Returns all registered transitions.
    pub fn transitions(&self) -> &[Transition] {
        &self.transitions
    }

    /// Returns the entrypoint action name.
    pub fn entrypoint(&self) -> &str {
        &self.entrypoint
    }

    pub(crate) fn with_entrypoint(
        mut self,
        entrypoint: impl Into<String>,
    ) -> Result<Self, GraphError> {
        let entrypoint = entrypoint.into();
        if !self.action_index.contains_key(&entrypoint) {
            return Err(GraphError::EntrypointNotFound {
                entrypoint,
                available_actions: self
                    .actions
                    .iter()
                    .map(|action| action.name().to_string())
                    .collect(),
            });
        }
        self.entrypoint = entrypoint;
        Ok(self)
    }

    pub(crate) fn into_parts(self) -> (Vec<GraphAction>, Vec<Transition>, String) {
        (self.actions, self.transitions, self.entrypoint)
    }

    /// Returns one action by name.
    pub fn get_action(&self, action_name: &str) -> Result<&GraphAction, GraphError> {
        self.action_index
            .get(action_name)
            .map(|index| &self.actions[*index])
            .ok_or_else(|| GraphError::ActionNotFound {
                action_name: action_name.to_string(),
                available_actions: self
                    .actions
                    .iter()
                    .map(|action| action.name().to_string())
                    .collect(),
            })
    }

    /// Resolves the next action name for `current_action` and `state`.
    pub fn get_next_node(
        &self,
        current_action: Option<&str>,
        state: &State,
    ) -> Result<Option<String>, GraphError> {
        let Some(current_action) = current_action else {
            return Ok(Some(self.entrypoint.clone()));
        };

        let Some(current_action_index) = self.action_index.get(current_action).copied() else {
            return Err(GraphError::ActionNotFound {
                action_name: current_action.to_string(),
                available_actions: self
                    .actions
                    .iter()
                    .map(|action| action.name().to_string())
                    .collect(),
            });
        };
        let transition_indexes = &self.transitions_from[current_action_index];
        if transition_indexes.is_empty() {
            return Ok(None);
        }

        for transition_index in transition_indexes {
            let transition = &self.transitions[*transition_index];
            let should_transition = transition.condition().evaluate(state).map_err(|source| {
                GraphError::ConditionEvaluation {
                    from: transition.from().to_string(),
                    to: transition.to().to_string(),
                    source: Box::new(source),
                }
            })?;
            if should_transition {
                return Ok(Some(transition.to().to_string()));
            }
        }

        Ok(None)
    }

    /// Returns all actions tagged with `tag`.
    ///
    /// Matching actions are returned in graph action order. Missing tags fail
    /// with [`GraphError::TagNotFound`] instead of returning an empty list; this
    /// keeps `@tag:<tag>` halt selectors from silently doing nothing.
    ///
    /// # Examples
    ///
    /// ```
    /// use indexmap::IndexMap;
    /// use rurr_core::{FunctionActionBuilder, GraphAction, GraphBuilder};
    /// use serde_json::Value;
    ///
    /// let action = FunctionActionBuilder::new()
    ///     .tags(["terminal"])
    ///     .build_sync(|_state, _ctx| IndexMap::<String, Value>::new())?;
    /// let graph = GraphBuilder::new()
    ///     .with_action(GraphAction::try_from(("answer", action))?)
    ///     .with_entrypoint("answer")
    ///     .build()?;
    ///
    /// let tagged = graph.get_actions_by_tag("terminal")?;
    /// assert_eq!(tagged[0].name(), "answer");
    /// assert!(graph.get_actions_by_tag("missing").is_err());
    /// # Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
    /// ```
    pub fn get_actions_by_tag(&self, tag: &str) -> Result<Vec<&GraphAction>, GraphError> {
        let actions: Vec<&GraphAction> = self
            .actions
            .iter()
            .filter(|action| action.tags().iter().any(|value| value == tag))
            .collect();
        if actions.is_empty() {
            return Err(GraphError::TagNotFound {
                tag: tag.to_string(),
                available_tags: self.available_tags(),
            });
        }
        Ok(actions)
    }

    /// Renders the graph as DOT text and optionally writes a `.dot` file.
    pub fn visualize(
        &self,
        output_file_path: Option<&Path>,
        write_dot: bool,
    ) -> std::io::Result<String> {
        let dot_output = self.render_dot();

        if write_dot {
            if let Some(output_file_path) = output_file_path {
                let dot_file_path = output_file_path.with_extension("dot");
                fs::write(dot_file_path, dot_output.as_bytes())?;
            }
        }

        Ok(dot_output)
    }

    fn render_dot(&self) -> String {
        let mut output = String::from("digraph rurr {\n");

        for action in &self.actions {
            output.push_str("  \"");
            output.push_str(&escape_dot_value(action.name()));
            output.push_str("\";\n");
        }

        for transition in &self.transitions {
            output.push_str("  \"");
            output.push_str(&escape_dot_value(transition.from()));
            output.push_str("\" -> \"");
            output.push_str(&escape_dot_value(transition.to()));
            output.push('"');
            if transition.condition().name() != "default" {
                output.push_str(" [label=\"");
                output.push_str(&escape_dot_value(transition.condition().name()));
                output.push_str("\"]");
            }
            output.push_str(";\n");
        }

        output.push_str("}\n");
        output
    }

    fn available_tags(&self) -> Vec<String> {
        let mut tags = IndexSet::new();
        for action in &self.actions {
            for tag in action.tags() {
                tags.insert(tag.clone());
            }
        }
        tags.into_iter().collect()
    }
}

impl GraphRegistrationView for Graph {
    fn actions(&self) -> &[GraphAction] {
        self.actions()
    }

    fn transitions(&self) -> &[Transition] {
        self.transitions()
    }

    fn entrypoint(&self) -> &str {
        self.entrypoint()
    }
}

/// Builder for constructing graphs incrementally.
#[derive(Debug, Clone, Default)]
pub struct GraphBuilder {
    actions: Vec<GraphAction>,
    transitions: Vec<Transition>,
    entrypoint: Option<String>,
}

impl GraphBuilder {
    /// Creates an empty graph builder.
    pub fn new() -> Self {
        Self::default()
    }

    /// Adds one action to the graph builder.
    pub fn with_action(mut self, action: GraphAction) -> Self {
        self.actions.push(action);
        self
    }

    /// Adds multiple actions to the graph builder.
    pub fn with_actions<I>(mut self, actions: I) -> Self
    where
        I: IntoIterator<Item = GraphAction>,
    {
        self.actions.extend(actions);
        self
    }

    /// Adds a default transition from `from` to `to`.
    pub fn with_transition(mut self, from: impl Into<String>, to: impl Into<String>) -> Self {
        self.transitions
            .push(Transition::new(from, to, Condition::default()));
        self
    }

    /// Adds a conditional transition from `from` to `to`.
    pub fn with_transition_when(
        mut self,
        from: impl Into<String>,
        to: impl Into<String>,
        condition: Condition,
    ) -> Self {
        self.transitions.push(Transition::new(from, to, condition));
        self
    }

    /// Imports another graph into this builder.
    pub fn with_graph(mut self, graph: &Graph) -> Self {
        self.actions.extend(graph.actions.iter().cloned());
        self.transitions.extend(graph.transitions.iter().cloned());
        self
    }

    /// Sets the entrypoint explicitly.
    pub fn with_entrypoint(mut self, entrypoint: impl Into<String>) -> Self {
        self.entrypoint = Some(entrypoint.into());
        self
    }

    /// Validates and constructs the graph.
    pub fn build(self) -> Result<Graph, GraphError> {
        let GraphBuilder {
            actions,
            transitions,
            entrypoint,
        } = self;
        let entrypoint = match entrypoint {
            Some(entrypoint) => entrypoint,
            None => {
                let Some(first_action) = actions.first() else {
                    return Err(GraphError::EmptyActions);
                };
                first_action.name().to_string()
            }
        };

        Graph::new(actions, transitions, entrypoint)
    }
}

/// Validates the graph action list.
pub fn validate_actions(actions: &[GraphAction]) -> Result<(), GraphError> {
    if actions.is_empty() {
        return Err(GraphError::EmptyActions);
    }

    let mut seen = HashSet::new();
    for action in actions {
        if !seen.insert(action.name()) {
            return Err(GraphError::DuplicateActionName {
                name: action.name().to_string(),
            });
        }
    }

    Ok(())
}

/// Validates graph transitions against a known set of action names.
pub fn validate_transitions(
    transitions: &[Transition],
    actions: &HashSet<String>,
) -> Result<(), GraphError> {
    let mut exhausted = HashSet::new();
    let available_actions = sorted_action_names(actions);

    for transition in transitions {
        if !actions.contains(transition.from()) {
            return Err(GraphError::TransitionSourceNotFound {
                from: transition.from().to_string(),
                available_actions: available_actions.clone(),
            });
        }
        if !actions.contains(transition.to()) {
            return Err(GraphError::TransitionTargetNotFound {
                to: transition.to().to_string(),
                available_actions: available_actions.clone(),
            });
        }
        if transition.condition().name() == "default" {
            if exhausted.contains(transition.from()) {
                return Err(GraphError::RedundantTransition {
                    from: transition.from().to_string(),
                    to: transition.to().to_string(),
                });
            }
            exhausted.insert(transition.from().to_string());
        }
    }

    Ok(())
}

fn action_name_set(actions: &[GraphAction]) -> HashSet<String> {
    actions
        .iter()
        .map(|action| action.name().to_string())
        .collect()
}

fn sorted_action_names(actions: &HashSet<String>) -> Vec<String> {
    let mut sorted: Vec<String> = actions.iter().cloned().collect();
    sorted.sort();
    sorted
}

fn escape_dot_value(value: &str) -> String {
    let mut escaped = String::with_capacity(value.len());
    for ch in value.chars() {
        match ch {
            '\\' => escaped.push_str("\\\\"),
            '"' => escaped.push_str("\\\""),
            _ => escaped.push(ch),
        }
    }
    escaped
}

#[cfg(test)]
mod tests {
    use super::{Condition, Graph, GraphAction, Transition};
    use crate::action::{ActionContext, ActionError, ActionResult, LocalAction};
    use crate::state::State;

    #[derive(Debug, Clone)]
    struct TestAction {
        name: String,
    }

    impl LocalAction for TestAction {
        fn name(&self) -> Option<&str> {
            Some(&self.name)
        }

        fn reads(&self) -> &[String] {
            &[]
        }

        fn writes(&self) -> &[String] {
            &[]
        }

        fn inputs(&self) -> &[String] {
            &[]
        }

        fn optional_inputs(&self) -> &[String] {
            &[]
        }

        fn tags(&self) -> &[String] {
            &[]
        }

        fn run(
            &self,
            _state: &State,
            _context: &ActionContext,
        ) -> Result<ActionResult, ActionError> {
            Ok(ActionResult::new(
                indexmap::IndexMap::new(),
                indexmap::IndexMap::new(),
            ))
        }

        fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
            Ok(Self { name: name.into() })
        }
    }

    fn graph_action(name: &str) -> GraphAction {
        GraphAction::new(TestAction {
            name: name.to_string(),
        })
        .expect("graph action should build")
    }

    #[test]
    fn adjacency_cache_tracks_only_outgoing_transitions_in_definition_order() {
        let graph = Graph::new(
            vec![
                graph_action("alpha"),
                graph_action("beta"),
                graph_action("gamma"),
            ],
            vec![
                Transition::new("beta", "gamma", Condition::expr("flag == true")),
                Transition::new("alpha", "beta", Condition::expr("flag == true")),
                Transition::new("beta", "alpha", Condition::default()),
                Transition::new("alpha", "gamma", Condition::default()),
            ],
            "alpha",
        )
        .expect("graph should build");

        let alpha_index = *graph
            .action_index
            .get("alpha")
            .expect("alpha index should exist");
        let beta_index = *graph
            .action_index
            .get("beta")
            .expect("beta index should exist");
        let gamma_index = *graph
            .action_index
            .get("gamma")
            .expect("gamma index should exist");

        assert_eq!(graph.transitions_from[alpha_index], vec![1, 3]);
        assert_eq!(graph.transitions_from[beta_index], vec![0, 2]);
        assert!(graph.transitions_from[gamma_index].is_empty());
    }
}
