use rurr_testkit::command_fixture::{assert_success, rurr_command, stdout_utf8};

#[test]
fn help_is_available() {
    let output = rurr_command()
        .arg("--help")
        .output()
        .expect("help invocation should run");

    assert_success(&output, "help should succeed");
    let stdout = stdout_utf8(&output);
    assert!(stdout.contains("Rurr CLI"));
}

#[test]
fn ui_build_succeeds_with_temp_home() {
    let temp_dir = tempfile::tempdir().expect("tempdir should be created");
    let out_dir = temp_dir.path().join("ui-out");

    let output = rurr_command()
        .arg("ui")
        .arg("build")
        .arg("--out-dir")
        .arg(&out_dir)
        .env("HOME", temp_dir.path())
        .output()
        .expect("ui build should run");
    assert_success(&output, "ui build should succeed");
}
