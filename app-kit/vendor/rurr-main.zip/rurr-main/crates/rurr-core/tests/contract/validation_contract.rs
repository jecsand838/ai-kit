use crate::test_support::{
    registry_test_guard, unique_registry_name, NonNegativeCountTypingSystem,
    ResumeRoundTripTypingSystem, RoundTripCountTypingSystem, StringListTypingSystem,
};
use indexmap::IndexMap;
use rurr_core::state::{register_field_serde, State, StateError};
use rurr_core::validation::assert_set;
use serde_json::json;
use std::sync::Arc;

#[test]
fn assert_set_succeeds_when_value_is_set() {
    assert_set(Some("foo"), "foo", "bar").expect("assert_set should pass when value is set");
}

#[test]
fn assert_set_errors_when_value_is_none() {
    let error = assert_set::<&str>(None, "foo", "bar")
        .expect_err("assert_set should fail when value is unset");
    assert!(
        error.to_string().contains("bar"),
        "error should mention method name for parity"
    );
}

#[test]
fn typing_failures_on_invalid_state_transitions_surface_loudly() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(
            NonNegativeCountTypingSystem::requiring_existing_count_before_increment(),
        ))
        .expect("typing system should attach");

    let error = state
        .increment(vec![("count".to_string(), -2)])
        .expect_err("typing system should reject negative count transition");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_post_action");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn typing_failures_on_invalid_update_surface_loudly() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(NonNegativeCountTypingSystem::default()))
        .expect("typing system should attach");

    let error = state
        .update(IndexMap::from([("count".to_string(), json!(-1))]))
        .expect_err("typing system should reject invalid update");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_post_action");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn roundtrip_construct_data_failures_on_invalid_update_surface_loudly() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(RoundTripCountTypingSystem))
        .expect("typing system should attach");

    let error = state
        .update(IndexMap::from([("count".to_string(), json!(-1))]))
        .expect_err("roundtrip typing system should reject invalid update");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "construct_data");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected construct_data typing error, got {other:?}"),
    }
}

#[test]
fn roundtrip_construct_state_failures_on_invalid_update_surface_loudly() {
    let state = State::new(IndexMap::from([
        ("restored".to_string(), json!(true)),
        ("__SEQUENCE_ID".to_string(), json!(7)),
        ("__PRIOR_STEP".to_string(), json!("noop")),
    ]))
    .with_typing_system(Arc::new(ResumeRoundTripTypingSystem))
    .expect("typing system should attach");

    let error = state
        .update(IndexMap::from([(
            "fail_construct_state".to_string(),
            json!(true),
        )]))
        .expect_err("roundtrip typing system should reject construct_state failures");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "construct_state");
            assert!(message.contains("rebuilding raw state"));
        }
        other => panic!("expected construct_state typing error, got {other:?}"),
    }
}

#[test]
fn typing_failures_on_invalid_extend_surface_loudly() {
    let state = State::new(IndexMap::from([("list".to_string(), json!(["a"]))]))
        .with_typing_system(Arc::new(StringListTypingSystem::new("list")))
        .expect("typing system should attach");

    let error = state
        .extend(vec![("list".to_string(), vec![json!(1)])])
        .expect_err("typing system should reject invalid extend");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("only strings"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn typing_failures_on_invalid_merge_surface_loudly() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(NonNegativeCountTypingSystem::default()))
        .expect("typing system should attach");

    let error = state
        .merge(&State::new(IndexMap::from([(
            "count".to_string(),
            json!(-1),
        )])))
        .expect_err("typing system should reject invalid merge");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn typing_failures_on_invalid_subset_surface_loudly() {
    let state = State::new(IndexMap::from([
        ("count".to_string(), json!(1)),
        ("foo".to_string(), json!("bar")),
    ]))
    .with_typing_system(Arc::new(NonNegativeCountTypingSystem::default()))
    .expect("typing system should attach");

    let error = state
        .subset(["foo"])
        .expect_err("typing system should reject invalid subset");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("integer"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn typing_failures_on_invalid_attach_surface_loudly() {
    let error = State::new(IndexMap::from([("count".to_string(), json!(-1))]))
        .with_typing_system(Arc::new(NonNegativeCountTypingSystem::default()))
        .expect_err("invalid raw state should fail typing attachment");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn field_serde_misuse_fails_loudly() {
    let _guard = registry_test_guard();
    let serializer_field = unique_registry_name("validation_serializer_field");
    register_field_serde(
        serializer_field.clone(),
        |_value| Err("serializer misuse"),
        |value| value.clone(),
    )
    .expect("serializer misuse field registration should succeed");

    let serialize_error = State::new(IndexMap::from([(
        serializer_field.clone(),
        json!("payload"),
    )]))
    .serialize()
    .expect_err("serializer misuse should fail loudly");
    match serialize_error {
        StateError::FieldSerdeHandlerFailed {
            field,
            direction,
            message,
        } => {
            assert_eq!(field, serializer_field);
            assert_eq!(direction, "serialize");
            assert!(message.contains("misuse"));
        }
        other => panic!("expected serializer misuse error, got {other:?}"),
    }

    let deserializer_field = unique_registry_name("validation_deserializer_field");
    register_field_serde(
        deserializer_field.clone(),
        |value| json!({"value": value}),
        |_value| Err("deserializer misuse"),
    )
    .expect("deserializer misuse field registration should succeed");

    let deserialize_error = State::deserialize(
        IndexMap::from([(deserializer_field.clone(), json!({"value": "payload"}))]),
        Arc::new(NonNegativeCountTypingSystem::default()),
    )
    .expect_err("deserializer misuse should fail loudly");
    match deserialize_error {
        StateError::FieldSerdeHandlerFailed {
            field,
            direction,
            message,
        } => {
            assert_eq!(field, deserializer_field);
            assert_eq!(direction, "deserialize");
            assert!(message.contains("misuse"));
        }
        other => panic!("expected deserializer misuse error, got {other:?}"),
    }
}
