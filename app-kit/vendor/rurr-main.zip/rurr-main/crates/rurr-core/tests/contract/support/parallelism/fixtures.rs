use indexmap::IndexMap;
use rurr_core::action::{ActionError, LocalAction};
use rurr_core::application::{Application, ApplicationError, Tracker, TrackerSpec};
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::parallelism::{ParallelExecutor, ParallelRuntimeContext, SubGraphTask};
use rurr_core::state::{State, StateError, StateOperation, TypingSystem};
use rurr_persistence::BaseStatePersister;
use rurr_testkit::application_fixture::{map_from_pairs, ApplicationFixtureBuilder};
pub(crate) use rurr_testkit::tracking_fixture::artifacts::{
    project_app_dir, read_json, read_jsonl,
};
use serde_json::{json, Value};
use std::sync::Arc;
use std::sync::Mutex;

pub(crate) fn app_error(message: impl Into<String>) -> ApplicationError {
    ApplicationError::Action(ActionError::Internal {
        message: message.into(),
    })
}

pub(crate) fn build_single_action_app<A: LocalAction + Send + Sync + 'static>(
    state: State,
    action_name: &str,
    action: A,
    app_id: &str,
    hooks: LifecycleAdapterSet,
    persister: Option<Arc<dyn BaseStatePersister>>,
) -> Application {
    ApplicationFixtureBuilder::single_action_with_test_identifiers(
        state,
        action_name,
        action,
        app_id,
    )
    .expect("action fixture should configure")
    .with_hooks(hooks)
    .expect("hooks should configure")
    .with_optional_sync_persister(persister)
    .expect("state persister spec should configure")
    .build()
    .expect("application should build")
}

pub(crate) fn build_looping_parent_app<A: LocalAction + Send + Sync + 'static>(
    action: A,
    app_id: &str,
    hooks: LifecycleAdapterSet,
) -> Application {
    looping_parent_builder(action, app_id, hooks)
        .build()
        .expect("application should build")
}

pub(crate) fn build_sync_persister_parent_app<A: LocalAction + Send + Sync + 'static>(
    action: A,
    app_id: &str,
    hooks: LifecycleAdapterSet,
    persister: Arc<dyn BaseStatePersister>,
) -> Application {
    looping_parent_builder(action, app_id, hooks)
        .with_sync_persister(persister)
        .expect("state persister spec should configure")
        .build()
        .expect("application should build")
}

pub(crate) fn parallel_parent_builder<A: LocalAction + Send + Sync + 'static>(
    action: A,
) -> ApplicationFixtureBuilder {
    parallel_parent_builder_with_state(State::default(), action)
}

pub(crate) fn parallel_parent_builder_with_hooks<A: LocalAction + Send + Sync + 'static>(
    action: A,
    hooks: LifecycleAdapterSet,
) -> ApplicationFixtureBuilder {
    parallel_parent_builder(action)
        .with_hooks(hooks)
        .expect("hooks should configure")
}

pub(crate) fn parallel_parent_builder_with_state<A: LocalAction + Send + Sync + 'static>(
    state: State,
    action: A,
) -> ApplicationFixtureBuilder {
    ApplicationFixtureBuilder::single_action_with_test_identifiers(
        state,
        "parallel",
        action,
        "parent-app",
    )
    .expect("parallel parent fixture should configure")
}

pub(crate) fn parallel_parent_builder_with_state_and_hooks<
    A: LocalAction + Send + Sync + 'static,
>(
    state: State,
    action: A,
    hooks: LifecycleAdapterSet,
) -> ApplicationFixtureBuilder {
    parallel_parent_builder_with_state(state, action)
        .with_hooks(hooks)
        .expect("hooks should configure")
}

pub(crate) fn build_parallel_parent_app_with_tracker<A: LocalAction + Send + Sync + 'static>(
    action: A,
    tracker: Arc<dyn Tracker>,
) -> Application {
    parallel_parent_builder(action)
        .with_tracker(TrackerSpec::provided(tracker))
        .expect("tracker should configure")
        .build()
        .expect("application should build")
}

pub(crate) async fn build_parallel_parent_async_app_with_tracker<
    A: LocalAction + Send + Sync + 'static,
>(
    action: A,
    tracker: Arc<dyn Tracker>,
) -> Application {
    parallel_parent_builder(action)
        .with_tracker(TrackerSpec::provided(tracker))
        .expect("tracker should configure")
        .abuild()
        .await
        .expect("application should build")
}

pub(crate) fn child_states(
    result: &IndexMap<String, Value>,
) -> Vec<serde_json::Map<String, Value>> {
    result
        .get("child_states")
        .and_then(Value::as_array)
        .expect("child_states should be present")
        .iter()
        .map(|value| {
            value
                .as_object()
                .cloned()
                .expect("child state should be an object")
        })
        .collect()
}

pub(crate) fn child_i64_values(result: &IndexMap<String, Value>, key: &str) -> Vec<i64> {
    child_states(result)
        .iter()
        .map(|state| {
            state
                .get(key)
                .and_then(Value::as_i64)
                .expect("child field should be an i64")
        })
        .collect()
}

pub(crate) fn child_states_in_state(state: &State) -> Vec<serde_json::Map<String, Value>> {
    state
        .get("child_states")
        .and_then(Value::as_array)
        .expect("state.child_states should be present")
        .iter()
        .map(|value| {
            value
                .as_object()
                .cloned()
                .expect("child state should be an object")
        })
        .collect()
}

pub(crate) fn child_i64_values_in_state(state: &State, key: &str) -> Vec<i64> {
    child_states_in_state(state)
        .iter()
        .map(|child_state| {
            child_state
                .get(key)
                .and_then(Value::as_i64)
                .expect("child field should be an i64")
        })
        .collect()
}

pub(crate) fn child_states_value(states: &[State]) -> Value {
    Value::Array(
        states
            .iter()
            .map(|state| Value::Object(state.get_all().into_iter().collect()))
            .collect(),
    )
}

fn looping_parent_builder<A: LocalAction + Send + Sync + 'static>(
    action: A,
    app_id: &str,
    hooks: LifecycleAdapterSet,
) -> ApplicationFixtureBuilder {
    ApplicationFixtureBuilder::single_action(State::default(), "parallel", action)
        .expect("parallel action should configure")
        .with_transitions(vec![rurr_core::graph::Transition::new(
            "parallel",
            "parallel",
            rurr_core::action::Condition::default(),
        )])
        .expect("transitions should configure")
        .with_test_identifiers(app_id)
        .expect("test identifiers should configure")
        .with_hooks(hooks)
        .expect("hooks should configure")
}

#[derive(Debug, Default)]
pub(crate) struct RecordingParallelExecutor {
    sync_batches: Mutex<Vec<Vec<String>>>,
    async_batches: Mutex<Vec<Vec<String>>>,
}

impl RecordingParallelExecutor {
    pub(crate) fn sync_batches(&self) -> Vec<Vec<String>> {
        self.sync_batches
            .lock()
            .expect("sync_batches lock should not be poisoned")
            .clone()
    }

    pub(crate) fn async_batches(&self) -> Vec<Vec<String>> {
        self.async_batches
            .lock()
            .expect("async_batches lock should not be poisoned")
            .clone()
    }
}

#[async_trait::async_trait(?Send)]
impl ParallelExecutor for RecordingParallelExecutor {
    fn execute_sync(
        &self,
        tasks: Vec<SubGraphTask>,
        _runtime: &ParallelRuntimeContext,
    ) -> Result<Vec<State>, ApplicationError> {
        self.sync_batches
            .lock()
            .expect("sync_batches lock should not be poisoned")
            .push(tasks.iter().map(|task| task.task_key.clone()).collect());
        tasks
            .into_iter()
            .map(|task| {
                task.state
                    .update(map_from_pairs([("output", json!(99))]))
                    .map_err(Into::into)
            })
            .collect()
    }

    async fn execute_async(
        &self,
        tasks: Vec<SubGraphTask>,
        _runtime: &ParallelRuntimeContext,
    ) -> Result<Vec<State>, ApplicationError> {
        self.async_batches
            .lock()
            .expect("async_batches lock should not be poisoned")
            .push(tasks.iter().map(|task| task.task_key.clone()).collect());
        tasks
            .into_iter()
            .map(|task| {
                task.state
                    .update(map_from_pairs([("output", json!(123))]))
                    .map_err(Into::into)
            })
            .collect()
    }
}

#[derive(Debug, Default)]
pub(crate) struct DelegatingParallelExecutor;

#[async_trait::async_trait(?Send)]
impl ParallelExecutor for DelegatingParallelExecutor {
    fn execute_sync(
        &self,
        tasks: Vec<SubGraphTask>,
        runtime: &ParallelRuntimeContext,
    ) -> Result<Vec<State>, ApplicationError> {
        tasks
            .into_iter()
            .map(|task| runtime.run_child_sync(task))
            .collect()
    }

    async fn execute_async(
        &self,
        tasks: Vec<SubGraphTask>,
        runtime: &ParallelRuntimeContext,
    ) -> Result<Vec<State>, ApplicationError> {
        let mut states = Vec::with_capacity(tasks.len());
        for task in tasks {
            states.push(runtime.run_child_async(task).await?);
        }
        Ok(states)
    }
}

#[derive(Debug)]
pub(crate) struct RejectSequenceDeletionTypingSystem;

impl TypingSystem for RejectSequenceDeletionTypingSystem {
    fn validate_post_action(
        &self,
        previous: &IndexMap<String, Value>,
        next: &IndexMap<String, Value>,
        operation: &StateOperation,
    ) -> Result<(), StateError> {
        if matches!(operation, StateOperation::Delete(_))
            && previous.contains_key("__SEQUENCE_ID")
            && !next.contains_key("__SEQUENCE_ID")
        {
            return Err(StateError::TypingSystem {
                phase: "validate_post_action",
                message: "__SEQUENCE_ID must survive task sanitization".to_string(),
            });
        }
        Ok(())
    }

    fn validate_state(&self, state: &IndexMap<String, Value>) -> Result<(), StateError> {
        if let Some(value) = state.get("__SEQUENCE_ID") {
            if value.as_u64().is_none() {
                return Err(StateError::TypingSystem {
                    phase: "validate_state",
                    message: "__SEQUENCE_ID must be a non-negative integer".to_string(),
                });
            }
        }
        Ok(())
    }
}
