use crate::PersistenceError;
use std::sync::atomic::{AtomicBool, Ordering};

/// Tracks whether a backend has already observed successful initialization.
#[derive(Debug)]
pub struct InitializationHint {
    initialized: AtomicBool,
}

impl InitializationHint {
    /// Creates a new hint in the uninitialized state.
    pub const fn new() -> Self {
        Self {
            initialized: AtomicBool::new(false),
        }
    }

    /// Creates a new hint with an explicit starting state.
    pub const fn from_initialized(initialized: bool) -> Self {
        Self {
            initialized: AtomicBool::new(initialized),
        }
    }

    /// Updates the cached initialization state.
    pub fn set(&self, initialized: bool) {
        self.initialized.store(initialized, Ordering::Release);
    }

    /// Returns the cached initialization state.
    pub fn is_set(&self) -> bool {
        self.initialized.load(Ordering::Acquire)
    }

    /// Marks the backend as uninitialized.
    pub fn clear(&self) {
        self.set(false);
    }

    /// Clears the hint when `error` indicates that initialization is missing.
    pub fn track_error(&self, error: PersistenceError) -> PersistenceError {
        if matches!(error, PersistenceError::NotInitialized) {
            self.clear();
        }
        error
    }
}

impl Default for InitializationHint {
    fn default() -> Self {
        Self::new()
    }
}
