use super::{
    runtime::{run_child_async, run_child_sync, sanitize_task_state},
    types::SubGraphTask,
};
use crate::{
    action::ActionError,
    application::{ApplicationError, RuntimeResources, Tracker},
    lifecycle::LifecycleAdapterSet,
    state::State,
};
use async_trait::async_trait;
use futures::future::join_all;
use std::sync::Arc;

#[derive(Clone)]
/// Runtime context passed to parallel child-graph execution.
pub struct ParallelRuntimeContext {
    parent_app_id: String,
    parent_partition_key: Option<String>,
    parent_sequence_id: u64,
    resources: RuntimeResources,
}

impl ParallelRuntimeContext {
    pub(crate) fn new(
        parent_app_id: String,
        parent_partition_key: Option<String>,
        parent_sequence_id: u64,
        resources: RuntimeResources,
    ) -> Self {
        Self {
            parent_app_id,
            parent_partition_key,
            parent_sequence_id,
            resources,
        }
    }

    /// Returns the parent application id for the child tasks being executed.
    pub fn parent_app_id(&self) -> &str {
        &self.parent_app_id
    }

    /// Returns the parent partition key, if one exists.
    pub fn parent_partition_key(&self) -> Option<&str> {
        self.parent_partition_key.as_deref()
    }

    /// Returns the parent sequence id associated with this parallel step.
    pub fn parent_sequence_id(&self) -> u64 {
        self.parent_sequence_id
    }

    /// Executes a child graph synchronously using the current runtime context.
    pub fn run_child_sync(&self, task: SubGraphTask) -> Result<State, ApplicationError> {
        run_child_sync(task, self)
    }

    /// Executes a child graph asynchronously using the current runtime context.
    pub async fn run_child_async(&self, task: SubGraphTask) -> Result<State, ApplicationError> {
        run_child_async(task, self).await
    }

    pub(crate) fn hooks(&self) -> &LifecycleAdapterSet {
        self.resources.hooks()
    }

    pub(crate) fn tracker(&self) -> Option<&Arc<dyn Tracker>> {
        self.resources.tracker()
    }

    pub(crate) fn parallel_executor(&self) -> Option<&Arc<dyn ParallelExecutor>> {
        self.resources.parallel_executor()
    }

    pub(crate) fn state_persister(&self) -> Option<&rurr_persistence::StatePersisterRef> {
        self.resources.state_persister()
    }

    pub(crate) fn state_initializer(&self) -> Option<&rurr_persistence::StateLoaderRef> {
        self.resources.state_initializer()
    }
}

#[async_trait(?Send)]
/// Strategy trait for executing a batch of parallel child tasks.
pub trait ParallelExecutor: Send + Sync {
    /// Executes child tasks synchronously.
    fn execute_sync(
        &self,
        tasks: Vec<SubGraphTask>,
        runtime: &ParallelRuntimeContext,
    ) -> Result<Vec<State>, ApplicationError> {
        tasks
            .into_iter()
            .map(|task| runtime.run_child_sync(task))
            .collect()
    }

    /// Executes child tasks asynchronously.
    async fn execute_async(
        &self,
        tasks: Vec<SubGraphTask>,
        runtime: &ParallelRuntimeContext,
    ) -> Result<Vec<State>, ApplicationError> {
        let results: Vec<Result<State, ApplicationError>> =
            join_all(tasks.into_iter().map(|task| run_child_async(task, runtime))).await;
        results.into_iter().collect()
    }
}

struct InlineParallelExecutor;

#[async_trait(?Send)]
impl ParallelExecutor for InlineParallelExecutor {}

/// Executes child tasks synchronously, optionally in pipeline mode.
pub fn execute_tasks_sync(
    tasks: Vec<SubGraphTask>,
    runtime: &ParallelRuntimeContext,
    pipeline_mode: bool,
) -> Result<Vec<State>, ApplicationError> {
    if pipeline_mode {
        let mut results = Vec::with_capacity(tasks.len());
        let mut pipeline_input: Option<State> = None;

        for task in tasks {
            let task = if let Some(next_state) = pipeline_input.take() {
                task.replace_state(next_state)
            } else {
                task
            };
            let output_state = runtime.run_child_sync(task)?;
            pipeline_input = Some(sanitize_task_state(output_state.clone())?);
            results.push(output_state);
        }

        return Ok(results);
    }

    let inline = InlineParallelExecutor;
    let executor: &dyn ParallelExecutor = runtime
        .parallel_executor()
        .map(|executor| executor.as_ref())
        .unwrap_or(&inline);
    executor.execute_sync(tasks, runtime)
}

/// Executes child tasks asynchronously.
pub async fn execute_tasks_async(
    tasks: Vec<SubGraphTask>,
    runtime: &ParallelRuntimeContext,
    pipeline_mode: bool,
) -> Result<Vec<State>, ApplicationError> {
    if pipeline_mode {
        return Err(ApplicationError::Action(
            ActionError::UnsupportedOperation {
                message: "CascadeMode::Pipeline is only supported in synchronous execution"
                    .to_string(),
            },
        ));
    }

    let inline = InlineParallelExecutor;
    let executor: &dyn ParallelExecutor = runtime
        .parallel_executor()
        .map(|executor| executor.as_ref())
        .unwrap_or(&inline);
    executor.execute_async(tasks, runtime).await
}
