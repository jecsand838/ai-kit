use async_trait::async_trait;
use futures::FutureExt;
use indexmap::IndexMap;
use redis::{AsyncCommands, Client, Commands};
use rurr_core::action::{Condition, FunctionActionBuilder};
use rurr_core::application::{Application, ApplicationBuilder, StepOutput};
use rurr_core::graph::Transition;
use rurr_persistence::{
    wire as persistence_wire, ApplicationPersistenceSpec, AsyncBaseStateLoader,
    AsyncBaseStateSaver, BaseStateLoader, BaseStateSaver, PersistedStateData, PersistedStateStatus,
    PersistenceError, PersistenceLoadTarget,
};
use rurr_redis::{AsyncRedisPersister, RedisPersister};
use rurr_testkit::application_fixture::register_prefixed_string_field_serde;
use rurr_testkit::persistence_cases::{
    self, map_from_pairs, PersistenceConfigLane, PersistenceLane, PersistenceOrderingLane,
};
use rurr_testkit::{
    cleanup_redis_namespace_async, cleanup_redis_namespace_sync, live_service_error_to_persistence,
    redis_url_from_env, wait_for_redis_ready, wait_for_redis_ready_sync, LiveServiceError,
};
use serde_json::{json, Value};
use std::collections::HashMap;
use std::future::Future;
use std::panic::AssertUnwindSafe;
use std::sync::Arc;
use uuid::Uuid;

const STATE_KEY_PREFIX: &str = "state";
const PARTITION_INDEX_KEY_PREFIX: &str = "partition_index";
const APP_INDEX_KEY_PREFIX: &str = "app_index";
const PARTITION_APP_IDS_KEY_PREFIX: &str = "app_members";
const INDEX_MEMBER_DELIMITER: char = '|';
const SORTABLE_HEX_TERMINATOR: char = '!';
const SEQUENCE_ID_WIDTH: usize = 20;
const OP_REDIS_LIVE_CLEANUP: &str = "redis_live_cleanup";
const REDIS_NAMESPACE_SCAN_COUNT: usize = 128;

fn unique_namespace(prefix: &str) -> String {
    let suffix = Uuid::new_v4().simple().to_string();
    let suffix = &suffix[..8];
    format!("rurr_redis_{prefix}_{suffix}")
}

fn lane_namespace(label: &str, prefix: &str) -> String {
    unique_namespace(&format!("{label}_{prefix}"))
}

fn hermetic_config(namespace: &str) -> rurr_redis::RedisPersisterConfig {
    rurr_redis::RedisPersisterConfig {
        redis_url: "redis://127.0.0.1:6379/0".to_string(),
        namespace: namespace.to_string(),
    }
}

fn normalize_partition_key(partition_key: Option<&str>) -> String {
    persistence_wire::normalize_partition_key(partition_key)
}

fn namespaced_key(namespace: &str, key: &str) -> String {
    if namespace.is_empty() {
        key.to_string()
    } else {
        format!("{namespace}:{key}")
    }
}

fn encoded_segment(value: &str) -> String {
    format!("{}:{value}", value.len())
}

fn expected_state_key(
    namespace: &str,
    partition_key: &str,
    app_id: &str,
    sequence_id: u64,
    position: &str,
) -> String {
    namespaced_key(
        namespace,
        &format!(
            "{STATE_KEY_PREFIX}|{}|{}|{sequence_id}|{}",
            encoded_segment(partition_key),
            encoded_segment(app_id),
            encoded_segment(position),
        ),
    )
}

fn expected_partition_index_key(namespace: &str, partition_key: &str) -> String {
    namespaced_key(
        namespace,
        &format!(
            "{PARTITION_INDEX_KEY_PREFIX}|{}",
            encoded_segment(partition_key)
        ),
    )
}

fn expected_app_index_key(namespace: &str, partition_key: &str, app_id: &str) -> String {
    namespaced_key(
        namespace,
        &format!(
            "{APP_INDEX_KEY_PREFIX}|{}|{}",
            encoded_segment(partition_key),
            encoded_segment(app_id),
        ),
    )
}

fn expected_partition_app_ids_key(namespace: &str, partition_key: &str) -> String {
    namespaced_key(
        namespace,
        &format!(
            "{PARTITION_APP_IDS_KEY_PREFIX}|{}",
            encoded_segment(partition_key)
        ),
    )
}

fn expected_legacy_partition_index_key(namespace: &str, partition_key: &str) -> String {
    if namespace.is_empty() {
        format!("index|{}", encoded_segment(partition_key))
    } else {
        format!("{namespace}:index|{}", encoded_segment(partition_key))
    }
}

fn padded_sequence_id(sequence_id: u64) -> String {
    format!("{sequence_id:0width$}", width = SEQUENCE_ID_WIDTH)
}

fn sortable_hex_encode(value: &str) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";

    let mut encoded = String::with_capacity(value.len() * 2 + 1);
    for byte in value.as_bytes() {
        encoded.push(HEX[(byte >> 4) as usize] as char);
        encoded.push(HEX[(byte & 0x0f) as usize] as char);
    }
    encoded.push(SORTABLE_HEX_TERMINATOR);
    encoded
}

fn expected_partition_index_member(
    record_key: &str,
    app_id: &str,
    sequence_id: u64,
    position: &str,
    created_at: &str,
) -> String {
    format!(
        "{created_at}{INDEX_MEMBER_DELIMITER}{}{INDEX_MEMBER_DELIMITER}{}{INDEX_MEMBER_DELIMITER}{}{INDEX_MEMBER_DELIMITER}{}",
        padded_sequence_id(sequence_id),
        sortable_hex_encode(position),
        sortable_hex_encode(app_id),
        sortable_hex_encode(record_key),
    )
}

fn expected_app_index_member(
    record_key: &str,
    sequence_id: u64,
    position: &str,
    created_at: &str,
) -> String {
    format!(
        "{}{INDEX_MEMBER_DELIMITER}{created_at}{INDEX_MEMBER_DELIMITER}{}{INDEX_MEMBER_DELIMITER}{}",
        padded_sequence_id(sequence_id),
        sortable_hex_encode(position),
        sortable_hex_encode(record_key),
    )
}

struct PreparedSave {
    record_key: String,
    partition_index_key: String,
    partition_index_member: String,
    app_index_key: String,
    app_index_member: String,
    partition_app_ids_key: String,
    partition_key: String,
    app_id: String,
    sequence_id: u64,
    position: String,
    state_json: String,
    status: &'static str,
    created_at: String,
}

struct ForcedTimestampSave<'a> {
    partition_key: Option<&'a str>,
    app_id: &'a str,
    sequence_id: u64,
    position: &'a str,
    state: IndexMap<String, Value>,
    status: PersistedStateStatus,
    created_at: &'a str,
}

fn prepared_save_with_created_at(
    config: &rurr_redis::RedisPersisterConfig,
    spec: ForcedTimestampSave<'_>,
) -> PreparedSave {
    let partition_key = normalize_partition_key(spec.partition_key);
    let record_key = expected_state_key(
        &config.namespace,
        &partition_key,
        spec.app_id,
        spec.sequence_id,
        spec.position,
    );
    let partition_index_key = expected_partition_index_key(&config.namespace, &partition_key);
    let app_index_key = expected_app_index_key(&config.namespace, &partition_key, spec.app_id);
    let partition_app_ids_key = expected_partition_app_ids_key(&config.namespace, &partition_key);
    let state_json =
        persistence_wire::serialize_state_json(&spec.state, "state_serialization_failed")
            .expect("prepare_save should serialize state");
    let status = persistence_wire::persisted_status_as_str(spec.status);
    let created_at = spec.created_at.to_string();
    let partition_index_member = expected_partition_index_member(
        &record_key,
        spec.app_id,
        spec.sequence_id,
        spec.position,
        spec.created_at,
    );
    let app_index_member = expected_app_index_member(
        &record_key,
        spec.sequence_id,
        spec.position,
        spec.created_at,
    );

    PreparedSave {
        record_key,
        partition_index_key,
        partition_index_member,
        app_index_key,
        app_index_member,
        partition_app_ids_key,
        partition_key,
        app_id: spec.app_id.to_string(),
        sequence_id: spec.sequence_id,
        position: spec.position.to_string(),
        state_json,
        status,
        created_at,
    }
}

fn completed_marker_save(
    config: &rurr_redis::RedisPersisterConfig,
    partition_key: Option<&str>,
    app_id: &str,
    sequence_id: u64,
    position: &str,
    marker: &str,
    created_at: &str,
) -> PreparedSave {
    prepared_save_with_created_at(
        config,
        ForcedTimestampSave {
            partition_key,
            app_id,
            sequence_id,
            position,
            state: map_from_pairs([("marker", json!(marker))]),
            status: PersistedStateStatus::Completed,
            created_at,
        },
    )
}

#[test]
fn sync_gate1_hermetic_contract_surface_runs_without_live_redis() {
    let config = hermetic_config("gate1_sync");
    let persister = RedisPersister::new(config.clone()).expect("sync persister should build");
    assert_eq!(persister.config(), config);
}

#[test]
fn async_gate1_hermetic_contract_surface_runs_without_live_redis() {
    let config = hermetic_config("gate1_async");
    let persister = AsyncRedisPersister::new(config.clone()).expect("async persister should build");
    assert_eq!(persister.config(), config);
}

async fn live_redis_url() -> String {
    let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
    wait_for_redis_ready(&redis_url)
        .await
        .expect("redis must be reachable for live tests");
    redis_url
}

fn live_redis_url_sync() -> String {
    let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
    wait_for_redis_ready_sync(&redis_url).expect("redis must be reachable for live tests");
    redis_url
}

fn redis_live_cleanup_error(error: LiveServiceError) -> PersistenceError {
    live_service_error_to_persistence(OP_REDIS_LIVE_CLEANUP, error)
}

fn cleanup_namespace_sync(redis_url: &str, namespace: &str) -> Result<(), PersistenceError> {
    cleanup_redis_namespace_sync(redis_url, namespace).map_err(redis_live_cleanup_error)
}

async fn cleanup_namespace_async(redis_url: &str, namespace: &str) -> Result<(), PersistenceError> {
    cleanup_redis_namespace_async(redis_url, namespace)
        .await
        .map_err(redis_live_cleanup_error)
}

fn collect_namespace_keys_sync(redis_url: &str, namespace: &str) -> Vec<String> {
    let client = Client::open(redis_url).expect("redis client should open");
    let mut connection = client
        .get_connection()
        .expect("redis connection should open");
    let pattern = format!("{namespace}:*");
    let mut cursor = 0_u64;
    let mut keys = Vec::new();

    loop {
        let (next_cursor, mut batch): (u64, Vec<String>) = redis::cmd("SCAN")
            .arg(cursor)
            .arg("MATCH")
            .arg(&pattern)
            .arg("COUNT")
            .arg(REDIS_NAMESPACE_SCAN_COUNT)
            .query(&mut connection)
            .expect("scan should succeed");
        keys.append(&mut batch);

        if next_cursor == 0 {
            break;
        }
        cursor = next_cursor;
    }

    keys.sort();
    keys.dedup();
    keys
}

async fn collect_namespace_keys_async(redis_url: &str, namespace: &str) -> Vec<String> {
    let client = Client::open(redis_url).expect("redis client should open");
    let mut connection = client
        .get_connection_manager()
        .await
        .expect("redis connection should open");
    let pattern = format!("{namespace}:*");
    let mut cursor = 0_u64;
    let mut keys = Vec::new();

    loop {
        let (next_cursor, mut batch): (u64, Vec<String>) = redis::cmd("SCAN")
            .arg(cursor)
            .arg("MATCH")
            .arg(&pattern)
            .arg("COUNT")
            .arg(REDIS_NAMESPACE_SCAN_COUNT)
            .query_async(&mut connection)
            .await
            .expect("scan should succeed");
        keys.append(&mut batch);

        if next_cursor == 0 {
            break;
        }
        cursor = next_cursor;
    }

    keys.sort();
    keys.dedup();
    keys
}

fn counter_builder() -> ApplicationBuilder {
    let start_action = FunctionActionBuilder::new()
        .writes(vec!["count".to_string()])
        .build_sync(|state, _ctx| {
            let next = state
                .get("count")
                .and_then(Value::as_i64)
                .unwrap_or_default()
                + 1;
            IndexMap::from([(String::from("count"), Value::from(next))])
        })
        .expect("action should build");
    let finish_action = FunctionActionBuilder::new()
        .writes(vec!["count".to_string()])
        .build_sync(|state, _ctx| {
            let next = state
                .get("count")
                .and_then(Value::as_i64)
                .unwrap_or_default()
                + 1;
            IndexMap::from([(String::from("count"), Value::from(next))])
        })
        .expect("action should build");

    ApplicationBuilder::new()
        .with_actions(vec![("start", start_action), ("finish", finish_action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "start",
            "finish",
            Condition::default(),
        )])
        .expect("transitions should configure")
}

fn assert_latest_sequence_for_app_outcome(loaded: PersistedStateData) {
    assert_eq!(loaded.sequence_id, 10);
    assert_eq!(loaded.position.as_deref(), Some("position_10"));
    assert_eq!(
        loaded.state,
        Some(map_from_pairs([("key", json!("value_10"))]))
    );
}

fn assert_collision_safe_key_outcome(left: PersistedStateData, right: PersistedStateData) {
    assert_eq!(left.position.as_deref(), Some("position_left"));
    assert_eq!(left.state, Some(map_from_pairs([("side", json!("left"))])));
    assert_eq!(right.position.as_deref(), Some("position_right"));
    assert_eq!(
        right.state,
        Some(map_from_pairs([("side", json!("right"))]))
    );
}

fn assert_latest_app_ordering_outcome(app_ids: Vec<String>, loaded: PersistedStateData) {
    assert_eq!(app_ids, vec!["app_a".to_string(), "app_b".to_string()]);
    assert_eq!(loaded.app_id, "app_a");
    assert_eq!(loaded.sequence_id, 50);
    assert_eq!(loaded.position.as_deref(), Some("position_a_50"));
    assert_eq!(
        loaded.state,
        Some(map_from_pairs([("key", json!("value_a_50"))]))
    );
}

fn assert_tied_created_at_partition_index_ordering_outcome(app_ids: Vec<String>) {
    assert_eq!(
        app_ids,
        vec!["zz_app".to_string(), "aa_app".to_string()],
        "list_app_ids must preserve partition-index order when created_at ties",
    );
}

struct KeyLayoutOutcome {
    expected_hash_key: String,
    expected_partition_index_key: String,
    expected_app_index_key: String,
    expected_partition_app_ids_key: String,
    legacy_partition_index_exists: bool,
    hash_exists: bool,
    hash: HashMap<String, String>,
    partition_index_members: Vec<String>,
    app_index_members: Vec<String>,
    partition_app_ids: Vec<String>,
}

fn assert_key_layout_outcome(outcome: KeyLayoutOutcome) {
    assert_ne!(
        outcome.expected_hash_key, outcome.expected_partition_index_key,
        "state and partition index keyspaces must never overlap"
    );
    assert_ne!(
        outcome.expected_hash_key, outcome.expected_app_index_key,
        "state and app index keyspaces must never overlap"
    );
    assert_ne!(
        outcome.expected_hash_key, outcome.expected_partition_app_ids_key,
        "state and app-members keyspaces must never overlap"
    );
    assert!(
        !outcome.legacy_partition_index_exists,
        "legacy Redis partition index key must not be written by the record-centric layout"
    );
    assert!(outcome.hash_exists, "hash key should exist");
    assert_eq!(
        outcome.hash.get("partition_key").map(String::as_str),
        Some("partition")
    );
    assert_eq!(
        outcome.hash.get("app_id").map(String::as_str),
        Some("app_id")
    );
    assert_eq!(
        outcome.hash.get("sequence_id").map(String::as_str),
        Some("9")
    );
    assert_eq!(
        outcome.hash.get("position").map(String::as_str),
        Some("position_9")
    );
    assert_eq!(
        outcome.hash.get("status").map(String::as_str),
        Some("completed")
    );
    let created_at = outcome
        .hash
        .get("created_at")
        .expect("created_at should be stored in the hash");
    assert_eq!(
        outcome.partition_index_members,
        vec![expected_partition_index_member(
            &outcome.expected_hash_key,
            "app_id",
            9,
            "position_9",
            created_at,
        )]
    );
    assert_eq!(
        outcome.app_index_members,
        vec![expected_app_index_member(
            &outcome.expected_hash_key,
            9,
            "position_9",
            created_at,
        )]
    );
    let mut partition_app_ids = outcome.partition_app_ids;
    partition_app_ids.sort();
    assert_eq!(partition_app_ids, vec!["app_id".to_string()]);
}

fn assert_namespace_isolation_outcome(
    loaded_one: PersistedStateData,
    loaded_two: PersistedStateData,
) {
    assert_eq!(loaded_one.position.as_deref(), Some("position_one"));
    assert_eq!(
        loaded_one.state,
        Some(map_from_pairs([("key", json!("value_one"))]))
    );
    assert_eq!(loaded_two.position.as_deref(), Some("position_two"));
    assert_eq!(
        loaded_two.state,
        Some(map_from_pairs([("key", json!("value_two"))]))
    );
}

fn assert_pipe_heavy_identity_roundtrip_outcome(
    latest_partition: PersistedStateData,
    latest_app: PersistedStateData,
    exact: PersistedStateData,
    app_ids: Vec<String>,
) {
    assert_eq!(
        latest_partition.partition_key.as_deref(),
        Some("tenant|alpha")
    );
    assert_eq!(latest_partition.app_id, "app|alpha");
    assert_eq!(latest_partition.sequence_id, 1);
    assert_eq!(
        latest_partition.position.as_deref(),
        Some("position|second")
    );
    assert_eq!(
        latest_partition.state,
        Some(map_from_pairs([("key", json!("value|second"))]))
    );

    assert_eq!(latest_app.app_id, "app|alpha");
    assert_eq!(latest_app.sequence_id, 1);
    assert_eq!(latest_app.position.as_deref(), Some("position|second"));
    assert_eq!(
        latest_app.state,
        Some(map_from_pairs([("key", json!("value|second"))]))
    );

    assert_eq!(exact.app_id, "app|alpha");
    assert_eq!(exact.sequence_id, 1);
    assert_eq!(exact.position.as_deref(), Some("position|second"));
    assert_eq!(
        exact.state,
        Some(map_from_pairs([("key", json!("value|second"))]))
    );

    assert_eq!(
        app_ids,
        vec!["app|alpha".to_string(), "app|beta".to_string()]
    );
}

#[async_trait(?Send)]
trait RedisExtraLane: PersistenceLane + PersistenceOrderingLane {
    fn config(&self) -> rurr_redis::RedisPersisterConfig;
    async fn hash_for_key(&self, key: &str) -> HashMap<String, String>;
    async fn key_exists(&self, key: &str) -> bool;
    async fn zset_members(&self, key: &str) -> Vec<String>;
    async fn set_members(&self, key: &str) -> Vec<String>;
    async fn insert_prepared_save(&self, prepared: &PreparedSave);
}

async fn run_with_dual_lane_cleanup_on_panic<M, F>(
    lane: &LiveRedisLane<M>,
    sibling: &LiveRedisLane<M>,
    future: F,
) -> Result<(), PersistenceError>
where
    M: RedisMode,
    F: Future<Output = Result<(), PersistenceError>>,
{
    match AssertUnwindSafe(future).catch_unwind().await {
        Ok(result) => result,
        Err(payload) => {
            lane.cleanup()
                .await
                .expect("current lane cleanup should succeed after test panic");
            sibling
                .cleanup()
                .await
                .expect("sibling lane cleanup should succeed after test panic");
            std::panic::resume_unwind(payload);
        }
    }
}

async fn redis_out_of_order_save_does_not_lower_latest_sequence_for_app<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    persistence_cases::run_with_cleanup(lane, async {
        lane.initialize().await?;
        lane.save(
            Some("partition"),
            "app_id",
            10,
            "position_10",
            map_from_pairs([("key", json!("value_10"))]),
            PersistedStateStatus::Completed,
        )
        .await?;
        lane.save(
            Some("partition"),
            "app_id",
            5,
            "position_5",
            map_from_pairs([("key", json!("value_5"))]),
            PersistedStateStatus::Completed,
        )
        .await?;

        let loaded = lane
            .load(Some("partition"), Some("app_id"), None)
            .await?
            .expect("state should exist");
        assert_latest_sequence_for_app_outcome(loaded);
        Ok(())
    })
    .await
}

async fn redis_state_key_encoding_prevents_partition_and_app_id_collisions<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    persistence_cases::run_with_cleanup(lane, async {
        lane.initialize().await?;
        lane.save(
            Some("a:b"),
            "c",
            1,
            "position_left",
            map_from_pairs([("side", json!("left"))]),
            PersistedStateStatus::Completed,
        )
        .await?;
        lane.save(
            Some("a"),
            "b:c",
            1,
            "position_right",
            map_from_pairs([("side", json!("right"))]),
            PersistedStateStatus::Completed,
        )
        .await?;

        let left = lane
            .load(Some("a:b"), Some("c"), Some(1))
            .await?
            .expect("left state should exist");
        let right = lane
            .load(Some("a"), Some("b:c"), Some(1))
            .await?
            .expect("right state should exist");
        assert_collision_safe_key_outcome(left, right);
        Ok(())
    })
    .await
}

async fn redis_out_of_order_save_does_not_change_latest_app_ordering<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    persistence_cases::run_with_cleanup(lane, async {
        lane.initialize().await?;
        lane.save(
            Some("partition"),
            "app_a",
            100,
            "position_a_100",
            map_from_pairs([("key", json!("value_a_100"))]),
            PersistedStateStatus::Completed,
        )
        .await?;
        lane.save(
            Some("partition"),
            "app_b",
            80,
            "position_b_80",
            map_from_pairs([("key", json!("value_b_80"))]),
            PersistedStateStatus::Completed,
        )
        .await?;
        lane.save(
            Some("partition"),
            "app_a",
            50,
            "position_a_50",
            map_from_pairs([("key", json!("value_a_50"))]),
            PersistedStateStatus::Completed,
        )
        .await?;

        let app_ids = lane.list_app_ids(Some("partition")).await?;
        let loaded = lane
            .load(Some("partition"), None, None)
            .await?
            .expect("state should exist");
        assert_latest_app_ordering_outcome(app_ids, loaded);
        Ok(())
    })
    .await
}

async fn redis_tied_created_at_uses_partition_index_ordering_for_app_ids<L: RedisExtraLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    persistence_cases::run_with_cleanup(lane, async {
        lane.initialize().await?;
        let config = lane.config();
        let tied_created_at = "2026-03-21T00:00:00.000000000Z";

        lane.insert_prepared_save(&prepared_save_with_created_at(
            &config,
            ForcedTimestampSave {
                partition_key: Some("partition"),
                app_id: "aa_app",
                sequence_id: 7,
                position: "position_1",
                state: map_from_pairs([("key", json!("value_aa"))]),
                status: PersistedStateStatus::Completed,
                created_at: tied_created_at,
            },
        ))
        .await;
        lane.insert_prepared_save(&prepared_save_with_created_at(
            &config,
            ForcedTimestampSave {
                partition_key: Some("partition"),
                app_id: "zz_app",
                sequence_id: 7,
                position: "position_9",
                state: map_from_pairs([("key", json!("value_zz"))]),
                status: PersistedStateStatus::Completed,
                created_at: tied_created_at,
            },
        ))
        .await;

        let app_ids = lane.list_app_ids(Some("partition")).await?;
        assert_tied_created_at_partition_index_ordering_outcome(app_ids);
        Ok(())
    })
    .await
}

async fn redis_writes_expected_hash_and_index_keys<L: RedisExtraLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    persistence_cases::run_with_cleanup(lane, async {
        lane.initialize().await?;
        let config = lane.config();
        lane.save(
            Some("partition"),
            "app_id",
            9,
            "position_9",
            map_from_pairs([("key", json!("value_9"))]),
            PersistedStateStatus::Completed,
        )
        .await?;

        let expected_hash_key =
            expected_state_key(&config.namespace, "partition", "app_id", 9, "position_9");
        let expected_partition_index_key =
            expected_partition_index_key(&config.namespace, "partition");
        let expected_app_index_key =
            expected_app_index_key(&config.namespace, "partition", "app_id");
        let expected_partition_app_ids_key =
            expected_partition_app_ids_key(&config.namespace, "partition");
        let legacy_partition_index_key =
            expected_legacy_partition_index_key(&config.namespace, "partition");
        let legacy_partition_index_exists = lane.key_exists(&legacy_partition_index_key).await;
        let hash_exists = lane.key_exists(&expected_hash_key).await;
        let hash = lane.hash_for_key(&expected_hash_key).await;
        let partition_index_members = lane.zset_members(&expected_partition_index_key).await;
        let app_index_members = lane.zset_members(&expected_app_index_key).await;
        let partition_app_ids = lane.set_members(&expected_partition_app_ids_key).await;
        assert_key_layout_outcome(KeyLayoutOutcome {
            expected_hash_key,
            expected_partition_index_key,
            expected_app_index_key,
            expected_partition_app_ids_key,
            legacy_partition_index_exists,
            hash_exists,
            hash,
            partition_index_members,
            app_index_members,
            partition_app_ids,
        });
        Ok(())
    })
    .await
}

async fn redis_pipe_heavy_partition_and_app_ids_roundtrip<L: PersistenceLane>(
    lane: &L,
) -> Result<(), PersistenceError> {
    persistence_cases::run_with_cleanup(lane, async {
        lane.initialize().await?;
        lane.save(
            Some("tenant|alpha"),
            "app|beta",
            0,
            "position|beta",
            map_from_pairs([("key", json!("value|beta"))]),
            PersistedStateStatus::Completed,
        )
        .await?;
        lane.save(
            Some("tenant|alpha"),
            "app|alpha",
            1,
            "position|first",
            map_from_pairs([("key", json!("value|first"))]),
            PersistedStateStatus::Completed,
        )
        .await?;
        lane.save(
            Some("tenant|alpha"),
            "app|alpha",
            1,
            "position|second",
            map_from_pairs([("key", json!("value|second"))]),
            PersistedStateStatus::Failed,
        )
        .await?;

        let latest_partition = lane
            .load(Some("tenant|alpha"), None, None)
            .await?
            .expect("latest partition state should exist");
        let latest_app = lane
            .load(Some("tenant|alpha"), Some("app|alpha"), None)
            .await?
            .expect("latest app state should exist");
        let exact = lane
            .load(Some("tenant|alpha"), Some("app|alpha"), Some(1))
            .await?
            .expect("exact state should exist");
        let app_ids = lane.list_app_ids(Some("tenant|alpha")).await?;

        assert_pipe_heavy_identity_roundtrip_outcome(latest_partition, latest_app, exact, app_ids);
        Ok(())
    })
    .await
}

#[async_trait(?Send)]
trait RedisMode {
    const MODE_LABEL: &'static str;
    type Persister;

    async fn create_persister(namespace: String) -> Self::Persister;
    fn rebuild_persister(
        config: rurr_redis::RedisPersisterConfig,
    ) -> Result<Self::Persister, PersistenceError>;
    fn config(persister: &Self::Persister) -> rurr_redis::RedisPersisterConfig;
    async fn hash_for_key(redis_url: &str, key: &str) -> HashMap<String, String>;
    async fn key_exists(redis_url: &str, key: &str) -> bool;
    async fn namespace_keys(redis_url: &str, namespace: &str) -> Vec<String>;
    async fn zset_members(redis_url: &str, key: &str) -> Vec<String>;
    async fn set_members(redis_url: &str, key: &str) -> Vec<String>;
    async fn insert_prepared_save(redis_url: &str, prepared: &PreparedSave);
    async fn initialize(persister: &Self::Persister) -> Result<(), PersistenceError>;
    async fn is_initialized(persister: &Self::Persister) -> Result<bool, PersistenceError>;
    async fn save(
        persister: &Self::Persister,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: persistence_cases::PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError>;
    async fn load(
        persister: &Self::Persister,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError>;
    async fn list_app_ids(
        persister: &Self::Persister,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError>;
    async fn build_counter_app(
        persister: Arc<Self::Persister>,
        app_id: &str,
        partition_key: Option<String>,
        load_target: Option<PersistenceLoadTarget>,
    ) -> Application;
    async fn cleanup_namespace(
        config: &rurr_redis::RedisPersisterConfig,
    ) -> Result<(), PersistenceError>;
    fn resume_persistence_spec(persister: Arc<Self::Persister>) -> ApplicationPersistenceSpec;
    async fn build_application(builder: ApplicationBuilder) -> Application;
    async fn step_counter_app(app: &mut Application) -> StepOutput;
}

struct SyncRedisMode;
struct AsyncRedisMode;

struct LiveRedisLane<M: RedisMode> {
    persister: Arc<M::Persister>,
}

impl<M: RedisMode> LiveRedisLane<M> {
    async fn new(prefix: &str) -> Self {
        let namespace = lane_namespace(M::MODE_LABEL, prefix);
        let persister = Arc::new(M::create_persister(namespace).await);
        Self { persister }
    }

    fn config(&self) -> rurr_redis::RedisPersisterConfig {
        M::config(self.persister.as_ref())
    }
}

#[async_trait(?Send)]
impl<M: RedisMode> PersistenceLane for LiveRedisLane<M> {
    async fn initialize(&self) -> Result<(), PersistenceError> {
        M::initialize(self.persister.as_ref()).await
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        M::is_initialized(self.persister.as_ref()).await
    }

    async fn cleanup(&self) -> Result<(), PersistenceError> {
        M::cleanup_namespace(&self.config()).await
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: persistence_cases::PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        M::save(
            self.persister.as_ref(),
            partition_key,
            app_id,
            sequence_id,
            position,
            state,
            status,
        )
        .await
    }

    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        M::load(self.persister.as_ref(), partition_key, app_id, sequence_id).await
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        M::list_app_ids(self.persister.as_ref(), partition_key).await
    }
}

#[async_trait(?Send)]
impl<M: RedisMode> PersistenceConfigLane for LiveRedisLane<M> {
    async fn rebuild_from_config(&self) -> Result<Self, PersistenceError> {
        Ok(Self {
            persister: Arc::new(M::rebuild_persister(self.config())?),
        })
    }
}

#[async_trait(?Send)]
impl<M: RedisMode> PersistenceOrderingLane for LiveRedisLane<M> {
    async fn seed_latest_partition_order_fixture(&self) -> Result<(), PersistenceError> {
        let config = self.config();
        for prepared in [
            completed_marker_save(
                &config,
                Some("partition"),
                "older_created_at_higher_seq",
                99,
                "step_old",
                "old",
                "2026-02-20T00:00:00.000000000Z",
            ),
            completed_marker_save(
                &config,
                Some("partition"),
                "newer_created_at_lower_seq",
                1,
                "step_new",
                "new",
                "2026-02-21T00:00:00.000000000Z",
            ),
        ] {
            M::insert_prepared_save(&config.redis_url, &prepared).await;
        }
        Ok(())
    }

    async fn seed_exact_sequence_order_fixture(&self) -> Result<(), PersistenceError> {
        let config = self.config();
        for prepared in [
            completed_marker_save(
                &config,
                Some("partition"),
                "app_id",
                7,
                "step_z",
                "older",
                "2026-02-20T00:00:00.000000000Z",
            ),
            completed_marker_save(
                &config,
                Some("partition"),
                "app_id",
                7,
                "step_a",
                "newer_low_position",
                "2026-02-21T00:00:00.000000000Z",
            ),
            completed_marker_save(
                &config,
                Some("partition"),
                "app_id",
                7,
                "step_b",
                "newer_high_position",
                "2026-02-21T00:00:00.000000000Z",
            ),
        ] {
            M::insert_prepared_save(&config.redis_url, &prepared).await;
        }
        Ok(())
    }

    async fn seed_list_app_ids_order_fixture(&self) -> Result<Vec<String>, PersistenceError> {
        let config = self.config();
        for prepared in [
            completed_marker_save(
                &config,
                Some("partition"),
                "older_created_at_higher_seq",
                99,
                "step_old",
                "old",
                "2026-02-20T00:00:00.000000000Z",
            ),
            completed_marker_save(
                &config,
                Some("partition"),
                "newer_created_at_lower_seq",
                1,
                "step_new",
                "new",
                "2026-02-21T00:00:00.000000000Z",
            ),
        ] {
            M::insert_prepared_save(&config.redis_url, &prepared).await;
        }
        Ok(vec![
            "newer_created_at_lower_seq".to_string(),
            "older_created_at_higher_seq".to_string(),
        ])
    }
}

#[async_trait(?Send)]
impl<M: RedisMode> RedisExtraLane for LiveRedisLane<M> {
    fn config(&self) -> rurr_redis::RedisPersisterConfig {
        LiveRedisLane::<M>::config(self)
    }

    async fn hash_for_key(&self, key: &str) -> HashMap<String, String> {
        M::hash_for_key(&self.config().redis_url, key).await
    }

    async fn key_exists(&self, key: &str) -> bool {
        M::key_exists(&self.config().redis_url, key).await
    }

    async fn zset_members(&self, key: &str) -> Vec<String> {
        M::zset_members(&self.config().redis_url, key).await
    }

    async fn set_members(&self, key: &str) -> Vec<String> {
        M::set_members(&self.config().redis_url, key).await
    }

    async fn insert_prepared_save(&self, prepared: &PreparedSave) {
        M::insert_prepared_save(&self.config().redis_url, prepared).await;
    }
}

#[async_trait(?Send)]
impl RedisMode for SyncRedisMode {
    const MODE_LABEL: &'static str = "sync";
    type Persister = RedisPersister;

    async fn create_persister(namespace: String) -> Self::Persister {
        RedisPersister::new(rurr_redis::RedisPersisterConfig::new(
            live_redis_url_sync(),
            namespace,
        ))
        .expect("persister should create")
    }

    fn rebuild_persister(
        config: rurr_redis::RedisPersisterConfig,
    ) -> Result<Self::Persister, PersistenceError> {
        RedisPersister::new(config)
    }

    fn config(persister: &Self::Persister) -> rurr_redis::RedisPersisterConfig {
        persister.config()
    }

    async fn hash_for_key(redis_url: &str, key: &str) -> HashMap<String, String> {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection()
            .expect("redis connection should open");
        connection.hgetall(key).expect("hgetall should succeed")
    }

    async fn key_exists(redis_url: &str, key: &str) -> bool {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection()
            .expect("redis connection should open");
        connection.exists(key).expect("exists should succeed")
    }

    async fn namespace_keys(redis_url: &str, namespace: &str) -> Vec<String> {
        collect_namespace_keys_sync(redis_url, namespace)
    }

    async fn zset_members(redis_url: &str, key: &str) -> Vec<String> {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection()
            .expect("redis connection should open");
        connection
            .zrange(key, 0, -1)
            .expect("zrange should succeed")
    }

    async fn set_members(redis_url: &str, key: &str) -> Vec<String> {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection()
            .expect("redis connection should open");
        connection.smembers(key).expect("smembers should succeed")
    }

    async fn insert_prepared_save(redis_url: &str, prepared: &PreparedSave) {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection()
            .expect("redis connection should open");
        let sequence_id = prepared.sequence_id.to_string();

        let _: () = connection
            .hset_multiple(
                prepared.record_key.as_str(),
                &[
                    ("partition_key", prepared.partition_key.as_str()),
                    ("app_id", prepared.app_id.as_str()),
                    ("sequence_id", sequence_id.as_str()),
                    ("position", prepared.position.as_str()),
                    ("state", prepared.state_json.as_str()),
                    ("status", prepared.status),
                    ("created_at", prepared.created_at.as_str()),
                ],
            )
            .expect("hset_multiple should succeed");
        let _: usize = connection
            .zadd(
                prepared.partition_index_key.as_str(),
                prepared.partition_index_member.as_str(),
                0_i32,
            )
            .expect("partition zadd should succeed");
        let _: usize = connection
            .zadd(
                prepared.app_index_key.as_str(),
                prepared.app_index_member.as_str(),
                0_i32,
            )
            .expect("app zadd should succeed");
        let _: usize = connection
            .sadd(
                prepared.partition_app_ids_key.as_str(),
                prepared.app_id.as_str(),
            )
            .expect("sadd should succeed");
    }

    async fn initialize(persister: &Self::Persister) -> Result<(), PersistenceError> {
        persister.initialize()
    }

    async fn is_initialized(persister: &Self::Persister) -> Result<bool, PersistenceError> {
        persister.is_initialized()
    }

    async fn save(
        persister: &Self::Persister,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: persistence_cases::PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        persister.save(partition_key, app_id, sequence_id, position, state, status)
    }

    async fn load(
        persister: &Self::Persister,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        persister.load(partition_key, app_id, sequence_id)
    }

    async fn list_app_ids(
        persister: &Self::Persister,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        persister.list_app_ids(partition_key)
    }

    async fn build_counter_app(
        persister: Arc<Self::Persister>,
        app_id: &str,
        partition_key: Option<String>,
        load_target: Option<PersistenceLoadTarget>,
    ) -> Application {
        counter_builder()
            .with_identifiers(app_id, partition_key, None)
            .expect("identifiers should configure")
            .with_persistence_spec(ApplicationPersistenceSpec::sync_resume(
                persister,
                true,
                map_from_pairs([("count", json!(0))]),
                "start",
                None,
                load_target,
            ))
            .expect("persistence spec should configure")
            .build()
            .expect("build should succeed")
    }

    async fn cleanup_namespace(
        config: &rurr_redis::RedisPersisterConfig,
    ) -> Result<(), PersistenceError> {
        cleanup_namespace_sync(&config.redis_url, &config.namespace)
    }

    fn resume_persistence_spec(persister: Arc<Self::Persister>) -> ApplicationPersistenceSpec {
        ApplicationPersistenceSpec::sync_resume(
            persister,
            true,
            IndexMap::new(),
            "start",
            None,
            None,
        )
    }

    async fn build_application(builder: ApplicationBuilder) -> Application {
        builder.build().expect("build should succeed")
    }

    async fn step_counter_app(app: &mut Application) -> StepOutput {
        app.step(None)
            .expect("step should succeed")
            .expect("step should execute")
    }
}

#[async_trait(?Send)]
impl RedisMode for AsyncRedisMode {
    const MODE_LABEL: &'static str = "async";
    type Persister = AsyncRedisPersister;

    async fn create_persister(namespace: String) -> Self::Persister {
        AsyncRedisPersister::new(rurr_redis::RedisPersisterConfig::new(
            live_redis_url().await,
            namespace,
        ))
        .expect("persister should create")
    }

    fn rebuild_persister(
        config: rurr_redis::RedisPersisterConfig,
    ) -> Result<Self::Persister, PersistenceError> {
        AsyncRedisPersister::new(config)
    }

    fn config(persister: &Self::Persister) -> rurr_redis::RedisPersisterConfig {
        persister.config()
    }

    async fn hash_for_key(redis_url: &str, key: &str) -> HashMap<String, String> {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection_manager()
            .await
            .expect("redis connection should open");
        connection
            .hgetall(key)
            .await
            .expect("hgetall should succeed")
    }

    async fn key_exists(redis_url: &str, key: &str) -> bool {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection_manager()
            .await
            .expect("redis connection should open");
        connection.exists(key).await.expect("exists should succeed")
    }

    async fn namespace_keys(redis_url: &str, namespace: &str) -> Vec<String> {
        collect_namespace_keys_async(redis_url, namespace).await
    }

    async fn zset_members(redis_url: &str, key: &str) -> Vec<String> {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection_manager()
            .await
            .expect("redis connection should open");
        connection
            .zrange(key, 0, -1)
            .await
            .expect("zrange should succeed")
    }

    async fn set_members(redis_url: &str, key: &str) -> Vec<String> {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection_manager()
            .await
            .expect("redis connection should open");
        connection
            .smembers(key)
            .await
            .expect("smembers should succeed")
    }

    async fn insert_prepared_save(redis_url: &str, prepared: &PreparedSave) {
        let client = Client::open(redis_url).expect("redis client should open");
        let mut connection = client
            .get_connection_manager()
            .await
            .expect("redis connection should open");
        let sequence_id = prepared.sequence_id.to_string();

        let _: () = connection
            .hset_multiple(
                prepared.record_key.as_str(),
                &[
                    ("partition_key", prepared.partition_key.as_str()),
                    ("app_id", prepared.app_id.as_str()),
                    ("sequence_id", sequence_id.as_str()),
                    ("position", prepared.position.as_str()),
                    ("state", prepared.state_json.as_str()),
                    ("status", prepared.status),
                    ("created_at", prepared.created_at.as_str()),
                ],
            )
            .await
            .expect("hset_multiple should succeed");
        let _: usize = connection
            .zadd(
                prepared.partition_index_key.as_str(),
                prepared.partition_index_member.as_str(),
                0_i32,
            )
            .await
            .expect("partition zadd should succeed");
        let _: usize = connection
            .zadd(
                prepared.app_index_key.as_str(),
                prepared.app_index_member.as_str(),
                0_i32,
            )
            .await
            .expect("app zadd should succeed");
        let _: usize = connection
            .sadd(
                prepared.partition_app_ids_key.as_str(),
                prepared.app_id.as_str(),
            )
            .await
            .expect("sadd should succeed");
    }

    async fn initialize(persister: &Self::Persister) -> Result<(), PersistenceError> {
        persister.initialize().await
    }

    async fn is_initialized(persister: &Self::Persister) -> Result<bool, PersistenceError> {
        persister.is_initialized().await
    }

    async fn save(
        persister: &Self::Persister,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: persistence_cases::PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        persister
            .save(partition_key, app_id, sequence_id, position, state, status)
            .await
    }

    async fn load(
        persister: &Self::Persister,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        persister.load(partition_key, app_id, sequence_id).await
    }

    async fn list_app_ids(
        persister: &Self::Persister,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        persister.list_app_ids(partition_key).await
    }

    async fn build_counter_app(
        persister: Arc<Self::Persister>,
        app_id: &str,
        partition_key: Option<String>,
        load_target: Option<PersistenceLoadTarget>,
    ) -> Application {
        counter_builder()
            .with_identifiers(app_id, partition_key, None)
            .expect("identifiers should configure")
            .with_persistence_spec(ApplicationPersistenceSpec::async_resume(
                persister,
                true,
                map_from_pairs([("count", json!(0))]),
                "start",
                None,
                load_target,
            ))
            .expect("persistence spec should configure")
            .abuild()
            .await
            .expect("build should succeed")
    }

    async fn cleanup_namespace(
        config: &rurr_redis::RedisPersisterConfig,
    ) -> Result<(), PersistenceError> {
        cleanup_namespace_async(&config.redis_url, &config.namespace).await
    }

    fn resume_persistence_spec(persister: Arc<Self::Persister>) -> ApplicationPersistenceSpec {
        ApplicationPersistenceSpec::async_resume(
            persister,
            true,
            IndexMap::new(),
            "start",
            None,
            None,
        )
    }

    async fn build_application(builder: ApplicationBuilder) -> Application {
        builder.abuild().await.expect("build should succeed")
    }

    async fn step_counter_app(app: &mut Application) -> StepOutput {
        app.astep(None)
            .await
            .expect("step should succeed")
            .expect("step should execute")
    }
}

async fn save_load_list_app_ids_roundtrip<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("roundtrip").await;
    persistence_cases::latest_partition_latest_app_exact_and_list(&lane)
        .await
        .expect("roundtrip assertions should succeed");
}

async fn save_accepts_multiple_positions_for_same_sequence_and_rejects_exact_duplicate<
    M: RedisMode,
>() {
    let lane = LiveRedisLane::<M>::new("duplicate").await;
    persistence_cases::duplicate_identity_behavior(&lane, "record_already_exists")
        .await
        .expect("duplicate assertions should succeed");
}

async fn load_latest_partition_app_and_exact_sequence_behaviors<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("latest_exact").await;
    persistence_cases::latest_partition_latest_app_exact_and_list(&lane)
        .await
        .expect("latest/exact assertions should succeed");
}

async fn config_roundtrip_rebuilds_persister_and_loads_saved_state<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("config_roundtrip").await;
    persistence_cases::config_roundtrip_rebuilds_persister_and_loads_saved_state(&lane)
        .await
        .expect("config roundtrip assertions should succeed");
}

async fn out_of_order_save_does_not_lower_latest_sequence_for_app<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("out_of_order_app").await;
    redis_out_of_order_save_does_not_lower_latest_sequence_for_app(&lane)
        .await
        .expect("out-of-order app assertions should succeed");
}

async fn state_key_encoding_prevents_partition_and_app_id_collisions<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("delimiter_collision").await;
    redis_state_key_encoding_prevents_partition_and_app_id_collisions(&lane)
        .await
        .expect("collision assertions should succeed");
}

async fn out_of_order_save_does_not_change_latest_app_ordering<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("out_of_order_apps").await;
    redis_out_of_order_save_does_not_change_latest_app_ordering(&lane)
        .await
        .expect("latest-app ordering assertions should succeed");
}

async fn tied_created_at_uses_partition_index_ordering_for_app_ids<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("tied_created_at").await;
    redis_tied_created_at_uses_partition_index_ordering_for_app_ids(&lane)
        .await
        .expect("tied-created-at assertions should succeed");
}

async fn writes_expected_hash_and_index_keys<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("key_layout").await;
    redis_writes_expected_hash_and_index_keys(&lane)
        .await
        .expect("key-layout assertions should succeed");
}

async fn pipe_heavy_partition_and_app_ids_roundtrip<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("pipe_heavy").await;
    redis_pipe_heavy_partition_and_app_ids_roundtrip(&lane)
        .await
        .expect("pipe-heavy assertions should succeed");
}

async fn pipe_heavy_partition_and_app_ids_roundtrip_with_namespaced_prefix<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("namespace:pipe_heavy").await;
    redis_pipe_heavy_partition_and_app_ids_roundtrip(&lane)
        .await
        .expect("namespaced pipe-heavy assertions should succeed");
}

async fn namespace_isolation<M: RedisMode>() {
    let lane_one = LiveRedisLane::<M>::new("isolation_one").await;
    let lane_two = LiveRedisLane::<M>::new("isolation_two").await;
    lane_one
        .initialize()
        .await
        .expect("initialize should succeed");
    lane_two
        .initialize()
        .await
        .expect("initialize should succeed");
    lane_one
        .save(
            Some("partition"),
            "app_id",
            1,
            "position_one",
            map_from_pairs([("key", json!("value_one"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("first save should succeed");
    lane_two
        .save(
            Some("partition"),
            "app_id",
            1,
            "position_two",
            map_from_pairs([("key", json!("value_two"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("second save should succeed");
    let loaded_one = lane_one
        .load(Some("partition"), Some("app_id"), Some(1))
        .await
        .expect("first load should succeed")
        .expect("first state should exist");
    let loaded_two = lane_two
        .load(Some("partition"), Some("app_id"), Some(1))
        .await
        .expect("second load should succeed")
        .expect("second state should exist");
    assert_namespace_isolation_outcome(loaded_one, loaded_two);
}

async fn methods_accept_none_partition_key<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("none_partition").await;
    persistence_cases::none_partition_key_roundtrip(&lane)
        .await
        .expect("none-partition assertions should succeed");
}

async fn load_with_sequence_id_and_no_app_id_returns_none<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("load_seq_without_app_id").await;
    persistence_cases::load_with_sequence_id_and_no_app_id_returns_none(&lane)
        .await
        .expect("missing-app-id assertions should succeed");
}

async fn load_nonexistent_returns_none<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("nonexistent").await;
    persistence_cases::missing_load_returns_none(&lane)
        .await
        .expect("missing-load assertions should succeed");
}

async fn save_accepts_large_u64_sequence_id<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("seq_large_u64").await;
    persistence_cases::save_accepts_large_u64_sequence_id(&lane)
        .await
        .expect("large-sequence assertions should succeed");
}

async fn persistence_spec_resume_path_loads_state_and_resumes_next_action<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("resume").await;
    persistence_cases::persistence_spec_resume_path_smoke(
        &lane,
        |lane, app_id, partition_key, load_target| {
            let persister = Arc::clone(&lane.persister);
            Box::pin(async move {
                M::build_counter_app(persister, app_id, partition_key, load_target).await
            })
        },
        |_, app| Box::pin(async move { M::step_counter_app(app).await }),
    )
    .await
    .expect("resume assertions should succeed");
}

async fn persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer<
    M: RedisMode,
>() {
    let lane = LiveRedisLane::<M>::new("fork").await;
    persistence_cases::persistence_spec_fork_smoke(
        &lane,
        |lane, app_id, partition_key, load_target| {
            let persister = Arc::clone(&lane.persister);
            Box::pin(async move {
                M::build_counter_app(persister, app_id, partition_key, load_target).await
            })
        },
        |_, app| Box::pin(async move { M::step_counter_app(app).await }),
    )
    .await
    .expect("fork assertions should succeed");
}

fn serde_resume_builder(
    field_name: &str,
    app_id: &str,
    persistence_spec: ApplicationPersistenceSpec,
) -> ApplicationBuilder {
    let start_field = field_name.to_string();
    let finish_field = field_name.to_string();

    let start_action = FunctionActionBuilder::new()
        .writes(vec![start_field.clone()])
        .build_sync(move |_state, _ctx| {
            IndexMap::from([(start_field.clone(), json!("persisted via serde"))])
        })
        .expect("start action should build");
    let finish_action = FunctionActionBuilder::new()
        .reads(vec![finish_field.clone()])
        .writes(["output"])
        .build_sync(move |state, _ctx| {
            IndexMap::from([(
                "output".to_string(),
                state.get(&finish_field).cloned().unwrap_or(Value::Null),
            )])
        })
        .expect("finish action should build");

    ApplicationBuilder::new()
        .with_actions(vec![("start", start_action), ("finish", finish_action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "start",
            "finish",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_identifiers(app_id, Some("tenant".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(persistence_spec)
        .expect("persistence spec should configure")
}

async fn build_serde_resume_app<M: RedisMode>(
    lane: &LiveRedisLane<M>,
    field_name: &str,
    app_id: &str,
) -> Application {
    M::build_application(serde_resume_builder(
        field_name,
        app_id,
        M::resume_persistence_spec(Arc::clone(&lane.persister)),
    ))
    .await
}

async fn persistence_spec_resume_roundtrips_registered_field_serde<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("serde_resume").await;
    let config = lane.config();
    let field_name = lane_namespace(M::MODE_LABEL, "serde_field");
    let app_id = format!("{}_serde_resume_app", M::MODE_LABEL);
    let state_key = expected_state_key(&config.namespace, "tenant", &app_id, 0, "start");
    register_prefixed_string_field_serde(&field_name, "serialized::")
        .expect("field serde registration should succeed");
    persistence_cases::run_with_cleanup(&lane, async {
        lane.initialize().await.expect("initialize should succeed");

        let mut first_app = build_serde_resume_app(&lane, &field_name, &app_id).await;
        let first_step = M::step_counter_app(&mut first_app).await;
        assert_eq!(first_step.action.name(), "start");
        assert_eq!(
            first_step.state.get(&field_name),
            Some(&json!("persisted via serde"))
        );

        let stored = M::load(
            lane.persister.as_ref(),
            Some("tenant"),
            Some(&app_id),
            Some(0),
        )
        .await
        .expect("load should succeed")
        .expect("stored state should exist");
        assert_eq!(
            stored
                .state
                .as_ref()
                .and_then(|state| state.get(&field_name)),
            Some(&json!({"value": "serialized::persisted via serde"}))
        );
        assert!(
            M::key_exists(&config.redis_url, &state_key).await,
            "serde-resume state key should exist before cleanup",
        );

        let mut resumed_app = build_serde_resume_app(&lane, &field_name, &app_id).await;
        assert_eq!(
            resumed_app.state().get(&field_name),
            Some(&json!("persisted via serde"))
        );
        assert_eq!(resumed_app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
        assert_eq!(
            resumed_app.state().get("__PRIOR_STEP"),
            Some(&json!("start"))
        );

        let resumed_step = M::step_counter_app(&mut resumed_app).await;
        assert_eq!(resumed_step.action.name(), "finish");
        assert_eq!(
            resumed_step.state.get("output"),
            Some(&json!("persisted via serde"))
        );

        Ok::<(), PersistenceError>(())
    })
    .await
    .expect("serde resume assertions should succeed");
    assert!(
        !M::key_exists(&config.redis_url, &state_key).await,
        "cleanup should remove the serde-resume state key",
    );
}

async fn panic_cleanup_clears_serde_resume_namespace<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("panic_cleanup_single").await;
    let config = lane.config();

    let panic_result = AssertUnwindSafe(persistence_cases::run_with_cleanup(&lane, async {
        lane.initialize().await.expect("initialize should succeed");
        lane.save(
            Some("tenant"),
            "panic_cleanup_app",
            0,
            "start",
            map_from_pairs([("value", json!("panic"))]),
            PersistedStateStatus::Completed,
        )
        .await?;
        panic!("synthetic redis panic")
    }))
    .catch_unwind()
    .await;

    assert!(panic_result.is_err(), "panic fixture should unwind");
    assert!(
        M::namespace_keys(&config.redis_url, &config.namespace)
            .await
            .is_empty(),
        "panic cleanup should reclaim the serde-resume namespace",
    );
}

async fn cleanup_removes_only_current_namespace<M: RedisMode>() {
    const MULTI_PAGE_APP_COUNT: usize = 256;

    let lane = LiveRedisLane::<M>::new("cleanup_scope").await;
    let lane_config = lane.config();
    let sibling = LiveRedisLane::<M>::new("cleanup_sibling").await;
    let sibling_config = sibling.config();

    let lane_app_id = "lane_app_0000";
    let sibling_app_id = "sibling_app_0000";
    let lane_state_key = expected_state_key(
        &lane_config.namespace,
        "partition",
        lane_app_id,
        1,
        "position_lane",
    );
    let lane_partition_index_key =
        expected_partition_index_key(&lane_config.namespace, "partition");
    let lane_app_index_key =
        expected_app_index_key(&lane_config.namespace, "partition", lane_app_id);
    let lane_members_key = expected_partition_app_ids_key(&lane_config.namespace, "partition");
    let sibling_state_key = expected_state_key(
        &sibling_config.namespace,
        "partition",
        sibling_app_id,
        1,
        "position_sibling",
    );
    let sibling_partition_index_key =
        expected_partition_index_key(&sibling_config.namespace, "partition");
    let sibling_app_index_key =
        expected_app_index_key(&sibling_config.namespace, "partition", sibling_app_id);
    let sibling_members_key =
        expected_partition_app_ids_key(&sibling_config.namespace, "partition");

    let result = run_with_dual_lane_cleanup_on_panic(&lane, &sibling, async {
        lane.initialize().await?;
        sibling.initialize().await?;
        for index in 0..MULTI_PAGE_APP_COUNT {
            let app_id = format!("lane_app_{index:04}");
            lane.save(
                Some("partition"),
                &app_id,
                1,
                "position_lane",
                map_from_pairs([("key", json!(app_id))]),
                PersistedStateStatus::Completed,
            )
            .await?;
        }
        sibling
            .save(
                Some("partition"),
                sibling_app_id,
                1,
                "position_sibling",
                map_from_pairs([("key", json!("value_sibling"))]),
                PersistedStateStatus::Completed,
            )
            .await?;

        let lane_namespace_keys =
            M::namespace_keys(&lane_config.redis_url, &lane_config.namespace).await;
        let sibling_namespace_keys =
            M::namespace_keys(&sibling_config.redis_url, &sibling_config.namespace).await;

        assert!(lane_namespace_keys.contains(&lane_state_key));
        assert!(lane_namespace_keys.contains(&lane_partition_index_key));
        assert!(lane_namespace_keys.contains(&lane_app_index_key));
        assert!(lane_namespace_keys.contains(&lane_members_key));
        assert!(sibling_namespace_keys.contains(&sibling_state_key));
        assert!(sibling_namespace_keys.contains(&sibling_partition_index_key));
        assert!(sibling_namespace_keys.contains(&sibling_app_index_key));
        assert!(sibling_namespace_keys.contains(&sibling_members_key));

        Ok::<(), PersistenceError>(())
    })
    .await;

    let lane_cleanup = lane.cleanup().await;
    let lane_namespace_keys_after =
        M::namespace_keys(&lane_config.redis_url, &lane_config.namespace).await;
    let sibling_namespace_keys_after =
        M::namespace_keys(&sibling_config.redis_url, &sibling_config.namespace).await;
    let sibling_state_exists = M::key_exists(&sibling_config.redis_url, &sibling_state_key).await;
    let sibling_partition_index_exists =
        M::key_exists(&sibling_config.redis_url, &sibling_partition_index_key).await;
    let sibling_app_index_exists =
        M::key_exists(&sibling_config.redis_url, &sibling_app_index_key).await;
    let sibling_members_exists =
        M::key_exists(&sibling_config.redis_url, &sibling_members_key).await;
    let sibling_cleanup = sibling.cleanup().await;

    result.expect("cleanup namespace fixture should succeed");
    lane_cleanup.expect("lane cleanup should succeed");
    assert!(
        lane_namespace_keys_after.is_empty(),
        "cleanup should remove the entire current lane namespace",
    );
    assert!(
        !sibling_namespace_keys_after.is_empty(),
        "cleanup must preserve sibling namespace keys",
    );
    assert!(
        sibling_state_exists
            && sibling_partition_index_exists
            && sibling_app_index_exists
            && sibling_members_exists,
        "cleanup must preserve sibling namespace keys",
    );
    sibling_cleanup.expect("sibling cleanup should succeed");
}

async fn panic_cleanup_reclaims_current_and_sibling_namespaces<M: RedisMode>() {
    let lane = LiveRedisLane::<M>::new("panic_cleanup_current").await;
    let lane_config = lane.config();
    let sibling = LiveRedisLane::<M>::new("panic_cleanup_sibling").await;
    let sibling_config = sibling.config();

    let panic_result = AssertUnwindSafe(run_with_dual_lane_cleanup_on_panic(
        &lane,
        &sibling,
        async {
            lane.initialize().await?;
            sibling.initialize().await?;
            lane.save(
                Some("partition"),
                "lane_app",
                1,
                "position_lane",
                map_from_pairs([("key", json!("value_lane"))]),
                PersistedStateStatus::Completed,
            )
            .await?;
            sibling
                .save(
                    Some("partition"),
                    "sibling_app",
                    1,
                    "position_sibling",
                    map_from_pairs([("key", json!("value_sibling"))]),
                    PersistedStateStatus::Completed,
                )
                .await?;
            panic!("synthetic dual-lane redis panic")
        },
    ))
    .catch_unwind()
    .await;

    assert!(panic_result.is_err(), "panic fixture should unwind");
    assert!(
        M::namespace_keys(&lane_config.redis_url, &lane_config.namespace)
            .await
            .is_empty(),
        "panic cleanup should reclaim the current namespace",
    );
    assert!(
        M::namespace_keys(&sibling_config.redis_url, &sibling_config.namespace)
            .await
            .is_empty(),
        "panic cleanup should reclaim the sibling namespace",
    );
}

macro_rules! redis_live_lane_tests {
    ($(($sync_name:ident, $async_name:ident, $scenario:ident)),+ $(,)?) => {
        $(
            #[test]
            fn $sync_name() {
                rurr_testkit::require_check_live_tests!();
                persistence_cases::run_sync_case($scenario::<SyncRedisMode>());
            }

            #[tokio::test]
            async fn $async_name() {
                rurr_testkit::require_check_live_tests!();
                $scenario::<AsyncRedisMode>().await;
            }
        )+
    };
}

redis_live_lane_tests!(
    (
        sync_save_load_list_app_ids_roundtrip,
        async_save_load_list_app_ids_roundtrip,
        save_load_list_app_ids_roundtrip
    ),
    (
        sync_save_accepts_multiple_positions_for_same_sequence_and_rejects_exact_duplicate,
        async_save_accepts_multiple_positions_for_same_sequence_and_rejects_exact_duplicate,
        save_accepts_multiple_positions_for_same_sequence_and_rejects_exact_duplicate
    ),
    (
        sync_load_latest_partition_app_and_exact_sequence_behaviors,
        async_load_latest_partition_app_and_exact_sequence_behaviors,
        load_latest_partition_app_and_exact_sequence_behaviors
    ),
    (
        sync_config_roundtrip_rebuilds_persister_and_loads_saved_state,
        async_config_roundtrip_rebuilds_persister_and_loads_saved_state,
        config_roundtrip_rebuilds_persister_and_loads_saved_state
    ),
    (
        sync_out_of_order_save_does_not_lower_latest_sequence_for_app,
        async_out_of_order_save_does_not_lower_latest_sequence_for_app,
        out_of_order_save_does_not_lower_latest_sequence_for_app
    ),
    (
        sync_state_key_encoding_prevents_partition_and_app_id_collisions,
        async_state_key_encoding_prevents_partition_and_app_id_collisions,
        state_key_encoding_prevents_partition_and_app_id_collisions
    ),
    (
        sync_out_of_order_save_does_not_change_latest_app_ordering,
        async_out_of_order_save_does_not_change_latest_app_ordering,
        out_of_order_save_does_not_change_latest_app_ordering
    ),
    (
        sync_tied_created_at_uses_partition_index_ordering_for_app_ids,
        async_tied_created_at_uses_partition_index_ordering_for_app_ids,
        tied_created_at_uses_partition_index_ordering_for_app_ids
    ),
    (
        sync_writes_expected_hash_and_index_keys,
        async_writes_expected_hash_and_index_keys,
        writes_expected_hash_and_index_keys
    ),
    (
        sync_pipe_heavy_partition_and_app_ids_roundtrip,
        async_pipe_heavy_partition_and_app_ids_roundtrip,
        pipe_heavy_partition_and_app_ids_roundtrip
    ),
    (
        sync_pipe_heavy_partition_and_app_ids_roundtrip_with_namespaced_prefix,
        async_pipe_heavy_partition_and_app_ids_roundtrip_with_namespaced_prefix,
        pipe_heavy_partition_and_app_ids_roundtrip_with_namespaced_prefix
    ),
    (
        sync_namespace_isolation,
        async_namespace_isolation,
        namespace_isolation
    ),
    (
        sync_methods_accept_none_partition_key,
        async_methods_accept_none_partition_key,
        methods_accept_none_partition_key
    ),
    (
        sync_load_with_sequence_id_and_no_app_id_returns_none,
        async_load_with_sequence_id_and_no_app_id_returns_none,
        load_with_sequence_id_and_no_app_id_returns_none
    ),
    (
        sync_load_nonexistent_returns_none,
        async_load_nonexistent_returns_none,
        load_nonexistent_returns_none
    ),
    (
        sync_save_accepts_large_u64_sequence_id,
        async_save_accepts_large_u64_sequence_id,
        save_accepts_large_u64_sequence_id
    ),
    (
        sync_persistence_spec_resume_path_loads_state_and_resumes_next_action,
        async_persistence_spec_resume_path_loads_state_and_resumes_next_action,
        persistence_spec_resume_path_loads_state_and_resumes_next_action
    ),
    (
        sync_persistence_spec_resume_roundtrips_registered_field_serde,
        async_persistence_spec_resume_roundtrips_registered_field_serde,
        persistence_spec_resume_roundtrips_registered_field_serde
    ),
    (
        sync_panic_cleanup_clears_serde_resume_namespace,
        async_panic_cleanup_clears_serde_resume_namespace,
        panic_cleanup_clears_serde_resume_namespace
    ),
    (
        sync_cleanup_removes_only_current_namespace,
        async_cleanup_removes_only_current_namespace,
        cleanup_removes_only_current_namespace
    ),
    (
        sync_panic_cleanup_reclaims_current_and_sibling_namespaces,
        async_panic_cleanup_reclaims_current_and_sibling_namespaces,
        panic_cleanup_reclaims_current_and_sibling_namespaces
    ),
    (
        sync_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer,
        async_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer,
        persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer
    ),
);
