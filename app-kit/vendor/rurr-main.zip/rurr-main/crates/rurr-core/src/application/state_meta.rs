use super::builder::ApplicationError;
use crate::graph::Graph;
use crate::state::State;
use serde_json::Value;

pub(crate) const PRIOR_STEP_KEY: &str = "__PRIOR_STEP";
pub(crate) const SEQUENCE_ID_KEY: &str = "__SEQUENCE_ID";

#[derive(Debug, Clone, Copy)]
enum ParsedSequenceId {
    Missing,
    Valid(u64),
    InvalidType { actual: &'static str },
}

impl ParsedSequenceId {
    fn into_result(self) -> Result<Option<u64>, ApplicationError> {
        match self {
            Self::Missing => Ok(None),
            Self::Valid(value) => Ok(Some(value)),
            Self::InvalidType { actual } => Err(ApplicationError::InvalidSequenceIdType {
                actual: actual.to_string(),
            }),
        }
    }
}

#[derive(Debug, Clone, Copy)]
enum ParsedPriorStep<'a> {
    Missing,
    Valid(&'a str),
    InvalidType { actual: &'static str },
}

impl<'a> ParsedPriorStep<'a> {
    fn into_result(self) -> Result<Option<&'a str>, ApplicationError> {
        match self {
            Self::Missing => Ok(None),
            Self::Valid(value) => Ok(Some(value)),
            Self::InvalidType { actual } => Err(ApplicationError::InvalidPriorStepType {
                actual: actual.to_string(),
            }),
        }
    }
}

#[derive(Debug, Clone)]
pub(crate) struct CommittedStateMetadata<'a> {
    state: &'a State,
    sequence_id: ParsedSequenceId,
    prior_step: ParsedPriorStep<'a>,
    preview_sequence_id: u64,
}

impl<'a> CommittedStateMetadata<'a> {
    pub(crate) fn read(state: &'a State) -> Self {
        let raw_sequence_id = state.get(SEQUENCE_ID_KEY);
        Self {
            state,
            sequence_id: parse_sequence_id(raw_sequence_id),
            prior_step: parse_prior_step(state.get(PRIOR_STEP_KEY)),
            preview_sequence_id: preview_sequence_id(raw_sequence_id),
        }
    }

    pub(crate) fn strict_sequence_id(&self) -> Result<Option<u64>, ApplicationError> {
        self.sequence_id.into_result()
    }

    pub(crate) fn strict_prior_step(&self) -> Result<Option<&'a str>, ApplicationError> {
        self.prior_step.into_result()
    }

    pub(crate) fn strict_validated_prior_step(
        &self,
        graph: &Graph,
    ) -> Result<Option<&'a str>, ApplicationError> {
        let prior_step = self.strict_prior_step()?;
        if let Some(prior_step_name) = prior_step {
            let _ = graph.get_action(prior_step_name)?;
        }
        Ok(prior_step)
    }

    pub(crate) fn strict_next_action_name(
        &self,
        graph: &Graph,
    ) -> Result<Option<String>, ApplicationError> {
        graph
            .get_next_node(self.strict_prior_step()?, self.state)
            .map_err(Into::into)
    }

    pub(crate) fn strict_reserved_sequence_id(&self) -> Result<u64, ApplicationError> {
        match self.strict_sequence_id()? {
            None => Ok(0),
            Some(current) => current
                .checked_add(1)
                .ok_or(ApplicationError::SequenceIdOverflow { current }),
        }
    }

    pub(crate) fn preview_execute_sequence_id(&self) -> u64 {
        self.strict_reserved_sequence_id()
            .unwrap_or(self.preview_sequence_id)
    }
}

pub(crate) fn parse_non_negative_u64(value: &Value) -> Option<u64> {
    if let Some(integer) = value.as_u64() {
        return Some(integer);
    }

    value.as_i64().and_then(|integer| {
        if integer < 0 {
            None
        } else {
            Some(integer as u64)
        }
    })
}

pub(crate) fn value_type_name(value: &Value) -> &'static str {
    match value {
        Value::Null => "null",
        Value::Bool(_) => "bool",
        Value::Number(number) => {
            if number.is_i64() || number.is_u64() {
                "integer"
            } else {
                "float"
            }
        }
        Value::String(_) => "string",
        Value::Array(_) => "array",
        Value::Object(_) => "object",
    }
}

fn parse_sequence_id(value: Option<&Value>) -> ParsedSequenceId {
    match value {
        None => ParsedSequenceId::Missing,
        Some(raw_value) => match parse_non_negative_u64(raw_value) {
            Some(value) => ParsedSequenceId::Valid(value),
            None => ParsedSequenceId::InvalidType {
                actual: value_type_name(raw_value),
            },
        },
    }
}

fn parse_prior_step<'a>(value: Option<&'a Value>) -> ParsedPriorStep<'a> {
    match value {
        None => ParsedPriorStep::Missing,
        Some(Value::String(value)) => ParsedPriorStep::Valid(value.as_str()),
        Some(other) => ParsedPriorStep::InvalidType {
            actual: value_type_name(other),
        },
    }
}

fn preview_sequence_id(value: Option<&Value>) -> u64 {
    match value {
        Some(Value::Number(number)) => {
            if let Some(value) = number.as_u64() {
                value
            } else if let Some(value) = number.as_i64() {
                if value < 0 {
                    0
                } else {
                    value as u64
                }
            } else {
                0
            }
        }
        _ => 0,
    }
}
