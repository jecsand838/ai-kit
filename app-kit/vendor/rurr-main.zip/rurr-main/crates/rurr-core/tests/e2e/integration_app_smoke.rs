#[cfg(not(feature = "sqlite"))]
use super::support::skip_feature;
use super::support::{map_from_pairs, unique_id};
use crate::test_support::{
    registry_test_guard, unique_registry_name, with_sync_initializer_spec, with_sync_persister_spec,
};
use indexmap::IndexMap;
use rurr_core::action::{Condition, FunctionActionBuilder};
use rurr_core::application::{ApplicationBuilder, ApplicationError};
use rurr_core::graph::Transition;
use rurr_core::lifecycle::{LifecycleAdapterSet, SyncLifecycleAdapter};
use rurr_core::state::register_field_serde;
use rurr_core::tracking::LocalTrackingClient;
#[cfg(feature = "sqlite")]
use rurr_persistence::BaseStateSaver;
use rurr_persistence::{BaseStateLoader, BaseStatePersister};
use rurr_testkit::test_dir_for_test;
use serde_json::{json, Value};
use std::sync::Arc;

#[cfg(feature = "sqlite")]
use rurr_sqlite::SqlitePersister;

fn register_custom_field_serde(field_name: &str) {
    register_field_serde(
        field_name,
        |value| {
            let text = value
                .as_str()
                .map(str::to_string)
                .unwrap_or_else(|| value.to_string());
            json!({"value": format!("serialized::{text}")})
        },
        |value| {
            let text = value
                .get("value")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .replace("serialized::", "");
            json!(text)
        },
    )
    .expect("field serde registration should succeed");
}

fn build_smoke_application(
    app_id: &str,
    initializer: Arc<dyn BaseStateLoader>,
    state_persister: Option<Arc<dyn BaseStatePersister>>,
    hooks: Option<LifecycleAdapterSet>,
    custom_field: &str,
) -> Result<rurr_core::Application, ApplicationError> {
    let custom_field_name = custom_field.to_string();
    let custom_field_name_for_serde = custom_field_name.clone();
    let custom_field_name_for_terminal = custom_field_name.clone();
    let basic_action = FunctionActionBuilder::new()
        .inputs(["user_input"])
        .writes(["dict"])
        .with_source_code(
            "fn basic_action(_state, ctx) { let user_input = ctx.inputs.get(\"user_input\").cloned().unwrap_or(Value::Null); map_from_pairs([(\"dict\", json!({\"foo\": 1, \"bar\": \"2\", \"bool\": true, \"None\": null, \"input\": user_input}))]) }",
        )
        .build_sync(|_state, ctx| {
            let user_input = ctx.inputs.get("user_input").cloned().unwrap_or(Value::Null);
            map_from_pairs([(
                "dict",
                json!({
                    "foo": 1,
                    "bar": "2",
                    "bool": true,
                    "None": null,
                    "input": user_input,
                }),
            )])
        })
        .expect("basic_action should build");

    let serde_action = FunctionActionBuilder::new()
        .reads(["dict"])
        .writes(vec![custom_field_name.clone()])
        .with_source_code(
            "fn serde_action(state, _ctx) { let dict = state.get(\"dict\").and_then(Value::as_object).expect(\"dict should be present before serde_action\"); let formatted = format!(\"foo: {}, bool: {}\", dict.get(\"foo\").and_then(Value::as_i64).unwrap_or_default(), dict.get(\"bool\").and_then(Value::as_bool).unwrap_or(false)); IndexMap::from([(custom_field_name_for_serde.clone(), json!(formatted))]) }",
        )
        .build_sync(move |state, _ctx| {
            let dict = state
                .get("dict")
                .and_then(Value::as_object)
                .expect("dict should be present before serde_action");
            let formatted = format!(
                "foo: {}, bool: {}",
                dict.get("foo").and_then(Value::as_i64).unwrap_or_default(),
                dict.get("bool").and_then(Value::as_bool).unwrap_or(false)
            );
            IndexMap::from([(custom_field_name_for_serde.clone(), json!(formatted))])
        })
        .expect("serde_action should build");

    let terminal_action = FunctionActionBuilder::new()
        .reads(vec![custom_field_name.clone()])
        .writes(["output"])
        .with_source_code(
            "fn terminal_action(state, _ctx) { let output = state.get(&custom_field_name_for_terminal).cloned().unwrap_or(Value::Null); map_from_pairs([(\"output\", output)]) }",
        )
        .build_sync(move |state, _ctx| {
            let output = state
                .get(&custom_field_name_for_terminal)
                .cloned()
                .unwrap_or(Value::Null);
            map_from_pairs([("output", output)])
        })
        .expect("terminal_action should build");

    let mut builder = with_sync_initializer_spec(
        ApplicationBuilder::new()
            .with_actions(vec![
                ("basic_action", basic_action),
                ("serde_action", serde_action),
                ("terminal_action", terminal_action),
            ])?
            .with_transitions(vec![
                Transition::new("basic_action", "serde_action", Condition::default()),
                Transition::new("serde_action", "terminal_action", Condition::default()),
            ])?
            .with_identifiers(app_id, Some(String::new()), None)?,
        initializer,
        true,
        IndexMap::from([(
            custom_field_name.clone(),
            json!("this is a custom field to serialize"),
        )]),
        "basic_action",
        None,
        None,
    )?;

    if let Some(persister) = state_persister {
        builder = with_sync_persister_spec(builder, persister)?;
    }

    if let Some(hooks) = hooks {
        builder = builder.with_hooks(hooks)?;
    }

    builder.build()
}

#[test]
fn tracker_rebuild_per_step_smoke_with_global_field_serde() {
    let _guard = registry_test_guard();
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let tracker = Arc::new(
        LocalTrackingClient::new("integration-test", &storage_root)
            .expect("tracking client should initialize"),
    );

    let tracker_loader: Arc<dyn BaseStateLoader> = tracker.clone();
    let tracker_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![tracker_hook], Vec::new());

    let app_id = unique_id("integration_tracker");
    let custom_field = unique_registry_name("custom_field");
    register_custom_field_serde(&custom_field);

    let mut step_one_app = build_smoke_application(
        &app_id,
        Arc::clone(&tracker_loader),
        None,
        Some(hooks.clone()),
        &custom_field,
    )
    .expect("step one app should build");
    tracker
        .register_application(
            step_one_app.uid(),
            step_one_app.partition_key(),
            step_one_app.graph(),
            None,
            None,
        )
        .expect("tracker registration should succeed");

    let step_one = step_one_app
        .step(Some(map_from_pairs([("user_input", json!("hello"))])))
        .expect("step one should succeed")
        .expect("step one should execute");
    assert_eq!(step_one.action.name(), "basic_action");

    let serialized = step_one
        .state
        .serialize()
        .expect("state serialization should work");
    assert_eq!(
        serialized.get(&custom_field),
        Some(&json!({"value": "serialized::this is a custom field to serialize"}))
    );

    let mut step_two_app = build_smoke_application(
        &app_id,
        Arc::clone(&tracker_loader),
        None,
        Some(hooks.clone()),
        &custom_field,
    )
    .expect("step two app should build");

    let step_two = step_two_app
        .step(None)
        .expect("step two should succeed")
        .expect("step two should execute");
    assert_eq!(step_two.action.name(), "serde_action");

    let mut step_three_app =
        build_smoke_application(&app_id, tracker_loader, None, Some(hooks), &custom_field)
            .expect("step three app should build");

    let step_three = step_three_app
        .step(None)
        .expect("step three should succeed")
        .expect("step three should execute");
    assert_eq!(step_three.action.name(), "terminal_action");

    assert_eq!(
        step_one
            .state
            .get("dict")
            .expect("dict should exist after step one"),
        step_three
            .state
            .get("dict")
            .expect("dict should exist after step three")
    );
    assert_eq!(
        step_two.state.get(&custom_field).and_then(Value::as_str),
        Some("foo: 1, bool: true")
    );
    assert_eq!(
        step_three.state.get("output").and_then(Value::as_str),
        Some("foo: 1, bool: true")
    );

    let loaded = tracker
        .load(Some(""), Some(&app_id), None)
        .expect("tracker load should succeed")
        .expect("tracker should hold persisted state");
    let loaded_state = loaded
        .state
        .expect("tracker load should return state payload");

    assert_eq!(loaded_state.get("output"), step_three.state.get("output"));
    assert_eq!(loaded_state.get("dict"), step_three.state.get("dict"));
    assert_eq!(
        loaded_state.get(&custom_field),
        Some(&json!({"value": "serialized::foo: 1, bool: true"}))
    );
}

#[cfg(feature = "sqlite")]
#[test]
fn sqlite_rebuild_per_step_smoke_with_global_field_serde() {
    let _guard = registry_test_guard();
    let temp_dir = test_dir_for_test().expect("temp dir should build");
    let db_path = temp_dir.join("integration-smoke.db");

    let sqlite = Arc::new(
        SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
            &db_path,
            "e2e_integration_app",
        ))
        .expect("sqlite persister should initialize"),
    );
    sqlite
        .initialize()
        .expect("sqlite migration should complete before tests");

    let sqlite_loader: Arc<dyn BaseStateLoader> = sqlite.clone();
    let sqlite_persister: Arc<dyn BaseStatePersister> = sqlite.clone();

    let app_id = unique_id("integration_sqlite");
    let custom_field = unique_registry_name("custom_field");
    register_custom_field_serde(&custom_field);

    let mut step_one_app = build_smoke_application(
        &app_id,
        Arc::clone(&sqlite_loader),
        Some(Arc::clone(&sqlite_persister)),
        None,
        &custom_field,
    )
    .expect("step one app should build");

    let step_one = step_one_app
        .step(Some(map_from_pairs([("user_input", json!("hello"))])))
        .expect("step one should succeed")
        .expect("step one should execute");
    assert_eq!(step_one.action.name(), "basic_action");

    let mut step_two_app = build_smoke_application(
        &app_id,
        Arc::clone(&sqlite_loader),
        Some(Arc::clone(&sqlite_persister)),
        None,
        &custom_field,
    )
    .expect("step two app should build");

    let step_two = step_two_app
        .step(None)
        .expect("step two should succeed")
        .expect("step two should execute");
    assert_eq!(step_two.action.name(), "serde_action");

    let mut step_three_app = build_smoke_application(
        &app_id,
        sqlite_loader,
        Some(sqlite_persister),
        None,
        &custom_field,
    )
    .expect("step three app should build");

    let step_three = step_three_app
        .step(None)
        .expect("step three should succeed")
        .expect("step three should execute");
    assert_eq!(step_three.action.name(), "terminal_action");

    assert_eq!(
        step_three.state.get("output").and_then(Value::as_str),
        Some("foo: 1, bool: true")
    );

    let loaded = sqlite
        .load(Some(""), Some(&app_id), None)
        .expect("sqlite load should succeed")
        .expect("sqlite should hold persisted state");
    let loaded_state = loaded
        .state
        .expect("sqlite load should return state payload");

    assert_eq!(loaded_state.get("output"), step_three.state.get("output"));
    assert_eq!(
        loaded_state.get(&custom_field),
        Some(&json!({"value": "serialized::foo: 1, bool: true"}))
    );
    let app_ids = sqlite
        .list_app_ids(Some(""))
        .expect("list_app_ids should succeed");
    assert!(
        app_ids.iter().any(|candidate| candidate == &app_id),
        "sqlite app ids should include the integration app id"
    );
}

#[cfg(not(feature = "sqlite"))]
#[test]
fn sqlite_rebuild_per_step_smoke_requires_feature() {
    skip_feature("sqlite");
}
