# crates/AGENTS.override.md — Shared crate execution rules

This file applies to staged crate work under `crates/` and supplements the repo-root `AGENTS.md`.
Use the nearest child override when one exists; `crates/rurr-core/AGENTS.override.md` and
`crates/rurr-macros/AGENTS.override.md` are stricter for their subtrees.

## Scope and precedence
- Start with repo-root `AGENTS.md`, then apply this file for everything under `crates/`.
- Treat `.codex/config.toml` as execution/config context only; it does not weaken crate-level
  verification or parity rules.
- If you edit any `AGENTS*.md` file while working in `crates/`, restart Codex before continuing.

## Remediation reopening workflow
- The Burr parity remediation program is complete; use this workflow only when the operator
  explicitly reopens remediation work.
- Before editing crate code for reopened remediation work, load:
  - `ARCHITECTURE.md`
  - `docs/00_overview.md`
  - `TASKS_PROGRESS.md`
  - `docs/refactors/burr-parity-remediation/README.md`
- Only work on the reopened remediation phase recorded in `TASKS_PROGRESS.md`.
- Limit crate edits to the targets owned by that reopened phase plus minimal compile fallout needed to keep the phase coherent.
- Do not begin another remediation phase inside the same worktree until the current reopened phase is committed or the progress file says it is complete.
- Treat `docs/refactors/rurr-refactor/` as archive-only history for the completed Phase 1-8 bundle.

## Progress discipline
- For reopened remediation work, update `TASKS_PROGRESS.md` at phase start, after each loop-stage transition, after required gates run, and before any blocked handoff.
- Record branch/worktree, recorded loop stage, gates run, commit SHA, and residual risks exactly once the information is known.
- If you stop mid-phase, leave exact resume instructions in `TASKS_PROGRESS.md`.

## Guardrails
- Preserve public APIs and documented Burr parity constraints unless the reopened remediation phase explicitly says otherwise.
- Keep strict TDD for behavior changes and do not weaken tests to get a phase through its gates.
- If the reopened remediation phase requires oracle, competition, or live checks, follow `docs/refactors/burr-parity-remediation/README.md` and the repo-root gate flow exactly.
- Do not let crate-local non-live tests invent external/provider/backend behavior when the workspace expects a named strict proof lane.
- If a crate behavior is unavailable or unproven, prefer explicit `Unsupported`, `NotYetImplemented`, or typed configuration/startup errors over synthetic fallback paths.
- Do not use helper macros or macro helper crates to reduce ordinary crate-code duplication. Use
  domain structs, enums, methods, and real trait boundaries instead.
