use super::support::{map_from_pairs, state_from_pairs, unique_id};
use crate::test_support::{
    with_async_initializer_spec, with_async_persister_spec, with_sync_initializer_spec,
    with_sync_persister_spec,
};
use futures::StreamExt;
use indexmap::IndexMap;
use rurr_core::action::{
    ActionContext, ActionError, ActionResult, Condition, FunctionActionBuilder, InputAction,
    LocalAction, ResultAction, StreamOutput,
};
use rurr_core::application::{ApplicationBuilder, ApplicationError};
use rurr_core::graph::{GraphAction, Transition};
use rurr_core::lifecycle::LifecycleError;
use rurr_core::lifecycle::{LifecycleAdapterSet, PostStepContext, SyncLifecycleAdapter};
use rurr_core::parallelism::{CascadeMode, ParallelMap, ParallelTaskSource, RunnableGraph};
use rurr_core::state::State;
use rurr_persistence::{
    AsyncBaseStateLoader, AsyncBaseStatePersister, AsyncInMemoryPersister, BaseStateLoader,
    BaseStatePersister, InMemoryPersister, PersistedStateStatus,
};
use serde_json::{json, Value};
use std::collections::{BTreeMap, BTreeSet};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use tokio::time::{sleep, Duration};

const COLLATZ_MIN: i64 = 80;
const COLLATZ_MAX: i64 = 100;
const DETERMINISTIC_FAILURE: &str = "deterministic fail-once";

fn app_error(message: impl Into<String>) -> ApplicationError {
    ApplicationError::Action(ActionError::Internal {
        message: message.into(),
    })
}

fn collatz_steps(mut n: i64) -> usize {
    let mut steps = 0;
    while n != 1 {
        if n % 2 == 0 {
            n /= 2;
        } else {
            n = 3 * n + 1;
        }
        steps += 1;
    }
    steps
}

#[derive(Debug, Default)]
struct StepCountHook {
    count: AtomicUsize,
}

impl StepCountHook {
    fn value(&self) -> usize {
        self.count.load(Ordering::SeqCst)
    }
}

impl SyncLifecycleAdapter for StepCountHook {
    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        if context.action_name() != "result" {
            self.count.fetch_add(1, Ordering::SeqCst);
        }
        Ok(())
    }
}

#[derive(Debug, Clone)]
struct NamedActionCountHook {
    action_name: &'static str,
    count: Arc<AtomicUsize>,
}

impl NamedActionCountHook {
    fn new(action_name: &'static str, count: Arc<AtomicUsize>) -> Self {
        Self { action_name, count }
    }
}

impl SyncLifecycleAdapter for NamedActionCountHook {
    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        if context.action_name() == self.action_name {
            self.count.fetch_add(1, Ordering::SeqCst);
        }
        Ok(())
    }
}

#[derive(Clone)]
struct DeterministicCollatzAction {
    name: Option<String>,
    even_branch: bool,
    fail_on_value: Option<i64>,
    fail_once_seen: Arc<Mutex<BTreeSet<i64>>>,
    async_delay: bool,
    reads: Vec<String>,
    writes: Vec<String>,
}

impl DeterministicCollatzAction {
    fn new(
        even_branch: bool,
        fail_on_value: Option<i64>,
        fail_once_seen: Arc<Mutex<BTreeSet<i64>>>,
        async_delay: bool,
    ) -> Self {
        Self {
            name: None,
            even_branch,
            fail_on_value,
            fail_once_seen,
            async_delay,
            reads: vec!["n".to_string(), "n_history".to_string()],
            writes: vec!["n".to_string(), "n_history".to_string()],
        }
    }

    fn execute(&self, state: &State) -> Result<ActionResult, ActionError> {
        let current =
            state
                .get("n")
                .and_then(Value::as_i64)
                .ok_or_else(|| ActionError::Internal {
                    message: "missing integer n".to_string(),
                })?;

        if self.fail_on_value == Some(current) {
            let mut seen = self
                .fail_once_seen
                .lock()
                .expect("fail-once set lock should not be poisoned");
            if !seen.contains(&current) {
                seen.insert(current);
                return Err(ActionError::Internal {
                    message: format!("{DETERMINISTIC_FAILURE}: n={current}"),
                });
            }
        }

        let next = if self.even_branch {
            current / 2
        } else {
            3 * current + 1
        };
        let mut history = state
            .get("n_history")
            .and_then(Value::as_array)
            .cloned()
            .unwrap_or_default();
        history.push(json!(next));

        let result = map_from_pairs([("n", json!(next)), ("n_history", Value::Array(history))]);
        Ok(ActionResult::new(result.clone(), result))
    }
}

impl LocalAction for DeterministicCollatzAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &self.reads
    }

    fn writes(&self) -> &[String] {
        &self.writes
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }

        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        self.execute(state)
    }

    async fn run_async(
        &self,
        state: &State,
        _ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        if self.async_delay {
            sleep(Duration::from_millis(1)).await;
        }
        self.execute(state)
    }
}

#[derive(Clone)]
struct LazyStreamingAction {
    name: Option<String>,
    calls: Arc<AtomicUsize>,
    writes: Vec<String>,
}

impl LazyStreamingAction {
    fn new(calls: Arc<AtomicUsize>) -> Self {
        Self {
            name: None,
            calls,
            writes: vec!["count".to_string()],
        }
    }
}

impl LocalAction for LazyStreamingAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &self.writes
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }

        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        let next = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
        let result = map_from_pairs([("count", json!(next))]);
        Ok(ActionResult::new(result.clone(), result))
    }

    fn stream_run_async(
        &self,
        state: State,
        _ctx: ActionContext,
    ) -> std::pin::Pin<Box<dyn futures::Stream<Item = StreamOutput>>> {
        let calls = Arc::clone(&self.calls);
        let base = state.get("count").and_then(Value::as_i64).unwrap_or(0);
        let stream = futures::stream::unfold(0usize, move |index| {
            let calls = Arc::clone(&calls);
            let state = state.clone();
            async move {
                if index >= 2 {
                    return None;
                }
                let next_index = index + 1;
                calls.fetch_add(1, Ordering::SeqCst);
                let value = base + next_index as i64;
                let item = map_from_pairs([("count", json!(value))]);
                let output = if next_index == 2 {
                    let final_state = state
                        .update(map_from_pairs([("count", json!(value))]))
                        .expect("stream terminal state update should succeed");
                    Ok((item, Some(final_state)))
                } else {
                    Ok((item, None))
                };
                Some((output, next_index))
            }
        });

        Box::pin(stream)
    }
}

fn named_graph_action<A>(name: &str, action: A) -> GraphAction
where
    A: LocalAction + Send + Sync + 'static,
{
    let named = action
        .with_name(name)
        .expect("action naming should succeed");
    GraphAction::new(named).expect("graph action construction should succeed")
}

fn collatz_child_graph(
    fail_on_value: Option<i64>,
    fail_once_seen: Arc<Mutex<BTreeSet<i64>>>,
    child_execution_counts: Arc<Mutex<BTreeMap<String, usize>>>,
    async_delay: bool,
) -> RunnableGraph {
    let child_execution_counts_for_initial = Arc::clone(&child_execution_counts);
    let initial = FunctionActionBuilder::new()
        .reads(["n"])
        .writes(["n", "original_n", "n_history"])
        .build_sync(move |state, ctx| {
            let app_id = ctx
                .app_context
                .as_ref()
                .map(|context| context.app_id.clone())
                .expect("child initial action should run with an application context app id");
            let mut counts = child_execution_counts_for_initial
                .lock()
                .expect("child execution counts lock should not be poisoned");
            let count = counts.entry(app_id.clone()).or_insert(0);
            *count += 1;
            assert_eq!(
                *count, 1,
                "child initial action should execute once per child app id, got repeats for {app_id}"
            );
            let n = state.get("n").cloned().unwrap_or_else(|| json!(0));
            let history = state
                .get("n_history")
                .cloned()
                .unwrap_or_else(|| Value::Array(Vec::new()));
            map_from_pairs([("n", n.clone()), ("original_n", n), ("n_history", history)])
        })
        .expect("initial action should build");

    let even = DeterministicCollatzAction::new(
        true,
        fail_on_value,
        Arc::clone(&fail_once_seen),
        async_delay,
    );
    let odd = DeterministicCollatzAction::new(false, fail_on_value, fail_once_seen, async_delay);

    RunnableGraph::new(
        vec![
            named_graph_action("initial", initial),
            named_graph_action("even", even),
            named_graph_action("odd", odd),
            named_graph_action(
                "result",
                ResultAction::new(["n_history", "original_n", "n"]),
            ),
        ],
        vec![
            Transition::new("initial", "result", Condition::expr("n == 1")),
            Transition::new("even", "result", Condition::expr("n == 1")),
            Transition::new("initial", "even", Condition::expr("n % 2 == 0")),
            Transition::new("even", "even", Condition::expr("n % 2 == 0")),
            Transition::new("odd", "even", Condition::expr("n % 2 == 0")),
            Transition::new("initial", "odd", Condition::expr("n % 2 != 0")),
            Transition::new("even", "odd", Condition::expr("n % 2 != 0")),
            Transition::new("odd", "odd", Condition::expr("n % 2 != 0")),
        ],
        Some("initial".to_string()),
    )
}

fn parallel_collatz_action(
    fail_on_value: Option<i64>,
    fail_once_seen: Arc<Mutex<BTreeSet<i64>>>,
    child_execution_counts: Arc<Mutex<BTreeMap<String, usize>>>,
    async_delay: bool,
) -> ParallelMap {
    let child_graph = collatz_child_graph(
        fail_on_value,
        fail_once_seen,
        child_execution_counts,
        async_delay,
    );

    let splitter = Arc::new(|state: &State, _ctx: &ActionContext| {
        let numbers = state
            .get("ns")
            .and_then(Value::as_array)
            .ok_or_else(|| app_error("parallel collatz requires array field `ns`"))?;
        Ok(numbers
            .iter()
            .map(|n| state_from_pairs([("n", n.clone()), ("n_history", json!([]))]))
            .collect::<Vec<_>>())
    });

    let reducer = Arc::new(|states: Vec<State>| {
        let mut counts = BTreeMap::new();
        for state in states {
            let original = state
                .get("original_n")
                .and_then(Value::as_i64)
                .ok_or_else(|| app_error("missing `original_n` in child result"))?;
            let history_len = state
                .get("n_history")
                .and_then(Value::as_array)
                .map(|values| values.len() as u64)
                .ok_or_else(|| app_error("missing `n_history` in child result"))?;
            counts.insert(original.to_string(), Value::from(history_len));
        }

        let counts_value = Value::Object(counts.into_iter().collect());
        Ok(state_from_pairs([("counts", counts_value)]))
    });

    ParallelMap::new(
        ParallelTaskSource::states(child_graph, splitter),
        vec!["ns".to_string()],
        vec!["counts".to_string()],
        vec![],
        CascadeMode::Fixed(reducer),
    )
}

fn parallel_collatz_builder(
    app_id: &str,
    fail_on_value: Option<i64>,
    fail_once_seen: Arc<Mutex<BTreeSet<i64>>>,
    child_execution_counts: Arc<Mutex<BTreeMap<String, usize>>>,
    async_delay: bool,
    hooks: Option<LifecycleAdapterSet>,
) -> Result<ApplicationBuilder, ApplicationError> {
    let map_step = FunctionActionBuilder::new()
        .writes(["ns"])
        .build_sync(|_state, _ctx| {
            let ns = (COLLATZ_MIN..COLLATZ_MAX)
                .map(Value::from)
                .collect::<Vec<Value>>();
            map_from_pairs([("ns", Value::Array(ns))])
        })
        .expect("map_step action should build");

    let mut builder = ApplicationBuilder::new()
        .with_actions(vec![("map_step", map_step)])?
        .with_actions(vec![(
            "parallel_collatz",
            parallel_collatz_action(
                fail_on_value,
                fail_once_seen,
                child_execution_counts,
                async_delay,
            ),
        )])?
        .with_actions(vec![("final", ResultAction::new(["counts"]))])?
        .with_transitions(vec![
            Transition::new("map_step", "parallel_collatz", Condition::default()),
            Transition::new("parallel_collatz", "final", Condition::default()),
        ])?
        .with_identifiers(app_id, Some(String::new()), None)?;

    if let Some(hooks) = hooks {
        builder = builder.with_hooks(hooks)?;
    }

    Ok(builder)
}

fn build_parallel_collatz_app(
    app_id: &str,
    persister: Arc<InMemoryPersister>,
    fail_on_value: Option<i64>,
    fail_once_seen: Arc<Mutex<BTreeSet<i64>>>,
    child_execution_counts: Arc<Mutex<BTreeMap<String, usize>>>,
    async_delay: bool,
    hooks: Option<LifecycleAdapterSet>,
) -> Result<rurr_core::Application, ApplicationError> {
    let loader: Arc<dyn BaseStateLoader> = persister.clone();
    let saver: Arc<dyn BaseStatePersister> = persister;

    let builder = parallel_collatz_builder(
        app_id,
        fail_on_value,
        fail_once_seen,
        child_execution_counts,
        async_delay,
        hooks,
    )?;
    let builder = with_sync_initializer_spec(
        builder,
        loader,
        true,
        IndexMap::new(),
        "map_step",
        None,
        None,
    )?;
    with_sync_persister_spec(builder, saver)?.build()
}

async fn build_async_parallel_collatz_app(
    app_id: &str,
    persister: Arc<AsyncInMemoryPersister>,
    fail_on_value: Option<i64>,
    fail_once_seen: Arc<Mutex<BTreeSet<i64>>>,
    child_execution_counts: Arc<Mutex<BTreeMap<String, usize>>>,
    async_delay: bool,
    hooks: Option<LifecycleAdapterSet>,
) -> Result<rurr_core::Application, ApplicationError> {
    let loader: Arc<dyn AsyncBaseStateLoader> = persister.clone();
    let saver: Arc<dyn AsyncBaseStatePersister> = persister;

    let builder = parallel_collatz_builder(
        app_id,
        fail_on_value,
        fail_once_seen,
        child_execution_counts,
        async_delay,
        hooks,
    )?;
    let builder = with_async_initializer_spec(
        builder,
        loader,
        true,
        IndexMap::new(),
        "map_step",
        None,
        None,
    )?;
    with_async_persister_spec(builder, saver)?.abuild().await
}

fn build_async_save_load_app(
    app_id: &str,
    persister: Arc<InMemoryPersister>,
) -> Result<rurr_core::Application, ApplicationError> {
    let loader: Arc<dyn BaseStateLoader> = persister.clone();
    let saver: Arc<dyn BaseStatePersister> = persister;

    let dummy_input = FunctionActionBuilder::new()
        .reads(["chat_history"])
        .writes(["prompt", "chat_history"])
        .build_async(|state, _ctx| async move {
            sleep(Duration::from_millis(1)).await;
            let next = state
                .get("chat_history")
                .and_then(Value::as_array)
                .and_then(|values| values.last())
                .and_then(Value::as_i64)
                .unwrap_or(0)
                + 1;
            let mut history = state
                .get("chat_history")
                .and_then(Value::as_array)
                .cloned()
                .unwrap_or_default();
            history.push(json!(next));
            map_from_pairs([
                ("prompt", json!("PROMPT")),
                ("chat_history", Value::Array(history)),
            ])
        })
        .expect("dummy_input action should build");

    let dummy_response = FunctionActionBuilder::new()
        .reads(["chat_history"])
        .writes(["response", "chat_history"])
        .build_async(|state, _ctx| async move {
            sleep(Duration::from_millis(1)).await;
            let next = state
                .get("chat_history")
                .and_then(Value::as_array)
                .and_then(|values| values.last())
                .and_then(Value::as_i64)
                .unwrap_or(0)
                + 1;
            let mut history = state
                .get("chat_history")
                .and_then(Value::as_array)
                .cloned()
                .unwrap_or_default();
            history.push(json!(next));
            map_from_pairs([
                ("response", json!("RESPONSE")),
                ("chat_history", Value::Array(history)),
            ])
        })
        .expect("dummy_response action should build");

    let builder = with_sync_initializer_spec(
        ApplicationBuilder::new()
            .with_actions(vec![
                ("dummy_input", dummy_input),
                ("dummy_response", dummy_response),
            ])?
            .with_transitions(vec![
                Transition::new("dummy_input", "dummy_response", Condition::default()),
                Transition::new("dummy_response", "dummy_input", Condition::default()),
            ])?
            .with_identifiers(app_id, Some(String::new()), None)?,
        loader,
        true,
        map_from_pairs([("chat_history", json!([]))]),
        "dummy_input",
        None,
        None,
    )?;
    with_sync_persister_spec(builder, saver)?.build()
}

#[test]
fn collatz_function_api_reaches_one_and_counts_steps() {
    let hook = Arc::new(StepCountHook::default());
    let hook_adapter: Arc<dyn SyncLifecycleAdapter> = hook.clone();

    let even = FunctionActionBuilder::new()
        .reads(["n", "n_history"])
        .writes(["n", "n_history"])
        .build_sync(|state, _ctx| {
            let n = state.get("n").and_then(Value::as_i64).unwrap_or(0);
            let mut history = state
                .get("n_history")
                .and_then(Value::as_array)
                .cloned()
                .unwrap_or_default();
            let next = n / 2;
            history.push(json!(next));
            map_from_pairs([("n", json!(next)), ("n_history", Value::Array(history))])
        })
        .expect("even action should build");

    let odd = FunctionActionBuilder::new()
        .reads(["n", "n_history"])
        .writes(["n", "n_history"])
        .build_sync(|state, _ctx| {
            let n = state.get("n").and_then(Value::as_i64).unwrap_or(0);
            let mut history = state
                .get("n_history")
                .and_then(Value::as_array)
                .cloned()
                .unwrap_or_default();
            let next = 3 * n + 1;
            history.push(json!(next));
            map_from_pairs([("n", json!(next)), ("n_history", Value::Array(history))])
        })
        .expect("odd action should build");

    let hooks = LifecycleAdapterSet::new(vec![hook_adapter], Vec::new());

    let mut app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("n_history", json!([]))]))
        .expect("state should configure")
        .with_actions(vec![("original", InputAction::new(["n"]))])
        .expect("original action should configure")
        .with_actions(vec![("even", even), ("odd", odd)])
        .expect("even and odd actions should configure")
        .with_actions(vec![("result", ResultAction::new(["n_history"]))])
        .expect("actions should configure")
        .with_transitions(vec![
            Transition::new("original", "result", Condition::expr("n == 1")),
            Transition::new("even", "result", Condition::expr("n == 1")),
            Transition::new("original", "even", Condition::expr("n % 2 == 0")),
            Transition::new("even", "even", Condition::expr("n % 2 == 0")),
            Transition::new("odd", "even", Condition::expr("n % 2 == 0")),
            Transition::new("original", "odd", Condition::expr("n % 2 != 0")),
            Transition::new("even", "odd", Condition::expr("n % 2 != 0")),
            Transition::new("odd", "odd", Condition::expr("n % 2 != 0")),
        ])
        .expect("transitions should configure")
        .with_entrypoint("original")
        .expect("entrypoint should configure")
        .with_hooks(hooks)
        .expect("hooks should configure")
        .build()
        .expect("application should build");

    let output = app
        .run_with_options(
            rurr_core::ExecutionOptions::new()
                .with_inputs(map_from_pairs([("n", json!(1000))]))
                .halt_after(["result"]),
        )
        .expect("run should succeed");

    assert_eq!(
        output.action.as_ref().map(|action| action.name()),
        Some("result")
    );
    let history = output
        .result
        .as_ref()
        .and_then(|result| result.get("n_history"))
        .and_then(Value::as_array)
        .expect("n_history should be present in result");
    assert_eq!(history.last(), Some(&json!(1)));
    assert_eq!(history.len(), 111);
    assert_eq!(hook.value(), 112);
}

#[test]
fn parallel_collatz_sync_retry_resume_eventually_completes() {
    let app_id = unique_id("parallel_collatz_sync");
    let persister = Arc::new(InMemoryPersister::new());
    let fail_once_seen = Arc::new(Mutex::new(BTreeSet::new()));
    let child_execution_counts = Arc::new(Mutex::new(BTreeMap::new()));
    let map_step_count = Arc::new(AtomicUsize::new(0));
    let map_step_hook: Arc<dyn SyncLifecycleAdapter> = Arc::new(NamedActionCountHook::new(
        "map_step",
        Arc::clone(&map_step_count),
    ));
    let map_step_hooks = LifecycleAdapterSet::new(vec![map_step_hook], Vec::new());

    let mut attempts = 0usize;
    let mut saw_failure_checkpoint = false;
    let final_state = loop {
        attempts += 1;
        let mut app = build_parallel_collatz_app(
            &app_id,
            Arc::clone(&persister),
            Some(COLLATZ_MIN),
            Arc::clone(&fail_once_seen),
            Arc::clone(&child_execution_counts),
            false,
            Some(map_step_hooks.clone()),
        )
        .expect("parallel collatz app should build");

        match app.run_with_options(rurr_core::ExecutionOptions::new().halt_after(["final"])) {
            Ok(output) => break output.state,
            Err(error) => {
                let persisted = persister
                    .load(Some(""), Some(&app_id), None)
                    .expect("persister load should succeed")
                    .expect("checkpoint must exist after failed attempt");
                assert_eq!(
                    persisted.position.as_deref(),
                    Some("map_step"),
                    "failed attempt must resume from map_step checkpoint"
                );
                assert_eq!(
                    persisted.status,
                    PersistedStateStatus::Completed,
                    "checkpoint after failure must remain completed map_step state"
                );
                assert_eq!(
                    persisted.sequence_id, 0,
                    "map_step checkpoint sequence id should remain 0"
                );
                saw_failure_checkpoint = true;
                assert!(
                    error.to_string().contains(DETERMINISTIC_FAILURE),
                    "unexpected error while retrying parallel collatz: {error}"
                );
                assert!(attempts < 4, "parallel collatz should converge quickly");
            }
        }
    };

    assert_eq!(
        attempts, 2,
        "deterministic fail-once should need two attempts"
    );
    assert!(
        saw_failure_checkpoint,
        "test must observe at least one failed attempt checkpoint"
    );
    assert_eq!(
        map_step_count.load(Ordering::SeqCst),
        1,
        "map_step should execute exactly once across retries when resume wiring is correct"
    );
    let child_execution_counts = child_execution_counts
        .lock()
        .expect("child execution counts lock should not be poisoned");
    assert_eq!(
        child_execution_counts.len(),
        (COLLATZ_MAX - COLLATZ_MIN) as usize,
        "child app id set should remain stable across retries"
    );
    assert!(
        child_execution_counts.values().all(|count| *count == 1),
        "each child app should execute initial exactly once across parent retries"
    );
    assert_eq!(
        final_state.get("__SEQUENCE_ID").and_then(Value::as_u64),
        Some(2),
        "final sequence id should prove resume at parallel_collatz then final"
    );

    let counts = final_state
        .get("counts")
        .and_then(Value::as_object)
        .expect("counts should be present in final state");
    assert_eq!(counts.len(), (COLLATZ_MAX - COLLATZ_MIN) as usize);

    for number in COLLATZ_MIN..COLLATZ_MAX {
        let expected = collatz_steps(number) as u64;
        assert_eq!(
            counts.get(&number.to_string()).and_then(Value::as_u64),
            Some(expected),
            "unexpected collatz step count for {number}"
        );
    }
}

#[tokio::test]
async fn parallel_collatz_async_retry_resume_eventually_completes() {
    let app_id = unique_id("parallel_collatz_async");
    let persister = Arc::new(AsyncInMemoryPersister::new());
    let fail_once_seen = Arc::new(Mutex::new(BTreeSet::new()));
    let child_execution_counts = Arc::new(Mutex::new(BTreeMap::new()));
    let map_step_count = Arc::new(AtomicUsize::new(0));
    let map_step_hook: Arc<dyn SyncLifecycleAdapter> = Arc::new(NamedActionCountHook::new(
        "map_step",
        Arc::clone(&map_step_count),
    ));
    let map_step_hooks = LifecycleAdapterSet::new(vec![map_step_hook], Vec::new());

    let mut attempts = 0usize;
    let mut saw_failure_checkpoint = false;
    let final_state = loop {
        attempts += 1;
        let mut app = build_async_parallel_collatz_app(
            &app_id,
            Arc::clone(&persister),
            Some(COLLATZ_MIN + 1),
            Arc::clone(&fail_once_seen),
            Arc::clone(&child_execution_counts),
            true,
            Some(map_step_hooks.clone()),
        )
        .await
        .expect("parallel collatz app should build");

        match app
            .arun_with_options(rurr_core::ExecutionOptions::new().halt_after(["final"]))
            .await
        {
            Ok(output) => break output.state,
            Err(error) => {
                let persisted = persister
                    .load(Some(""), Some(&app_id), None)
                    .await
                    .expect("persister load should succeed")
                    .expect("checkpoint must exist after failed attempt");
                assert_eq!(
                    persisted.position.as_deref(),
                    Some("map_step"),
                    "failed attempt must resume from map_step checkpoint"
                );
                assert_eq!(
                    persisted.status,
                    PersistedStateStatus::Completed,
                    "checkpoint after failure must remain completed map_step state"
                );
                assert_eq!(
                    persisted.sequence_id, 0,
                    "map_step checkpoint sequence id should remain 0"
                );
                saw_failure_checkpoint = true;
                assert!(
                    error.to_string().contains(DETERMINISTIC_FAILURE),
                    "unexpected async error while retrying parallel collatz: {error}"
                );
                assert!(attempts < 4, "parallel collatz should converge quickly");
            }
        }
    };

    assert_eq!(
        attempts, 2,
        "deterministic fail-once should need two attempts"
    );
    assert!(
        saw_failure_checkpoint,
        "test must observe at least one failed attempt checkpoint"
    );
    assert_eq!(
        map_step_count.load(Ordering::SeqCst),
        1,
        "map_step should execute exactly once across retries when resume wiring is correct"
    );
    let child_execution_counts = child_execution_counts
        .lock()
        .expect("child execution counts lock should not be poisoned");
    assert_eq!(
        child_execution_counts.len(),
        (COLLATZ_MAX - COLLATZ_MIN) as usize,
        "child app id set should remain stable across retries"
    );
    assert!(
        child_execution_counts.values().all(|count| *count == 1),
        "each child app should execute initial exactly once across parent retries"
    );
    assert_eq!(
        final_state.get("__SEQUENCE_ID").and_then(Value::as_u64),
        Some(2),
        "final sequence id should prove resume at parallel_collatz then final"
    );

    let counts = final_state
        .get("counts")
        .and_then(Value::as_object)
        .expect("counts should be present in final state");
    assert_eq!(counts.len(), (COLLATZ_MAX - COLLATZ_MIN) as usize);

    for number in COLLATZ_MIN..COLLATZ_MAX {
        let expected = collatz_steps(number) as u64;
        assert_eq!(
            counts.get(&number.to_string()).and_then(Value::as_u64),
            Some(expected),
            "unexpected collatz step count for {number}"
        );
    }
}

#[test]
fn echo_bot_iterate_flow_returns_prompted_response() {
    let echo = FunctionActionBuilder::new()
        .reads(["prompt"])
        .writes(["response"])
        .build_sync(|state, _ctx| {
            let prompt = state.get("prompt").cloned().unwrap_or(Value::Null);
            map_from_pairs([("response", prompt)])
        })
        .expect("echo action should build");

    let mut app = ApplicationBuilder::new()
        .with_actions(vec![("prompt", InputAction::new(["prompt"]))])
        .expect("prompt action should configure")
        .with_actions(vec![("response", echo)])
        .expect("response action should configure")
        .with_transitions(vec![Transition::new(
            "prompt",
            "response",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_entrypoint("prompt")
        .expect("entrypoint should configure")
        .build()
        .expect("application should build");

    let halt_after = vec!["response".to_string()];
    let mut iter = app.iterate_with_options(
        rurr_core::ExecutionOptions::new()
            .with_inputs(map_from_pairs([("prompt", json!("hello"))]))
            .halt_after(halt_after),
    );

    let first = iter
        .next()
        .expect("first iterate item should exist")
        .expect("first iterate item should succeed");
    assert_eq!(first.action.name(), "prompt");

    let second = iter
        .next()
        .expect("second iterate item should exist")
        .expect("second iterate item should succeed");
    assert_eq!(second.action.name(), "response");
    assert!(second.halted);

    assert!(
        iter.next().is_none(),
        "iterate should stop after halt_after"
    );
    drop(iter);

    assert_eq!(app.state().get("response").cloned(), Some(json!("hello")));
}

#[tokio::test]
async fn async_save_load_resume_end_to_end() {
    let app_id = unique_id("async_save_load");
    let persister = Arc::new(InMemoryPersister::new());

    let mut first = build_async_save_load_app(&app_id, Arc::clone(&persister))
        .expect("first async app should build");

    let first_run = first
        .arun_with_options(rurr_core::ExecutionOptions::new().halt_after(["dummy_response"]))
        .await
        .expect("first async run should succeed");

    let first_history = first_run
        .state
        .get("chat_history")
        .and_then(Value::as_array)
        .expect("chat_history should exist after first run");
    assert_eq!(first_history, &vec![json!(1), json!(2)]);

    let mut resumed = build_async_save_load_app(&app_id, Arc::clone(&persister))
        .expect("resumed async app should build");

    let resumed_history = resumed
        .state()
        .get("chat_history")
        .and_then(Value::as_array)
        .expect("chat_history should exist after initializer-spec resume");
    assert_eq!(resumed_history, &vec![json!(1), json!(2)]);

    let resumed_run = resumed
        .arun_with_options(rurr_core::ExecutionOptions::new().halt_after(["dummy_response"]))
        .await
        .expect("resumed async run should succeed");

    let final_history = resumed_run
        .state
        .get("chat_history")
        .and_then(Value::as_array)
        .expect("chat_history should exist after resumed run");
    assert_eq!(final_history, &vec![json!(1), json!(2), json!(3), json!(4)]);
}

#[tokio::test]
async fn streaming_smoke_collects_items_lazily_and_preserves_terminal_output() {
    let calls = Arc::new(AtomicUsize::new(0));
    let action = LazyStreamingAction::new(Arc::clone(&calls));

    let mut app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![("stream", action)])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("stream")
        .expect("entrypoint should configure")
        .build()
        .expect("application should build");

    let (_action, mut stream_result) = app
        .astream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(["stream"]))
        .await
        .expect("astream_result should build");

    assert_eq!(calls.load(Ordering::SeqCst), 0, "stream setup must be lazy");

    let mut collected = Vec::new();
    while let Some(item) = stream_result.next().await {
        collected.push(item);
    }
    assert_eq!(
        calls.load(Ordering::SeqCst),
        2,
        "stream should advance per item"
    );
    assert_eq!(
        collected.len(),
        1,
        "stream_result yields only intermediate items; terminal output is returned via get()"
    );
    for item in collected {
        assert!(item.is_ok(), "stream item should not error: {item:?}");
    }

    let (terminal, state) = stream_result
        .get()
        .await
        .expect("terminal get should succeed");
    assert_eq!(
        terminal.as_ref().and_then(|it| it.get("count")),
        Some(&json!(2))
    );
    assert_eq!(state.get("count").cloned(), Some(json!(2)));
}
