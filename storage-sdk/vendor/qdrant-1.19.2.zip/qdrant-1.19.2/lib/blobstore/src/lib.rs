pub mod blob;
mod blobstore;
pub mod config;
pub mod error;
pub mod fixtures;
mod tracker;

pub use blob::Blob;
// The append-only variant, it is public for backends that only append, which cannot name
// `Blobstore` as it is bound at `UniversalWrite + UniversalAppend`
pub use blobstore::Logstore;
// The bitmask belongs to the Gridstore variant, it is only public for the benchmarks
pub use blobstore::gridstore::bitmask;
pub use blobstore::{Blobstore, BlobstoreReader, BlobstoreView};
pub use tracker::tracker_journal_path;

use crate::error::BlobstoreError;

pub(crate) type Result<T, E = BlobstoreError> = std::result::Result<T, E>;
