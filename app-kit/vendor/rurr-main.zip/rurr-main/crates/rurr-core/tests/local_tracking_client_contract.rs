mod support;

mod local_tracking_client_contract {
    use crate::support::local_client as local_client_support;
    use crate::support::local_client_actions;
    use crate::support::tracking_actions;
    use rurr_core::action::FunctionActionBuilder;
    use rurr_core::application::{ApplicationError, ParentPointer};
    use rurr_core::lifecycle::{
        AsyncLifecycleAdapter, LifecycleAdapterSet, LifecycleError, PostStepContext, StreamContext,
        StreamItemContext, SyncLifecycleAdapter,
    };
    use rurr_core::tracking::{
        allowed_project_name, ApplicationMetadataModel, ChildApplicationModel, LocalTrackingClient,
        TrackingError,
    };
    use rurr_persistence::{BaseStateLoader, PersistedStateStatus, PersistenceError};
    use rurr_testkit::application_fixture::{build_sync_app, map_from_pairs};
    use rurr_testkit::test_dir_for_test;
    use rurr_testkit::tracking_fixture::artifacts::{
        project_app_dir, read_json, read_jsonl, read_jsonl_if_exists,
        write_raw_tracking_metadata as write_raw_metadata,
        write_tracking_metadata as write_metadata,
    };
    use rurr_testkit::tracking_fixture::{
        build_counter_template_app, registered_async_app, registered_sync_app, seeded_app_dir,
        seeded_counter_app_dir,
    };
    use serde_json::{json, Value};
    use std::collections::BTreeSet;
    use std::fs;
    use std::sync::Arc;
    use std::time::SystemTime;

    use self::local_client_actions::broken_action;
    use self::local_client_support::{
        app_dir, app_log_path, assert_invalid_input_tracking_io, assert_log_event_counts,
        assert_logs_to_correct_app_after_registering_multiple_apps, assert_stream_case,
        count_log_entries, counter_end_entry, counter_end_entry_with_exception, ensure_app_dir,
        read_app_log, read_app_log_if_exists, register_application, span_events, tracker,
        write_app_log_entries, MultiAppRouteMode, StreamFixture, TrackingMode,
    };
    use self::tracking_actions::{
        build_cross_factory_routed_sync_action, build_delta_sync_action,
        build_single_step_sync_action, build_traced_async_action, build_traced_sync_action,
    };

    mod alias_and_write_guards;
    mod basics_and_spans;
    mod load_and_partition;
    mod multi_app_and_symlink_root;
    mod streaming_and_async;
}
