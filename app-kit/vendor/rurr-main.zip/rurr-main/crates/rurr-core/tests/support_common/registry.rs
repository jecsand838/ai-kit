use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Mutex, MutexGuard, OnceLock};

static REGISTRY_LOCK: OnceLock<Mutex<()>> = OnceLock::new();
static REGISTRY_NAME_COUNTER: AtomicUsize = AtomicUsize::new(0);

pub(crate) fn registry_test_guard() -> MutexGuard<'static, ()> {
    REGISTRY_LOCK
        .get_or_init(|| Mutex::new(()))
        .lock()
        .expect("registry test mutex should not be poisoned")
}

pub(crate) fn unique_registry_name(prefix: &str) -> String {
    format!(
        "{prefix}_{}",
        REGISTRY_NAME_COUNTER.fetch_add(1, Ordering::Relaxed)
    )
}
