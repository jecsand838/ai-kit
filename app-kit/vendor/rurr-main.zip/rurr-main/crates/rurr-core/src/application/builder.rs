use super::build::{build_from_builder_async, build_from_builder_sync};
use crate::action::api::{ActionError, LocalAction};
use crate::application::context::ParentPointer;
use crate::application::initialize_from_spec::InitializeFromSpec;
use crate::application::tracker_spec::TrackerSpec;
use crate::application::Application;
use crate::graph::{Graph, GraphAction, GraphError, Transition};
use crate::lifecycle::{LifecycleAdapterSet, LifecycleError};
use crate::parallelism::ParallelExecutor;
use crate::state::{State, StateError, TypingSystem};
use crate::tracking::TrackingError;
use rurr_persistence::{ApplicationPersistenceSpec, PersistenceError, StateLoaderRef};
use std::convert::Infallible;
use std::sync::Arc;
use thiserror::Error;

/// Error returned while configuring, building, or validating an application.
#[derive(Debug, Error)]
pub enum ApplicationError {
    /// Action configuration or execution failed.
    #[error(transparent)]
    Action(#[from] ActionError),
    /// Graph validation failed.
    #[error(transparent)]
    Graph(#[from] GraphError),
    /// Persistence configuration or loading failed.
    #[error(transparent)]
    Persistence(#[from] PersistenceError),
    /// Tracking setup or I/O failed.
    #[error(transparent)]
    Tracking(#[from] TrackingError),
    /// State validation or mutation failed.
    #[error(transparent)]
    State(#[from] StateError),
    /// A persistence initializer was configured after explicit state or an
    /// explicit entrypoint.
    #[error(
        "cannot configure a persistence initializer after state or entrypoint has been configured"
    )]
    PersistenceInitializerConflictsWithStateOrEntrypoint,
    /// `with_state` was called after a persistence initializer was configured.
    #[error("cannot call with_state after a persistence initializer has been configured")]
    WithStateAfterPersistenceInitializer,
    /// `with_entrypoint` was called after a persistence initializer was configured.
    #[error("cannot call with_entrypoint after a persistence initializer has been configured")]
    WithEntrypointAfterPersistenceInitializer,
    /// `with_entrypoint` was called more than once.
    #[error("cannot call with_entrypoint more than once")]
    EntrypointAlreadyConfigured,
    /// A persistence load target attempted to reuse the current app id.
    #[error("explicit persistence load target cannot reuse the target app id")]
    PersistenceLoadTargetMatchesTargetAppId,
    /// More than one parallel executor was configured.
    #[error("parallel executor already configured")]
    ParallelExecutorAlreadyConfigured,
    /// A sync build attempted to use an async initializer.
    #[error("sync build cannot use async initializer")]
    SyncBuildUsedAsyncInitializer,
    /// A sync build attempted to use an async persister.
    #[error("sync build cannot use async state persister")]
    SyncBuildUsedAsyncPersister,
    /// An async build attempted to use a sync initializer.
    #[error("async build cannot use sync initializer")]
    AsyncBuildUsedSyncInitializer,
    /// An async build attempted to use a sync persister.
    #[error("async build cannot use sync state persister")]
    AsyncBuildUsedSyncPersister,
    /// A sync run API was used on an async application.
    #[error("async application must be executed with async step/arun/streaming APIs")]
    AsyncApplicationUsedSyncRun,
    /// A sync single-step API was used on an async application.
    #[error("async application must use astep for step execution")]
    AsyncApplicationUsedSyncStep,
    /// A sync streaming API was used on an async application.
    #[error("async application must use async streaming APIs")]
    AsyncApplicationUsedSyncStream,
    /// Sync execution attempted to use an async state persister.
    #[error("sync execution cannot use async state persister")]
    SyncRunUsedAsyncPersister,
    /// A persistence initializer returned a record without state.
    #[error(
        "initializer returned a persisted record with state=None; return None for missing records"
    )]
    InitializerReturnedMissingState,
    /// A failed persisted record omitted its position.
    #[error(
        "initializer returned failed persisted record with position=None; failed resume requires position"
    )]
    InitializerReturnedFailedStateWithoutPosition,
    /// The reserved `__SEQUENCE_ID` value had the wrong type.
    #[error("__SEQUENCE_ID must be a non-negative integer, got {actual}")]
    InvalidSequenceIdType {
        /// String description of the value that was received.
        actual: String,
    },
    /// Reserving the next sequence id overflowed `u64`.
    #[error("__SEQUENCE_ID overflow while reserving next id from {current}")]
    SequenceIdOverflow {
        /// Sequence id that could not be incremented safely.
        current: u64,
    },
    /// The reserved `__PRIOR_STEP` value had the wrong type.
    #[error("__PRIOR_STEP must be a string, got {actual}")]
    InvalidPriorStepType {
        /// String description of the value that was received.
        actual: String,
    },
    /// A single-step output payload was malformed for the action.
    #[error("single-step output validation failed for action {action_name}: {message}")]
    InvalidSingleStepOutput {
        /// Action whose output failed validation.
        action_name: String,
        /// Human-readable validation failure.
        message: String,
    },
    /// Result streaming was requested when no next action existed.
    #[error("cannot stream result: no next action found (prior step: {prior_step:?})")]
    NoNextActionForStreaming {
        /// Prior step recorded on the application, when one exists.
        prior_step: Option<String>,
    },
    /// Halt controls referenced action names that are not registered.
    ///
    /// This validation runs during execution startup after any `@tag:<tag>`
    /// selectors have expanded. Unknown explicit action selectors from
    /// `halt_before` and `halt_after` are reported together in first-seen
    /// order, before lifecycle execute-call guards or action bodies start.
    #[error(
        "halt controls reference unknown actions {missing_actions:?}; available actions: {available_actions:?}"
    )]
    InvalidHaltActions {
        /// Unknown action names referenced by halt controls.
        missing_actions: Vec<String>,
        /// Registered graph actions.
        available_actions: Vec<String>,
    },
    /// The streaming action returned a terminal failure.
    #[error("streaming action failed: {message}")]
    StreamingActionFailed {
        /// Human-readable streaming failure.
        message: String,
    },
    /// A stream step handle was used after it had already been finalized.
    #[error("stream step handle has already been finalized")]
    StreamStepHandleClosed,
    /// An internal streaming invariant was violated.
    #[error("streaming invariant violation: {message}")]
    StreamInvariantViolation {
        /// Static description of the violated invariant.
        message: &'static str,
    },
    /// A panic was captured and converted into an application error.
    #[error("captured panic in {scope}: {message}")]
    PanicCaptured {
        /// Logical scope that captured the panic.
        scope: &'static str,
        /// Panic payload rendered as a string.
        message: String,
    },
    /// A lifecycle hook returned an error or panic.
    #[error("lifecycle hook failed during {phase}: {message}")]
    LifecycleHookFailed {
        /// Lifecycle phase that failed.
        phase: &'static str,
        /// Human-readable hook failure.
        message: String,
    },
    /// A visibility operation returned an error or panic.
    #[error("visibility operation failed during {operation}: {message}")]
    VisibilityFailed {
        /// Visibility operation that failed.
        operation: &'static str,
        /// Human-readable failure message.
        message: String,
    },
    /// A required internal state key was absent.
    #[error("required state key missing: {key}")]
    MissingStateKey {
        /// Missing state key.
        key: String,
    },
    /// An internal application invariant was violated.
    #[error("invalid internal state: {message}")]
    InternalInvariant {
        /// Static description of the invariant failure.
        message: &'static str,
    },
    /// Callers attempted to supply reserved runtime input keys.
    #[error(
        "inputs starting with '__' ({keys:?}) are reserved for runtime context and cannot be provided by callers"
    )]
    ReservedRuntimeInputKeys {
        /// Reserved keys supplied by the caller.
        keys: Vec<String>,
    },
}

impl From<Infallible> for ApplicationError {
    fn from(value: Infallible) -> Self {
        match value {}
    }
}

impl From<LifecycleError> for ApplicationError {
    fn from(value: LifecycleError) -> Self {
        ApplicationError::LifecycleHookFailed {
            phase: value.phase(),
            message: value.message().to_string(),
        }
    }
}

impl<N, A> TryFrom<(N, A)> for GraphAction
where
    N: Into<String>,
    A: LocalAction + Send + Sync + 'static,
{
    type Error = ApplicationError;

    fn try_from(value: (N, A)) -> Result<Self, Self::Error> {
        let (name, action) = value;
        let named = LocalAction::with_name(&action, name.into())?;
        Ok(GraphAction::new(named)?)
    }
}

/// Builder for constructing [`Application`] values and their runtime resources.
///
/// The builder collects the graph, initial state or persistence initializer,
/// lifecycle hooks, optional tracker, persistence spec, typing system, and
/// parallel executor before validating them into a runnable application. Use
/// [`build`](Self::build) for purely synchronous actions/hooks and
/// [`abuild`](Self::abuild) when the graph, initializer, lifecycle lane, or
/// persister requires async execution.
#[derive(Default)]
pub struct ApplicationBuilder {
    pub(super) actions: Vec<GraphAction>,
    pub(super) transitions: Vec<Transition>,
    pub(super) entrypoint: Option<String>,
    pub(super) imported_entrypoint: Option<String>,
    pub(super) explicit_state: Option<State>,
    pub(super) app_id: Option<String>,
    pub(super) partition_key: Option<String>,
    pub(super) sequence_id: Option<u64>,
    pub(super) parent_pointer: Option<ParentPointer>,
    pub(super) spawning_parent_pointer: Option<ParentPointer>,
    pub(super) hooks: LifecycleAdapterSet,
    pub(super) tracker_spec: Option<TrackerSpec>,
    pub(super) parallel_executor: Option<Arc<dyn ParallelExecutor>>,
    pub(super) persistence_spec: ApplicationPersistenceSpec,
    pub(super) typing_system: Option<Arc<dyn TypingSystem>>,
}

impl ApplicationBuilder {
    /// Creates an empty application builder.
    pub fn new() -> Self {
        Self::default()
    }

    /// Adds actions to the application definition.
    ///
    /// Each item is converted into a named [`GraphAction`]. Existing actions are
    /// preserved, so callers can add actions in multiple batches as long as the
    /// final graph validates.
    pub fn with_actions<I, T>(mut self, actions: I) -> Result<Self, ApplicationError>
    where
        I: IntoIterator<Item = T>,
        GraphAction: TryFrom<T>,
        ApplicationError: From<<GraphAction as TryFrom<T>>::Error>,
    {
        self.actions.extend(convert_actions(actions)?);
        Ok(self)
    }

    /// Imports all actions, transitions, and the entrypoint from an existing
    /// [`Graph`].
    pub fn with_graph(mut self, graph: Graph) -> Result<Self, ApplicationError> {
        let (actions, transitions, imported_entrypoint) = graph.into_parts();
        if self.imported_entrypoint.is_none() {
            self.imported_entrypoint = Some(imported_entrypoint);
        }
        self.actions.extend(actions);
        self.transitions.extend(transitions);
        Ok(self)
    }

    /// Imports multiple graphs into one builder.
    pub fn with_graphs<I>(self, graphs: I) -> Result<Self, ApplicationError>
    where
        I: IntoIterator<Item = Graph>,
    {
        graphs
            .into_iter()
            .try_fold(self, |builder, graph| builder.with_graph(graph))
    }

    /// Adds transitions to the application definition.
    ///
    /// Transitions are evaluated against committed state after each step. When no
    /// transition matches, the run/step APIs stop at the current action.
    pub fn with_transitions<I>(mut self, transitions: I) -> Result<Self, ApplicationError>
    where
        I: IntoIterator<Item = Transition>,
    {
        self.transitions.extend(transitions);
        Ok(self)
    }

    /// Sets the application entrypoint explicitly.
    pub fn with_entrypoint(
        mut self,
        entrypoint: impl Into<String>,
    ) -> Result<Self, ApplicationError> {
        if self.has_initializer() {
            return Err(ApplicationError::WithEntrypointAfterPersistenceInitializer);
        }
        if self.entrypoint.is_some() {
            return Err(ApplicationError::EntrypointAlreadyConfigured);
        }
        self.entrypoint = Some(entrypoint.into());
        Ok(self)
    }

    /// Sets the explicit initial state.
    pub fn with_state(mut self, state: State) -> Result<Self, ApplicationError> {
        if self.has_initializer() {
            return Err(ApplicationError::WithStateAfterPersistenceInitializer);
        }
        self.explicit_state = Some(state);
        Ok(self)
    }

    /// Sets application identifiers used for persistence, tracking, and runtime
    /// context.
    ///
    /// `app_id` identifies the application run. `partition_key` groups runs in
    /// tracking and persistence stores, and `sequence_id` seeds the committed
    /// step counter when resuming or importing state.
    pub fn with_identifiers(
        mut self,
        app_id: impl Into<String>,
        partition_key: Option<String>,
        sequence_id: Option<u64>,
    ) -> Result<Self, ApplicationError> {
        self.app_id = Some(app_id.into());
        if let Some(partition_key) = partition_key {
            self.partition_key = Some(partition_key);
        }
        if let Some(sequence_id) = sequence_id {
            self.sequence_id = Some(sequence_id);
        }
        Ok(self)
    }

    /// Records the parent application that spawned this application.
    pub fn with_spawning_parent(
        mut self,
        app_id: impl Into<String>,
        partition_key: Option<String>,
        sequence_id: u64,
    ) -> Result<Self, ApplicationError> {
        self.spawning_parent_pointer = Some(ParentPointer {
            app_id: app_id.into(),
            partition_key,
            sequence_id: Some(sequence_id),
        });
        Ok(self)
    }

    /// Replaces the configured lifecycle hook set.
    ///
    /// Hook sets may carry sync adapters, async adapters, and provider-neutral
    /// async context propagators. Passing the hook set returned by
    /// `rurr_otel::OtelTrackingBridge::lifecycle_hooks`, for example, preserves
    /// OTEL context across awaited async actions without core depending on OTEL.
    pub fn with_hooks(
        mut self,
        adapter_set: LifecycleAdapterSet,
    ) -> Result<Self, ApplicationError> {
        self.hooks = adapter_set;
        Ok(self)
    }

    /// Installs a tracker specification for the application.
    ///
    /// Tracker specs are resolved during build and may register lifecycle hooks
    /// and application metadata. Enable the `s3` feature for S3 tracker specs;
    /// local tracking remains available through the default core tracking API.
    pub fn with_tracker(mut self, tracker_spec: TrackerSpec) -> Result<Self, ApplicationError> {
        self.tracker_spec = Some(tracker_spec);
        Ok(self)
    }

    /// Installs the parallel executor used by task-based parallel actions.
    pub fn with_parallel_executor(
        mut self,
        executor: Arc<dyn ParallelExecutor>,
    ) -> Result<Self, ApplicationError> {
        if self.parallel_executor.is_some() {
            return Err(ApplicationError::ParallelExecutorAlreadyConfigured);
        }
        self.parallel_executor = Some(executor);
        Ok(self)
    }

    /// Merges an application persistence specification into the builder.
    ///
    /// Persistence specs can configure a state loader/initializer, a persister,
    /// or both. Initializers intentionally conflict with explicit state and
    /// entrypoints because the loaded record decides the starting state and
    /// resume position.
    pub fn with_persistence_spec(
        mut self,
        spec: ApplicationPersistenceSpec,
    ) -> Result<Self, ApplicationError> {
        if spec.initializer().is_some()
            && (self.explicit_state.is_some() || self.entrypoint.is_some())
        {
            return Err(ApplicationError::PersistenceInitializerConflictsWithStateOrEntrypoint);
        }
        self.persistence_spec.merge(spec);
        Ok(self)
    }

    /// Configures a state initializer plus its resume/fork behavior.
    pub fn initialize_from<I>(
        self,
        initializer: I,
        spec: InitializeFromSpec,
    ) -> Result<Self, ApplicationError>
    where
        I: Into<StateLoaderRef>,
    {
        let initializer = spec.into_state_initializer_spec(initializer.into());

        self.with_persistence_spec(ApplicationPersistenceSpec::new().with_initializer(initializer))
    }

    /// Sets the typing system used to validate future state transitions.
    pub fn with_typing(
        mut self,
        typing_system: Arc<dyn TypingSystem>,
    ) -> Result<Self, ApplicationError> {
        self.typing_system = Some(typing_system);
        Ok(self)
    }

    /// Builds the application on the sync lane.
    pub fn build(self) -> Result<Application, ApplicationError> {
        build_from_builder_sync(self)
    }

    /// Builds the application on the async lane.
    pub async fn abuild(self) -> Result<Application, ApplicationError> {
        build_from_builder_async(self).await
    }

    fn has_initializer(&self) -> bool {
        self.persistence_spec.initializer().is_some()
    }
}

fn convert_actions<I, T>(actions: I) -> Result<Vec<GraphAction>, ApplicationError>
where
    I: IntoIterator<Item = T>,
    GraphAction: TryFrom<T>,
    ApplicationError: From<<GraphAction as TryFrom<T>>::Error>,
{
    actions
        .into_iter()
        .map(|action| GraphAction::try_from(action).map_err(ApplicationError::from))
        .collect()
}
