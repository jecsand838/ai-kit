//! Test helpers and fixtures for exercising the Rurr workspace.
//!
//! This crate collects reusable application fixtures, tracking fixtures,
//! temporary-directory helpers, and optional live-service probes used by
//! integration tests across the workspace.
//!
//! Reach for [`fixtures`] when you need lightweight value-level behavior, for
//! [`application_fixture`] when you need full applications and builders, and
//! for [`tracking_fixture`] or [`persistence_cases`] when a test needs
//! workspace-realistic storage artifacts.
//!
//! With the `live-services` feature enabled, [`live_services`] exposes the
//! Docker-backed readiness probes and raw OTEL collector-file readers used by
//! strict provider lanes. Those helpers intentionally read raw provider output
//! instead of reshaping it into test-friendly structures. Ordinary doctests and
//! unit tests should stay on the local fixture modules unless they are
//! explicitly part of a strict live/provider lane.
//!
//! The fixtures here prove Rurr behavior without inventing provider semantics.
//! When a helper reads live Redis, Postgres, MongoDB, OTEL collector, or OpenAI
//! output, it exposes the raw service result to the calling test.
//!
//! # Examples
//!
//! ```
//! use rurr_testkit::fixtures::{counter_app_sync_fixture, read_count};
//!
//! let fixture = counter_app_sync_fixture();
//! let next = fixture.action.run_logic(&fixture.initial_state);
//! assert_eq!(read_count(&next), 1);
//! ```

#![deny(missing_docs)]

/// Concrete metadata-backed action fixtures for workspace tests.
pub mod action_fixture;
/// Action metadata fixtures used by macro and facade tests.
pub mod action_metadata;
/// Builder helpers for assembling small test applications.
pub mod application_fixture;
/// CLI command runners and assertion helpers.
pub mod command_fixture;
/// Scoped environment-variable overrides for tests.
pub mod env;
/// Reusable sync and async counter-style fixtures.
pub mod fixtures;
#[cfg(feature = "live-services")]
/// Opt-in helpers for docker-backed Redis, Postgres, and MongoDB tests.
pub mod live_services;
/// Shared persistence behavior assertions for backend contract tests.
pub mod persistence_cases;
/// Shared Burr-parity streaming fixtures used by examples and integration tests.
pub mod streaming_parity;
/// Ephemeral tempdir helpers for isolated filesystem tests.
pub mod tempdir;
/// Tracking-artifact fixtures and helpers.
pub mod tracking_fixture;
/// Workspace directory helpers for tests that need isolated current directories.
pub mod workspace_fixture;

#[cfg(feature = "live-services")]
/// Returns early unless docker-backed live/provider tests are enabled for this process.
#[macro_export]
macro_rules! require_check_live_tests {
    () => {
        if !$crate::check_live_tests_enabled() {
            return;
        }
    };
    ($return_value:expr) => {
        if !$crate::check_live_tests_enabled() {
            return $return_value;
        }
    };
}

#[cfg(feature = "live-services")]
/// Returns early unless the private OpenAI live lane is enabled for this process.
#[macro_export]
macro_rules! require_openai_live_tests {
    () => {
        if !$crate::openai_live_tests_enabled() {
            return;
        }
    };
    ($return_value:expr) => {
        if !$crate::openai_live_tests_enabled() {
            return $return_value;
        }
    };
}

#[cfg(feature = "live-services")]
pub use live_services::{
    check_live_tests_enabled, cleanup_redis_namespace_async, cleanup_redis_namespace_sync,
    drop_mongodb_collection_sync, drop_postgres_table, drop_postgres_table_sync,
    live_service_error_to_persistence, mongodb_uri_from_env, openai_live_tests_enabled,
    postgres_url_from_env, ready_mongodb_uri_sync, ready_postgres_url, ready_postgres_url_sync,
    redis_url_from_env, unique_mongodb_collection_name, unique_postgres_table_name,
    unique_redis_namespace, wait_for_mongodb_ready_sync, wait_for_postgres_ready,
    wait_for_postgres_ready_sync, wait_for_redis_ready, wait_for_redis_ready_sync,
    LiveServiceError, S3LiveHarness, CHECK_LIVE_ENV, OPENAI_LIVE_ENV,
};
pub use persistence_cases::run_sync_on_thread;
pub use tempdir::{test_dir, test_dir_for_test, TestDir};
