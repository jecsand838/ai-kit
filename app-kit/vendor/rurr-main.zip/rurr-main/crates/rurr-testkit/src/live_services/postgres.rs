use super::common::{unique_name_suffix, LiveServiceError, ProbeSchedule, ServiceProbe};
use postgres::{config::Host as PgHost, Config as PgClientConfig, NoTls};
use sqlx::postgres::{PgConnectOptions, PgConnection};
use sqlx::Connection;
use std::io::{Read, Write};
use std::net::{TcpStream, ToSocketAddrs};
#[cfg(unix)]
use std::os::unix::net::UnixStream;
use std::path::PathBuf;
use std::str::FromStr;
use std::sync::atomic::AtomicU64;
use std::time::Duration;
use tokio::time::timeout;

const DEFAULT_DATABASE_URL: &str = "postgres://rurr:rurr@localhost:5432/rurr";
const POSTGRES_IDENTIFIER_MAX_LEN: usize = 63;
const CREATED_AT_INDEX_SUFFIX: &str = "_created_at_index";
const POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN: usize =
    POSTGRES_IDENTIFIER_MAX_LEN - CREATED_AT_INDEX_SUFFIX.len();

static POSTGRES_TABLE_COUNTER: AtomicU64 = AtomicU64::new(0);

/// Returns a validated Postgres URL from `DATABASE_URL` or the local default.
pub fn postgres_url_from_env() -> Result<String, LiveServiceError> {
    let database_url =
        std::env::var("DATABASE_URL").unwrap_or_else(|_| DEFAULT_DATABASE_URL.to_string());
    validate_postgres_url(&database_url)?;
    Ok(database_url)
}

/// Returns a validated Postgres URL after confirming the server is reachable.
pub async fn ready_postgres_url() -> Result<String, LiveServiceError> {
    let database_url = postgres_url_from_env()?;
    wait_for_postgres_ready(&database_url).await?;
    Ok(database_url)
}

/// Returns a validated Postgres URL after confirming the server is reachable synchronously.
pub fn ready_postgres_url_sync() -> Result<String, LiveServiceError> {
    let database_url = postgres_url_from_env()?;
    wait_for_postgres_ready_sync(&database_url)?;
    Ok(database_url)
}

/// Drops a Postgres table used by a live test if it exists.
pub async fn drop_postgres_table(
    database_url: &str,
    table_name: &str,
) -> Result<(), LiveServiceError> {
    let probe = ServiceProbe::new("postgres", database_url, ProbeSchedule::live_defaults());
    let connect_options = validate_postgres_url(database_url)?;
    let mut connection = PgConnection::connect_with(&connect_options)
        .await
        .map_err(|error| probe.unavailable(format!("table drop connection failed: {error}")))?;
    sqlx::query(&format!("DROP TABLE IF EXISTS {table_name}"))
        .execute(&mut connection)
        .await
        .map_err(|error| probe.unavailable(format!("table drop failed: {error}")))?;
    connection
        .close()
        .await
        .map_err(|error| probe.unavailable(format!("table drop close failed: {error}")))?;
    Ok(())
}

/// Drops a Postgres table used by a live test if it exists.
pub fn drop_postgres_table_sync(
    database_url: &str,
    table_name: &str,
) -> Result<(), LiveServiceError> {
    let probe = ServiceProbe::new("postgres", database_url, ProbeSchedule::live_defaults());
    let mut client = validate_postgres_url_sync(database_url)?
        .connect(NoTls)
        .map_err(|error| probe.unavailable(format!("table drop connection failed: {error}")))?;
    client
        .batch_execute(&format!("DROP TABLE IF EXISTS {table_name}"))
        .map_err(|error| probe.unavailable(format!("table drop failed: {error}")))?;
    Ok(())
}

/// Waits for a Postgres server to accept connections at `database_url`.
pub async fn wait_for_postgres_ready(database_url: &str) -> Result<(), LiveServiceError> {
    wait_for_postgres_ready_with_schedule(database_url, ProbeSchedule::live_defaults()).await
}

#[cfg(test)]
fn wait_for_postgres_ready_sync_with_timeouts(
    database_url: &str,
    attempt_timeout: Duration,
    total_timeout: Duration,
    retry_delay: Duration,
) -> Result<(), LiveServiceError> {
    wait_for_postgres_ready_sync_with_schedule(
        database_url,
        ProbeSchedule::new(attempt_timeout, total_timeout, retry_delay),
    )
}

fn wait_for_postgres_ready_sync_with_schedule(
    database_url: &str,
    schedule: ProbeSchedule,
) -> Result<(), LiveServiceError> {
    let connect_config = validate_postgres_url_sync(database_url)?;
    let probe = ServiceProbe::new("postgres", database_url, schedule);

    probe.retry_sync(|| {
        probe_postgres_startup_response(&connect_config, schedule.attempt_timeout)?;
        let mut connect_config = connect_config.clone();
        connect_config.connect_timeout(schedule.attempt_timeout);
        connect_config
            .connect(NoTls)
            .map(|_| ())
            .map_err(|error| format!("connection failed: {error}"))
    })
}

async fn wait_for_postgres_ready_with_schedule(
    database_url: &str,
    schedule: ProbeSchedule,
) -> Result<(), LiveServiceError> {
    let connect_options = validate_postgres_url(database_url)?;
    let probe = ServiceProbe::new("postgres", database_url, schedule);
    probe
        .retry_async(|| {
            let connect_options = connect_options.clone();
            async move { probe_postgres_with_sqlx(connect_options, schedule.attempt_timeout).await }
        })
        .await
}

/// Waits synchronously for a Postgres server to accept connections at `database_url`.
pub fn wait_for_postgres_ready_sync(database_url: &str) -> Result<(), LiveServiceError> {
    wait_for_postgres_ready_sync_with_schedule(database_url, ProbeSchedule::live_defaults())
}

/// Builds a unique Postgres table name that stays within identifier length limits.
pub fn unique_postgres_table_name(prefix: &str) -> String {
    let suffix = unique_name_suffix(&POSTGRES_TABLE_COUNTER);
    let available_prefix_len =
        POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN - "rurr_pg__".len() - suffix.len();
    let prefix = if prefix.len() > available_prefix_len {
        &prefix[..available_prefix_len]
    } else {
        prefix
    };

    format!("rurr_pg_{prefix}_{suffix}")
}

fn validate_postgres_url(database_url: &str) -> Result<PgConnectOptions, LiveServiceError> {
    let probe = ServiceProbe::new("postgres", database_url, ProbeSchedule::live_defaults());
    PgConnectOptions::from_str(database_url).map_err(|error| probe.invalid(error.to_string()))
}

fn validate_postgres_url_sync(database_url: &str) -> Result<PgClientConfig, LiveServiceError> {
    validate_postgres_url(database_url)?;
    let probe = ServiceProbe::new("postgres", database_url, ProbeSchedule::live_defaults());
    PgClientConfig::from_str(database_url).map_err(|error| probe.invalid(error.to_string()))
}

async fn probe_postgres_with_sqlx(
    connect_options: PgConnectOptions,
    attempt_timeout: Duration,
) -> Result<(), String> {
    match timeout(
        attempt_timeout,
        PgConnection::connect_with(&connect_options),
    )
    .await
    {
        Ok(Ok(connection)) => connection
            .close()
            .await
            .map_err(|error| format!("close failed: {error}")),
        Ok(Err(error)) => Err(error.to_string()),
        Err(_) => Err("connection timed out".to_string()),
    }
}

fn probe_postgres_startup_response(
    connect_config: &PgClientConfig,
    attempt_timeout: Duration,
) -> Result<(), String> {
    let startup_packet = postgres_startup_packet(connect_config)?;
    let ports = connect_config.get_ports();

    for (index, host) in connect_config.get_hosts().iter().enumerate() {
        let port = ports
            .get(index)
            .copied()
            .or_else(|| ports.first().copied())
            .unwrap_or(5432);

        match host {
            PgHost::Tcp(hostname) => {
                let addresses = (hostname.as_str(), port)
                    .to_socket_addrs()
                    .map_err(|error| format!("resolve failed: {error}"))?;
                for address in addresses {
                    if probe_postgres_stream(
                        TcpStream::connect_timeout(&address, attempt_timeout)
                            .map_err(|error| format!("connection failed: {error}"))?,
                        attempt_timeout,
                        &startup_packet,
                    )
                    .is_ok()
                    {
                        return Ok(());
                    }
                }
            }
            #[cfg(unix)]
            PgHost::Unix(path) => {
                let socket_path = PathBuf::from(path).join(format!(".s.PGSQL.{port}"));
                if probe_postgres_stream(
                    UnixStream::connect(&socket_path)
                        .map_err(|error| format!("connection failed: {error}"))?,
                    attempt_timeout,
                    &startup_packet,
                )
                .is_ok()
                {
                    return Ok(());
                }
            }
        }
    }

    Err("connection timed out".to_string())
}

fn postgres_startup_packet(connect_config: &PgClientConfig) -> Result<Vec<u8>, String> {
    let user = connect_config
        .get_user()
        .ok_or_else(|| "missing user".to_string())?;
    let database = connect_config.get_dbname().unwrap_or(user);

    let mut payload = Vec::new();
    payload.extend_from_slice(b"user\0");
    payload.extend_from_slice(user.as_bytes());
    payload.push(0);
    payload.extend_from_slice(b"database\0");
    payload.extend_from_slice(database.as_bytes());
    payload.push(0);
    payload.push(0);

    let length = (payload.len() + 8) as u32;
    let mut packet = Vec::with_capacity(length as usize);
    packet.extend_from_slice(&length.to_be_bytes());
    packet.extend_from_slice(&196_608_u32.to_be_bytes());
    packet.extend_from_slice(&payload);
    Ok(packet)
}

fn probe_postgres_stream<T>(
    mut stream: T,
    attempt_timeout: Duration,
    startup_packet: &[u8],
) -> Result<(), String>
where
    T: Read + Write + StreamTimeouts,
{
    let timeout = Some(attempt_timeout);
    set_stream_timeouts(&stream, timeout)?;
    stream
        .write_all(startup_packet)
        .map_err(|error| format!("write failed: {error}"))?;
    stream
        .flush()
        .map_err(|error| format!("flush failed: {error}"))?;

    let mut header = [0_u8; 5];
    stream
        .read_exact(&mut header)
        .map_err(|error| format!("read failed: {error}"))?;

    let body_len = u32::from_be_bytes([header[1], header[2], header[3], header[4]])
        .checked_sub(4)
        .ok_or_else(|| "invalid postgres message length".to_string())? as usize;
    let mut body = vec![0_u8; body_len];
    stream
        .read_exact(&mut body)
        .map_err(|error| format!("read failed: {error}"))?;
    Ok(())
}

fn set_stream_timeouts(
    stream: &impl StreamTimeouts,
    timeout: Option<Duration>,
) -> Result<(), String> {
    stream
        .set_read_timeout(timeout)
        .map_err(|error| format!("read timeout setup failed: {error}"))?;
    stream
        .set_write_timeout(timeout)
        .map_err(|error| format!("write timeout setup failed: {error}"))?;
    Ok(())
}

trait StreamTimeouts {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> std::io::Result<()>;
    fn set_write_timeout(&self, timeout: Option<Duration>) -> std::io::Result<()>;
}

impl StreamTimeouts for TcpStream {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> std::io::Result<()> {
        TcpStream::set_read_timeout(self, timeout)
    }

    fn set_write_timeout(&self, timeout: Option<Duration>) -> std::io::Result<()> {
        TcpStream::set_write_timeout(self, timeout)
    }
}

#[cfg(unix)]
impl StreamTimeouts for UnixStream {
    fn set_read_timeout(&self, timeout: Option<Duration>) -> std::io::Result<()> {
        UnixStream::set_read_timeout(self, timeout)
    }

    fn set_write_timeout(&self, timeout: Option<Duration>) -> std::io::Result<()> {
        UnixStream::set_write_timeout(self, timeout)
    }
}

#[cfg(test)]
mod tests {
    use super::{wait_for_postgres_ready_sync_with_timeouts, LiveServiceError};
    use crate::live_services::common::tests::StallServer;
    use std::time::{Duration, Instant};

    #[test]
    fn wait_for_postgres_ready_sync_times_out_against_stalled_server() {
        let server = StallServer::start();
        let postgres_url = format!("postgres://user:password@{}/database", server.address());
        let attempt_timeout = Duration::from_millis(40);
        let total_timeout = Duration::from_millis(120);
        let retry_delay = Duration::from_millis(10);
        let start = Instant::now();

        let error = wait_for_postgres_ready_sync_with_timeouts(
            &postgres_url,
            attempt_timeout,
            total_timeout,
            retry_delay,
        )
        .expect_err("stalled postgres endpoint should time out");

        assert!(matches!(
            &error,
            LiveServiceError::Unavailable {
                service,
                endpoint,
                message,
            } if *service == "postgres"
                && endpoint == &postgres_url
                && message.contains("probe failed after")
        ));
        assert!(
            start.elapsed() < Duration::from_millis(750),
            "sync postgres probe should honor injected timeout bounds"
        );
    }
}
