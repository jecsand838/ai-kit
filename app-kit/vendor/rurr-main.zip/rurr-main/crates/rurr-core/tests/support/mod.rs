pub(crate) mod local_client;
pub(crate) mod local_client_actions;
pub(crate) mod tracking_actions;

const _: () = {
    let _ = local_client::tracker;
    let _ = local_client::app_dir;
    let _ = local_client::ensure_app_dir;
    let _ = local_client::app_log_path;
    let _ = local_client::read_app_log;
    let _ = local_client::read_app_log_if_exists;
    let _ = local_client::write_app_log_entries;
    let _ = local_client::counter_end_entry;
    let _ = local_client::counter_end_entry_with_exception;
    let _ = local_client::log_type_sequence;
    let _ = local_client::stream_items_streamed;
    let _ = local_client::count_log_entries;
    let _ = local_client::count_app_log_entries;
    let _ = local_client::span_events;
    let _ = local_client::assert_log_types;
    let _ = local_client::assert_log_event_counts;
    let _ = local_client::register_application;
    let _ = local_client::assert_invalid_input_tracking_io;

    let _ = local_client_actions::broken_action;
    let _ = std::mem::size_of::<local_client_actions::StreamingScript>();
    let _ = std::mem::size_of::<local_client_actions::StreamingLane>();
    let _ = local_client_actions::streaming_action;

    let _ = tracking_actions::build_single_step_sync_action;
    let _ = tracking_actions::build_delta_sync_action;
    let _ = tracking_actions::build_traced_sync_action;
    let _ = tracking_actions::build_traced_async_action;
    let _ = tracking_actions::build_cross_factory_routed_sync_action;
};
