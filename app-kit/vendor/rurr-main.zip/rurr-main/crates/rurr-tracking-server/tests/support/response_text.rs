use crate::support::response_body::response_body_bytes;

pub(crate) async fn response_text(response: axum::response::Response) -> String {
    let bytes = response_body_bytes(response).await;
    String::from_utf8(bytes).expect("response body should be utf-8")
}
