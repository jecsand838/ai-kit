use super::models::{
    ApplicationMetadataModel, ApplicationModel, ChildApplicationModel, PointerModel,
};
use crate::action::api::is_reserved_runtime_input;
use crate::application::context::ParentPointer;
use crate::application::Tracker;
use crate::graph::GraphRegistrationView;
use crate::lifecycle::{AsyncLifecycleAdapter, LifecycleError, SyncLifecycleAdapter};
use crate::tracking::lifecycle_events::TrackingLifecycleLog;
use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_persistence::{
    BaseStateLoader, PersistedStateData, PersistedStateStatus, PersistenceError,
};
use rurr_tracking_store as store_util;
use serde_json::Value;
use std::path::{Path, PathBuf};
use std::sync::{Mutex, MutexGuard};
use thiserror::Error;

mod fs;
mod lifecycle_hooks;
mod persistence_loader;
mod registration;
mod validation;

/// Returns whether a project name is valid for local tracking storage.
pub use validation::allowed_project_name;

const STORAGE_ROOT_SCOPE: &str = store_util::tracking_repository::artifacts::STORAGE_ROOT_SCOPE;
const PROJECT_ID_KIND: &str = store_util::tracking_repository::artifacts::PROJECT_ID_KIND;
const APP_ID_KIND: &str = store_util::tracking_repository::artifacts::APP_ID_KIND;

#[derive(Debug, Error)]
/// Errors raised by the local tracking client.
pub enum TrackingError {
    /// The project name could not be represented in local tracking storage.
    #[error("project name is not valid: {project}")]
    InvalidProjectName {
        /// Invalid project name.
        project: String,
    },
    /// The application id could not be represented in local tracking storage.
    #[error("app id is not valid: {app_id}")]
    InvalidAppId {
        /// Invalid application id.
        app_id: String,
    },
    /// An unsupported tracker parameter was supplied.
    #[error("unsupported local tracker parameter: {param}")]
    UnsupportedLocalTrackerParam {
        /// Unsupported tracker parameter name.
        param: String,
    },
    /// A tracker parameter existed but had the wrong JSON type.
    #[error("invalid local tracker parameter type for {param}: expected {expected}, got {actual}")]
    InvalidLocalTrackerParamType {
        /// Parameter name.
        param: &'static str,
        /// Expected JSON type.
        expected: &'static str,
        /// Actual JSON type.
        actual: &'static str,
    },
    /// Required S3 tracker configuration was absent.
    #[error("missing s3 tracker configuration: {field}")]
    MissingS3TrackerConfig {
        /// Missing field.
        field: &'static str,
    },
    /// Tracking was requested for an unnamed action.
    #[error("action must be named before tracking")]
    UnnamedAction,
    /// Tracking was requested for an action whose source could not be proven.
    #[error("action source is unavailable for tracking: {action}")]
    MissingActionSource {
        /// Named action that could not provide source text.
        action: String,
    },
    /// An operation required an application id that was not available.
    #[error("missing app id for operation: {operation}")]
    MissingAppId {
        /// Operation that required an application id.
        operation: &'static str,
    },
    /// An internal client lock was poisoned.
    #[error("tracking lock poisoned: {lock}")]
    LockPoisoned {
        /// Name of the poisoned lock.
        lock: &'static str,
    },
    /// S3 transport failed.
    #[error("s3 tracking operation failed during {operation}: {message}")]
    S3Transport {
        /// Operation that failed.
        operation: &'static str,
        /// Transport or service message.
        message: String,
    },
    /// S3 tracking object layout or addressing validation failed.
    #[error("s3 tracking layout error: {message}")]
    S3Layout {
        /// Layout validation message.
        message: String,
    },
    /// A tracking timestamp could not be represented.
    #[error("tracking timestamp failed during {operation}: {message}")]
    Timestamp {
        /// Operation that needed a timestamp.
        operation: &'static str,
        /// Timestamp conversion details.
        message: String,
    },
    /// File-system I/O failed.
    #[error(transparent)]
    Io(#[from] std::io::Error),
    /// JSON serialization or deserialization failed.
    #[error(transparent)]
    SerdeJson(#[from] serde_json::Error),
}

/// File-backed tracking client that writes Burr-compatible tracking artifacts locally.
///
/// Registering an application creates the required local artifact set:
/// `graph.json`, `metadata.json`, and `log.jsonl`. Child relationship logs are
/// optional. The client also implements [`BaseStateLoader`] so applications can
/// resume from local tracking data; an existing app directory with a missing or
/// malformed required log is reported as
/// [`PersistenceError::InvalidPersistedState`] rather than as a missing record.
pub struct LocalTrackingClient {
    project_id: String,
    raw_storage_dir: PathBuf,
    project_anchor: store_util::anchored_fs::AnchoredDir,
    serde_kwargs: IndexMap<String, Value>,
    lifecycle_log: TrackingLifecycleLog,
    write_lock: Mutex<()>,
}

impl LocalTrackingClient {
    /// Graph artifact filename written for each tracked application.
    pub const GRAPH_FILENAME: &str = store_util::tracking_repository::artifacts::GRAPH_FILENAME;
    /// Metadata artifact filename written for each tracked application.
    pub const METADATA_FILENAME: &str =
        store_util::tracking_repository::artifacts::METADATA_FILENAME;
    /// JSONL log filename written for each tracked application.
    pub const LOG_FILENAME: &str = store_util::tracking_repository::artifacts::LOG_FILENAME;
    /// Child-application artifact filename written for each tracked application.
    pub const CHILDREN_FILENAME: &str =
        store_util::tracking_repository::artifacts::CHILDREN_FILENAME;
    /// Default storage root used when no explicit directory is configured.
    pub const DEFAULT_STORAGE_DIR: &str = "~/.burr";

    fn lock_write(&self) -> Result<MutexGuard<'_, ()>, TrackingError> {
        self.write_lock
            .lock()
            .map_err(|_| TrackingError::LockPoisoned { lock: "write_lock" })
    }

    fn with_write_lock<R>(
        &self,
        write: impl FnOnce() -> std::io::Result<R>,
    ) -> Result<R, TrackingError> {
        let _lock = self.lock_write()?;
        write().map_err(TrackingError::from)
    }

    pub(super) fn lifecycle_log(&self) -> &TrackingLifecycleLog {
        &self.lifecycle_log
    }
}
