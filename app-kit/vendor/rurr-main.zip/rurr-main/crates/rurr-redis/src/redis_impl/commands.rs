use crate::{
    RedisPersisterConfig, SaveInvocation, OP_REDIS_CLIENT_OPEN_FAILED, OP_REDIS_COMMAND_FAILED,
    SAVE_IF_NOT_EXISTS_SCRIPT,
};
use redis::aio::ConnectionManager;
use redis::{Client, Connection};
use rurr_persistence::PersistenceError;

pub(crate) fn open_client(
    redis_url: impl Into<String>,
    namespace: impl Into<String>,
) -> Result<(Client, RedisPersisterConfig), PersistenceError> {
    let redis_url = redis_url.into();
    let namespace = namespace.into();
    let client =
        Client::open(redis_url.as_str()).map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_CLIENT_OPEN_FAILED,
        })?;
    let config = RedisPersisterConfig {
        redis_url,
        namespace,
    };
    Ok((client, config))
}

pub(crate) async fn invoke_save_if_not_exists_async(
    connection: &mut ConnectionManager,
    save_invocation: &SaveInvocation<'_>,
) -> Result<i32, PersistenceError> {
    SAVE_IF_NOT_EXISTS_SCRIPT
        .key(save_invocation.record_key)
        .key(save_invocation.partition_index_key)
        .key(save_invocation.app_index_key)
        .key(save_invocation.partition_app_ids_key)
        .arg(save_invocation.partition_key)
        .arg(save_invocation.app_id)
        .arg(save_invocation.sequence_id.to_string())
        .arg(save_invocation.position)
        .arg(save_invocation.state_json)
        .arg(save_invocation.status)
        .arg(save_invocation.created_at)
        .arg(save_invocation.partition_index_member)
        .arg(save_invocation.app_index_member)
        .invoke_async(connection)
        .await
        .map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_REDIS_COMMAND_FAILED,
        })
}

pub(crate) fn invoke_save_if_not_exists_sync(
    connection: &mut Connection,
    save_invocation: &SaveInvocation<'_>,
) -> redis::RedisResult<i32> {
    SAVE_IF_NOT_EXISTS_SCRIPT
        .key(save_invocation.record_key)
        .key(save_invocation.partition_index_key)
        .key(save_invocation.app_index_key)
        .key(save_invocation.partition_app_ids_key)
        .arg(save_invocation.partition_key)
        .arg(save_invocation.app_id)
        .arg(save_invocation.sequence_id.to_string())
        .arg(save_invocation.position)
        .arg(save_invocation.state_json)
        .arg(save_invocation.status)
        .arg(save_invocation.created_at)
        .arg(save_invocation.partition_index_member)
        .arg(save_invocation.app_index_member)
        .invoke(connection)
}
