use rurr_tracking_store::tracking_repository::LocalTestCaseFixture;
use std::error::Error;
use std::fs;
use std::io;
use std::path::Path;

pub(super) fn emit_fixture(
    target_file_name: Option<&Path>,
    fixture: &LocalTestCaseFixture,
) -> Result<(), Box<dyn Error>> {
    if let Some(target_file_name) = target_file_name {
        append_fixture_file(target_file_name, fixture)?;
        println!("\nWriting data to file {}", target_file_name.display());
    } else {
        println!("{}", serialize_fixture(fixture)?);
    }
    Ok(())
}

fn append_fixture_file(path: &Path, fixture: &LocalTestCaseFixture) -> Result<(), Box<dyn Error>> {
    let mut fixtures = load_existing_fixtures(path)?;
    fixtures.push(fixture.clone());
    fs::write(path, serde_json::to_string_pretty(&fixtures)?)?;
    Ok(())
}

fn serialize_fixture(fixture: &LocalTestCaseFixture) -> io::Result<String> {
    serde_json::to_string_pretty(fixture)
        .map_err(|error| io::Error::other(format!("serialize fixture json: {error}")))
}

fn load_existing_fixtures(path: &Path) -> io::Result<Vec<LocalTestCaseFixture>> {
    if !path.exists() {
        return Ok(Vec::new());
    }

    let contents = fs::read_to_string(path)?;
    if contents.trim().is_empty() {
        return Ok(Vec::new());
    }

    let value: serde_json::Value = serde_json::from_str(&contents).map_err(|error| {
        io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "fixture file {} must contain a JSON array of test-case fixtures: {error}",
                path.display()
            ),
        )
    })?;

    if !value.is_array() {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "fixture file {} must contain a JSON array of test-case fixtures",
                path.display()
            ),
        ));
    }

    serde_json::from_value(value).map_err(|error| {
        io::Error::new(
            io::ErrorKind::InvalidData,
            format!(
                "fixture file {} must contain valid test-case fixtures: {error}",
                path.display()
            ),
        )
    })
}
