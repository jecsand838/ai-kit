mod support;

use rurr_telemetry::capture_cli_command;
use rurr_testkit::env::EnvVarGuard;
use rurr_testkit::live_services::reset_otel_file_exports;
use tempfile::tempdir;

#[tokio::test(flavor = "multi_thread")]
async fn invalid_enablement_config_emits_no_telemetry() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let home = tempdir().expect("tempdir should create");
    let config_path = home.path().join(".rurr.conf");
    let invalid_config = "[DEFAULT]\ntelemetry_enabled = definitely\n";
    std::fs::write(&config_path, invalid_config).expect("config file should write");

    let docker_config = support::inherited_docker_config();
    {
        let _env = EnvVarGuard::set([
            (
                "HOME",
                Some(home.path().to_str().expect("home path should be utf-8")),
            ),
            ("USERPROFILE", None),
            ("HOMEDRIVE", None),
            ("HOMEPATH", None),
            ("DOCKER_CONFIG", docker_config.as_deref()),
            ("BURR_TELEMETRY_ENABLED", Some("absolutely-not")),
            ("OTEL_EXPORTER_OTLP_ENDPOINT", Some("http://127.0.0.1:4318")),
            ("OTEL_EXPORTER_OTLP_PROTOCOL", Some("http/protobuf")),
        ]);
        capture_cli_command("serve");
        support::assert_no_cli_telemetry_exports("invalid telemetry enablement").await;
        assert_eq!(
            std::fs::read_to_string(&config_path).expect("config file should be readable"),
            invalid_config,
            "invalid telemetry config must not be rewritten into a passing shape"
        );
    }
}
