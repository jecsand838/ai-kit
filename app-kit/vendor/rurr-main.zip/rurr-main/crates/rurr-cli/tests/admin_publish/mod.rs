use serde::Deserialize;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

use rurr_testkit::command_fixture::{assert_failure, assert_success, rurr_command, stderr_lossy};

pub(crate) use super::workspace_snapshot::workspace_root;

pub(crate) const MANAGED_DIR_MARKER_FILENAME: &str = ".rurr-managed-dir.json";

#[derive(Debug, Deserialize)]
pub(crate) struct CargoMetadataSummary {
    pub(crate) packages: Vec<CargoMetadataSummaryPackage>,
    pub(crate) workspace_members: Vec<String>,
}

#[derive(Debug, Deserialize)]
pub(crate) struct CargoMetadataSummaryPackage {
    pub(crate) id: String,
    pub(crate) name: String,
    pub(crate) publish: Option<Vec<String>>,
    pub(crate) dependencies: Vec<CargoMetadataSummaryDependency>,
}

#[derive(Debug, Deserialize)]
pub(crate) struct CargoMetadataSummaryDependency {
    pub(crate) name: String,
    pub(crate) kind: Option<String>,
}

pub(crate) fn canonical_cli_target(path: &Path) -> PathBuf {
    if path.exists() {
        return fs::canonicalize(path).expect("existing cli target should canonicalize");
    }

    let parent = path
        .parent()
        .expect("target should have a parent directory");
    let name = path.file_name().expect("target should have a file name");
    fs::canonicalize(parent)
        .expect("cli target parent should canonicalize")
        .join(name)
}

pub(crate) fn admin_publish_command(current_dir: &Path, dist_dir: &Path) -> Command {
    let mut command = rurr_command();
    command
        .current_dir(current_dir)
        .arg("admin")
        .arg("publish")
        .arg("--dist-dir")
        .arg(dist_dir);
    command
}

#[cfg(unix)]
pub(crate) fn install_dist_dir_symlink(target: &Path, link: &Path) -> io::Result<()> {
    std::os::unix::fs::symlink(target, link)
}

#[cfg(windows)]
pub(crate) fn install_dist_dir_symlink(target: &Path, link: &Path) -> io::Result<()> {
    std::os::windows::fs::symlink_dir(target, link)
}

#[cfg(unix)]
pub(crate) fn remove_dist_dir_symlink(link: &Path) -> io::Result<()> {
    fs::remove_file(link)
}

#[cfg(windows)]
pub(crate) fn remove_dist_dir_symlink(link: &Path) -> io::Result<()> {
    fs::remove_dir(link)
}

pub(crate) fn workspace_metadata_summary() -> CargoMetadataSummary {
    let output = Command::new("cargo")
        .current_dir(workspace_root())
        .arg("metadata")
        .arg("--format-version")
        .arg("1")
        .arg("--no-deps")
        .output()
        .expect("cargo metadata should run");
    assert_success(&output, "cargo metadata should succeed");
    serde_json::from_slice(&output.stdout).expect("cargo metadata should parse")
}

pub(crate) fn assert_unsafe_dist_dir_rejected(output: &Output, context: &str) {
    assert_failure(output, context);
    let stderr = stderr_lossy(output);
    assert!(
        stderr.contains("refusing to clear unsafe dist_dir"),
        "expected unsafe target error, got: {stderr}"
    );
}
