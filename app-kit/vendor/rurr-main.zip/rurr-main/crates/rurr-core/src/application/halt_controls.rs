use crate::application::ApplicationError;
use crate::graph::Graph;
use indexmap::IndexSet;

const TAG_SELECTOR_PREFIX: &str = "@tag:";

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub(crate) struct HaltControls {
    halt_before: IndexSet<String>,
    halt_after: IndexSet<String>,
}

impl HaltControls {
    pub(crate) fn resolve(
        graph: &Graph,
        halt_before_selectors: Vec<String>,
        halt_after_selectors: Vec<String>,
    ) -> Result<Self, ApplicationError> {
        let halt_before = expand_selectors(graph, halt_before_selectors)?;
        let halt_after = expand_selectors(graph, halt_after_selectors)?;
        validate_actions(graph, &halt_before, &halt_after)?;
        Ok(Self {
            halt_before,
            halt_after,
        })
    }

    pub(crate) fn halts_before(&self, action_name: &str) -> bool {
        self.halt_before.contains(action_name)
    }

    pub(crate) fn halts_after(&self, action_name: &str) -> bool {
        self.halt_after.contains(action_name)
    }

    pub(crate) fn targets_result_action(&self, action_name: &str) -> bool {
        if self.halt_after.is_empty() {
            self.halt_before.is_empty()
        } else {
            self.halts_after(action_name)
        }
    }

    #[cfg(test)]
    fn halt_before_actions(&self) -> impl Iterator<Item = &str> {
        self.halt_before.iter().map(String::as_str)
    }

    #[cfg(test)]
    fn halt_after_actions(&self) -> impl Iterator<Item = &str> {
        self.halt_after.iter().map(String::as_str)
    }
}

fn expand_selectors(
    graph: &Graph,
    selectors: Vec<String>,
) -> Result<IndexSet<String>, ApplicationError> {
    let mut expanded = IndexSet::new();
    for selector in selectors {
        if let Some(tag) = selector.strip_prefix(TAG_SELECTOR_PREFIX) {
            for action in graph.get_actions_by_tag(tag)? {
                expanded.insert(action.name().to_string());
            }
        } else {
            expanded.insert(selector);
        }
    }
    Ok(expanded)
}

fn validate_actions(
    graph: &Graph,
    halt_before: &IndexSet<String>,
    halt_after: &IndexSet<String>,
) -> Result<(), ApplicationError> {
    let mut missing_actions = IndexSet::new();
    for action_name in halt_before.iter().chain(halt_after) {
        if !graph.contains_action(action_name) {
            missing_actions.insert(action_name.clone());
        }
    }
    if missing_actions.is_empty() {
        return Ok(());
    }

    Err(ApplicationError::InvalidHaltActions {
        missing_actions: missing_actions.into_iter().collect(),
        available_actions: graph.action_names_in_order().map(str::to_string).collect(),
    })
}

#[cfg(test)]
mod tests {
    use super::HaltControls;
    use crate::action::{Condition, FunctionActionBuilder};
    use crate::application::{ApplicationBuilder, ApplicationError};
    use crate::graph::{GraphError, Transition};
    use crate::state::State;
    use indexmap::IndexMap;
    use serde_json::{json, Value};

    fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
        pairs
            .into_iter()
            .map(|(key, value)| (key.to_string(), value))
            .collect()
    }

    fn state_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> State {
        State::new(map_from_pairs(pairs))
    }

    fn counter_action(tags: &[&str]) -> crate::action::FunctionAction {
        FunctionActionBuilder::new()
            .writes(["count"])
            .tags(tags.iter().copied())
            .build_sync(|state, _ctx| {
                let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
                map_from_pairs([("count", json!(count))])
            })
            .expect("action should build")
    }

    fn app() -> crate::application::Application {
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(0))]))
            .expect("state should configure")
            .with_actions(vec![
                ("prepare", counter_action(&["setup"])),
                ("answer", counter_action(&["terminal"])),
                ("fallback", counter_action(&["terminal"])),
            ])
            .expect("actions should configure")
            .with_transitions(vec![
                Transition::new("prepare", "answer", Condition::default()),
                Transition::new("answer", "fallback", Condition::default()),
            ])
            .expect("transitions should configure")
            .with_entrypoint("prepare")
            .expect("entrypoint should configure")
            .build()
            .expect("app should build")
    }

    #[test]
    fn expands_tags_in_graph_order_and_preserves_explicit_order() {
        let app = app();
        let controls = HaltControls::resolve(
            app.graph_definition(),
            vec!["prepare".to_string(), "@tag:terminal".to_string()],
            vec!["@tag:setup".to_string(), "fallback".to_string()],
        )
        .expect("controls should resolve");

        assert_eq!(
            controls.halt_before_actions().collect::<Vec<_>>(),
            ["prepare", "answer", "fallback"]
        );
        assert_eq!(
            controls.halt_after_actions().collect::<Vec<_>>(),
            ["prepare", "fallback"]
        );
    }

    #[test]
    fn dedupes_each_control_list_by_first_occurrence() {
        let app = app();
        let controls = HaltControls::resolve(
            app.graph_definition(),
            vec![
                "@tag:terminal".to_string(),
                "answer".to_string(),
                "fallback".to_string(),
            ],
            vec!["fallback".to_string(), "@tag:terminal".to_string()],
        )
        .expect("controls should resolve");

        assert_eq!(
            controls.halt_before_actions().collect::<Vec<_>>(),
            ["answer", "fallback"]
        );
        assert_eq!(
            controls.halt_after_actions().collect::<Vec<_>>(),
            ["fallback", "answer"]
        );
    }

    #[test]
    fn unknown_tag_surfaces_graph_tag_error() {
        let app = app();
        let error = HaltControls::resolve(
            app.graph_definition(),
            vec!["@tag:missing".to_string()],
            Vec::new(),
        )
        .expect_err("missing tag should fail");

        assert!(matches!(
            error,
            ApplicationError::Graph(GraphError::TagNotFound { tag, .. }) if tag == "missing"
        ));
    }

    #[test]
    fn unknown_explicit_actions_are_combined_in_stable_order() {
        let app = app();
        let error = HaltControls::resolve(
            app.graph_definition(),
            vec!["missing_before".to_string(), "missing_shared".to_string()],
            vec!["missing_after".to_string(), "missing_shared".to_string()],
        )
        .expect_err("missing actions should fail");

        assert!(matches!(
            error,
            ApplicationError::InvalidHaltActions {
                missing_actions,
                available_actions,
            } if missing_actions == vec![
                "missing_before".to_string(),
                "missing_shared".to_string(),
                "missing_after".to_string(),
            ] && available_actions == vec![
                "prepare".to_string(),
                "answer".to_string(),
                "fallback".to_string(),
            ]
        ));
    }
}
