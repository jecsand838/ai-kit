use rurr_expr::{
    compare_json_values, evaluate_bool, parse, referenced_names, ComparisonOperator, ExprError,
    StateView,
};
use serde_json::{json, Value};
use std::collections::HashMap;

struct MapState {
    values: HashMap<String, Value>,
}

impl MapState {
    fn from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> Self {
        Self {
            values: pairs
                .into_iter()
                .map(|(key, value)| (key.to_string(), value))
                .collect(),
        }
    }
}

impl StateView for MapState {
    fn get_value(&self, key: &str) -> Option<&Value> {
        self.values.get(key)
    }
}

#[test]
fn parse_rejects_unsafe_nodes() {
    let unsafe_cases = [
        "lambda x: x",
        "[x for x in items]",
        "{x for x in items}",
        "{k: v for (k, v) in items}",
    ];

    for expression in unsafe_cases {
        let error = parse(expression).expect_err("unsafe expression should be rejected");
        match error {
            ExprError::UnsupportedNode { .. } => {}
            other => panic!("expected UnsupportedNode for {expression:?}, got {other:?}"),
        }
    }
}

#[test]
fn parse_allows_attribute_access() {
    let ast = parse("foo.bar == 1").expect("attribute expressions should parse");
    assert_eq!(referenced_names(&ast), vec!["foo".to_string()]);
}

#[test]
fn referenced_names_treat_len_identifier_and_builtin_distinctly() {
    let plain_len = parse("len == 3").expect("parse should succeed");
    assert_eq!(referenced_names(&plain_len), vec!["len".to_string()]);

    let len_call = parse("len(items) == 3").expect("parse should succeed");
    assert_eq!(referenced_names(&len_call), vec!["items".to_string()]);
}

#[test]
fn referenced_names_preserve_first_seen_order_across_nested_nodes() {
    let ast =
        parse("outer.inner[item] and len(items) and item and outer").expect("parse should succeed");
    assert_eq!(
        referenced_names(&ast),
        vec!["outer".to_string(), "item".to_string(), "items".to_string()]
    );
}

#[test]
fn evaluate_handles_comparisons_modulo_bool_ops_membership_and_subscripts() {
    let cases = [
        (
            "n == 1 and count < 10 and n % 2 == 1",
            MapState::from_pairs([("n", json!(1)), ("count", json!(9))]),
            true,
        ),
        (
            "\"exit\" in question",
            MapState::from_pairs([("question", json!("type exit to quit"))]),
            true,
        ),
        (
            "len(list_key) == 3",
            MapState::from_pairs([("list_key", json!([1, 2, 3]))]),
            true,
        ),
        (
            "dict_key[\"foo\"] == 0",
            MapState::from_pairs([("dict_key", json!({"foo": 0}))]),
            true,
        ),
        (
            "list_key[0] == 1",
            MapState::from_pairs([("list_key", json!([1, 2, 3]))]),
            true,
        ),
        (
            "a and b or not c",
            MapState::from_pairs([("a", json!(true)), ("b", json!(false)), ("c", json!(false))]),
            true,
        ),
    ];

    for (expression, state, expected) in cases {
        let ast = parse(expression).expect("parse should succeed");
        let actual = evaluate_bool(&ast, &state).expect("evaluation should succeed");
        assert_eq!(actual, expected, "unexpected result for {expression}");
    }
}

#[test]
fn comparison_helper_matches_condition_operator_semantics() {
    assert_eq!(
        compare_json_values(&json!("bar"), ComparisonOperator::Eq, &json!("bar")),
        Ok(true)
    );
    assert_eq!(
        compare_json_values(&json!(19), ComparisonOperator::Gt, &json!(18)),
        Ok(true)
    );
    assert_eq!(
        compare_json_values(
            &json!("active"),
            ComparisonOperator::In,
            &json!(["active", "pending"])
        ),
        Ok(true)
    );
    assert_eq!(
        compare_json_values(
            &json!(["python", "java"]),
            ComparisonOperator::Contains,
            &json!("python")
        ),
        Ok(true)
    );
    assert_eq!(
        compare_json_values(
            &json!("say hello world"),
            ComparisonOperator::Contains,
            &json!("hello")
        ),
        Ok(true)
    );
    assert_eq!(
        compare_json_values(&Value::Null, ComparisonOperator::Is, &Value::Null),
        Ok(true)
    );
    assert_eq!(
        compare_json_values(&json!(true), ComparisonOperator::Is, &json!(1)),
        Ok(false)
    );
}

#[test]
fn comparison_operator_metadata_stays_on_closed_enum() {
    let operators = [
        ComparisonOperator::Eq,
        ComparisonOperator::NotEq,
        ComparisonOperator::Lt,
        ComparisonOperator::LtE,
        ComparisonOperator::Gt,
        ComparisonOperator::GtE,
        ComparisonOperator::In,
        ComparisonOperator::NotIn,
        ComparisonOperator::Contains,
        ComparisonOperator::Is,
        ComparisonOperator::IsNot,
    ];
    assert_eq!(
        operators.map(ComparisonOperator::symbol),
        ["==", "!=", "<", "<=", ">", ">=", "in", "not in", "contains", "is", "is not"]
    );
    assert_eq!(
        operators.map(ComparisonOperator::is_word_operator),
        [false, false, false, false, false, false, true, true, true, true, true]
    );
}

#[test]
fn comparison_helper_recurses_python_equality_through_arrays_and_objects() {
    assert_eq!(
        compare_json_values(
            &json!([1, {"nested": [true, 0]}, {"flag": false}]),
            ComparisonOperator::Eq,
            &json!([true, {"nested": [1, false]}, {"flag": 0}])
        ),
        Ok(true)
    );
    assert_eq!(
        compare_json_values(
            &json!({"payload": [1, {"flag": false}]}),
            ComparisonOperator::NotEq,
            &json!({"payload": [true, {"flag": 0}]})
        ),
        Ok(false)
    );
    assert_eq!(
        compare_json_values(
            &json!({"payload": [1, {"flag": false}]}),
            ComparisonOperator::Eq,
            &json!({"payload": [true, {"flag": true}]})
        ),
        Ok(false)
    );
    assert_eq!(
        compare_json_values(
            &json!([true, {"flag": 0}]),
            ComparisonOperator::In,
            &json!([[1, {"flag": false}], [2]])
        ),
        Ok(true)
    );
}

#[test]
fn comparison_helper_reports_type_errors_instead_of_fallback_false() {
    let error = compare_json_values(&json!({"age": 19}), ComparisonOperator::Gt, &json!(18))
        .expect_err("invalid ordered comparison should fail");

    match error {
        ExprError::TypeError { message } => {
            assert!(
                message.contains("cannot compare values"),
                "unexpected message: {message}"
            );
        }
        other => panic!("expected TypeError, got {other:?}"),
    }
}

#[test]
fn evaluate_enforces_short_circuit_value_semantics() {
    let truthy_or_missing = parse("truthy or missing_name").expect("parse should succeed");
    let state = MapState::from_pairs([("truthy", json!("yes"))]);
    assert!(
        evaluate_bool(&truthy_or_missing, &state).expect("or should short-circuit"),
        "truthy or missing_name should be truthy"
    );

    let falsy_and_missing = parse("falsy and missing_name").expect("parse should succeed");
    let state = MapState::from_pairs([("falsy", json!(0))]);
    assert!(
        !evaluate_bool(&falsy_and_missing, &state).expect("and should short-circuit"),
        "falsy and missing_name should be falsey"
    );
}

#[test]
fn evaluate_uses_python_modulo_sign_rules() {
    let ast = parse("n % 2 == 1").expect("parse should succeed");
    let negative = MapState::from_pairs([("n", json!(-1))]);
    assert!(
        evaluate_bool(&ast, &negative).expect("evaluation should succeed"),
        "-1 % 2 should equal 1 under Python semantics"
    );

    let ast = parse("n % -2 == -1").expect("parse should succeed");
    let positive = MapState::from_pairs([("n", json!(1))]);
    assert!(
        evaluate_bool(&ast, &positive).expect("evaluation should succeed"),
        "1 % -2 should equal -1 under Python semantics"
    );
}

#[test]
fn evaluate_modulo_i128_min_negative_one_edge_expression() {
    let ast = parse("(-170141183460469231731687303715884105727 - 1) % -1 == 0")
        .expect("parse should succeed");
    assert_eq!(evaluate_bool(&ast, &MapState::from_pairs([])), Ok(true));
}

#[test]
fn evaluate_modulo_i128_min_negative_one_does_not_panic() {
    let ast = parse("(-170141183460469231731687303715884105727 - 1) % -1 == 0")
        .expect("parse should succeed");
    let result = std::panic::catch_unwind(|| evaluate_bool(&ast, &MapState::from_pairs([])));
    assert!(result.is_ok(), "evaluation should not panic");
    assert_eq!(
        result.expect("catch_unwind should succeed"),
        Ok(true),
        "evaluation should still return true"
    );
}

#[test]
fn evaluate_handles_mixed_numeric_comparisons_without_lossy_int_to_float_cast() {
    let ast = parse("n > 9007199254740992.0").expect("parse should succeed");
    let state = MapState::from_pairs([("n", json!(9007199254740993_i64))]);
    assert!(
        evaluate_bool(&ast, &state).expect("evaluation should succeed"),
        "comparison should remain exact near 2^53"
    );
}

#[test]
fn evaluate_coerces_bool_to_int_in_arithmetic_and_comparison() {
    let arithmetic = parse("True + 1 == 2").expect("parse should succeed");
    assert!(
        evaluate_bool(&arithmetic, &MapState::from_pairs([])).expect("evaluation should succeed")
    );

    let comparison = parse("flag == 1").expect("parse should succeed");
    let state = MapState::from_pairs([("flag", json!(true))]);
    assert!(
        evaluate_bool(&comparison, &state).expect("evaluation should succeed"),
        "bool should compare equal to 1"
    );
}

#[test]
fn parse_and_evaluate_preserve_unknown_escape_literals() {
    let ast = parse("'\\q' == '\\q'").expect("parse should succeed");
    assert!(
        evaluate_bool(&ast, &MapState::from_pairs([])).expect("evaluation should succeed"),
        "unknown escape should preserve literal backslash"
    );
}

#[test]
fn evaluate_reports_integer_overflow() {
    let ast =
        parse("170141183460469231731687303715884105727 + 1 == 0").expect("parse should succeed");
    let error = evaluate_bool(&ast, &MapState::from_pairs([]))
        .expect_err("evaluation should fail with overflow");
    match error {
        ExprError::IntegerOverflow => {}
        other => panic!("expected IntegerOverflow, got {other:?}"),
    }
}
