use super::streaming::{actions, hooks::LifecycleHookRecorder, hooks::StreamAbortHookCounts};
use async_trait::async_trait;
use rurr_core::action::{
    ActionContext, ActionError, ActionInputs, ActionResult, Condition, FunctionActionBuilder,
    LocalAction,
};
use rurr_core::application::{
    Application, ApplicationBuilder, ApplicationError, ExecutionOptions, InitializeFromSpec,
    ParentPointer, RunOutput, StepOutput, Tracker,
};
use rurr_core::graph::Transition;
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, ExecuteCallContext, LifecycleAdapterSet, LifecycleError,
    SyncLifecycleAdapter,
};
use rurr_core::parallelism::ParallelExecutor;
use rurr_core::state::State;
use rurr_persistence::{
    ApplicationPersistenceSpec, AsyncBaseStateLoader, AsyncBaseStatePersister, AsyncBaseStateSaver,
    BaseStateLoader, BaseStatePersister, BaseStateSaver, PersistedStateData, PersistedStateStatus,
    PersistenceError, PersistenceLoadTarget, StateInitializerSpec, StatePersisterSpec,
};
use rurr_testkit::application_fixture::{map_from_pairs, state_from_pairs};
use serde_json::{json, Value};
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

mod persistence;

pub(crate) type HookCounts = StreamAbortHookCounts;

pub(crate) use persistence::*;
pub(crate) use rurr_testkit::application_fixture::{
    async_counter_action, async_counter_action_with_tags, async_counter_with_inputs_action,
    count_zero_state, counter_action, counter_action_with_tags as sync_counter_action_with_tags,
    counter_with_inputs_action, ApplicationScenario, CounterApplicationFixture, CounterMode,
};

pub(crate) fn async_panic_action(message: &'static str) -> rurr_core::FunctionAction {
    FunctionActionBuilder::new()
        .writes(["count"])
        .build_async(move |_state, _ctx| async move { panic!("{message}") })
        .expect("async panic action should build")
}

#[derive(Debug, Clone)]
pub(crate) struct UpdateContextProbeAction {
    name: Option<String>,
    writes: Vec<String>,
    missing_context_message: &'static str,
    missing_sequence_message: &'static str,
}

impl UpdateContextProbeAction {
    fn new(missing_context_message: &'static str, missing_sequence_message: &'static str) -> Self {
        Self {
            name: None,
            writes: vec!["count".to_string(), "update_sequence_id".to_string()],
            missing_context_message,
            missing_sequence_message,
        }
    }
}

impl LocalAction for UpdateContextProbeAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &self.writes
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }
        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
        let result = map_from_pairs([("count", json!(count))]);
        Ok(ActionResult::new(result.clone(), result))
    }

    fn update(
        &self,
        result: &ActionResult,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<State, ActionError> {
        let context =
            ctx.app_context
                .clone()
                .ok_or_else(|| ActionError::RuntimeContextUnavailable {
                    message: self.missing_context_message.to_string(),
                })?;
        let sequence_id =
            context
                .sequence_id
                .ok_or_else(|| ActionError::RuntimeContextUnavailable {
                    message: self.missing_sequence_message.to_string(),
                })?;
        let mut writes = result.writes().clone();
        writes.insert("update_sequence_id".to_string(), Value::from(sequence_id));
        state.update(writes).map_err(ActionError::from)
    }
}

pub(crate) fn sync_update_context_probe_action() -> UpdateContextProbeAction {
    UpdateContextProbeAction::new(
        "expected current context during sync update",
        "expected sequence_id during sync update",
    )
}

pub(crate) fn async_update_context_probe_action() -> UpdateContextProbeAction {
    UpdateContextProbeAction::new(
        "expected current context during async update",
        "expected sequence_id during async update",
    )
}

pub(crate) fn start_finish_counter_builder() -> ApplicationBuilder {
    ApplicationBuilder::new()
        .with_actions(vec![
            ("start", counter_action()),
            ("finish", counter_action()),
        ])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "start",
            "finish",
            Condition::default(),
        )])
        .expect("transitions should configure")
}

pub(crate) fn initialize_from_spec(
    resume_at_next_action: bool,
    default_state: indexmap::IndexMap<String, Value>,
    default_entrypoint: &str,
) -> InitializeFromSpec {
    InitializeFromSpec::new(
        resume_at_next_action,
        default_state,
        default_entrypoint.to_string(),
    )
}

#[derive(Debug, Default)]
pub(crate) struct NoopTracker;

impl SyncLifecycleAdapter for NoopTracker {}
impl AsyncLifecycleAdapter for NoopTracker {}
impl Tracker for NoopTracker {
    fn sync_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn SyncLifecycleAdapter>> {
        Some(self)
    }

    fn async_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn AsyncLifecycleAdapter>> {
        Some(self)
    }
}

#[derive(Debug, Default)]
pub(crate) struct NoopParallelExecutor;

impl ParallelExecutor for NoopParallelExecutor {}

pub(crate) fn sync_counting_hooks(counts: Arc<HookCounts>) -> LifecycleAdapterSet {
    let hook = Arc::new(LifecycleHookRecorder::counting(counts));
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook;
    LifecycleAdapterSet::new(vec![sync_hook], Vec::new())
}

pub(crate) fn sync_async_counting_hooks(counts: Arc<HookCounts>) -> LifecycleAdapterSet {
    let hook = Arc::new(LifecycleHookRecorder::counting(counts));
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = hook;
    LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook])
}

#[derive(Debug)]
struct PostExecuteFailureHook {
    sync_marker: Option<&'static str>,
    async_marker: Option<&'static str>,
}

impl SyncLifecycleAdapter for PostExecuteFailureHook {
    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        if let Some(marker) = self.sync_marker {
            return Err(LifecycleError::hook_failed("post_execute_call", marker));
        }
        Ok(())
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for PostExecuteFailureHook {
    async fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        if let Some(marker) = self.async_marker {
            return Err(LifecycleError::hook_failed("post_execute_call", marker));
        }
        Ok(())
    }
}

pub(crate) fn sync_post_execute_failure_hooks(marker: &'static str) -> LifecycleAdapterSet {
    let hook = Arc::new(PostExecuteFailureHook {
        sync_marker: Some(marker),
        async_marker: None,
    });
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook;
    LifecycleAdapterSet::new(vec![sync_hook], Vec::new())
}

pub(crate) fn async_post_execute_failure_hooks(marker: &'static str) -> LifecycleAdapterSet {
    let hook = Arc::new(PostExecuteFailureHook {
        sync_marker: None,
        async_marker: Some(marker),
    });
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = hook;
    LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook])
}

#[derive(Debug)]
struct PreExecuteFailureHook {
    counts: Arc<HookCounts>,
    marker: &'static str,
}

impl SyncLifecycleAdapter for PreExecuteFailureHook {
    fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.counts
            .sync_pre_execute_call
            .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
        Err(LifecycleError::hook_failed("pre_execute_call", self.marker))
    }

    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.counts
            .sync_post_execute_call
            .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
        Ok(())
    }
}

pub(crate) fn sync_pre_execute_failure_hooks(
    counts: Arc<HookCounts>,
    marker: &'static str,
) -> LifecycleAdapterSet {
    let hook = Arc::new(PreExecuteFailureHook { counts, marker });
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook;
    LifecycleAdapterSet::new(vec![sync_hook], Vec::new())
}

#[derive(Debug)]
struct PanickingPostExecuteHook {
    counts: Arc<HookCounts>,
}

impl SyncLifecycleAdapter for PanickingPostExecuteHook {
    fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.counts
            .sync_pre_execute_call
            .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
        Ok(())
    }

    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.counts
            .sync_post_execute_call
            .fetch_add(1, std::sync::atomic::Ordering::SeqCst);
        panic!("intentional panic in iterate post_execute_call hook");
    }
}

pub(crate) fn sync_panicking_post_execute_hooks(counts: Arc<HookCounts>) -> LifecycleAdapterSet {
    let hook = Arc::new(PanickingPostExecuteHook { counts });
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook;
    LifecycleAdapterSet::new(vec![sync_hook], Vec::new())
}

#[derive(Debug)]
pub(crate) struct ExecuteContextRecorder {
    records: Arc<Mutex<Vec<(String, u64)>>>,
}

impl ExecuteContextRecorder {
    pub(crate) fn new(records: Arc<Mutex<Vec<(String, u64)>>>) -> Self {
        Self { records }
    }
}

impl SyncLifecycleAdapter for ExecuteContextRecorder {
    fn pre_execute_call(&self, context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.records
            .lock()
            .expect("records lock should not be poisoned")
            .push((context.action_name().to_string(), context.sequence_id()));
        Ok(())
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum StepMode {
    Sync,
    Async,
}

pub(crate) type RunMode = StepMode;

impl StepMode {
    fn counter_action(self) -> rurr_core::FunctionAction {
        match self {
            Self::Sync => counter_action(),
            Self::Async => async_counter_action(),
        }
    }

    pub(crate) fn counter_action_with_tags(self, tags: &[&str]) -> rurr_core::FunctionAction {
        match self {
            Self::Sync => sync_counter_action_with_tags(tags),
            Self::Async => async_counter_action_with_tags(tags),
        }
    }

    fn counter_with_inputs_action(self, input_name: &'static str) -> rurr_core::FunctionAction {
        match self {
            Self::Sync => counter_with_inputs_action(input_name),
            Self::Async => async_counter_with_inputs_action(input_name),
        }
    }

    fn counting_hooks(self, counts: Arc<HookCounts>) -> LifecycleAdapterSet {
        match self {
            Self::Sync => sync_counting_hooks(counts),
            Self::Async => sync_async_counting_hooks(counts),
        }
    }

    fn post_execute_failure_hooks(self, marker: &'static str) -> LifecycleAdapterSet {
        match self {
            Self::Sync => sync_post_execute_failure_hooks(marker),
            Self::Async => async_post_execute_failure_hooks(marker),
        }
    }

    fn update_context_probe_action(self) -> UpdateContextProbeAction {
        match self {
            Self::Sync => sync_update_context_probe_action(),
            Self::Async => async_update_context_probe_action(),
        }
    }

    async fn step(
        self,
        app: &mut Application,
        inputs: Option<ActionInputs>,
    ) -> Result<Option<StepOutput>, ApplicationError> {
        match self {
            Self::Sync => app.step(inputs),
            Self::Async => app.astep(inputs).await,
        }
    }

    async fn run(
        self,
        app: &mut Application,
        options: ExecutionOptions,
    ) -> Result<RunOutput, ApplicationError> {
        match self {
            Self::Sync => app.run_with_options(options),
            Self::Async => app.arun_with_options(options).await,
        }
    }

    fn assert_execute_hook_counts(self, counts: &HookCounts, expected_execute: usize) {
        assert_eq!(
            counts
                .sync_pre_execute_call
                .load(std::sync::atomic::Ordering::SeqCst),
            expected_execute,
        );
        assert_eq!(
            counts
                .sync_post_execute_call
                .load(std::sync::atomic::Ordering::SeqCst),
            expected_execute,
        );
        assert_eq!(
            counts
                .sync_pre_run_step
                .load(std::sync::atomic::Ordering::SeqCst),
            0,
        );
        assert_eq!(
            counts
                .sync_post_run_step
                .load(std::sync::atomic::Ordering::SeqCst),
            0,
        );

        if self == Self::Async {
            assert_eq!(
                counts
                    .async_pre_execute_call
                    .load(std::sync::atomic::Ordering::SeqCst),
                expected_execute,
            );
            assert_eq!(
                counts
                    .async_post_execute_call
                    .load(std::sync::atomic::Ordering::SeqCst),
                expected_execute,
            );
            assert_eq!(
                counts
                    .async_pre_run_step
                    .load(std::sync::atomic::Ordering::SeqCst),
                0,
            );
            assert_eq!(
                counts
                    .async_post_run_step
                    .load(std::sync::atomic::Ordering::SeqCst),
                0,
            );
        }
    }

    fn assert_no_hooks_fired(self, counts: &HookCounts) {
        self.assert_execute_hook_counts(counts, 0);
    }
}

const TERMINAL_TAG: &str = "terminal";

pub(crate) const RUN_HALT_ACTIONS: &[&str] = &["counter"];
pub(crate) const STREAM_HALT_ACTIONS: &[&str] = &["pre", "stream"];

pub(crate) fn halt_before_terminal_tag() -> ExecutionOptions {
    ExecutionOptions::new().halt_before([terminal_tag_selector()])
}

pub(crate) fn halt_after_terminal_tag() -> ExecutionOptions {
    ExecutionOptions::new().halt_after([terminal_tag_selector()])
}

pub(crate) fn invalid_halt_options() -> ExecutionOptions {
    ExecutionOptions::new()
        .halt_before(["missing_before"])
        .halt_after(["missing_after"])
}

pub(crate) fn tagged_counter_run_app(mode: RunMode) -> Application {
    CounterApplicationFixture::tagged_three_step(counter_mode(mode), &[TERMINAL_TAG])
        .build()
        .expect("tagged run app should build")
}

pub(crate) fn single_halt_validation_app(mode: RunMode, hooks: LifecycleAdapterSet) -> Application {
    ApplicationScenario::single_action(
        count_zero_state(),
        "counter",
        mode.counter_action_with_tags(&[]),
    )
    .map(|scenario| scenario.with_hooks(hooks))
    .and_then(ApplicationScenario::build)
    .expect("single halt-validation app should build")
}

pub(crate) fn streaming_halt_app(
    pre_calls: Arc<AtomicUsize>,
    stream_calls: Arc<AtomicUsize>,
    hooks: Option<LifecycleAdapterSet>,
) -> Application {
    let builder = ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![(
            "pre",
            actions::non_streaming_count_action(Arc::clone(&pre_calls)).with_tags(&[]),
        )])
        .expect("pre action should configure")
        .with_actions(vec![(
            "stream",
            actions::streaming_count_action(Arc::clone(&stream_calls), 1, None)
                .with_tags(&[TERMINAL_TAG]),
        )])
        .expect("stream action should configure")
        .with_transitions(vec![Transition::new("pre", "stream", Condition::default())])
        .expect("transitions should configure")
        .with_entrypoint("pre")
        .expect("entrypoint should configure");
    let builder = match hooks {
        Some(hooks) => builder.with_hooks(hooks).expect("hooks should configure"),
        None => builder,
    };
    builder.build().expect("streaming halt app should build")
}

pub(crate) fn counting_hooks_for_run(
    mode: RunMode,
    counts: Arc<HookCounts>,
) -> LifecycleAdapterSet {
    mode.counting_hooks(counts)
}

pub(crate) fn assert_invalid_halt_actions(error: ApplicationError, available_actions: &[&str]) {
    let available_actions = available_actions
        .iter()
        .map(|action| (*action).to_string())
        .collect::<Vec<_>>();
    let ApplicationError::InvalidHaltActions {
        missing_actions,
        available_actions: actual_available_actions,
    } = error
    else {
        panic!("expected invalid halt action error");
    };
    assert_eq!(
        missing_actions,
        vec!["missing_before".to_string(), "missing_after".to_string()]
    );
    assert_eq!(actual_available_actions, available_actions);
}

pub(crate) fn assert_no_execute_hooks(counts: &HookCounts) {
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 0);
}

fn terminal_tag_selector() -> String {
    format!("@tag:{TERMINAL_TAG}")
}

fn counter_mode(mode: RunMode) -> CounterMode {
    match mode {
        RunMode::Sync => CounterMode::Sync,
        RunMode::Async => CounterMode::Async,
    }
}

fn reserved_runtime_inputs() -> ActionInputs {
    map_from_pairs([
        ("__context", json!({"forged": true})),
        ("__tracer", json!("forged")),
    ])
}

fn assert_reserved_runtime_input_error(error: &ApplicationError) {
    assert!(matches!(
        error,
        ApplicationError::ReservedRuntimeInputKeys { keys }
            if keys == &vec!["__context".to_string(), "__tracer".to_string()]
    ));
}

fn assert_zero_count_without_sequence_id(app: &Application) {
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

fn assert_zero_count_without_runtime_metadata(app: &Application) {
    assert_zero_count_without_sequence_id(app);
    assert!(!app.state().contains_key("__PRIOR_STEP"));
}

pub(crate) struct IterateExpectation<'a> {
    pub(crate) action: &'a str,
    pub(crate) result_count: i64,
    pub(crate) halted: bool,
    pub(crate) state_count: i64,
    pub(crate) sequence_id: Option<u64>,
    pub(crate) prior_step: Option<&'a str>,
}

pub(crate) struct RunExpectation<'a> {
    pub(crate) action: &'a str,
    pub(crate) result_count: Option<i64>,
    pub(crate) state_count: i64,
    pub(crate) sequence_id: Option<u64>,
    pub(crate) prior_step: Option<&'a str>,
}

pub(crate) const fn iterate_expectation<'a>(
    action: &'a str,
    result_count: i64,
    halted: bool,
    state_count: i64,
    sequence_id: Option<u64>,
    prior_step: Option<&'a str>,
) -> IterateExpectation<'a> {
    IterateExpectation {
        action,
        result_count,
        halted,
        state_count,
        sequence_id,
        prior_step,
    }
}

pub(crate) const fn run_expectation<'a>(
    action: &'a str,
    result_count: Option<i64>,
    state_count: i64,
    sequence_id: Option<u64>,
    prior_step: Option<&'a str>,
) -> RunExpectation<'a> {
    RunExpectation {
        action,
        result_count,
        state_count,
        sequence_id,
        prior_step,
    }
}

#[derive(Clone, Copy, Debug)]
pub(crate) enum ExecuteDriveMode {
    Step,
    Run,
}

impl ExecuteDriveMode {
    pub(crate) async fn drive(
        self,
        mode: StepMode,
        app: &mut Application,
    ) -> Result<(), ApplicationError> {
        match self {
            Self::Step => mode.step(app, None).await.map(|_| ()),
            Self::Run => mode.run(app, ExecutionOptions::new()).await.map(|_| ()),
        }
    }

    pub(crate) fn expectation_label(self) -> &'static str {
        match self {
            Self::Step => "step startup should fail",
            Self::Run => "run startup should fail",
        }
    }
}

pub(crate) async fn assert_execute_drive_startup_error_still_fires_execute_call_hooks(
    drive: ExecuteDriveMode,
    mode: StepMode,
    state: State,
    assert_error: impl FnOnce(&ApplicationError),
    assert_state: impl FnOnce(&Application),
) {
    let counts = Arc::new(HookCounts::default());
    let hooks = mode.counting_hooks(Arc::clone(&counts));
    let mut app = ApplicationScenario::single_action(state, "counter", mode.counter_action())
        .map(|scenario| scenario.with_optional_hooks(Some(hooks)))
        .and_then(ApplicationScenario::build)
        .expect("app should build");

    let error = drive
        .drive(mode, &mut app)
        .await
        .expect_err(drive.expectation_label());

    assert_error(&error);
    mode.assert_execute_hook_counts(&counts, 1);
    assert_state(&app);
}

pub(crate) async fn assert_execute_drive_startup_error_prefers_post_execute_call_failure(
    drive: ExecuteDriveMode,
    mode: StepMode,
    marker: &'static str,
) {
    let hooks = mode.post_execute_failure_hooks(marker);
    let mut app = ApplicationScenario::single_action(
        state_from_pairs([("__SEQUENCE_ID", json!("bad-seq"))]),
        "counter",
        mode.counter_action(),
    )
    .map(|scenario| scenario.with_optional_hooks(Some(hooks)))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let error = drive
        .drive(mode, &mut app)
        .await
        .expect_err(drive.expectation_label());

    assert!(matches!(
        error,
        ApplicationError::LifecycleHookFailed {
            phase: "post_execute_call",
            message
        } if message.contains(marker)
    ));
}

fn assert_sync_execute_call_hooks_once(counts: &HookCounts) {
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
}

pub(crate) fn assert_iterate_startup_error_still_fires_execute_call_hooks(
    state: State,
    assert_error: impl FnOnce(&ApplicationError),
    assert_state: impl FnOnce(&Application),
) {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_counting_hooks(Arc::clone(&counts));
    let app = ApplicationScenario::single_action(state, "counter", counter_action())
        .map(|scenario| scenario.with_optional_hooks(Some(hooks)))
        .and_then(ApplicationScenario::build)
        .expect("app should build");

    let (error, app) = iterate_first_error(app, ExecutionOptions::new());
    assert_error(&error);
    assert_sync_execute_call_hooks_once(&counts);
    assert_state(&app);
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum StepSimpleCase {
    CommitsInternalKeys,
    ReturnsNoneWhenNoNextActionExists,
    CommitsApplicationSequenceAndContextState,
}

pub(crate) async fn assert_step_simple_case(mode: StepMode, case: StepSimpleCase) {
    match case {
        StepSimpleCase::CommitsApplicationSequenceAndContextState => {
            let mut app = ApplicationScenario::single_action(
                state_from_pairs([("count", json!(0))]),
                "counter",
                mode.counter_action(),
            )
            .expect("fixture should build")
            .into_fixture()
            .with_identifiers("phase-a-app", Some("tenant-1".to_string()), None)
            .expect("identifiers should configure")
            .build()
            .expect("app should build");

            let output = mode
                .step(&mut app, None)
                .await
                .expect("step should succeed")
                .expect("step should execute");

            assert_eq!(
                app.sequence_id().expect("sequence_id should resolve"),
                Some(0)
            );

            let context = app.context().expect("context should resolve after step");
            assert_eq!(context.sequence_id, Some(0));
            assert_eq!(context.prior_step.as_deref(), Some("counter"));
            assert_eq!(output.state.get("__PRIOR_STEP"), Some(&json!("counter")));
        }
        simple_case => {
            let mut app = ApplicationScenario::single_action(
                count_zero_state(),
                "counter",
                mode.counter_action(),
            )
            .and_then(ApplicationScenario::build)
            .expect("app should build");

            match simple_case {
                StepSimpleCase::CommitsInternalKeys => {
                    let output = mode
                        .step(&mut app, None)
                        .await
                        .expect("step should succeed")
                        .expect("step should execute an action");

                    assert_eq!(output.action.name(), "counter");
                    assert_eq!(output.result.get("count"), Some(&json!(1)));
                    assert!(!output.halted);
                    assert_eq!(output.state.get("count").cloned(), Some(json!(1)));
                    assert_eq!(output.state.get("__SEQUENCE_ID").cloned(), Some(json!(0)));
                    assert_eq!(
                        output.state.get("__PRIOR_STEP").cloned(),
                        Some(json!("counter"))
                    );
                    assert_eq!(app.state().get("count").cloned(), Some(json!(1)));
                    assert_eq!(app.state().get("__SEQUENCE_ID").cloned(), Some(json!(0)));
                    assert_eq!(
                        app.state().get("__PRIOR_STEP").cloned(),
                        Some(json!("counter"))
                    );
                }
                StepSimpleCase::ReturnsNoneWhenNoNextActionExists => {
                    let _ = mode
                        .step(&mut app, None)
                        .await
                        .expect("first step should succeed")
                        .expect("first step should execute");
                    let second = mode
                        .step(&mut app, None)
                        .await
                        .expect("second step should succeed");

                    assert!(second.is_none(), "there should be no next action");
                    assert_eq!(app.state().get("__SEQUENCE_ID").cloned(), Some(json!(0)));
                }
                StepSimpleCase::CommitsApplicationSequenceAndContextState => unreachable!(),
            }
        }
    }
}

pub(crate) async fn assert_step_keeps_context_active_through_update(mode: StepMode) {
    let mut app = ApplicationScenario::single_action(
        state_from_pairs([("count", json!(0))]),
        "context_update_probe",
        mode.update_context_probe_action(),
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let output = mode
        .step(&mut app, None)
        .await
        .expect("step should succeed")
        .expect("step should execute an action");

    assert_eq!(output.state.get("count").cloned(), Some(json!(1)));
    assert_eq!(
        output.state.get("update_sequence_id").cloned(),
        Some(json!(0))
    );
    assert_eq!(app.state().get("count").cloned(), Some(json!(1)));
    assert_eq!(
        app.state().get("update_sequence_id").cloned(),
        Some(json!(0))
    );
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum ReservedRuntimeInputCase {
    StepWithoutExecuteHooks,
    StepDirect,
    RunDirect,
}

pub(crate) async fn assert_reserved_runtime_inputs_rejected(
    mode: StepMode,
    case: ReservedRuntimeInputCase,
) {
    match case {
        ReservedRuntimeInputCase::StepWithoutExecuteHooks => {
            let counts = Arc::new(HookCounts::default());
            let hooks = mode.counting_hooks(Arc::clone(&counts));

            let mut app = ApplicationScenario::single_action(
                count_zero_state(),
                "counter",
                mode.counter_action(),
            )
            .map(|scenario| scenario.with_hooks(hooks))
            .and_then(ApplicationScenario::build)
            .expect("app should build");

            let error = mode
                .step(&mut app, Some(reserved_runtime_inputs()))
                .await
                .expect_err("reserved runtime inputs should be rejected");

            assert_reserved_runtime_input_error(&error);
            mode.assert_no_hooks_fired(&counts);
        }
        ReservedRuntimeInputCase::StepDirect => {
            let mut app = ApplicationScenario::single_action(
                count_zero_state(),
                "counter",
                mode.counter_action(),
            )
            .and_then(ApplicationScenario::build)
            .expect("app should build");

            let error = mode
                .step(&mut app, Some(reserved_runtime_inputs()))
                .await
                .expect_err("reserved runtime inputs should be rejected");
            assert_reserved_runtime_input_error(&error);
            assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
        }
        ReservedRuntimeInputCase::RunDirect => {
            let mut app = ApplicationScenario::single_action(
                count_zero_state(),
                "counter",
                mode.counter_action(),
            )
            .and_then(ApplicationScenario::build)
            .expect("app should build");

            let error = mode
                .run(
                    &mut app,
                    ExecutionOptions::new().with_inputs(reserved_runtime_inputs()),
                )
                .await
                .expect_err("reserved runtime inputs should be rejected");

            assert_reserved_runtime_input_error(&error);
            assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
        }
    }
}

pub(crate) async fn assert_step_error_rolls_back_without_partial_commit(mode: StepMode) {
    let mut app = match mode {
        StepMode::Sync => {
            let async_only = FunctionActionBuilder::new()
                .writes(["count"])
                .build_async(|_state, _ctx| async move { map_from_pairs([("count", json!(1))]) })
                .expect("async action should build");

            ApplicationScenario::single_action(
                state_from_pairs([("count", json!(0))]),
                "async_only",
                async_only,
            )
            .and_then(ApplicationScenario::build)
            .expect("app should build")
        }
        StepMode::Async => ApplicationScenario::single_action(
            count_zero_state(),
            "counter_async",
            mode.counter_with_inputs_action("additional_increment"),
        )
        .and_then(ApplicationScenario::build)
        .expect("app should build"),
    };

    let error = mode
        .step(&mut app, None)
        .await
        .expect_err("step should surface a pre-commit action error");

    match mode {
        StepMode::Sync => {
            assert!(matches!(
                error,
                ApplicationError::Action(ActionError::AsyncActionRequiresRunAsync)
            ));
        }
        StepMode::Async => {
            assert!(matches!(
                error,
                ApplicationError::Action(ActionError::MissingInput { ref key })
                    if key == "additional_increment"
            ));
        }
    }
    assert_zero_count_without_runtime_metadata(&app);
}

pub(crate) async fn assert_step_execute_context_tracks_resolved_next_action_and_reserved_sequence(
    mode: StepMode,
) {
    let records: Arc<Mutex<Vec<(String, u64)>>> = Arc::new(Mutex::new(Vec::new()));
    let hooks = LifecycleAdapterSet::new(
        vec![Arc::new(ExecuteContextRecorder::new(Arc::clone(&records)))],
        Vec::new(),
    );

    let mut app = ApplicationScenario::two_action_transition(
        state_from_pairs([("count", json!(0))]),
        "A",
        mode.counter_action(),
        "B",
        mode.counter_action(),
        vec![Transition::new("A", "B", Condition::default())],
    )
    .expect("fixture should build")
    .with_hooks(hooks)
    .build()
    .expect("app should build");

    let first = mode
        .step(&mut app, None)
        .await
        .expect("first step should succeed")
        .expect("first step should execute");
    let second = mode
        .step(&mut app, None)
        .await
        .expect("second step should succeed")
        .expect("second step should execute");

    assert_eq!(first.action.name(), "A");
    assert_eq!(second.action.name(), "B");
    assert_eq!(
        records
            .lock()
            .expect("records lock should not be poisoned")
            .as_slice(),
        &[("A".to_string(), 0), ("B".to_string(), 1)]
    );
}

pub(crate) async fn assert_step_injects_application_context_with_reserved_sequence_id(
    mode: StepMode,
) {
    let action = match mode {
        StepMode::Sync => FunctionActionBuilder::new()
            .build_sync(|_state, ctx| {
                let context = ctx
                    .app_context
                    .as_ref()
                    .expect("runtime should provide app context");
                map_from_pairs([
                    ("app_id", json!(context.app_id.clone())),
                    ("partition_key", json!(context.partition_key.clone())),
                    (
                        "sequence_id",
                        json!(context
                            .sequence_id
                            .expect("context should include sequence_id")),
                    ),
                ])
            })
            .expect("context action should build"),
        StepMode::Async => FunctionActionBuilder::new()
            .build_async(|_state, ctx| async move {
                let context = ctx
                    .app_context
                    .as_ref()
                    .expect("runtime should set app context");
                map_from_pairs([
                    ("app_id", json!(context.app_id.clone())),
                    ("partition_key", json!(context.partition_key.clone())),
                    (
                        "sequence_id",
                        json!(context
                            .sequence_id
                            .expect("context should include sequence_id")),
                    ),
                ])
            })
            .expect("context action should build"),
    };
    let mut app = ApplicationScenario::single_action(State::default(), "inspect", action)
        .expect("fixture should build")
        .into_fixture()
        .with_identifiers("app-ctx", Some("tenant-1".to_string()), None)
        .expect("identifiers should configure")
        .build()
        .expect("app should build");

    let output = mode
        .step(&mut app, None)
        .await
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(output.result.get("app_id"), Some(&json!("app-ctx")));
    assert_eq!(output.result.get("partition_key"), Some(&json!("tenant-1")));
    assert_eq!(output.result.get("sequence_id"), Some(&json!(0)));
}

pub(crate) fn assert_iterate_advances_once_then_terminates(
    mut app: Application,
    options: ExecutionOptions,
    expected: IterateExpectation<'_>,
) {
    let mut iter = app.iterate_with_options(options);

    let first = iter
        .next()
        .expect("first iterate call should produce one step")
        .expect("first step should succeed");
    assert_eq!(first.action.name(), expected.action);
    assert_eq!(
        first.result.get("count"),
        Some(&json!(expected.result_count))
    );
    assert_eq!(first.halted, expected.halted);
    assert!(
        iter.next().is_none(),
        "iterate should terminate after the expected first advance"
    );

    drop(iter);
    assert_eq!(
        app.state().get("count").cloned(),
        Some(json!(expected.state_count))
    );

    if let Some(sequence_id) = expected.sequence_id {
        assert_eq!(
            app.state().get("__SEQUENCE_ID").cloned(),
            Some(json!(sequence_id))
        );
    }
    if let Some(prior_step) = expected.prior_step {
        assert_eq!(
            app.state().get("__PRIOR_STEP").cloned(),
            Some(json!(prior_step))
        );
    }
}

pub(crate) fn assert_run_advances_to_expected_terminal_or_pending_action(
    mut app: Application,
    options: ExecutionOptions,
    expected: RunExpectation<'_>,
) {
    let output = app.run_with_options(options).expect("run should succeed");

    let action = output
        .action
        .expect("run should return an action when it advances");
    assert_eq!(action.name(), expected.action);

    match expected.result_count {
        Some(expected_result_count) => {
            let result = output
                .result
                .expect("run should return a result for executed terminal output");
            assert_eq!(result.get("count"), Some(&json!(expected_result_count)));
        }
        None => assert!(
            output.result.is_none(),
            "halt_before should return a pending action without a result"
        ),
    }

    assert_eq!(
        output.state.get("count").cloned(),
        Some(json!(expected.state_count))
    );

    if let Some(sequence_id) = expected.sequence_id {
        assert_eq!(
            output.state.get("__SEQUENCE_ID").cloned(),
            Some(json!(sequence_id))
        );
        assert_eq!(
            app.state().get("__SEQUENCE_ID").cloned(),
            Some(json!(sequence_id))
        );
    }
    if let Some(prior_step) = expected.prior_step {
        assert_eq!(
            output.state.get("__PRIOR_STEP").cloned(),
            Some(json!(prior_step))
        );
        assert_eq!(
            app.state().get("__PRIOR_STEP").cloned(),
            Some(json!(prior_step))
        );
    }
}

fn iterate_first_error(
    mut app: Application,
    options: ExecutionOptions,
) -> (ApplicationError, Application) {
    let mut iter = app.iterate_with_options(options);
    let error = iter
        .next()
        .expect("first iterate call should return an error item")
        .expect_err("iterate startup should fail");
    assert!(
        iter.next().is_none(),
        "iterator should terminate after returning an error"
    );
    drop(iter);
    (error, app)
}

pub(crate) fn assert_iterate_startup_failure_exhausts_iterator_after_pre_execute_hook_error(
    marker: &'static str,
) {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_pre_execute_failure_hooks(Arc::clone(&counts), marker);
    let app = ApplicationScenario::single_action(count_zero_state(), "counter", counter_action())
        .map(|scenario| scenario.with_hooks(hooks))
        .and_then(ApplicationScenario::build)
        .expect("app should build");

    let (error, _) = iterate_first_error(app, ExecutionOptions::new());
    assert!(matches!(
        error,
        ApplicationError::LifecycleHookFailed {
            phase: "pre_execute_call",
            message
        } if message.contains(marker)
    ));
    assert_eq!(
        counts
            .sync_pre_execute_call
            .load(std::sync::atomic::Ordering::SeqCst),
        1,
    );
    assert_eq!(
        counts
            .sync_post_execute_call
            .load(std::sync::atomic::Ordering::SeqCst),
        0,
    );
}

pub(crate) fn assert_iterate_startup_error_prefers_post_execute_call_failure(marker: &'static str) {
    let hooks = sync_post_execute_failure_hooks(marker);
    let app = ApplicationScenario::single_action(
        state_from_pairs([("__SEQUENCE_ID", json!("bad-seq"))]),
        "counter",
        counter_action(),
    )
    .map(|scenario| scenario.with_optional_hooks(Some(hooks)))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let (error, _) = iterate_first_error(app, ExecutionOptions::new());
    assert!(matches!(
        error,
        ApplicationError::LifecycleHookFailed {
            phase: "post_execute_call",
            message
        } if message.contains(marker)
    ));
}

pub(crate) fn assert_iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next() {
    let app = ApplicationScenario::single_action(count_zero_state(), "counter", counter_action())
        .and_then(ApplicationScenario::build)
        .expect("app should build");

    let (error, app) = iterate_first_error(
        app,
        ExecutionOptions::new().with_inputs(reserved_runtime_inputs()),
    );
    assert_reserved_runtime_input_error(&error);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
}
