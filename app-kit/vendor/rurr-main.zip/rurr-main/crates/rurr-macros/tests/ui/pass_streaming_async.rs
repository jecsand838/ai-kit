use indexmap::IndexMap;
use rurr_core::action::{
    boxed_local_async_stream, ActionContext, ActionTracer, LocalAction, LocalAsyncStreamOutput,
};
use rurr_core::state::State;
use serde_json::json;

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
async fn async_streaming_counter(state: &State) -> LocalAsyncStreamOutput {
    let next = state
        .get("count")
        .and_then(serde_json::Value::as_i64)
        .unwrap_or(0)
        + 1;
    let item = IndexMap::from([("count".to_string(), json!(next))]);
    let final_state = state
        .update(IndexMap::from([("count".to_string(), json!(next))]))
        .expect("streaming action state update should succeed");
    boxed_local_async_stream(futures::stream::once(async move {
        Ok((item, Some(final_state)))
    }))
}

fn assert_async_streaming_bounds<T: LocalAction + Send + Sync>(action: &T) {
    let _ = action;
}

fn main() {
    let action = async_streaming_counter_action().expect("macro-generated action should build");
    assert_async_streaming_bounds(&action);
    let state = State::new(IndexMap::new());
    let _ = action.stream_run_async(
        state,
        ActionContext::new(IndexMap::new(), ActionTracer::default(), None),
    );
}
