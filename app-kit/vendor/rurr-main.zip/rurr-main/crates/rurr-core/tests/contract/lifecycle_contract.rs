use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_core::lifecycle::LifecycleError;
use rurr_core::{
    AsyncLifecycleAdapter, ExecuteCallContext, FunctionActionBuilder, Graph, GraphAction,
    GraphBuilder, LifecycleAdapterSet, LocalAction, ParentPointer, PostStepContext, PreStepContext,
    SlowDownHook, State, StateAndResultsFullLogger, StateAndResultsLogMode, StreamContext,
    SyncLifecycleAdapter,
};
use rurr_testkit::test_dir_for_test;
use serde_json::{json, Value};
use std::fs;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant, SystemTime};

type SharedLog = Arc<Mutex<Vec<String>>>;

#[derive(Debug)]
struct SyncRecorderAdapter {
    label: &'static str,
    calls: SharedLog,
}

impl SyncRecorderAdapter {
    fn new(label: &'static str, calls: SharedLog) -> Self {
        Self { label, calls }
    }

    fn record(&self, event: &str) {
        self.calls
            .lock()
            .expect("call log lock poisoned")
            .push(format!("{}:sync:{event}", self.label));
    }
}

impl SyncLifecycleAdapter for SyncRecorderAdapter {
    fn register_application(
        &self,
        _app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.record("register_application");
        Ok(())
    }

    fn register_child_application(
        &self,
        _child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.record("register_child_application");
        Ok(())
    }

    fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.record("pre_execute_call");
        Ok(())
    }

    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.record("post_execute_call");
        Ok(())
    }

    fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        self.record("pre_run_step");
        Ok(())
    }

    fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        self.record("post_run_step");
        Ok(())
    }

    fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.record("pre_start_stream");
        Ok(())
    }

    fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.record("post_end_stream");
        Ok(())
    }
}

#[derive(Debug)]
struct AsyncRecorderAdapter {
    label: &'static str,
    calls: SharedLog,
}

impl AsyncRecorderAdapter {
    fn new(label: &'static str, calls: SharedLog) -> Self {
        Self { label, calls }
    }

    fn record(&self, event: &str) {
        self.calls
            .lock()
            .expect("call log lock poisoned")
            .push(format!("{}:async:{event}", self.label));
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for AsyncRecorderAdapter {
    async fn register_application(
        &self,
        _app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.record("register_application");
        Ok(())
    }

    async fn register_child_application(
        &self,
        _child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.record("register_child_application");
        Ok(())
    }

    async fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.record("pre_execute_call");
        Ok(())
    }

    async fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.record("post_execute_call");
        Ok(())
    }

    async fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.record("pre_start_stream");
        Ok(())
    }

    async fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.record("post_end_stream");
        Ok(())
    }
}

fn execute_context() -> ExecuteCallContext {
    ExecuteCallContext::new("app", "partition", "action", 41)
}

fn pre_step_context() -> PreStepContext {
    PreStepContext::new("action", 41, 9, fixed_started_at())
}

fn post_step_context() -> PostStepContext {
    PostStepContext::new("action", 41, 9, fixed_started_at())
}

fn stream_context() -> StreamContext {
    StreamContext::new("action", 41, 7)
}

fn graph_action(name: &str) -> GraphAction {
    let named = FunctionActionBuilder::new()
        .reads(["lifecycle_input"])
        .writes(["lifecycle_output"])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("function action should build")
        .with_name(name)
        .expect("function action should accept a name once");
    GraphAction::new(named).expect("named function action should create a graph action")
}

fn child_registration_graph() -> Graph {
    GraphBuilder::new()
        .with_actions(vec![graph_action("entrypoint")])
        .build()
        .expect("single-action graph should build")
}

fn parent_pointer(app_id: &str, sequence_id: u64) -> ParentPointer {
    ParentPointer {
        app_id: app_id.to_string(),
        partition_key: Some("pk".to_string()),
        sequence_id: Some(sequence_id),
    }
}

fn snapshot(calls: &SharedLog) -> Vec<String> {
    calls.lock().expect("call log lock poisoned").clone()
}

fn fixed_started_at() -> SystemTime {
    SystemTime::UNIX_EPOCH + Duration::from_secs(1)
}

#[derive(Debug, Default)]
struct StepStartedAtRecorder {
    pre_contexts: Mutex<Vec<PreStepContext>>,
    post_contexts: Mutex<Vec<PostStepContext>>,
}

impl StepStartedAtRecorder {
    fn pre_snapshot(&self) -> Vec<PreStepContext> {
        self.pre_contexts
            .lock()
            .expect("pre contexts lock poisoned")
            .clone()
    }

    fn post_snapshot(&self) -> Vec<PostStepContext> {
        self.post_contexts
            .lock()
            .expect("post contexts lock poisoned")
            .clone()
    }
}

impl SyncLifecycleAdapter for StepStartedAtRecorder {
    fn pre_run_step(&self, context: &PreStepContext) -> Result<(), LifecycleError> {
        self.pre_contexts
            .lock()
            .expect("pre contexts lock poisoned")
            .push(context.clone());
        Ok(())
    }

    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.post_contexts
            .lock()
            .expect("post contexts lock poisoned")
            .push(context.clone());
        Ok(())
    }
}

#[test]
fn sync_helpers_preserve_order_across_adapters() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        Vec::new(),
    );
    let context = execute_context();

    adapter_set
        .pre_execute_call_sync(&context)
        .expect("pre_execute_call_sync should succeed");
    adapter_set
        .post_execute_call_sync(&context)
        .expect("post_execute_call_sync should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:pre_execute_call".to_string(),
            "sync-2:sync:pre_execute_call".to_string(),
            "sync-1:sync:post_execute_call".to_string(),
            "sync-2:sync:post_execute_call".to_string(),
        ]
    );
}

#[tokio::test]
async fn async_helpers_run_sync_before_async_and_preserve_order() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        vec![
            Arc::new(AsyncRecorderAdapter::new("async-1", Arc::clone(&calls))),
            Arc::new(AsyncRecorderAdapter::new("async-2", Arc::clone(&calls))),
        ],
    );
    let context = execute_context();

    adapter_set
        .pre_execute_call_async(&context)
        .await
        .expect("pre_execute_call_async should succeed");
    adapter_set
        .post_execute_call_async(&context)
        .await
        .expect("post_execute_call_async should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:pre_execute_call".to_string(),
            "sync-2:sync:pre_execute_call".to_string(),
            "async-1:async:pre_execute_call".to_string(),
            "async-2:async:pre_execute_call".to_string(),
            "sync-1:sync:post_execute_call".to_string(),
            "sync-2:sync:post_execute_call".to_string(),
            "async-1:async:post_execute_call".to_string(),
            "async-2:async:post_execute_call".to_string(),
        ]
    );
}

#[test]
fn register_child_application_sync_preserves_order_across_adapters() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        Vec::new(),
    );
    let graph = child_registration_graph();
    let parent = parent_pointer("parent-app", 41);
    let spawning_parent = parent_pointer("spawning-parent-app", 42);

    adapter_set
        .register_child_application_sync(
            "child-app",
            Some("partition"),
            &graph,
            Some(&parent),
            Some(&spawning_parent),
        )
        .expect("register_child_application_sync should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:register_child_application".to_string(),
            "sync-2:sync:register_child_application".to_string(),
        ]
    );
}

#[tokio::test]
async fn register_child_application_async_runs_sync_before_async() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        vec![
            Arc::new(AsyncRecorderAdapter::new("async-1", Arc::clone(&calls))),
            Arc::new(AsyncRecorderAdapter::new("async-2", Arc::clone(&calls))),
        ],
    );
    let graph = child_registration_graph();
    let parent = parent_pointer("parent-app", 41);
    let spawning_parent = parent_pointer("spawning-parent-app", 42);

    adapter_set
        .register_child_application_async(
            "child-app",
            Some("partition"),
            &graph,
            Some(&parent),
            Some(&spawning_parent),
        )
        .await
        .expect("register_child_application_async should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:register_child_application".to_string(),
            "sync-2:sync:register_child_application".to_string(),
            "async-1:async:register_child_application".to_string(),
            "async-2:async:register_child_application".to_string(),
        ]
    );
}

#[test]
fn register_application_sync_preserves_order_across_adapters() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        Vec::new(),
    );
    let graph = child_registration_graph();

    adapter_set
        .register_application_sync("app", Some("pk"), &graph, None, None)
        .expect("register_application_sync should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:register_application".to_string(),
            "sync-2:sync:register_application".to_string(),
        ]
    );
}

#[tokio::test]
async fn register_application_async_runs_sync_before_async() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        vec![
            Arc::new(AsyncRecorderAdapter::new("async-1", Arc::clone(&calls))),
            Arc::new(AsyncRecorderAdapter::new("async-2", Arc::clone(&calls))),
        ],
    );
    let graph = child_registration_graph();

    adapter_set
        .register_application_async("app", Some("pk"), &graph, None, None)
        .await
        .expect("register_application_async should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:register_application".to_string(),
            "sync-2:sync:register_application".to_string(),
            "async-1:async:register_application".to_string(),
            "async-2:async:register_application".to_string(),
        ]
    );
}

#[tokio::test]
async fn async_paths_execute_sync_step_hooks_even_without_async_adapters() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        Vec::new(),
    );
    let pre_context = pre_step_context();
    let post_context = post_step_context();

    adapter_set
        .pre_run_step_async(&pre_context)
        .await
        .expect("pre_run_step_async should succeed");
    adapter_set
        .post_run_step_async(&post_context)
        .await
        .expect("post_run_step_async should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:pre_run_step".to_string(),
            "sync-2:sync:pre_run_step".to_string(),
            "sync-1:sync:post_run_step".to_string(),
            "sync-2:sync:post_run_step".to_string(),
        ]
    );
}

#[tokio::test]
async fn pre_start_stream_async_runs_sync_before_async() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        vec![
            Arc::new(AsyncRecorderAdapter::new("async-1", Arc::clone(&calls))),
            Arc::new(AsyncRecorderAdapter::new("async-2", Arc::clone(&calls))),
        ],
    );
    let context = stream_context();

    adapter_set
        .pre_start_stream_async(&context)
        .await
        .expect("pre_start_stream_async should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:pre_start_stream".to_string(),
            "sync-2:sync:pre_start_stream".to_string(),
            "async-1:async:pre_start_stream".to_string(),
            "async-2:async:pre_start_stream".to_string(),
        ]
    );
}

#[tokio::test]
async fn post_end_stream_async_runs_sync_then_async_once_each() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        vec![
            Arc::new(AsyncRecorderAdapter::new("async-1", Arc::clone(&calls))),
            Arc::new(AsyncRecorderAdapter::new("async-2", Arc::clone(&calls))),
        ],
    );
    let context = stream_context();

    adapter_set
        .post_end_stream_async(&context)
        .await
        .expect("post_end_stream_async should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "sync-1:sync:post_end_stream".to_string(),
            "sync-2:sync:post_end_stream".to_string(),
            "async-1:async:post_end_stream".to_string(),
            "async-2:async:post_end_stream".to_string(),
        ]
    );
}

#[tokio::test]
async fn post_end_stream_async_only_skips_sync_adapters() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        vec![
            Arc::new(AsyncRecorderAdapter::new("async-1", Arc::clone(&calls))),
            Arc::new(AsyncRecorderAdapter::new("async-2", Arc::clone(&calls))),
        ],
    );
    let context = stream_context();

    adapter_set
        .post_end_stream_async_only(&context)
        .await
        .expect("post_end_stream_async_only should succeed");

    assert_eq!(
        snapshot(&calls),
        vec![
            "async-1:async:post_end_stream".to_string(),
            "async-2:async:post_end_stream".to_string(),
        ]
    );
}

#[test]
fn state_and_results_full_logger_requires_jsonl_suffix() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let error = StateAndResultsFullLogger::new(
        temp_dir.join("not-a-log.txt"),
        StateAndResultsLogMode::Append,
    )
    .expect_err("non-jsonl path should be rejected");

    assert!(
        error.to_string().contains(".jsonl"),
        "expected jsonl validation error, got: {error}"
    );
}

#[test]
fn state_and_results_full_logger_writes_stable_jsonl_record() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let log_path = temp_dir.join("state-results.jsonl");
    let logger = StateAndResultsFullLogger::new(&log_path, StateAndResultsLogMode::Truncate)
        .expect("logger should initialize");

    let pre_context = pre_step_context().with_app_id("demo-app");
    let state = State::new(IndexMap::from([
        ("count".to_string(), json!(2)),
        ("status".to_string(), json!("done")),
    ]));
    let post_context = post_step_context()
        .with_app_id("demo-app")
        .with_result(IndexMap::from([
            ("count".to_string(), json!(2)),
            ("message".to_string(), json!("ok")),
        ]))
        .with_state(state);

    logger
        .pre_run_step(&pre_context)
        .expect("pre_run_step should succeed");
    logger
        .post_run_step(&post_context)
        .expect("post_run_step should succeed");

    let log_contents = fs::read_to_string(&log_path).expect("log file should be readable");
    let lines = log_contents.lines().collect::<Vec<_>>();
    assert_eq!(lines.len(), 1, "expected a single jsonl record");

    let record: Value = serde_json::from_str(lines[0]).expect("record should be valid json");
    let object = record
        .as_object()
        .expect("record should deserialize as an object");
    let keys = object.keys().cloned().collect::<Vec<_>>();
    assert_eq!(
        keys,
        vec![
            "state".to_string(),
            "action".to_string(),
            "result".to_string(),
            "exception".to_string(),
            "start_time".to_string(),
            "end_time".to_string(),
        ]
    );
    assert_eq!(object.get("action"), Some(&json!("action")));
    assert_eq!(
        object.get("state"),
        Some(&json!({
            "count": 2,
            "status": "done"
        }))
    );
    assert_eq!(
        object.get("result"),
        Some(&json!({
            "count": 2,
            "message": "ok"
        }))
    );
    assert_eq!(object.get("exception"), Some(&Value::Null));

    let start_time = object
        .get("start_time")
        .and_then(Value::as_str)
        .expect("start_time should be a string");
    let end_time = object
        .get("end_time")
        .and_then(Value::as_str)
        .expect("end_time should be a string");
    assert!(
        start_time.contains('T') && start_time.ends_with('Z'),
        "start_time should use RFC3339 UTC formatting: {start_time}"
    );
    assert!(
        end_time.contains('T') && end_time.ends_with('Z'),
        "end_time should use RFC3339 UTC formatting: {end_time}"
    );
    assert!(
        start_time <= end_time,
        "timestamps should be monotonic within a single step record"
    );
}

#[test]
fn state_and_results_full_logger_uses_post_context_started_at_without_pre_registration() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let log_path = temp_dir.join("state-results-started-at.jsonl");
    let logger = StateAndResultsFullLogger::new(&log_path, StateAndResultsLogMode::Truncate)
        .expect("logger should initialize");

    let post_context = PostStepContext::new("action", 41, 9, fixed_started_at())
        .with_app_id("demo-app")
        .with_state(State::new(IndexMap::from([(
            "count".to_string(),
            json!(2),
        )])))
        .with_result(IndexMap::from([("count".to_string(), json!(2))]));

    logger
        .post_run_step(&post_context)
        .expect("post_run_step should succeed without prior logger-local pre hook");

    let log_contents = fs::read_to_string(&log_path).expect("log file should be readable");
    let record: Value =
        serde_json::from_str(log_contents.lines().next().expect("record should exist"))
            .expect("record should deserialize");
    assert_eq!(
        record.get("start_time"),
        Some(&json!("1970-01-01T00:00:01.000000000Z"))
    );
}

#[test]
fn state_and_results_full_logger_append_mode_preserves_existing_jsonl_boundaries() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let log_path = temp_dir.join("state-results-append.jsonl");
    fs::write(
        &log_path,
        r#"{"state":{"count":1},"action":"seed","result":{"count":1},"exception":null,"start_time":"2026-03-21T00:00:00Z","end_time":"2026-03-21T00:00:01Z"}"#,
    )
    .expect("seed log should be written without a trailing newline");

    let logger = StateAndResultsFullLogger::new(&log_path, StateAndResultsLogMode::Append)
        .expect("logger should initialize in append mode");
    let pre_context = pre_step_context().with_app_id("demo-app");
    let post_context = post_step_context()
        .with_app_id("demo-app")
        .with_state(State::new(IndexMap::from([(
            "count".to_string(),
            json!(2),
        )])))
        .with_result(IndexMap::from([("count".to_string(), json!(2))]));

    logger
        .pre_run_step(&pre_context)
        .expect("pre_run_step should succeed");
    logger
        .post_run_step(&post_context)
        .expect("post_run_step should succeed");

    let log_contents = fs::read_to_string(&log_path).expect("log file should be readable");
    let lines = log_contents.lines().collect::<Vec<_>>();
    assert_eq!(lines.len(), 2, "expected a two-line jsonl file");
    for line in lines {
        serde_json::from_str::<Value>(line).expect("each jsonl line should remain valid json");
    }
}

#[test]
fn state_and_results_full_logger_fails_closed_without_state() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let log_path = temp_dir.join("state-results-missing-state.jsonl");
    let logger = StateAndResultsFullLogger::new(&log_path, StateAndResultsLogMode::Truncate)
        .expect("logger should initialize");

    let error = logger
        .post_run_step(&post_step_context().with_app_id("demo-app"))
        .expect_err("missing post-step state should fail closed");
    assert!(
        error
            .to_string()
            .contains("state/results logger requires committed post-step state"),
        "unexpected missing-state error: {error}"
    );
    assert!(
        fs::read_to_string(&log_path)
            .map(|contents| contents.trim().is_empty())
            .unwrap_or(true),
        "logger should not write a synthetic record when post-step state is absent"
    );
}

#[test]
fn lifecycle_defaults_are_reexported_from_rurr_core_root() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let _mode = rurr_core::StateAndResultsLogMode::Append;
    let _slow_down = rurr_core::SlowDownHook::default();
    let _logger = rurr_core::StateAndResultsFullLogger::new(
        temp_dir.join("root-export.jsonl"),
        rurr_core::StateAndResultsLogMode::Truncate,
    )
    .expect("root re-export should be constructible");
}

#[test]
fn slow_down_hook_sleeps_for_configured_pre_and_post_durations() {
    let hook = SlowDownHook::new(Duration::from_millis(10), Duration::from_millis(12));
    let pre_context = pre_step_context();
    let post_context = post_step_context();

    let pre_start = Instant::now();
    hook.pre_run_step(&pre_context)
        .expect("pre_run_step should succeed");
    assert!(
        pre_start.elapsed() >= Duration::from_millis(10),
        "pre_run_step should sleep for at least the configured duration"
    );

    let post_start = Instant::now();
    hook.post_run_step(&post_context)
        .expect("post_run_step should succeed");
    assert!(
        post_start.elapsed() >= Duration::from_millis(12),
        "post_run_step should sleep for at least the configured duration"
    );
}

#[test]
fn step_guard_preserves_started_at_from_pre_to_post_context() {
    let recorder = Arc::new(StepStartedAtRecorder::default());
    let adapter_set = LifecycleAdapterSet::new(vec![recorder.clone()], Vec::new());
    let mut guard = rurr_core::StepGuard::start_sync(
        &adapter_set,
        PreStepContext::new("action", 41, 9, fixed_started_at()).with_app_id("demo-app"),
    )
    .expect("step guard should start");
    guard.record_outcome(rurr_core::StepOutcome::Success {
        result: IndexMap::from([("count".to_string(), json!(2))]),
        state: State::new(IndexMap::from([("count".to_string(), json!(2))])),
    });
    guard
        .finish_sync()
        .expect("step guard should finish successfully");

    let pre_contexts = recorder.pre_snapshot();
    let post_contexts = recorder.post_snapshot();
    assert_eq!(pre_contexts.len(), 1);
    assert_eq!(post_contexts.len(), 1);
    assert_eq!(pre_contexts[0].started_at(), fixed_started_at());
    assert_eq!(post_contexts[0].started_at(), fixed_started_at());
}

#[test]
fn log_attributes_sync_is_ordered() {
    let calls: SharedLog = Arc::new(Mutex::new(Vec::new()));
    let adapter_set = LifecycleAdapterSet::new(
        vec![
            Arc::new(SyncRecorderAdapter::new("sync-1", Arc::clone(&calls))),
            Arc::new(SyncRecorderAdapter::new("sync-2", Arc::clone(&calls))),
        ],
        Vec::new(),
    );
    let context = rurr_core::lifecycle::SpanContext::new("action", 41, "span-1");
    let attributes: IndexMap<String, Value> = IndexMap::from([("foo".to_string(), Value::Null)]);

    adapter_set
        .log_attributes_sync(&context, &attributes)
        .expect("log_attributes_sync should succeed");
    assert!(
        snapshot(&calls).is_empty(),
        "default log_attributes no-op should not emit records"
    );
}
