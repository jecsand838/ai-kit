use crate::layout::{PersistedStateData, PersistedStateStatus};
use async_trait::async_trait;
use indexmap::IndexMap;
use serde_json::Value;
use thiserror::Error;

/// Errors returned by persistence loaders and savers.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum PersistenceError {
    /// The backend has not been initialized yet.
    #[error("persister is not initialized")]
    NotInitialized,
    /// The backend rejected the requested operation.
    #[error("operation is not supported: {operation}")]
    UnsupportedOperation {
        /// Stable operation identifier used by callers and tests.
        operation: &'static str,
    },
    /// The backend read a persisted artifact that is present in an invalid state.
    ///
    /// Loaders use this when a caller selected an existing persisted record or
    /// application directory, but a required artifact inside it was missing or
    /// malformed. This is distinct from `Ok(None)`, which means the requested
    /// record itself was absent or did not match the requested partition.
    #[error("invalid persisted state during {operation}: {message}")]
    InvalidPersistedState {
        /// Stable operation identifier used by callers and tests.
        operation: &'static str,
        /// Backend-provided corruption details.
        message: String,
    },
    /// A persistence timestamp could not be represented by the storage layout.
    #[error("invalid timestamp during {operation}: {message}")]
    InvalidTimestamp {
        /// Stable operation identifier used by callers and tests.
        operation: &'static str,
        /// Timestamp conversion details.
        message: String,
    },
    /// A backend operation failed and exposed provider-specific detail.
    #[error("backend operation failed during {operation}: {message}")]
    BackendOperationFailed {
        /// Stable operation identifier used by callers and tests.
        operation: &'static str,
        /// Backend-provided failure details.
        message: String,
    },
    /// The in-memory persister's internal mutex was poisoned.
    #[error("in-memory persister lock poisoned")]
    InMemoryLockPoisoned,
}

/// Synchronous loader for persisted application state.
pub trait BaseStateLoader: Send + Sync {
    /// Loads a persisted-state record, optionally scoped by app id and sequence id.
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError>;

    /// Lists application identifiers that exist within `partition_key`.
    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError>;
}

/// Synchronous saver for persisted application state.
pub trait BaseStateSaver: Send + Sync {
    /// Performs any one-time backend initialization.
    fn initialize(&self) -> Result<(), PersistenceError> {
        Ok(())
    }

    /// Returns whether the backend is initialized.
    fn is_initialized(&self) -> Result<bool, PersistenceError> {
        Err(PersistenceError::UnsupportedOperation {
            operation: "is_initialized",
        })
    }

    /// Performs any backend cleanup needed before shutdown.
    fn cleanup(&self) -> Result<(), PersistenceError> {
        Ok(())
    }

    /// Saves a persisted-state record.
    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError>;
}

/// Combined sync loader and saver trait.
pub trait BaseStatePersister: BaseStateLoader + BaseStateSaver {}

impl<T> BaseStatePersister for T where T: BaseStateLoader + BaseStateSaver + ?Sized {}

/// Asynchronous loader for persisted application state.
#[async_trait]
pub trait AsyncBaseStateLoader: Send + Sync {
    /// Loads a persisted-state record, optionally scoped by app id and sequence id.
    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError>;

    /// Lists application identifiers that exist within `partition_key`.
    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError>;
}

/// Asynchronous saver for persisted application state.
#[async_trait]
pub trait AsyncBaseStateSaver: Send + Sync {
    /// Performs any one-time backend initialization.
    async fn initialize(&self) -> Result<(), PersistenceError> {
        Ok(())
    }

    /// Returns whether the backend is initialized.
    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        Err(PersistenceError::UnsupportedOperation {
            operation: "is_initialized",
        })
    }

    /// Performs any backend cleanup needed before shutdown.
    async fn cleanup(&self) -> Result<(), PersistenceError> {
        Ok(())
    }

    /// Saves a persisted-state record.
    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError>;
}

/// Combined async loader and saver trait.
#[async_trait]
pub trait AsyncBaseStatePersister: AsyncBaseStateLoader + AsyncBaseStateSaver {}

impl<T> AsyncBaseStatePersister for T where T: AsyncBaseStateLoader + AsyncBaseStateSaver + ?Sized {}
