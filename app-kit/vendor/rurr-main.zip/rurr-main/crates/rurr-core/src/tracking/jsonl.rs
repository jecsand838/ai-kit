use serde::Serialize;
use std::io::{self, Write};
use std::path::Path;

pub use rurr_tracking_store::jsonl::{with_locked_jsonl_file, JsonlLockMode};

/// Appends a single JSON value to a locked JSONL file and flushes the write.
pub fn append_jsonl_locked<T: Serialize>(path: &Path, value: &T) -> io::Result<()> {
    with_locked_jsonl_file(path, JsonlLockMode::Exclusive, |file| {
        rurr_tracking_store::jsonl::JsonlWriter::new(file)?.write_value(value)?;
        file.flush()
    })
}
