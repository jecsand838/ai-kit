---
name: rurr-proc-macro-ui-contract
description: "Use when editing rurr-macros proc macros, generated action or streaming-action APIs, reserved runtime identifiers, or trybuild compile-fail suites to preserve deterministic diagnostics and remove hidden macro-generated panic paths."
---

# Rurr Proc Macro UI Contract

Use this skill when a Rurr proc-macro change affects generated APIs, diagnostics, compile-fail tests, or runtime-reserved identifiers.

## Quick start

Load, in order:

- `AGENTS.md`
- `README.md`
- `docs/00_overview.md`
- current `rurr-macros` code and trybuild tests
- relevant generated-action call sites or examples

Load these companion skills:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-testing`

Add `$rurr-burr-source-parity-walk` only when macro behavior changes Burr-visible action semantics.

## Workflow

1. Identify whether the change affects signature analysis, generated constructors, streaming actions, diagnostics, or reserved runtime names.
2. Add or request a trybuild red test before changing macro behavior.
3. Validate user-discovered identifiers during signature analysis and emit `syn::Error` for invalid user input.
4. Keep generated constructors panic-free when macro validation already proves inputs valid.
5. Preserve deterministic diagnostics and update stderr fixtures only for intentional diagnostic changes.
6. Keep macro implementation concrete and local; do not add broad parser abstractions without repeated real patterns.
7. Keep this skill scoped to the user-facing `rurr-macros` API. Do not use proc macros,
   `macro_rules!`, or macro helper crates as a general reduction strategy elsewhere in the
   workspace.
8. Run the macro package gate before broader gates.

## Output contract

Return:

- the macro contract under review
- the compile-fail or compile-pass fixture required
- the diagnostic text or reserved-name rule being enforced
- the panic path or generated code path being removed
- the narrow macro gate and any follow-on repo gate

## Default rules

- Treat user parameters starting with `__` as reserved runtime namespace violations.
- Prefer compile-time `syn::Error` over generated runtime panics.
- Do not weaken trybuild tests or accept vague diagnostic drift.
- Keep public constructor shape only when it remains useful after validation.
- Avoid new proc-macro helper crates.
- Do not justify macro-based cleanup outside the public macro crate by invoking this skill.

## Do not use this skill alone when

- the macro change is part of a larger delete-first plan: also use `$rurr-delete-first-refactor-plan`
- implementation is requested for an approved delete-first refactor: also use `$rurr-delete-first-refactor-plan` in implementation mode
- the change affects runtime execution semantics too: also use `$rurr-streaming-transaction-safety`
- final handoff requires gate selection: also use `$rurr-gate-closeout`
