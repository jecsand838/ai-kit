use super::*;

#[derive(Default)]
struct IndexingBackendStub {
    queries: Mutex<Vec<(usize, usize, bool)>>,
}

#[async_trait]
impl TrackingBackend for IndexingBackendStub {
    fn backend_name(&self) -> &'static str {
        "stub"
    }

    fn backend_capabilities(&self) -> BackendCapabilities {
        BackendCapabilities {
            indexing: true,
            ..BackendCapabilities::default()
        }
    }

    async fn list_projects(&self) -> Result<Vec<Project>, BackendError> {
        Ok(Vec::new())
    }

    async fn list_apps(
        &self,
        _project_id: &str,
        _partition_key: Option<&str>,
        _limit: usize,
        _offset: usize,
    ) -> Result<ApplicationPage, BackendError> {
        Ok(ApplicationPage {
            applications: Vec::new(),
            total: 0,
            has_another_page: false,
        })
    }

    async fn read_app(
        &self,
        project_id: &str,
        app_id: &str,
        partition_key: Option<&str>,
    ) -> Result<ApplicationLogs, BackendError> {
        Err(BackendError::NotFound {
            resource: match partition_key {
                Some(partition_key) => format!("app:{project_id}/{app_id}/{partition_key}"),
                None => format!("app:{project_id}/{app_id}"),
            },
        })
    }

    async fn indexing_jobs(
        &self,
        offset: usize,
        limit: usize,
        filter_empty: bool,
    ) -> Result<Vec<IndexingJob>, BackendError> {
        self.queries
            .lock()
            .expect("queries mutex should lock")
            .push((offset, limit, filter_empty));

        let jobs = vec![
            IndexingJob {
                id: 1,
                start_time: "2026-03-20T00:00:00.000000000Z".to_string(),
                end_time: None,
                status: "running".to_string(),
                records_processed: 0,
                metadata: serde_json::from_value(json!({
                    "project": "proj-empty",
                }))
                .expect("metadata should deserialize"),
            },
            IndexingJob {
                id: 2,
                start_time: "2026-03-20T00:01:00.000000000Z".to_string(),
                end_time: Some("2026-03-20T00:02:00.000000000Z".to_string()),
                status: "completed".to_string(),
                records_processed: 7,
                metadata: serde_json::from_value(json!({
                    "project": "proj1",
                }))
                .expect("metadata should deserialize"),
            },
        ];

        Ok(jobs
            .into_iter()
            .filter(|job| !filter_empty || job.records_processed > 0)
            .skip(offset)
            .take(limit)
            .collect())
    }
}

#[tokio::test]
async fn indexing_jobs_route_returns_backend_jobs_when_supported() {
    let backend = Arc::new(IndexingBackendStub::default());
    let app = rurr_tracking_server::app_with_state(AppState::with_embedded_ui(backend.clone()));

    let app_spec = app
        .clone()
        .oneshot(
            Request::builder()
                .uri("/api/v0/metadata/app_spec")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("app spec request should succeed");
    assert_eq!(app_spec.status(), StatusCode::OK);
    let app_spec_payload = response_json(app_spec).await;
    assert_eq!(app_spec_payload["indexing"], json!(true));
    assert_eq!(app_spec_payload["supports_annotations"], json!(false));

    let response = app
        .oneshot(
            Request::builder()
                .uri("/api/v0/indexing_jobs?offset=1&limit=5000&filter_empty=false")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("indexing jobs request should succeed");
    assert_eq!(response.status(), StatusCode::OK);
    let payload = response_json(response).await;
    assert_eq!(payload.as_array().map(Vec::len), Some(1));
    assert_eq!(payload[0]["id"], json!(2));
    assert_eq!(payload[0]["metadata"]["project"], json!("proj1"));
    assert_eq!(
        backend
            .queries
            .lock()
            .expect("queries mutex should lock")
            .as_slice(),
        &[(1, 5000, false)]
    );
}

#[tokio::test]
async fn indexing_jobs_route_returns_json_404_when_backend_does_not_support_indexing() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    build_fixture(tempdir.path());
    let app = rurr_tracking_server::app_with_state(AppState::with_embedded_ui(Arc::new(
        LocalBackend::new(tempdir.path()).expect("local backend should build"),
    )));

    let response = app
        .oneshot(
            Request::builder()
                .uri("/api/v0/indexing_jobs")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("indexing jobs request should succeed");

    assert_eq!(response.status(), StatusCode::NOT_FOUND);
    let payload = response_json(response).await;
    assert!(
        payload["error"]
            .as_str()
            .is_some_and(|value| value.contains("indexing")),
        "unsupported indexing route should return a descriptive json error"
    );
}
