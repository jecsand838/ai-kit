use crate::test_support::NonNegativeCountTypingSystem;
use futures::{stream, StreamExt};
use indexmap::IndexMap;
use rurr_core::action::{
    ActionContext, ActionError, ActionInputs, ActionKind, ActionResult, ActionTracer,
    FunctionActionBuilder, InputAction, LocalAction, ResultAction,
};
use rurr_core::graph::GraphAction;
use rurr_core::state::{State, StateError};
use serde_json::{json, Value};
use std::cell::Cell;
use std::rc::Rc;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

use super::support::pairs::{inputs_from_pairs, map_from_pairs, state_from_pairs};

#[derive(Debug, Clone)]
struct BasicTestAction {
    name: Option<String>,
    run_count: Arc<AtomicUsize>,
    reads: Vec<String>,
    writes: Vec<String>,
    inputs: Vec<String>,
    optional_inputs: Vec<String>,
    tags: Vec<String>,
}

impl BasicTestAction {
    fn new(run_count: Arc<AtomicUsize>) -> Self {
        Self {
            name: None,
            run_count,
            reads: vec!["input_variable".to_string()],
            writes: vec!["output_variable".to_string()],
            inputs: vec!["foo".to_string()],
            optional_inputs: vec!["bar".to_string()],
            tags: vec!["tag1".to_string(), "tag2".to_string()],
        }
    }
}

impl LocalAction for BasicTestAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &self.reads
    }

    fn writes(&self) -> &[String] {
        &self.writes
    }

    fn inputs(&self) -> &[String] {
        &self.inputs
    }

    fn optional_inputs(&self) -> &[String] {
        &self.optional_inputs
    }

    fn tags(&self) -> &[String] {
        &self.tags
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }
        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        self.run_count.fetch_add(1, Ordering::SeqCst);
        Ok(ActionResult::new(
            IndexMap::from([("output_variable".to_string(), json!("value"))]),
            IndexMap::from([("output_variable".to_string(), json!("value"))]),
        ))
    }
}

#[derive(Debug, Clone)]
struct AsyncKindAction;

impl LocalAction for AsyncKindAction {
    fn name(&self) -> Option<&str> {
        Some("async_kind_action")
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn inputs(&self) -> &[String] {
        &[]
    }

    fn optional_inputs(&self) -> &[String] {
        &[]
    }

    fn tags(&self) -> &[String] {
        &[]
    }

    fn kind(&self) -> ActionKind {
        ActionKind::Async
    }

    fn with_name(&self, _name: impl Into<String>) -> Result<Self, ActionError> {
        Ok(self.clone())
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
    }
}

#[derive(Debug, Clone)]
struct LocalFutureAction;

impl LocalAction for LocalFutureAction {
    fn name(&self) -> Option<&str> {
        Some("local_future")
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn with_name(&self, _name: impl Into<String>) -> Result<Self, ActionError> {
        Ok(self.clone())
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Err(ActionError::AsyncActionRequiresRunAsync)
    }

    async fn run_async(
        &self,
        _state: &State,
        _ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        let local = Rc::new(Cell::new(40));
        tokio::task::yield_now().await;
        local.set(local.get() + 2);
        let result = IndexMap::from([("answer".to_string(), json!(local.get()))]);
        Ok(ActionResult::new(result.clone(), result))
    }
}

#[test]
fn with_name_returns_renamed_copy_and_preserves_metadata() {
    let run_count = Arc::new(AtomicUsize::new(0));
    let action = BasicTestAction::new(run_count);
    assert_eq!(action.name(), None);

    let renamed = action
        .with_name("my_action")
        .expect("with_name should return renamed action");

    assert_eq!(renamed.name(), Some("my_action"));
    assert_eq!(renamed.reads(), action.reads());
    assert_eq!(renamed.writes(), action.writes());
    assert_eq!(renamed.inputs(), action.inputs());
    assert_eq!(renamed.optional_inputs(), action.optional_inputs());
    assert_eq!(renamed.tags(), action.tags());
    assert_eq!(action.name(), None, "original action should remain unnamed");
}

#[test]
fn with_name_on_already_named_action_returns_error() {
    let run_count = Arc::new(AtomicUsize::new(0));
    let action = BasicTestAction::new(run_count);
    let named = action
        .with_name("first_name")
        .expect("first with_name should succeed");

    let error = named
        .with_name("second_name")
        .expect_err("renaming already named action should fail");

    assert_eq!(
        error,
        ActionError::NameAlreadySet {
            current_name: "first_name".to_string(),
            attempted_name: "second_name".to_string(),
        }
    );
}

#[test]
fn action_kind_is_sync_by_default_and_async_when_overridden() {
    let run_count = Arc::new(AtomicUsize::new(0));
    let sync_action = BasicTestAction::new(run_count);
    let async_action = AsyncKindAction;

    assert_eq!(sync_action.kind(), ActionKind::Sync);
    assert!(!sync_action.is_async());
    assert_eq!(async_action.kind(), ActionKind::Async);
    assert!(async_action.is_async());
}

#[tokio::test]
async fn function_action_dual_handlers_preserve_preferred_kind_and_lane_dispatch() {
    fn result(value: &'static str) -> ActionResult {
        let result = map_from_pairs([("lane", json!(value))]);
        ActionResult::new(result.clone(), result)
    }

    let action = FunctionActionBuilder::new()
        .writes(["lane"])
        .build_dual_action_result(
            |_state, _ctx| Ok(result("sync")),
            |_state, _ctx| async { Ok(result("async")) },
            ActionKind::Async,
        )
        .expect("dual handler action should build");
    let state = State::default();
    let ctx = ActionContext::default();
    let sync_result = action.run(&state, &ctx).expect("sync lane");
    let async_result = action.run_async(&state, &ctx).await.expect("async lane");

    assert_eq!(action.kind(), ActionKind::Async);
    assert_eq!(sync_result.result()["lane"], json!("sync"));
    assert_eq!(async_result.result()["lane"], json!("async"));
}

#[tokio::test]
async fn graph_action_erased_dispatch_accepts_local_non_send_run_async_future() {
    let graph_action = GraphAction::new(LocalFutureAction).expect("graph action should build");
    let result = graph_action
        .action()
        .run_async_erased(&State::default(), &ActionContext::default())
        .await
        .expect("erased local action should run");

    assert_eq!(result.result().get("answer"), Some(&json!(42)));
    assert_eq!(result.writes().get("answer"), Some(&json!(42)));
}

#[tokio::test]
async fn function_action_builder_sync_streaming_supports_stream_and_terminal_run() {
    let polls = Arc::new(AtomicUsize::new(0));
    let action = FunctionActionBuilder::new()
        .writes(["response"])
        .optional_inputs(["prompt"])
        .build_streaming_sync({
            let polls = Arc::clone(&polls);
            move |state, ctx| {
                let prompt = ctx
                    .inputs
                    .get("prompt")
                    .and_then(Value::as_str)
                    .or_else(|| state.get("prompt").and_then(Value::as_str))
                    .unwrap_or("say alpha beta gamma");
                let chunks = if prompt.contains("gamma") {
                    vec!["ALPHA ", "BETA ", "GAMMA"]
                } else {
                    vec!["ALPHA "]
                };
                let total = chunks.len();
                let mut buffer = String::new();
                let polls = Arc::clone(&polls);

                chunks.into_iter().enumerate().map(move |(index, chunk)| {
                    polls.fetch_add(1, Ordering::SeqCst);
                    buffer.push_str(chunk);
                    let item = map_from_pairs([(
                        "response",
                        json!(if index + 1 == total {
                            buffer.clone()
                        } else {
                            chunk.to_string()
                        }),
                    )]);
                    let terminal_state = if index + 1 == total {
                        Some(
                            state
                                .update(map_from_pairs([("response", json!(buffer.clone()))]))
                                .expect("terminal state update should succeed"),
                        )
                    } else {
                        None
                    };
                    Ok((item, terminal_state))
                })
            }
        })
        .expect("sync streaming action should build");

    let state = state_from_pairs([("prompt", json!("say alpha beta gamma"))]);
    let ctx = ActionContext::default();

    let mut stream = action.stream_run(state.clone(), ctx.clone());
    assert_eq!(
        polls.load(Ordering::SeqCst),
        0,
        "stream creation must stay lazy"
    );

    let first = stream
        .next()
        .expect("first item should exist")
        .expect("first item should be ok");
    assert_eq!(first.0.get("response"), Some(&json!("ALPHA ")));
    assert!(
        first.1.is_none(),
        "intermediate item should not commit state"
    );

    let second = stream
        .next()
        .expect("second item should exist")
        .expect("second item should be ok");
    assert_eq!(second.0.get("response"), Some(&json!("BETA ")));
    assert!(
        second.1.is_none(),
        "second intermediate item should not commit state"
    );

    let terminal = stream
        .next()
        .expect("terminal item should exist")
        .expect("terminal item should be ok");
    assert_eq!(terminal.0.get("response"), Some(&json!("ALPHA BETA GAMMA")));
    assert_eq!(
        terminal
            .1
            .as_ref()
            .and_then(|state| state.get("response"))
            .cloned(),
        Some(json!("ALPHA BETA GAMMA"))
    );

    let run_result = action
        .run(&state, &ctx)
        .expect("run should exhaust streaming action to the terminal result");
    assert_eq!(
        run_result.result().get("response"),
        Some(&json!("ALPHA BETA GAMMA"))
    );
    assert_eq!(
        run_result.writes().get("response"),
        Some(&json!("ALPHA BETA GAMMA"))
    );

    let async_run_result = action
        .run_async(&state, &ctx)
        .await
        .expect("run_async should also exhaust sync streaming actions to the terminal result");
    assert_eq!(async_run_result.result(), run_result.result());
    assert_eq!(async_run_result.writes(), run_result.writes());
}

#[tokio::test]
async fn function_action_builder_async_streaming_supports_stream_and_terminal_run() {
    let polls = Arc::new(AtomicUsize::new(0));
    let action = FunctionActionBuilder::new()
        .writes(["response"])
        .optional_inputs(["prompt"])
        .build_streaming_async({
            let polls = Arc::clone(&polls);
            move |state, ctx| {
                let prompt = ctx
                    .inputs
                    .get("prompt")
                    .and_then(Value::as_str)
                    .or_else(|| state.get("prompt").and_then(Value::as_str))
                    .unwrap_or("say alpha beta gamma");
                let chunks = if prompt.contains("gamma") {
                    vec!["ALPHA ", "BETA ", "GAMMA"]
                } else {
                    vec!["ALPHA "]
                };
                let total = chunks.len();
                let mut buffer = String::new();
                let polls = Arc::clone(&polls);

                stream::iter(chunks.into_iter().enumerate().map(move |(index, chunk)| {
                    polls.fetch_add(1, Ordering::SeqCst);
                    buffer.push_str(chunk);
                    let item = map_from_pairs([(
                        "response",
                        json!(if index + 1 == total {
                            buffer.clone()
                        } else {
                            chunk.to_string()
                        }),
                    )]);
                    let terminal_state = if index + 1 == total {
                        Some(
                            state
                                .update(map_from_pairs([("response", json!(buffer.clone()))]))
                                .expect("terminal state update should succeed"),
                        )
                    } else {
                        None
                    };
                    Ok((item, terminal_state))
                }))
            }
        })
        .expect("async streaming action should build");

    let state = state_from_pairs([("prompt", json!("say alpha beta gamma"))]);
    let ctx = ActionContext::default();

    let mut stream = action.stream_run_async(state.clone(), ctx.clone());
    assert_eq!(
        polls.load(Ordering::SeqCst),
        0,
        "stream creation must stay lazy"
    );

    let first = stream
        .next()
        .await
        .expect("first item should exist")
        .expect("first item should be ok");
    assert_eq!(first.0.get("response"), Some(&json!("ALPHA ")));
    assert!(
        first.1.is_none(),
        "intermediate item should not commit state"
    );

    let second = stream
        .next()
        .await
        .expect("second item should exist")
        .expect("second item should be ok");
    assert_eq!(second.0.get("response"), Some(&json!("BETA ")));
    assert!(
        second.1.is_none(),
        "second intermediate item should not commit state"
    );

    let terminal = stream
        .next()
        .await
        .expect("terminal item should exist")
        .expect("terminal item should be ok");
    assert_eq!(terminal.0.get("response"), Some(&json!("ALPHA BETA GAMMA")));
    assert_eq!(
        terminal
            .1
            .as_ref()
            .and_then(|state| state.get("response"))
            .cloned(),
        Some(json!("ALPHA BETA GAMMA"))
    );

    let run_result = action
        .run_async(&state, &ctx)
        .await
        .expect("run_async should exhaust streaming action to the terminal result");
    assert_eq!(
        run_result.result().get("response"),
        Some(&json!("ALPHA BETA GAMMA"))
    );
    assert_eq!(
        run_result.writes().get("response"),
        Some(&json!("ALPHA BETA GAMMA"))
    );
}

#[tokio::test]
async fn function_action_one_shot_sync_and_async_handlers_preserve_parity() {
    fn compute_result(state: &State, ctx: &ActionContext) -> IndexMap<String, Value> {
        let base = state
            .get("base")
            .and_then(Value::as_i64)
            .expect("state should contain base");
        let multiplier = ctx
            .inputs
            .get("multiplier")
            .and_then(Value::as_i64)
            .expect("resolved inputs should contain multiplier");
        let offset = ctx
            .inputs
            .get("offset")
            .and_then(Value::as_i64)
            .expect("resolved inputs should contain offset");

        IndexMap::from([
            ("multiplier_seen".to_string(), json!(multiplier)),
            ("total".to_string(), json!(base * multiplier + offset)),
            ("ephemeral".to_string(), json!("result-only")),
        ])
    }

    let builder = FunctionActionBuilder::new()
        .writes(["total", "multiplier_seen"])
        .optional_inputs(["offset"])
        .bind([("multiplier", json!(3))])
        .defaults([("offset", json!(1))]);
    let sync_action = builder
        .clone()
        .build_sync(compute_result)
        .expect("sync function action should build");
    let async_action = builder
        .build_async(|state, ctx| async move { compute_result(&state, &ctx) })
        .expect("async function action should build");

    let state = state_from_pairs([("base", json!(4))]);
    let ctx = ActionContext::new(
        inputs_from_pairs([("offset", json!(5))]),
        ActionTracer::default(),
        None,
    );

    let sync_result = sync_action
        .run(&state, &ctx)
        .expect("sync one-shot action should run");
    let async_result = async_action
        .run_async(&state, &ctx)
        .await
        .expect("async one-shot action should run");

    assert_eq!(sync_result.result(), async_result.result());
    assert_eq!(sync_result.writes(), async_result.writes());
    assert_eq!(
        sync_result.result(),
        &IndexMap::from([
            ("multiplier_seen".to_string(), json!(3)),
            ("total".to_string(), json!(17)),
            ("ephemeral".to_string(), json!("result-only")),
        ])
    );
    assert_eq!(
        sync_result.writes(),
        &IndexMap::from([
            ("total".to_string(), json!(17)),
            ("multiplier_seen".to_string(), json!(3)),
        ])
    );
}

#[tokio::test]
async fn function_action_streaming_sync_and_async_handlers_preserve_parity() {
    fn stream_items(state: State, ctx: ActionContext) -> Vec<rurr_core::action::StreamOutput> {
        let prefix = ctx
            .inputs
            .get("prefix")
            .and_then(Value::as_str)
            .expect("resolved inputs should contain prefix")
            .to_string();
        let first = format!("{prefix} ");
        let final_response = format!("{first}world");

        vec![
            Ok((map_from_pairs([("response", json!(first))]), None)),
            Ok((
                map_from_pairs([("response", json!(final_response.clone()))]),
                Some(
                    state
                        .update(map_from_pairs([("response", json!(final_response))]))
                        .expect("terminal state update should succeed"),
                ),
            )),
        ]
    }

    let builder = FunctionActionBuilder::new()
        .writes(["response"])
        .optional_inputs(["prefix"])
        .defaults([("prefix", json!("hello"))]);
    let sync_action = builder
        .clone()
        .build_streaming_sync(|state, ctx| stream_items(state, ctx).into_iter())
        .expect("sync streaming action should build");
    let async_action = builder
        .build_streaming_async(|state, ctx| stream::iter(stream_items(state, ctx)))
        .expect("async streaming action should build");

    let state = State::default();
    let ctx = ActionContext::default();

    let sync_items = sync_action
        .stream_run(state.clone(), ctx.clone())
        .collect::<Vec<_>>();
    let async_items = async_action
        .stream_run_async(state.clone(), ctx.clone())
        .collect::<Vec<_>>()
        .await;

    assert_eq!(sync_items, async_items);

    let sync_result = sync_action
        .run(&state, &ctx)
        .expect("sync streaming run should exhaust to terminal result");
    let async_result = async_action
        .run_async(&state, &ctx)
        .await
        .expect("async streaming run should exhaust to terminal result");

    assert_eq!(sync_result.result(), async_result.result());
    assert_eq!(sync_result.writes(), async_result.writes());
    assert_eq!(
        sync_result.result().get("response"),
        Some(&json!("hello world"))
    );
}

#[test]
fn function_action_sync_entrypoints_on_async_streaming_require_run_async() {
    let action = FunctionActionBuilder::new()
        .inputs(["required_input"])
        .build_streaming_async(|_state, _ctx| {
            stream::iter(std::iter::once(Ok((
                map_from_pairs([("response", json!("terminal"))]),
                Some(State::new(map_from_pairs([(
                    "response",
                    json!("terminal"),
                )]))),
            ))))
        })
        .expect("async streaming action should build");

    let run_error = action
        .run(&State::default(), &ActionContext::default())
        .expect_err("sync run should reject async streaming handlers");
    assert_eq!(run_error, ActionError::AsyncActionRequiresRunAsync);

    let stream_error = action
        .stream_run(State::default(), ActionContext::default())
        .next()
        .expect("sync stream should yield an explicit async-entrypoint error")
        .expect_err("sync stream should not execute async streaming handlers");
    assert_eq!(
        stream_error,
        rurr_core::action::RurrError::Action(ActionError::AsyncActionRequiresRunAsync)
    );
}

#[test]
fn function_action_builder_sync_streaming_requires_terminal_state() {
    let action = FunctionActionBuilder::new()
        .writes(["response"])
        .build_streaming_sync(|_state, _ctx| {
            std::iter::once(Ok((map_from_pairs([("response", json!("ALPHA "))]), None)))
        })
        .expect("sync streaming action should build");

    let error = action
        .run(&State::default(), &ActionContext::default())
        .expect_err("run should fail when the stream never yields a terminal state");
    assert_eq!(
        error,
        ActionError::Internal {
            message: "function streaming action exhausted without yielding a terminal state"
                .to_string(),
        }
    );
}

#[tokio::test]
async fn run_async_default_delegates_to_run() {
    let run_count = Arc::new(AtomicUsize::new(0));
    let action = BasicTestAction::new(Arc::clone(&run_count));
    let state = state_from_pairs([("input_variable", json!("in"))]);

    let result = action
        .run_async(&state, &ActionContext::default())
        .await
        .expect("run_async should succeed for sync action");

    assert_eq!(
        result.result(),
        &IndexMap::from([("output_variable".to_string(), json!("value"))])
    );
    assert_eq!(run_count.load(Ordering::SeqCst), 1);
}

#[test]
fn default_update_merges_result_writes_into_state() {
    let run_count = Arc::new(AtomicUsize::new(0));
    let action = BasicTestAction::new(run_count);
    let state = state_from_pairs([("existing", json!(1)), ("output_variable", json!("old"))]);
    let result = ActionResult::new(
        IndexMap::from([("result_only".to_string(), json!(true))]),
        IndexMap::from([("output_variable".to_string(), json!("new"))]),
    );

    let updated = action
        .update(&result, &state, &ActionContext::default())
        .expect("default update should succeed");

    assert_eq!(
        updated.get_all(),
        IndexMap::from([
            ("existing".to_string(), json!(1)),
            ("output_variable".to_string(), json!("new")),
        ])
    );
}

#[test]
fn default_update_surfaces_state_typing_failures() {
    let run_count = Arc::new(AtomicUsize::new(0));
    let action = BasicTestAction::new(run_count);
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(NonNegativeCountTypingSystem::default()))
        .expect("typing system should attach");
    let result = ActionResult::new(
        IndexMap::new(),
        IndexMap::from([("count".to_string(), json!(-1))]),
    );

    let error = action
        .update(&result, &state, &ActionContext::default())
        .expect_err("default update should surface typing errors");

    match error {
        ActionError::State(StateError::TypingSystem { phase, message }) => {
            assert_eq!(phase, "validate_post_action");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected action state error, got {other:?}"),
    }
}

#[test]
fn input_action_reads_runtime_inputs_and_updates_state() {
    let action = InputAction::new(["foo", "bar"]);
    let state = State::default();
    let inputs = inputs_from_pairs([("foo", json!("baz")), ("bar", json!("qux"))]);

    assert_eq!(action.reads(), &Vec::<String>::new());
    assert_eq!(action.writes(), &vec!["foo".to_string(), "bar".to_string()]);
    assert_eq!(action.inputs(), &vec!["foo".to_string(), "bar".to_string()]);
    assert_eq!(action.optional_inputs(), &Vec::<String>::new());

    let result = action
        .run(
            &state,
            &ActionContext::new(inputs.clone(), ActionTracer::default(), None),
        )
        .expect("input action run should succeed");

    assert_eq!(
        result.result(),
        &IndexMap::from([
            ("foo".to_string(), json!("baz")),
            ("bar".to_string(), json!("qux")),
        ])
    );
    assert_eq!(
        result.writes(),
        &IndexMap::from([
            ("foo".to_string(), json!("baz")),
            ("bar".to_string(), json!("qux")),
        ])
    );

    let updated = action
        .update(&result, &state, &ActionContext::default())
        .expect("default update should merge writes");
    assert_eq!(
        updated.get_all(),
        IndexMap::from([
            ("foo".to_string(), json!("baz")),
            ("bar".to_string(), json!("qux")),
        ])
    );
}

#[test]
fn input_action_missing_required_input_returns_error() {
    let action = InputAction::new(["foo", "bar"]);
    let state = State::default();
    let inputs = inputs_from_pairs([("foo", json!("baz"))]);

    let error = action
        .run(
            &state,
            &ActionContext::new(inputs.clone(), ActionTracer::default(), None),
        )
        .expect_err("missing required input should fail");

    assert_eq!(
        error,
        ActionError::MissingInput {
            key: "bar".to_string()
        }
    );
}

#[test]
fn input_action_preserves_declared_field_order_in_result_and_writes() {
    let action = InputAction::new(["first", "second"]);
    let state = State::default();
    let mut inputs = ActionInputs::new();
    inputs.insert("second".to_string(), json!("b"));
    inputs.insert("first".to_string(), json!("a"));

    let result = action
        .run(
            &state,
            &ActionContext::new(inputs.clone(), ActionTracer::default(), None),
        )
        .expect("input action run should succeed");

    assert_eq!(
        result.result().keys().cloned().collect::<Vec<_>>(),
        vec!["first".to_string(), "second".to_string()]
    );
    assert_eq!(
        result.writes().keys().cloned().collect::<Vec<_>>(),
        vec!["first".to_string(), "second".to_string()]
    );
}

#[test]
fn result_action_reads_state_into_result_without_mutating_state() {
    let action = ResultAction::new(["foo", "bar"]);
    let state = state_from_pairs([
        ("foo", json!("baz")),
        ("bar", json!("qux")),
        ("quux", json!(1)),
    ]);

    assert_eq!(action.reads(), &vec!["foo".to_string(), "bar".to_string()]);
    assert_eq!(action.writes(), &Vec::<String>::new());
    assert_eq!(action.inputs(), &Vec::<String>::new());
    assert_eq!(action.optional_inputs(), &Vec::<String>::new());

    let result = action
        .run(&state, &ActionContext::default())
        .expect("result action run should succeed");

    assert_eq!(
        result.result(),
        &IndexMap::from([
            ("foo".to_string(), json!("baz")),
            ("bar".to_string(), json!("qux")),
        ])
    );
    assert!(result.writes().is_empty());

    let updated = action
        .update(&result, &state, &ActionContext::default())
        .expect("result action update should be no-op");
    assert_eq!(updated, state);
}

#[test]
fn result_action_preserves_state_iteration_order_not_requested_field_order() {
    let action = ResultAction::new(["bar", "foo"]);
    let state = state_from_pairs([
        ("foo", json!("foo-value")),
        ("bar", json!("bar-value")),
        ("baz", json!("baz-value")),
    ]);

    let result = action
        .run(&state, &ActionContext::default())
        .expect("result action run should succeed");

    assert_eq!(
        result.result().keys().cloned().collect::<Vec<_>>(),
        vec!["foo".to_string(), "bar".to_string()]
    );
    assert_eq!(
        result.result(),
        &IndexMap::from([
            ("foo".to_string(), json!("foo-value")),
            ("bar".to_string(), json!("bar-value")),
        ])
    );
}

#[test]
fn result_action_omits_missing_requested_keys() {
    let action = ResultAction::new(["foo", "missing"]);
    let state = state_from_pairs([("foo", json!("baz")), ("bar", json!("qux"))]);

    let result = action
        .run(&state, &ActionContext::default())
        .expect("result action run should succeed");

    assert_eq!(
        result.result(),
        &IndexMap::from([("foo".to_string(), json!("baz"))])
    );
    assert!(result.writes().is_empty());
}

#[test]
fn function_action_writes_preserve_declared_order_and_omit_missing_keys() {
    let action = FunctionActionBuilder::new()
        .writes(["beta", "alpha", "missing"])
        .build_sync(|_state, _ctx| {
            IndexMap::from([
                ("alpha".to_string(), json!(1)),
                ("extra".to_string(), json!(2)),
                ("beta".to_string(), json!(3)),
            ])
        })
        .expect("function action builder should succeed");

    let result = action
        .run(&State::default(), &ActionContext::default())
        .expect("function action should run successfully");

    assert_eq!(
        result.writes(),
        &IndexMap::from([
            ("beta".to_string(), json!(3)),
            ("alpha".to_string(), json!(1)),
        ])
    );
}

#[test]
fn function_action_returns_dict_result() {
    let action = FunctionActionBuilder::new()
        .reads(["input_variable"])
        .writes(["output_variable"])
        .tags(["tag1", "tag2"])
        .inputs(["multiplier"])
        .optional_inputs(["offset"])
        .defaults([("offset", json!(1))])
        .build_sync(|state, ctx| {
            let input_value = state
                .get("input_variable")
                .and_then(Value::as_i64)
                .expect("state should contain integer input_variable");
            let multiplier = ctx
                .inputs
                .get("multiplier")
                .and_then(Value::as_i64)
                .expect("resolved inputs should contain multiplier");
            let offset = ctx
                .inputs
                .get("offset")
                .and_then(Value::as_i64)
                .expect("resolved inputs should contain offset");
            let output_value = input_value * multiplier + offset;
            IndexMap::from([
                ("output_variable".to_string(), json!(output_value)),
                ("result_only".to_string(), json!("ephemeral")),
            ])
        })
        .expect("function action builder should accept optional defaults");

    assert_eq!(action.reads(), &vec!["input_variable".to_string()]);
    assert_eq!(action.writes(), &vec!["output_variable".to_string()]);
    assert_eq!(action.tags(), &vec!["tag1".to_string(), "tag2".to_string()]);
    assert_eq!(action.inputs(), &vec!["multiplier".to_string()]);
    assert_eq!(action.optional_inputs(), &vec!["offset".to_string()]);

    let state = state_from_pairs([("input_variable", json!(5))]);
    let result = action
        .run(
            &state,
            &ActionContext::new(
                inputs_from_pairs([("multiplier", json!(4))]),
                ActionTracer::default(),
                None,
            ),
        )
        .expect("function action should run successfully");

    assert_eq!(
        result.result(),
        &IndexMap::from([
            ("output_variable".to_string(), json!(21)),
            ("result_only".to_string(), json!("ephemeral")),
        ])
    );
    assert_eq!(
        result.writes(),
        &IndexMap::from([("output_variable".to_string(), json!(21))])
    );
}

#[test]
fn function_action_enforces_required_inputs() {
    let action = FunctionActionBuilder::new()
        .inputs(["required_input"])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("function action builder should succeed");

    let error = action
        .run(&State::default(), &ActionContext::default())
        .expect_err("missing required input should fail");

    assert_eq!(
        error,
        ActionError::MissingInput {
            key: "required_input".to_string(),
        }
    );
}

#[test]
fn function_action_applies_optional_defaults() {
    let action = FunctionActionBuilder::new()
        .inputs(["required_input"])
        .optional_inputs(["optional_input"])
        .defaults([("optional_input", json!(100))])
        .build_sync(|_state, ctx| {
            let required = ctx
                .inputs
                .get("required_input")
                .and_then(Value::as_i64)
                .expect("resolved inputs should include required_input");
            let optional = ctx
                .inputs
                .get("optional_input")
                .and_then(Value::as_i64)
                .expect("resolved inputs should include optional_input from defaults");
            IndexMap::from([("sum".to_string(), json!(required + optional))])
        })
        .expect("function action builder should allow optional defaults");

    let result = action
        .run(
            &State::default(),
            &ActionContext::new(
                inputs_from_pairs([("required_input", json!(11))]),
                ActionTracer::default(),
                None,
            ),
        )
        .expect("function action should apply default optional inputs");

    assert_eq!(
        result.result(),
        &IndexMap::from([("sum".to_string(), json!(111))])
    );
}

#[test]
fn function_action_bind_chain_merges_last_write_wins() {
    let action = FunctionActionBuilder::new()
        .inputs(["bound_input"])
        .bind([("bound_input", json!(10))])
        .bind([("bound_input", json!(20))])
        .build_sync(|_state, ctx| {
            IndexMap::from([(
                "bound_input".to_string(),
                ctx.inputs
                    .get("bound_input")
                    .cloned()
                    .expect("bound input should be present"),
            )])
        })
        .expect("function action builder should succeed for valid bind inputs");

    let result = action
        .run(&State::default(), &ActionContext::default())
        .expect("bound input should satisfy required key");

    assert_eq!(
        result.result(),
        &IndexMap::from([("bound_input".to_string(), json!(20))])
    );
}

#[test]
fn function_action_rejects_runtime_override_of_bound_input_sync() {
    let action = FunctionActionBuilder::new()
        .inputs(["bound_input"])
        .bind([("bound_input", json!(10))])
        .build_sync(|_state, ctx| {
            IndexMap::from([(
                "bound_input".to_string(),
                ctx.inputs
                    .get("bound_input")
                    .cloned()
                    .expect("bound input should be present"),
            )])
        })
        .expect("function action builder should succeed for valid bind inputs");

    let error = action
        .run(
            &State::default(),
            &ActionContext::new(
                inputs_from_pairs([("bound_input", json!(99))]),
                ActionTracer::default(),
                None,
            ),
        )
        .expect_err("runtime input must not override builder-bound input");

    assert_eq!(
        error,
        ActionError::BoundInputOverride {
            key: "bound_input".to_string(),
        }
    );
}

#[tokio::test]
async fn function_action_rejects_runtime_override_of_bound_input_async() {
    let action = FunctionActionBuilder::new()
        .inputs(["bound_input"])
        .bind([("bound_input", json!(10))])
        .build_async(|_state, ctx| async move {
            IndexMap::from([(
                "bound_input".to_string(),
                ctx.inputs
                    .get("bound_input")
                    .cloned()
                    .expect("bound input should be present"),
            )])
        })
        .expect("function action builder should succeed for async handler");

    let error = action
        .run_async(
            &State::default(),
            &ActionContext::new(
                inputs_from_pairs([("bound_input", json!(99))]),
                ActionTracer::default(),
                None,
            ),
        )
        .await
        .expect_err("runtime input must not override builder-bound input");

    assert_eq!(
        error,
        ActionError::BoundInputOverride {
            key: "bound_input".to_string(),
        }
    );
}

#[test]
fn function_action_sync_run_on_async_handler_returns_async_error_even_when_inputs_missing() {
    let action = FunctionActionBuilder::new()
        .inputs(["required_input"])
        .build_async(|_state, _ctx| async move { IndexMap::new() })
        .expect("function action builder should succeed for async handler");

    let error = action
        .run(&State::default(), &ActionContext::default())
        .expect_err(
            "sync run of async function action should always fail with async-specific error",
        );

    assert_eq!(error, ActionError::AsyncActionRequiresRunAsync);
}

#[tokio::test]
async fn function_action_sync_run_on_async_handler_returns_explicit_error() {
    let action = FunctionActionBuilder::new()
        .writes(["output_variable"])
        .inputs(["addend"])
        .build_async(|state, ctx| async move {
            let base = state
                .get("base")
                .and_then(Value::as_i64)
                .expect("state should contain base");
            let addend = ctx
                .inputs
                .get("addend")
                .and_then(Value::as_i64)
                .expect("inputs should contain addend");
            IndexMap::from([("output_variable".to_string(), json!(base + addend))])
        })
        .expect("function action builder should succeed for async handler");

    let state = state_from_pairs([("base", json!(2))]);
    let inputs = inputs_from_pairs([("addend", json!(3))]);

    let sync_error = action
        .run(
            &state,
            &ActionContext::new(inputs.clone(), ActionTracer::default(), None),
        )
        .expect_err("sync run of async function action should fail explicitly");
    assert_eq!(sync_error, ActionError::AsyncActionRequiresRunAsync);

    let async_result = action
        .run_async(
            &state,
            &ActionContext::new(inputs.clone(), ActionTracer::default(), None),
        )
        .await
        .expect("run_async should execute async function action");
    assert_eq!(
        async_result.result(),
        &IndexMap::from([("output_variable".to_string(), json!(5))])
    );
    assert_eq!(
        async_result.writes(),
        &IndexMap::from([("output_variable".to_string(), json!(5))])
    );
}

#[test]
fn function_action_build_rejects_default_for_required_input() {
    let error = FunctionActionBuilder::new()
        .inputs(["required_input"])
        .optional_inputs(["optional_input"])
        .defaults([("required_input", json!(123))])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject defaults for required inputs");

    assert_eq!(
        error,
        ActionError::DefaultInputMustBeOptional {
            key: "required_input".to_string(),
        }
    );
}

#[test]
fn function_action_build_rejects_default_for_non_optional_input() {
    let error = FunctionActionBuilder::new()
        .inputs(["required_input"])
        .optional_inputs(["optional_input"])
        .defaults([("undeclared_default", json!(123))])
        .build_async(|_state, _ctx| async { IndexMap::new() })
        .expect_err("builder should reject defaults not declared as optional inputs");

    assert_eq!(
        error,
        ActionError::DefaultInputMustBeOptional {
            key: "undeclared_default".to_string(),
        }
    );
}

#[test]
fn function_action_build_rejects_reserved_runtime_bind_input() {
    let error = FunctionActionBuilder::new()
        .bind([("__tracer", json!("forged"))])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject reserved runtime bind inputs");

    let message = error.to_string();
    assert!(
        message.contains("__tracer"),
        "error should mention reserved key, got: {message}"
    );
}

#[test]
fn function_action_build_rejects_reserved_runtime_default_input() {
    let error = FunctionActionBuilder::new()
        .optional_inputs(["optional_input"])
        .defaults([("__context", json!("forged"))])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject reserved runtime default inputs");

    let message = error.to_string();
    assert!(
        message.contains("__context"),
        "error should mention reserved key, got: {message}"
    );
}

#[test]
fn function_action_build_rejects_non_injected_reserved_required_input_sync() {
    let error = FunctionActionBuilder::new()
        .inputs(["__foo"])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject non-injected reserved required inputs");

    assert_eq!(
        error,
        ActionError::ReservedRuntimeInputDeclaration {
            key: "__foo".to_string(),
        }
    );
}

#[tokio::test]
async fn function_action_build_rejects_non_injected_reserved_required_input_async() {
    let error = FunctionActionBuilder::new()
        .inputs(["__foo"])
        .build_async(|_state, _ctx| async { IndexMap::new() })
        .expect_err("builder should reject non-injected reserved required inputs");

    assert_eq!(
        error,
        ActionError::ReservedRuntimeInputDeclaration {
            key: "__foo".to_string(),
        }
    );
}

#[test]
fn function_action_build_rejects_non_injected_reserved_optional_input() {
    let error = FunctionActionBuilder::new()
        .optional_inputs(["__foo"])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject non-injected reserved optional inputs");

    assert_eq!(
        error,
        ActionError::ReservedRuntimeInputDeclaration {
            key: "__foo".to_string(),
        }
    );
}

#[test]
fn function_action_build_rejects_context_reserved_optional_input() {
    let error = FunctionActionBuilder::new()
        .optional_inputs(["__context"])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject __context optional inputs");

    assert_eq!(
        error,
        ActionError::ReservedRuntimeInputDeclaration {
            key: "__context".to_string(),
        }
    );
}

#[test]
fn function_action_build_rejects_tracer_reserved_optional_input() {
    let error = FunctionActionBuilder::new()
        .optional_inputs(["__tracer"])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject __tracer optional inputs");

    assert_eq!(
        error,
        ActionError::ReservedRuntimeInputDeclaration {
            key: "__tracer".to_string(),
        }
    );
}

#[test]
fn function_action_build_rejects_reserved_runtime_inputs_declaration() {
    let error = FunctionActionBuilder::new()
        .inputs(["__context"])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject reserved runtime inputs declarations");

    assert_eq!(
        error,
        ActionError::ReservedRuntimeInputDeclaration {
            key: "__context".to_string(),
        }
    );
}
