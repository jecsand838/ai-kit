use super::*;
use super::{actions::non_streaming_count_action, builders::build_resumed_non_streaming_chain_app};
use rurr_core::application::ExecutionOptions;

#[derive(Clone, Copy)]
enum HaltBoundary {
    Before,
    After,
}

async fn assert_resumed_halt_ignores_historical_prior_step(
    mode: StreamMode,
    halt_boundary: HaltBoundary,
) {
    let a_calls = Arc::new(AtomicUsize::new(0));
    let b_calls = Arc::new(AtomicUsize::new(0));
    let mut app = build_resumed_non_streaming_chain_app(
        state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(7)),
        ]),
        vec![
            ("A", non_streaming_count_action(Arc::clone(&a_calls))),
            ("B", non_streaming_count_action(Arc::clone(&b_calls))),
        ],
        vec![Transition::new("A", "B", Condition::default())],
        "A",
    )
    .expect("app should build");

    let halt_before = matches!(halt_boundary, HaltBoundary::Before).then(|| vec!["B".to_string()]);
    let halt_after = matches!(halt_boundary, HaltBoundary::After).then(|| vec!["A".to_string()]);
    let mut options = ExecutionOptions::new();
    if let Some(halt_before) = halt_before {
        options = options.halt_before(halt_before);
    }
    if let Some(halt_after) = halt_after {
        options = options.halt_after(halt_after);
    }
    let mut iterate = mode.stream_iterate(&mut app, options).await;
    let (executed, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("resumed state should still execute current-session next action");
    assert_eq!(executed, "B");
    let (_terminal, state) = handle.get().await.expect("step should complete");
    assert_eq!(state.get("count").cloned(), Some(json!(1)));
    assert_eq!(a_calls.load(Ordering::SeqCst), 0);
    assert_eq!(b_calls.load(Ordering::SeqCst), 1);
}

async fn assert_resumed_halt_stops_after_first_committed_step(
    mode: StreamMode,
    halt_boundary: HaltBoundary,
) {
    let b_calls = Arc::new(AtomicUsize::new(0));
    let c_calls = Arc::new(AtomicUsize::new(0));
    let mut app = build_resumed_non_streaming_chain_app(
        state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(11)),
        ]),
        vec![
            (
                "A",
                non_streaming_count_action(Arc::new(AtomicUsize::new(0))),
            ),
            ("B", non_streaming_count_action(Arc::clone(&b_calls))),
            ("C", non_streaming_count_action(Arc::clone(&c_calls))),
        ],
        vec![
            Transition::new("A", "B", Condition::default()),
            Transition::new("B", "C", Condition::default()),
        ],
        "A",
    )
    .expect("app should build");

    let halt_before = matches!(halt_boundary, HaltBoundary::Before).then(|| vec!["C".to_string()]);
    let halt_after = matches!(halt_boundary, HaltBoundary::After).then(|| vec!["B".to_string()]);
    let mut options = ExecutionOptions::new();
    if let Some(halt_before) = halt_before {
        options = options.halt_before(halt_before);
    }
    if let Some(halt_after) = halt_after {
        options = options.halt_after(halt_after);
    }
    let mut iterate = mode.stream_iterate(&mut app, options).await;
    {
        let (executed, mut handle) = iterate
            .next_step()
            .await
            .expect("next_step should succeed")
            .expect("first step should exist");
        assert_eq!(executed, "B");
        let _ = handle.get().await.expect("first step should complete");
    }
    assert!(
        iterate
            .next_step()
            .await
            .expect("next_step should succeed")
            .is_none(),
        "{} should stop iteration after one committed step",
        match halt_boundary {
            HaltBoundary::Before => "halt_before",
            HaltBoundary::After => "halt_after",
        }
    );
    assert_eq!(b_calls.load(Ordering::SeqCst), 1);
    assert_eq!(c_calls.load(Ordering::SeqCst), 0);
}

sync_stream_cases! {
    stream_iterate_halt_after_ignores_historical_prior_step_on_resumed_app =>
        assert_resumed_halt_ignores_historical_prior_step(StreamMode::Sync, HaltBoundary::After),
    stream_iterate_halt_before_ignores_historical_prior_step_on_resumed_app =>
        assert_resumed_halt_ignores_historical_prior_step(StreamMode::Sync, HaltBoundary::Before),
    stream_iterate_halt_after_stops_after_session_committed_step =>
        assert_resumed_halt_stops_after_first_committed_step(StreamMode::Sync, HaltBoundary::After),
    stream_iterate_halt_before_stops_on_next_matching_action_after_first_commit =>
        assert_resumed_halt_stops_after_first_committed_step(StreamMode::Sync, HaltBoundary::Before)
}
async_stream_cases! {
    astream_iterate_halt_after_ignores_historical_prior_step_on_resumed_app =>
        assert_resumed_halt_ignores_historical_prior_step(StreamMode::Async, HaltBoundary::After),
    astream_iterate_halt_before_ignores_historical_prior_step_on_resumed_app =>
        assert_resumed_halt_ignores_historical_prior_step(StreamMode::Async, HaltBoundary::Before),
    astream_iterate_halt_after_stops_after_session_committed_step =>
        assert_resumed_halt_stops_after_first_committed_step(StreamMode::Async, HaltBoundary::After),
    astream_iterate_halt_before_stops_on_next_matching_action_after_first_commit =>
        assert_resumed_halt_stops_after_first_committed_step(StreamMode::Async, HaltBoundary::Before)
}
