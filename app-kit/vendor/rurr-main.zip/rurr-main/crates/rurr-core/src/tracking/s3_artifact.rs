//! Shared Burr-compatible S3 tracking artifact contracts.

use super::s3_layout::{S3Prefix, S3TrackingObjectKey, S3TrackingObjectKind};
use super::s3_metadata::{self, S3MetadataError};
use super::{ApplicationMetadataModel, ApplicationModel, ChildApplicationModel, PointerModel};
use crate::application::context::ParentPointer;
use crate::graph::GraphRegistrationView;
use rurr_tracking_store::tracked_log::{
    TrackingLogProjector, TrackingLogScanOptions, TrackingLogScanResult,
};
use serde_json::Value;
use std::collections::{BTreeMap, HashMap};
use std::io::{self, BufReader, Cursor};
use std::time::SystemTime;
use time::OffsetDateTime;
use uuid::Uuid;

/// Errors raised while preparing or decoding S3 tracking artifacts.
#[derive(Debug, thiserror::Error)]
pub enum S3TrackingArtifactError {
    /// An application id was not a valid path segment.
    #[error("invalid S3 tracking app id: {0}")]
    InvalidAppId(String),
    /// S3 tracking key layout was invalid.
    #[error(transparent)]
    Layout(#[from] super::s3_layout::S3LayoutError),
    /// S3 user metadata was missing or malformed.
    #[error(transparent)]
    Metadata(#[from] S3MetadataError),
    /// A JSON body could not be serialized or decoded.
    #[error(transparent)]
    Json(#[from] serde_json::Error),
    /// A registered graph could not be represented as a Burr tracking model.
    #[error("failed to build S3 graph artifact model: {0}")]
    GraphModel(String),
    /// A JSONL log body could not be read.
    #[error(transparent)]
    Io(#[from] io::Error),
    /// The parsed key did not match the artifact operation being performed.
    #[error("S3 object '{0}' is a {2:?} object, expected {1:?}")]
    UnexpectedKind(String, S3TrackingObjectKind, S3TrackingObjectKind),
    /// A body was required to decode or index an artifact.
    #[error("S3 object '{key}' requires a {kind:?} body for artifact decoding")]
    MissingBody {
        /// Object key that needed a body.
        key: String,
        /// Artifact kind that required a body.
        kind: S3TrackingObjectKind,
    },
    /// A lifecycle event did not carry Burr sequence metadata.
    #[error("S3 log event is missing sequence_id/action_sequence_id")]
    MissingSequenceId,
    /// A tracking timestamp could not be represented.
    #[error("S3 tracking timestamp failed during {operation}: {message}")]
    Timestamp {
        /// Operation that needed a timestamp.
        operation: &'static str,
        /// Timestamp conversion details.
        message: String,
    },
}

pub(crate) struct S3TrackedArtifact {
    pub(crate) key: String,
    pub(crate) body: Vec<u8>,
    pub(crate) metadata: BTreeMap<String, String>,
}

pub(crate) struct S3RegistrationArtifactInput<'a, G: GraphRegistrationView> {
    pub(crate) data_prefix: &'a S3Prefix,
    pub(crate) project: &'a str,
    pub(crate) tracker_id: &'a str,
    pub(crate) app_id: &'a str,
    pub(crate) partition_key: Option<&'a str>,
    pub(crate) graph: &'a G,
    pub(crate) parent_pointer: Option<ParentPointer>,
    pub(crate) spawning_parent_pointer: Option<ParentPointer>,
    pub(crate) record_application_artifacts: bool,
    pub(crate) record_child_relationships: bool,
    pub(crate) child_sequence_start: u64,
}

pub(crate) fn registration_artifacts<G>(
    input: S3RegistrationArtifactInput<'_, G>,
) -> Result<Vec<S3TrackedArtifact>, S3TrackingArtifactError>
where
    G: GraphRegistrationView,
{
    let timestamp = OffsetDateTime::now_utc();
    let child_event_count = if input.record_child_relationships {
        usize::from(input.parent_pointer.is_some())
            + usize::from(input.spawning_parent_pointer.is_some())
    } else {
        0
    };
    let application_artifact_count = if input.record_application_artifacts {
        2
    } else {
        0
    };
    let mut artifacts = Vec::with_capacity(application_artifact_count + child_event_count);
    if input.record_application_artifacts {
        let graph_model = ApplicationModel::from_graph(input.graph)
            .map_err(|error| S3TrackingArtifactError::GraphModel(error.to_string()))?;
        let metadata_model = ApplicationMetadataModel::new(
            input.partition_key.map(str::to_string),
            input.parent_pointer.clone(),
            input.spawning_parent_pointer.clone(),
        );
        for (filename, body, metadata) in [
            (
                "graph.json",
                serde_json::to_vec(&graph_model)?,
                s3_metadata::object_metadata(input.tracker_id),
            ),
            (
                "metadata.json",
                serde_json::to_vec(&metadata_model)?,
                s3_metadata::application_metadata(
                    input.tracker_id,
                    input.parent_pointer.as_ref(),
                    input.spawning_parent_pointer.as_ref(),
                )?,
            ),
        ] {
            artifacts.push(S3TrackedArtifact {
                key: build_object_key(
                    input.data_prefix,
                    input.project,
                    timestamp,
                    input.partition_key,
                    input.app_id,
                    filename,
                )?,
                body,
                metadata,
            });
        }
    }
    if input.record_child_relationships {
        let mut child_sequence = input.child_sequence_start;
        for (parent, kind) in [
            (input.parent_pointer.as_ref(), ChildRelationshipKind::Fork),
            (
                input.spawning_parent_pointer.as_ref(),
                ChildRelationshipKind::SpawnStart,
            ),
        ] {
            if let Some(parent) = parent {
                artifacts.push(child_relationship_artifact(
                    input.data_prefix,
                    input.project,
                    input.tracker_id,
                    ChildRelationshipEvent {
                        parent,
                        child_app_id: input.app_id,
                        child_partition_key: input.partition_key,
                        kind,
                        object_sequence: child_sequence,
                    },
                )?);
                child_sequence += 1;
            }
        }
    }
    Ok(artifacts)
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ChildRelationshipKind {
    Fork,
    SpawnStart,
}

impl ChildRelationshipKind {
    fn event_type(self) -> &'static str {
        match self {
            Self::Fork => "fork",
            Self::SpawnStart => "spawn_start",
        }
    }
}

struct ChildRelationshipEvent<'a> {
    parent: &'a ParentPointer,
    child_app_id: &'a str,
    child_partition_key: Option<&'a str>,
    kind: ChildRelationshipKind,
    object_sequence: u64,
}

pub(crate) fn build_object_key(
    data_prefix: &S3Prefix,
    project: &str,
    timestamp: OffsetDateTime,
    partition_key: Option<&str>,
    app_id: &str,
    filename: &str,
) -> Result<String, S3TrackingArtifactError> {
    validate_app_id(app_id)?;
    S3TrackingObjectKey::build(
        data_prefix,
        project,
        timestamp,
        partition_key,
        app_id,
        filename,
    )
    .map_err(S3TrackingArtifactError::from)
}

pub(crate) fn lifecycle_log_artifact(
    data_prefix: &S3Prefix,
    project: &str,
    tracker_id: &str,
    sequence: u64,
    partition_key: Option<&str>,
    app_id: &str,
    event: &Value,
) -> Result<S3TrackedArtifact, S3TrackingArtifactError> {
    let (min_sequence_id, max_sequence_id) = event_sequence_range(event)?;
    let filename = format!("{sequence:020}_{}__log.jsonl", Uuid::new_v4());
    let key = build_object_key(
        data_prefix,
        project,
        OffsetDateTime::now_utc(),
        partition_key,
        app_id,
        &filename,
    )?;
    let mut body = serde_json::to_vec(event)?;
    body.push(b'\n');
    Ok(S3TrackedArtifact {
        key,
        body,
        metadata: s3_metadata::log_metadata(tracker_id, min_sequence_id, max_sequence_id),
    })
}

fn child_relationship_artifact(
    data_prefix: &S3Prefix,
    project: &str,
    tracker_id: &str,
    relationship: ChildRelationshipEvent<'_>,
) -> Result<S3TrackedArtifact, S3TrackingArtifactError> {
    validate_app_id(relationship.child_app_id)?;
    let filename = format!(
        "{:020}_{}__children.jsonl",
        relationship.object_sequence,
        Uuid::new_v4()
    );
    let key = build_object_key(
        data_prefix,
        project,
        OffsetDateTime::now_utc(),
        relationship.parent.partition_key.as_deref(),
        &relationship.parent.app_id,
        &filename,
    )?;
    let event = ChildApplicationModel::new(
        PointerModel::application(
            relationship.child_app_id,
            relationship.child_partition_key.map(str::to_string),
            None,
        ),
        relationship.kind.event_type(),
        relationship.parent.sequence_id,
        rurr_persistence::wire::sortable_rfc3339_utc_string(SystemTime::now()).map_err(
            |error| S3TrackingArtifactError::Timestamp {
                operation: "s3_child_relationship",
                message: error.to_string(),
            },
        )?,
    );
    let mut body = serde_json::to_vec(&event)?;
    body.push(b'\n');
    Ok(S3TrackedArtifact {
        key,
        body,
        metadata: s3_metadata::object_metadata(tracker_id),
    })
}

/// Validated lifecycle log artifact body and S3 metadata.
#[derive(Debug)]
pub struct S3LogBundle {
    /// Parsed provider key.
    pub file: S3TrackingObjectKey,
    /// Inclusive minimum sequence id.
    pub min_sequence_id: u64,
    /// Inclusive maximum sequence id.
    pub max_sequence_id: u64,
    /// Tracker id that wrote the object.
    pub tracker_id: String,
    body: Vec<u8>,
}

impl S3LogBundle {
    /// Projects the lifecycle log body with the shared tracked-log scanner.
    ///
    /// The body is parsed with the same validated `end_entry` reader used by
    /// local tracking logs. A log object with no terminal entry returns an
    /// empty summary; malformed terminal records fail rather than producing a
    /// partial provider index row.
    pub fn project_log(
        &self,
        options: TrackingLogScanOptions,
    ) -> Result<TrackingLogScanResult, S3TrackingArtifactError> {
        let mut projector = TrackingLogProjector::new(options);
        self.project_into(&mut projector)?;
        Ok(projector.finish())
    }

    /// Projects this lifecycle log body into an existing incremental projector.
    pub fn project_into(
        &self,
        projector: &mut TrackingLogProjector,
    ) -> Result<(), S3TrackingArtifactError> {
        projector.ingest_reader(
            BufReader::new(Cursor::new(self.body.as_slice())),
            rurr_tracking_store::jsonl::JsonlTailPolicy::Complete,
        )
    }
}

/// Closed descriptor for one Burr-compatible S3 tracking object kind.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum S3ArtifactDescriptor {
    /// Application graph JSON object.
    Graph,
    /// Application metadata JSON object.
    Metadata,
    /// Lifecycle log JSONL object.
    Log,
    /// Child relationship JSONL object.
    Children,
}

/// Decoded application metadata artifact with index metadata.
#[derive(Debug)]
pub struct S3DecodedMetadataArtifact {
    /// Application metadata model decoded from the object body.
    pub model: ApplicationMetadataModel,
    /// Canonical parent pointer JSON from user metadata.
    pub parent_pointer_json: Option<String>,
    /// Canonical spawning parent pointer JSON from user metadata.
    pub spawning_parent_pointer_json: Option<String>,
}

/// Decoded child relationship artifact with index metadata.
#[derive(Debug)]
pub struct S3DecodedChildrenArtifact {
    /// Child relationship models decoded from the JSONL body.
    pub children: Vec<ChildApplicationModel>,
    /// Tracker id that wrote the object.
    pub tracker_id: String,
}

/// Index metadata projected from one decoded S3 tracking artifact.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum S3ArtifactIndexPayload {
    /// Graph object touched the application.
    Graph,
    /// Metadata object touched the application and may carry parent pointers.
    Metadata {
        /// Canonical parent pointer JSON from user metadata.
        parent_pointer_json: Option<String>,
        /// Canonical spawning parent pointer JSON from user metadata.
        spawning_parent_pointer_json: Option<String>,
    },
    /// Log object with validated sequence metadata.
    Log {
        /// Inclusive minimum sequence id.
        min_sequence_id: u64,
        /// Inclusive maximum sequence id.
        max_sequence_id: u64,
        /// Tracker id that wrote the object.
        tracker_id: String,
    },
    /// Child relationship object.
    Child {
        /// Tracker id that wrote the object.
        tracker_id: String,
    },
}

impl S3ArtifactDescriptor {
    /// Returns the descriptor for a parsed tracking object key.
    #[must_use]
    pub fn for_key(file: &S3TrackingObjectKey) -> Self {
        Self::from_kind(file.kind())
    }

    /// Returns the descriptor for an S3 tracking object kind.
    #[must_use]
    pub fn from_kind(kind: S3TrackingObjectKind) -> Self {
        match kind {
            S3TrackingObjectKind::Graph => Self::Graph,
            S3TrackingObjectKind::Metadata => Self::Metadata,
            S3TrackingObjectKind::Log => Self::Log,
            S3TrackingObjectKind::Children => Self::Children,
        }
    }

    /// Returns the artifact kind this descriptor accepts.
    #[must_use]
    pub fn kind(self) -> S3TrackingObjectKind {
        match self {
            Self::Graph => S3TrackingObjectKind::Graph,
            Self::Metadata => S3TrackingObjectKind::Metadata,
            Self::Log => S3TrackingObjectKind::Log,
            Self::Children => S3TrackingObjectKind::Children,
        }
    }

    /// Returns a user-facing description for errors expecting this artifact kind.
    #[must_use]
    pub fn description(self) -> &'static str {
        match self {
            Self::Graph => "a graph object",
            Self::Metadata => "an application metadata object",
            Self::Log => "a lifecycle log object",
            Self::Children => "a child relationship object",
        }
    }

    /// Returns whether indexing this artifact requires reading the object body.
    #[must_use]
    pub const fn requires_body_for_index(self) -> bool {
        self as u8 == Self::Log as u8
    }

    fn required_metadata(self) -> &'static [&'static str] {
        match self {
            Self::Graph | Self::Children => &[s3_metadata::TRACKER_ID],
            Self::Metadata => &[
                s3_metadata::TRACKER_ID,
                s3_metadata::PARENT_POINTER,
                s3_metadata::SPAWNING_PARENT_POINTER,
            ],
            Self::Log => &[
                s3_metadata::MIN_SEQUENCE_ID,
                s3_metadata::MAX_SEQUENCE_ID,
                s3_metadata::TRACKER_ID,
            ],
        }
    }

    /// Validates the parsed key and required user metadata for this artifact kind.
    pub fn validate(
        self,
        file: &S3TrackingObjectKey,
        metadata: &HashMap<String, String>,
    ) -> Result<(), S3TrackingArtifactError> {
        ensure_kind(file, self.kind())?;
        for field in self.required_metadata() {
            s3_metadata::required_metadata_value(metadata, field, file.key())?;
        }
        Ok(())
    }

    /// Decodes and validates an application graph artifact.
    pub fn decode_graph(
        self,
        file: S3TrackingObjectKey,
        metadata: &HashMap<String, String>,
        body: Vec<u8>,
    ) -> Result<ApplicationModel, S3TrackingArtifactError> {
        self.validate(&file, metadata)?;
        self.ensure_descriptor(Self::Graph, &file)?;
        serde_json::from_slice(&body).map_err(S3TrackingArtifactError::from)
    }

    /// Decodes and validates an application metadata artifact.
    pub fn decode_metadata(
        self,
        file: S3TrackingObjectKey,
        metadata: &HashMap<String, String>,
        body: Vec<u8>,
    ) -> Result<S3DecodedMetadataArtifact, S3TrackingArtifactError> {
        self.validate(&file, metadata)?;
        self.ensure_descriptor(Self::Metadata, &file)?;
        let (parent_pointer_json, spawning_parent_pointer_json) =
            metadata_pointer_json(&file, metadata)?;
        let model = serde_json::from_slice(&body)?;
        Ok(S3DecodedMetadataArtifact {
            model,
            parent_pointer_json,
            spawning_parent_pointer_json,
        })
    }

    /// Decodes and validates a lifecycle log artifact.
    pub fn decode_log(
        self,
        file: S3TrackingObjectKey,
        metadata: &HashMap<String, String>,
        body: Vec<u8>,
    ) -> Result<S3LogBundle, S3TrackingArtifactError> {
        self.validate(&file, metadata)?;
        self.ensure_descriptor(Self::Log, &file)?;
        self.log_bundle(&file, metadata, body)
    }

    /// Decodes and validates a child relationship artifact.
    pub fn decode_children(
        self,
        file: S3TrackingObjectKey,
        metadata: &HashMap<String, String>,
        body: Vec<u8>,
    ) -> Result<S3DecodedChildrenArtifact, S3TrackingArtifactError> {
        self.validate(&file, metadata)?;
        self.ensure_descriptor(Self::Children, &file)?;
        let tracker_id = tracker_id(metadata, file.key())?;
        let children = decode_child_models_body(&body)?;
        Ok(S3DecodedChildrenArtifact {
            children,
            tracker_id,
        })
    }

    /// Projects index metadata from the artifact key, metadata, and optional body.
    pub fn index_payload(
        self,
        file: &S3TrackingObjectKey,
        metadata: &HashMap<String, String>,
        body: Option<Vec<u8>>,
    ) -> Result<S3ArtifactIndexPayload, S3TrackingArtifactError> {
        self.validate(file, metadata)?;
        match self {
            Self::Graph => Ok(S3ArtifactIndexPayload::Graph),
            Self::Metadata => {
                let (parent_pointer_json, spawning_parent_pointer_json) =
                    metadata_pointer_json(file, metadata)?;
                Ok(S3ArtifactIndexPayload::Metadata {
                    parent_pointer_json,
                    spawning_parent_pointer_json,
                })
            }
            Self::Log => {
                let body = body.ok_or_else(|| S3TrackingArtifactError::MissingBody {
                    key: file.key().to_string(),
                    kind: self.kind(),
                })?;
                let bundle = self.log_bundle(file, metadata, body)?;
                bundle.project_log(TrackingLogScanOptions::summary())?;
                Ok(S3ArtifactIndexPayload::Log {
                    min_sequence_id: bundle.min_sequence_id,
                    max_sequence_id: bundle.max_sequence_id,
                    tracker_id: bundle.tracker_id,
                })
            }
            Self::Children => Ok(S3ArtifactIndexPayload::Child {
                tracker_id: tracker_id(metadata, file.key())?,
            }),
        }
    }

    fn log_bundle(
        self,
        file: &S3TrackingObjectKey,
        metadata: &HashMap<String, String>,
        body: Vec<u8>,
    ) -> Result<S3LogBundle, S3TrackingArtifactError> {
        Ok(S3LogBundle {
            min_sequence_id: s3_metadata::required_sequence_metadata(
                metadata,
                s3_metadata::MIN_SEQUENCE_ID,
                file.key(),
            )?,
            max_sequence_id: s3_metadata::required_sequence_metadata(
                metadata,
                s3_metadata::MAX_SEQUENCE_ID,
                file.key(),
            )?,
            tracker_id: tracker_id(metadata, file.key())?,
            file: file.clone(),
            body,
        })
    }

    fn ensure_descriptor(
        self,
        expected: Self,
        file: &S3TrackingObjectKey,
    ) -> Result<(), S3TrackingArtifactError> {
        if self == expected {
            Ok(())
        } else {
            Err(S3TrackingArtifactError::UnexpectedKind(
                file.key().to_string(),
                expected.kind(),
                file.kind(),
            ))
        }
    }
}

fn tracker_id(
    metadata: &HashMap<String, String>,
    object_key: &str,
) -> Result<String, S3TrackingArtifactError> {
    Ok(
        s3_metadata::required_metadata_value(metadata, s3_metadata::TRACKER_ID, object_key)?
            .to_string(),
    )
}

fn metadata_pointer_json(
    file: &S3TrackingObjectKey,
    metadata: &HashMap<String, String>,
) -> Result<(Option<String>, Option<String>), S3TrackingArtifactError> {
    let parent_pointer_json =
        s3_metadata::parse_pointer_metadata(metadata, s3_metadata::PARENT_POINTER, file.key())?;
    let spawning_parent_pointer_json = s3_metadata::parse_pointer_metadata(
        metadata,
        s3_metadata::SPAWNING_PARENT_POINTER,
        file.key(),
    )?;
    Ok((parent_pointer_json, spawning_parent_pointer_json))
}

fn decode_child_models_body(
    body: &[u8],
) -> Result<Vec<ChildApplicationModel>, S3TrackingArtifactError> {
    let mut values = Vec::new();
    rurr_tracking_store::jsonl::visit_complete_jsonl_values::<
        _,
        ChildApplicationModel,
        S3TrackingArtifactError,
        _,
    >(BufReader::new(Cursor::new(body)), |value| {
        values.push(value);
        Ok(())
    })?;
    Ok(values)
}

fn event_sequence_range(event: &Value) -> Result<(u64, u64), S3TrackingArtifactError> {
    let sequence_id = event
        .get("sequence_id")
        .or_else(|| event.get("action_sequence_id"))
        .and_then(Value::as_u64)
        .ok_or(S3TrackingArtifactError::MissingSequenceId)?;
    Ok((sequence_id, sequence_id))
}

fn ensure_kind(
    file: &S3TrackingObjectKey,
    expected: S3TrackingObjectKind,
) -> Result<(), S3TrackingArtifactError> {
    let actual = file.kind();
    if actual == expected {
        Ok(())
    } else {
        Err(S3TrackingArtifactError::UnexpectedKind(
            file.key().to_string(),
            expected,
            actual,
        ))
    }
}

fn validate_app_id(app_id: &str) -> Result<(), S3TrackingArtifactError> {
    rurr_tracking_store::anchored_fs::validate_path_segment("app_id", app_id)
        .map_err(|_| S3TrackingArtifactError::InvalidAppId(app_id.to_string()))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn child_relationship_artifact_serializes_one_jsonl_row_with_tracker_metadata() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        let parent = ParentPointer {
            app_id: "parent-app".to_string(),
            partition_key: Some("parent-pk".to_string()),
            sequence_id: Some(7),
        };
        let artifact = child_relationship_artifact(
            &prefix,
            "project",
            "tracker-1",
            ChildRelationshipEvent {
                parent: &parent,
                child_app_id: "child-app",
                child_partition_key: Some("child-pk"),
                kind: ChildRelationshipKind::SpawnStart,
                object_sequence: 3,
            },
        )
        .expect("child artifact should build");

        assert!(artifact.key.starts_with("data/project/"));
        assert!(artifact
            .key
            .contains("/parent-pk/parent-app/00000000000000000003_"));
        assert!(artifact.key.ends_with("__children.jsonl"));
        assert_eq!(
            artifact.metadata.get(s3_metadata::TRACKER_ID),
            Some(&"tracker-1".to_string())
        );
        assert!(
            artifact.body.ends_with(b"\n"),
            "child artifacts are complete JSONL rows"
        );

        let file = S3TrackingObjectKey::parse(&prefix, &artifact.key).expect("key should parse");
        let metadata = artifact
            .metadata
            .into_iter()
            .collect::<HashMap<String, String>>();
        let children = S3ArtifactDescriptor::for_key(&file)
            .decode_children(file, &metadata, artifact.body)
            .expect("child JSONL should decode")
            .children;
        assert_eq!(children.len(), 1);
        assert_eq!(children[0].event_type, "spawn_start");
        assert_eq!(children[0].sequence_id, Some(7));
        assert_eq!(children[0].child.app_id, "child-app");
        assert_eq!(children[0].child.partition_key.as_deref(), Some("child-pk"));
    }

    #[test]
    fn child_relationship_decoder_rejects_wrong_object_kind() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        let key = build_object_key(
            &prefix,
            "project",
            OffsetDateTime::UNIX_EPOCH,
            Some("pk"),
            "parent-app",
            "graph.json",
        )
        .expect("graph key should build");
        let file = S3TrackingObjectKey::parse(&prefix, &key).expect("key should parse");
        let metadata =
            HashMap::from([(s3_metadata::TRACKER_ID.to_string(), "tracker".to_string())]);

        let error = S3ArtifactDescriptor::Children
            .decode_children(file, &metadata, Vec::new())
            .expect_err("wrong object kind should fail");
        assert!(matches!(
            error,
            S3TrackingArtifactError::UnexpectedKind(
                _,
                S3TrackingObjectKind::Children,
                S3TrackingObjectKind::Graph
            )
        ));
    }

    #[test]
    fn descriptor_projects_metadata_index_payload() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        let parent = ParentPointer {
            app_id: "parent-app".to_string(),
            partition_key: Some("pk".to_string()),
            sequence_id: Some(9),
        };
        let file = S3TrackingObjectKey::parse(
            &prefix,
            &build_object_key(
                &prefix,
                "project",
                OffsetDateTime::UNIX_EPOCH,
                None,
                "app",
                "metadata.json",
            )
            .expect("metadata key should build"),
        )
        .expect("metadata key should parse");
        let metadata = s3_metadata::application_metadata("tracker", Some(&parent), None)
            .expect("metadata should encode")
            .into_iter()
            .collect::<HashMap<_, _>>();

        let payload = S3ArtifactDescriptor::for_key(&file)
            .index_payload(&file, &metadata, None)
            .expect("metadata should project");

        assert!(matches!(
            payload,
            S3ArtifactIndexPayload::Metadata {
                parent_pointer_json: Some(_),
                spawning_parent_pointer_json: None
            }
        ));
    }

    #[test]
    fn descriptor_exposes_closed_kind_policy_without_envelope() {
        for (descriptor, description, requires_body) in [
            (S3ArtifactDescriptor::Graph, "a graph object", false),
            (
                S3ArtifactDescriptor::Metadata,
                "an application metadata object",
                false,
            ),
            (
                S3ArtifactDescriptor::Children,
                "a child relationship object",
                false,
            ),
            (S3ArtifactDescriptor::Log, "a lifecycle log object", true),
        ] {
            assert_eq!(descriptor.description(), description);
            assert_eq!(descriptor.requires_body_for_index(), requires_body);
        }
    }

    #[test]
    fn log_descriptor_enforces_body_and_projects_through_log_projector() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        let event = serde_json::json!({
            "type": "end_entry",
            "end_time": "2026-03-20T00:00:00.000000000Z",
            "action": "counter",
            "result": {"count": 1},
            "exception": Value::Null,
            "state": {
                "count": 1,
                "__SEQUENCE_ID": 0,
                "__PRIOR_STEP": "counter",
            },
            "sequence_id": 0,
        });
        let artifact =
            lifecycle_log_artifact(&prefix, "project", "tracker", 0, None, "app", &event)
                .expect("log artifact should build");
        let file =
            S3TrackingObjectKey::parse(&prefix, &artifact.key).expect("log key should parse");
        let metadata = artifact.metadata.into_iter().collect::<HashMap<_, _>>();

        let missing_body_error = S3ArtifactDescriptor::Log
            .index_payload(&file, &metadata, None)
            .expect_err("log index projection should require body");
        let S3TrackingArtifactError::MissingBody { kind, .. } = missing_body_error else {
            panic!("expected missing log body error");
        };
        assert_eq!(kind, S3TrackingObjectKind::Log);

        let payload = S3ArtifactDescriptor::Log
            .index_payload(&file, &metadata, Some(artifact.body))
            .expect("log should project through tracked-log projector");

        assert_eq!(
            payload,
            S3ArtifactIndexPayload::Log {
                min_sequence_id: 0,
                max_sequence_id: 0,
                tracker_id: "tracker".to_string()
            }
        );
    }
}
