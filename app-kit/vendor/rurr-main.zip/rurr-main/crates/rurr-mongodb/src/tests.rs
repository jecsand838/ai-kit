use super::{is_namespace_exists_error, is_namespace_not_found_error, parse_save_reply};
use crate::{
    schema::{MongoPersistencePlan, UNIQUE_RECORD_INDEX_NAME},
    MongoPersister, MongoPersisterConfig,
};
use indexmap::IndexMap;
use mongodb::bson::{doc, Document};
use mongodb::sync::Client as MongoClient;
use rurr_persistence::{BaseStateSaver, PersistedStateStatus, PersistenceError};
use rurr_testkit::{
    drop_mongodb_collection_sync, ready_mongodb_uri_sync, unique_mongodb_collection_name,
};
use serde_json::json;

fn live_config(prefix: &str) -> MongoPersisterConfig {
    MongoPersisterConfig {
        uri: ready_mongodb_uri_sync().expect("mongodb must be reachable for live tests"),
        db_name: "rurr_mongodb_live_unit".to_string(),
        collection_name: unique_mongodb_collection_name(prefix),
    }
}

fn cleanup_collection(config: &MongoPersisterConfig) {
    cleanup_named_collection(config, config.collection_name.as_str());
}

fn cleanup_named_collection(config: &MongoPersisterConfig, collection_name: &str) {
    let _ = drop_mongodb_collection_sync(
        config.uri.as_str(),
        config.db_name.as_str(),
        collection_name,
    );
}

fn with_live_persister<T>(
    prefix: &str,
    test: impl FnOnce(&MongoPersister, &MongoPersisterConfig) -> T,
) -> T {
    let config = live_config(prefix);
    let persister = MongoPersister::new(config.clone()).expect("persister should create");
    let output = test(&persister, &config);
    let _ = persister.cleanup();
    cleanup_collection(&config);
    output
}

fn drop_required_index(config: &MongoPersisterConfig, index_name: &str) {
    let client =
        MongoClient::with_uri_str(config.uri.as_str()).expect("inspection client should construct");
    client
        .database(config.db_name.as_str())
        .collection::<Document>(config.collection_name.as_str())
        .drop_index(index_name)
        .run()
        .expect("index drop should succeed");
}

fn live_save_reply(
    persister: &MongoPersister,
    partition_key: Option<&str>,
    app_id: &str,
    sequence_id: u64,
    position: &str,
) -> Document {
    let collection_uuid = persister
        .collection_uuid()
        .expect("initialized persister should resolve collection UUID");
    let state = IndexMap::from([(String::from("value"), json!("saved"))]);
    let plan = MongoPersistencePlan::save(
        partition_key,
        app_id,
        sequence_id,
        position,
        &state,
        PersistedStateStatus::Completed,
        crate::now_sortable_rfc3339_utc_string().expect("valid current timestamp should format"),
    )
    .expect("save plan should build");

    persister
        .database()
        .expect("database should resolve")
        .run_command(
            plan.update_command(persister.config.collection_name.as_str(), &collection_uuid),
        )
        .run()
        .expect("raw save command should succeed")
}

#[test]
fn live_namespace_helpers_detect_real_create_and_drop_errors() {
    rurr_testkit::require_check_live_tests!();

    let config = live_config("namespace_helpers");
    let persister = MongoPersister::new(config.clone()).expect("persister should create");
    let database = persister.database().expect("database should resolve");
    let admin = persister.client.database("admin");
    let source_name = format!("{}_source", config.collection_name);
    let target_name = format!("{}_target", config.collection_name);
    let missing_name = format!("{}_missing", config.collection_name);
    let renamed_name = format!("{}_renamed", config.collection_name);

    database
        .create_collection(source_name.as_str())
        .run()
        .expect("source collection should be created");
    database
        .create_collection(target_name.as_str())
        .run()
        .expect("target collection should be created");

    let namespace_exists = admin
        .run_command(doc! {
            "renameCollection": format!("{}.{}", config.db_name, source_name),
            "to": format!("{}.{}", config.db_name, target_name),
            "dropTarget": false,
        })
        .run()
        .expect_err("rename into an existing namespace should return NamespaceExists");
    assert!(is_namespace_exists_error(&namespace_exists));

    let namespace_not_found = admin
        .run_command(doc! {
            "renameCollection": format!("{}.{}", config.db_name, missing_name),
            "to": format!("{}.{}", config.db_name, renamed_name),
            "dropTarget": false,
        })
        .run()
        .expect_err("rename from a missing namespace should return NamespaceNotFound");
    assert!(is_namespace_not_found_error(&namespace_not_found));

    let _ = persister.cleanup();
    cleanup_named_collection(&config, source_name.as_str());
    cleanup_named_collection(&config, target_name.as_str());
    cleanup_named_collection(&config, renamed_name.as_str());
    cleanup_collection(&config);
}

#[test]
fn live_save_reply_parser_matches_real_upsert_and_duplicate_match_replies() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("save_reply", |persister, _config| {
        persister
            .initialize()
            .expect("initialize should succeed for raw save reply tests");

        let inserted_reply = live_save_reply(persister, Some("tenant"), "app", 7, "step");
        parse_save_reply(inserted_reply).expect("real upsert reply should parse as success");

        let duplicate_reply = live_save_reply(persister, Some("tenant"), "app", 7, "step");
        let duplicate_error =
            parse_save_reply(duplicate_reply).expect_err("real duplicate match should fail");
        assert!(matches!(
            duplicate_error,
            PersistenceError::UnsupportedOperation {
                operation: "record_already_exists"
            }
        ));
    });
}

#[test]
fn live_unique_index_drift_save_error_clears_cached_collection_uuid() {
    rurr_testkit::require_check_live_tests!();

    with_live_persister("save_schema_drift", |persister, config| {
        persister
            .initialize()
            .expect("initialize should succeed before index drift");
        assert!(
            persister
                .cached_collection_uuid()
                .expect("cached collection UUID should load")
                .is_some(),
            "initialize should populate the cached collection UUID"
        );

        drop_required_index(config, UNIQUE_RECORD_INDEX_NAME);

        let error = persister
            .save(
                Some("tenant"),
                "app",
                1,
                "step",
                IndexMap::from([(String::from("value"), json!("after-drop"))]),
                PersistedStateStatus::Completed,
            )
            .expect_err("save should fail once the required unique index is removed");
        assert!(matches!(error, PersistenceError::NotInitialized));
        assert!(
            persister
                .cached_collection_uuid()
                .expect("cached collection UUID should load")
                .is_none(),
            "live schema drift should invalidate the cached collection UUID"
        );
    });
}
