use indexmap::IndexMap;
use rurr_persistence::{PersistenceLoadTarget, StateInitializerSpec, StateLoaderRef};
use serde_json::Value;

/// Describes how an application should initialize or resume from persistence.
#[derive(Clone, Debug)]
pub struct InitializeFromSpec {
    resume_at_next_action: bool,
    default_state: IndexMap<String, Value>,
    default_entrypoint: String,
    load_target: Option<PersistenceLoadTarget>,
    override_state_values: Option<IndexMap<String, Value>>,
}

impl InitializeFromSpec {
    /// Creates a persistence-initialization specification.
    ///
    /// `resume_at_next_action` controls whether resumed applications continue at
    /// the next action (`true`) or replay the last completed action (`false`)
    /// according to the persistence contract.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use indexmap::IndexMap;
    /// use rurr_core::InitializeFromSpec;
    /// use serde_json::json;
    ///
    /// let spec = InitializeFromSpec::new(
    ///     true,
    ///     IndexMap::from([("count".to_string(), json!(0))]),
    ///     "increment",
    /// );
    /// let _ = spec;
    /// ```
    pub fn new(
        resume_at_next_action: bool,
        default_state: IndexMap<String, Value>,
        default_entrypoint: impl Into<String>,
    ) -> Self {
        Self {
            resume_at_next_action,
            default_state,
            default_entrypoint: default_entrypoint.into(),
            load_target: None,
            override_state_values: None,
        }
    }

    /// Pins initialization to a specific persisted load target.
    pub fn with_fork_target(mut self, load_target: PersistenceLoadTarget) -> Self {
        self.load_target = Some(load_target);
        self
    }

    /// Overrides selected state values after loading persisted state.
    pub fn with_override_state_values(
        mut self,
        override_state_values: IndexMap<String, Value>,
    ) -> Self {
        self.override_state_values = Some(override_state_values);
        self
    }

    pub(crate) fn into_state_initializer_spec(
        self,
        initializer: StateLoaderRef,
    ) -> StateInitializerSpec {
        let Self {
            resume_at_next_action,
            default_state,
            default_entrypoint,
            load_target,
            override_state_values,
        } = self;

        StateInitializerSpec::from_ref(
            initializer,
            resume_at_next_action,
            default_state,
            default_entrypoint,
            override_state_values,
        )
        .with_optional_load_target(load_target)
    }
}
