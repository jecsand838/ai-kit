use super::*;
use super::{actions::*, builders::*, cases::*, hooks::*};

macro_rules! stream_mode_case_matrix {
    ($(
        ($sync_name:ident, $async_name:ident) => $func:path $(; $arg:expr)*
    ),+ $(,)?) => {
        $(
            sync_stream_case!($sync_name => $func(StreamMode::Sync $(, $arg)*));
            async_stream_case!($async_name => $func(StreamMode::Async $(, $arg)*));
        )+
    };
}

stream_mode_case_matrix! {
    (stream_result_direct_execution_options_match_runner_defaults, astream_result_direct_execution_options_match_runner_defaults) =>
        assert_stream_result_direct_matches_runner_default,
    (stream_result_direct_execution_options_match_runner_with_halt_after, astream_result_direct_execution_options_match_runner_with_halt_after) =>
        assert_stream_result_direct_matches_runner_with_halt_after,
    (stream_result_is_lazy_and_advances_one_item_per_next_item_call, astream_result_is_lazy_and_advances_one_item_per_next_item_call) =>
        assert_result_is_lazy_and_advances_one_item_per_next_item_call,
    (stream_result_terminal_close_surfaces_sync_post_execute_call_failure, astream_result_terminal_close_surfaces_async_post_execute_call_failure) =>
        assert_result_terminal_close_surfaces_post_execute_call_failure,
    (stream_result_failed_first_item_finishes_terminally, astream_result_failed_first_item_finishes_terminally) =>
        assert_result_failed_first_item_finishes_terminally,
    (stream_result_drop_mid_stream_rolls_back_state_and_sequence_id, astream_result_drop_mid_stream_rolls_back_state_and_sequence_id) =>
        assert_result_drop_mid_stream_rolls_back_state_and_sequence_id,
    (stream_result_panic_mid_stream_rolls_back_state_and_sequence_id, astream_result_panic_mid_stream_maps_async_next_scope_and_rolls_back) =>
        assert_result_panic_mid_stream_rolls_back_state_and_sequence_id,
    (stream_iterate_is_lazy_until_next_step, astream_iterate_is_lazy_until_next_step) =>
        assert_iterate_is_lazy_until_next_step,
    (stream_iterate_direct_execution_options_match_runner_defaults, astream_iterate_direct_execution_options_match_runner_defaults) =>
        assert_stream_iterate_direct_matches_runner_default,
    (stream_iterate_direct_execution_options_match_runner_with_halt_after, astream_iterate_direct_execution_options_match_runner_with_halt_after) =>
        assert_stream_iterate_direct_matches_runner_with_halt_after,
    (stream_iterate_terminal_session_stays_terminal, astream_iterate_terminal_session_stays_terminal) =>
        assert_iterate_terminal_session_stays_terminal,
    (stream_result_returns_resolved_halt_after_action_after_fast_forward, astream_result_returns_resolved_halt_after_action_after_fast_forward) =>
        assert_stream_result_fast_forward_case; StreamResultFastForwardCase::ResolvedHaltAfter,
    (stream_result_returns_halt_before_action_after_fast_forward, astream_result_returns_halt_before_action_after_fast_forward) =>
        assert_stream_result_fast_forward_case; StreamResultFastForwardCase::HaltBeforeTarget,
    (stream_result_halt_before_current_action_with_no_next_transition_returns_passthrough_terminal, astream_result_halt_before_current_action_with_no_next_transition_returns_passthrough_terminal) =>
        assert_stream_result_fast_forward_case; StreamResultFastForwardCase::HaltBeforeCurrentTerminal,
    (stream_result_no_matching_halt_target_still_errors_when_graph_exhausts, astream_result_no_matching_halt_target_still_errors_when_graph_exhausts) =>
        assert_stream_result_fast_forward_case; StreamResultFastForwardCase::MissingHaltTarget,
    (stream_result_resumed_overlap_halt_after_overrides_halt_before, astream_result_resumed_overlap_halt_after_overrides_halt_before) =>
        assert_stream_result_fast_forward_case; StreamResultFastForwardCase::ResumedOverlapPrefersHaltAfter,
    (stream_result_fast_forward_does_not_invoke_pre_target_stream_path, astream_result_fast_forward_does_not_invoke_pre_target_stream_path) =>
        assert_stream_result_fast_forward_case; StreamResultFastForwardCase::PreTargetRunOnlyGuard
}

sync_stream_cases! {
    stream_step_rollback_surfaces_sync_post_run_step_failure =>
        assert_sync_stream_result_rollback_surfaces_finish_failure(SyncFinishFailurePhase::PostRunStep),
    stream_step_rollback_surfaces_sync_post_end_stream_failure =>
        assert_sync_stream_result_rollback_surfaces_finish_failure(SyncFinishFailurePhase::PostEndStream),
    stream_step_handle_drop_mid_stream_sync_post_run_step_failure_surfaces_hook_error_not_stream_invariant =>
        assert_sync_step_handle_drop_mid_stream_surfaces_finish_failure(SyncFinishFailurePhase::PostRunStep),
    stream_step_handle_drop_mid_stream_sync_post_end_stream_failure_surfaces_hook_error_not_stream_invariant =>
        assert_sync_step_handle_drop_mid_stream_surfaces_finish_failure(SyncFinishFailurePhase::PostEndStream),
    stream_result_post_stream_item_failure_with_sync_finish_failure_preserves_rollback_state =>
        assert_sync_result_post_stream_item_failure_preserves_rollback_state(),
    stream_iterate_non_streaming_update_trace_emits_span_hooks =>
        assert_non_streaming_update_trace_emits_span_hooks(StreamMode::Sync, UpdateTraceDrive::Iterate)
}

async_stream_case!(
    astream_result_post_stream_item_failure_with_async_finish_failure_preserves_rollback_state =>
        assert_async_result_post_stream_item_failure_preserves_rollback_state()
);

sync_stream_case!(
    stream_result_non_streaming_update_trace_emits_span_hooks =>
        assert_non_streaming_update_trace_emits_span_hooks(StreamMode::Sync, UpdateTraceDrive::Result)
);

#[test]
fn stream_result_wraps_non_streaming_action_lazily() {
    let calls = Arc::new(AtomicUsize::new(0));
    let action = non_streaming_count_action(Arc::clone(&calls));
    let mut app = build_count_zero_action_app("non_stream", action).expect("app should build");

    let halt_after = vec!["non_stream".to_string()];
    let (_action, mut stream_result) = app
        .stream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .expect("stream_result should create");
    assert_eq!(calls.load(Ordering::SeqCst), 0);

    assert!(
        stream_result
            .next_item()
            .expect("next_item should succeed")
            .is_none(),
        "non-streaming stream_result should produce no intermediate items"
    );
    let (result, state) = stream_result.get().expect("get should succeed");
    assert_eq!(result, Some(map_from_pairs([("count", json!(1))])));
    assert_eq!(state.get("count").cloned(), Some(json!(1)));
    assert_eq!(calls.load(Ordering::SeqCst), 1);
}

#[test]
fn stream_result_runs_non_target_steps_without_buffering_then_streams_target() {
    let non_stream_calls = Arc::new(AtomicUsize::new(0));
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let non_stream = non_streaming_count_action(Arc::clone(&non_stream_calls));
    let stream_action = streaming_count_action(Arc::clone(&stream_calls), 3, None);
    let mut app = build_count_zero_transition_app(
        "A",
        non_stream,
        "B",
        stream_action,
        vec![Transition::new("A", "B", Condition::default())],
    )
    .expect("app should build");

    let halt_after = vec!["B".to_string()];
    let (action, mut stream_result) = app
        .stream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .expect("stream_result should create");
    assert_eq!(action.name(), "B");
    assert_eq!(non_stream_calls.load(Ordering::SeqCst), 1);
    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);

    let _first = stream_result
        .next_item()
        .expect("next_item should succeed")
        .expect("first item should exist");
    assert_eq!(non_stream_calls.load(Ordering::SeqCst), 1);
    assert_eq!(stream_calls.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn astream_result_implements_stream_trait_and_stays_lazy() {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(Arc::clone(&stream_calls), 3, None);
    let mut app = build_streaming_app(action).expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = app
        .astream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("astream_result should create");

    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);

    let first = stream_result
        .next()
        .await
        .expect("first stream item should exist")
        .expect("first stream item should succeed");
    assert_eq!(first.get("count"), Some(&json!(1)));
    assert_eq!(stream_calls.load(Ordering::SeqCst), 1);

    let second = stream_result
        .next()
        .await
        .expect("second stream item should exist")
        .expect("second stream item should succeed");
    assert_eq!(second.get("count"), Some(&json!(2)));
    assert_eq!(stream_calls.load(Ordering::SeqCst), 2);

    let end = stream_result.next().await;
    assert!(end.is_none(), "terminal item must not be yielded");
    assert_eq!(stream_calls.load(Ordering::SeqCst), 3);

    let (terminal, state) = stream_result.get().await.expect("get should succeed");
    assert_eq!(terminal, Some(map_from_pairs([("count", json!(3))])));
    assert_eq!(state.get("count").cloned(), Some(json!(3)));
}

#[tokio::test]
async fn astream_result_stream_trait_is_cancellation_safe_when_setup_yields_pending() {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let hook_counts = Arc::new(PendingHookCounts::default());
    let hook = Arc::new(YieldingPreRunStepHook::new(Arc::clone(&hook_counts)));
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = hook;
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook]);

    let action = streaming_count_action(Arc::clone(&stream_calls), 3, None);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = app
        .astream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("astream_result should create");

    let first = stream_result
        .next()
        .await
        .expect("first stream item should exist")
        .expect("first stream item should succeed");
    assert_eq!(first.get("count"), Some(&json!(1)));
    assert_eq!(stream_calls.load(Ordering::SeqCst), 1);
    assert_eq!(
        hook_counts.sync_pre_run_step.load(Ordering::SeqCst),
        1,
        "setup must run exactly once despite pending poll"
    );
    assert_eq!(
        hook_counts.async_pre_run_step.load(Ordering::SeqCst),
        1,
        "async setup must run exactly once despite pending poll"
    );

    let _second = stream_result
        .next()
        .await
        .expect("second stream item should exist")
        .expect("second stream item should succeed");
    let end = stream_result.next().await;
    assert!(end.is_none(), "terminal item must not be yielded");
    let (terminal, state) = stream_result.get().await.expect("get should succeed");
    assert_eq!(terminal, Some(map_from_pairs([("count", json!(3))])));
    assert_eq!(state.get("count").cloned(), Some(json!(3)));
}

#[tokio::test]
async fn astream_result_stream_trait_handles_pending_stream_source_without_restarts() {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let pending_polls = Arc::new(AtomicUsize::new(0));
    let action = pending_async_stream_action(Arc::clone(&stream_calls), Arc::clone(&pending_polls));
    let mut app = build_pending_async_streaming_app(action).expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = app
        .astream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("astream_result should create");

    let first = stream_result
        .next()
        .await
        .expect("first stream item should exist")
        .expect("first stream item should succeed");
    assert_eq!(first.get("count"), Some(&json!(1)));
    assert_eq!(pending_polls.load(Ordering::SeqCst), 1);
    assert_eq!(stream_calls.load(Ordering::SeqCst), 1);

    let end = stream_result.next().await;
    assert!(
        end.is_none(),
        "terminal item should commit and not be yielded as stream output"
    );
    assert_eq!(stream_calls.load(Ordering::SeqCst), 2);
    let (terminal, state) = stream_result.get().await.expect("get should succeed");
    assert_eq!(terminal, Some(map_from_pairs([("count", json!(2))])));
    assert_eq!(state.get("count").cloned(), Some(json!(2)));
}
