//! Generic OpenTelemetry OTLP bootstrap helpers and Rurr lifecycle integration.
//!
//! This crate owns concrete OpenTelemetry integration for the workspace:
//! OTLP exporter/provider setup, direct `tracing-opentelemetry` subscriber
//! construction, and the lifecycle bridge that mirrors Rurr execution into
//! spans. `rurr-core` stays provider-neutral and receives only ordinary
//! lifecycle hooks from this crate.
//!
//! Use [`OtlpConfig`] and the provider builders for exporter setup, and use
//! [`OtelTrackingBridge::lifecycle_hooks`] when an application should emit Rurr
//! lifecycle spans and keep async child spans attached across `.await` points.
//! HTTP instrumentation crates such as `tower-http` should be used directly;
//! this crate only supplies the subscriber and Rurr-specific lifecycle bridge.
//! Subscriber installation and exporter setup are process-global or
//! network-facing operations, so examples that perform them live on the
//! corresponding builder functions and are compile-checked with `no_run`.
//!
//! ```rust
//! use opentelemetry::Value as OtelValue;
//!
//! let value = rurr_otel::convert_to_otel_attribute(&serde_json::json!(["a", "b"]))
//!     .ok_or_else(|| std::io::Error::other("JSON array should convert to an OTEL attribute"))?;
//! assert!(matches!(value, OtelValue::Array(_)));
//! # Ok::<(), Box<dyn std::error::Error>>(())
//! ```
#![deny(missing_docs)]

mod attributes;
mod init;
mod lifecycle;

/// Converts a JSON value into the closest matching OpenTelemetry attribute value.
pub use attributes::convert_to_otel_attribute;
/// Traces/logs OTLP bootstrap helpers and provider builders.
pub use init::{
    build_otlp_log_exporter, build_otlp_logger_provider, build_otlp_span_exporter,
    build_otlp_tracer_provider, build_otlp_tracer_provider_with_span_processors, build_resource,
    build_tracing_subscriber, has_any_otlp_endpoint_configuration, init_tracing,
    init_tracing_with_exporter, install_tracing_subscriber_with_config, OtlpConfig, OtlpEndpoint,
    OtlpError, OtlpSignal, TracingSubscriberConfig,
};
/// Rurr lifecycle adapters and tracking bridge for OpenTelemetry spans.
pub use lifecycle::{
    OtelLifecycleAdapter, OtelTrackingBridge, OtelTrackingError, OtelTrackingRegistry,
    RurrTrackingSpanProcessor,
};
/// Re-export of the OpenTelemetry API crate used by `rurr-otel`.
pub use opentelemetry;
/// Re-export of the OpenTelemetry SDK crate used by `rurr-otel`.
pub use opentelemetry_sdk;
