use rurr_core::application::ApplicationBuilder;

fn main() {
    let _ = ApplicationBuilder::new().with_state_persister(unimplemented!());
}
