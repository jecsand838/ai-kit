use super::common::LiveServiceError;
use serde_json::Value;
use std::ffi::OsStr;
use std::process::Command;
use std::thread::sleep as thread_sleep;
use std::time::{Duration, Instant as StdInstant};

const OTEL_LIVE_PROJECT: &str = "rurr-dev";
const OTEL_LIVE_SERVICE: &str = "otel-lgtm";
const OTEL_LIVE_FILES_DIR: &str = "/data/rurr-live";
const OTEL_LIVE_TRACES_FILE: &str = "/data/rurr-live/traces.jsonl";
const OTEL_LIVE_LOGS_FILE: &str = "/data/rurr-live/logs.jsonl";

fn otel_live_endpoint() -> String {
    format!(
        "docker ps --filter label=com.docker.compose.project={OTEL_LIVE_PROJECT} --filter label=com.docker.compose.service={OTEL_LIVE_SERVICE}"
    )
}

fn otel_live_error(message: impl Into<String>) -> LiveServiceError {
    LiveServiceError::Unavailable {
        service: OTEL_LIVE_SERVICE,
        endpoint: otel_live_endpoint(),
        message: message.into(),
    }
}

fn otel_container_id() -> Result<String, LiveServiceError> {
    let project_filter = format!("label=com.docker.compose.project={OTEL_LIVE_PROJECT}");
    let service_filter = format!("label=com.docker.compose.service={OTEL_LIVE_SERVICE}");
    let output = Command::new("docker")
        .args([
            "ps",
            "--filter",
            project_filter.as_str(),
            "--filter",
            service_filter.as_str(),
            "--format",
            "{{.ID}}",
        ])
        .output()
        .map_err(|error| {
            otel_live_error(format!("failed to locate collector container: {error}"))
        })?;

    if !output.status.success() {
        return Err(otel_live_error(format!(
            "collector container lookup failed: {}",
            String::from_utf8_lossy(&output.stderr).trim()
        )));
    }

    let container_id = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if container_id.is_empty() {
        return Err(otel_live_error(
            "collector container is not running; start ./scripts/dev_up.sh first",
        ));
    }
    Ok(container_id)
}

fn docker_exec_otel_args<I, S>(args: I) -> Result<String, LiveServiceError>
where
    I: IntoIterator<Item = S>,
    S: AsRef<OsStr>,
{
    let container_id = otel_container_id()?;
    let output = Command::new("docker")
        .arg("exec")
        .arg(container_id.as_str())
        .args(args)
        .output()
        .map_err(|error| otel_live_error(format!("docker exec failed: {error}")))?;

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        let stdout = String::from_utf8_lossy(&output.stdout);
        let details = if stderr.trim().is_empty() {
            stdout.trim()
        } else {
            stderr.trim()
        };
        return Err(otel_live_error(format!(
            "collector command failed with status {}: {}",
            output.status, details
        )));
    }

    Ok(String::from_utf8_lossy(&output.stdout).into_owned())
}

fn docker_exec_otel_shell(command: &str) -> Result<String, LiveServiceError> {
    docker_exec_otel_args(["sh", "-lc", command])
}

fn read_otel_json_lines(path: &str) -> Result<Vec<Value>, LiveServiceError> {
    let contents = docker_exec_otel_args(["cat", path])?;
    parse_otel_json_lines_contents(&contents, path)
}

fn parse_otel_json_lines_contents(
    contents: &str,
    path: &str,
) -> Result<Vec<Value>, LiveServiceError> {
    let lines = contents
        .lines()
        .enumerate()
        .filter(|(_, line)| !line.trim().is_empty())
        .collect::<Vec<_>>();
    let last_line_index = lines.last().map(|(index, _)| *index);
    let mut values = Vec::with_capacity(lines.len());

    for (line_index, line) in lines {
        match serde_json::from_str(line) {
            Ok(value) => values.push(value),
            Err(error) if Some(line_index) == last_line_index && error.is_eof() => break,
            Err(error) => {
                return Err(otel_live_error(format!(
                    "invalid OTEL JSON export line in {path}: {error}"
                )))
            }
        }
    }

    Ok(values)
}

/// Clears the collector file-export artifacts used by strict OTEL live tests.
///
/// The collector container must already be running through `./scripts/dev_up.sh`.
pub fn reset_otel_file_exports() -> Result<(), LiveServiceError> {
    docker_exec_otel_shell(&format!(
        "mkdir -p {OTEL_LIVE_FILES_DIR} && : > {OTEL_LIVE_TRACES_FILE} && : > {OTEL_LIVE_LOGS_FILE}"
    ))?;
    Ok(())
}

/// Reads raw collector trace JSONL exports without reshaping OTLP fields.
///
/// Incomplete trailing JSONL records are ignored so callers can poll files while
/// the collector is appending.
pub fn read_otel_trace_exports() -> Result<Vec<Value>, LiveServiceError> {
    read_otel_json_lines(OTEL_LIVE_TRACES_FILE)
}

/// Reads raw collector log JSONL exports without reshaping OTLP fields.
///
/// Incomplete trailing JSONL records are ignored so callers can poll files while
/// the collector is appending.
pub fn read_otel_log_exports() -> Result<Vec<Value>, LiveServiceError> {
    read_otel_json_lines(OTEL_LIVE_LOGS_FILE)
}

/// Raw trace span exported by the OTEL collector file exporter.
#[derive(Clone, Debug, PartialEq)]
pub struct RawOtelTraceSpan {
    /// Resource-level attributes attached to the span export.
    pub resource_attributes: Option<Value>,
    /// Raw OTLP JSON span object as written by the collector.
    pub span: Value,
}

/// Raw log record exported by the OTEL collector file exporter.
#[derive(Clone, Debug, PartialEq)]
pub struct RawOtelLogRecord {
    /// Resource-level attributes attached to the log export.
    pub resource_attributes: Option<Value>,
    /// Raw OTLP JSON log record object as written by the collector.
    pub record: Value,
}

/// Returns an OTLP `AnyValue.stringValue` payload.
pub fn otel_string_any_value(value: &Value) -> Option<&str> {
    value.get("stringValue").and_then(Value::as_str)
}

/// Returns an OTLP `AnyValue.boolValue` payload.
pub fn otel_bool_any_value(value: &Value) -> Option<bool> {
    value.get("boolValue").and_then(Value::as_bool)
}

/// Returns an OTLP `AnyValue.intValue` payload.
pub fn otel_int_any_value(value: &Value) -> Option<&str> {
    value.get("intValue").and_then(Value::as_str)
}

/// Returns an OTLP `AnyValue.doubleValue` payload.
pub fn otel_double_any_value(value: &Value) -> Option<f64> {
    value.get("doubleValue").and_then(Value::as_f64)
}

/// Returns OTLP `AnyValue.arrayValue.values` payloads.
pub fn otel_array_any_values(value: &Value) -> Option<&[Value]> {
    value
        .get("arrayValue")
        .and_then(|array| array.get("values"))
        .and_then(Value::as_array)
        .map(Vec::as_slice)
}

/// Finds a raw OTLP attribute value by key.
pub fn otel_attribute_value<'a>(attributes: &'a Value, key: &str) -> Option<&'a Value> {
    attributes.as_array()?.iter().find_map(|entry| {
        (entry.get("key").and_then(Value::as_str) == Some(key))
            .then(|| entry.get("value"))
            .flatten()
    })
}

/// Finds a resource-level raw OTLP attribute by key when the resource exists.
pub fn otel_resource_attribute_value<'a>(
    attributes: &'a Option<Value>,
    key: &str,
) -> Option<&'a Value> {
    attributes
        .as_ref()
        .and_then(|attributes| otel_attribute_value(attributes, key))
}

/// Flattens collector trace JSONL exports into raw spans.
///
/// Resource attributes are cloned onto each span so assertions can check both
/// resource-level and span-level fields without losing the raw OTLP payload.
pub fn raw_otel_trace_spans(exports: &[Value]) -> Result<Vec<RawOtelTraceSpan>, LiveServiceError> {
    let mut spans = Vec::new();
    OtelEnvelopeProjector::new(OtelSignalSpec::TRACE, exports).for_each_record(|record| {
        spans.push(RawOtelTraceSpan {
            resource_attributes: record.owned_resource_attributes(),
            span: record.record.clone(),
        });
        Ok(())
    })?;
    Ok(spans)
}

/// Flattens collector log JSONL exports into raw log records.
///
/// Resource attributes are cloned onto each record so assertions can correlate
/// log and span resource metadata without normalizing collector output.
pub fn raw_otel_log_records(exports: &[Value]) -> Result<Vec<RawOtelLogRecord>, LiveServiceError> {
    let mut records = Vec::new();
    OtelEnvelopeProjector::new(OtelSignalSpec::LOG, exports).for_each_record(|record| {
        records.push(RawOtelLogRecord {
            resource_attributes: record.owned_resource_attributes(),
            record: record.record.clone(),
        });
        Ok(())
    })?;
    Ok(records)
}

#[derive(Clone, Copy)]
struct OtelSignalSpec {
    signal: &'static str,
    resources: &'static str,
    scopes: &'static str,
    records: &'static str,
}

impl OtelSignalSpec {
    const TRACE: Self = Self {
        signal: "traces",
        resources: "resourceSpans",
        scopes: "scopeSpans",
        records: "spans",
    };

    const LOG: Self = Self {
        signal: "logs",
        resources: "resourceLogs",
        scopes: "scopeLogs",
        records: "logRecords",
    };
}

struct RawOtelRecordRef<'a> {
    resource_attributes: Option<&'a [Value]>,
    record: &'a Value,
}

impl RawOtelRecordRef<'_> {
    fn owned_resource_attributes(&self) -> Option<Value> {
        self.resource_attributes
            .map(|attributes| Value::Array(attributes.to_vec()))
    }
}

struct OtelEnvelopeProjector<'a> {
    spec: OtelSignalSpec,
    exports: &'a [Value],
}

impl<'a> OtelEnvelopeProjector<'a> {
    fn new(spec: OtelSignalSpec, exports: &'a [Value]) -> Self {
        Self { spec, exports }
    }

    fn for_each_record(
        &self,
        mut visit: impl FnMut(RawOtelRecordRef<'a>) -> Result<(), LiveServiceError>,
    ) -> Result<(), LiveServiceError> {
        for (export_index, export) in self.exports.iter().enumerate() {
            let export_path = format!("/{export_index}");
            ensure_otel_object(self.spec.signal, &export_path, export)?;
            let resources =
                required_otel_array(self.spec.signal, &export_path, export, self.spec.resources)?;
            for (resource_index, resource) in resources.iter().enumerate() {
                let resource_path =
                    format!("{export_path}/{}/{resource_index}", self.spec.resources);
                ensure_otel_object(self.spec.signal, &resource_path, resource)?;
                let resource_attributes =
                    otel_resource_attributes(self.spec.signal, &resource_path, resource)?;
                let scopes = required_otel_array(
                    self.spec.signal,
                    &resource_path,
                    resource,
                    self.spec.scopes,
                )?;
                for (scope_index, scope) in scopes.iter().enumerate() {
                    let scope_path = format!("{resource_path}/{}/{scope_index}", self.spec.scopes);
                    ensure_otel_object(self.spec.signal, &scope_path, scope)?;
                    let entries = required_otel_array(
                        self.spec.signal,
                        &scope_path,
                        scope,
                        self.spec.records,
                    )?;
                    for (record_index, entry) in entries.iter().enumerate() {
                        let record_path =
                            format!("{scope_path}/{}/{record_index}", self.spec.records);
                        ensure_otel_object(self.spec.signal, &record_path, entry)?;
                        visit(RawOtelRecordRef {
                            resource_attributes,
                            record: entry,
                        })?;
                    }
                }
            }
        }
        Ok(())
    }
}

fn otel_envelope_error(
    signal: &'static str,
    path: impl Into<String>,
    message: impl Into<String>,
) -> LiveServiceError {
    LiveServiceError::MalformedOtelJsonEnvelope {
        signal,
        path: path.into(),
        message: message.into(),
    }
}

fn ensure_otel_object(
    signal: &'static str,
    path: &str,
    value: &Value,
) -> Result<(), LiveServiceError> {
    if value.is_object() {
        Ok(())
    } else {
        Err(otel_envelope_error(signal, path, "expected JSON object"))
    }
}

fn required_otel_array<'a>(
    signal: &'static str,
    path: &str,
    value: &'a Value,
    key: &str,
) -> Result<&'a [Value], LiveServiceError> {
    let field_path = format!("{path}/{key}");
    match value.get(key) {
        Some(Value::Array(values)) => Ok(values),
        Some(_) => Err(otel_envelope_error(
            signal,
            field_path,
            "expected JSON array",
        )),
        None => Err(otel_envelope_error(
            signal,
            field_path,
            "missing required OTLP array",
        )),
    }
}

fn otel_resource_attributes<'a>(
    signal: &'static str,
    resource_path: &str,
    resource_spans_or_logs: &'a Value,
) -> Result<Option<&'a [Value]>, LiveServiceError> {
    let Some(resource) = resource_spans_or_logs.get("resource") else {
        return Ok(None);
    };
    let resource_object_path = format!("{resource_path}/resource");
    ensure_otel_object(signal, &resource_object_path, resource)?;
    match resource.get("attributes") {
        Some(Value::Array(attributes)) => Ok(Some(attributes)),
        Some(_) => Err(otel_envelope_error(
            signal,
            format!("{resource_object_path}/attributes"),
            "expected JSON array",
        )),
        None => Ok(Some(&[])),
    }
}

/// Finds a span-level raw OTLP attribute by key.
pub fn otel_span_attribute<'a>(span: &'a Value, key: &str) -> Option<&'a Value> {
    span.get("attributes")
        .and_then(|attributes| otel_attribute_value(attributes, key))
}

/// Finds a log-record-level raw OTLP attribute by key.
pub fn otel_log_attribute<'a>(record: &'a Value, key: &str) -> Option<&'a Value> {
    record
        .get("attributes")
        .and_then(|attributes| otel_attribute_value(attributes, key))
}

/// Polls raw collector trace/log exports until the matcher returns a value.
///
/// The matcher receives flattened raw spans and log records on each poll. Read
/// errors are returned to the caller so live-test failures preserve collector
/// diagnostics.
///
/// # Examples
///
/// ```no_run
/// // This reads Docker-backed collector files started by `./scripts/dev_up.sh`,
/// // so it is compile-checked rather than run by ordinary doctests.
/// use rurr_testkit::live_services::wait_for_raw_otel_exports;
/// use std::time::Duration;
///
/// let span_name = wait_for_raw_otel_exports(Duration::from_secs(5), "span exported", |spans, _logs| {
///     spans.into_iter().find_map(|span| {
///         span.span
///             .get("name")
///             .and_then(serde_json::Value::as_str)
///             .map(str::to_string)
///             .filter(|name| name == "docs-span")
///     })
/// })?;
/// assert_eq!(span_name, "docs-span");
/// # Ok::<(), rurr_testkit::LiveServiceError>(())
/// ```
pub fn wait_for_raw_otel_exports<T>(
    timeout_duration: Duration,
    failure_message: &str,
    mut find: impl FnMut(Vec<RawOtelTraceSpan>, Vec<RawOtelLogRecord>) -> Option<T>,
) -> Result<T, LiveServiceError> {
    let deadline = StdInstant::now() + timeout_duration;

    loop {
        if StdInstant::now() >= deadline {
            return Err(otel_live_error(failure_message));
        }

        let spans = raw_otel_trace_spans(&read_otel_trace_exports()?)?;
        let logs = raw_otel_log_records(&read_otel_log_exports()?)?;

        if let Some(found) = find(spans, logs) {
            return Ok(found);
        }

        thread_sleep(Duration::from_millis(250));
    }
}

#[cfg(test)]
mod tests {
    use super::{
        otel_live_endpoint, otel_resource_attribute_value, parse_otel_json_lines_contents,
        raw_otel_log_records, raw_otel_trace_spans, read_otel_json_lines, reset_otel_file_exports,
        wait_for_raw_otel_exports, LiveServiceError, RawOtelTraceSpan, OTEL_LIVE_FILES_DIR,
        OTEL_LIVE_SERVICE,
    };
    use crate::live_services::common::{unique_live_suffix, ProbeSchedule, ServiceProbe};
    use crate::require_check_live_tests;
    use std::time::Duration;

    #[test]
    fn parse_otel_json_lines_contents_reads_complete_jsonl_records() {
        let values = parse_otel_json_lines_contents("{\"one\":1}\n{\"two\":2}\n", "/tmp/test")
            .expect("valid OTEL JSONL should parse");

        assert_eq!(values.len(), 2);
        assert_eq!(values[0]["one"], serde_json::json!(1));
        assert_eq!(values[1]["two"], serde_json::json!(2));
    }

    #[test]
    fn parse_otel_json_lines_contents_ignores_truncated_final_line() {
        let values = parse_otel_json_lines_contents("{\"one\":1}\n{\"two\":", "/tmp/test")
            .expect("truncated final line should be ignored for this poll");

        assert_eq!(values.len(), 1);
        assert_eq!(values[0]["one"], serde_json::json!(1));
    }

    #[test]
    fn parse_otel_json_lines_contents_rejects_malformed_middle_line() {
        let error =
            parse_otel_json_lines_contents("{\"one\":1}\nnot-json\n{\"two\":2}\n", "/tmp/test")
                .expect_err("malformed middle line should fail");

        assert!(
            error.to_string().contains("invalid OTEL JSON export line"),
            "unexpected parser error: {error}"
        );
    }

    #[test]
    fn parse_otel_json_lines_contents_rejects_non_eof_final_syntax_error() {
        let error = parse_otel_json_lines_contents("{\"one\":1}\n{\"two\":}\n", "/tmp/test")
            .expect_err("final syntax error should fail");

        assert!(
            error.to_string().contains("invalid OTEL JSON export line"),
            "unexpected parser error: {error}"
        );
    }

    #[test]
    fn read_otel_json_lines_fails_closed_for_missing_collector_file() {
        require_check_live_tests!();

        let path = format!(
            "{OTEL_LIVE_FILES_DIR}/missing-{}.jsonl",
            unique_live_suffix("otel_missing_file")
        );
        let error =
            read_otel_json_lines(&path).expect_err("missing collector files must fail closed");

        assert!(
            matches!(
                &error,
                LiveServiceError::Unavailable {
                    service,
                    endpoint,
                    message,
                } if service == &OTEL_LIVE_SERVICE
                    && endpoint == &otel_live_endpoint()
                    && message.contains("collector command failed")
                    && message.contains(&path)
            ),
            "unexpected missing-file error: {error}"
        );

        reset_otel_file_exports().expect("collector file exports should reset after proof");
    }

    #[test]
    fn raw_otel_trace_spans_validates_envelope_paths() {
        let error = raw_otel_trace_spans(&[serde_json::json!({
            "resourceSpans": [{
                "resource": {"attributes": []},
                "scopeSpans": [{"spans": {}}]
            }]
        })])
        .expect_err("non-array spans field should fail");

        assert!(matches!(
            error,
            LiveServiceError::MalformedOtelJsonEnvelope {
                signal: "traces",
                ref path,
                ref message,
            } if path == "/0/resourceSpans/0/scopeSpans/0/spans"
                && message.contains("expected JSON array")
        ));
    }

    #[test]
    fn raw_otel_log_records_rejects_non_object_records() {
        let error = raw_otel_log_records(&[serde_json::json!({
            "resourceLogs": [{
                "scopeLogs": [{"logRecords": [false]}]
            }]
        })])
        .expect_err("non-object log record should fail");

        assert!(matches!(
            error,
            LiveServiceError::MalformedOtelJsonEnvelope {
                signal: "logs",
                ref path,
                ref message,
            } if path == "/0/resourceLogs/0/scopeLogs/0/logRecords/0"
                && message.contains("expected JSON object")
        ));
    }

    #[test]
    fn raw_otel_projection_preserves_missing_resource_as_absence() {
        let spans = raw_otel_trace_spans(&[serde_json::json!({
            "resourceSpans": [{
                "scopeSpans": [{"spans": [{"name": "span"}]}]
            }]
        })])
        .expect("missing resource is optional");

        assert_eq!(
            spans,
            vec![RawOtelTraceSpan {
                resource_attributes: None,
                span: serde_json::json!({"name": "span"}),
            }]
        );
    }

    #[test]
    fn raw_otel_projection_preserves_empty_resource_attributes_array() {
        let spans = raw_otel_trace_spans(&[serde_json::json!({
            "resourceSpans": [{
                "resource": {},
                "scopeSpans": [{"spans": [{"name": "span"}]}]
            }]
        })])
        .expect("resource without attributes is valid");

        assert_eq!(
            otel_resource_attribute_value(&spans[0].resource_attributes, "service.name"),
            None
        );
        assert_eq!(spans[0].resource_attributes, Some(serde_json::json!([])));
    }

    #[test]
    fn wait_for_raw_otel_exports_returns_timeout_error() {
        let error = wait_for_raw_otel_exports(
            Duration::ZERO,
            "no matching OTEL exports",
            |_, _| None::<()>,
        )
        .expect_err("zero timeout should return a typed timeout");

        assert!(matches!(
            &error,
            LiveServiceError::Unavailable {
                service,
                endpoint,
                message,
            } if service == &OTEL_LIVE_SERVICE
                && endpoint == &otel_live_endpoint()
                && message.contains("no matching OTEL exports")
        ));
    }

    #[test]
    fn service_probe_sync_reports_timeout() {
        let probe = ServiceProbe::new(
            "otel-test",
            "in-memory",
            ProbeSchedule::new(Duration::ZERO, Duration::ZERO, Duration::ZERO),
        );
        let error = probe
            .retry_sync(|| Err("still unavailable".to_string()))
            .expect_err("zero timeout should surface the probe failure");

        assert!(matches!(
            error,
            LiveServiceError::Unavailable {
                service: "otel-test",
                ref endpoint,
                ref message,
            } if endpoint == "in-memory" && message.contains("still unavailable")
        ));
    }
}
