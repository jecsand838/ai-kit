---
name: use-rust-best-practices-architecture
description: "Apply this when creating or restructuring Rust packages, workspaces, crates, modules, lib.rs/main.rs boundaries, target layout, or test placement. Use it when deciding whether to add a new crate or extend an existing one, when choosing between src/bin and a separate package, when replacing outdated module layouts, and when organizing code to minimize clone-heavy flows and borrow-checker friction."
---

# Rust architecture best practices

Use this skill when the task changes project layout, crate boundaries, module structure, binary/library boundaries, or test placement.

## When to use

Use it when the task:

- creates a new Rust package or workspace
- restructures modules or folders
- asks whether to add a new crate
- asks where to place unit, integration, doctest, or e2e tests
- asks how to make `main.rs` / `lib.rs` boundaries cleaner
- needs clone-minimizing, borrow-checker-friendly architecture guidance

## Do not use this skill alone when

- the task is mostly about test implementation details → also load `$use-rust-best-practices-testing`
- the task is mostly about trait/generic/error/lifetime design → also load `$use-rust-best-practices-abstractions`
- the task is mostly about async runtime/task orchestration → also load `$use-rust-best-practices-async`

## Workflow

1. Keep binaries thin and move reusable behavior into library crates or `lib.rs` modules.
2. Organize by **functional domain and behavior**, not by vague buckets like `helpers`, `misc`, or `common`.
3. Prefer modern file paths (`foo.rs` and `foo/bar.rs`) over widespread `mod.rs`.
4. Add a new crate only when it introduces a real ownership, dependency, deployment, reuse, or release boundary.
5. Do not add macro layers to paper over architectural duplication; extract owned domain structs,
   enum-backed closed sets, methods, or real trait boundaries instead.
6. Put tests at the narrowest level that still exercises the behavior you need.

## Default rules

- Prefer one coherent domain crate over many tiny pseudo-layer crates.
- Use `src/bin/` before introducing a separate package for small extra binaries that share the same domain and dependencies.
- Use `examples/` for runnable samples, not for core business logic.
- Use `benches/` only for benchmark targets.
- Move ownership transitions to natural boundaries: parsing, persistence, network transport, and task spawning.

## Load these references directly when needed

- `references/architecture.md` — crate roots, target layout, workspaces, module layout, crate-splitting, test placement, and clone-minimizing architecture patterns.

## Load these templates when useful

- `assets/templates/workspace-root/Cargo.toml`
- `assets/templates/thin-lib-bin/src/lib.rs`
- `assets/templates/thin-lib-bin/src/main.rs`

## Companion skills

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-async`
