---
name: rurr-delete-first-refactor-plan
description: "Use when turning a Rurr reduction audit, branch-diff cleanup audit, or operator cleanup brief into a decision-complete, TDD-oriented, delete-first refactor plan, or implementing an approved delete-first Rurr refactor plan with strict red-test-first slices, immediate legacy deletion, structural completion checks, manifest handling, and Burr parity constraints."
---

# Rurr Delete-First Refactor Plan

Use this skill when the user wants a concrete plan for a large reductive refactor in Rurr or wants an approved delete-first refactor plan implemented. Use `$rurr-resolve-review-findings` instead for implementation bugs found by Codex `/review`.

## Quick start

Load, in order:

- the current audit, branch-diff audit, approved plan, or prior findings, if present
- `README.md`
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- relevant Burr source under `tools/burr_oracle/vendor/apache-burr/`

Load the full Rust best-practices bundle when the plan spans runtime, tracking, persistence, macros, or gates:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-dependencies-platforms`

Name the relevant Rurr guardrail skill in each phase that touches streaming/session behavior, anchored filesystem, persistence adapters, proc macros, structural completion, or skill-catalog changes.

## When to use

Use it when the task:

- asks for a large reductive refactor or delete pass plan
- asks to turn a branch-diff cleanup audit into implementation phases
- asks to cover every previously identified reduction target
- needs explicit API removals, type removals, TDD order, and gate order before implementation
- needs a one-batch or follow-on cleanup plan with clear completion criteria
- asks to implement an approved delete-first refactor plan

Do not use it for concrete Codex `/review` bug-fix findings unless the review finding itself asks for a delete-first refactor.

## Workflow

1. Restate the reduction goal in parity terms, not generic cleanup terms.
2. Group the plan by subsystem or behavior, not by file inventory.
3. Make deletions explicit: old crates, modules, helper families, wrapper types, and compatibility layers.
4. Define the public API and type fallout that the implementation must remove.
5. Specify the red-test-first development order for each behavior-sensitive phase, including the named strict proof lane when external/provider behavior is touched.
6. Require struct/method/enum/trait refactors for duplication; reject helper macros and macro
   helper crates as the cleanup mechanism.
7. Name the subsystem guardrail skills that govern each phase.
8. Specify the narrow-gate order, structural completion checks, and final repo acceptance gates.
9. State what must still exist behaviorally and what must not still exist structurally.
10. Call out where explicit `Unsupported`, `NotYetImplemented`, or typed configuration/startup errors are the correct replacement for removed invented behavior.

## Implementation Phase

Use this phase when the user asks to implement an approved delete-first refactor plan or clicks Implement from a Plan mode result.

1. Load the approved refactor plan, then the guardrails and compatibility docs named above before editing.
2. If the task targets `docs/refactors/burr-parity-remediation/`, obey `AGENTS.md`, `TASKS_PROGRESS.md`, and that remediation README before choosing the active phase.
3. Add or enable the failing test first when behavior changes are involved.
4. Implement one subsystem slice at a time.
5. Delete the old path in the same slice once the replacement compiles and the narrow test passes.
6. Run narrow gates before expanding to the next slice.
7. Run structural completion checks before broad closeout gates and treat failures as implementation blockers.
8. Refresh generated manifests with `./scripts/fix_manifest_freshness.sh` when needed.
9. Use the temp-index gate flow with `GIT_INDEX_FILE=/tmp/rurr-check.index` when new tracked files affect the publishable-source or private-git contract.
10. Use `$rurr-gate-closeout` for final gate selection and truthful final reporting.

## Output contract

Produce a decision-complete plan with:

- a short summary
- grouped implementation changes
- important API or type removals
- TDD, structural-check, and gate order
- subsystem guardrail skills named per phase
- assumptions and defaults
- explicit "incomplete if these old layers still exist" criteria

When the client supports special plan rendering, wrap the final plan in `<proposed_plan>`.

## Default rules

- Prefer delete-first wording over migration wording.
- Do not keep shims, deprecated re-exports, compatibility aliases, or dual constructors unless Burr parity explicitly requires them.
- Do not use macros to make a reduction look smaller; design real domain structures and methods
  that delete the duplication.
- Do not replace deleted behavior with synthetic fallbacks, pass-shaping live tests, or local-only
  proof for provider/backend semantics.
- Cover every named cleanup target from the audit or user brief; do not silently drop one.
- Include manifest freshness, generated snapshot fallout, structural completion checks, and publishable-source fallout when the refactor changes tracked file layout.
- Delete legacy paths immediately during implementation; do not leave transitional wrappers behind.
- Count the pass as incomplete if required structural checks still fail, even when tests are green.
- Count success by removed legacy structure, not by "green gates only."
- Prefer explicit unsupported/unimplemented/configuration errors when the honest post-deletion
  state is "not implemented" rather than "fallback kept."
- When implementing, report what changed, what legacy structure was deleted, gates run, structural checks, and any residual gaps.

## Do not use this skill alone when

- the user still needs a current branch diff audit: also use `$rurr-branch-diff-reduction-audit`
- the user still needs a workspace or subsystem reduction ranking: also use `$rurr-burr-parity-reduction-audit`
- the plan depends on a disputed subsystem-level Burr comparison: also use `$rurr-burr-source-parity-walk`
- the user is asking for the next residual cleanup after a partial pass: also use `$rurr-follow-up-reduction-pass`
- the task is only final verification after implementation: also use `$rurr-gate-closeout`
