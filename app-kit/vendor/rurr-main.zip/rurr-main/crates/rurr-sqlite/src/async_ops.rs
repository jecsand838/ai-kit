use super::{
    default_async_pool_options, map_sqlx_error,
    schema::normalize_database_url,
    shared::{connection_closed_error, SqliteShared},
    AsyncSqlitePersister, PersistedStateData, PersistedStateStatus, PersistenceError,
    SqlitePersisterConfig, OP_SQLITE_CONNECT_FAILED, OP_STATE_SERIALIZATION_FAILED,
};
use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_persistence::{AsyncBaseStateLoader, AsyncBaseStateSaver};
use rurr_persistence::{
    AsyncSqlxPersistenceCore, InitializationHint, PersistedStateSaveRequest, SqliteDialect,
};
use serde_json::Value;
use sqlx::sqlite::SqliteConnectOptions;
use std::str::FromStr;
use std::sync::atomic::AtomicBool;
use std::sync::Arc;

impl AsyncSqlitePersister {
    /// Creates a lazy async SQLite persister from a serialized config value.
    pub fn new(config: SqlitePersisterConfig) -> Result<Self, PersistenceError> {
        let database_url = normalize_database_url(&config.database);
        let connect_options = SqliteConnectOptions::from_str(&database_url).map_err(|_| {
            PersistenceError::UnsupportedOperation {
                operation: OP_SQLITE_CONNECT_FAILED,
            }
        })?;

        Ok(Self {
            config: config.clone(),
            pool: default_async_pool_options()
                .connect_lazy_with(connect_options.create_if_missing(true)),
            shared: SqliteShared::new(config.table_name)?,
            initialized: Arc::new(InitializationHint::new()),
            closed: Arc::new(AtomicBool::new(false)),
        })
    }

    /// Returns the configuration originally used to construct this persister.
    pub fn config(&self) -> SqlitePersisterConfig {
        self.config.clone()
    }

    /// Closes the underlying pool and marks the persister as no longer usable.
    pub async fn close(&self) -> Result<(), PersistenceError> {
        self.shutdown().await
    }

    async fn shutdown(&self) -> Result<(), PersistenceError> {
        self.core().shutdown().await
    }

    fn core(&self) -> AsyncSqlxPersistenceCore<'_, SqliteDialect> {
        AsyncSqlxPersistenceCore::new(
            &self.pool,
            self.shared.async_query_plan(),
            self.shared.table_name(),
            self.shared.migration_sql(),
            self.initialized.as_ref(),
            self.closed.as_ref(),
            connection_closed_error,
        )
    }
}

#[async_trait]
impl AsyncBaseStateSaver for AsyncSqlitePersister {
    async fn initialize(&self) -> Result<(), PersistenceError> {
        self.core().initialize(map_sqlx_error).await
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.core().is_initialized(map_sqlx_error).await
    }

    async fn cleanup(&self) -> Result<(), PersistenceError> {
        self.close().await
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.core()
            .save(
                PersistedStateSaveRequest::new(
                    partition_key,
                    app_id,
                    sequence_id,
                    position,
                    state,
                    status,
                ),
                map_sqlx_error,
                OP_STATE_SERIALIZATION_FAILED,
            )
            .await
    }
}

#[async_trait]
impl AsyncBaseStateLoader for AsyncSqlitePersister {
    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.core()
            .load(partition_key, app_id, sequence_id, map_sqlx_error)
            .await
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        self.core()
            .list_app_ids(partition_key, map_sqlx_error)
            .await
    }
}
