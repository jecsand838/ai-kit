//! Shared helpers for running Burr-oracle parity scenarios against the local
//! Rurr workspace.
//!
//! This crate packages the stable scenario manifest plus a small runner that
//! executes those scenarios against the current checkout. It is primarily used
//! by parity tests, golden regeneration helpers, and audit tooling rather than
//! end-user applications. Scenario outputs remain raw enough for Burr/Rurr
//! comparison; callers should not normalize them into test-only contracts.
//! The support layer records what the oracle scenarios actually produce rather
//! than inventing compatibility behavior for unproven provider or runtime
//! paths.
//!
//! # Examples
//!
//! ```
//! let scenarios = rurr_oracle_test_support::oracle_scenarios();
//! assert!(!scenarios.is_empty());
//! assert_eq!(scenarios[0].id.as_str(), "00_create_only");
//! ```
#![deny(missing_docs)]

/// Scenario implementations used by the oracle runner.
pub mod cases;
mod manifest;
mod runner;

/// Scenario manifest helpers and parsed scenario descriptors.
pub use manifest::{
    burr_oracle_scenarios, oracle_scenarios, BurrOracleScenario, BurrOracleScenarioId,
};
/// Oracle runner entrypoint and result types.
pub use runner::{run_oracle_scenario, ScenarioRunResult};
