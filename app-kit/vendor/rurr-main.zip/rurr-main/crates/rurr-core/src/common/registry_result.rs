use serde_json::Value;

#[doc(hidden)]
pub trait IntoRegistryValueResult: private::Sealed {
    fn into_registry_value_result<E>(
        self,
        wrap_error: impl FnOnce(String) -> E,
    ) -> Result<Value, E>;
}

impl IntoRegistryValueResult for Value {
    fn into_registry_value_result<E>(
        self,
        _wrap_error: impl FnOnce(String) -> E,
    ) -> Result<Value, E> {
        Ok(self)
    }
}

impl<T> IntoRegistryValueResult for Result<Value, T>
where
    T: ToString,
{
    fn into_registry_value_result<E>(
        self,
        wrap_error: impl FnOnce(String) -> E,
    ) -> Result<Value, E> {
        self.map_err(|error| wrap_error(error.to_string()))
    }
}

mod private {
    use serde_json::Value;

    pub trait Sealed {}

    impl Sealed for Value {}

    impl<T> Sealed for Result<Value, T> where T: ToString {}
}
