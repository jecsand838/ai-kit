use rurr_oracle_test_support::{burr_oracle_scenarios, run_oracle_scenario};
use rurr_testkit::test_dir_for_test;
use rurr_tracking_server::schema::burr_compat_version;
use rurr_tracking_server::schema::{
    AnnotationCreate, AnnotationOut, AnnotationUpdate, AppSpecResponse, IndexingJob,
    VersionResponse,
};
use serde_json::{json, Value};
use std::error::Error;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use tempfile::tempdir;

#[test]
fn tracking_golden_matches_oracle_via_python_comparator() -> Result<(), Box<dyn Error>> {
    let repo_root = repo_root()?;
    let goldens_root = repo_root.join("goldens").join("tracking");
    let temp_storage_root = test_dir_for_test()?;

    for definition in burr_oracle_scenarios() {
        let scenario_id = definition.id.as_str();
        let run = run_oracle_scenario(definition, &temp_storage_root)?;
        let expected_dir = goldens_root.join(definition.id.as_str());
        if !expected_dir.exists() {
            return Err(format!(
                "missing oracle golden directory for {} at {}",
                scenario_id,
                expected_dir.display()
            )
            .into());
        }

        compare_tracking_dirs_via_python(scenario_id, &expected_dir, &run.app_dir)?;
    }

    Ok(())
}

#[test]
fn spans_and_attributes_golden_preserves_raw_burr_tracer_optional_input(
) -> Result<(), Box<dyn Error>> {
    let graph_path = repo_root()?
        .join("goldens")
        .join("tracking")
        .join("03_spans_and_attributes")
        .join("graph.json");
    let graph: Value = serde_json::from_slice(&fs::read(graph_path)?)?;
    let traced = graph["actions"]
        .as_array()
        .and_then(|actions| actions.iter().find(|action| action["name"] == "traced"))
        .ok_or_else(|| {
            std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "03_spans_and_attributes golden is missing traced action",
            )
        })?;

    assert_eq!(traced["inputs"], json!([]));
    assert_eq!(traced["optional_inputs"], json!(["__tracer"]));
    let code = traced["code"].as_str().ok_or_else(|| {
        std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "03_spans_and_attributes traced action code is not a string",
        )
    })?;
    assert!(code.contains("def traced(state, __tracer)"));

    Ok(())
}

#[test]
fn tracking_server_payload_models_serialize_to_stable_json_shapes() -> Result<(), Box<dyn Error>> {
    let app_spec = AppSpecResponse {
        backend: "local".to_string(),
        storage_layout_version: "v1".to_string(),
        indexing: false,
        snapshotting: false,
        supports_demos: false,
        supports_annotations: true,
    };
    assert_eq!(
        serde_json::to_string(&app_spec)?,
        r#"{"backend":"local","storage_layout_version":"v1","indexing":false,"snapshotting":false,"supports_demos":false,"supports_annotations":true}"#
    );

    let version = VersionResponse {
        version: burr_compat_version().to_string(),
    };
    assert_eq!(serde_json::to_string(&version)?, r#"{"version":"0.41.0"}"#);

    let annotation_create: AnnotationCreate = serde_json::from_value(json!({
        "span_id": null,
        "step_name": "answer",
        "tags": ["needs-review"],
        "observations": [{
            "data_fields": {
                "note": "looks good",
                "ground_truth": "approved"
            },
            "thumbs_up_thumbs_down": true,
            "data_pointers": [{
                "type": "state_field",
                "field_name": "response",
                "span_id": null
            }]
        }]
    }))?;
    assert_eq!(
        serde_json::to_string(&annotation_create)?,
        r#"{"span_id":null,"step_name":"answer","tags":["needs-review"],"observations":[{"data_fields":{"note":"looks good","ground_truth":"approved"},"thumbs_up_thumbs_down":true,"data_pointers":[{"type":"state_field","field_name":"response","span_id":null}]}]}"#
    );

    let annotation_update: AnnotationUpdate = serde_json::from_value(json!({
        "span_id": "span-1",
        "step_name": "answer",
        "tags": ["updated"],
        "observations": [{
            "data_fields": {
                "note": "updated note"
            },
            "thumbs_up_thumbs_down": false,
            "data_pointers": [{
                "type": "attribute",
                "field_name": "score",
                "span_id": "span-1"
            }]
        }]
    }))?;
    assert_eq!(
        serde_json::to_string(&annotation_update)?,
        r#"{"span_id":"span-1","step_name":"answer","tags":["updated"],"observations":[{"data_fields":{"note":"updated note"},"thumbs_up_thumbs_down":false,"data_pointers":[{"type":"attribute","field_name":"score","span_id":"span-1"}]}]}"#
    );

    let annotation_update_missing_tags: AnnotationUpdate = serde_json::from_value(json!({
        "span_id": "span-2",
        "step_name": "answer",
        "observations": [{
            "data_fields": {
                "note": "missing tags"
            },
            "thumbs_up_thumbs_down": null,
            "data_pointers": []
        }]
    }))?;
    assert_eq!(
        serde_json::to_string(&annotation_update_missing_tags)?,
        r#"{"span_id":"span-2","step_name":"answer","tags":[],"observations":[{"data_fields":{"note":"missing tags"},"thumbs_up_thumbs_down":null,"data_pointers":[]}]}"#
    );

    let annotation_update_null_tags: AnnotationUpdate = serde_json::from_value(json!({
        "span_id": null,
        "step_name": "answer",
        "tags": null,
        "observations": [{
            "data_fields": {
                "note": "null tags"
            },
            "thumbs_up_thumbs_down": true,
            "data_pointers": []
        }]
    }))?;
    assert_eq!(
        serde_json::to_string(&annotation_update_null_tags)?,
        r#"{"span_id":null,"step_name":"answer","tags":[],"observations":[{"data_fields":{"note":"null tags"},"thumbs_up_thumbs_down":true,"data_pointers":[]}]}"#
    );

    let annotation_out: AnnotationOut = serde_json::from_value(json!({
        "span_id": "span-1",
        "step_name": "answer",
        "tags": ["reviewed"],
        "observations": [{
            "data_fields": {
                "note": "looks good"
            },
            "thumbs_up_thumbs_down": true,
            "data_pointers": [{
                "type": "attribute",
                "field_name": "score",
                "span_id": "span-1"
            }]
        }],
        "id": 9,
        "project_id": "demo_project",
        "app_id": "chat-1",
        "partition_key": "pk",
        "step_sequence_id": 5,
        "created": "2026-03-20T00:00:00.000000000Z",
        "updated": "2026-03-20T00:00:01.000000000Z"
    }))?;
    assert_eq!(
        serde_json::to_string(&annotation_out)?,
        r#"{"span_id":"span-1","step_name":"answer","tags":["reviewed"],"observations":[{"data_fields":{"note":"looks good"},"thumbs_up_thumbs_down":true,"data_pointers":[{"type":"attribute","field_name":"score","span_id":"span-1"}]}],"id":9,"project_id":"demo_project","app_id":"chat-1","partition_key":"pk","step_sequence_id":5,"created":"2026-03-20T00:00:00.000000000Z","updated":"2026-03-20T00:00:01.000000000Z"}"#
    );

    let indexing_job: IndexingJob = serde_json::from_value(json!({
        "id": 2,
        "start_time": "2026-03-20T00:00:00.000000000Z",
        "end_time": null,
        "status": "running",
        "records_processed": 0,
        "metadata": {
            "project": "demo_project"
        }
    }))?;
    assert_eq!(
        serde_json::to_string(&indexing_job)?,
        r#"{"id":2,"start_time":"2026-03-20T00:00:00.000000000Z","end_time":null,"status":"running","records_processed":0,"metadata":{"project":"demo_project"}}"#
    );

    Ok(())
}

#[test]
fn tracking_version_surface_is_pinned_to_documented_burr_target() {
    assert_eq!(burr_compat_version(), "0.41.0");
}

fn compare_tracking_dirs_via_python(
    scenario_id: &str,
    expected_dir: &Path,
    actual_dir: &Path,
) -> Result<(), Box<dyn Error>> {
    let staging = tempdir()?;
    let left_root = staging.path().join("left");
    let right_root = staging.path().join("right");
    stage_tracking_dir(&left_root, scenario_id, expected_dir)?;
    stage_tracking_dir(&right_root, scenario_id, actual_dir)?;

    let output = Command::new("python3")
        .arg(compare_tracking_dirs_script()?)
        .arg("--left")
        .arg(&left_root)
        .arg("--right")
        .arg(&right_root)
        .output()?;
    if output.status.success() {
        return Ok(());
    }

    let stdout = String::from_utf8_lossy(&output.stdout);
    let stderr = String::from_utf8_lossy(&output.stderr);
    Err(format!(
        "python tracking comparator failed for {scenario_id}\nstdout:\n{stdout}\nstderr:\n{stderr}"
    )
    .into())
}

fn stage_tracking_dir(root: &Path, scenario_id: &str, source: &Path) -> Result<(), Box<dyn Error>> {
    let staged = root.join(scenario_id);
    fs::create_dir_all(root)?;
    copy_tracking_dir(source, &staged)?;
    Ok(())
}

fn copy_tracking_dir(source: &Path, destination: &Path) -> Result<(), Box<dyn Error>> {
    fs::create_dir_all(destination)?;
    for entry in fs::read_dir(source)? {
        let entry = entry?;
        let source_path = entry.path();
        let destination_path = destination.join(entry.file_name());
        let file_type = entry.file_type()?;
        if file_type.is_dir() {
            copy_tracking_dir(&source_path, &destination_path)?;
        } else if file_type.is_file() {
            fs::copy(&source_path, &destination_path)?;
        } else {
            return Err(format!("unexpected tracking path {}", source_path.display()).into());
        }
    }
    Ok(())
}

fn compare_tracking_dirs_script() -> Result<PathBuf, Box<dyn Error>> {
    Ok(repo_root()?
        .join("tools")
        .join("burr_oracle")
        .join("compare_tracking_dirs.py"))
}

fn repo_root() -> Result<PathBuf, Box<dyn Error>> {
    let crate_root = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    Ok(crate_root.join("../..").canonicalize()?)
}
