use super::step_core::{AsyncStepExecution, SyncStepExecution};
use super::SessionCore;
use crate::action::api::StreamItem;
use crate::application::session::{
    ExecutionLane, ExecutionSessionSettings, ExecutionStart, StartedExecution, SyncLane,
};
use crate::application::{Application, ApplicationError, ExecutionOptions};
use crate::common::drop_finalizer::run_drop_finalizer;
use crate::graph::GraphAction;
use crate::state::State;

/// Preview of the action currently being streamed.
#[derive(Debug, Clone)]
pub struct ExecutedAction {
    action: GraphAction,
    sequence_id: u64,
}

impl ExecutedAction {
    /// Returns the graph action being streamed.
    pub fn action(&self) -> &GraphAction {
        &self.action
    }

    /// Returns the action name.
    pub fn name(&self) -> &str {
        self.action.name()
    }

    /// Returns the reserved sequence id for the action.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }
}

/// Sync step-streaming session that yields one step handle at a time.
///
/// Each call to [`next_step`](Self::next_step) returns a handle that must be
/// drained or dropped before the next step can start. Intermediate stream items
/// do not commit application state; terminal completion commits atomically, and
/// drop/abort paths roll the in-flight step back.
///
/// The session holds the application's mutable borrow for its entire lifetime.
/// That makes Burr's "do not advance the app while streaming" rule a compile-time
/// property in Rust. When constructed with [`ExecutionOptions`], resolved
/// halt controls are stored in the session and applied between streamed steps.
pub struct StreamIterate<'a> {
    state: SessionCore<'a>,
}

impl<'a> StreamIterate<'a> {
    fn new(app: &'a mut Application, start: ExecutionStart) -> Self {
        let started = start.start_sync(app);
        let state = session_from_iterate_start(app, started);
        Self { state }
    }

    /// Aborts the streaming session and rolls back any deferred work.
    ///
    /// Use this when the caller intentionally stops before the graph finishes
    /// and wants any deferred sync abort errors returned immediately.
    pub fn abort(&mut self) -> Result<(), ApplicationError> {
        self.state.close_with_deferred_abort_sync()
    }

    /// Advances to the next action and returns a handle for its streamed items.
    ///
    /// The returned handle borrows this session, which enforces one active
    /// streamed step at a time.
    pub fn next_step<'s>(
        &'s mut self,
    ) -> Result<Option<(ExecutedAction, StreamStepHandle<'s, 'a>)>, ApplicationError> {
        let next_step = self.state.begin_sync_iterate_step()?;

        Ok(next_step.map(|(action, sequence_id, step)| {
            (
                ExecutedAction {
                    action,
                    sequence_id,
                },
                StreamStepHandle {
                    parent: self,
                    execution: Some(step),
                },
            )
        }))
    }
}

impl Drop for StreamIterate<'_> {
    fn drop(&mut self) {
        run_drop_finalizer(|| {
            let _ = self.state.close_with_deferred_abort_sync();
        });
    }
}

/// Sync handle for consuming the items of one streamed step.
///
/// Dropping the handle before terminal completion aborts the step and records
/// any abort error on the parent session so the next operation can report it.
pub struct StreamStepHandle<'s, 'a> {
    parent: &'s mut StreamIterate<'a>,
    execution: Option<SyncStepExecution<'a>>,
}

impl StreamStepHandle<'_, '_> {
    /// Returns the next streamed item for this step.
    pub fn next_item(&mut self) -> Result<Option<StreamItem>, ApplicationError> {
        self.parent
            .state
            .advance_sync_iterate_step(&mut self.execution)
    }

    /// Drains the step and returns its terminal item and committed state.
    ///
    /// This consumes intermediate items lazily and commits only after the
    /// terminal state is produced.
    pub fn get(&mut self) -> Result<(Option<StreamItem>, State), ApplicationError> {
        self.parent
            .state
            .complete_sync_iterate_step(&mut self.execution)
    }
}

impl Iterator for StreamStepHandle<'_, '_> {
    type Item = Result<StreamItem, ApplicationError>;

    fn next(&mut self) -> Option<Self::Item> {
        match self.next_item() {
            Ok(Some(item)) => Some(Ok(item)),
            Ok(None) => None,
            Err(error) => Some(Err(error)),
        }
    }
}

impl Drop for StreamStepHandle<'_, '_> {
    fn drop(&mut self) {
        run_drop_finalizer(|| {
            if let Some(step) = self.execution.take() {
                let (app_result, abort_hook_result) = step.abort_and_take_app_with_hook_result();
                let result = self
                    .parent
                    .state
                    .settle_abort(app_result, abort_hook_result);
                self.parent.state.record_deferred_abort(result);
            }
        });
    }
}

/// Async step-streaming session that yields one step handle at a time.
///
/// Async sessions require explicit [`abort`](Self::abort) or terminal
/// completion when callers need async lifecycle post-hooks to run. Drop remains
/// sync-only and never creates a runtime.
///
/// Like the sync session, this handle keeps exclusive mutable access to the
/// application while it is alive. Resolved halt controls are owned by the
/// session state and checked between streamed steps without draining async
/// streams.
#[must_use]
pub struct AStreamIterate<'a> {
    state: SessionCore<'a>,
}

impl<'a> AStreamIterate<'a> {
    async fn new(app: &'a mut Application, start: ExecutionStart) -> Self {
        let started = start.start_async(app).await;
        let state = session_from_iterate_start(app, started);
        Self { state }
    }

    /// Aborts the async streaming session and rolls back any deferred work.
    ///
    /// This is the explicit async cleanup path. Dropping the session can only
    /// perform synchronous rollback bookkeeping.
    pub async fn abort(&mut self) -> Result<(), ApplicationError> {
        self.state.close_with_deferred_abort_async().await
    }

    /// Advances to the next action and returns an async handle for its streamed
    /// items.
    pub async fn next_step<'s>(
        &'s mut self,
    ) -> Result<Option<(ExecutedAction, AStreamStepHandle<'s, 'a>)>, ApplicationError> {
        let next_step = self.state.begin_async_iterate_step().await?;

        Ok(next_step.map(|(action, sequence_id, step)| {
            (
                ExecutedAction {
                    action,
                    sequence_id,
                },
                AStreamStepHandle {
                    parent: self,
                    execution: Some(step),
                },
            )
        }))
    }
}

impl Drop for AStreamIterate<'_> {
    fn drop(&mut self) {
        self.state.close_session_sync_only();
    }
}

/// Async handle for consuming the items of one streamed step.
///
/// Call [`abort`](Self::abort) to run async abort hooks before dropping the
/// handle. A plain drop performs only sync rollback bookkeeping.
#[must_use]
pub struct AStreamStepHandle<'s, 'a> {
    parent: &'s mut AStreamIterate<'a>,
    execution: Option<AsyncStepExecution<'a>>,
}

impl AStreamStepHandle<'_, '_> {
    /// Returns the next streamed item for this step.
    pub async fn next_item(&mut self) -> Result<Option<StreamItem>, ApplicationError> {
        self.parent
            .state
            .advance_async_iterate_step(&mut self.execution)
            .await
    }

    /// Drains the step and returns its terminal item and committed state.
    ///
    /// Awaiting this method is the normal completion path for async lifecycle
    /// post-hooks attached to the streamed step.
    pub async fn get(&mut self) -> Result<(Option<StreamItem>, State), ApplicationError> {
        self.parent
            .state
            .complete_async_iterate_step(&mut self.execution)
            .await
    }

    /// Aborts the current streamed step.
    ///
    /// Use this instead of dropping the handle when async lifecycle adapters
    /// must observe the abort.
    pub async fn abort(&mut self) -> Result<(), ApplicationError> {
        self.parent
            .state
            .abort_async_iterate_step(&mut self.execution)
            .await
    }
}

impl Drop for AStreamStepHandle<'_, '_> {
    fn drop(&mut self) {
        if let Some(step) = self.execution.take() {
            let result = self
                .parent
                .state
                .settle_abort_sync_only(step.abort_sync_only_and_take_app());
            self.parent.state.record_deferred_abort(result);
        }
    }
}

pub(crate) fn stream_iterate<'a>(
    app: &'a mut Application,
    options: ExecutionOptions,
) -> StreamIterate<'a> {
    StreamIterate::new(
        app,
        ExecutionStart::new(app, ExecutionLane::Sync(SyncLane::Stream), options),
    )
}

pub(crate) async fn astream_iterate<'a>(
    app: &'a mut Application,
    options: ExecutionOptions,
) -> AStreamIterate<'a> {
    AStreamIterate::new(app, ExecutionStart::new(app, ExecutionLane::Async, options)).await
}

fn session_from_iterate_start<'a>(
    app: &'a mut Application,
    started: StartedExecution,
) -> SessionCore<'a> {
    match started {
        StartedExecution::Ready {
            settings,
            execute_guard,
            pending_plan,
        } => SessionCore::new(
            app,
            settings,
            Some(*execute_guard),
            None,
            Some(*pending_plan),
            None,
        ),
        StartedExecution::StartupError { error } => SessionCore::new(
            app,
            ExecutionSessionSettings::default(),
            None,
            None,
            None,
            Some(error),
        ),
    }
}
