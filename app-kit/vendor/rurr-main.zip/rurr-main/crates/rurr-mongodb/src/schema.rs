use mongodb::bson::{doc, Binary, Bson, Document};
use mongodb::options::IndexOptions;
use mongodb::IndexModel;
use rurr_persistence::layout::{
    FIELD_APP_ID, FIELD_CREATED_AT, FIELD_PARTITION_KEY, FIELD_POSITION, FIELD_SEQUENCE_ID,
    FIELD_STATE, FIELD_STATUS,
};
use rurr_persistence::wire as persistence_wire;
use rurr_persistence::{LoadSelector, PersistedStateStatus, PersistenceError};

const OP_SEQUENCE_ID_OUT_OF_RANGE: &str = "sequence_id_out_of_range";
const OP_STATE_SERIALIZATION_FAILED: &str = "state_serialization_failed";

/// Name of the unique index that enforces record identity.
pub const UNIQUE_RECORD_INDEX_NAME: &str = "unique_record";
/// Name of the index used to load the latest record within a partition.
pub const LATEST_PARTITION_INDEX_NAME: &str = "latest_partition";
/// Name of the index used to load the latest record for a specific app.
pub const LATEST_APP_INDEX_NAME: &str = "latest_app";
/// Name of the index used to list known app ids for a partition.
pub const LIST_APP_IDS_INDEX_NAME: &str = "list_app_ids";

type IndexKeysBuilder = fn() -> Document;

const REQUIRED_INDEX_SPECS: [(IndexKeysBuilder, &str, Option<bool>); 4] = [
    (
        unique_record_index_keys,
        UNIQUE_RECORD_INDEX_NAME,
        Some(true),
    ),
    (
        latest_partition_index_keys,
        LATEST_PARTITION_INDEX_NAME,
        None,
    ),
    (latest_app_index_keys, LATEST_APP_INDEX_NAME, None),
    (list_app_ids_index_keys, LIST_APP_IDS_INDEX_NAME, None),
];

/// Namespace for MongoDB persistence operation plans.
pub struct MongoPersistencePlan;

impl MongoPersistencePlan {
    /// Builds the save operation plan.
    pub fn save(
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: &indexmap::IndexMap<String, serde_json::Value>,
        status: PersistedStateStatus,
        created_at: String,
    ) -> Result<MongoSavePlan, PersistenceError> {
        let filter = unique_record_lookup_filter(partition_key, app_id, sequence_id, position)?;
        let document = persisted_document(
            partition_key,
            app_id,
            sequence_id,
            position,
            state,
            status,
            created_at,
        )?;
        Ok(MongoSavePlan { filter, document })
    }

    /// Builds the load operation plan.
    pub fn load(
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<MongoLoadPlan>, PersistenceError> {
        MongoLoadPlan::from_selector(LoadSelector::new(partition_key, app_id, sequence_id)?)
    }

    /// Builds the list-app-ids operation plan.
    pub fn list_app_ids(partition_key: Option<&str>) -> MongoListAppIdsPlan {
        let partition_key = persistence_wire::normalize_partition_key(partition_key);
        MongoListAppIdsPlan {
            pipeline: vec![
                match_stage(partition_filter(partition_key)),
                group_latest_created_at_stage(),
                sort_grouped_app_ids_stage(),
                project_app_id_stage(),
            ],
            hint: LIST_APP_IDS_INDEX_NAME,
        }
    }

    /// Returns the required index models for this backend.
    pub fn index_models() -> Vec<IndexModel> {
        REQUIRED_INDEX_SPECS
            .iter()
            .map(|(keys, name, unique)| named_index(keys(), name, *unique))
            .collect()
    }

    /// Returns whether the provided indexes satisfy this backend's required plan.
    pub fn index_definitions_match(actual_indexes: &[IndexModel]) -> bool {
        let required_indexes = Self::index_models();
        required_indexes.iter().all(|required| {
            actual_indexes
                .iter()
                .any(|actual| index_definition_matches(actual, required))
        })
    }
}

/// MongoDB save command plan.
#[derive(Debug, Clone, PartialEq)]
pub struct MongoSavePlan {
    filter: Document,
    document: Document,
}

impl MongoSavePlan {
    /// Builds the raw MongoDB update command for this save.
    pub fn update_command(&self, collection_name: &str, collection_uuid: &Binary) -> Document {
        doc! {
            "update": collection_name,
            "collectionUUID": Bson::Binary(collection_uuid.clone()),
            "updates": [
                {
                    "q": self.filter.clone(),
                    "u": { "$setOnInsert": self.document.clone() },
                    "upsert": true,
                    "multi": false,
                    "hint": UNIQUE_RECORD_INDEX_NAME,
                }
            ],
            "ordered": true,
        }
    }
}

/// MongoDB single-record load command plan.
#[derive(Debug, Clone, PartialEq)]
pub struct MongoLoadPlan {
    filter: Document,
    sort: Document,
    hint: &'static str,
}

impl MongoLoadPlan {
    fn from_selector(selector: LoadSelector<'_>) -> Result<Option<Self>, PersistenceError> {
        Ok(match selector {
            LoadSelector::NoRecord => None,
            LoadSelector::LatestPartition { partition_key } => Some(Self {
                filter: partition_filter(partition_key),
                sort: latest_partition_sort(),
                hint: LATEST_PARTITION_INDEX_NAME,
            }),
            LoadSelector::LatestApp {
                partition_key,
                app_id,
            } => Some(Self {
                filter: latest_app_filter(partition_key, app_id),
                sort: latest_app_sort(),
                hint: LATEST_APP_INDEX_NAME,
            }),
            LoadSelector::ExactSequence {
                partition_key,
                app_id,
                sequence_id,
            } => Some(Self {
                filter: exact_sequence_lookup_filter(
                    Some(partition_key.as_str()),
                    app_id,
                    sequence_id_i64_to_u64(sequence_id)?,
                )?,
                sort: exact_sequence_sort(),
                hint: LATEST_APP_INDEX_NAME,
            }),
        })
    }

    /// Returns the filter document.
    pub fn filter(&self) -> &Document {
        &self.filter
    }

    /// Returns the sort document.
    pub fn sort(&self) -> &Document {
        &self.sort
    }

    /// Returns the required index hint.
    pub fn hint(&self) -> &'static str {
        self.hint
    }

    /// Builds the raw MongoDB find command for this load.
    pub fn find_command(&self, collection_name: &str, collection_uuid: &Binary) -> Document {
        doc! {
            "find": collection_name,
            "collectionUUID": Bson::Binary(collection_uuid.clone()),
            "filter": self.filter.clone(),
            "sort": self.sort.clone(),
            "hint": self.hint,
            "limit": 1_i32,
            "singleBatch": true,
        }
    }
}

/// MongoDB list-app-ids aggregation plan.
#[derive(Debug, Clone, PartialEq)]
pub struct MongoListAppIdsPlan {
    pipeline: Vec<Document>,
    hint: &'static str,
}

impl MongoListAppIdsPlan {
    /// Returns the aggregation pipeline.
    pub fn pipeline(&self) -> &[Document] {
        &self.pipeline
    }

    /// Builds the raw MongoDB aggregate command for this list operation.
    pub fn aggregate_command(&self, collection_name: &str, collection_uuid: &Binary) -> Document {
        doc! {
            "aggregate": collection_name,
            "collectionUUID": Bson::Binary(collection_uuid.clone()),
            "pipeline": Bson::Array(self.pipeline.iter().cloned().map(Bson::Document).collect()),
            "hint": self.hint,
            "cursor": {},
        }
    }
}

fn sequence_id_i64_to_u64(sequence_id: i64) -> Result<u64, PersistenceError> {
    u64::try_from(sequence_id).map_err(|_| PersistenceError::UnsupportedOperation {
        operation: OP_SEQUENCE_ID_OUT_OF_RANGE,
    })
}

/// Returns the full set of index models required by the MongoDB backend.
pub fn required_index_models() -> Vec<IndexModel> {
    MongoPersistencePlan::index_models()
}

/// Returns `true` when the provided index list satisfies the MongoDB backend
/// contract.
pub fn required_index_definitions_match(actual_indexes: &[IndexModel]) -> bool {
    MongoPersistencePlan::index_definitions_match(actual_indexes)
}

/// Returns the key document for the unique record index.
pub fn unique_record_index_keys() -> Document {
    doc! {
        FIELD_PARTITION_KEY: 1_i32,
        FIELD_APP_ID: 1_i32,
        FIELD_SEQUENCE_ID: 1_i32,
        FIELD_POSITION: 1_i32,
    }
}

/// Returns the key document for the latest-partition index.
pub fn latest_partition_index_keys() -> Document {
    doc! {
        FIELD_PARTITION_KEY: 1_i32,
        FIELD_CREATED_AT: -1_i32,
        FIELD_SEQUENCE_ID: -1_i32,
        FIELD_POSITION: -1_i32,
    }
}

/// Returns the key document for the latest-app index.
pub fn latest_app_index_keys() -> Document {
    doc! {
        FIELD_PARTITION_KEY: 1_i32,
        FIELD_APP_ID: 1_i32,
        FIELD_SEQUENCE_ID: -1_i32,
        FIELD_CREATED_AT: -1_i32,
        FIELD_POSITION: -1_i32,
    }
}

/// Returns the key document for the list-app-ids index.
pub fn list_app_ids_index_keys() -> Document {
    doc! {
        FIELD_PARTITION_KEY: 1_i32,
        FIELD_CREATED_AT: -1_i32,
        FIELD_APP_ID: 1_i32,
    }
}

/// Converts a persisted-state payload into the MongoDB document stored by the
/// backend.
pub fn persisted_document(
    partition_key: Option<&str>,
    app_id: &str,
    sequence_id: u64,
    position: &str,
    state: &indexmap::IndexMap<String, serde_json::Value>,
    status: PersistedStateStatus,
    created_at: String,
) -> Result<Document, PersistenceError> {
    Ok(doc! {
        FIELD_PARTITION_KEY: persistence_wire::normalize_partition_key(partition_key),
        FIELD_APP_ID: app_id,
        FIELD_SEQUENCE_ID: sequence_id_u64_to_i64(sequence_id)?,
        FIELD_POSITION: position,
        FIELD_STATE: persistence_wire::serialize_state_json(state, OP_STATE_SERIALIZATION_FAILED)?,
        FIELD_STATUS: persistence_wire::persisted_status_as_str(status),
        FIELD_CREATED_AT: created_at,
    })
}

/// Builds the filter used to load an exact sequence for a known app id.
pub fn exact_sequence_lookup_filter(
    partition_key: Option<&str>,
    app_id: &str,
    sequence_id: u64,
) -> Result<Document, PersistenceError> {
    Ok(exact_sequence_filter(
        persistence_wire::normalize_partition_key(partition_key),
        app_id,
        sequence_id_u64_to_i64(sequence_id)?,
    ))
}

/// Builds the filter used to detect duplicate records during save.
pub fn unique_record_lookup_filter(
    partition_key: Option<&str>,
    app_id: &str,
    sequence_id: u64,
    position: &str,
) -> Result<Document, PersistenceError> {
    let mut filter = exact_sequence_filter(
        persistence_wire::normalize_partition_key(partition_key),
        app_id,
        sequence_id_u64_to_i64(sequence_id)?,
    );
    filter.insert(FIELD_POSITION, Bson::String(position.to_string()));
    Ok(filter)
}

fn index_definition_matches(actual: &IndexModel, required: &IndexModel) -> bool {
    index_name(actual) == index_name(required)
        && actual.keys == required.keys
        && unique_option_matches(actual, required)
}

fn index_name(index: &IndexModel) -> Option<&str> {
    index
        .options
        .as_ref()
        .and_then(|options| options.name.as_deref())
}

fn unique_option_matches(actual: &IndexModel, required: &IndexModel) -> bool {
    let required_unique = required.options.as_ref().and_then(|options| options.unique);
    let actual_unique = actual.options.as_ref().and_then(|options| options.unique);

    match required_unique {
        Some(true) => actual_unique == Some(true),
        _ => actual_unique != Some(true),
    }
}

fn named_index(keys: Document, name: &str, unique: Option<bool>) -> IndexModel {
    IndexModel::builder()
        .keys(keys)
        .options(
            IndexOptions::builder()
                .name(Some(name.to_string()))
                .unique(unique)
                .build(),
        )
        .build()
}

fn partition_filter(partition_key: String) -> Document {
    doc! { FIELD_PARTITION_KEY: partition_key }
}

fn latest_app_filter(partition_key: String, app_id: &str) -> Document {
    doc! {
        FIELD_PARTITION_KEY: partition_key,
        FIELD_APP_ID: app_id,
    }
}

fn exact_sequence_filter(partition_key: String, app_id: &str, sequence_id: i64) -> Document {
    doc! {
        FIELD_PARTITION_KEY: partition_key,
        FIELD_APP_ID: app_id,
        FIELD_SEQUENCE_ID: sequence_id,
    }
}

fn latest_partition_sort() -> Document {
    doc! {
        FIELD_CREATED_AT: -1_i32,
        FIELD_SEQUENCE_ID: -1_i32,
        FIELD_POSITION: -1_i32,
    }
}

fn latest_app_sort() -> Document {
    doc! {
        FIELD_SEQUENCE_ID: -1_i32,
        FIELD_CREATED_AT: -1_i32,
        FIELD_POSITION: -1_i32,
    }
}

fn exact_sequence_sort() -> Document {
    doc! {
        FIELD_CREATED_AT: -1_i32,
        FIELD_POSITION: -1_i32,
    }
}

fn match_stage(filter: Document) -> Document {
    doc! { "$match": filter }
}

fn group_latest_created_at_stage() -> Document {
    doc! {
        "$group": {
            "_id": format!("${FIELD_APP_ID}"),
            "latest_created_at": {
                "$max": format!("${FIELD_CREATED_AT}"),
            },
        }
    }
}

fn sort_grouped_app_ids_stage() -> Document {
    doc! {
        "$sort": {
            "latest_created_at": -1_i32,
            "_id": 1_i32,
        }
    }
}

fn project_app_id_stage() -> Document {
    doc! {
        "$project": {
            "_id": 0_i32,
            FIELD_APP_ID: "$_id",
        }
    }
}

fn sequence_id_u64_to_i64(sequence_id: u64) -> Result<i64, PersistenceError> {
    i64::try_from(sequence_id).map_err(|_| PersistenceError::UnsupportedOperation {
        operation: OP_SEQUENCE_ID_OUT_OF_RANGE,
    })
}

#[cfg(test)]
mod tests {
    use super::{
        exact_sequence_lookup_filter, latest_app_index_keys, latest_partition_index_keys,
        list_app_ids_index_keys, required_index_definitions_match, required_index_models,
        unique_record_index_keys, unique_record_lookup_filter, MongoPersistencePlan,
        LATEST_APP_INDEX_NAME, LATEST_PARTITION_INDEX_NAME, LIST_APP_IDS_INDEX_NAME,
        UNIQUE_RECORD_INDEX_NAME,
    };
    use indexmap::IndexMap;
    use mongodb::bson::{doc, spec::BinarySubtype, Binary, Bson, Document};
    use mongodb::options::IndexOptions;
    use mongodb::IndexModel;
    use rurr_persistence::{PersistedStateStatus, PersistenceLoadTarget};

    fn collection_uuid() -> Binary {
        Binary {
            subtype: BinarySubtype::Uuid,
            bytes: vec![7; 16],
        }
    }

    fn named_index_model(name: &str, keys: Document, unique: Option<bool>) -> IndexModel {
        IndexModel::builder()
            .keys(keys)
            .options(
                IndexOptions::builder()
                    .name(Some(name.to_string()))
                    .unique(unique)
                    .build(),
            )
            .build()
    }

    fn updates_entry(command: &Document) -> Document {
        command
            .get_array("updates")
            .expect("update command should contain updates")
            .first()
            .and_then(Bson::as_document)
            .cloned()
            .expect("update command should include a document update entry")
    }

    #[test]
    fn raw_find_command_includes_collection_uuid_and_named_hint() {
        let collection_uuid = collection_uuid();
        let plan = MongoPersistencePlan::load(Some("tenant"), None, None)
            .expect("load plan should build")
            .expect("latest partition should produce a query");
        let command = plan.find_command("states", &collection_uuid);

        assert_eq!(command.get_str("find").ok(), Some("states"));
        assert_eq!(
            command.get("collectionUUID"),
            Some(&Bson::Binary(collection_uuid))
        );
        assert_eq!(command.get_document("filter").ok(), Some(plan.filter()));
        assert_eq!(command.get_document("sort").ok(), Some(plan.sort()));
        assert_eq!(
            command.get_str("hint").ok(),
            Some(LATEST_PARTITION_INDEX_NAME)
        );
        assert_eq!(command.get_i32("limit").ok(), Some(1));
        assert_eq!(command.get_bool("singleBatch").ok(), Some(true));
    }

    #[test]
    fn raw_aggregate_command_includes_collection_uuid_and_named_hint() {
        let collection_uuid = collection_uuid();
        let plan = MongoPersistencePlan::list_app_ids(Some("tenant"));
        let command = plan.aggregate_command("states", &collection_uuid);

        assert_eq!(command.get_str("aggregate").ok(), Some("states"));
        assert_eq!(
            command.get("collectionUUID"),
            Some(&Bson::Binary(collection_uuid))
        );
        assert_eq!(command.get_str("hint").ok(), Some(LIST_APP_IDS_INDEX_NAME));
        assert_eq!(
            command
                .get_array("pipeline")
                .expect("aggregate command should contain a pipeline")
                .len(),
            plan.pipeline().len()
        );
    }

    #[test]
    fn raw_update_command_includes_collection_uuid_and_named_hint() {
        let collection_uuid = collection_uuid();
        let plan = MongoPersistencePlan::save(
            Some("tenant"),
            "app_id",
            7,
            "step",
            &IndexMap::new(),
            PersistedStateStatus::Completed,
            "2026-03-18T12:34:56.123456789Z".to_string(),
        )
        .expect("save plan should build");
        let command = plan.update_command("states", &collection_uuid);
        let update = updates_entry(&command);

        assert_eq!(command.get_str("update").ok(), Some("states"));
        assert_eq!(
            command.get("collectionUUID"),
            Some(&Bson::Binary(collection_uuid))
        );
        assert_eq!(
            update.get_document("q").ok(),
            Some(&doc! {
                "partition_key": "tenant",
                "app_id": "app_id",
                "sequence_id": 7_i64,
                "position": "step",
            })
        );
        assert_eq!(update.get_bool("upsert").ok(), Some(true));
        assert_eq!(update.get_bool("multi").ok(), Some(false));
        assert_eq!(update.get_str("hint").ok(), Some(UNIQUE_RECORD_INDEX_NAME));
        assert!(
            update
                .get_document("u")
                .expect("update entry should contain the update document")
                .contains_key("$setOnInsert"),
            "save should insert via $setOnInsert"
        );
    }

    #[test]
    fn schema_helpers_render_expected_indexes_filters_and_load_queries() {
        let index_models = required_index_models();
        let index_names = index_models
            .iter()
            .map(|model| {
                model
                    .options
                    .as_ref()
                    .and_then(|options| options.name.clone())
                    .expect("required index should have a name")
            })
            .collect::<Vec<_>>();

        assert_eq!(
            index_names,
            vec![
                UNIQUE_RECORD_INDEX_NAME.to_string(),
                LATEST_PARTITION_INDEX_NAME.to_string(),
                LATEST_APP_INDEX_NAME.to_string(),
                LIST_APP_IDS_INDEX_NAME.to_string(),
            ]
        );
        assert_eq!(index_models[0].keys, unique_record_index_keys());
        assert_eq!(index_models[1].keys, latest_partition_index_keys());
        assert_eq!(index_models[2].keys, latest_app_index_keys());
        assert_eq!(index_models[3].keys, list_app_ids_index_keys());
        assert_eq!(
            index_models[0]
                .options
                .as_ref()
                .and_then(|options| options.unique),
            Some(true)
        );

        let latest_partition = MongoPersistencePlan::load(Some("tenant"), None, None)
            .expect("latest partition query should build");
        let latest_app = MongoPersistencePlan::load(Some("tenant"), Some("app_id"), None)
            .expect("latest app query should build");
        let exact = MongoPersistencePlan::load(Some("tenant"), Some("app_id"), Some(7))
            .expect("exact query should build");
        let missing_app = MongoPersistencePlan::load(Some("tenant"), None, Some(7))
            .expect("missing-app query should build");

        assert!(latest_partition.is_some());
        assert!(latest_app.is_some());
        assert!(exact.is_some());
        assert!(missing_app.is_none());
        assert_eq!(
            exact_sequence_lookup_filter(Some("tenant"), "app_id", 7)
                .expect("exact lookup filter should build"),
            doc! {
                "partition_key": "tenant",
                "app_id": "app_id",
                "sequence_id": 7_i64,
            }
        );
        assert_eq!(
            unique_record_lookup_filter(Some("tenant"), "app_id", 7, "step")
                .expect("unique record filter should build"),
            doc! {
                "partition_key": "tenant",
                "app_id": "app_id",
                "sequence_id": 7_i64,
                "position": "step",
            }
        );
        assert_eq!(
            MongoPersistencePlan::list_app_ids(Some("tenant"))
                .pipeline()
                .len(),
            4,
            "list_app_ids pipeline should include match, group, sort, and project stages"
        );
    }

    #[test]
    fn duplicate_granularity_includes_position_in_lookup_and_required_unique_index() {
        let filter_a = unique_record_lookup_filter(Some("tenant"), "app_id", 7, "step_a")
            .expect("unique record filter should build");
        let filter_b = unique_record_lookup_filter(Some("tenant"), "app_id", 7, "step_b")
            .expect("unique record filter should build");

        assert_ne!(filter_a, filter_b);
        assert_eq!(filter_a.get_str("position").ok(), Some("step_a"));
        assert_eq!(filter_b.get_str("position").ok(), Some("step_b"));

        let required = required_index_models();
        assert!(required_index_definitions_match(&required));

        let malformed = vec![
            named_index_model(
                UNIQUE_RECORD_INDEX_NAME,
                doc! {
                    "partition_key": 1,
                    "app_id": 1,
                    "sequence_id": 1,
                },
                Some(true),
            ),
            named_index_model(
                LATEST_PARTITION_INDEX_NAME,
                latest_partition_index_keys(),
                None,
            ),
            named_index_model(LATEST_APP_INDEX_NAME, latest_app_index_keys(), None),
            named_index_model(LIST_APP_IDS_INDEX_NAME, list_app_ids_index_keys(), None),
        ];
        assert!(
            !required_index_definitions_match(&malformed),
            "required unique index matching must reject duplicate-record indexes that omit position"
        );
    }

    #[test]
    fn load_without_app_for_sequence_maps_to_none_semantics() {
        let query = MongoPersistencePlan::load(Some("tenant"), None, Some(9))
            .expect("missing-app exact sequence query should build");

        assert!(query.is_none());
    }

    #[test]
    fn persistence_load_target_exact_sequence_query_uses_target_identifiers() {
        let load_target =
            PersistenceLoadTarget::new("source-app", Some("tenant".to_string()), Some(7));
        let query = MongoPersistencePlan::load(
            load_target.partition_key(),
            Some(load_target.app_id()),
            load_target.sequence_id(),
        )
        .expect("exact-sequence query should build from load target")
        .expect("exact-sequence query should exist");

        assert_eq!(
            query.filter(),
            &doc! {
                "partition_key": "tenant",
                "app_id": "source-app",
                "sequence_id": 7_i64,
            }
        );
        assert_eq!(
            query.sort(),
            &doc! {
                "created_at": -1,
                "position": -1,
            }
        );
        assert_eq!(query.hint(), LATEST_APP_INDEX_NAME);
    }

    #[test]
    fn optional_partition_key_normalizes_to_empty_string_in_schema_helpers() {
        assert_eq!(
            exact_sequence_lookup_filter(None, "app_id", 7)
                .expect("exact lookup filter should build"),
            doc! {
                "partition_key": "",
                "app_id": "app_id",
                "sequence_id": 7_i64,
            }
        );
        assert_eq!(
            unique_record_lookup_filter(None, "app_id", 7, "step")
                .expect("unique record filter should build"),
            doc! {
                "partition_key": "",
                "app_id": "app_id",
                "sequence_id": 7_i64,
                "position": "step",
            }
        );

        let pipeline = MongoPersistencePlan::list_app_ids(None).pipeline().to_vec();
        assert_eq!(
            pipeline.first(),
            Some(&doc! {
                "$match": {
                    "partition_key": "",
                }
            }),
            "list_app_ids should match the normalized empty-string partition key"
        );
    }
}
