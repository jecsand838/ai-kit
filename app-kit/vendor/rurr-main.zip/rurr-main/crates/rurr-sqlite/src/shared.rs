use super::{
    schema::{render_migration_sql, validate_table_name},
    PersistenceError, OP_CONNECTION_CLOSED,
};
use rurr_persistence::{closed_connection_error, PersistedStateQueries};

/// Shared query plans and migration text derived from a SQLite table name.
#[derive(Clone)]
pub struct SqliteShared {
    table_name: String,
    sync_query_plan: PersistedStateQueries,
    async_query_plan: PersistedStateQueries,
    migration_sql: String,
}

impl SqliteShared {
    pub(crate) fn new(table_name: impl Into<String>) -> Result<Self, PersistenceError> {
        let table_name = table_name.into();
        validate_table_name(&table_name)?;

        Ok(Self {
            sync_query_plan: PersistedStateQueries::sqlite_sync(&table_name),
            async_query_plan: PersistedStateQueries::sqlite_async(&table_name),
            migration_sql: render_migration_sql(&table_name),
            table_name,
        })
    }

    pub(crate) fn table_name(&self) -> &str {
        self.table_name.as_str()
    }

    pub(crate) fn sync_query_plan(&self) -> &PersistedStateQueries {
        &self.sync_query_plan
    }

    pub(crate) fn async_query_plan(&self) -> &PersistedStateQueries {
        &self.async_query_plan
    }

    pub(crate) fn migration_sql(&self) -> &str {
        self.migration_sql.as_str()
    }
}

/// Returns the standardized error used when a SQLite connection has already
/// been closed.
pub fn connection_closed_error() -> PersistenceError {
    closed_connection_error(OP_CONNECTION_CLOSED)
}
