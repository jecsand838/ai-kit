use super::numeric::{numeric_cmp, numeric_equals};
use crate::value::{coerce_number, is_numeric_like, json_to_eval_value, EvalValue};
use crate::ExprError;
use serde_json::Value;
use std::cmp::Ordering;
use std::collections::BTreeMap;
use std::fmt;

/// Formatting mode for Python-style JSON rendering.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PythonReprMode {
    /// Render every string with Python-style single quotes.
    Standard,
    /// Render top-level strings without quotes for Burr `when(key=value)` names.
    BareStringForEquality,
}

/// Comparison operator supported by Rurr's bounded Python-like evaluator.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ComparisonOperator {
    /// Python `==`.
    Eq,
    /// Python `!=`.
    NotEq,
    /// Python `<`.
    Lt,
    /// Python `<=`.
    LtE,
    /// Python `>`.
    Gt,
    /// Python `>=`.
    GtE,
    /// Python `item in container`.
    In,
    /// Python `item not in container`.
    NotIn,
    /// Burr `when(key__contains=value)`, equivalent to `value in state[key]`.
    Contains,
    /// Python identity-style singleton check for JSON null and booleans.
    Is,
    /// Negated identity-style singleton check for JSON null and booleans.
    IsNot,
}

impl ComparisonOperator {
    const fn metadata(self) -> (&'static str, bool) {
        match self {
            Self::Eq => ("==", false),
            Self::NotEq => ("!=", false),
            Self::Lt => ("<", false),
            Self::LtE => ("<=", false),
            Self::Gt => (">", false),
            Self::GtE => (">=", false),
            Self::In => ("in", true),
            Self::NotIn => ("not in", true),
            Self::Contains => ("contains", true),
            Self::Is => ("is", true),
            Self::IsNot => ("is not", true),
        }
    }

    /// Returns the operator spelling used in expression and condition diagnostics.
    pub const fn symbol(self) -> &'static str {
        self.metadata().0
    }

    /// Returns whether the operator is formatted with spaces around it in rule names.
    pub const fn is_word_operator(self) -> bool {
        self.metadata().1
    }
}

impl fmt::Display for ComparisonOperator {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.symbol())
    }
}

/// Renders a JSON value using Python-style singleton and collection spelling.
///
/// ```
/// use rurr_expr::python_repr;
/// use serde_json::json;
///
/// assert_eq!(python_repr(&json!(null)), "None");
/// assert_eq!(python_repr(&json!({"enabled": true})), "{'enabled': True}");
/// ```
#[must_use]
pub fn python_repr(value: &Value) -> String {
    python_repr_with_mode(value, PythonReprMode::Standard)
}

/// Renders a JSON value using Python-style spelling and the supplied top-level mode.
#[must_use]
pub fn python_repr_with_mode(value: &Value, mode: PythonReprMode) -> String {
    match (mode, value) {
        (PythonReprMode::BareStringForEquality, Value::String(text)) => text.clone(),
        _ => python_repr_standard(value),
    }
}

/// Builds the stable display name for one Burr-style `when(...)` comparison rule.
#[must_use]
pub fn condition_rule_name(key: &str, operator: ComparisonOperator, value: &Value) -> String {
    if operator == ComparisonOperator::Eq {
        return format!(
            "{key}={}",
            python_repr_with_mode(value, PythonReprMode::BareStringForEquality)
        );
    }

    let symbol = operator.symbol();
    let value = python_repr(value);
    if operator.is_word_operator() {
        format!("{key} {symbol} {value}")
    } else {
        format!("{key}{symbol}{value}")
    }
}

fn python_repr_standard(value: &Value) -> String {
    match value {
        Value::Null => "None".to_string(),
        Value::Bool(true) => "True".to_string(),
        Value::Bool(false) => "False".to_string(),
        Value::Number(number) => number.to_string(),
        Value::String(text) => format!("'{}'", escape_python_repr_string(text)),
        Value::Array(items) => {
            let parts: Vec<String> = items.iter().map(python_repr_standard).collect();
            format!("[{}]", parts.join(", "))
        }
        Value::Object(values) => {
            let parts: Vec<String> = values
                .iter()
                .map(|(key, value)| {
                    format!(
                        "'{}': {}",
                        escape_python_repr_string(key),
                        python_repr_standard(value)
                    )
                })
                .collect();
            format!("{{{}}}", parts.join(", "))
        }
    }
}

fn escape_python_repr_string(text: &str) -> String {
    text.replace('\\', "\\\\").replace('\'', "\\'")
}

/// Compares two JSON values using Rurr's bounded Python-like comparison rules.
pub fn compare_json_values(
    left: &Value,
    operator: ComparisonOperator,
    right: &Value,
) -> Result<bool, ExprError> {
    let left = json_to_eval_value(left)?;
    let right = json_to_eval_value(right)?;
    compare_eval_values(&left, operator, &right)
}

/// Compares two already-normalized evaluation values.
pub fn compare_eval_values(
    left: &EvalValue,
    operator: ComparisonOperator,
    right: &EvalValue,
) -> Result<bool, ExprError> {
    match operator {
        ComparisonOperator::Eq => value_equals(left, right),
        ComparisonOperator::NotEq => value_equals(left, right).map(|result| !result),
        ComparisonOperator::Lt => value_ordered_compare(left, right, OrderingExpectation::Less),
        ComparisonOperator::LtE => {
            value_ordered_compare(left, right, OrderingExpectation::LessOrEqual)
        }
        ComparisonOperator::Gt => value_ordered_compare(left, right, OrderingExpectation::Greater),
        ComparisonOperator::GtE => {
            value_ordered_compare(left, right, OrderingExpectation::GreaterOrEqual)
        }
        ComparisonOperator::In => value_contains(right, left),
        ComparisonOperator::NotIn => value_contains(right, left).map(|contains| !contains),
        ComparisonOperator::Contains => value_contains(left, right),
        ComparisonOperator::Is => Ok(value_is(left, right)),
        ComparisonOperator::IsNot => Ok(!value_is(left, right)),
    }
}

pub(crate) fn value_equals(left: &EvalValue, right: &EvalValue) -> Result<bool, ExprError> {
    if is_numeric_like(left) && is_numeric_like(right) {
        return numeric_equals(coerce_number(left)?, coerce_number(right)?);
    }

    match (left, right) {
        (EvalValue::Array(left_items), EvalValue::Array(right_items)) => {
            array_values_equal(left_items, right_items)
        }
        (EvalValue::Object(left_values), EvalValue::Object(right_values)) => {
            object_values_equal(left_values, right_values)
        }
        _ => Ok(left == right),
    }
}

fn array_values_equal(left: &[EvalValue], right: &[EvalValue]) -> Result<bool, ExprError> {
    if left.len() != right.len() {
        return Ok(false);
    }

    for (left_item, right_item) in left.iter().zip(right) {
        if !value_equals(left_item, right_item)? {
            return Ok(false);
        }
    }

    Ok(true)
}

fn object_values_equal(
    left: &BTreeMap<String, EvalValue>,
    right: &BTreeMap<String, EvalValue>,
) -> Result<bool, ExprError> {
    if left.len() != right.len() {
        return Ok(false);
    }

    for (key, left_value) in left {
        let Some(right_value) = right.get(key) else {
            return Ok(false);
        };
        if !value_equals(left_value, right_value)? {
            return Ok(false);
        }
    }

    Ok(true)
}

#[derive(Debug, Clone, Copy)]
enum OrderingExpectation {
    Less,
    LessOrEqual,
    Greater,
    GreaterOrEqual,
}

fn value_ordered_compare(
    left: &EvalValue,
    right: &EvalValue,
    expectation: OrderingExpectation,
) -> Result<bool, ExprError> {
    let ordering = if is_numeric_like(left) && is_numeric_like(right) {
        numeric_cmp(coerce_number(left)?, coerce_number(right)?)?
    } else if let (EvalValue::String(left_text), EvalValue::String(right_text)) = (left, right) {
        left_text.cmp(right_text)
    } else {
        return Err(ExprError::TypeError {
            message: format!("cannot compare values {left:?} and {right:?}"),
        });
    };

    Ok(match expectation {
        OrderingExpectation::Less => ordering == Ordering::Less,
        OrderingExpectation::LessOrEqual => matches!(ordering, Ordering::Less | Ordering::Equal),
        OrderingExpectation::Greater => ordering == Ordering::Greater,
        OrderingExpectation::GreaterOrEqual => {
            matches!(ordering, Ordering::Greater | Ordering::Equal)
        }
    })
}

fn value_contains(container: &EvalValue, item: &EvalValue) -> Result<bool, ExprError> {
    match container {
        EvalValue::String(text) => {
            if let EvalValue::String(pattern) = item {
                Ok(text.contains(pattern))
            } else {
                Err(ExprError::InvalidMembership {
                    message: "left operand must be a string when right operand is a string"
                        .to_string(),
                })
            }
        }
        EvalValue::Array(items) => {
            for candidate in items {
                if value_equals(candidate, item)? {
                    return Ok(true);
                }
            }
            Ok(false)
        }
        EvalValue::Object(values) => {
            if let EvalValue::String(key) = item {
                Ok(values.contains_key(key))
            } else {
                Ok(false)
            }
        }
        _ => Err(ExprError::InvalidMembership {
            message: format!("value {container:?} does not support membership tests"),
        }),
    }
}

fn value_is(left: &EvalValue, right: &EvalValue) -> bool {
    match (left, right) {
        (EvalValue::Null, EvalValue::Null) => true,
        (EvalValue::Bool(left), EvalValue::Bool(right)) => left == right,
        _ => false,
    }
}
