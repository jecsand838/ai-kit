use crate::validate::{is_len_call, validate_expr};
use crate::{ExprAst, ExprError};
use rustpython_parser::{ast, Parse};
use std::collections::HashSet;

/// Parses `expr_str` and validates that it only uses the supported expression subset.
pub fn parse(expr_str: &str) -> Result<ExprAst, ExprError> {
    let expr = ast::Expr::parse(expr_str, "<expr>").map_err(|error| ExprError::Parse {
        message: error.to_string(),
    })?;
    validate_expr(&expr)?;
    Ok(ExprAst { expr })
}

/// Returns the distinct variable names referenced by `ast`, in first-seen order.
pub fn referenced_names(ast: &ExprAst) -> Vec<String> {
    let mut names = Vec::new();
    let mut seen = HashSet::new();
    collect_referenced_names(&ast.expr, &mut names, &mut seen);
    names
}

fn collect_referenced_names(expr: &ast::Expr, names: &mut Vec<String>, seen: &mut HashSet<String>) {
    match expr {
        ast::Expr::Name(node) => push_name(names, seen, node.id.as_str()),
        ast::Expr::BoolOp(node) => {
            for value in &node.values {
                collect_referenced_names(value, names, seen);
            }
        }
        ast::Expr::UnaryOp(node) => collect_referenced_names(&node.operand, names, seen),
        ast::Expr::BinOp(node) => {
            collect_referenced_names(&node.left, names, seen);
            collect_referenced_names(&node.right, names, seen);
        }
        ast::Expr::IfExp(node) => {
            collect_referenced_names(&node.test, names, seen);
            collect_referenced_names(&node.body, names, seen);
            collect_referenced_names(&node.orelse, names, seen);
        }
        ast::Expr::Compare(node) => {
            collect_referenced_names(&node.left, names, seen);
            for comparator in &node.comparators {
                collect_referenced_names(comparator, names, seen);
            }
        }
        ast::Expr::Call(node) => {
            if is_len_call(node) {
                collect_referenced_names(&node.args[0], names, seen);
            }
        }
        ast::Expr::Subscript(node) => {
            collect_referenced_names(&node.value, names, seen);
            match node.slice.as_ref() {
                ast::Expr::Slice(slice) => {
                    if let Some(lower) = &slice.lower {
                        collect_referenced_names(lower, names, seen);
                    }
                    if let Some(upper) = &slice.upper {
                        collect_referenced_names(upper, names, seen);
                    }
                    if let Some(step) = &slice.step {
                        collect_referenced_names(step, names, seen);
                    }
                }
                other => collect_referenced_names(other, names, seen),
            }
        }
        ast::Expr::Attribute(node) => collect_referenced_names(&node.value, names, seen),
        ast::Expr::Constant(_) => {}
        _ => {}
    }
}

fn push_name(names: &mut Vec<String>, seen: &mut HashSet<String>, candidate: &str) {
    if seen.insert(candidate.to_string()) {
        names.push(candidate.to_string());
    }
}
