//! String-dispatch serialization helpers used by state, persistence, and
//! tracking flows.
//!
//! The default serializer preserves ordinary JSON values directly. Tagged
//! objects carrying [`crate::serde::KEY`] are routed through a
//! [`StringDispatch`](crate::serde::StringDispatch) registry so callers can
//! round-trip custom payloads through storage and tracking artifacts without
//! giving up deterministic JSON output.

use crate::common::{cow_registry::CowRegistry, registry_result::IntoRegistryValueResult};
use indexmap::IndexMap;
use serde_json::{Map, Value};
use std::fmt;
use std::sync::Arc;
use thiserror::Error;

/// Dispatch-tag key used by custom serde handlers.
pub const KEY: &str = "__burr_serde__";

type DispatchDeserializer = dyn Fn(&Value) -> Result<Value, SerdeError> + Send + Sync + 'static;

#[derive(Clone, Default)]
/// A string-keyed registry of serde dispatch handlers.
pub struct StringDispatch {
    handlers: IndexMap<String, Arc<DispatchDeserializer>>,
}

impl StringDispatch {
    /// Creates an empty dispatch registry.
    pub fn new() -> Self {
        Self {
            handlers: IndexMap::new(),
        }
    }

    /// Registers a handler and returns the updated registry.
    pub fn with_handler<D>(mut self, key: impl Into<String>, deserializer: D) -> Self
    where
        D: Fn(&Value) -> Result<Value, SerdeError> + Send + Sync + 'static,
    {
        self.register(key, deserializer);
        self
    }

    /// Registers or replaces the handler for a dispatch key.
    pub fn register<D>(&mut self, key: impl Into<String>, deserializer: D)
    where
        D: Fn(&Value) -> Result<Value, SerdeError> + Send + Sync + 'static,
    {
        self.handlers.insert(key.into(), Arc::new(deserializer));
    }

    /// Invokes the handler registered for `key`.
    pub fn call(&self, key: &str, value: &Value) -> Result<Value, SerdeError> {
        let deserializer =
            self.handlers
                .get(key)
                .ok_or_else(|| SerdeError::MissingDispatchKey {
                    key: key.to_string(),
                })?;
        deserializer(value)
    }

    /// Returns the registered dispatch keys in insertion order.
    pub fn keys(&self) -> Vec<String> {
        self.handlers.keys().cloned().collect()
    }
}

impl fmt::Debug for StringDispatch {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("StringDispatch")
            .field("keys", &self.keys())
            .finish()
    }
}

#[derive(Debug, Error, Clone, PartialEq, Eq)]
/// Errors raised while serializing or deserializing custom dispatched values.
pub enum SerdeError {
    /// No handler was registered for the requested dispatch key.
    #[error("no function registered for key: {key}")]
    MissingDispatchKey {
        /// Dispatch key that was requested.
        key: String,
    },
    /// The dispatch tag existed but was not a string.
    #[error("dispatch key '{key_name}' must be a string, got {actual}")]
    InvalidDispatchTagType {
        /// The name of the dispatch tag field.
        key_name: &'static str,
        /// The actual JSON value kind that was encountered.
        actual: String,
    },
    /// The global dispatch registry lock was poisoned.
    #[error("serde dispatch registry lock was poisoned")]
    DispatchRegistryPoisoned,
    /// A registered handler returned an error.
    #[error("serde dispatch handler for '{key}' failed: {message}")]
    DispatchHandlerFailed {
        /// The dispatch key whose handler failed.
        key: String,
        /// The handler-provided error message.
        message: String,
    },
}

/// Serializes a value using the default JSON-preserving representation.
pub fn serialize(value: &Value) -> Value {
    value.clone()
}

/// Deserializes a JSON value, dispatching tagged objects through the provided registry.
pub fn deserialize(value: &Value, dispatch: &StringDispatch) -> Result<Value, SerdeError> {
    match value {
        Value::Array(items) => items
            .iter()
            .map(|item| deserialize(item, dispatch))
            .collect::<Result<Vec<_>, _>>()
            .map(Value::Array),
        Value::Object(map) => {
            if let Some(dispatch_key) = map.get(KEY) {
                let dispatch_key =
                    dispatch_key
                        .as_str()
                        .ok_or_else(|| SerdeError::InvalidDispatchTagType {
                            key_name: KEY,
                            actual: value_kind(dispatch_key).to_string(),
                        })?;
                return dispatch.call(dispatch_key, value);
            }

            let mut out = Map::new();
            for (key, value) in map {
                out.insert(key.clone(), deserialize(value, dispatch)?);
            }
            Ok(Value::Object(out))
        }
        _ => Ok(value.clone()),
    }
}

/// Deserializes a value using the process-global serde dispatch registry.
pub fn deserialize_registered(value: &Value) -> Result<Value, SerdeError> {
    let dispatch = snapshot_registered_deserializers()?;
    deserialize(value, dispatch.as_ref())
}

/// Registers a deserializer in the process-global serde dispatch registry.
pub fn register_serde_deserializer<D, R>(
    key: impl Into<String>,
    deserializer: D,
) -> Result<(), SerdeError>
where
    D: Fn(&Value) -> R + Send + Sync + 'static,
    R: IntoRegistryValueResult,
{
    let key = key.into();
    let wrapped_key = key.clone();
    REGISTERED_DESERIALIZERS.update_by_cloning(
        || SerdeError::DispatchRegistryPoisoned,
        |next| {
            next.register(key, move |value| {
                deserializer(value).into_registry_value_result(|message| {
                    SerdeError::DispatchHandlerFailed {
                        key: wrapped_key.clone(),
                        message,
                    }
                })
            });
        },
    )?;
    Ok(())
}

static REGISTERED_DESERIALIZERS: CowRegistry<StringDispatch> =
    CowRegistry::new(StringDispatch::default);

pub(crate) fn snapshot_registered_deserializers() -> Result<Arc<StringDispatch>, SerdeError> {
    REGISTERED_DESERIALIZERS.snapshot(|| SerdeError::DispatchRegistryPoisoned)
}

fn value_kind(value: &Value) -> &'static str {
    match value {
        Value::Null => "null",
        Value::Bool(_) => "bool",
        Value::Number(number) => {
            if number.is_i64() {
                "i64"
            } else if number.is_u64() {
                "u64"
            } else {
                "f64"
            }
        }
        Value::String(_) => "string",
        Value::Array(_) => "array",
        Value::Object(_) => "object",
    }
}
