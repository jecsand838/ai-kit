use crate::test_support::{
    register_prefixed_string_field_serde, registry_test_guard, unique_registry_name,
    DeleteOnlyPostActionTypingSystem, DeleteOnlyRoundTripCountTypingSystem,
    NoRoundTripSpyTypingSystem, NonNegativeCountTypingSystem, PassthroughTypingSystem,
    RequireKeyTypingSystem, ResumeRoundTripTypingSystem, RoundTripCountTypingSystem,
};
use indexmap::IndexMap;
use rurr_core::state::{
    register_field_serde, DefaultTypingSystem, State, StateError, StateOperation, TypingSystem,
};
use serde_json::{json, Value};
use std::sync::Arc;

use super::support::pairs::{map_from_pairs, state_from_pairs};

fn register_string_field_serde(field_name: &str) {
    register_prefixed_string_field_serde(field_name, "serialized_")
        .expect("field serde registration should succeed");
}

#[test]
fn get_returns_some_for_existing_key() {
    let state = state_from_pairs([("foo", json!("bar"))]);
    assert_eq!(state.get("foo").cloned(), Some(json!("bar")));
}

#[test]
fn get_returns_none_for_missing_key() {
    let state = state_from_pairs([("foo", json!("bar"))]);
    assert_eq!(state.get("baz"), None);
}

#[test]
fn require_missing_key_returns_missing_key_error_with_available_keys() {
    let state = state_from_pairs([
        ("foo", json!("bar")),
        ("__SEQUENCE_ID", json!(3)),
        ("__PRIOR_STEP", json!("load")),
    ]);

    let error = state.require("missing").unwrap_err();
    match &error {
        StateError::MissingKey {
            key,
            available_keys,
        } => {
            assert_eq!(key, "missing");
            assert_eq!(
                available_keys,
                &vec![
                    "foo".to_string(),
                    "__SEQUENCE_ID".to_string(),
                    "__PRIOR_STEP".to_string()
                ]
            );
        }
        other => panic!("expected MissingKey error, got {other:?}"),
    }

    let message = error.to_string();
    assert!(message.contains("missing"));
    assert!(message.contains("foo"));
    assert!(message.contains("__SEQUENCE_ID"));
    assert!(message.contains("__PRIOR_STEP"));
}

#[test]
fn get_or_returns_existing_or_default_value() {
    let state = state_from_pairs([("foo", json!("bar"))]);
    let fallback = json!("fallback");

    assert_eq!(state.get_or("foo", &fallback), &json!("bar"));
    assert_eq!(state.get_or("missing", &fallback), &fallback);
}

#[test]
fn get_or_default_returns_existing_value_or_null() {
    let state = state_from_pairs([("foo", json!("bar"))]);

    assert_eq!(state.get_or_default("foo"), json!("bar"));
    assert_eq!(state.get_or_default("missing"), Value::Null);
}

#[test]
fn get_all_returns_copy_of_state_map() {
    let state = state_from_pairs([("foo", json!("bar")), ("baz", json!("qux"))]);

    let mut copy = state.get_all();
    copy.insert("foo".to_string(), json!("updated"));
    copy.insert("new".to_string(), json!(1));

    assert_eq!(
        state.get_all(),
        IndexMap::from([
            ("foo".to_string(), json!("bar")),
            ("baz".to_string(), json!("qux"))
        ])
    );
}

#[test]
fn contains_key_reports_membership() {
    let state = state_from_pairs([("foo", json!("bar"))]);
    assert!(state.contains_key("foo"));
    assert!(!state.contains_key("missing"));
}

#[test]
fn keys_returns_insertion_ordered_vec() {
    let state = state_from_pairs([
        ("a", json!(1)),
        ("b", json!(2)),
        ("c", json!(3)),
        ("__SEQUENCE_ID", json!(10)),
    ]);

    assert_eq!(
        state.keys(),
        vec![
            "a".to_string(),
            "b".to_string(),
            "c".to_string(),
            "__SEQUENCE_ID".to_string(),
        ]
    );
}

#[test]
fn merge_is_right_biased_and_preserves_ordering() {
    let left = state_from_pairs([
        ("foo", json!("bar")),
        ("baz", json!("qux")),
        ("__SEQUENCE_ID", json!(1)),
    ]);
    let right = state_from_pairs([
        ("foo", json!("override")),
        ("new", json!(99)),
        ("__PRIOR_STEP", json!("run")),
    ]);

    let merged = left.merge(&right).expect("merge should succeed");

    assert_eq!(
        merged.get_all(),
        IndexMap::from([
            ("foo".to_string(), json!("override")),
            ("baz".to_string(), json!("qux")),
            ("__SEQUENCE_ID".to_string(), json!(1)),
            ("new".to_string(), json!(99)),
            ("__PRIOR_STEP".to_string(), json!("run")),
        ])
    );

    assert_eq!(left.get("foo").cloned(), Some(json!("bar")));
    assert_eq!(right.get("foo").cloned(), Some(json!("override")));
}

#[test]
fn subset_returns_requested_order_and_skips_missing_keys() {
    let state = state_from_pairs([("a", json!(1)), ("b", json!(2)), ("c", json!(3))]);

    let subset = state
        .subset(["c", "missing", "a"])
        .expect("subset should succeed");

    assert_eq!(
        subset.get_all(),
        IndexMap::from([("c".to_string(), json!(3)), ("a".to_string(), json!(1))])
    );
}

#[test]
fn internal_dunder_keys_are_treated_as_normal_keys() {
    let state = state_from_pairs([("__SEQUENCE_ID", json!(7)), ("__PRIOR_STEP", json!("prep"))]);

    assert!(state.contains_key("__SEQUENCE_ID"));
    assert!(state.contains_key("__PRIOR_STEP"));
    assert_eq!(state.get("__SEQUENCE_ID").cloned(), Some(json!(7)));
    assert_eq!(state.get("__PRIOR_STEP").cloned(), Some(json!("prep")));
    assert_eq!(
        state.keys(),
        vec!["__SEQUENCE_ID".to_string(), "__PRIOR_STEP".to_string()]
    );

    let error = state.require("missing").unwrap_err();
    let available_keys = match error {
        StateError::MissingKey { available_keys, .. } => available_keys,
        other => panic!("expected MissingKey error, got {other:?}"),
    };
    assert_eq!(
        available_keys,
        vec!["__SEQUENCE_ID".to_string(), "__PRIOR_STEP".to_string()]
    );
}

#[test]
fn state_require_returns_value_for_existing_key() {
    let state = state_from_pairs([("foo", json!("bar"))]);
    assert_eq!(
        state
            .require("foo")
            .expect("state should contain required key"),
        &json!("bar")
    );
}

#[test]
fn state_require_missing_returns_error_with_available_keys_context() {
    let state = state_from_pairs([("foo", json!("bar")), ("__SEQUENCE_ID", json!(3))]);

    let error = state
        .require("missing")
        .expect_err("missing key access should return an error");

    match error {
        StateError::MissingKey {
            key,
            available_keys,
        } => {
            assert_eq!(key, "missing");
            assert!(available_keys.contains(&"foo".to_string()));
            assert!(available_keys.contains(&"__SEQUENCE_ID".to_string()));
        }
        other => panic!("expected MissingKey error, got {other:?}"),
    }
}

#[test]
fn update_overwrites_existing_values_and_appends_new_keys_deterministically() {
    let state = state_from_pairs([("foo", json!("bar")), ("baz", json!("qux"))]);
    let updates = map_from_pairs([("foo", json!("updated")), ("new", json!(3))]);

    let updated = state.update(updates).expect("update should succeed");

    assert_eq!(
        updated.get_all(),
        IndexMap::from([
            ("foo".to_string(), json!("updated")),
            ("baz".to_string(), json!("qux")),
            ("new".to_string(), json!(3)),
        ])
    );
    assert_eq!(state.get("foo"), Some(&json!("bar")));
}

#[test]
fn apply_operation_is_the_primitive_mutation_api() {
    let state = state_from_pairs([("foo", json!("bar")), ("count", json!(1))]);

    let updated = state
        .apply_operation(StateOperation::Update(map_from_pairs([
            ("foo", json!("updated")),
            ("new", json!(3)),
        ])))
        .expect("update operation should succeed");
    let incremented = updated
        .apply_operation(StateOperation::Increment(vec![
            ("count".to_string(), 2),
            ("new".to_string(), -1),
        ]))
        .expect("increment operation should succeed");

    assert_eq!(
        incremented.get_all(),
        IndexMap::from([
            ("foo".to_string(), json!("updated")),
            ("count".to_string(), json!(3)),
            ("new".to_string(), json!(2)),
        ])
    );
}

#[test]
fn append_and_append_many_apply_payloads_in_vector_order_including_duplicates() {
    let state = state_from_pairs([("foo", json!(["start"])), ("bar", json!([1]))]);

    let appended = state
        .append(vec![("foo".to_string(), json!("one"))])
        .expect("append should succeed");
    let appended_many = appended
        .append_many(vec![
            ("foo".to_string(), json!("two")),
            ("bar".to_string(), json!(2)),
            ("foo".to_string(), json!("three")),
            ("baz".to_string(), json!(true)),
        ])
        .expect("append_many should succeed");

    assert_eq!(
        appended_many.get_all(),
        IndexMap::from([
            ("foo".to_string(), json!(["start", "one", "two", "three"])),
            ("bar".to_string(), json!([1, 2])),
            ("baz".to_string(), json!([true])),
        ])
    );
}

#[test]
fn append_returns_error_for_non_array_existing_values() {
    let state = state_from_pairs([("foo", json!("bar"))]);

    let error = state
        .append(vec![("foo".to_string(), json!("baz"))])
        .expect_err("append on non-array should fail");

    match error {
        StateError::NonAppendable { key } => assert_eq!(key, "foo"),
        other => panic!("expected NonAppendable error, got {other:?}"),
    }
}

#[test]
fn extend_and_extend_many_apply_payloads_in_vector_order_including_duplicates() {
    let state = state_from_pairs([("foo", json!(["bar"])), ("baz", json!([1]))]);

    let extended = state
        .extend(vec![("foo".to_string(), vec![json!("qux")])])
        .expect("extend should succeed");
    let extended_many = extended
        .extend_many(vec![
            ("foo".to_string(), vec![json!("zap"), json!("zip")]),
            ("baz".to_string(), vec![json!(2), json!(3)]),
            ("foo".to_string(), vec![json!("final")]),
        ])
        .expect("extend_many should succeed");

    assert_eq!(
        extended_many.get_all(),
        IndexMap::from([
            (
                "foo".to_string(),
                json!(["bar", "qux", "zap", "zip", "final"])
            ),
            ("baz".to_string(), json!([1, 2, 3])),
        ])
    );
}

#[test]
fn extend_returns_error_for_non_array_existing_values() {
    let state = state_from_pairs([("foo", json!("bar"))]);

    let error = state
        .extend(vec![("foo".to_string(), vec![json!("baz"), json!("qux")])])
        .expect_err("extend on non-array should fail");

    match error {
        StateError::NonExtendable { key } => assert_eq!(key, "foo"),
        other => panic!("expected NonExtendable error, got {other:?}"),
    }
}

#[test]
fn increment_and_increment_many_support_i64_and_u64_values_with_duplicate_order() {
    let state = state_from_pairs([("foo", json!(1)), ("bar", json!(u64::MAX - 5))]);

    let incremented = state
        .increment(vec![("foo".to_string(), 2)])
        .expect("increment should succeed");
    let incremented_many = incremented
        .increment_many(vec![
            ("foo".to_string(), 3),
            ("foo".to_string(), -1),
            ("bar".to_string(), 5),
            ("new".to_string(), 4),
            ("new".to_string(), -10),
        ])
        .expect("increment_many should succeed");

    assert_eq!(
        incremented_many.get_all(),
        IndexMap::from([
            ("foo".to_string(), json!(5)),
            ("bar".to_string(), json!(u64::MAX)),
            ("new".to_string(), json!(-6)),
        ])
    );
}

#[test]
fn increment_returns_error_for_non_integer_existing_values() {
    let state = state_from_pairs([("foo", json!("bar"))]);

    let error = state
        .increment(vec![("foo".to_string(), 1)])
        .expect_err("increment on non-integer should fail");

    match error {
        StateError::NonInteger { key } => assert_eq!(key, "foo"),
        other => panic!("expected NonInteger error, got {other:?}"),
    }
}

#[test]
fn increment_returns_integer_overflow_error_instead_of_panicking() {
    let state = state_from_pairs([("foo", json!(u64::MAX))]);

    let error = state
        .increment(vec![("foo".to_string(), 1)])
        .expect_err("increment beyond u64::MAX should fail");

    match error {
        StateError::IntegerOverflow { key } => assert_eq!(key, "foo"),
        other => panic!("expected IntegerOverflow error, got {other:?}"),
    }
}

#[test]
fn wipe_with_delete_removes_requested_keys_and_preserves_remaining_order() {
    let state = state_from_pairs([
        ("a", json!(1)),
        ("b", json!(2)),
        ("c", json!(3)),
        ("d", json!(4)),
    ]);

    let wiped = state
        .wipe(
            Some(vec![
                "b".to_string(),
                "missing".to_string(),
                "d".to_string(),
            ]),
            None,
        )
        .expect("wipe delete should succeed");

    assert_eq!(
        wiped.get_all(),
        IndexMap::from([("a".to_string(), json!(1)), ("c".to_string(), json!(3))])
    );
}

#[test]
fn wipe_with_keep_keeps_requested_keys_in_original_state_order() {
    let state = state_from_pairs([
        ("a", json!(1)),
        ("b", json!(2)),
        ("c", json!(3)),
        ("d", json!(4)),
    ]);

    let wiped = state
        .wipe(
            None,
            Some(vec![
                "d".to_string(),
                "b".to_string(),
                "missing".to_string(),
            ]),
        )
        .expect("wipe keep should succeed");

    assert_eq!(
        wiped.get_all(),
        IndexMap::from([("b".to_string(), json!(2)), ("d".to_string(), json!(4))])
    );
}

#[test]
fn wipe_errors_when_both_delete_and_keep_are_provided() {
    let state = state_from_pairs([("a", json!(1)), ("b", json!(2))]);

    let error = state
        .wipe(Some(vec!["a".to_string()]), Some(vec!["b".to_string()]))
        .expect_err("wipe should reject delete and keep together");

    match error {
        StateError::WipeDeleteAndKeepConflict { delete, keep } => {
            assert_eq!(delete, vec!["a".to_string()]);
            assert_eq!(keep, vec!["b".to_string()]);
        }
        other => panic!("expected wipe conflict error, got {other:?}"),
    }
}

#[test]
fn derived_states_preserve_typing_system_reference() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(PassthroughTypingSystem);
    let state = State::new(map_from_pairs([
        ("foo", json!("bar")),
        ("list", json!(["a"])),
        ("count", json!(1)),
    ]))
    .with_typing_system(Arc::clone(&typing_system))
    .expect("typing system should attach");

    let applied = state
        .apply_operation(StateOperation::Update(map_from_pairs([(
            "foo",
            json!("baz"),
        )])))
        .expect("apply_operation should succeed");
    let updated = state
        .update(IndexMap::from([("new".to_string(), json!(10))]))
        .expect("update should succeed");
    let subset = state
        .subset(["foo", "missing"])
        .expect("subset should succeed");
    let merged = state
        .merge(&state_from_pairs([("other", json!(99))]))
        .expect("merge should succeed");
    let appended = state
        .append(vec![("list".to_string(), json!("b"))])
        .expect("append should succeed");
    let extended = state
        .extend(vec![("list".to_string(), vec![json!("c"), json!("d")])])
        .expect("extend should succeed");
    let incremented = state
        .increment(vec![("count".to_string(), 2)])
        .expect("increment should succeed");
    let wiped = state
        .wipe(None, Some(vec!["foo".to_string(), "count".to_string()]))
        .expect("wipe keep should succeed");

    assert!(Arc::ptr_eq(state.typing_system(), applied.typing_system()));
    assert!(Arc::ptr_eq(state.typing_system(), updated.typing_system()));
    assert!(Arc::ptr_eq(state.typing_system(), subset.typing_system()));
    assert!(Arc::ptr_eq(state.typing_system(), merged.typing_system()));
    assert!(Arc::ptr_eq(state.typing_system(), appended.typing_system()));
    assert!(Arc::ptr_eq(state.typing_system(), extended.typing_system()));
    assert!(Arc::ptr_eq(
        state.typing_system(),
        incremented.typing_system()
    ));
    assert!(Arc::ptr_eq(state.typing_system(), wiped.typing_system()));
}

#[test]
fn wipe_with_none_none_clears_all_keys_without_type_annotations() {
    let state = state_from_pairs([("a", json!(1)), ("b", json!(2))]);

    let wiped = state.wipe(None, None).expect("wipe should succeed");

    assert!(wiped.get_all().is_empty());
}

#[test]
fn update_surfaces_typing_failures_instead_of_panicking() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(NonNegativeCountTypingSystem::default()))
        .expect("typing system should attach");

    let error = state
        .update(IndexMap::from([("count".to_string(), json!(-1))]))
        .expect_err("update should reject invalid typed transition");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_post_action");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn merge_rejects_invalid_typed_state_transitions() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(NonNegativeCountTypingSystem::default()))
        .expect("typing system should attach");

    let error = state
        .merge(&state_from_pairs([("count", json!(-1))]))
        .expect_err("merge should reject invalid typed transition");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn subset_rejects_invalid_typed_state_transitions() {
    let state = State::new(IndexMap::from([
        ("count".to_string(), json!(1)),
        ("foo".to_string(), json!("bar")),
    ]))
    .with_typing_system(Arc::new(RequireKeyTypingSystem::new("count")))
    .expect("typing system should attach");

    let error = state
        .subset(["foo"])
        .expect_err("subset should reject invalid typed transition");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("count"));
        }
        other => panic!("expected typing validation error, got {other:?}"),
    }
}

#[test]
fn with_typing_system_validates_existing_state() {
    let error = state_from_pairs([("foo", json!("bar"))])
        .with_typing_system(Arc::new(RequireKeyTypingSystem::new("count")))
        .expect_err("attaching invalid typing system should fail");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("count"));
        }
        other => panic!("expected typing system validation error, got {other:?}"),
    }
}

#[test]
fn with_typing_system_runs_roundtrip_construct_data_validation() {
    let error = state_from_pairs([("foo", json!("bar"))])
        .with_typing_system(Arc::new(RoundTripCountTypingSystem))
        .expect_err("attaching invalid roundtrip-only typing system should fail");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "construct_data");
            assert!(message.contains("count"));
        }
        other => panic!("expected construct_data typing error, got {other:?}"),
    }
}

#[test]
fn custom_post_action_hooks_do_not_disable_whole_state_validation() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(DeleteOnlyPostActionTypingSystem))
        .expect("typing system should attach");

    let error = state
        .update(IndexMap::from([("count".to_string(), json!(-1))]))
        .expect_err("update should still run whole-state validation");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected validate_state typing error, got {other:?}"),
    }
}

#[test]
fn custom_post_action_hooks_do_not_disable_roundtrip_validation() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(DeleteOnlyRoundTripCountTypingSystem))
        .expect("typing system should attach");

    let error = state
        .update(IndexMap::from([("count".to_string(), json!(-1))]))
        .expect_err("update should still run roundtrip validation");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "construct_data");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected construct_data typing error, got {other:?}"),
    }
}

#[test]
fn overridden_roundtrip_hooks_skip_typed_construction_on_update() {
    let typing_system = NoRoundTripSpyTypingSystem::default();
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(typing_system.clone()))
        .expect("typing system should attach");
    typing_system.reset_counts();

    let updated = state
        .update(IndexMap::from([("count".to_string(), json!(2))]))
        .expect("update should use the overridden roundtrip hook");

    assert_eq!(updated.get("count"), Some(&json!(2)));
    assert_eq!(typing_system.roundtrip_calls(), 1);
    assert_eq!(typing_system.construct_data_calls(), 0);
    assert_eq!(typing_system.construct_state_calls(), 0);
}

#[test]
fn merge_runs_roundtrip_construct_data_validation() {
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::new(RoundTripCountTypingSystem))
        .expect("typing system should attach");

    let error = state
        .merge(&state_from_pairs([("count", json!(-1))]))
        .expect_err("merge should reject invalid roundtrip state");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "construct_data");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected construct_data typing error, got {other:?}"),
    }
}

#[test]
fn subset_runs_roundtrip_construct_data_validation() {
    let state = State::new(IndexMap::from([
        ("count".to_string(), json!(1)),
        ("foo".to_string(), json!("bar")),
    ]))
    .with_typing_system(Arc::new(RoundTripCountTypingSystem))
    .expect("typing system should attach");

    let error = state
        .subset(["foo"])
        .expect_err("subset should reject invalid roundtrip state");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "construct_data");
            assert!(message.contains("count"));
        }
        other => panic!("expected construct_data typing error, got {other:?}"),
    }
}

#[test]
fn deserialize_runs_roundtrip_construct_state_validation() {
    let error = State::deserialize(
        IndexMap::from([
            ("restored".to_string(), json!(true)),
            ("__SEQUENCE_ID".to_string(), json!(7)),
            ("__PRIOR_STEP".to_string(), json!("noop")),
            ("fail_construct_state".to_string(), json!(true)),
        ]),
        Arc::new(ResumeRoundTripTypingSystem),
    )
    .expect_err("deserialize should reject construct_state failures");

    match error {
        StateError::TypingSystem { phase, message } => {
            assert_eq!(phase, "construct_state");
            assert!(message.contains("rebuilding raw state"));
        }
        other => panic!("expected construct_state typing error, got {other:?}"),
    }
}

#[test]
fn field_level_serde_roundtrip_uses_global_registration() {
    let _guard = registry_test_guard();
    let registered_field = unique_registry_name("my_field");
    let plain_field = unique_registry_name("plain_field");
    register_string_field_serde(&registered_field);

    let typing_system: Arc<dyn TypingSystem> = Arc::new(DefaultTypingSystem);
    let state = State::new(IndexMap::from([
        ("foo".to_string(), json!({"hi": "world"})),
        ("baz".to_string(), json!("qux")),
        (registered_field.clone(), json!("testing 123")),
    ]))
    .with_typing_system(Arc::clone(&typing_system))
    .expect("typing system should attach");

    let serialized = state.serialize().expect("serialize should succeed");
    assert_eq!(serialized.get("foo"), Some(&json!({"hi": "world"})));
    assert_eq!(serialized.get("baz"), Some(&json!("qux")));
    assert_eq!(
        serialized.get(&registered_field),
        Some(&json!({"value": "serialized_testing 123"}))
    );

    let plain_state = State::new(IndexMap::from([(
        plain_field.clone(),
        json!("testing 123"),
    )]));
    let plain_serialized = plain_state.serialize().expect("serialize should succeed");
    assert_eq!(
        plain_serialized.get(&plain_field),
        Some(&json!("testing 123"))
    );

    let deserialized =
        State::deserialize(serialized, typing_system).expect("deserialize should succeed");
    assert_eq!(deserialized.get("foo"), Some(&json!({"hi": "world"})));
    assert_eq!(deserialized.get("baz"), Some(&json!("qux")));
    assert_eq!(
        deserialized.get(&registered_field),
        Some(&json!("testing 123"))
    );
}

#[test]
fn state_equality_is_value_based_even_with_distinct_runtime_references() {
    let state_a = State::new(map_from_pairs([("foo", json!("bar")), ("count", json!(3))]))
        .with_typing_system(Arc::new(PassthroughTypingSystem))
        .expect("typing system should attach");
    let state_b = State::new(map_from_pairs([("foo", json!("bar")), ("count", json!(3))]))
        .with_typing_system(Arc::new(DefaultTypingSystem))
        .expect("typing system should attach");

    assert_eq!(state_a, state_b);
}

#[test]
fn state_equality_detects_different_values() {
    let left = state_from_pairs([("foo", json!("bar")), ("count", json!(3))]);
    let right = state_from_pairs([("foo", json!("bar")), ("count", json!(4))]);

    assert_ne!(left, right);
}

#[test]
fn field_level_serializer_must_return_object_or_map() {
    let _guard = registry_test_guard();
    let field_name = unique_registry_name("bad_serializer_field");
    register_field_serde(
        field_name.clone(),
        |value| Value::String(format!("bad_{value}")),
        |value| value.clone(),
    )
    .expect("field serde registration should succeed");
    let state = State::new(IndexMap::from([(field_name.clone(), json!("testing 123"))]));

    let error = state
        .serialize()
        .expect_err("serializer must fail when returning non-object");

    match error {
        StateError::FieldSerializerMustReturnObject { field, actual } => {
            assert_eq!(field, field_name);
            assert_eq!(actual, "string");
        }
        other => panic!("expected FieldSerializerMustReturnObject error, got {other:?}"),
    }
}
