use super::builder::ApplicationError;
use super::context::{ApplicationContext, ParentPointer};
use super::graph_view::ApplicationGraph;
use super::state_meta::{CommittedStateMetadata, PRIOR_STEP_KEY};
use super::RuntimeResources;
use crate::action::ActionTracer;
use crate::graph::{Graph, GraphAction};
use crate::lifecycle::{AsyncLifecycleAdapter, LifecycleAdapterSet, SyncLifecycleAdapter};
use crate::parallelism::ParallelExecutor;
use crate::state::State;
use indexmap::IndexMap;
use rurr_persistence::{StateLoaderRef, StatePersisterRef};
use serde_json::Value;
use std::path::Path;
use std::sync::Arc;

/// Tracking adapter used by applications that emit Burr-compatible tracking events.
///
/// Trackers provide lifecycle adapters instead of writing directly from the
/// execution engine. This keeps core execution provider-neutral while letting
/// local and S3 tracking use the same begin/end/span/stream event model.
pub trait Tracker: Send + Sync {
    /// Returns the synchronous lifecycle adapter lane, when this tracker supports sync execution.
    fn sync_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn SyncLifecycleAdapter>>;

    /// Returns the asynchronous lifecycle adapter lane, when this tracker supports async execution.
    fn async_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn AsyncLifecycleAdapter>>;
}

/// Executable application instance plus its committed state and resources.
///
/// `Application` owns the validated graph, committed state, runtime resources,
/// identifiers, and lifecycle/tracking configuration. Step and streaming APIs
/// mutate the committed state only at action terminal boundaries; dropped or
/// aborted streams roll back through the session guards documented on the
/// streaming handle types.
#[derive(Clone)]
pub struct Application {
    graph: ApplicationGraph,
    state: State,
    app_id: String,
    partition_key: Option<String>,
    parent_pointer: Option<ParentPointer>,
    spawning_parent_pointer: Option<ParentPointer>,
    resources: RuntimeResources,
    is_async_app: bool,
}

#[derive(Clone)]
pub(crate) struct ApplicationConfig {
    pub(crate) graph: Graph,
    pub(crate) state: State,
    pub(crate) app_id: String,
    pub(crate) partition_key: Option<String>,
    pub(crate) parent_pointer: Option<ParentPointer>,
    pub(crate) spawning_parent_pointer: Option<ParentPointer>,
    pub(crate) resources: RuntimeResources,
    pub(crate) is_async_app: bool,
}

/// Output produced by one successful step.
///
/// The `state` field is the committed state after the action has completed and
/// after lifecycle post-hooks have run successfully.
#[derive(Debug, Clone)]
pub struct StepOutput {
    /// Action that executed.
    pub action: GraphAction,
    /// Result payload returned by the action.
    pub result: IndexMap<String, Value>,
    /// Committed application state after the step.
    pub state: State,
    /// Whether execution halted before another action was selected.
    pub halted: bool,
}

/// Output produced by a full run to completion or halt.
///
/// `action` and `result` are `None` when the application has no selectable
/// action at the time the run starts.
#[derive(Debug, Clone)]
pub struct RunOutput {
    /// Last action that executed, when one ran.
    pub action: Option<GraphAction>,
    /// Last result payload produced, when one exists.
    pub result: Option<IndexMap<String, Value>>,
    /// Committed application state at the end of the run.
    pub state: State,
}

impl Application {
    pub(crate) fn new(config: ApplicationConfig) -> Self {
        Self {
            graph: ApplicationGraph::new(config.graph),
            state: config.state,
            app_id: config.app_id,
            partition_key: config.partition_key,
            parent_pointer: config.parent_pointer,
            spawning_parent_pointer: config.spawning_parent_pointer,
            resources: config.resources,
            is_async_app: config.is_async_app,
        }
    }

    /// Returns the read-only application graph view.
    pub fn graph(&self) -> &ApplicationGraph {
        &self.graph
    }

    pub(crate) fn graph_definition(&self) -> &Graph {
        self.graph.as_graph()
    }

    pub(crate) fn state_meta(&self) -> CommittedStateMetadata<'_> {
        CommittedStateMetadata::read(self.state())
    }

    /// Returns the committed application state.
    pub fn state(&self) -> &State {
        &self.state
    }

    /// Returns the application id.
    pub fn uid(&self) -> &str {
        &self.app_id
    }

    /// Returns the partition key, when one exists.
    pub fn partition_key(&self) -> Option<&str> {
        self.partition_key.as_deref()
    }

    /// Returns the persisted parent pointer, when one exists.
    pub fn parent_pointer(&self) -> Option<&ParentPointer> {
        self.parent_pointer.as_ref()
    }

    /// Returns the spawn-time parent pointer, when one exists.
    pub fn spawning_parent_pointer(&self) -> Option<&ParentPointer> {
        self.spawning_parent_pointer.as_ref()
    }

    /// Returns the current graph entrypoint.
    pub fn entrypoint(&self) -> &str {
        self.graph.entrypoint()
    }

    /// Returns the lifecycle hook set configured for the application.
    pub fn hooks(&self) -> &LifecycleAdapterSet {
        self.resources.hooks()
    }

    pub(crate) fn resources(&self) -> &RuntimeResources {
        &self.resources
    }

    /// Returns the tracker, when one is configured.
    pub fn tracker(&self) -> Option<&Arc<dyn Tracker>> {
        self.resources.tracker()
    }

    /// Returns the parallel executor, when one is configured.
    pub fn parallel_executor(&self) -> Option<&Arc<dyn ParallelExecutor>> {
        self.resources.parallel_executor()
    }

    /// Returns whether this application must be driven through async APIs.
    pub fn is_async_app(&self) -> bool {
        self.is_async_app
    }

    /// Returns the committed sequence id, when one exists.
    pub fn sequence_id(&self) -> Result<Option<u64>, ApplicationError> {
        self.state_meta().strict_sequence_id()
    }

    /// Builds the current application context from committed state metadata.
    pub fn context(&self) -> Result<ApplicationContext, ApplicationError> {
        let metadata = self.state_meta();
        let prior_step = metadata
            .strict_validated_prior_step(self.graph_definition())?
            .map(str::to_string);
        Ok(self.build_context(metadata.strict_sequence_id()?, prior_step))
    }

    /// Returns whether another action can be selected from the current state.
    pub fn has_next_action(&self) -> Result<bool, ApplicationError> {
        Ok(self
            .state_meta()
            .strict_next_action_name(self.graph_definition())?
            .is_some())
    }

    /// Removes the recorded prior step so execution restarts from the
    /// entrypoint.
    pub fn reset_to_entrypoint(&mut self) -> Result<(), ApplicationError> {
        let state = self
            .state
            .wipe(Some(vec![PRIOR_STEP_KEY.to_string()]), None)?;
        self.update_state(state)
    }

    /// Replaces the committed application state after validating metadata and
    /// typing constraints.
    pub fn update_state(&mut self, new_state: State) -> Result<(), ApplicationError> {
        let stamped = new_state.with_typing_system(Arc::clone(self.state.typing_system()))?;
        let metadata = CommittedStateMetadata::read(&stamped);
        metadata.strict_sequence_id()?;
        let _ = metadata.strict_next_action_name(self.graph_definition())?;
        self.replace_state(stamped);
        Ok(())
    }

    /// Returns an error if a sync API is used on an async application.
    pub fn validate_correct_async_use(&self) -> Result<(), ApplicationError> {
        if self.is_async_app() {
            return Err(ApplicationError::AsyncApplicationUsedSyncRun);
        }
        Ok(())
    }

    /// Renders the application graph as DOT text and optionally writes a `.dot`
    /// file.
    pub fn visualize(
        &self,
        output_file_path: Option<&Path>,
        write_dot: bool,
    ) -> std::io::Result<String> {
        self.graph.as_graph().visualize(output_file_path, write_dot)
    }

    pub(crate) fn action_tracer_for_action(
        &self,
        action_name: &str,
        action_sequence_id: u64,
    ) -> ActionTracer {
        ActionTracer::active(
            action_name.to_string(),
            action_sequence_id,
            self.uid().to_string(),
            self.partition_key.clone(),
            self.resources.hooks().clone(),
        )
    }

    /// Returns the state persister, when one is configured.
    pub fn state_persister(&self) -> Option<&StatePersisterRef> {
        self.resources.state_persister()
    }

    /// Returns the state initializer, when one is configured.
    pub fn state_initializer(&self) -> Option<&StateLoaderRef> {
        self.resources.state_initializer()
    }

    pub(crate) fn context_for_step(
        &self,
        sequence_id: u64,
        prior_step: Option<&str>,
    ) -> ApplicationContext {
        self.build_context(Some(sequence_id), prior_step.map(str::to_string))
    }

    pub(crate) fn replace_state(&mut self, state: State) {
        self.state = state;
    }

    fn build_context(
        &self,
        sequence_id: Option<u64>,
        prior_step: Option<String>,
    ) -> ApplicationContext {
        ApplicationContext {
            app_id: self.uid().to_string(),
            partition_key: self.partition_key.clone(),
            sequence_id,
            prior_step,
            parent_pointer: self.parent_pointer.clone(),
            spawning_parent_pointer: self.spawning_parent_pointer.clone(),
        }
    }
}
