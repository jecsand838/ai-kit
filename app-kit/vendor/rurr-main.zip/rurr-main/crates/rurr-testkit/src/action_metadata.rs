use rurr_core::action::ActionError;

/// Reusable action metadata fixture for tests that need a named action shape.
///
/// # Examples
///
/// ```
/// use rurr_testkit::action_metadata::NamedActionMetadata;
///
/// let metadata = NamedActionMetadata::from_slices(&["input"], &["output"], &["prompt"])
///     .with_tags(["terminal", "docs"]);
/// let tags: Vec<_> = metadata.tags().iter().map(String::as_str).collect();
/// assert_eq!(tags, ["terminal", "docs"]);
/// ```
#[derive(Debug, Clone, Default)]
pub struct NamedActionMetadata {
    name: Option<String>,
    reads: Vec<String>,
    writes: Vec<String>,
    inputs: Vec<String>,
    tags: Vec<String>,
}

impl NamedActionMetadata {
    /// Builds metadata from borrowed field-name slices.
    pub fn from_slices(reads: &[&str], writes: &[&str], inputs: &[&str]) -> Self {
        Self::from_owned(
            owned_fields(reads),
            owned_fields(writes),
            owned_fields(inputs),
        )
    }

    /// Builds metadata from owned field-name lists.
    pub fn from_owned(reads: Vec<String>, writes: Vec<String>, inputs: Vec<String>) -> Self {
        Self {
            name: None,
            reads,
            writes,
            inputs,
            tags: Vec::new(),
        }
    }

    /// Returns the assigned action name, if present.
    pub fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    /// Returns the declared read set.
    pub fn reads(&self) -> &[String] {
        &self.reads
    }

    /// Returns the declared write set.
    pub fn writes(&self) -> &[String] {
        &self.writes
    }

    /// Returns the declared input set.
    pub fn inputs(&self) -> &[String] {
        &self.inputs
    }

    /// Returns the declared action tags.
    pub fn tags(&self) -> &[String] {
        &self.tags
    }

    /// Returns this metadata with explicit action tags assigned.
    ///
    /// Tags are used by graph tag queries and by `@tag:<tag>` halt-control
    /// contract tests.
    pub fn with_tags<I, T>(mut self, tags: I) -> Self
    where
        I: IntoIterator<Item = T>,
        T: Into<String>,
    {
        self.tags = tags.into_iter().map(Into::into).collect();
        self
    }

    /// Returns a cloned copy of this metadata with a stable name assigned.
    pub fn with_name_cloned(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let attempted_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name,
            });
        }

        let mut copied = self.clone();
        copied.name = Some(attempted_name);
        Ok(copied)
    }
}

fn owned_fields(values: &[&str]) -> Vec<String> {
    values.iter().map(|value| (*value).to_string()).collect()
}
