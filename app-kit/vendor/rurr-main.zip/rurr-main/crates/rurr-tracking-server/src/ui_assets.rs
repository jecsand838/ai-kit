use crate::backend::BackendError;
use crate::ui_fs::{
    normalize_asset_path as normalize_ui_asset_path, validate_asset_request_path,
    NormalizedAssetPath,
};
use rurr_tracking_store::anchored_fs::{OutputRootMode, OutputRootPolicy, PreparedOutputDirectory};
use std::io;
use std::path::Path;

const INDEX_HTML: &str = include_str!("../ui/index.html");
const APP_JS: &[u8] = include_bytes!("../ui/assets/app.js");

/// One embedded UI asset plus the content type needed to serve it.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct EmbeddedAsset {
    /// Raw asset bytes embedded in the binary.
    pub bytes: &'static [u8],
    /// HTTP content type header value for the asset.
    pub content_type: &'static str,
}

/// Returns the embedded UI entrypoint HTML.
///
/// # Examples
///
/// ```rust
/// assert!(rurr_tracking_server::ui_assets::embedded_index_html().contains("<!doctype html>"));
/// ```
pub fn embedded_index_html() -> &'static str {
    INDEX_HTML
}

/// Returns one embedded asset by request path.
///
/// Paths may be given as `app.js`, `/assets/app.js`, or `assets/app.js`.
///
/// # Examples
///
/// ```rust
/// let asset = rurr_tracking_server::ui_assets::embedded_asset("assets/app.js");
/// assert_eq!(
///     asset.map(|asset| asset.content_type),
///     Some("application/javascript; charset=utf-8"),
/// );
/// ```
pub fn embedded_asset(path: &str) -> Option<EmbeddedAsset> {
    let normalized = normalize_ui_asset_path(path).ok()?;
    embedded_asset_for_path(&normalized)
}

fn embedded_asset_for_path(path: &NormalizedAssetPath) -> Option<EmbeddedAsset> {
    match path.as_str() {
        "app.js" => Some(EmbeddedAsset {
            bytes: APP_JS,
            content_type: "application/javascript; charset=utf-8",
        }),
        _ => None,
    }
}

pub(crate) fn resolve_embedded_asset(path: &str) -> Result<EmbeddedAsset, BackendError> {
    let relative_path = validate_asset_request_path(path)?;
    embedded_asset_for_path(&relative_path).ok_or_else(|| BackendError::NotFound {
        resource: format!("asset '{}'", relative_path.as_str()),
    })
}

/// Writes the embedded UI bundle to a prepared output directory.
///
/// # Examples
///
/// ```rust
/// # fn unique_dir() -> std::path::PathBuf {
/// #     let nanos = std::time::SystemTime::now()
/// #         .duration_since(std::time::UNIX_EPOCH)
/// #         .map(|duration| duration.as_nanos())
/// #         .unwrap_or(0);
/// #     std::env::temp_dir().join(format!("rurr-embedded-ui-{nanos}"))
/// # }
/// let out_dir = unique_dir();
/// rurr_tracking_server::ui_assets::write_embedded_bundle(&out_dir)?;
/// assert!(out_dir.join("index.html").exists());
/// assert!(out_dir.join("assets").join("app.js").exists());
/// # std::fs::remove_dir_all(&out_dir)?;
/// # Ok::<(), std::io::Error>(())
/// ```
pub fn write_embedded_bundle(out_dir: &Path) -> io::Result<()> {
    let policy = OutputRootPolicy::new(&[]).allow_system_root_namespace_aliases();
    let out_dir = PreparedOutputDirectory::prepare(
        Path::new("."),
        out_dir,
        "ui bundle output",
        &policy,
        OutputRootMode::CreateOnly,
    )?
    .ensure_exists()?;
    let assets_dir = out_dir.child_dir(Path::new("assets"))?.ensure_exists()?;
    assets_dir
        .child_file(Path::new("app.js"))?
        .write_overwrite(APP_JS)?;
    out_dir
        .child_file(Path::new("index.html"))?
        .write_overwrite(INDEX_HTML.as_bytes())
}
