use proc_macro2::Span;
use syn::parse::{Parse, ParseStream};
use syn::spanned::Spanned;
use syn::{Expr, ExprLit, Ident, Lit, Token};

#[derive(Default)]
pub(crate) struct MacroArgs {
    pub(crate) reads: Vec<String>,
    pub(crate) writes: Vec<String>,
    pub(crate) tags: Vec<String>,
}

impl Parse for MacroArgs {
    fn parse(input: ParseStream<'_>) -> syn::Result<Self> {
        let mut reads = None;
        let mut writes = None;
        let mut tags = None;

        while !input.is_empty() {
            let key: Ident = input.parse()?;
            input.parse::<Token![=]>()?;
            let expr: Expr = input.parse()?;
            let values = parse_string_array(&expr, key.span())?;

            match key.to_string().as_str() {
                "reads" => {
                    if reads.is_some() {
                        return Err(syn::Error::new(key.span(), "duplicate `reads` argument"));
                    }
                    reads = Some(values);
                }
                "writes" => {
                    if writes.is_some() {
                        return Err(syn::Error::new(key.span(), "duplicate `writes` argument"));
                    }
                    writes = Some(values);
                }
                "tags" => {
                    if tags.is_some() {
                        return Err(syn::Error::new(key.span(), "duplicate `tags` argument"));
                    }
                    tags = Some(values);
                }
                _ => {
                    return Err(syn::Error::new(
                        key.span(),
                        format!("unknown macro argument `{}`", key),
                    ))
                }
            }

            if input.peek(Token![,]) {
                input.parse::<Token![,]>()?;
            }
        }

        Ok(Self {
            reads: reads.ok_or_else(|| syn::Error::new(Span::call_site(), "missing `reads`"))?,
            writes: writes.ok_or_else(|| syn::Error::new(Span::call_site(), "missing `writes`"))?,
            tags: tags.unwrap_or_default(),
        })
    }
}

fn parse_string_array(expr: &Expr, span: Span) -> syn::Result<Vec<String>> {
    let array = match expr {
        Expr::Array(array) => array,
        _ => {
            return Err(syn::Error::new(
                span,
                "expected an array of string literals, e.g. [\"count\"]",
            ))
        }
    };

    let mut values = Vec::with_capacity(array.elems.len());
    for element in &array.elems {
        let lit = match element {
            Expr::Lit(ExprLit {
                lit: Lit::Str(lit), ..
            }) => lit,
            _ => {
                return Err(syn::Error::new(
                    element.span(),
                    "array entries must be string literals",
                ))
            }
        };
        values.push(lit.value());
    }
    Ok(values)
}
