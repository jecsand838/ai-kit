use crate::spec::PersistenceLane;
use crate::{AsyncBaseStateLoader, AsyncBaseStatePersister, BaseStateLoader, BaseStatePersister};
use std::sync::Arc;

/// Type-erased reference to either a sync or async state loader.
#[derive(Clone)]
pub struct StateLoaderRef(LaneRef<dyn BaseStateLoader, dyn AsyncBaseStateLoader>);

enum LaneRef<S: ?Sized, A: ?Sized> {
    Sync(Arc<S>),
    Async(Arc<A>),
}

impl<S: ?Sized, A: ?Sized> Clone for LaneRef<S, A> {
    fn clone(&self) -> Self {
        match self {
            Self::Sync(value) => Self::Sync(Arc::clone(value)),
            Self::Async(value) => Self::Async(Arc::clone(value)),
        }
    }
}

impl<S: ?Sized, A: ?Sized> LaneRef<S, A> {
    fn sync(value: Arc<S>) -> Self {
        Self::Sync(value)
    }

    fn async_(value: Arc<A>) -> Self {
        Self::Async(value)
    }

    fn is_async(&self) -> bool {
        matches!(self, Self::Async(_))
    }

    fn lane(&self) -> PersistenceLane {
        if self.is_async() {
            PersistenceLane::Async
        } else {
            PersistenceLane::Sync
        }
    }

    fn as_sync(&self) -> Option<&Arc<S>> {
        match self {
            Self::Sync(value) => Some(value),
            Self::Async(_) => None,
        }
    }

    fn as_sync_arc(&self) -> Option<Arc<S>> {
        self.as_sync().cloned()
    }

    fn as_async(&self) -> Option<&Arc<A>> {
        match self {
            Self::Async(value) => Some(value),
            Self::Sync(_) => None,
        }
    }

    fn as_async_arc(&self) -> Option<Arc<A>> {
        self.as_async().cloned()
    }
}

impl StateLoaderRef {
    /// Wraps a synchronous persistence loader reference.
    pub fn sync<T>(value: Arc<T>) -> Self
    where
        T: BaseStateLoader + 'static,
    {
        let value: Arc<dyn BaseStateLoader> = value;
        Self(LaneRef::sync(value))
    }

    /// Wraps an asynchronous persistence loader reference.
    pub fn async_loader<T>(value: Arc<T>) -> Self
    where
        T: AsyncBaseStateLoader + 'static,
    {
        let value: Arc<dyn AsyncBaseStateLoader> = value;
        Self(LaneRef::async_(value))
    }

    /// Returns `true` when this reference points to an async implementation.
    pub fn is_async(&self) -> bool {
        self.0.is_async()
    }

    /// Returns the execution lane required by this reference.
    pub fn lane(&self) -> PersistenceLane {
        self.0.lane()
    }

    /// Returns the underlying synchronous loader reference, if present.
    pub fn as_sync(&self) -> Option<&Arc<dyn BaseStateLoader>> {
        self.0.as_sync()
    }

    /// Clones the underlying synchronous loader reference, if present.
    pub fn as_sync_arc(&self) -> Option<Arc<dyn BaseStateLoader>> {
        self.0.as_sync_arc()
    }

    /// Returns the underlying async loader reference, if present.
    pub fn as_async(&self) -> Option<&Arc<dyn AsyncBaseStateLoader>> {
        self.0.as_async()
    }

    /// Clones the underlying async loader reference, if present.
    pub fn as_async_arc(&self) -> Option<Arc<dyn AsyncBaseStateLoader>> {
        self.0.as_async_arc()
    }
}

impl From<Arc<dyn BaseStateLoader>> for StateLoaderRef {
    fn from(value: Arc<dyn BaseStateLoader>) -> Self {
        Self(LaneRef::sync(value))
    }
}

impl From<Arc<dyn BaseStatePersister>> for StateLoaderRef {
    fn from(value: Arc<dyn BaseStatePersister>) -> Self {
        let loader: Arc<dyn BaseStateLoader> = value;
        Self(LaneRef::sync(loader))
    }
}

impl From<Arc<dyn AsyncBaseStateLoader>> for StateLoaderRef {
    fn from(value: Arc<dyn AsyncBaseStateLoader>) -> Self {
        Self(LaneRef::async_(value))
    }
}

/// Type-erased reference to either a sync or async persister.
#[derive(Clone)]
pub struct StatePersisterRef(LaneRef<dyn BaseStatePersister, dyn AsyncBaseStatePersister>);

impl StatePersisterRef {
    /// Wraps a synchronous persistence persister reference.
    pub fn sync<T>(value: Arc<T>) -> Self
    where
        T: BaseStatePersister + 'static,
    {
        let value: Arc<dyn BaseStatePersister> = value;
        Self(LaneRef::sync(value))
    }

    /// Wraps an asynchronous persistence persister reference.
    pub fn async_persister<T>(value: Arc<T>) -> Self
    where
        T: AsyncBaseStatePersister + 'static,
    {
        let value: Arc<dyn AsyncBaseStatePersister> = value;
        Self(LaneRef::async_(value))
    }

    /// Returns `true` when this reference points to an async implementation.
    pub fn is_async(&self) -> bool {
        self.0.is_async()
    }

    /// Returns the execution lane required by this reference.
    pub fn lane(&self) -> PersistenceLane {
        self.0.lane()
    }

    /// Returns the underlying synchronous persister reference, if present.
    pub fn as_sync(&self) -> Option<&Arc<dyn BaseStatePersister>> {
        self.0.as_sync()
    }

    /// Clones the underlying synchronous persister reference, if present.
    pub fn as_sync_arc(&self) -> Option<Arc<dyn BaseStatePersister>> {
        self.0.as_sync_arc()
    }

    /// Returns the underlying async persister reference, if present.
    pub fn as_async(&self) -> Option<&Arc<dyn AsyncBaseStatePersister>> {
        self.0.as_async()
    }

    /// Clones the underlying async persister reference, if present.
    pub fn as_async_arc(&self) -> Option<Arc<dyn AsyncBaseStatePersister>> {
        self.0.as_async_arc()
    }
}

impl From<Arc<dyn BaseStatePersister>> for StatePersisterRef {
    fn from(value: Arc<dyn BaseStatePersister>) -> Self {
        Self(LaneRef::sync(value))
    }
}

impl From<Arc<dyn AsyncBaseStatePersister>> for StatePersisterRef {
    fn from(value: Arc<dyn AsyncBaseStatePersister>) -> Self {
        Self(LaneRef::async_(value))
    }
}
