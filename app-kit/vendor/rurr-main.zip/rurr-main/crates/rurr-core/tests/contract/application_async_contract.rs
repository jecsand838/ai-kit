use super::support::application::{
    assert_execute_drive_startup_error_prefers_post_execute_call_failure,
    assert_execute_drive_startup_error_still_fires_execute_call_hooks,
    assert_reserved_runtime_inputs_rejected, assert_step_error_rolls_back_without_partial_commit,
    assert_step_execute_context_tracks_resolved_next_action_and_reserved_sequence,
    assert_step_injects_application_context_with_reserved_sequence_id,
    assert_step_keeps_context_active_through_update, assert_step_simple_case, async_counter_action,
    async_counter_with_inputs_action, async_panic_action, count_zero_state,
    sync_async_counting_hooks, ApplicationScenario, ExecuteDriveMode, HookCounts,
    ReservedRuntimeInputCase, RunMode, StepMode, StepSimpleCase,
};
use crate::test_support::NonNegativeCountTypingSystem;
use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_core::action::{ActionError, FunctionActionBuilder};
use rurr_core::application::ApplicationError;
use rurr_core::lifecycle::LifecycleError;
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, AsyncLifecycleContextPropagator, AsyncLifecyclePollContext,
    AsyncLifecyclePollGuard, LifecycleAdapterSet, PostStepContext, PreStepContext,
    SyncLifecycleAdapter,
};
use rurr_core::state::{DefaultTypingSystem, State, StateError, TypingSystem};
use rurr_persistence::{
    BaseStateLoader, BaseStatePersister, BaseStateSaver, PersistedStateData, PersistedStateStatus,
    PersistenceError,
};
use rurr_testkit::application_fixture::{map_from_pairs, state_from_pairs};
use serde_json::{json, Value};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

const INTENTIONAL_ASYNC_COMMIT_FAILURE: &str = "intentional_async_commit_failure";
const INTENTIONAL_ARUN_POST_EXECUTE_FAILURE: &str = "intentional_arun_post_execute_failure";

macro_rules! async_app_case {
    ($name:ident => $body:expr $(,)?) => {
        #[tokio::test]
        async fn $name() {
            $body.await;
        }
    };
}

macro_rules! async_app_cases {
    ($($name:ident => $body:expr),+ $(,)?) => {
        $(async_app_case!($name => $body);)+
    };
}

#[derive(Debug, Default)]
struct FailingCommitPersister;

impl BaseStateLoader for FailingCommitPersister {
    fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(None)
    }

    fn list_app_ids(&self, _partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

impl BaseStateSaver for FailingCommitPersister {
    fn save(
        &self,
        _partition_key: Option<&str>,
        _app_id: &str,
        _sequence_id: u64,
        _position: &str,
        _state: IndexMap<String, Value>,
        _status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        Err(PersistenceError::UnsupportedOperation {
            operation: INTENTIONAL_ASYNC_COMMIT_FAILURE,
        })
    }
}

#[derive(Debug, Default)]
struct PostStepExceptionRecorder {
    sync_exceptions: Mutex<Vec<Option<String>>>,
    async_exceptions: Mutex<Vec<Option<String>>>,
}

impl PostStepExceptionRecorder {
    fn sync_exceptions(&self) -> Vec<Option<String>> {
        self.sync_exceptions
            .lock()
            .expect("sync_exceptions lock should not be poisoned")
            .clone()
    }

    fn async_exceptions(&self) -> Vec<Option<String>> {
        self.async_exceptions
            .lock()
            .expect("async_exceptions lock should not be poisoned")
            .clone()
    }
}

impl SyncLifecycleAdapter for PostStepExceptionRecorder {
    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.sync_exceptions
            .lock()
            .expect("sync_exceptions lock should not be poisoned")
            .push(context.exception().map(str::to_string));
        Ok(())
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for PostStepExceptionRecorder {
    async fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.async_exceptions
            .lock()
            .expect("async_exceptions lock should not be poisoned")
            .push(context.exception().map(str::to_string));
        Ok(())
    }
}

#[derive(Debug)]
struct CountingAsyncContextPropagator {
    wrap_count: Arc<AtomicUsize>,
    poll_count: Arc<AtomicUsize>,
}

impl AsyncLifecycleContextPropagator for CountingAsyncContextPropagator {
    fn step_poll_context(
        &self,
        _context: &PreStepContext,
    ) -> Option<Arc<dyn AsyncLifecyclePollContext>> {
        self.wrap_count.fetch_add(1, Ordering::SeqCst);
        let poll_count = Arc::clone(&self.poll_count);
        Some(Arc::new(CountingAsyncPollContext { poll_count }))
    }
}

#[derive(Debug)]
struct CountingAsyncPollContext {
    poll_count: Arc<AtomicUsize>,
}

impl AsyncLifecyclePollContext for CountingAsyncPollContext {
    fn enter(&self) -> Box<dyn AsyncLifecyclePollGuard + '_> {
        self.poll_count.fetch_add(1, Ordering::SeqCst);
        Box::new(())
    }
}

#[tokio::test]
async fn astep_async_lifecycle_context_propagator_enters_action_future_poll_context() {
    let wrap_count = Arc::new(AtomicUsize::new(0));
    let poll_count = Arc::new(AtomicUsize::new(0));
    let hooks = LifecycleAdapterSet::new(Vec::new(), Vec::new())
        .with_async_lifecycle_context_propagator(Arc::new(CountingAsyncContextPropagator {
            wrap_count: Arc::clone(&wrap_count),
            poll_count: Arc::clone(&poll_count),
        }));

    let mut app =
        ApplicationScenario::single_action(count_zero_state(), "counter", async_counter_action())
            .map(|scenario| scenario.with_hooks(hooks))
            .expect("fixture should build")
            .into_fixture()
            .into_builder()
            .build()
            .expect("app should build");

    app.astep(None)
        .await
        .expect("astep should succeed")
        .expect("astep should execute");

    assert_eq!(wrap_count.load(Ordering::SeqCst), 1);
    assert!(poll_count.load(Ordering::SeqCst) >= 1);
}

#[derive(Clone, Copy, Debug)]
enum AsyncCommitDriveMode {
    Step,
    Run,
}

impl AsyncCommitDriveMode {
    async fn drive(self, app: &mut rurr_core::Application) -> Result<(), ApplicationError> {
        match self {
            Self::Step => app.astep(None).await.map(|_| ()),
            Self::Run => app.arun().await.map(|_| ()),
        }
    }

    fn expectation_label(self) -> &'static str {
        match self {
            Self::Step => "astep should fail when commit save fails",
            Self::Run => "arun should fail when commit save fails",
        }
    }
}

async fn assert_async_commit_failure_records_post_step_exception_and_rolls_back(
    mode: AsyncCommitDriveMode,
) {
    let counts = Arc::new(HookCounts::default());
    let exception_recorder = Arc::new(PostStepExceptionRecorder::default());
    let sync_hooks: Vec<Arc<dyn SyncLifecycleAdapter>> = vec![
        Arc::new(
            super::support::streaming::hooks::LifecycleHookRecorder::counting(Arc::clone(&counts)),
        ),
        exception_recorder.clone(),
    ];
    let async_hooks: Vec<Arc<dyn AsyncLifecycleAdapter>> = vec![
        Arc::new(
            super::support::streaming::hooks::LifecycleHookRecorder::counting(Arc::clone(&counts)),
        ),
        exception_recorder.clone(),
    ];
    let hooks = LifecycleAdapterSet::new(sync_hooks, async_hooks);
    let persister: Arc<dyn BaseStatePersister> = Arc::new(FailingCommitPersister);

    let mut app = ApplicationScenario::single_action(
        state_from_pairs([("count", json!(0))]),
        "counter",
        async_counter_action(),
    )
    .map(|scenario| scenario.with_hooks(hooks))
    .expect("fixture should build")
    .into_fixture()
    .into_builder()
    .with_persistence_spec(
        rurr_persistence::ApplicationPersistenceSpec::new()
            .with_persister(rurr_persistence::StatePersisterSpec::sync(persister)),
    )
    .expect("state persister spec should configure")
    .build()
    .expect("app should build");

    let error = mode
        .drive(&mut app)
        .await
        .expect_err(mode.expectation_label());

    assert!(
        error.to_string().contains(INTENTIONAL_ASYNC_COMMIT_FAILURE),
        "error should include commit failure marker: {error}"
    );
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
    assert!(!app.state().contains_key("__PRIOR_STEP"));
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_run_step.load(Ordering::SeqCst), 1);

    let sync_exceptions = exception_recorder.sync_exceptions();
    assert_eq!(sync_exceptions.len(), 1, "expected one sync post_run_step");
    assert!(
        sync_exceptions[0]
            .as_deref()
            .is_some_and(|exception| exception.contains(INTENTIONAL_ASYNC_COMMIT_FAILURE)),
        "sync post_run_step should capture commit exception: {sync_exceptions:?}"
    );

    let async_exceptions = exception_recorder.async_exceptions();
    assert_eq!(
        async_exceptions.len(),
        1,
        "expected one async post_run_step"
    );
    assert!(
        async_exceptions[0]
            .as_deref()
            .is_some_and(|exception| exception.contains(INTENTIONAL_ASYNC_COMMIT_FAILURE)),
        "async post_run_step should capture commit exception: {async_exceptions:?}"
    );
}

fn assert_dual_lane_step_hook_counts(counts: &HookCounts) {
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_run_step.load(Ordering::SeqCst), 1);
}

async_app_case!(
    astep_executes_and_commits_internal_keys_at_commit_time =>
        assert_step_simple_case(StepMode::Async, StepSimpleCase::CommitsInternalKeys)
);

#[tokio::test]
async fn astep_surfaces_default_update_typing_failures_without_panicking() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(NonNegativeCountTypingSystem::default());
    let state = State::new(IndexMap::from([("count".to_string(), json!(1))]))
        .with_typing_system(Arc::clone(&typing_system))
        .expect("typing system should attach");
    let inputs = map_from_pairs([("additional_increment", json!(-2))]);
    let mut app = ApplicationScenario::single_action(
        state,
        "counter",
        async_counter_with_inputs_action("additional_increment"),
    )
    .expect("fixture should build")
    .into_fixture()
    .into_builder()
    .with_typing(typing_system)
    .expect("typing system should configure")
    .build()
    .expect("app should build");

    let error = app
        .astep(Some(inputs))
        .await
        .expect_err("astep should surface default update typing failures");

    match error {
        ApplicationError::Action(ActionError::State(StateError::TypingSystem {
            phase,
            message,
        })) => {
            assert_eq!(phase, "validate_post_action");
            assert!(message.contains("non-negative"));
        }
        other => panic!("expected action typing error, got {other:?}"),
    }
}

async_app_cases!(
    astep_keeps_context_active_through_update =>
        assert_step_keeps_context_active_through_update(StepMode::Async),
    astep_returns_none_when_no_next_action_exists =>
        assert_step_simple_case(StepMode::Async, StepSimpleCase::ReturnsNoneWhenNoNextActionExists),
    astep_rejects_reserved_runtime_inputs_without_execute_hooks =>
        assert_reserved_runtime_inputs_rejected(StepMode::Async, ReservedRuntimeInputCase::StepWithoutExecuteHooks),
    astep_error_rolls_back_without_partial_commit =>
        assert_step_error_rolls_back_without_partial_commit(StepMode::Async),
    astep_execute_context_tracks_resolved_next_action_and_reserved_sequence =>
        assert_step_execute_context_tracks_resolved_next_action_and_reserved_sequence(StepMode::Async),
    astep_injects_application_context_with_reserved_sequence_id =>
        assert_step_injects_application_context_with_reserved_sequence_id(StepMode::Async)
);

#[tokio::test]
async fn astep_startup_errors_still_fire_execute_call_hooks() {
    assert_execute_drive_startup_error_still_fires_execute_call_hooks(
        ExecuteDriveMode::Step,
        StepMode::Async,
        state_from_pairs([("__SEQUENCE_ID", json!("bad-seq"))]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::InvalidSequenceIdType { .. }
            ))
        },
        |_| {},
    )
    .await;
    assert_execute_drive_startup_error_still_fires_execute_call_hooks(
        ExecuteDriveMode::Step,
        StepMode::Async,
        state_from_pairs([("__SEQUENCE_ID", json!(0)), ("__PRIOR_STEP", json!(12))]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::InvalidPriorStepType { .. }
            ))
        },
        |_| {},
    )
    .await;
    assert_execute_drive_startup_error_still_fires_execute_call_hooks(
        ExecuteDriveMode::Step,
        StepMode::Async,
        state_from_pairs([
            ("__SEQUENCE_ID", json!(0)),
            ("__PRIOR_STEP", json!("missing")),
        ]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::Graph(rurr_core::graph::GraphError::ActionNotFound {
                    action_name,
                    ..
                }) if action_name == "missing"
            ));
        },
        |app| {
            assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("missing")));
            assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
        },
    )
    .await;
}

#[tokio::test]
async fn astep_does_not_preclone_working_state() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(DefaultTypingSystem);
    let state = State::new(map_from_pairs([("count", json!(0))]))
        .with_typing_system(Arc::clone(&typing_system))
        .expect("typing system should attach");
    let observed_typing_system_count = Arc::new(AtomicUsize::new(0));
    let observed_typing_system_count_for_action = Arc::clone(&observed_typing_system_count);
    let count_probe_action = FunctionActionBuilder::new()
        .writes(["count"])
        .build_async(move |state, _ctx| {
            let observed_typing_system_count_for_action =
                Arc::clone(&observed_typing_system_count_for_action);
            async move {
                observed_typing_system_count_for_action
                    .store(Arc::strong_count(state.typing_system()), Ordering::SeqCst);
                let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
                map_from_pairs([("count", json!(count))])
            }
        })
        .expect("count probe action should build");

    let mut app = ApplicationScenario::single_action(state, "count_probe", count_probe_action)
        .and_then(ApplicationScenario::build)
        .expect("app should build");

    let baseline = Arc::strong_count(&typing_system);
    let _ = app
        .astep(None)
        .await
        .expect("astep should succeed")
        .expect("astep should execute");

    assert_eq!(
        observed_typing_system_count.load(Ordering::SeqCst),
        baseline + 3,
        "astep should avoid pre-cloning transaction working state before run_async"
    );
}

#[tokio::test]
async fn astep_startup_error_prefers_post_execute_call_failure() {
    assert_execute_drive_startup_error_prefers_post_execute_call_failure(
        ExecuteDriveMode::Step,
        StepMode::Async,
        INTENTIONAL_ARUN_POST_EXECUTE_FAILURE,
    )
    .await;
}

#[tokio::test]
async fn astep_lifecycle_sync_and_async_hooks_fire_on_success() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_async_counting_hooks(Arc::clone(&counts));

    let mut app =
        ApplicationScenario::single_action(count_zero_state(), "counter", async_counter_action())
            .map(|scenario| scenario.with_hooks(hooks))
            .and_then(ApplicationScenario::build)
            .expect("app should build");

    let _ = app
        .astep(None)
        .await
        .expect("astep should succeed")
        .expect("astep should execute");

    assert_dual_lane_step_hook_counts(counts.as_ref());
}

#[tokio::test]
async fn astep_lifecycle_sync_and_async_hooks_fire_on_mapped_error() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_async_counting_hooks(Arc::clone(&counts));

    let mut app = ApplicationScenario::single_action(
        count_zero_state(),
        "counter_async",
        async_counter_with_inputs_action("additional_increment"),
    )
    .map(|scenario| scenario.with_hooks(hooks))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let error = app
        .astep(None)
        .await
        .expect_err("astep should fail when required input is missing");
    assert!(matches!(
        error,
        ApplicationError::Action(ActionError::MissingInput { ref key }) if key == "additional_increment"
    ));

    assert_dual_lane_step_hook_counts(counts.as_ref());
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
    assert!(!app.state().contains_key("__PRIOR_STEP"));
}

async_app_cases!(
    astep_commit_failure_records_post_step_exception_and_rolls_back =>
        assert_async_commit_failure_records_post_step_exception_and_rolls_back(
            AsyncCommitDriveMode::Step,
        ),
    arun_commit_failure_records_post_step_exception_and_rolls_back =>
        assert_async_commit_failure_records_post_step_exception_and_rolls_back(
            AsyncCommitDriveMode::Run,
        )
);

#[tokio::test]
async fn arun_startup_errors_still_fire_execute_call_hooks() {
    assert_execute_drive_startup_error_still_fires_execute_call_hooks(
        ExecuteDriveMode::Run,
        StepMode::Async,
        state_from_pairs([("__SEQUENCE_ID", json!("bad-seq"))]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::InvalidSequenceIdType { .. }
            ))
        },
        |_| {},
    )
    .await;
    assert_execute_drive_startup_error_still_fires_execute_call_hooks(
        ExecuteDriveMode::Run,
        StepMode::Async,
        state_from_pairs([("__SEQUENCE_ID", json!(0)), ("__PRIOR_STEP", json!(12))]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::InvalidPriorStepType { .. }
            ))
        },
        |_| {},
    )
    .await;
    assert_execute_drive_startup_error_still_fires_execute_call_hooks(
        ExecuteDriveMode::Run,
        StepMode::Async,
        state_from_pairs([
            ("__SEQUENCE_ID", json!(0)),
            ("__PRIOR_STEP", json!("missing")),
        ]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::Graph(rurr_core::graph::GraphError::ActionNotFound {
                    action_name,
                    ..
                }) if action_name == "missing"
            ));
        },
        |app| {
            assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("missing")));
            assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
        },
    )
    .await;
}

#[tokio::test]
async fn arun_startup_error_prefers_post_execute_call_failure() {
    assert_execute_drive_startup_error_prefers_post_execute_call_failure(
        ExecuteDriveMode::Run,
        StepMode::Async,
        INTENTIONAL_ARUN_POST_EXECUTE_FAILURE,
    )
    .await;
}

#[tokio::test]
async fn astep_panic_capture_runs_post_hooks_and_returns_typed_error() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_async_counting_hooks(Arc::clone(&counts));

    let mut app = ApplicationScenario::single_action(
        count_zero_state(),
        "panic_async",
        async_panic_action("intentional panic in async action"),
    )
    .map(|scenario| scenario.with_hooks(hooks))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let app_result = app.astep(None).await;
    assert!(
        matches!(
            app_result,
            Err(ApplicationError::PanicCaptured {
                scope: "action.run_async_or_update",
                ..
            })
        ),
        "astep should convert action panic to typed error"
    );
    assert_dual_lane_step_hook_counts(counts.as_ref());
}

async_app_cases!(
    astep_rejects_user_supplied_reserved_runtime_inputs =>
        assert_reserved_runtime_inputs_rejected(StepMode::Async, ReservedRuntimeInputCase::StepDirect),
    arun_rejects_user_supplied_reserved_runtime_inputs =>
        assert_reserved_runtime_inputs_rejected(RunMode::Async, ReservedRuntimeInputCase::RunDirect),
    astep_commits_application_sequence_and_context_state =>
        assert_step_simple_case(
            StepMode::Async,
            StepSimpleCase::CommitsApplicationSequenceAndContextState,
        )
);
