use super::{
    PersistenceError, MIGRATION_SQL, OP_INVALID_TABLE_NAME, POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN,
};

/// Renders the bundled PostgreSQL migration SQL for a specific table name.
pub fn render_migration_sql(table_name: &str) -> String {
    MIGRATION_SQL.replace("__TABLE_NAME__", table_name)
}

/// Validates that a PostgreSQL table name is safe to interpolate into the
/// bundled migration templates.
pub fn validate_table_name(table_name: &str) -> Result<(), PersistenceError> {
    // Migration uses `<table_name>_created_at_index`, so keep table names short enough to avoid
    // PostgreSQL identifier truncation that can collide index and table relation names.
    if table_name.len() > POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN {
        return Err(PersistenceError::UnsupportedOperation {
            operation: OP_INVALID_TABLE_NAME,
        });
    }

    let mut characters = table_name.chars();
    let Some(first_character) = characters.next() else {
        return Err(PersistenceError::UnsupportedOperation {
            operation: OP_INVALID_TABLE_NAME,
        });
    };

    // We use unquoted identifiers in SQL, so enforce lowercase names to avoid Postgres case-folding mismatches.
    let is_valid = (first_character.is_ascii_lowercase() || first_character == '_')
        && characters.all(|character| {
            character.is_ascii_lowercase() || character.is_ascii_digit() || character == '_'
        });
    if is_valid {
        Ok(())
    } else {
        Err(PersistenceError::UnsupportedOperation {
            operation: OP_INVALID_TABLE_NAME,
        })
    }
}
