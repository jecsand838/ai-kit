use http_body_util::BodyExt;

pub(crate) async fn response_body_bytes(response: axum::response::Response) -> Vec<u8> {
    response
        .into_body()
        .collect()
        .await
        .expect("response body should collect")
        .to_bytes()
        .to_vec()
}
