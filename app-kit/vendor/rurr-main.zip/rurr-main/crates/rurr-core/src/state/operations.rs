use super::value_ops::{checked_increment, parse_integer};
use super::StateError;
use indexmap::IndexMap;
use serde_json::Value;
use std::collections::HashSet;

#[derive(Debug, Clone, PartialEq)]
/// A state mutation applied by an action result.
pub enum StateOperation {
    /// Replaces or inserts scalar/object values by key.
    Update(IndexMap<String, Value>),
    /// Appends one value per key to array fields.
    Append(Vec<(String, Value)>),
    /// Appends many values per key to array fields.
    Extend(Vec<(String, Vec<Value>)>),
    /// Adds signed integer deltas to numeric fields.
    Increment(Vec<(String, i64)>),
    /// Deletes the named keys from the state.
    Delete(Vec<String>),
}

impl StateOperation {
    pub(crate) fn apply(&self, values: &mut IndexMap<String, Value>) -> Result<(), StateError> {
        match self {
            Self::Update(updates) => apply_update(values, updates),
            Self::Append(payload) => apply_append(values, payload),
            Self::Extend(payload) => apply_extend(values, payload),
            Self::Increment(payload) => apply_increment(values, payload),
            Self::Delete(keys) => apply_delete(values, keys),
        }
    }
}

fn apply_update(
    values: &mut IndexMap<String, Value>,
    updates: &IndexMap<String, Value>,
) -> Result<(), StateError> {
    for (key, value) in updates {
        values.insert(key.clone(), value.clone());
    }
    Ok(())
}

fn apply_append(
    values: &mut IndexMap<String, Value>,
    payload: &[(String, Value)],
) -> Result<(), StateError> {
    for (key, value) in payload {
        match values.get_mut(key) {
            Some(existing) => {
                let existing_array = existing
                    .as_array_mut()
                    .ok_or_else(|| StateError::NonAppendable { key: key.clone() })?;
                existing_array.push(value.clone());
            }
            None => {
                values.insert(key.clone(), Value::Array(vec![value.clone()]));
            }
        }
    }
    Ok(())
}

fn apply_extend(
    values: &mut IndexMap<String, Value>,
    payload: &[(String, Vec<Value>)],
) -> Result<(), StateError> {
    for (key, value_list) in payload {
        match values.get_mut(key) {
            Some(existing) => {
                let existing_array = existing
                    .as_array_mut()
                    .ok_or_else(|| StateError::NonExtendable { key: key.clone() })?;
                existing_array.extend(value_list.iter().cloned());
            }
            None => {
                values.insert(key.clone(), Value::Array(value_list.clone()));
            }
        }
    }
    Ok(())
}

fn apply_increment(
    values: &mut IndexMap<String, Value>,
    payload: &[(String, i64)],
) -> Result<(), StateError> {
    for (key, delta) in payload {
        let current_value = match values.get(key) {
            Some(existing) => parse_integer(existing, key)?,
            None => 0,
        };
        let next_value = checked_increment(current_value, *delta, key)?;
        values.insert(key.clone(), next_value);
    }
    Ok(())
}

fn apply_delete(values: &mut IndexMap<String, Value>, keys: &[String]) -> Result<(), StateError> {
    let keys_to_delete: HashSet<&str> = keys.iter().map(String::as_str).collect();
    values.retain(|key, _| !keys_to_delete.contains(key.as_str()));
    Ok(())
}
