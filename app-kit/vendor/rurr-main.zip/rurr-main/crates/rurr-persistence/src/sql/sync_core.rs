use crate::{
    InitializationHint, PersistedRowTuple, PersistedStateData, PersistedStateQueries,
    PersistedStateSaveRequest, PersistenceError,
};

use super::core_plan::{
    ensure_initialized_result, list_app_ids_operation, persisted_state_from_tuple, LoadOperation,
    SqlInitializationPlan, SqlListAppIdsPlan, SqlSavePlan,
};

/// Backend adapter used by the shared synchronous SQL persistence core.
pub trait SyncSqlBackend {
    /// Verifies that the backend connection is still open.
    fn ensure_open(&self) -> Result<(), PersistenceError>;

    /// Executes backend-specific migration SQL.
    fn run_migration(&self, plan: &SqlInitializationPlan<'_>) -> Result<(), PersistenceError>;

    /// Checks whether the configured table already exists.
    fn table_exists(&self, plan: &SqlInitializationPlan<'_>) -> Result<bool, PersistenceError>;

    /// Saves a persisted-state request using the provided insert SQL.
    fn save(&self, plan: &SqlSavePlan<'_, '_>) -> Result<(), PersistenceError>;

    /// Loads the newest record for the requested partition.
    fn load_latest_partition(
        &self,
        query: &str,
        partition_key: &str,
    ) -> Result<Option<PersistedRowTuple>, PersistenceError>;

    /// Loads the newest record for the requested app.
    fn load_latest_app(
        &self,
        query: &str,
        partition_key: &str,
        app_id: &str,
    ) -> Result<Option<PersistedRowTuple>, PersistenceError>;

    /// Loads the exact sequence requested for an app.
    fn load_exact_sequence(
        &self,
        query: &str,
        partition_key: &str,
        app_id: &str,
        sequence_id: i64,
    ) -> Result<Option<PersistedRowTuple>, PersistenceError>;

    /// Lists app ids for the normalized partition key.
    fn list_app_ids(&self, plan: &SqlListAppIdsPlan<'_>) -> Result<Vec<String>, PersistenceError>;
}

/// Shared synchronous SQL control flow used by backend-specific adapters.
pub struct SyncSqlPersistenceCore<'a, B> {
    backend: B,
    queries: &'a PersistedStateQueries,
    table_name: &'a str,
    migration_sql: &'a str,
    initialization_hint: &'a InitializationHint,
}

impl<'a, B> SyncSqlPersistenceCore<'a, B>
where
    B: SyncSqlBackend,
{
    /// Creates a new synchronous SQL persistence core.
    pub fn new(
        backend: B,
        queries: &'a PersistedStateQueries,
        table_name: &'a str,
        migration_sql: &'a str,
        initialization_hint: &'a InitializationHint,
    ) -> Self {
        Self {
            backend,
            queries,
            table_name,
            migration_sql,
            initialization_hint,
        }
    }

    /// Runs backend migrations and records the initialized state.
    pub fn initialize(&self) -> Result<(), PersistenceError> {
        self.backend.ensure_open()?;
        let plan = SqlInitializationPlan::new(self.table_name, self.migration_sql);
        self.backend
            .run_migration(&plan)
            .map_err(|error| self.initialization_hint.track_error(error))?;
        self.initialization_hint.set(true);
        Ok(())
    }

    /// Checks whether the configured table already exists.
    pub fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.backend.ensure_open()?;
        let plan = SqlInitializationPlan::new(self.table_name, self.migration_sql);
        let exists = self
            .backend
            .table_exists(&plan)
            .map_err(|error| self.initialization_hint.track_error(error))?;
        self.initialization_hint.set(exists);
        Ok(exists)
    }

    /// Saves a new persisted-state row.
    pub fn save(
        &self,
        request: PersistedStateSaveRequest<'_>,
        serialization_failure_operation: &'static str,
    ) -> Result<(), PersistenceError> {
        self.ensure_initialized()?;
        let plan = SqlSavePlan::new(self.queries, request, serialization_failure_operation)?;
        self.backend
            .save(&plan)
            .map_err(|error| self.initialization_hint.track_error(error))
    }

    /// Loads a persisted-state row.
    pub fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.ensure_initialized()?;
        let row = match LoadOperation::new(self.queries, partition_key, app_id, sequence_id)? {
            LoadOperation::NoRecord => None,
            LoadOperation::LatestPartition {
                query,
                partition_key,
            } => self.backend.load_latest_partition(query, &partition_key)?,
            LoadOperation::LatestApp {
                query,
                partition_key,
                app_id,
            } => self
                .backend
                .load_latest_app(query, &partition_key, app_id)?,
            LoadOperation::ExactSequence {
                query,
                partition_key,
                app_id,
                sequence_id,
            } => self
                .backend
                .load_exact_sequence(query, &partition_key, app_id, sequence_id)?,
        };

        row.map(persisted_state_from_tuple).transpose()
    }

    /// Lists app ids for a partition in backend-defined canonical order.
    pub fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        self.ensure_initialized()?;
        let plan = list_app_ids_operation(self.queries, partition_key);
        self.backend
            .list_app_ids(&plan)
            .map_err(|error| self.initialization_hint.track_error(error))
    }

    fn ensure_initialized(&self) -> Result<(), PersistenceError> {
        self.backend.ensure_open()?;
        if self.initialization_hint.is_set() {
            return Ok(());
        }

        ensure_initialized_result(self.initialization_hint, self.is_initialized()?)
    }
}

#[cfg(test)]
mod tests {
    use super::{SyncSqlBackend, SyncSqlPersistenceCore};
    use crate::{
        InitializationHint, PersistedRowTuple, PersistedStateQueries, PersistedStateSaveRequest,
        PersistedStateStatus, PersistenceError,
    };
    use indexmap::IndexMap;
    use serde_json::json;
    use std::cell::RefCell;

    #[derive(Default)]
    struct FakeBackend {
        ops: RefCell<Vec<&'static str>>,
        initialized: bool,
    }

    impl SyncSqlBackend for FakeBackend {
        fn ensure_open(&self) -> Result<(), PersistenceError> {
            self.ops.borrow_mut().push("ensure_open");
            Ok(())
        }

        fn table_exists(
            &self,
            _plan: &super::SqlInitializationPlan<'_>,
        ) -> Result<bool, PersistenceError> {
            self.ops.borrow_mut().push("table_exists");
            Ok(self.initialized)
        }

        fn run_migration(
            &self,
            _plan: &super::SqlInitializationPlan<'_>,
        ) -> Result<(), PersistenceError> {
            self.ops.borrow_mut().push("run_migration");
            Ok(())
        }

        fn save(&self, _plan: &super::SqlSavePlan<'_, '_>) -> Result<(), PersistenceError> {
            self.ops.borrow_mut().push("save");
            Ok(())
        }

        fn load_latest_partition(
            &self,
            _query: &str,
            _partition_key: &str,
        ) -> Result<Option<PersistedRowTuple>, PersistenceError> {
            self.ops.borrow_mut().push("load_latest_partition");
            Ok(None)
        }

        fn load_latest_app(
            &self,
            _query: &str,
            _partition_key: &str,
            _app_id: &str,
        ) -> Result<Option<PersistedRowTuple>, PersistenceError> {
            self.ops.borrow_mut().push("load_latest_app");
            Ok(None)
        }

        fn load_exact_sequence(
            &self,
            _query: &str,
            _partition_key: &str,
            _app_id: &str,
            _sequence_id: i64,
        ) -> Result<Option<PersistedRowTuple>, PersistenceError> {
            self.ops.borrow_mut().push("load_exact_sequence");
            Ok(None)
        }

        fn list_app_ids(
            &self,
            _plan: &super::SqlListAppIdsPlan<'_>,
        ) -> Result<Vec<String>, PersistenceError> {
            self.ops.borrow_mut().push("list_app_ids");
            Ok(vec!["a".to_string()])
        }
    }

    #[test]
    fn save_probes_initialization_before_writing_when_hint_is_cleared() {
        let backend = FakeBackend {
            initialized: true,
            ..FakeBackend::default()
        };
        let hint = InitializationHint::new();
        let queries = PersistedStateQueries::sqlite_sync("burr_state");
        let core = SyncSqlPersistenceCore::new(backend, &queries, "burr_state", "migration", &hint);

        core.save(
            PersistedStateSaveRequest::new(
                None,
                "app",
                1,
                "step",
                IndexMap::from([("count".to_string(), json!(1))]),
                PersistedStateStatus::Completed,
            ),
            "serialize_failed",
        )
        .expect("save should succeed");

        assert_eq!(
            core.backend.ops.into_inner(),
            vec!["ensure_open", "ensure_open", "table_exists", "save"]
        );
    }

    #[test]
    fn load_exact_sequence_uses_exact_sequence_backend_path() {
        let backend = FakeBackend {
            initialized: true,
            ..FakeBackend::default()
        };
        let hint = InitializationHint::new();
        hint.set(true);
        let queries = PersistedStateQueries::sqlite_sync("burr_state");
        let core = SyncSqlPersistenceCore::new(backend, &queries, "burr_state", "migration", &hint);

        let loaded = core
            .load(None, Some("app"), Some(9))
            .expect("load should succeed");

        assert!(loaded.is_none());
        assert_eq!(
            core.backend.ops.into_inner(),
            vec!["ensure_open", "load_exact_sequence"]
        );
    }
}
