use super::*;
use super::{assertions::*, fixtures::*, graphs::*, hooks::*};

#[test]
fn child_context_uses_child_app_id_not_parent() {
    let graph = runnable_graph_from_action(
        "context_probe",
        FunctionActionBuilder::new()
            .writes(["seen_app_id"])
            .build_sync(|_state, ctx| {
                let app_id = ctx
                    .app_context
                    .as_ref()
                    .map(|context| context.app_id.clone())
                    .expect("application context should exist in child action");
                map_from_pairs([("seen_app_id", json!(app_id))])
            })
            .expect("action should build"),
    );

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(vec![graph], Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");
    let child_app_id = step
        .state
        .get("child_states")
        .and_then(Value::as_array)
        .and_then(|states| states.first())
        .and_then(Value::as_object)
        .and_then(|state| state.get("seen_app_id"))
        .and_then(Value::as_str)
        .expect("seen_app_id should be present")
        .to_string();

    assert_eq!(child_app_id, stable_child_app_id("parent-app", "0-0"));
    assert_ne!(child_app_id, "parent-app");
}

#[test]
fn child_id_seed_ignores_parent_action_name() {
    let graph = runnable_graph_from_action(
        "context_probe_seed",
        FunctionActionBuilder::new()
            .writes(["seen_app_id"])
            .build_sync(|_state, ctx| {
                let app_id = ctx
                    .app_context
                    .as_ref()
                    .map(|context| context.app_id.clone())
                    .expect("application context should exist in child action");
                map_from_pairs([("seen_app_id", json!(app_id))])
            })
            .expect("action should build"),
    );
    let action = ParallelMap::new(
        ParallelTaskSource::graphs(vec![graph], Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel_custom_name",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );
    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");
    let child_app_id = child_seen_app_ids_in_state(&step.state)
        .into_iter()
        .next()
        .expect("exactly one child id should be present");

    assert_eq!(child_app_id, stable_child_app_id("parent-app", "0-0"));
    assert_ne!(
        child_app_id,
        namespaced_child_app_id("parent-app", "parallel_custom_name", "0-0")
    );
}

#[test]
fn sync_child_context_includes_spawning_parent_pointer() {
    let graph = runnable_graph_from_action(
        "sync_spawn_probe",
        FunctionActionBuilder::new()
            .writes([
                "spawn_parent_app_id",
                "spawn_parent_partition_key",
                "spawn_parent_sequence_id",
            ])
            .build_sync(|_state, ctx| {
                let context = ctx
                    .app_context
                    .clone()
                    .expect("application context should exist");
                let spawning_parent = context
                    .spawning_parent_pointer
                    .expect("spawning_parent_pointer should be present in child context");
                map_from_pairs([
                    ("spawn_parent_app_id", json!(spawning_parent.app_id)),
                    (
                        "spawn_parent_partition_key",
                        json!(spawning_parent.partition_key),
                    ),
                    (
                        "spawn_parent_sequence_id",
                        json!(spawning_parent.sequence_id),
                    ),
                ])
            })
            .expect("action should build"),
    );

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(vec![graph], Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("__SEQUENCE_ID", json!(41))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");
    let child_state = &child_states_in_state(&step.state)[0];

    assert_eq!(
        child_state.get("spawn_parent_app_id"),
        Some(&json!("parent-app"))
    );
    assert_eq!(
        child_state.get("spawn_parent_partition_key"),
        Some(&json!("pk"))
    );
    assert_eq!(
        child_state.get("spawn_parent_sequence_id"),
        Some(&json!(42))
    );
}

#[tokio::test]
async fn async_child_context_includes_spawning_parent_pointer() {
    let graph = runnable_graph_from_action(
        "async_spawn_probe",
        FunctionActionBuilder::new()
            .writes([
                "start_spawn_parent_app_id",
                "end_spawn_parent_app_id",
                "spawn_parent_sequence_id",
                "stable_spawn_pointer",
            ])
            .build_async(|_state, ctx| async move {
                let start = ctx
                    .app_context
                    .clone()
                    .expect("start context should exist")
                    .spawning_parent_pointer
                    .expect("spawning_parent_pointer should exist at start");
                sleep(Duration::from_millis(15)).await;
                let end = ctx
                    .app_context
                    .clone()
                    .expect("end context should exist")
                    .spawning_parent_pointer
                    .expect("spawning_parent_pointer should exist at end");
                map_from_pairs([
                    ("start_spawn_parent_app_id", json!(start.app_id.clone())),
                    ("end_spawn_parent_app_id", json!(end.app_id.clone())),
                    ("spawn_parent_sequence_id", json!(end.sequence_id)),
                    (
                        "stable_spawn_pointer",
                        json!(start.app_id == end.app_id && start.sequence_id == end.sequence_id),
                    ),
                ])
            })
            .expect("action should build"),
    );

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(vec![graph], Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("__SEQUENCE_ID", json!(41))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .astep(None)
        .await
        .expect("astep should succeed")
        .expect("astep should execute");
    let child_state = &child_states_in_state(&step.state)[0];

    assert_eq!(
        child_state.get("start_spawn_parent_app_id"),
        Some(&json!("parent-app"))
    );
    assert_eq!(
        child_state.get("end_spawn_parent_app_id"),
        Some(&json!("parent-app"))
    );
    assert_eq!(
        child_state.get("spawn_parent_sequence_id"),
        Some(&json!(42))
    );
    assert_eq!(child_state.get("stable_spawn_pointer"), Some(&json!(true)));
}

#[test]
fn spawn_pointer_uses_parent_reserved_sequence_id() {
    let spawn_seq_graph = |name: &'static str| {
        runnable_graph_from_action(
            name,
            FunctionActionBuilder::new()
                .writes(["spawn_parent_sequence_id"])
                .build_sync(|_state, ctx| {
                    let context = ctx
                        .app_context
                        .clone()
                        .expect("application context should exist");
                    let sequence_id = context
                        .spawning_parent_pointer
                        .expect("spawning_parent_pointer should be present")
                        .sequence_id;
                    map_from_pairs([("spawn_parent_sequence_id", json!(sequence_id))])
                })
                .expect("action should build"),
        )
    };

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![spawn_seq_graph("child1"), spawn_seq_graph("child2")],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("__SEQUENCE_ID", json!(8))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        child_i64_values_in_state(&step.state, "spawn_parent_sequence_id"),
        vec![9, 9]
    );
}

#[test]
fn parallel_action_missing_parent_sequence_id_returns_runtime_context_unavailable_sync() {
    let child_registration_recorder = Arc::new(ChildRegistrationRecorder::default());
    let hooks = LifecycleAdapterSet::new(
        vec![child_registration_recorder.clone() as Arc<dyn SyncLifecycleAdapter>],
        Vec::new(),
    );
    let tracer = ActionTracer::new(
        "parallel_missing_parent_sequence_id_sync",
        7,
        hooks,
        "parent-app",
        Some("pk".to_string()),
    );

    let child_graph = runnable_graph_from_action(
        "child_sync",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
            .expect("action should build"),
    );
    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![child_graph.clone(), child_graph],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    )
    .with_name("parallel_sync")
    .expect("action naming should succeed");

    let error = action
        .run(
            &State::default(),
            &ActionContext::new(
                ActionInputs::new(),
                tracer,
                Some(ApplicationContext {
                    app_id: "parent-app".to_string(),
                    partition_key: Some("pk".to_string()),
                    sequence_id: None,
                    prior_step: None,
                    parent_pointer: None,
                    spawning_parent_pointer: None,
                }),
            ),
        )
        .expect_err("missing parent sequence id should fail closed");
    assert!(matches!(
        error,
        ActionError::RuntimeContextUnavailable { message }
        if message == "parallel action requires application-managed execution scope"
    ));
    assert!(
        child_registration_recorder.child_app_ids().is_empty(),
        "child registration must not occur when context validation fails"
    );
}

#[tokio::test]
async fn parallel_action_missing_parent_sequence_id_returns_runtime_context_unavailable_async() {
    let child_registration_recorder = Arc::new(ChildRegistrationRecorder::default());
    let hooks = LifecycleAdapterSet::new(
        Vec::new(),
        vec![child_registration_recorder.clone() as Arc<dyn AsyncLifecycleAdapter>],
    );
    let tracer = ActionTracer::new(
        "parallel_missing_parent_sequence_id_async",
        7,
        hooks,
        "parent-app",
        Some("pk".to_string()),
    );

    let child_graph = runnable_graph_from_action(
        "child_async",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
            .expect("action should build"),
    );
    let action = ParallelMap::new(
        ParallelTaskSource::graphs(vec![child_graph], Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    )
    .with_name("parallel_async")
    .expect("action naming should succeed");
    let app_context = ApplicationContext {
        app_id: "parent-app".to_string(),
        partition_key: Some("pk".to_string()),
        sequence_id: None,
        prior_step: None,
        parent_pointer: None,
        spawning_parent_pointer: None,
    };

    let error = action
        .run_async(
            &State::default(),
            &ActionContext::new(ActionInputs::new(), tracer, Some(app_context)),
        )
        .await
        .expect_err("missing parent sequence id should fail closed");
    assert!(matches!(
        error,
        ActionError::RuntimeContextUnavailable { message }
        if message == "parallel action requires application-managed execution scope"
    ));
    assert!(
        child_registration_recorder.child_app_ids().is_empty(),
        "child registration must not occur when context validation fails"
    );
}

#[test]
fn spawn_context_parent_pointer_remains_none() {
    let graph = runnable_graph_from_action(
        "parent_pointer_probe",
        FunctionActionBuilder::new()
            .writes(["has_parent_pointer", "has_spawning_parent_pointer"])
            .build_sync(|_state, ctx| {
                let context = ctx
                    .app_context
                    .clone()
                    .expect("application context should exist");
                map_from_pairs([
                    (
                        "has_parent_pointer",
                        json!(context.parent_pointer.is_some()),
                    ),
                    (
                        "has_spawning_parent_pointer",
                        json!(context.spawning_parent_pointer.is_some()),
                    ),
                ])
            })
            .expect("action should build"),
    );

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(vec![graph], Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("__SEQUENCE_ID", json!(3))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");
    let child_state = &child_states_in_state(&step.state)[0];

    assert_eq!(child_state.get("has_parent_pointer"), Some(&json!(false)));
    assert_eq!(
        child_state.get("has_spawning_parent_pointer"),
        Some(&json!(true))
    );
}

#[tokio::test]
async fn async_siblings_do_not_observe_each_others_context() {
    let make_graph = |name: &'static str| {
        runnable_graph_from_action(
            name,
            FunctionActionBuilder::new()
                .writes(["start_app_id", "end_app_id", "stable_context"])
                .build_async(|_state, ctx| async move {
                    let start = ctx
                        .app_context
                        .as_ref()
                        .map(|context| context.app_id.clone())
                        .expect("start context should exist");
                    sleep(Duration::from_millis(40)).await;
                    let end = ctx
                        .app_context
                        .as_ref()
                        .map(|context| context.app_id.clone())
                        .expect("end context should exist");
                    map_from_pairs([
                        ("start_app_id", json!(start.clone())),
                        ("end_app_id", json!(end.clone())),
                        ("stable_context", json!(start == end)),
                    ])
                })
                .expect("action should build"),
        )
    };

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![make_graph("a"), make_graph("b")],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .astep(None)
        .await
        .expect("astep should succeed")
        .expect("astep should execute");

    let states = child_states_in_state(&step.state);
    let mut observed_ids = BTreeSet::new();
    for state in states {
        let start = state
            .get("start_app_id")
            .and_then(Value::as_str)
            .expect("start_app_id should be present")
            .to_string();
        let end = state
            .get("end_app_id")
            .and_then(Value::as_str)
            .expect("end_app_id should be present")
            .to_string();
        let stable = state
            .get("stable_context")
            .and_then(Value::as_bool)
            .expect("stable_context should be present");

        assert!(stable, "each child should keep its own context");
        assert_eq!(start, end);
        assert_ne!(start, "parent-app");
        observed_ids.insert(start);
    }

    assert_eq!(observed_ids.len(), 2);
}
