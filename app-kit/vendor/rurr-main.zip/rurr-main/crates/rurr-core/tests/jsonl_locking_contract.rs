use fs2::FileExt;
use rurr_core::tracking::jsonl::{append_jsonl_locked, with_locked_jsonl_file, JsonlLockMode};
use rurr_testkit::test_dir_for_test;
use std::fs::{self, OpenOptions};
use std::io::{self, BufRead, BufReader, Seek, SeekFrom};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc;
use std::sync::Arc;
use std::thread;
use std::time::Duration;

#[derive(Debug, Eq, PartialEq)]
enum ReaderState {
    Attempting,
    Acquired,
}

#[test]
fn shared_lock_waits_for_exclusive_writer_and_reads_complete_file() {
    let tempdir = test_dir_for_test().expect("tempdir should be created");
    let path = tempdir.join("shared.jsonl");
    fs::write(&path, "{\"sequence\":0}\n{\"sequence\":1}\n").expect("jsonl file should be written");

    let lock_file = OpenOptions::new()
        .read(true)
        .write(true)
        .open(&path)
        .expect("jsonl file should open");
    lock_file
        .lock_exclusive()
        .expect("jsonl file should lock exclusively");

    let finished = Arc::new(AtomicBool::new(false));
    let finished_reader = finished.clone();
    let path_reader = path.clone();
    let (state_tx, state_rx) = mpsc::channel();
    let reader = thread::spawn(move || {
        state_tx
            .send(ReaderState::Attempting)
            .expect("reader should signal lock attempt");
        let lines = with_locked_jsonl_file(
            &path_reader,
            JsonlLockMode::Shared,
            |file: &mut std::fs::File| -> io::Result<Vec<String>> {
                state_tx
                    .send(ReaderState::Acquired)
                    .expect("reader should signal lock acquisition");
                file.seek(SeekFrom::Start(0))?;
                BufReader::new(file.try_clone()?).lines().collect()
            },
        );
        finished_reader.store(true, Ordering::SeqCst);
        lines
    });

    assert_eq!(
        state_rx
            .recv_timeout(Duration::from_secs(1))
            .expect("reader should signal lock attempt"),
        ReaderState::Attempting
    );
    assert!(
        state_rx.recv_timeout(Duration::from_millis(100)).is_err(),
        "shared readers must remain blocked until the exclusive writer lock releases"
    );
    assert!(
        !finished.load(Ordering::SeqCst),
        "shared readers must wait while an exclusive writer lock is held"
    );

    lock_file
        .unlock()
        .expect("jsonl file lock should release cleanly");

    assert_eq!(
        state_rx
            .recv_timeout(Duration::from_secs(1))
            .expect("reader should signal lock acquisition after unlock"),
        ReaderState::Acquired
    );

    let lines = reader
        .join()
        .expect("reader thread should join")
        .expect("reader should acquire the shared lock after release");
    assert_eq!(lines, vec!["{\"sequence\":0}", "{\"sequence\":1}"]);
}

#[test]
fn append_jsonl_locked_preserves_record_separator_when_file_lacks_trailing_newline() {
    let tempdir = test_dir_for_test().expect("tempdir should be created");
    let path = tempdir.join("shared.jsonl");
    fs::write(&path, "{\"sequence\":0}").expect("jsonl file should be written");

    append_jsonl_locked(&path, &serde_json::json!({ "sequence": 1 }))
        .expect("jsonl append should succeed");

    let contents = fs::read_to_string(&path).expect("jsonl file should be readable");
    assert_eq!(contents, "{\"sequence\":0}\n{\"sequence\":1}\n");

    let lines = contents
        .lines()
        .map(|line| {
            serde_json::from_str::<serde_json::Value>(line).expect("jsonl line should parse")
        })
        .collect::<Vec<_>>();
    assert_eq!(lines.len(), 2);
    assert_eq!(lines[0]["sequence"], 0);
    assert_eq!(lines[1]["sequence"], 1);
}
