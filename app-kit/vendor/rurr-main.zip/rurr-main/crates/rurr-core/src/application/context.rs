use serde::{Deserialize, Serialize};

/// Pointer to a parent application that spawned the current application.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ParentPointer {
    /// Parent application id.
    pub app_id: String,
    /// Parent partition key, when one exists.
    pub partition_key: Option<String>,
    /// Parent sequence id associated with the spawn point.
    pub sequence_id: Option<u64>,
}

/// Serialized application identity and ancestry context.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ApplicationContext {
    /// Current application id.
    pub app_id: String,
    /// Current partition key, when one exists.
    pub partition_key: Option<String>,
    /// Current sequence id, when one exists.
    pub sequence_id: Option<u64>,
    /// Prior step name recorded in the current application.
    pub prior_step: Option<String>,
    /// Immediate persisted parent pointer, when one exists.
    pub parent_pointer: Option<ParentPointer>,
    /// Parent pointer recorded at spawn time for child applications.
    pub spawning_parent_pointer: Option<ParentPointer>,
}
