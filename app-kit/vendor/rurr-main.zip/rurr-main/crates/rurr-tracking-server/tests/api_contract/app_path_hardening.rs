use super::*;

#[cfg(unix)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum AliasLeafKind {
    Metadata,
    Log,
    Graph,
    Children,
}

#[cfg(unix)]
impl AliasLeafKind {
    fn filename(self) -> &'static str {
        match self {
            AliasLeafKind::Metadata => "metadata.json",
            AliasLeafKind::Log => "log.jsonl",
            AliasLeafKind::Graph => "graph.json",
            AliasLeafKind::Children => "children.jsonl",
        }
    }
}

async fn assert_tracking_path_rejected(
    app: &axum::Router,
    endpoint: TrackingEndpointKind,
    project_id: &str,
    app_id: &str,
    leak_marker: Option<&str>,
    context: &str,
) {
    let response =
        tracking_endpoint_request(app, endpoint, project_id, app_id, DEFAULT_PARTITION_KEY).await;
    assert_bad_request_response(response, leak_marker, context).await;
}

#[cfg(unix)]
async fn assert_parent_swap_rejected(kind: TrackingEndpointKind) {
    use std::os::unix::fs as unix_fs;

    // Initialize before mutating paths so requests exercise post-startup root revalidation.
    match kind {
        TrackingEndpointKind::Projects => {
            let (storage_dir, app) = single_app_tempdir_app(
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            build_single_app_fixture(
                outside_dir.path(),
                "shadow-proj",
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );
            let moved_project_dir = storage_dir
                .path()
                .join(format!("{DEFAULT_PROJECT_ID}-real"));

            fs::rename(
                storage_dir.path().join(DEFAULT_PROJECT_ID),
                &moved_project_dir,
            )
            .expect("project dir should move out of the original path");
            unix_fs::symlink(
                outside_dir.path().join("shadow-proj"),
                storage_dir.path().join(DEFAULT_PROJECT_ID),
            )
            .expect("project symlink replacement should be created");

            assert_tracking_path_rejected(
                &app,
                kind,
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some("shadow-proj"),
                "projects listing must fail closed after a parent storage swap",
            )
            .await;
        }
        TrackingEndpointKind::Apps => {
            let (storage_dir, app) = single_app_tempdir_app(
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            let outside_project_dir = outside_dir.path().join("outside-project");
            fs::create_dir_all(outside_project_dir.join(DEFAULT_APP_ID))
                .expect("outside app dir should be created");
            fs::write(
                outside_project_dir
                    .join(DEFAULT_APP_ID)
                    .join("metadata.json"),
                json!({
                    "partition_key": DEFAULT_PARTITION_KEY,
                    "parent_pointer": Value::Null,
                    "spawning_parent_pointer": Value::Null
                })
                .to_string(),
            )
            .expect("outside metadata should be written");
            let moved_project_dir = storage_dir
                .path()
                .join(format!("{DEFAULT_PROJECT_ID}-real"));

            fs::rename(
                storage_dir.path().join(DEFAULT_PROJECT_ID),
                &moved_project_dir,
            )
            .expect("project dir should move out of the original path");
            unix_fs::symlink(
                &outside_project_dir,
                storage_dir.path().join(DEFAULT_PROJECT_ID),
            )
            .expect("project symlink replacement should be created");

            assert_tracking_path_rejected(
                &app,
                kind,
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                None,
                "apps endpoint must fail closed after a parent project swap",
            )
            .await;
        }
        TrackingEndpointKind::AppDetail => {
            let (storage_dir, app) = single_app_tempdir_app(
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            build_single_app_fixture(
                outside_dir.path(),
                "shadow-proj",
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );
            let outside_app_dir = outside_dir.path().join("shadow-proj").join(DEFAULT_APP_ID);
            fs::write(
                outside_app_dir.join("graph.json"),
                json!({
                    "type": "application",
                    "entrypoint": "outside-graph",
                    "actions": [],
                    "transitions": []
                })
                .to_string(),
            )
            .expect("outside graph should be overwritten");

            let requested_app_dir = storage_dir
                .path()
                .join(DEFAULT_PROJECT_ID)
                .join(DEFAULT_APP_ID);
            let moved_app_dir = storage_dir
                .path()
                .join(DEFAULT_PROJECT_ID)
                .join(format!("{DEFAULT_APP_ID}-real"));

            fs::rename(&requested_app_dir, &moved_app_dir)
                .expect("app dir should move out of the original path");
            unix_fs::symlink(&outside_app_dir, &requested_app_dir)
                .expect("app symlink replacement should be created");

            assert_tracking_path_rejected(
                &app,
                kind,
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some("outside-graph"),
                "app detail must fail closed after a parent app swap",
            )
            .await;
        }
    }
}

async fn assert_path_traversal_rejected(kind: TrackingEndpointKind) {
    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let app = local_backend_app(storage_dir.path());
    assert_tracking_path_rejected(
        &app,
        kind,
        "%2e%2e",
        DEFAULT_APP_ID,
        None,
        "path traversal project ids must fail closed",
    )
    .await;
}

#[cfg(unix)]
async fn assert_same_root_alias_rejected(kind: TrackingEndpointKind) {
    use std::os::unix::fs as unix_fs;

    match kind {
        TrackingEndpointKind::Projects => {
            let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
            build_single_app_fixture(
                storage_dir.path(),
                "real_project",
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );
            unix_fs::symlink(
                storage_dir.path().join("real_project"),
                storage_dir.path().join("alias_project"),
            )
            .expect("project alias should be created");

            let app = local_backend_app(storage_dir.path());
            assert_tracking_path_rejected(
                &app,
                kind,
                "alias_project",
                DEFAULT_APP_ID,
                None,
                "same-root project aliases must fail closed",
            )
            .await;
        }
        TrackingEndpointKind::AppDetail => {
            let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
            build_single_app_fixture(
                storage_dir.path(),
                DEFAULT_PROJECT_ID,
                "real-app",
                Some(DEFAULT_PARTITION_KEY),
            );
            unix_fs::symlink(
                storage_dir.path().join(DEFAULT_PROJECT_ID).join("real-app"),
                storage_dir
                    .path()
                    .join(DEFAULT_PROJECT_ID)
                    .join("alias-app"),
            )
            .expect("app alias should be created");

            let app = local_backend_app(storage_dir.path());
            assert_tracking_path_rejected(
                &app,
                kind,
                DEFAULT_PROJECT_ID,
                "alias-app",
                None,
                "same-root app aliases must fail closed",
            )
            .await;
        }
        TrackingEndpointKind::Apps => unreachable!("apps requests only exercise project aliases"),
    }
}

#[cfg(unix)]
async fn assert_same_root_file_alias_rejected(
    kind: TrackingEndpointKind,
    alias_kind: AliasLeafKind,
) {
    use std::os::unix::fs as unix_fs;

    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    build_single_app_fixture(
        storage_dir.path(),
        DEFAULT_PROJECT_ID,
        "requested-app",
        Some(DEFAULT_PARTITION_KEY),
    );
    build_single_app_fixture(
        storage_dir.path(),
        DEFAULT_PROJECT_ID,
        "sibling-app",
        Some(DEFAULT_PARTITION_KEY),
    );

    let requested_leaf = storage_dir
        .path()
        .join(DEFAULT_PROJECT_ID)
        .join("requested-app")
        .join(alias_kind.filename());
    let sibling_leaf = storage_dir
        .path()
        .join(DEFAULT_PROJECT_ID)
        .join("sibling-app")
        .join(alias_kind.filename());

    if alias_kind == AliasLeafKind::Children {
        write_jsonl(
            &sibling_leaf,
            &[json!({
                "type": "child_application_data",
                "child": {
                    "type": "pointer_data",
                    "app_id": "child-1",
                    "sequence_id": 0,
                    "partition_key": DEFAULT_PARTITION_KEY
                },
                "event_time": "2026-03-20T00:00:00.000000000Z",
                "event_type": "spawn_start",
                "sequence_id": 0
            })],
        );
    }
    if requested_leaf.exists() {
        fs::remove_file(&requested_leaf).expect("requested leaf should be removable");
    }
    unix_fs::symlink(&sibling_leaf, &requested_leaf).expect("same-root alias should be created");

    let app = local_backend_app(storage_dir.path());
    assert_tracking_path_rejected(
        &app,
        kind,
        DEFAULT_PROJECT_ID,
        "requested-app",
        None,
        "same-root file aliases must fail closed",
    )
    .await;
}

#[cfg(unix)]
async fn assert_apps_symlink_escape_rejected() {
    use std::os::unix::fs as unix_fs;

    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
    build_single_app_fixture(
        outside_dir.path(),
        "external_project",
        DEFAULT_APP_ID,
        Some(DEFAULT_PARTITION_KEY),
    );

    let symlink_name = "external_link";
    unix_fs::symlink(
        outside_dir.path().join("external_project"),
        storage_dir.path().join(symlink_name),
    )
    .expect("symlink should be created");

    let app = local_backend_app(storage_dir.path());
    assert_tracking_path_rejected(
        &app,
        TrackingEndpointKind::Apps,
        symlink_name,
        DEFAULT_APP_ID,
        None,
        "symlink-escaped project directories must fail closed",
    )
    .await;
}

#[cfg(unix)]
async fn assert_broken_graph_symlink_rejected() {
    use std::os::unix::fs as unix_fs;

    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    build_single_app_fixture(
        storage_dir.path(),
        DEFAULT_PROJECT_ID,
        "requested-app",
        Some(DEFAULT_PARTITION_KEY),
    );
    let requested_graph = storage_dir
        .path()
        .join(DEFAULT_PROJECT_ID)
        .join("requested-app")
        .join("graph.json");
    fs::remove_file(&requested_graph).expect("requested graph should be removable");
    unix_fs::symlink(
        storage_dir
            .path()
            .join(DEFAULT_PROJECT_ID)
            .join("requested-app")
            .join("missing-graph.json"),
        &requested_graph,
    )
    .expect("broken graph symlink should be created");

    let app = local_backend_app(storage_dir.path());
    assert_tracking_path_rejected(
        &app,
        TrackingEndpointKind::AppDetail,
        DEFAULT_PROJECT_ID,
        "requested-app",
        None,
        "broken graph symlinks must fail closed for app detail",
    )
    .await;
}

#[cfg(unix)]
#[tokio::test]
async fn tracking_endpoints_reject_parent_swaps_after_backend_initialization() {
    for kind in [
        TrackingEndpointKind::Apps,
        TrackingEndpointKind::AppDetail,
        TrackingEndpointKind::Projects,
    ] {
        assert_parent_swap_rejected(kind).await;
    }
}

#[tokio::test]
async fn tracking_endpoints_reject_path_traversal_project_ids() {
    for kind in [TrackingEndpointKind::Apps, TrackingEndpointKind::AppDetail] {
        assert_path_traversal_rejected(kind).await;
    }
}

#[cfg(unix)]
#[tokio::test]
async fn apps_endpoint_rejects_symlink_escape_outside_storage_root() {
    assert_apps_symlink_escape_rejected().await;
}

#[cfg(unix)]
#[tokio::test]
async fn tracking_endpoints_reject_same_root_project_and_app_aliases() {
    for kind in [
        TrackingEndpointKind::Projects,
        TrackingEndpointKind::AppDetail,
    ] {
        assert_same_root_alias_rejected(kind).await;
    }
}

#[cfg(unix)]
#[tokio::test]
async fn tracking_endpoints_reject_same_root_file_aliases() {
    for (kind, alias_kind) in [
        (TrackingEndpointKind::Apps, AliasLeafKind::Metadata),
        (TrackingEndpointKind::Apps, AliasLeafKind::Log),
        (TrackingEndpointKind::AppDetail, AliasLeafKind::Metadata),
        (TrackingEndpointKind::AppDetail, AliasLeafKind::Graph),
        (TrackingEndpointKind::AppDetail, AliasLeafKind::Log),
        (TrackingEndpointKind::AppDetail, AliasLeafKind::Children),
    ] {
        assert_same_root_file_alias_rejected(kind, alias_kind).await;
    }
}

#[cfg(unix)]
#[tokio::test]
async fn app_detail_endpoint_rejects_broken_graph_symlink() {
    assert_broken_graph_symlink_rejected().await;
}
