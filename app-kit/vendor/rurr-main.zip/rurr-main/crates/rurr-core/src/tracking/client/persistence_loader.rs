use super::validation::map_tracking_error;
use super::*;
use store_util::tracking_repository::{
    open_app_dir_if_present,
    read::{self as repository_read, PartitionSemantics, VisitPartitionedAppsError},
};
impl LocalTrackingClient {
    #[cfg(test)]
    fn select_end_entry_from_text(
        text: &str,
        sequence_id: Option<u64>,
    ) -> Result<Option<store_util::tracked_log::TrackedEndEntry>, PersistenceError> {
        let reader = std::io::Cursor::new(text.as_bytes());
        let (selected, _) = store_util::tracked_log::select_tracked_end_entries_from_reader::<
            _,
            TrackingError,
        >(reader, sequence_id, None)
        .map_err(map_tracking_error)?;

        if sequence_id.is_some() && selected.is_none() {
            return Err(PersistenceError::UnsupportedOperation {
                operation: "sequence_id_not_found",
            });
        }

        Ok(selected)
    }

    fn select_end_entry_from_child(
        anchor: &store_util::anchored_fs::AnchoredDir,
        sequence_id: Option<u64>,
    ) -> Result<Option<store_util::tracked_log::TrackedEndEntry>, PersistenceError> {
        let (selected, _) = repository_read::select_app_end_entries(anchor, sequence_id, None)
            .map_err(|error| {
                map_local_tracking_read_error(LocalTrackingRead::RequiredLog, error)
            })?;

        if sequence_id.is_some() && selected.is_none() {
            return Err(PersistenceError::UnsupportedOperation {
                operation: "sequence_id_not_found",
            });
        }

        Ok(selected)
    }
}

impl BaseStateLoader for LocalTrackingClient {
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        let Some(app_id) = app_id else {
            return Ok(None);
        };

        Self::validate_app_id(app_id).map_err(Self::map_invalid_app_id_for_load)?;
        let Some(app_anchor) =
            open_app_dir_if_present(self.project_anchor(), app_id).map_err(|error| {
                map_local_tracking_read_error(LocalTrackingRead::RepositoryListing, error)
            })?
        else {
            return Ok(None);
        };
        let metadata =
            repository_read::read_required_app_metadata_header(&app_anchor).map_err(|error| {
                map_local_tracking_read_error(LocalTrackingRead::RequiredMetadata, error)
            })?;
        if !repository_read::partition_matches(
            metadata.partition_key(),
            partition_key,
            PartitionSemantics::LoaderNormalizedDefault,
        ) {
            return Ok(None);
        }
        let persisted_partition_key = Self::normalize_partition_key(metadata.partition_key());
        let entry = Self::select_end_entry_from_child(&app_anchor, sequence_id)?;
        let Some(entry) = entry else {
            return Ok(None);
        };

        let mut state = entry.state;
        state.retain(|key, _| !is_reserved_runtime_input(key));
        state.insert("__SEQUENCE_ID".to_string(), Value::from(entry.sequence_id));

        let status = if entry.exception.is_some() {
            PersistedStateStatus::Failed
        } else {
            PersistedStateStatus::Completed
        };

        Ok(Some(PersistedStateData {
            partition_key: Some(persisted_partition_key),
            app_id: app_id.to_string(),
            sequence_id: entry.sequence_id,
            position: Some(entry.action),
            state: Some(state),
            created_at: Some(entry.end_time),
            status,
        }))
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        let mut app_ids = Vec::new();
        repository_read::visit_sorted_partitioned_apps(
            self.project_anchor(),
            partition_key,
            PartitionSemantics::LoaderNormalizedDefault,
            |entry| {
                app_ids.push(entry.app_id);
                Ok::<(), std::convert::Infallible>(())
            },
        )
        .map_err(|error| match error {
            VisitPartitionedAppsError::List(error) => {
                map_local_tracking_read_error(LocalTrackingRead::RepositoryListing, error)
            }
            VisitPartitionedAppsError::Metadata(error) => {
                map_local_tracking_read_error(LocalTrackingRead::RequiredMetadata, error)
            }
            VisitPartitionedAppsError::Visit(never) => match never {},
        })?;

        Ok(app_ids)
    }
}

#[derive(Clone, Copy)]
enum LocalTrackingRead {
    RequiredLog,
    RequiredMetadata,
    RepositoryListing,
}

impl LocalTrackingRead {
    fn is_invalid_persisted_state(self, kind: std::io::ErrorKind) -> bool {
        match self {
            Self::RequiredLog => matches!(
                kind,
                std::io::ErrorKind::NotFound
                    | std::io::ErrorKind::InvalidData
                    | std::io::ErrorKind::InvalidInput
            ),
            Self::RequiredMetadata => {
                matches!(
                    kind,
                    std::io::ErrorKind::InvalidData | std::io::ErrorKind::InvalidInput
                )
            }
            Self::RepositoryListing => false,
        }
    }
}

fn map_local_tracking_read_error(
    kind: LocalTrackingRead,
    error: std::io::Error,
) -> PersistenceError {
    if kind.is_invalid_persisted_state(error.kind()) {
        return PersistenceError::InvalidPersistedState {
            operation: "local_tracking_client_load",
            message: error.to_string(),
        };
    }

    map_tracking_error(TrackingError::Io(error))
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn end_entry_line(sequence_id: u64, count: u64) -> String {
        json!({
            "type": "end_entry",
            "end_time": "2026-03-20T00:00:00.000000000Z",
            "action": "counter",
            "result": {"count": count},
            "exception": Value::Null,
            "state": {"count": count, "__SEQUENCE_ID": sequence_id, "__PRIOR_STEP": "counter"},
            "sequence_id": sequence_id
        })
        .to_string()
    }

    #[test]
    fn select_end_entry_prefers_latest_matching_sequence_id() {
        let text = [
            end_entry_line(9, 1),
            end_entry_line(3, 2),
            end_entry_line(9, 3),
        ]
        .join("\n");

        let selected = LocalTrackingClient::select_end_entry_from_text(&text, Some(9))
            .expect("parse should succeed")
            .expect("matching sequence should be selected");

        assert_eq!(selected.sequence_id, 9);
        assert_eq!(selected.state.get("count"), Some(&json!(3)));
    }

    #[test]
    fn select_end_entry_ignores_truncated_trailing_jsonl_line() {
        let text = format!(
            "{}\n{}",
            end_entry_line(1, 1),
            r#"{"type":"end_entry","sequence_id":2"#
        );

        let selected = LocalTrackingClient::select_end_entry_from_text(&text, None)
            .expect("parse should succeed")
            .expect("latest complete end_entry should be selected");

        assert_eq!(selected.sequence_id, 1);
    }

    #[test]
    fn select_end_entry_errors_on_malformed_non_terminal_line() {
        let text = format!("{{ not valid json\n{}", end_entry_line(2, 2));

        let error = LocalTrackingClient::select_end_entry_from_text(&text, None)
            .expect_err("non-terminal malformed json must fail");

        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation {
                operation: "local_tracking_client_operation"
            }
        ));
    }

    #[test]
    fn select_end_entry_returns_error_when_requested_sequence_missing() {
        let text = [end_entry_line(1, 1), end_entry_line(2, 2)].join("\n");

        let error = LocalTrackingClient::select_end_entry_from_text(&text, Some(999))
            .expect_err("missing explicit sequence should fail");

        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation {
                operation: "sequence_id_not_found"
            }
        ));
    }
}
