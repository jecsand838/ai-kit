//! Visibility helpers for wrapping execution in trace spans and child scopes.
//!
//! These helpers stay intentionally small: [`trace`] and [`trace_async`] run a
//! closure inside a configured tracer, while [`ActionSpan`] and
//! [`TraceSpanHandle`] expose the lower-level span lifecycle when callers need
//! to emit attributes or child spans manually.

mod factory;
mod span;
mod span_scope;
mod trace_api;

pub use factory::{TraceSpanHandle, VisibilityError};
pub use span::ActionSpan;
pub use trace_api::{trace, trace_async, TraceOptions};

pub(crate) use factory::TraceSession;
