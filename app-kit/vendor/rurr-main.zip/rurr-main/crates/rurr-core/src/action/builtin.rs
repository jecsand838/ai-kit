use crate::action::api::{ActionContext, ActionError, ActionResult, LocalAction};
use crate::action::macro_support;
use crate::state::State;
use indexmap::IndexMap;
use std::collections::HashSet;

/// Action that copies named runtime inputs into both the result payload and
/// state writes.
#[derive(Debug, Clone)]
pub struct InputAction {
    fields: Vec<String>,
    name: Option<String>,
}

impl InputAction {
    /// Creates an input action for the provided field names.
    pub fn new<F, I>(fields: I) -> Self
    where
        F: Into<String>,
        I: IntoIterator<Item = F>,
    {
        Self {
            fields: normalize_fields(fields),
            name: None,
        }
    }
}

impl LocalAction for InputAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &self.fields
    }

    fn inputs(&self) -> &[String] {
        &self.fields
    }

    fn source_code(&self) -> Option<String> {
        Some(input_action_source(&self.fields))
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        macro_support::with_name_once(self, self.name.as_deref(), name, |copied, next_name| {
            copied.name = Some(next_name);
        })
    }

    fn run(&self, _state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        let mut payload = IndexMap::new();
        for key in &self.fields {
            let value = ctx
                .inputs
                .get(key)
                .cloned()
                .ok_or_else(|| ActionError::MissingInput { key: key.clone() })?;
            payload.insert(key.clone(), value);
        }
        Ok(ActionResult::new(payload.clone(), payload))
    }
}

/// Action that reads selected state fields into the result payload without
/// writing state.
#[derive(Debug, Clone)]
pub struct ResultAction {
    fields: Vec<String>,
    name: Option<String>,
}

impl ResultAction {
    /// Creates a result action for the provided field names.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use indexmap::IndexMap;
    /// use rurr_core::action::{ActionContext, LocalAction, ResultAction};
    /// use rurr_core::State;
    /// use serde_json::json;
    ///
    /// let action = ResultAction::new(["count"]);
    /// let state = State::new(IndexMap::from([("count".to_string(), json!(3))]));
    /// let result = action.run(&state, &ActionContext::default())?;
    /// assert_eq!(result.result().get("count"), Some(&json!(3)));
    /// # Ok::<(), rurr_core::ActionError>(())
    /// ```
    pub fn new<F, I>(fields: I) -> Self
    where
        F: Into<String>,
        I: IntoIterator<Item = F>,
    {
        Self {
            fields: normalize_fields(fields),
            name: None,
        }
    }
}

impl LocalAction for ResultAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &self.fields
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn source_code(&self) -> Option<String> {
        Some(result_action_source(&self.fields))
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        macro_support::with_name_once(self, self.name.as_deref(), name, |copied, next_name| {
            copied.name = Some(next_name);
        })
    }

    fn run(&self, state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        // Iterate borrowed entries so we only clone selected values, not the full state snapshot.
        let requested_fields: HashSet<&str> = self.fields.iter().map(String::as_str).collect();
        let result = state
            .entries()
            .filter(|(key, _)| requested_fields.contains(key.as_str()))
            .map(|(key, value)| (key.clone(), value.clone()))
            .collect();
        Ok(ActionResult::new(result, IndexMap::new()))
    }
}

fn normalize_fields<F, I>(fields: I) -> Vec<String>
where
    F: Into<String>,
    I: IntoIterator<Item = F>,
{
    fields.into_iter().map(Into::into).collect()
}

fn format_string_array(fields: &[String]) -> String {
    let formatted = fields
        .iter()
        .map(|field| format!("{field:?}"))
        .collect::<Vec<_>>()
        .join(", ");
    format!("[{formatted}]")
}

fn input_action_source(fields: &[String]) -> String {
    let fields = format_string_array(fields);
    format!(
        "fn input_action(_state: &State, ctx: &ActionContext) -> ActionResult {{\n    let fields = {fields};\n    let mut payload = IndexMap::new();\n    for key in fields {{\n        let value = ctx.inputs.get(key).cloned().expect(\"declared input must exist\");\n        payload.insert(key.to_string(), value);\n    }}\n    ActionResult::new(payload.clone(), payload)\n}}"
    )
}

fn result_action_source(fields: &[String]) -> String {
    let fields = format_string_array(fields);
    format!(
        "fn result_action(state: &State, _ctx: &ActionContext) -> ActionResult {{\n    let fields = {fields};\n    let result = state\n        .entries()\n        .filter(|(key, _)| fields.contains(&key.as_str()))\n        .map(|(key, value)| (key.clone(), value.clone()))\n        .collect();\n    ActionResult::new(result, IndexMap::new())\n}}"
    )
}

#[cfg(test)]
mod tests {
    use super::{InputAction, ResultAction};
    use crate::action::{ActionContext, LocalAction};
    use crate::state::State;
    use indexmap::IndexMap;
    use serde_json::json;

    #[test]
    fn result_action_run_returns_only_requested_fields() {
        let mut values = IndexMap::new();
        for i in 0..128 {
            values.insert(format!("key_{i}"), json!(i));
        }
        let state = State::new(values);
        let action = ResultAction::new(["key_3", "key_89", "missing"]);

        let result = action
            .run(&state, &ActionContext::default())
            .expect("result action run should succeed");

        assert_eq!(
            result.result(),
            &IndexMap::from([
                ("key_3".to_string(), json!(3)),
                ("key_89".to_string(), json!(89)),
            ])
        );
        assert!(
            result.writes().is_empty(),
            "result action should not produce state writes"
        );
        assert_eq!(result.result().len(), 2, "missing fields should be omitted");
    }

    #[test]
    fn builtin_actions_report_deterministic_source_code() {
        let input = InputAction::new(["first", "second"]);
        let result = ResultAction::new(["count"]);

        let input_source = input
            .source_code()
            .expect("input action should report source");
        let result_source = result
            .source_code()
            .expect("result action should report source");

        assert!(input_source.contains(r#"["first", "second"]"#));
        assert!(input_source.contains("ActionResult::new(payload.clone(), payload)"));
        assert!(result_source.contains(r#"["count"]"#));
        assert!(result_source.contains("ActionResult::new(result, IndexMap::new())"));
    }
}
