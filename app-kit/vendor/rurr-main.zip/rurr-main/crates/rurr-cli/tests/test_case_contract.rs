mod test_case;

mod test_case_contract {
    use crate::test_case::{
        run_test_case_create, test_case_create_command, write_tracking_fixture,
    };
    use rurr_testkit::command_fixture::{
        assert_failure, assert_success, run_command, stderr_lossy, stdout_utf8,
    };
    use serde_json::Value;
    use std::fs;
    use std::io;
    #[cfg(unix)]
    use std::os::unix::fs::symlink;
    use std::path::Path;
    use std::path::PathBuf;

    #[derive(Clone, Copy, Debug)]
    enum TestSerdeDecoderBehavior {
        DecodeFixtureState,
        ExitNonzero,
        InvalidJson,
        NonObject,
    }

    struct TestSerdeDecoder {
        _root: tempfile::TempDir,
        path: PathBuf,
    }

    impl TestSerdeDecoder {
        fn path(&self) -> &Path {
            &self.path
        }
    }

    #[cfg(unix)]
    fn install_test_serde_decoder(
        behavior: TestSerdeDecoderBehavior,
    ) -> io::Result<TestSerdeDecoder> {
        use std::os::unix::fs::PermissionsExt;

        let root = tempfile::tempdir()?;
        let path = root.path().join("serde-decoder");
        let script = match behavior {
            TestSerdeDecoderBehavior::DecodeFixtureState => {
                "#!/usr/bin/env bash\nset -euo pipefail\npayload=\"$(cat)\"\ncase \"$payload\" in\n  *'\"serialized::before\"'*) printf '%s' '{\"custom_field\":\"before\",\"tagged_payload\":\"decoded::before\"}' ;;\n  *'\"serialized::after\"'*) printf '%s' '{\"custom_field\":\"after\",\"tagged_payload\":\"decoded::after\"}' ;;\n  *) printf '%s\\n' \"unexpected decoder input: $payload\" >&2; exit 97 ;;\nesac\n"
            }
            TestSerdeDecoderBehavior::ExitNonzero => {
                "#!/usr/bin/env bash\nset -euo pipefail\nprintf '%s\\n' 'decoder failed on purpose' >&2\nexit 23\n"
            }
            TestSerdeDecoderBehavior::InvalidJson => {
                "#!/usr/bin/env bash\nset -euo pipefail\nprintf '%s' 'not-json'\n"
            }
            TestSerdeDecoderBehavior::NonObject => {
                "#!/usr/bin/env bash\nset -euo pipefail\nprintf '%s' '[]'\n"
            }
        };
        fs::write(&path, script)?;
        let mut permissions = fs::metadata(&path)?.permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(&path, permissions)?;
        Ok(TestSerdeDecoder { _root: root, path })
    }

    #[cfg(windows)]
    fn install_test_serde_decoder(
        behavior: TestSerdeDecoderBehavior,
    ) -> io::Result<TestSerdeDecoder> {
        let root = tempfile::tempdir()?;
        let path = root.path().join("serde-decoder.cmd");
        let script = match behavior {
            TestSerdeDecoderBehavior::DecodeFixtureState => {
                "@echo off\r\nsetlocal\r\nset \"payload=\"\r\nset /p payload=\r\necho %payload% | findstr /c:\"serialized::before\" >nul\r\nif not errorlevel 1 (\r\n  <nul set /p ={\"custom_field\":\"before\",\"tagged_payload\":\"decoded::before\"}\r\n  exit /b 0\r\n)\r\necho %payload% | findstr /c:\"serialized::after\" >nul\r\nif not errorlevel 1 (\r\n  <nul set /p ={\"custom_field\":\"after\",\"tagged_payload\":\"decoded::after\"}\r\n  exit /b 0\r\n)\r\necho unexpected decoder input 1>&2\r\nexit /b 97\r\n"
            }
            TestSerdeDecoderBehavior::ExitNonzero => {
                "@echo off\r\necho decoder failed on purpose 1>&2\r\nexit /b 23\r\n"
            }
            TestSerdeDecoderBehavior::InvalidJson => {
                "@echo off\r\n<nul set /p =not-json\r\nexit /b 0\r\n"
            }
            TestSerdeDecoderBehavior::NonObject => {
                "@echo off\r\n<nul set /p =[]\r\nexit /b 0\r\n"
            }
        };
        fs::write(&path, script)?;
        Ok(TestSerdeDecoder { _root: root, path })
    }

    fn assert_test_case_failure_contains(
        output: &std::process::Output,
        context: &str,
        needle: &str,
    ) {
        assert_failure(output, context);
        let stderr = stderr_lossy(output);
        assert!(
            stderr.contains(needle),
            "expected stderr to contain {needle:?}, got: {stderr}"
        );
    }

    mod fixture_generation;
    mod serde_decoder;
    mod validation;
}
