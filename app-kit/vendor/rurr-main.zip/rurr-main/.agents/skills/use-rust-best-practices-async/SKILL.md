---
name: use-rust-best-practices-async
description: "Apply this when writing or reviewing async Rust, Tokio, or futures-based code. Use it for task spawning, join/select patterns, bounded fan-out, cancellation, graceful shutdown, stream handling, mutex and channel choices, LocalSet/spawn_local, and bridging sync and async code while eliminating blocking calls, await-while-locked bugs, and clone-heavy ownership mistakes."
---

# Rust async, Tokio, and futures best practices

Use this skill whenever a Rust task includes `async`, Tokio, futures, streams, spawned tasks, cancellation, or graceful shutdown.

## When to use

Use it when the task:

- adds or modifies `async fn`
- uses Tokio or futures
- spawns tasks or fans out work
- introduces channels, mutexes, or shared async state
- needs cancellation or graceful shutdown
- mixes sync and async code
- needs bounded concurrency or backpressure

## Do not use this skill alone when

- the task is mostly about HTTP/gRPC/database clients → also load `$use-rust-best-practices-networking`
- the task is mostly about testing async code → also load `$use-rust-best-practices-testing`
- the task is mostly about trait/lifetime/error design → also load `$use-rust-best-practices-abstractions`

## Workflow

1. Use async only where it buys concurrency or latency hiding.
2. Keep async all the way to natural process boundaries.
3. Choose between direct await, `join!`, `select!`, `JoinSet`, and bounded stream fan-out based on concurrency shape.
4. Use short lock scopes and avoid holding guards across `.await`.
5. Own values at task boundaries; borrow within a task.
6. Design shutdown up front: cancellation signal + task tracking + bounded cleanup.

## Default rules

- Prefer direct `.await` over spawning if the task does not need to outlive the caller.
- Prefer `tokio::try_join!` for a small fixed set of sibling futures.
- Prefer `tokio::task::JoinSet` for dynamic sets of spawned tasks.
- Prefer bounded `buffer_unordered` / `for_each_concurrent` over unbounded fan-out.
- Prefer `std::sync::Mutex` for short non-await critical sections around plain data.
- Use `tokio::sync::Mutex` only when the guard must cross `.await` or when protecting shared async I/O state.
- Treat `spawn_blocking` as a narrow bridge for bounded blocking work, not as a general worker-pool substitute.

## Load these references directly when needed

- `references/async.md` — async dos/don'ts, Tokio/futures patterns, cancellation, graceful shutdown, and bad-vs-best examples.

## Load these templates when useful

- `assets/templates/graceful_shutdown.rs`
- `assets/templates/bounded_fanout.rs`
- `assets/templates/localset_spawn_local.rs`

## Companion skills

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-abstractions`
