use crate::ExprError;
use rustpython_parser::ast;
use serde_json::Value;
use std::collections::BTreeMap;

/// Normalized runtime value used while evaluating an expression.
#[derive(Debug, Clone, PartialEq)]
pub enum EvalValue {
    /// JSON null.
    Null,
    /// Boolean value.
    Bool(bool),
    /// Exact integer value.
    Int(i128),
    /// Floating-point value.
    Float(f64),
    /// UTF-8 string value.
    String(String),
    /// Ordered list value.
    Array(Vec<EvalValue>),
    /// Keyed object value.
    Object(BTreeMap<String, EvalValue>),
}

/// Numeric representation used by arithmetic helpers during evaluation.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum NumberValue {
    /// Exact integer value.
    Int(i128),
    /// Floating-point value.
    Float(f64),
}

/// Coerces a boolean or numeric [`EvalValue`] into a [`NumberValue`].
pub fn coerce_number(value: &EvalValue) -> Result<NumberValue, ExprError> {
    match value {
        EvalValue::Bool(boolean) => Ok(NumberValue::Int(if *boolean { 1 } else { 0 })),
        EvalValue::Int(integer) => Ok(NumberValue::Int(*integer)),
        EvalValue::Float(float) => Ok(NumberValue::Float(*float)),
        other => Err(ExprError::TypeError {
            message: format!("expected numeric value, got {other:?}"),
        }),
    }
}

/// Coerces an [`EvalValue`] into a Python-style integer subscript index.
pub fn coerce_index(value: &EvalValue) -> Result<i128, ExprError> {
    match value {
        EvalValue::Bool(boolean) => Ok(if *boolean { 1 } else { 0 }),
        EvalValue::Int(integer) => Ok(*integer),
        other => Err(ExprError::InvalidSubscript {
            message: format!("list indices must be integers, got {other:?}"),
        }),
    }
}

/// Converts a [`NumberValue`] into `f64` for mixed-mode arithmetic.
pub fn number_to_f64(value: NumberValue) -> f64 {
    match value {
        NumberValue::Int(integer) => integer as f64,
        NumberValue::Float(float) => float,
    }
}

/// Returns `true` when `value` participates in numeric arithmetic and comparison.
pub fn is_numeric_like(value: &EvalValue) -> bool {
    matches!(
        value,
        EvalValue::Bool(_) | EvalValue::Int(_) | EvalValue::Float(_)
    )
}

/// Applies Python-style truthiness rules to an evaluated value.
pub fn is_truthy(value: &EvalValue) -> bool {
    match value {
        EvalValue::Null => false,
        EvalValue::Bool(boolean) => *boolean,
        EvalValue::Int(integer) => *integer != 0,
        EvalValue::Float(float) => *float != 0.0,
        EvalValue::String(text) => !text.is_empty(),
        EvalValue::Array(items) => !items.is_empty(),
        EvalValue::Object(values) => !values.is_empty(),
    }
}

/// Converts a parsed Python constant into an [`EvalValue`].
pub fn constant_to_eval_value(constant: &ast::Constant) -> Result<EvalValue, ExprError> {
    match constant {
        ast::Constant::None => Ok(EvalValue::Null),
        ast::Constant::Bool(boolean) => Ok(EvalValue::Bool(*boolean)),
        ast::Constant::Str(text) => Ok(EvalValue::String(text.clone())),
        ast::Constant::Int(value) => {
            let integer = i128::try_from(value.clone()).map_err(|_| ExprError::IntegerOverflow)?;
            Ok(EvalValue::Int(integer))
        }
        ast::Constant::Float(value) => Ok(EvalValue::Float(*value)),
        _ => Err(ExprError::UnsupportedConstant {
            constant: format!("{constant:?}"),
        }),
    }
}

/// Converts a JSON value into the evaluation representation used by this crate.
pub fn json_to_eval_value(value: &Value) -> Result<EvalValue, ExprError> {
    match value {
        Value::Null => Ok(EvalValue::Null),
        Value::Bool(boolean) => Ok(EvalValue::Bool(*boolean)),
        Value::Number(number) => {
            if let Some(value) = number.as_i64() {
                return Ok(EvalValue::Int(i128::from(value)));
            }
            if let Some(value) = number.as_u64() {
                return Ok(EvalValue::Int(i128::from(value)));
            }
            if let Some(value) = number.as_f64() {
                return Ok(EvalValue::Float(value));
            }
            Err(ExprError::TypeError {
                message: format!("unsupported number value: {number}"),
            })
        }
        Value::String(text) => Ok(EvalValue::String(text.clone())),
        Value::Array(items) => {
            let mut converted = Vec::with_capacity(items.len());
            for item in items {
                converted.push(json_to_eval_value(item)?);
            }
            Ok(EvalValue::Array(converted))
        }
        Value::Object(values) => {
            let mut converted = BTreeMap::new();
            for (key, value) in values {
                converted.insert(key.clone(), json_to_eval_value(value)?);
            }
            Ok(EvalValue::Object(converted))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{coerce_index, coerce_number, EvalValue};
    use crate::{value::NumberValue, ExprError};

    #[test]
    fn coerce_number_rejects_non_numeric_values() {
        let error = coerce_number(&EvalValue::String("not numeric".to_string()))
            .expect_err("string should fail");

        assert_eq!(
            error,
            ExprError::TypeError {
                message: "expected numeric value, got String(\"not numeric\")".to_string(),
            }
        );
    }

    #[test]
    fn coerce_number_accepts_boolean_values() {
        assert_eq!(
            coerce_number(&EvalValue::Bool(true)),
            Ok(NumberValue::Int(1))
        );
        assert_eq!(
            coerce_number(&EvalValue::Bool(false)),
            Ok(NumberValue::Int(0))
        );
    }

    #[test]
    fn coerce_index_rejects_non_integer_values() {
        let error = coerce_index(&EvalValue::Float(1.5)).expect_err("float index should fail");

        assert_eq!(
            error,
            ExprError::InvalidSubscript {
                message: "list indices must be integers, got Float(1.5)".to_string(),
            }
        );
    }
}
