use super::{stream_invariant, StreamTerminal};
use crate::application::{Application, ApplicationError};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum StreamPhase {
    NotStarted,
    Streaming,
    Finalizing,
    Done,
}

#[derive(Debug, Clone, PartialEq)]
pub(super) enum TerminalState {
    Missing,
    Ready(StreamTerminal),
}

#[derive(Debug, Clone, PartialEq)]
pub(super) struct StreamProgress {
    pub(super) phase: StreamPhase,
    pub(super) terminal: TerminalState,
}

impl StreamProgress {
    pub(super) fn new(terminal: Option<StreamTerminal>) -> Self {
        let phase = if terminal.is_some() {
            StreamPhase::Done
        } else {
            StreamPhase::NotStarted
        };
        Self {
            phase,
            terminal: terminal
                .map(TerminalState::Ready)
                .unwrap_or(TerminalState::Missing),
        }
    }

    pub(super) fn is_done(&self) -> bool {
        matches!(self.phase, StreamPhase::Done)
    }

    pub(super) fn mark_streaming_started(&mut self) {
        if matches!(self.phase, StreamPhase::NotStarted) {
            self.phase = StreamPhase::Streaming;
        }
    }

    pub(super) fn begin_finalizing(&mut self) {
        if !self.is_done() {
            self.phase = StreamPhase::Finalizing;
        }
    }

    pub(super) fn mark_done(&mut self) {
        self.phase = StreamPhase::Done;
    }

    pub(super) fn clear_terminal(&mut self) {
        self.terminal = TerminalState::Missing;
    }

    pub(super) fn set_terminal(&mut self, terminal: StreamTerminal) {
        self.terminal = TerminalState::Ready(terminal);
    }

    pub(super) fn finish_with_terminal(&mut self, terminal: StreamTerminal) {
        self.set_terminal(terminal);
        self.mark_done();
    }

    pub(super) fn has_terminal(&self) -> bool {
        matches!(self.terminal, TerminalState::Ready(_))
    }

    pub(super) fn terminal_or_invariant(
        &self,
        message: &'static str,
    ) -> Result<StreamTerminal, ApplicationError> {
        match &self.terminal {
            TerminalState::Ready(terminal) => Ok(terminal.clone()),
            TerminalState::Missing => Err(stream_invariant(message)),
        }
    }

    pub(super) fn cache_current_state_if_missing(&mut self, app: Option<&Application>) {
        if matches!(self.terminal, TerminalState::Missing) {
            if let Some(app) = app {
                self.terminal = TerminalState::Ready((None, app.state().clone()));
            }
        }
    }

    pub(super) fn finish_from_current_state(&mut self, app: Option<&Application>) {
        if self.is_done() {
            return;
        }
        self.begin_finalizing();
        self.cache_current_state_if_missing(app);
        self.mark_done();
    }
}
