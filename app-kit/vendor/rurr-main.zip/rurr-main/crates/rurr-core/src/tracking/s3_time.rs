//! Shared Burr-compatible S3 timestamp parsing helpers.
//!
//! These parsers intentionally accept the timestamp spellings used by Burr S3
//! tracking keys and snapshot keys, then reject malformed dates, non-UTC
//! snapshots, and over-precise fractions.
//!
//! # Examples
//!
//! ```
//! use rurr_core::tracking::s3_time::{
//!     parse_burr_time_suffix, parse_tracking_utc_partition, parse_utc_iso_timestamp,
//! };
//!
//! assert_eq!(parse_burr_time_suffix("03:02.123456")?, (3, 2, 123_456_000));
//! assert_eq!(parse_tracking_utc_partition("2026", "05", "07", "14", "03:02")?.year(), 2026);
//! assert!(parse_utc_iso_timestamp("2026-05-07T14:03:02Z").is_ok());
//! assert!(parse_utc_iso_timestamp("2026-05-07T14:03:02-05:00").is_err());
//! # Ok::<(), Box<dyn std::error::Error>>(())
//! ```

use std::fmt::Display;
use std::str::FromStr;
use thiserror::Error;
use time::{Date, Month, OffsetDateTime, Time};

/// Error raised while parsing S3 tracking or snapshot timestamp segments.
#[derive(Debug, Clone, PartialEq, Eq, Error)]
#[error("{0}")]
pub struct S3TimeParseError(String);

impl S3TimeParseError {
    fn invalid(message: impl Into<String>) -> Self {
        Self(message.into())
    }
}

/// Parses Burr/Rurr S3 time suffixes: `mm:ss`, `mm:ss.ffffff`, or nanoseconds.
///
/// The returned tuple is `(minute, second, nanosecond)`. Fractions longer than
/// nanosecond precision are rejected instead of truncated.
pub fn parse_burr_time_suffix(segment: &str) -> Result<(u8, u8, u32), S3TimeParseError> {
    let (minute, second, nanos) = split_clock_suffix(segment)?;
    if minute >= 60 || second >= 60 {
        return Err(S3TimeParseError::invalid(
            "minute segment must match mm:ss or mm:ss.<1-9 digits>",
        ));
    }
    Ok((minute, second, nanos))
}

/// Parses a UTC tracking partition into a typed timestamp.
///
/// The inputs are the five path segments used in Burr S3 tracking keys:
/// `YYYY`, `MM`, `DD`, `HH`, and `mm:ss[.fraction]`.
pub fn parse_tracking_utc_partition(
    year: &str,
    month: &str,
    day: &str,
    hour: &str,
    minute: &str,
) -> Result<OffsetDateTime, S3TimeParseError> {
    let year = parse_fixed_segment(year, 4, "year")?;
    let month = parse_fixed_segment(month, 2, "month")?;
    let day = parse_fixed_segment(day, 2, "day")?;
    let hour = parse_fixed_segment(hour, 2, "hour")?;
    let (minute, second, nanos) = parse_burr_time_suffix(minute)?;
    utc_datetime(year, month, day, hour, minute, second, nanos)
}

/// Parses `YYYY-MM-DDTHH:MM:SS[.fraction](Z|+00:00)` as a UTC timestamp.
///
/// Non-UTC offsets are rejected instead of converted because snapshot keys use
/// UTC as part of their stable provider ordering.
pub fn parse_utc_iso_timestamp(timestamp: &str) -> Result<OffsetDateTime, S3TimeParseError> {
    let timestamp = timestamp
        .strip_suffix('Z')
        .or_else(|| timestamp.strip_suffix("+00:00"))
        .ok_or_else(|| S3TimeParseError::invalid("snapshot timestamp must be UTC"))?;
    let (date, time) = timestamp
        .split_once('T')
        .ok_or_else(|| S3TimeParseError::invalid("snapshot timestamp must contain 'T'"))?;
    if date.len() != 10 || &date[4..5] != "-" || &date[7..8] != "-" {
        return Err(S3TimeParseError::invalid(
            "snapshot timestamp date must match YYYY-MM-DD",
        ));
    }
    let year = parse_fixed_segment(&date[..4], 4, "year")?;
    let month = parse_fixed_segment(&date[5..7], 2, "month")?;
    let day = parse_fixed_segment(&date[8..], 2, "day")?;
    let (hour, minute, second, nanos) = split_clock_time(time)?;
    utc_datetime(year, month, day, hour, minute, second, nanos)
}

fn parse_fixed_segment<T>(segment: &str, len: usize, label: &str) -> Result<T, S3TimeParseError>
where
    T: FromStr,
    T::Err: Display,
{
    if segment.len() != len || !segment.bytes().all(|byte| byte.is_ascii_digit()) {
        return Err(S3TimeParseError::invalid(format!(
            "{label} segment must be {len} digits"
        )));
    }
    segment
        .parse::<T>()
        .map_err(|error| S3TimeParseError::invalid(format!("{label} segment is invalid: {error}")))
}

fn split_clock_suffix(segment: &str) -> Result<(u8, u8, u32), S3TimeParseError> {
    let (minute, rest) = segment.split_once(':').ok_or_else(invalid_clock)?;
    let (second, fraction) = rest.split_once('.').unwrap_or((rest, ""));
    Ok((
        two_digit_segment(minute)?,
        two_digit_segment(second)?,
        nanos_from_fraction(fraction, segment.contains('.'))?,
    ))
}

fn split_clock_time(time: &str) -> Result<(u8, u8, u8, u32), S3TimeParseError> {
    let mut parts = time.splitn(3, ':');
    let hour = parts.next().ok_or_else(invalid_clock)?;
    let minute = parts.next().ok_or_else(invalid_clock)?;
    let second = parts.next().ok_or_else(invalid_clock)?;
    let (second, fraction) = second.split_once('.').unwrap_or((second, ""));
    Ok((
        two_digit_segment(hour)?,
        two_digit_segment(minute)?,
        two_digit_segment(second)?,
        nanos_from_fraction(fraction, time.contains('.'))?,
    ))
}

fn two_digit_segment(segment: &str) -> Result<u8, S3TimeParseError> {
    if segment.len() == 2 && segment.bytes().all(|byte| byte.is_ascii_digit()) {
        Ok((segment.as_bytes()[0] - b'0') * 10 + (segment.as_bytes()[1] - b'0'))
    } else {
        Err(invalid_clock())
    }
}

fn nanos_from_fraction(fraction: &str, has_fraction: bool) -> Result<u32, S3TimeParseError> {
    if fraction.is_empty() && !has_fraction {
        return Ok(0);
    }
    if fraction.is_empty()
        || fraction.len() > 9
        || !fraction.bytes().all(|byte| byte.is_ascii_digit())
    {
        return Err(S3TimeParseError::invalid("fraction must be 1-9 digits"));
    }
    Ok(fraction
        .bytes()
        .fold(0, |nanos, byte| nanos * 10 + u32::from(byte - b'0'))
        * 10_u32.pow((9 - fraction.len()) as u32))
}

fn utc_datetime(
    year: i32,
    month: u8,
    day: u8,
    hour: u8,
    minute: u8,
    second: u8,
    nanos: u32,
) -> Result<OffsetDateTime, S3TimeParseError> {
    let month =
        Month::try_from(month).map_err(|_| S3TimeParseError::invalid("invalid month segment"))?;
    let date = Date::from_calendar_date(year, month, day)
        .map_err(|_| S3TimeParseError::invalid("invalid UTC calendar date"))?;
    let time = Time::from_hms_nano(hour, minute, second, nanos)
        .map_err(|_| S3TimeParseError::invalid("invalid UTC time"))?;
    Ok(OffsetDateTime::new_utc(date, time))
}

fn invalid_clock() -> S3TimeParseError {
    S3TimeParseError::invalid(
        "time must match HH:MM:SS, mm:ss, or include a 1-9 digit fraction where supported",
    )
}
