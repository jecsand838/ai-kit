use zerocopy::{FromBytes, Immutable, IntoBytes};

use crate::Result;
use crate::error::BlobstoreError;

pub trait Blob: Sized {
    fn to_bytes(&self) -> Vec<u8>;

    /// Decode a value from its bytes.
    ///
    /// Stored bytes may be corrupt, so this must return an error rather than panic.
    fn from_bytes(bytes: &[u8]) -> Result<Self>;
}

impl Blob for Vec<u8> {
    fn to_bytes(&self) -> Vec<u8> {
        self.clone()
    }

    fn from_bytes(bytes: &[u8]) -> Result<Self> {
        Ok(bytes.to_vec())
    }
}

impl Blob for Vec<ecow::EcoString> {
    fn to_bytes(&self) -> Vec<u8> {
        serde_cbor::to_vec(self).expect("Failed to serialize Vec<ecow::EcoString>")
    }

    fn from_bytes(bytes: &[u8]) -> Result<Self> {
        serde_cbor::from_slice(bytes).map_err(|err| {
            BlobstoreError::decode_error(format!(
                "Failed to deserialize Vec<ecow::EcoString>: {err}"
            ))
        })
    }
}

impl Blob for Vec<(f64, f64)> {
    fn to_bytes(&self) -> Vec<u8> {
        self.iter()
            .flat_map(|(a, b)| a.to_le_bytes().into_iter().chain(b.to_le_bytes()))
            .collect()
    }

    fn from_bytes(bytes: &[u8]) -> Result<Self> {
        if !bytes.len().is_multiple_of(size_of::<f64>() * 2) {
            return Err(BlobstoreError::decode_error(format!(
                "unexpected number of bytes for Vec<(f64, f64)>: {}",
                bytes.len(),
            )));
        }
        Ok(bytes
            .chunks(size_of::<f64>() * 2)
            .map(|v| {
                let (a, b) = v.split_at(size_of::<f64>());
                (
                    f64::read_from_bytes(a).expect("invalid number of bytes for type f64"),
                    f64::read_from_bytes(b).expect("invalid number of bytes for type f64"),
                )
            })
            .collect())
    }
}

macro_rules! impl_blob_vec_zerocopy {
    ($type:ty) => {
        impl Blob for Vec<$type>
        where
            $type: FromBytes + IntoBytes + Immutable,
        {
            fn to_bytes(&self) -> Vec<u8> {
                self.iter()
                    .flat_map(|item| item.as_bytes())
                    .copied()
                    .collect()
            }

            fn from_bytes(bytes: &[u8]) -> Result<Self> {
                if !bytes.len().is_multiple_of(size_of::<$type>()) {
                    return Err(BlobstoreError::decode_error(format!(
                        "unexpected number of bytes for Vec<{}>: {}",
                        stringify!($type),
                        bytes.len(),
                    )));
                }
                Ok(bytes
                    .chunks(size_of::<$type>())
                    .map(|v| <$type>::read_from_bytes(v).expect("invalid chunk size for type T"))
                    .collect())
            }
        }
    };
}

impl_blob_vec_zerocopy!(i64);
impl_blob_vec_zerocopy!(u128);
impl_blob_vec_zerocopy!(f64);
