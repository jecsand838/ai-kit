use rurr_telemetry::{capture_cli_command, force_flush, shutdown};
use rurr_testkit::env::EnvVarGuard;
use rurr_testkit::live_services::{
    otel_log_attribute as log_attribute, otel_resource_attribute_value as resource_attribute_value,
    otel_span_attribute as span_attribute, otel_string_any_value as string_any_value,
    reset_otel_file_exports, wait_for_raw_otel_exports, RawOtelLogRecord, RawOtelTraceSpan,
};
use serde_json::Value;
use std::path::Path;
use std::time::Duration;
use tempfile::tempdir;

const CLI_EVENT: &str = "os_burr_cli_command";

fn anonymous_id_from_config(home: &Path) -> String {
    std::fs::read_to_string(home.join(".rurr.conf"))
        .expect("telemetry config should exist")
        .lines()
        .find_map(|line| {
            line.trim()
                .strip_prefix("anonymous_id = ")
                .map(str::to_string)
        })
        .expect("telemetry config should persist anonymous_id")
}

fn wait_for_telemetry_exports(anonymous_id: &str) -> (RawOtelTraceSpan, RawOtelLogRecord) {
    wait_for_raw_otel_exports(
        Duration::from_secs(15),
        "collector file exporter did not record the expected telemetry OTLP signals within 15s",
        |spans, logs| {
            let cli_span = spans.iter().find(|export| {
                export.span.get("name").and_then(Value::as_str) == Some(CLI_EVENT)
                    && span_attribute(&export.span, "command").and_then(string_any_value)
                        == Some("serve")
                    && span_attribute(&export.span, "anonymous_id").and_then(string_any_value)
                        == Some(anonymous_id)
            });
            let cli_log = logs.iter().find(|export| {
                export.record.get("eventName").and_then(Value::as_str) == Some(CLI_EVENT)
                    && log_attribute(&export.record, "command").and_then(string_any_value)
                        == Some("serve")
                    && log_attribute(&export.record, "anonymous_id").and_then(string_any_value)
                        == Some(anonymous_id)
            });

            if let (Some(cli_span), Some(cli_log)) = (cli_span, cli_log) {
                return Some((cli_span.clone(), cli_log.clone()));
            }
            None
        },
    )
    .expect("collector file exporter should return the expected telemetry OTLP signals")
}

#[tokio::test(flavor = "multi_thread")]
async fn telemetry_exports_cli_signal_to_collector_files() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let home = tempdir().expect("tempdir should create");
    let docker_config = std::env::var("DOCKER_CONFIG").ok().or_else(|| {
        std::env::var("HOME")
            .ok()
            .map(|home| format!("{home}/.docker"))
    });
    {
        let _env = EnvVarGuard::set([
            (
                "HOME",
                Some(home.path().to_str().expect("home path should be utf-8")),
            ),
            ("USERPROFILE", None),
            ("HOMEDRIVE", None),
            ("HOMEPATH", None),
            ("DOCKER_CONFIG", docker_config.as_deref()),
            ("BURR_TELEMETRY_ENABLED", Some("true")),
            ("OTEL_EXPORTER_OTLP_ENDPOINT", Some("http://127.0.0.1:4318")),
            ("OTEL_EXPORTER_OTLP_PROTOCOL", Some("http/protobuf")),
        ]);
        capture_cli_command("serve");
        force_flush();
        shutdown();

        let anonymous_id = anonymous_id_from_config(home.path());
        let (cli_span, cli_log) = wait_for_telemetry_exports(&anonymous_id);

        assert_eq!(
            cli_log.record.get("traceId").and_then(Value::as_str),
            cli_span.span.get("traceId").and_then(Value::as_str)
        );
        assert_eq!(
            cli_log.record.get("spanId").and_then(Value::as_str),
            cli_span.span.get("spanId").and_then(Value::as_str)
        );

        assert_eq!(
            resource_attribute_value(&cli_span.resource_attributes, "service.name")
                .and_then(string_any_value),
            Some("rurr")
        );
        assert_eq!(
            span_attribute(&cli_span.span, "anonymous_id").and_then(string_any_value),
            Some(anonymous_id.as_str())
        );
        assert_eq!(
            span_attribute(&cli_span.span, "telemetry_version").and_then(string_any_value),
            Some("0.1.0")
        );
        assert_eq!(
            resource_attribute_value(&cli_log.resource_attributes, "service.name")
                .and_then(string_any_value),
            Some("rurr")
        );
        assert_eq!(
            log_attribute(&cli_log.record, "anonymous_id").and_then(string_any_value),
            Some(anonymous_id.as_str())
        );
        assert_eq!(
            log_attribute(&cli_log.record, "telemetry_version").and_then(string_any_value),
            Some("0.1.0")
        );
        assert_eq!(
            cli_log.record.get("severityText").and_then(Value::as_str),
            Some("INFO")
        );

        assert_eq!(
            cli_log.record.get("body").and_then(string_any_value),
            Some(CLI_EVENT)
        );
    }
}
