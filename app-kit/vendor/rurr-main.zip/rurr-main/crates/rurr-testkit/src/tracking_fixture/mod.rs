//! Tracking-artifact fixtures and assertions for workspace tests.
//!
//! Use this module when a test needs real tracking directories, seeded JSONL
//! logs, or helper assertions over span and event output rather than ad hoc
//! JSON construction inline.

/// Low-level tracking artifact helpers used by tracking tests.
pub mod artifacts;

use crate::application_fixture::{
    build_sync_app, count_zero_state, counter_action, ApplicationFixtureBuilder,
};
use artifacts::{write_jsonl, ANNOTATIONS_FILENAME, LOG_FILENAME};
use rurr_core::action::LocalAction;
use rurr_core::application::Application;
use rurr_core::lifecycle::{AsyncLifecycleAdapter, LifecycleAdapterSet, SyncLifecycleAdapter};
use rurr_core::tracking::{AttributeModel, BeginSpanModel, EndSpanModel, LocalTrackingClient};
use serde_json::{json, Value};
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};
use std::sync::Arc;

const FIXED_EVENT_TIME: &str = "2026-03-20T00:00:00.000000000Z";

/// Builds the expected tracking metadata JSON value for a partitioned or unpartitioned app.
pub fn tracking_metadata_value(partition_key: Option<&str>) -> Value {
    json!({
        "type": "application_metadata",
        "partition_key": partition_key,
        "parent_pointer": null,
        "spawning_parent_pointer": null
    })
}

/// Appends a raw truncated line to an application's log file for corruption tests.
pub fn append_truncated_app_log_line(
    storage_root: &Path,
    project: &str,
    app_id: &str,
    line: &[u8],
) {
    let log_path = artifacts::project_app_dir(storage_root, project, app_id).join(LOG_FILENAME);
    let mut log = fs::OpenOptions::new()
        .append(true)
        .open(&log_path)
        .expect("log file should open for append");
    log.write_all(line).expect("truncated line should append");
}

/// Writes project-level annotations into the tracking fixture storage root.
pub fn write_project_annotations(storage_root: &Path, project: &str, values: &[Value]) {
    write_jsonl(
        &storage_root.join(project).join(ANNOTATIONS_FILENAME),
        values,
    );
}

/// Creates a local tracking client rooted at `storage_root`.
pub fn tracker(project: &str, storage_root: &Path) -> Arc<LocalTrackingClient> {
    Arc::new(
        LocalTrackingClient::new(project, storage_root).expect("tracking client should initialize"),
    )
}

/// Builds a lifecycle hook set that registers the tracker as a synchronous hook.
pub fn sync_tracking_hooks(tracker: Arc<LocalTrackingClient>) -> LifecycleAdapterSet {
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = tracker;
    LifecycleAdapterSet::new(vec![sync_hook], vec![])
}

/// Builds a lifecycle hook set that registers the tracker as an asynchronous hook.
pub fn async_tracking_hooks(tracker: Arc<LocalTrackingClient>) -> LifecycleAdapterSet {
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = tracker;
    LifecycleAdapterSet::new(vec![], vec![async_hook])
}

/// Returns the tracked application directory for `project/app_id`.
pub fn app_dir(storage_root: &Path, project: &str, app_id: &str) -> PathBuf {
    artifacts::project_app_dir(storage_root, project, app_id)
}

/// Ensures the tracked application directory exists and returns its path.
pub fn ensure_app_dir(storage_root: &Path, project: &str, app_id: &str) -> PathBuf {
    let app_dir = app_dir(storage_root, project, app_id);
    fs::create_dir_all(&app_dir).expect("app directory should exist");
    app_dir
}

/// Returns the application log path for `project/app_id`.
pub fn app_log_path(storage_root: &Path, project: &str, app_id: &str) -> PathBuf {
    app_dir(storage_root, project, app_id).join(LocalTrackingClient::LOG_FILENAME)
}

/// Reads and parses the application log for `project/app_id`.
pub fn read_app_log(storage_root: &Path, project: &str, app_id: &str) -> Vec<Value> {
    artifacts::read_jsonl(&app_log_path(storage_root, project, app_id))
}

/// Writes JSON log entries into an application directory.
pub fn write_app_log_entries(app_dir: &Path, entries: &[Value]) {
    artifacts::write_jsonl(&app_dir.join(LocalTrackingClient::LOG_FILENAME), entries);
}

/// Reads the application log if it exists, otherwise returns an empty vector.
pub fn read_app_log_if_exists(storage_root: &Path, project: &str, app_id: &str) -> Vec<Value> {
    artifacts::read_jsonl_if_exists(&app_log_path(storage_root, project, app_id))
}

/// Builds a successful counter `end_entry` log record.
pub fn counter_end_entry(sequence_id: i64, count: i64) -> Value {
    counter_end_entry_with_exception(sequence_id, count, Value::Null)
}

/// Builds a counter `end_entry` log record with an explicit exception field.
pub fn counter_end_entry_with_exception(sequence_id: i64, count: i64, exception: Value) -> Value {
    json!({
        "type": "end_entry",
        "end_time": FIXED_EVENT_TIME,
        "action": "counter",
        "result": {"count": count},
        "exception": exception,
        "state": {"count": count, "__SEQUENCE_ID": sequence_id, "__PRIOR_STEP": "counter"},
        "sequence_id": sequence_id
    })
}

/// Extracts the ordered `type` field sequence from log lines.
pub fn log_type_sequence(log_lines: &[Value]) -> Vec<String> {
    log_lines
        .iter()
        .map(|line| {
            line.get("type")
                .and_then(Value::as_str)
                .unwrap_or("<missing-type>")
                .to_string()
        })
        .collect()
}

/// Returns the `items_streamed` value from the first `end_stream` log record.
pub fn stream_items_streamed(log_lines: &[Value]) -> i64 {
    let end_stream = log_lines
        .iter()
        .find(|line| line.get("type").and_then(Value::as_str) == Some("end_stream"))
        .expect("end_stream entry should be present");
    end_stream
        .get("items_streamed")
        .and_then(Value::as_i64)
        .expect("end_stream.items_streamed should be i64")
}

/// Counts log entries whose `type` field matches `event_type`.
pub fn count_log_entries(log_lines: &[Value], event_type: &str) -> usize {
    log_lines
        .iter()
        .filter(|line| line.get("type").and_then(Value::as_str) == Some(event_type))
        .count()
}

/// Splits parsed log lines into typed begin-span, end-span, and attribute records.
pub fn span_events(
    log_lines: &[Value],
) -> (Vec<BeginSpanModel>, Vec<EndSpanModel>, Vec<AttributeModel>) {
    (
        log_lines
            .iter()
            .filter(|line| line["type"] == "begin_span")
            .cloned()
            .map(|line| serde_json::from_value(line).expect("begin_span should parse"))
            .collect(),
        log_lines
            .iter()
            .filter(|line| line["type"] == "end_span")
            .cloned()
            .map(|line| serde_json::from_value(line).expect("end_span should parse"))
            .collect(),
        log_lines
            .iter()
            .filter(|line| line["type"] == "attribute")
            .cloned()
            .map(|line| serde_json::from_value(line).expect("attribute should parse"))
            .collect(),
    )
}

/// Asserts that the log line `type` sequence matches `expected`.
pub fn assert_log_types(log_lines: &[Value], expected: &[&str]) {
    assert_eq!(
        log_type_sequence(log_lines),
        expected
            .iter()
            .map(|value| (*value).to_string())
            .collect::<Vec<_>>()
    );
}

/// Asserts the count of each named log event type.
pub fn assert_log_event_counts(log_lines: &[Value], expected: &[(&str, usize)]) {
    for (event_type, expected_count) in expected {
        assert_eq!(
            count_log_entries(log_lines, event_type),
            *expected_count,
            "unexpected count for {event_type}"
        );
    }
}

/// Registers an application's graph and metadata with the provided tracker.
pub fn register_application(tracker: &LocalTrackingClient, app: &Application) {
    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("registration should succeed");
}

/// Builds an application with tracking hooks and registers it with the tracker.
pub fn registered_tracking_app<A: LocalAction + Send + Sync + 'static>(
    tracker: Arc<LocalTrackingClient>,
    app_id: &str,
    partition_key: Option<&str>,
    action_name: &str,
    action: A,
    hooks: LifecycleAdapterSet,
) -> (Arc<LocalTrackingClient>, Application) {
    let app = ApplicationFixtureBuilder::single_action(count_zero_state(), action_name, action)
        .expect("action fixture should configure")
        .with_identifiers(app_id, partition_key.map(str::to_string), None)
        .expect("identifiers should configure")
        .with_hooks(hooks)
        .expect("hooks should configure")
        .build()
        .expect("application should build");
    register_application(tracker.as_ref(), &app);
    (tracker, app)
}

/// Builds the canonical counter application used by tracking fixture tests.
pub fn build_counter_template_app(app_id: &str) -> Application {
    build_sync_app(
        app_id,
        "counter",
        counter_action(),
        LifecycleAdapterSet::default(),
    )
}

/// Builds and registers a synchronous tracking app with an optional partition key.
pub fn registered_sync_app_with_partition<A: LocalAction + Send + Sync + 'static>(
    project: &str,
    storage_root: &Path,
    app_id: &str,
    partition_key: Option<&str>,
    action_name: &str,
    action: A,
) -> (Arc<LocalTrackingClient>, Application) {
    let tracker = tracker(project, storage_root);
    registered_tracking_app(
        Arc::clone(&tracker),
        app_id,
        partition_key,
        action_name,
        action,
        sync_tracking_hooks(tracker),
    )
}

/// Builds and registers a synchronous tracking app under the default `"pk"` partition.
pub fn registered_sync_app<A: LocalAction + Send + Sync + 'static>(
    project: &str,
    storage_root: &Path,
    app_id: &str,
    action_name: &str,
    action: A,
) -> (Arc<LocalTrackingClient>, Application) {
    registered_sync_app_with_partition(
        project,
        storage_root,
        app_id,
        Some("pk"),
        action_name,
        action,
    )
}

/// Builds and registers an asynchronous tracking app with an optional partition key.
pub fn registered_async_app_with_partition<A: LocalAction + Send + Sync + 'static>(
    project: &str,
    storage_root: &Path,
    app_id: &str,
    partition_key: Option<&str>,
    action_name: &str,
    action: A,
) -> (Arc<LocalTrackingClient>, Application) {
    let tracker = tracker(project, storage_root);
    registered_tracking_app(
        Arc::clone(&tracker),
        app_id,
        partition_key,
        action_name,
        action,
        async_tracking_hooks(tracker),
    )
}

/// Builds and registers an asynchronous tracking app under the default `"pk"` partition.
pub fn registered_async_app<A: LocalAction + Send + Sync + 'static>(
    project: &str,
    storage_root: &Path,
    app_id: &str,
    action_name: &str,
    action: A,
) -> (Arc<LocalTrackingClient>, Application) {
    registered_async_app_with_partition(
        project,
        storage_root,
        app_id,
        Some("pk"),
        action_name,
        action,
    )
}

/// Seeds a counter application directory by executing `sequence_id` counter steps.
pub fn seeded_counter_app_dir(
    storage_root: &Path,
    project: &str,
    app_id: &str,
    partition_key: Option<&str>,
    sequence_id: i64,
    count: i64,
) -> (Arc<LocalTrackingClient>, PathBuf) {
    assert_eq!(
        count, sequence_id,
        "counter fixture currently models one increment per sequence id"
    );
    let (tracker, mut app) = registered_sync_app_with_partition(
        project,
        storage_root,
        app_id,
        partition_key,
        "counter",
        counter_action(),
    );
    for _ in 0..sequence_id {
        app.step(None).expect("counter step should succeed");
    }
    let app_dir = app_dir(storage_root, project, app_id);
    (tracker, app_dir)
}

/// Creates a registered application directory without executing any steps.
pub fn seeded_app_dir(
    storage_root: &Path,
    project: &str,
    app_id: &str,
    partition_key: Option<&str>,
) -> (Arc<LocalTrackingClient>, PathBuf) {
    let tracker = tracker(project, storage_root);
    tracker
        .register_application(
            app_id,
            partition_key,
            build_counter_template_app("template").graph(),
            None,
            None,
        )
        .expect("registration should succeed");
    let app_dir = app_dir(storage_root, project, app_id);
    (tracker, app_dir)
}
