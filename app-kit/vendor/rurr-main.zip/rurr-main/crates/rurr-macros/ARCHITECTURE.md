# rurr-macros Architecture

This is the current architecture map for the proc-macro crate on `dev`.

## 1. Project Structure

```text
crates/rurr-macros/
├── src/
│   ├── lib.rs       # proc-macro entrypoints
│   ├── parse.rs     # syntax parsing and signature extraction
│   ├── model.rs     # normalized intermediate model
│   ├── validate.rs  # user-facing contract validation
│   └── expand.rs    # token generation
└── tests/
    ├── integration.rs
    ├── minimal_consumer_contract.rs
    ├── trybuild.rs
    └── ui/
```

## 2. Data-Flow Overview

```text
attribute input
  -> parse.rs
     - read function signature and macro attributes
  -> model.rs
     - normalize reads/writes/inputs/async-ness/context parameters
  -> validate.rs
     - reject unsupported signatures
     - reject reserved runtime identifiers
     - build spanned diagnostics
  -> expand.rs
     - emit deterministic impls and helper glue
  -> downstream compile + trybuild UI tests
```

## 3. Core Responsibilities

- `#[action(...)]` and `#[streaming_action(...)]` are the public macro entrypoints.
- Parsing and validation are intentionally split from expansion so diagnostics stay deterministic
  and targeted.
- Macro output must preserve the public `rurr-core` action contracts rather than inventing a
  separate runtime.

## 4. Key Interfaces

- Public attributes:
  - `#[action(...)]`
  - `#[streaming_action(...)]`
- Internal stages:
  - parse
  - model
  - validate
  - expand

## 5. External Dependencies

- Standard proc-macro stack only:
  - `syn`
  - `quote`
  - `proc-macro2`
- No runtime dependencies are introduced by the macro crate itself.

## 6. Testing And UI Contract

- `trybuild` UI tests are the primary diagnostic contract.
- `tests/ui/*.stderr` pin compile-fail output for reserved identifiers, invalid signatures, and
  accepted pass cases.
- `minimal_consumer_contract.rs` and `integration.rs` pin generated public API behavior against
  real downstream-style usage.

## 7. Security And Guardrails

- Expansion must never `panic!`; diagnostics are returned as spanned `syn::Error`.
- Output must stay deterministic and stable on the pinned Rust toolchain.
- Reserved runtime identifiers and unsupported borrowed streaming outputs are rejected at macro
  validation time rather than surfacing as hidden runtime failures.

## 8. Current-State Notes

- The current internal split across `parse.rs`, `model.rs`, `validate.rs`, and `expand.rs` is the
  intended architecture, not temporary scaffolding.
- Proc-macro behavior is stable at the public surface even though internal organization was
  recently cleaned up.

## 9. Glossary

- `UI test`: a `trybuild` compile-pass or compile-fail contract that pins user-visible diagnostics.
- `Reserved runtime identifiers`: names such as user-declared `__context`-style bindings that are
  intentionally blocked by macro validation.
