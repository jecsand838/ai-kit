use rurr_testkit::command_fixture::{assert_success, run_command, rurr_command, stdout_utf8};

pub(crate) fn run_help(args: &[&str]) -> String {
    let mut command = rurr_command();
    command.args(args);
    let output = run_command(&mut command, "help invocation should run");
    assert_success(&output, &format!("help command failed for args {args:?}"));
    stdout_utf8(&output)
}
