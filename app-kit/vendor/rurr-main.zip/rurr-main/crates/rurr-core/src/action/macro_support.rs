use super::api::{
    boxed_local_async_stream, ActionContext, ActionError, ActionInputs, LocalAction,
    LocalAsyncStreamOutput, RurrError, StreamOutput,
};
use super::function::FunctionActionBuilder;
use super::FunctionAction;
use crate::state::State;
use futures::{stream, Stream, StreamExt};
use serde::de::DeserializeOwned;
use std::future::Future;

pub fn with_name_once<A, F>(
    action: &A,
    current_name: Option<&str>,
    name: impl Into<String>,
    set_name: F,
) -> Result<A, ActionError>
where
    A: Clone,
    F: FnOnce(&mut A, String),
{
    let next_name = name.into();
    if let Some(existing_name) = current_name {
        return Err(ActionError::NameAlreadySet {
            current_name: existing_name.to_string(),
            attempted_name: next_name,
        });
    }

    let mut copied = action.clone();
    set_name(&mut copied, next_name);
    Ok(copied)
}

pub fn deserialize_input<T>(inputs: &ActionInputs, key: &str) -> Result<T, ActionError>
where
    T: DeserializeOwned,
{
    let value = inputs
        .get(key)
        .cloned()
        .ok_or_else(|| ActionError::MissingInput {
            key: key.to_string(),
        })?;
    serde_json::from_value::<T>(value).map_err(|error| ActionError::InputDeserializationFailed {
        key: key.to_string(),
        message: error.to_string(),
    })
}

pub fn async_action_error_stream(error: ActionError) -> LocalAsyncStreamOutput {
    let error = RurrError::Action(error);
    boxed_local_async_stream(stream::once(async move { Err(error) }))
}

pub fn sync_action_error_stream(error: ActionError) -> Box<dyn Iterator<Item = StreamOutput>> {
    Box::new(std::iter::once(Err(RurrError::Action(error))))
}

pub fn deserialize_sync_stream_input<T>(
    inputs: &ActionInputs,
    key: &str,
) -> Result<T, Box<dyn Iterator<Item = StreamOutput>>>
where
    T: DeserializeOwned,
{
    deserialize_input(inputs, key).map_err(sync_action_error_stream)
}

pub fn deserialize_async_stream_input<T>(
    inputs: &ActionInputs,
    key: &str,
) -> Result<T, LocalAsyncStreamOutput>
where
    T: DeserializeOwned,
{
    deserialize_input(inputs, key).map_err(async_action_error_stream)
}

pub fn flatten_local_async_stream<S, Fut>(future: Fut) -> LocalAsyncStreamOutput
where
    S: Stream<Item = StreamOutput> + 'static,
    Fut: Future<Output = S> + 'static,
{
    boxed_local_async_stream(stream::once(future).flatten())
}

pub fn sync_action<H>(
    builder: FunctionActionBuilder,
    handler: H,
) -> Result<FunctionAction, ActionError>
where
    H: Fn(&State, &ActionContext) -> Result<super::ActionResult, ActionError>
        + Send
        + Sync
        + 'static,
{
    builder.into_macro_sync_action(handler)
}

pub fn async_action<H, Fut>(
    builder: FunctionActionBuilder,
    handler: H,
) -> Result<FunctionAction, ActionError>
where
    H: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
    Fut: Future<Output = Result<super::ActionResult, ActionError>> + 'static,
{
    builder.into_macro_async_action(handler)
}

pub fn streaming_sync_action<H, I>(
    builder: FunctionActionBuilder,
    handler: H,
) -> Result<FunctionAction, ActionError>
where
    H: Fn(State, ActionContext) -> I + Send + Sync + 'static,
    I: Iterator<Item = StreamOutput> + 'static,
{
    builder.into_macro_streaming_sync_action(handler)
}

pub fn streaming_async_action<H>(
    builder: FunctionActionBuilder,
    handler: H,
) -> Result<FunctionAction, ActionError>
where
    H: Fn(State, ActionContext) -> LocalAsyncStreamOutput + Send + Sync + 'static,
{
    builder.into_macro_streaming_async_action(handler)
}

pub fn one_shot_stream_from_run_async<A>(
    action: A,
    state: State,
    ctx: ActionContext,
) -> LocalAsyncStreamOutput
where
    A: LocalAction + Sync + 'static,
{
    boxed_local_async_stream(stream::once(async move {
        let result = action
            .run_async(&state, &ctx)
            .await
            .map_err(RurrError::from)?;
        let next_state = action
            .update(&result, &state, &ctx)
            .map_err(RurrError::from)?;
        Ok((result.result().clone(), Some(next_state)))
    }))
}
