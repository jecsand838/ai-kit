use super::contract_logic::{
    app_id_from_partition_index_member, app_index_exact_sequence_lex_range, app_index_member,
    created_at_from_partition_index_member, decode_partition_index_member, hash_to_persisted_state,
    parse_sequence_id, partition_index_member, record_key_from_app_index_member,
    record_key_from_partition_index_member, state_key, OP_RECORD_APP_ID_DESERIALIZATION_FAILED,
    OP_RECORD_PARTITION_KEY_DESERIALIZATION_FAILED, OP_RECORD_SEQUENCE_ID_DESERIALIZATION_FAILED,
    OP_SEQUENCE_ID_OUT_OF_RANGE,
};
use super::PersistenceError;
use std::collections::HashMap;

#[test]
fn state_key_distinguishes_positions_for_same_sequence() {
    assert!(
        state_key("ns", "partition", "app", 7, "left")
            != state_key("ns", "partition", "app", 7, "right"),
        "position must participate in the Redis primary record identity"
    );
}

#[test]
fn app_index_members_sort_by_sequence_then_created_at_then_position() {
    let low_sequence = app_index_member(
        "record::low",
        2,
        "position_2",
        "2026-03-20T00:00:00.000000000Z",
    );
    let newer_same_sequence = app_index_member(
        "record::newer",
        7,
        "position_2",
        "2026-03-20T00:00:01.000000000Z",
    );
    let higher_position_same_timestamp = app_index_member(
        "record::higher_position",
        7,
        "position_9",
        "2026-03-20T00:00:01.000000000Z",
    );

    let mut members = [
        higher_position_same_timestamp.clone(),
        low_sequence,
        newer_same_sequence,
    ];
    members.sort();

    assert_eq!(
        members.last(),
        Some(&higher_position_same_timestamp),
        "reverse lex order should surface the newest app record"
    );
}

#[test]
fn exact_sequence_lex_range_selects_latest_matching_app_member() {
    let older = app_index_member(
        "record::older",
        7,
        "position_1",
        "2026-03-20T00:00:00.000000000Z",
    );
    let newer = app_index_member(
        "record::newer",
        7,
        "position_2",
        "2026-03-20T00:00:01.000000000Z",
    );
    let other_sequence = app_index_member(
        "record::other_sequence",
        8,
        "position_1",
        "2026-03-20T00:00:02.000000000Z",
    );
    let (max, min) = app_index_exact_sequence_lex_range(7);
    let max = max.trim_start_matches('[');
    let min = min.trim_start_matches('[');

    let mut matches = [older, newer.clone(), other_sequence]
        .into_iter()
        .filter(|member| member.as_str() >= min && member.as_str() <= max)
        .collect::<Vec<_>>();
    matches.sort();

    assert_eq!(
        matches.last(),
        Some(&newer),
        "the exact-sequence lex window must return the newest matching member"
    );
    assert_eq!(
        record_key_from_app_index_member(matches.last().expect("member should exist"))
            .expect("record key should decode"),
        "record::newer"
    );
}

#[test]
fn partition_index_members_sort_by_created_at_then_sequence_then_position() {
    let older_created_at = partition_index_member(
        "record::older",
        "app_older",
        99,
        "position_9",
        "2026-03-20T00:00:00.000000000Z",
    );
    let newer_created_at = partition_index_member(
        "record::newer",
        "app_newer",
        1,
        "position_1",
        "2026-03-21T00:00:00.000000000Z",
    );
    let higher_position_same_timestamp = partition_index_member(
        "record::higher_position",
        "app_newer",
        1,
        "position_9",
        "2026-03-21T00:00:00.000000000Z",
    );

    let mut members = [
        newer_created_at,
        older_created_at,
        higher_position_same_timestamp.clone(),
    ];
    members.sort();

    assert_eq!(
        members.last(),
        Some(&higher_position_same_timestamp),
        "reverse lex order should surface the newest partition record"
    );
}

#[test]
fn partition_index_members_prioritize_position_before_app_id_when_timestamps_tie() {
    let lower_position_higher_app_id = partition_index_member(
        "record::lower_position_higher_app_id",
        "zz_app",
        7,
        "position_1",
        "2026-03-21T00:00:00.000000000Z",
    );
    let higher_position_lower_app_id = partition_index_member(
        "record::higher_position_lower_app_id",
        "aa_app",
        7,
        "position_9",
        "2026-03-21T00:00:00.000000000Z",
    );

    let mut members = [
        lower_position_higher_app_id,
        higher_position_lower_app_id.clone(),
    ];
    members.sort();

    assert_eq!(
        members.last(),
        Some(&higher_position_lower_app_id),
        "position must outrank app_id in reverse-lex latest-partition ordering"
    );
}

#[test]
fn partition_index_member_roundtrips_pipe_heavy_app_id_and_namespaced_record_key() {
    let member = partition_index_member(
        "ns:state|12:tenant|pipe|14:app|with|pipes|7|13:position|pipe",
        "app|with|pipes",
        7,
        "position|pipe",
        "2026-03-20T00:00:00.000000000Z",
    );
    let decoded =
        decode_partition_index_member(&member).expect("partition index member should decode");

    assert_eq!(
        app_id_from_partition_index_member(&member).expect("app id should decode"),
        "app|with|pipes"
    );
    assert_eq!(
        created_at_from_partition_index_member(&member).expect("created_at should decode"),
        "2026-03-20T00:00:00.000000000Z"
    );
    assert_eq!(
        record_key_from_partition_index_member(&member).expect("record key should decode"),
        "ns:state|12:tenant|pipe|14:app|with|pipes|7|13:position|pipe"
    );
    assert_eq!(decoded.position, "position|pipe");
}

#[test]
fn parse_sequence_id_accepts_large_u64_values() {
    assert_eq!(
        parse_sequence_id(&u64::MAX.to_string()).expect("u64::MAX should parse"),
        u64::MAX
    );
}

#[test]
fn parse_sequence_id_rejects_non_integer_values() {
    let error = parse_sequence_id("12.5").expect_err("non-integer sequence ids should fail");
    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation { operation }
            if operation == OP_SEQUENCE_ID_OUT_OF_RANGE
    ));
}

#[test]
fn hash_to_persisted_state_rejects_missing_required_identity_fields() {
    let fixtures = [
        (
            HashMap::from([
                ("app_id".to_string(), "app".to_string()),
                ("sequence_id".to_string(), "1".to_string()),
                ("status".to_string(), "completed".to_string()),
            ]),
            OP_RECORD_PARTITION_KEY_DESERIALIZATION_FAILED,
        ),
        (
            HashMap::from([
                ("partition_key".to_string(), "partition".to_string()),
                ("sequence_id".to_string(), "1".to_string()),
                ("status".to_string(), "completed".to_string()),
            ]),
            OP_RECORD_APP_ID_DESERIALIZATION_FAILED,
        ),
        (
            HashMap::from([
                ("partition_key".to_string(), "partition".to_string()),
                ("app_id".to_string(), "app".to_string()),
                ("status".to_string(), "completed".to_string()),
            ]),
            OP_RECORD_SEQUENCE_ID_DESERIALIZATION_FAILED,
        ),
    ];

    for (fields, expected_operation) in fixtures {
        let error = hash_to_persisted_state(fields).expect_err("missing required field must fail");
        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == expected_operation
        ));
    }
}
