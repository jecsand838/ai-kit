# rurr-core Architecture

This document maps the current `rurr-core` runtime for the `dev` branch.
It complements, but does not override:

1. `docs/ARCHITECTURE_GUARDRAILS.md`
2. `docs/compatibility/DIVERGENCES.md`
3. `docs/compatibility/SEMANTICS.md`

## 1. Project Structure

```text
crates/rurr-core/
├── src/
│   ├── action/              # action traits, function/macro support, conditions
│   ├── application/
│   │   ├── api.rs
│   │   ├── build/           # runtime assembly
│   │   ├── builder.rs
│   │   ├── execution_options.rs
│   │   ├── halt_controls.rs # graph-validated action/tag halt selectors
│   │   ├── graph_view.rs
│   │   ├── initialize_from_spec.rs
│   │   ├── resources.rs     # runtime resources and build-time wiring
│   │   ├── session.rs       # committed session state and run-loop coordination
│   │   ├── state_meta.rs    # reserved runtime metadata helpers
│   │   ├── step_txn.rs      # step commit/rollback boundary
│   │   ├── streaming/       # live sync/async streaming handles and progression
│   │   ├── tracker_spec.rs
│   │   ├── transaction.rs
│   │   └── types.rs
│   ├── lifecycle/           # sync/async lifecycle adapters and defaults
│   ├── parallelism/         # child runtime, executors, map helpers
│   ├── tracking/            # LocalTrackingClient, lifecycle models, S3 behind feature s3
│   ├── visibility/          # tracing/span model and OTEL-facing visibility hooks
│   └── state/               # State + typing + field serde
└── tests/
    ├── contract.rs
    ├── cross_process_locking_contract.rs
    ├── e2e.rs
    ├── golden.rs
    ├── jsonl_locking_contract.rs
    ├── local_tracking_client_contract.rs
    ├── public_parallelism_api.rs
    ├── public_surface_contract.rs
    ├── s3_tracking_live.rs
    ├── unit.rs
    ├── ui.rs
```

## 2. Runtime Flow

```text
ApplicationBuilder
  -> build/
     - graph/import merge
     - identifier resolution
     - initialize_from / persistence spec resolution
     - tracker and runtime resource assembly
  -> Application
     - committed state + graph view
     - step/run/arun entrypoints
     - context/inspection helpers
     - execution options resolve into session-owned controls
  -> session.rs
     - next-action resolution
     - committed execution state
     - run/iterate coordination
  -> step_txn.rs
     - pre-step snapshot
     - commit on terminal success
     - rollback on drop/error/panic
  -> streaming/*
     - live handle construction
     - per-item progression
     - explicit async finalization
```

## 3. Core Components

### 3.1. Application Assembly

- `ApplicationBuilder` is the public assembly surface.
- `build/` resolves graphs, identifiers, persistence specs, trackers, typing, and runtime
  metadata into one application instance.
- `InitializeFromSpec` is the canonical builder-side resume/fork configuration wrapper.

### 3.2. Session And Step Transactions

- `session.rs` owns committed application progress and execution-loop coordination.
- `halt_controls.rs` resolves raw `ExecutionOptions` selectors once against the graph. Explicit
  action selectors keep caller order, `@tag:<tag>` selectors expand in graph action order, and
  unknown tags/actions fail before execution.
- `step_txn.rs` is the transaction boundary for both normal and streaming execution:
  - intermediate streaming items do not commit application state
  - terminal completion commits atomically
  - interruption rolls back reserved runtime metadata and state

### 3.3. Streaming

- `application/streaming/` owns live sync and async streaming sessions.
- Handles borrow the application/session so concurrent advancement is impossible at compile time.
- Async cleanup remains explicit; `Drop` is rollback-only and never awaits hooks.

### 3.4. Parallelism

- `parallelism/` owns `ParallelExecutor`, `ParallelRuntimeContext`, `SubGraphTask`, and the map
  helper types.
- Child execution delegates through runtime-owned wiring rather than rebuilding tracker or
  persistence state in external executors.

### 3.5. Tracking And Visibility

- `tracking/` owns the public `LocalTrackingClient` plus shared tracking models and validation; S3
  tracking helpers are compiled only with feature `s3`, including provider layout, metadata, time,
  transport, and fail-closed stream-state helpers.
- `visibility/` owns action-span tracing and tracer adapters used by lifecycle integrations; OTEL
  export remains in `rurr-otel`, not in core.

## 4. Key Interfaces

- `ApplicationBuilder`
- `Application`
- `ApplicationGraph`
- `ApplicationPersistenceSpec`
- `StateInitializerSpec`
- `StatePersisterSpec`
- `PersistenceLoadTarget`
- `InitializeFromSpec`
- `TrackerSpec`
- `ParallelExecutor`
- `SubGraphTask`
- `ActionContext`

## 5. Stores, Integrations, And Boundaries

- `rurr-core` depends on `rurr-persistence` for canonical persistence contracts.
- Optional backend crates are activated through Cargo features for live tests and runtime use.
- Tracking IO is delegated to `rurr-tracking-store`.
- S3 tracking is a concrete optional tracker in `rurr-core`, behind feature `s3`; the default core
  build does not compile AWS SDK transport code.
- Explicit OTEL export lives in `rurr-otel` and wires into core through lifecycle hooks.

## 6. Testing And Verification

- Public/runtime behavior is pinned by:
  - contract tests in `tests/contract.rs` + `tests/contract/*`
  - golden, local tracking, JSONL locking, and public-surface tests
  - S3 live provider tests in `tests/s3_tracking_live.rs` when feature `s3` and live MinIO are enabled
  - compile-fail UI tests in `tests/ui.rs`
  - env-gated e2e oracle and live-backend flows
- tagged halt-control contracts cover sync/async run, iterate, stream-result, and stream-iterate
  behavior; S3 live tracking tests prove fail-closed lifecycle missing-state behavior through raw
  provider objects
- Primary local crate gates:
  - `cargo test -q -p rurr-core`
  - targeted `--test contract ...`
  - `cargo test -q -p rurr-core --test ui`

## 7. Security And Guardrails

- No buffered fake streaming.
- No internal `realize_stream`.
- No `spawn_blocking`, thread-spawn escapes, or runtime-dependent cleanup in `Drop`.
- Reserved runtime metadata stays typed and validated rather than injected as user inputs.

## 8. Current-State Notes

- The old `application/app_model`, `application/runtime_assembly`, and `application/engine`
  shapes are historical scaffolding, not the current operator-facing architecture.
- Tracking types and helpers live directly in `rurr-core`; there is no separate workspace tracking
  API crate in the current layout.
- `TrackerSpec::s3(...)` is the builder-facing S3 tracking path and keeps provider details out of
  the public application API.

## 9. Glossary

- `Session`: committed runtime/application progress between calls.
- `StepTxn`: per-step atomic commit/rollback context.
- `TrackerSpec::local(...)`: builder-side construction of a real local tracker in `rurr-core`.
- `TrackerSpec::s3(...)`: builder-side construction of a real S3 tracker when feature `s3` is enabled.
- `ActionContext`: typed runtime context for inputs, tracing, and application metadata.
