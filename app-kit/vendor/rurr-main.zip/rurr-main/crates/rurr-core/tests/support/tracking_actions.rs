use indexmap::IndexMap;
use rurr_core::action::{ActionTracer, FunctionAction, FunctionActionBuilder};
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::visibility::{trace, trace_async, TraceOptions, TraceSpanHandle};
use rurr_testkit::application_fixture::{counter_action as counter_fixture_action, map_from_pairs};
use serde_json::{json, Value};

pub(crate) fn build_single_step_sync_action() -> FunctionAction {
    counter_fixture_action()
}

pub(crate) fn build_delta_sync_action() -> FunctionAction {
    FunctionActionBuilder::new()
        .inputs(["delta"])
        .reads(["count"])
        .writes(["count"])
        .with_source_code(
            "fn build_delta_sync_action(state, ctx) { let next_count = state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + ctx.inputs.get(\"delta\").and_then(Value::as_i64).unwrap_or(0); map_from_pairs([(\"count\", json!(next_count))]) }",
        )
        .build_sync(|state, ctx| {
            let next_count = state.get("count").and_then(Value::as_i64).unwrap_or(0)
                + ctx.inputs.get("delta").and_then(Value::as_i64).unwrap_or(0);
            map_from_pairs([("count", json!(next_count))])
        })
        .expect("delta action should build")
}

pub(crate) fn build_traced_sync_action() -> FunctionAction {
    FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .with_source_code(
            "fn build_traced_sync_action(state, ctx) { trace(&ctx.tracer, \"increment\", &IndexMap::new(), &TraceOptions::new().with_capture_inputs(false).with_capture_auto_attributes(false).with_capture_outputs(false), |outer| { outer.trace_child_with_dependencies(\"inner\", vec![\"counter_dep\".to_string()], |inner| { inner.log_attribute(\"counter\", json!(state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1)).expect(\"attribute logging should succeed\"); }).expect(\"inner span should succeed\"); map_from_pairs([(\"count\", json!(state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1))]) }).expect(\"trace should succeed\") }",
        )
        .build_sync(|state, ctx| {
            let next_count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            trace(
                &ctx.tracer,
                "increment",
                &IndexMap::new(),
                &TraceOptions::new()
                    .with_capture_inputs(false)
                    .with_capture_auto_attributes(false)
                    .with_capture_outputs(false),
                |outer: TraceSpanHandle| {
                    outer
                        .trace_child_with_dependencies(
                            "inner",
                            vec!["counter_dep".to_string()],
                            |inner: TraceSpanHandle| {
                                inner
                                    .log_attribute("counter", json!(next_count))
                                    .expect("attribute logging should succeed");
                            },
                        )
                        .expect("inner span should succeed");
                    map_from_pairs([("count", json!(next_count))])
                },
            )
            .expect("trace should succeed")
        })
        .expect("traced action should build")
}

pub(crate) fn build_traced_async_action() -> FunctionAction {
    FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .with_source_code(
            "async fn build_traced_async_action(state, ctx) { trace_async(&ctx.tracer, \"increment_async\", &IndexMap::new(), &TraceOptions::new().with_capture_inputs(false).with_capture_auto_attributes(false).with_capture_outputs(false), |outer| async move { outer.trace_child_with_dependencies_async(\"inner_async\", vec![\"counter_dep_async\".to_string()], |inner| async move { inner.log_attribute_async(\"counter_async\", json!(state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1)).await.expect(\"attribute logging should succeed\"); }).await.expect(\"inner async span should succeed\"); map_from_pairs([(\"count\", json!(state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1))]) }).await.expect(\"async trace should succeed\") }",
        )
        .build_async(|state, ctx| async move {
            let next_count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            trace_async(
                &ctx.tracer,
                "increment_async",
                &IndexMap::new(),
                &TraceOptions::new()
                    .with_capture_inputs(false)
                    .with_capture_auto_attributes(false)
                    .with_capture_outputs(false),
                |outer: TraceSpanHandle| async move {
                    outer
                        .trace_child_with_dependencies_async(
                            "inner_async",
                            vec!["counter_dep_async".to_string()],
                            |inner: TraceSpanHandle| async move {
                                inner
                                    .log_attribute_async("counter_async", json!(next_count))
                                    .await
                                    .expect("attribute logging should succeed");
                            },
                        )
                        .await
                        .expect("inner async span should succeed");
                    map_from_pairs([("count", json!(next_count))])
                },
            )
            .await
            .expect("async trace should succeed")
        })
        .expect("traced async action should build")
}

pub(crate) fn build_cross_factory_routed_sync_action() -> FunctionAction {
    FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .with_source_code(
            "fn build_cross_factory_routed_sync_action(state, ctx) { let next_count = state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1; let foreign_tracer = ActionTracer::new(\"foreign_action\", 999, LifecycleAdapterSet::default(), \"foreign-app\", None); trace(&ctx.tracer, \"cross_factory_outer\", &IndexMap::new(), &TraceOptions::new().with_capture_inputs(false).with_capture_auto_attributes(false).with_capture_outputs(false), |outer| { trace(&foreign_tracer, \"foreign_outer\", &IndexMap::new(), &TraceOptions::new().with_capture_inputs(false).with_capture_auto_attributes(false).with_capture_outputs(false), |_foreign| ()).expect(\"foreign trace should succeed\"); outer.log_attribute(\"counter_cross_factory\", json!(next_count)).expect(\"attribute logging should succeed\"); map_from_pairs([(\"count\", json!(next_count))]) }).expect(\"cross-factory trace should succeed\") }",
        )
        .build_sync(|state, ctx| {
            let next_count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            let foreign_tracer = ActionTracer::new(
                "foreign_action",
                999,
                LifecycleAdapterSet::default(),
                "foreign-app",
                None,
            );
            trace(
                &ctx.tracer,
                "cross_factory_outer",
                &IndexMap::new(),
                &TraceOptions::new()
                    .with_capture_inputs(false)
                    .with_capture_auto_attributes(false)
                    .with_capture_outputs(false),
                |outer: TraceSpanHandle| {
                    trace(
                        &foreign_tracer,
                        "foreign_outer",
                        &IndexMap::new(),
                        &TraceOptions::new()
                            .with_capture_inputs(false)
                            .with_capture_auto_attributes(false)
                            .with_capture_outputs(false),
                        |_foreign: TraceSpanHandle| (),
                    )
                    .expect("foreign trace should succeed");
                    outer
                        .log_attribute("counter_cross_factory", json!(next_count))
                        .expect("attribute logging should succeed");
                    map_from_pairs([("count", json!(next_count))])
                },
            )
            .expect("cross-factory trace should succeed")
        })
        .expect("cross-factory traced action should build")
}
