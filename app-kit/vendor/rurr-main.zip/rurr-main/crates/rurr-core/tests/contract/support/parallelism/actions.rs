use rurr_core::action::{ActionContext, ActionError, ActionKind, ActionResult, FunctionAction};
use rurr_core::application::ApplicationError;
use rurr_core::parallelism::{SubGraphTask, TaskBasedParallelAction};
use rurr_core::state::State;
use rurr_testkit::action_fixture::{scripted_action, ScriptedActionSpec};
use rurr_testkit::action_metadata::NamedActionMetadata;
use std::sync::Arc;

pub(crate) type FailingAction = FunctionAction;

pub(crate) fn failing_action() -> FailingAction {
    scripted_action(
        NamedActionMetadata::from_slices(&[], &[], &[]),
        ScriptedActionSpec::from_run(|_state, _ctx| {
            Err(ActionError::Internal {
                message: "child failure".to_string(),
            })
        })
        .with_source_code(
            "fn failing_action(_state, _ctx) -> Result<ActionResult, ActionError> { Err(ActionError::Internal { message: \"child failure\".to_string() }) }",
        ),
    )
}

#[derive(Clone)]
pub(crate) struct ExplicitTaskAction {
    metadata: NamedActionMetadata,
    task_builder: ExplicitTaskBuilder,
    reducer: ExplicitTaskReducer,
    async_only: bool,
}

pub(crate) type ExplicitTaskBuilder = Arc<
    dyn Fn(&State, &ActionContext) -> Result<Vec<SubGraphTask>, ApplicationError> + Send + Sync,
>;
pub(crate) type ExplicitTaskReducer =
    Arc<dyn Fn(&State, Vec<State>) -> Result<ActionResult, ApplicationError> + Send + Sync>;

impl ExplicitTaskAction {
    pub(crate) fn new(
        reads: Vec<String>,
        writes: Vec<String>,
        inputs: Vec<String>,
        task_builder: ExplicitTaskBuilder,
        reducer: ExplicitTaskReducer,
        async_only: bool,
    ) -> ExplicitTaskAction {
        Self {
            metadata: NamedActionMetadata::from_owned(reads, writes, inputs),
            task_builder,
            reducer,
            async_only,
        }
    }
}

impl rurr_core::LocalAction for ExplicitTaskAction {
    fn name(&self) -> Option<&str> {
        self.metadata.name()
    }

    fn reads(&self) -> &[String] {
        self.metadata.reads()
    }

    fn writes(&self) -> &[String] {
        self.metadata.writes()
    }

    fn inputs(&self) -> &[String] {
        self.metadata.inputs()
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        Ok(Self {
            metadata: self.metadata.with_name_cloned(name)?,
            task_builder: Arc::clone(&self.task_builder),
            reducer: Arc::clone(&self.reducer),
            async_only: self.async_only,
        })
    }

    fn source_code(&self) -> Option<String> {
        Some("fn explicit_task_action(state, ctx) -> Result<ActionResult, ApplicationError> { self.run_task_sync(state, ctx) }".to_string())
    }

    fn kind(&self) -> ActionKind {
        if self.async_only {
            ActionKind::Async
        } else {
            ActionKind::Sync
        }
    }

    fn run(&self, state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        self.run_task_sync(state, ctx)
    }

    async fn run_async(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        self.run_task_async(state, ctx).await
    }
}

impl TaskBasedParallelAction for ExplicitTaskAction {
    fn tasks(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<Vec<SubGraphTask>, ApplicationError> {
        (self.task_builder)(state, ctx)
    }

    fn reduce(
        &self,
        parent_state: &State,
        child_states: Vec<State>,
    ) -> Result<ActionResult, ApplicationError> {
        (self.reducer)(parent_state, child_states)
    }
}
