//! Burr-compatible S3 tracking object layout and addressing helpers.
//!
//! Burr stores tracking data under a time-partitioned S3 prefix. Rurr keeps the
//! same public object layout while centralizing key construction and parsing so
//! tracking clients and the tracking server cannot drift independently. The
//! filename segment remains part of the ordering contract: graph and metadata
//! use their Burr names, while lifecycle log objects use sequence-prefixed
//! names so raw provider key order reflects emission order.
//!
//! Layout helpers validate prefixes, timestamps, partition sentinels, and
//! artifact filenames before callers index or write objects. They intentionally
//! preserve the raw key string so strict provider tests and the tracking server
//! can reason about provider order directly.
//!
//! # Examples
//!
//! ```
//! use rurr_core::tracking::{partition_segment, S3Prefix, S3TrackingObjectKey};
//!
//! let prefix = S3Prefix::new("/data/")?;
//! let key = S3TrackingObjectKey::build(
//!     &prefix,
//!     "project",
//!     time::OffsetDateTime::UNIX_EPOCH,
//!     None,
//!     "app",
//!     "graph.json",
//! )?;
//! let parsed = S3TrackingObjectKey::parse(&prefix, &key)?;
//!
//! assert_eq!(partition_segment(None), "__none__");
//! assert_eq!(parsed.project_id(), "project");
//! assert_eq!(parsed.partition_key(), None);
//! assert_eq!(parsed.filename(), "graph.json");
//! assert_eq!(rurr_core::tracking::S3AddressingStyle::parse("path")?.as_str(), "path-style");
//! # Ok::<(), Box<dyn std::error::Error>>(())
//! ```

use super::s3_time;
use std::fmt;
use thiserror::Error;
use time::OffsetDateTime;

/// Partition marker used by Burr's S3 tracking layout when no partition key exists.
pub const NONE_PARTITION: &str = "__none__";

/// Default prefix for S3 tracking data objects.
pub const DEFAULT_DATA_PREFIX: &str = "data";

/// Default prefix for S3 SQLite snapshots.
pub const DEFAULT_SNAPSHOT_PREFIX: &str = "snapshots";

/// S3 request addressing style.
///
/// Virtual-hosted addressing is the AWS default. Path-style addressing remains
/// useful for MinIO and other S3-compatible endpoints.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum S3AddressingStyle {
    /// Place the bucket in the host name.
    VirtualHosted,
    /// Place the bucket as the first path segment.
    PathStyle,
}

impl S3AddressingStyle {
    /// Parses a user-facing addressing style value.
    ///
    /// # Errors
    ///
    /// Returns [`S3LayoutError::InvalidAddressingStyle`] when the value is not
    /// one of the supported CLI/environment spellings.
    pub fn parse(value: &str) -> Result<Self, S3LayoutError> {
        match value {
            "virtual-hosted" | "virtual_hosted" | "virtual" => Ok(Self::VirtualHosted),
            "path-style" | "path_style" | "path" => Ok(Self::PathStyle),
            other => Err(S3LayoutError::InvalidAddressingStyle {
                value: other.to_string(),
            }),
        }
    }

    /// Returns the environment/CLI spelling for this style.
    pub fn as_str(self) -> &'static str {
        match self {
            Self::VirtualHosted => "virtual-hosted",
            Self::PathStyle => "path-style",
        }
    }
}

impl fmt::Display for S3AddressingStyle {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Validated S3 object prefix without leading or trailing slashes.
///
/// # Examples
///
/// ```
/// use rurr_core::tracking::S3Prefix;
///
/// let prefix = S3Prefix::new("/snapshots/")?;
/// assert_eq!(prefix.as_str(), "snapshots");
/// assert!(S3Prefix::new("bad//prefix").is_err());
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct S3Prefix(String);

impl S3Prefix {
    /// Creates a prefix from a user-supplied string.
    ///
    /// Leading and trailing slashes are normalized away. Empty prefixes and
    /// repeated separators are rejected so all generated keys have exactly one
    /// separator between layout segments.
    pub fn new(value: impl Into<String>) -> Result<Self, S3LayoutError> {
        let raw = value.into();
        let trimmed = raw.trim_matches('/').to_string();
        if trimmed.is_empty() || trimmed.contains("//") {
            return Err(S3LayoutError::InvalidPrefix { value: raw });
        }
        Ok(Self(trimmed))
    }

    /// Returns this prefix as a string slice.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for S3Prefix {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

/// Parsed S3 tracking object kind.
///
/// The kind is derived from the final filename segment only; validation of the
/// full key path lives on [`S3TrackingObjectKey::parse`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum S3TrackingObjectKind {
    /// Application graph object.
    Graph,
    /// Application metadata object.
    Metadata,
    /// JSONL tracking log object.
    Log,
    /// JSONL child-application relationship object.
    Children,
}

impl S3TrackingObjectKind {
    /// Classifies one object filename.
    ///
    /// # Errors
    ///
    /// Returns [`S3LayoutError::UnknownObjectFilename`] for files outside the
    /// Burr-compatible tracking artifact set.
    pub fn from_filename(filename: &str) -> Result<Self, S3LayoutError> {
        match filename {
            "graph.json" => Ok(Self::Graph),
            "metadata.json" => Ok(Self::Metadata),
            name if name.ends_with("__log.jsonl") => Ok(Self::Log),
            name if name.ends_with("__children.jsonl") => Ok(Self::Children),
            other => Err(S3LayoutError::UnknownObjectFilename {
                filename: other.to_string(),
            }),
        }
    }
}

/// Parsed Burr-compatible S3 tracking object key.
///
/// Parsing keeps the original key string and exposes typed accessors for the
/// semantic segments. This lets callers retain raw provider order while still
/// validating project, partition, app, timestamp, and artifact-kind fields.
///
/// # Examples
///
/// ```
/// use rurr_core::tracking::{S3Prefix, S3TrackingObjectKey, S3TrackingObjectKind};
///
/// let prefix = S3Prefix::new("data")?;
/// let parsed = S3TrackingObjectKey::parse(
///     &prefix,
///     "data/project/2026/05/07/14/03:02.000000005/customer/app/id__log.jsonl",
/// )?;
///
/// assert_eq!(parsed.kind(), S3TrackingObjectKind::Log);
/// assert_eq!(parsed.partition_key(), Some("customer"));
/// assert_eq!(parsed.app_id(), "app");
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct S3TrackingObjectKey {
    key: String,
    project_id: String,
    partition_segment: String,
    partition_key: Option<String>,
    app_id: String,
    filename: String,
    kind: S3TrackingObjectKind,
}

impl S3TrackingObjectKey {
    /// Builds a key for one tracking object.
    ///
    /// # Errors
    ///
    /// Returns an error when `filename` is not one of the supported tracking
    /// artifacts. Timestamp and partition formatting are otherwise derived from
    /// typed inputs.
    pub fn build(
        data_prefix: &S3Prefix,
        project_id: &str,
        timestamp: OffsetDateTime,
        partition_key: Option<&str>,
        app_id: &str,
        filename: &str,
    ) -> Result<String, S3LayoutError> {
        S3TrackingObjectKind::from_filename(filename)?;
        let partition_segment = partition_segment(partition_key);
        let time = TimePartition::from(timestamp);
        Ok(format!(
            "{}/{}/{}/{}/{}/{}/{}/{}/{}/{}",
            data_prefix,
            project_id,
            time.year,
            time.month,
            time.day,
            time.hour,
            time.minute,
            partition_segment,
            app_id,
            filename
        ))
    }

    /// Parses a tracking object key and validates its static layout.
    ///
    /// # Errors
    ///
    /// Returns an error when the key is outside `data_prefix`, has the wrong
    /// segment count, uses an invalid UTC time partition, or ends in an unknown
    /// tracking artifact filename.
    pub fn parse(data_prefix: &S3Prefix, key: &str) -> Result<Self, S3LayoutError> {
        let prefix = format!("{}/", data_prefix.as_str());
        let rest = key
            .strip_prefix(&prefix)
            .ok_or_else(|| S3LayoutError::KeyOutsidePrefix {
                key: key.to_string(),
                prefix: data_prefix.to_string(),
            })?;
        let parts = rest.split('/').collect::<Vec<_>>();
        if parts.len() != 9 {
            return Err(S3LayoutError::InvalidKey {
                key: key.to_string(),
                message: "expected 9 segments after the data prefix".to_string(),
            });
        }
        validate_time_partition(parts[1], parts[2], parts[3], parts[4], parts[5], key)?;
        let kind = S3TrackingObjectKind::from_filename(parts[8])?;
        Ok(Self {
            key: key.to_string(),
            project_id: parts[0].to_string(),
            partition_segment: parts[6].to_string(),
            partition_key: partition_key_from_segment(parts[6]),
            app_id: parts[7].to_string(),
            filename: parts[8].to_string(),
            kind,
        })
    }

    /// Returns the full S3 object key.
    pub fn key(&self) -> &str {
        &self.key
    }

    /// Returns the project id segment.
    pub fn project_id(&self) -> &str {
        &self.project_id
    }

    /// Returns the normalized S3 partition segment.
    pub fn partition_segment(&self) -> &str {
        &self.partition_segment
    }

    /// Returns the denormalized partition key.
    pub fn partition_key(&self) -> Option<&str> {
        self.partition_key.as_deref()
    }

    /// Returns the application id segment.
    pub fn app_id(&self) -> &str {
        &self.app_id
    }

    /// Returns the object filename.
    pub fn filename(&self) -> &str {
        &self.filename
    }

    /// Returns the parsed object kind.
    pub fn kind(&self) -> S3TrackingObjectKind {
        self.kind
    }
}

/// Errors from S3 layout parsing, formatting, and addressing values.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum S3LayoutError {
    /// A prefix was empty or contained repeated separators after trimming.
    #[error("invalid S3 prefix: {value}")]
    InvalidPrefix {
        /// Invalid prefix value.
        value: String,
    },
    /// An addressing style string was not supported.
    #[error("invalid S3 addressing style: {value}")]
    InvalidAddressingStyle {
        /// Invalid addressing style.
        value: String,
    },
    /// A key did not live under the expected data prefix.
    #[error("S3 key '{key}' is outside data prefix '{prefix}'")]
    KeyOutsidePrefix {
        /// Full S3 key.
        key: String,
        /// Expected data prefix.
        prefix: String,
    },
    /// A key did not match Burr's S3 tracking layout.
    #[error("invalid S3 tracking key '{key}': {message}")]
    InvalidKey {
        /// Full S3 key.
        key: String,
        /// Failure description.
        message: String,
    },
    /// A filename was not a known tracking artifact.
    #[error("unknown S3 tracking object filename: {filename}")]
    UnknownObjectFilename {
        /// Unknown filename.
        filename: String,
    },
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct TimePartition {
    year: String,
    month: String,
    day: String,
    hour: String,
    minute: String,
}

impl From<OffsetDateTime> for TimePartition {
    fn from(timestamp: OffsetDateTime) -> Self {
        Self {
            year: format!("{:04}", timestamp.year()),
            month: format!("{:02}", u8::from(timestamp.month())),
            day: format!("{:02}", timestamp.day()),
            hour: format!("{:02}", timestamp.hour()),
            minute: format!(
                "{:02}:{:02}.{:09}",
                timestamp.minute(),
                timestamp.second(),
                timestamp.nanosecond()
            ),
        }
    }
}

/// Converts an optional partition key to Burr's S3 partition segment.
///
/// Empty strings are treated the same as an absent partition and use Burr's
/// `__none__` segment.
///
/// # Examples
///
/// ```
/// use rurr_core::tracking::partition_segment;
///
/// assert_eq!(partition_segment(None), "__none__");
/// assert_eq!(partition_segment(Some("")), "__none__");
/// assert_eq!(partition_segment(Some("customer-a")), "customer-a");
/// ```
pub fn partition_segment(partition_key: Option<&str>) -> String {
    partition_key
        .filter(|value| !value.is_empty())
        .unwrap_or(NONE_PARTITION)
        .to_string()
}

/// Converts Burr's S3 partition segment back to an optional partition key.
///
/// # Examples
///
/// ```
/// use rurr_core::tracking::partition_key_from_segment;
///
/// assert_eq!(partition_key_from_segment("__none__"), None);
/// assert_eq!(partition_key_from_segment("customer-a").as_deref(), Some("customer-a"));
/// ```
pub fn partition_key_from_segment(partition_segment: &str) -> Option<String> {
    if partition_segment == NONE_PARTITION {
        None
    } else {
        Some(partition_segment.to_string())
    }
}

fn validate_time_partition(
    year_segment: &str,
    month_segment: &str,
    day_segment: &str,
    hour_segment: &str,
    minute_segment: &str,
    key: &str,
) -> Result<(), S3LayoutError> {
    s3_time::parse_tracking_utc_partition(
        year_segment,
        month_segment,
        day_segment,
        hour_segment,
        minute_segment,
    )
    .map(|_| ())
    .map_err(|error| S3LayoutError::InvalidKey {
        key: key.to_string(),
        message: error.to_string(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    use time::Month;

    #[test]
    fn builds_and_parses_burr_s3_tracking_key() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        let timestamp = OffsetDateTime::new_utc(
            time::Date::from_calendar_date(2026, Month::May, 7).unwrap(),
            time::Time::from_hms_nano(14, 3, 2, 5).unwrap(),
        );

        let key = S3TrackingObjectKey::build(
            &prefix,
            "project",
            timestamp,
            Some("pk"),
            "app",
            "graph.json",
        )
        .expect("key should build");

        assert_eq!(
            key,
            "data/project/2026/05/07/14/03:02.000000005/pk/app/graph.json"
        );
        let parsed = S3TrackingObjectKey::parse(&prefix, &key).expect("key should parse");
        assert_eq!(parsed.project_id(), "project");
        assert_eq!(parsed.partition_key(), Some("pk"));
        assert_eq!(parsed.partition_segment(), "pk");
        assert_eq!(parsed.app_id(), "app");
        assert_eq!(parsed.kind(), S3TrackingObjectKind::Graph);
    }

    #[test]
    fn parses_none_partition_log_key() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        let parsed = S3TrackingObjectKey::parse(
            &prefix,
            "data/project/2026/05/07/14/03:02.000000005/__none__/app/id__log.jsonl",
        )
        .expect("key should parse");

        assert_eq!(parsed.partition_key(), None);
        assert_eq!(parsed.kind(), S3TrackingObjectKind::Log);
    }

    #[test]
    fn parses_child_relationship_object_key() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        let parsed = S3TrackingObjectKey::parse(
            &prefix,
            "data/project/2026/05/07/14/03:02.000000005/pk/parent/00000000000000000000_id__children.jsonl",
        )
        .expect("key should parse");

        assert_eq!(parsed.partition_key(), Some("pk"));
        assert_eq!(parsed.app_id(), "parent");
        assert_eq!(parsed.kind(), S3TrackingObjectKind::Children);
    }

    #[test]
    fn parses_burr_iso_time_suffixes() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        for time_segment in ["03:02", "03:02.123456", "03:02.123456789"] {
            let key = format!("data/project/2026/05/07/14/{time_segment}/__none__/app/graph.json");
            let parsed = S3TrackingObjectKey::parse(&prefix, &key).expect("key should parse");
            assert_eq!(parsed.app_id(), "app");
            assert_eq!(parsed.kind(), S3TrackingObjectKind::Graph);
        }
    }

    #[test]
    fn shared_s3_time_primitives_parse_tracking_suffix_and_utc_snapshot_timestamp() {
        let (minute, second, nanos) =
            crate::tracking::s3_time::parse_burr_time_suffix("03:02.123456")
                .expect("Burr suffix should parse");
        assert_eq!((minute, second, nanos), (3, 2, 123_456_000));

        let timestamp =
            crate::tracking::s3_time::parse_utc_iso_timestamp("2026-05-07T14:03:02.123456789Z")
                .expect("UTC snapshot timestamp should parse");
        assert_eq!(timestamp.year(), 2026);
        assert_eq!(timestamp.nanosecond(), 123_456_789);
    }

    #[test]
    fn rejects_invalid_burr_iso_time_suffixes() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        for time_segment in [
            "3:02",
            "03:2",
            "60:02",
            "03:60",
            "03:02.",
            "03:02.1234567890",
        ] {
            let key = format!("data/project/2026/05/07/14/{time_segment}/__none__/app/graph.json");
            let error = S3TrackingObjectKey::parse(&prefix, &key)
                .expect_err("invalid time suffix should fail");
            assert!(matches!(error, S3LayoutError::InvalidKey { .. }));
        }
    }

    #[test]
    fn rejects_impossible_utc_date_time_partitions() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        for partition in [
            "2026/00/07/14/03:02",
            "2026/13/07/14/03:02",
            "2026/05/00/14/03:02",
            "2023/02/29/14/03:02",
            "2026/05/07/24/03:02",
            "2026/05/07/14/60:02",
            "2026/05/07/14/03:60",
            "2026/05/07/14/03:02.1234567890",
        ] {
            let key = format!("data/project/{partition}/__none__/app/graph.json");
            let error = S3TrackingObjectKey::parse(&prefix, &key)
                .expect_err("impossible UTC partition should fail");
            assert!(
                matches!(error, S3LayoutError::InvalidKey { .. }),
                "unexpected error for {partition}: {error}"
            );
        }
    }

    #[test]
    fn rejects_malformed_tracking_key() {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        let error = S3TrackingObjectKey::parse(&prefix, "data/project/bad/key")
            .expect_err("bad key should fail");

        assert!(matches!(error, S3LayoutError::InvalidKey { .. }));
    }

    #[test]
    fn parses_addressing_style_values() {
        assert_eq!(
            S3AddressingStyle::parse("path-style").expect("path style should parse"),
            S3AddressingStyle::PathStyle
        );
        assert_eq!(
            S3AddressingStyle::parse("virtual-hosted").expect("virtual style should parse"),
            S3AddressingStyle::VirtualHosted
        );
    }
}
