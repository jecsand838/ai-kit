use mongodb::bson::{Bson, Document};
use rurr_persistence::{
    layout::{
        FIELD_APP_ID, FIELD_CREATED_AT, FIELD_PARTITION_KEY, FIELD_POSITION, FIELD_SEQUENCE_ID,
        FIELD_STATE, FIELD_STATUS,
    },
    persisted_state_from_record_parts, wire as persistence_wire, PersistedRecordParts,
    PersistenceError,
};
use serde::Deserialize;
use std::time::SystemTime;

use super::error::{classify_mongo_server_error, duplicate_save_error};
use crate::{
    OP_DOCUMENT_DESERIALIZATION_FAILED, OP_MONGODB_COMMAND_FAILED, OP_SEQUENCE_ID_OUT_OF_RANGE,
    OP_STATE_DESERIALIZATION_FAILED, OP_STATUS_DESERIALIZATION_FAILED,
};

#[derive(Debug, Deserialize)]
struct ReplyWriteError {
    code: i32,
    #[serde(rename = "codeName", default)]
    code_name: Option<String>,
    #[serde(rename = "errmsg", default)]
    message: String,
}

fn sequence_id_i64_to_u64(sequence_id: i64) -> Result<u64, PersistenceError> {
    u64::try_from(sequence_id).map_err(|_| PersistenceError::UnsupportedOperation {
        operation: OP_SEQUENCE_ID_OUT_OF_RANGE,
    })
}

pub(crate) fn now_sortable_rfc3339_utc_string() -> Result<String, PersistenceError> {
    persistence_wire::sortable_rfc3339_utc_string(SystemTime::now())
}

pub(crate) fn parse_save_reply(reply: Document) -> Result<(), PersistenceError> {
    if let Some(write_error) = first_reply_write_error(&reply)? {
        return Err(classify_mongo_server_error(
            Some(write_error.code),
            write_error.code_name.as_deref(),
            Some(write_error.message.as_str()),
        )
        .unwrap_or(PersistenceError::UnsupportedOperation {
            operation: OP_MONGODB_COMMAND_FAILED,
        }));
    }

    if reply
        .get_array("upserted")
        .map(|upserted| !upserted.is_empty())
        .unwrap_or(false)
    {
        return Ok(());
    }

    if reply_count(&reply, "n").unwrap_or_default() > 0 {
        return Err(duplicate_save_error());
    }

    Err(PersistenceError::UnsupportedOperation {
        operation: OP_MONGODB_COMMAND_FAILED,
    })
}

pub(crate) fn document_to_persisted_state(
    document: Document,
) -> Result<rurr_persistence::PersistedStateData, PersistenceError> {
    let partition_key = document_string(&document, FIELD_PARTITION_KEY)?;
    let app_id = document_string(&document, FIELD_APP_ID)?;
    let sequence_id = sequence_id_i64_to_u64(document_i64(&document, FIELD_SEQUENCE_ID)?)?;
    let position = document_string(&document, FIELD_POSITION)?;
    let state_json = document_string(&document, FIELD_STATE)?;
    let created_at = document_string(&document, FIELD_CREATED_AT)?;
    let status = document_string(&document, FIELD_STATUS)?;

    persisted_state_from_record_parts(
        PersistedRecordParts {
            partition_key,
            app_id,
            sequence_id,
            position: Some(position),
            state_json: Some(state_json.as_str()),
            created_at: Some(created_at),
            status: status.as_str(),
        },
        OP_STATE_DESERIALIZATION_FAILED,
        OP_STATUS_DESERIALIZATION_FAILED,
    )
}

fn document_string(document: &Document, field: &'static str) -> Result<String, PersistenceError> {
    match document.get(field) {
        Some(Bson::String(value)) => Ok(value.clone()),
        _ => Err(PersistenceError::UnsupportedOperation {
            operation: OP_DOCUMENT_DESERIALIZATION_FAILED,
        }),
    }
}

fn document_i64(document: &Document, field: &'static str) -> Result<i64, PersistenceError> {
    match document.get(field) {
        Some(Bson::Int32(value)) => Ok(i64::from(*value)),
        Some(Bson::Int64(value)) => Ok(*value),
        _ => Err(PersistenceError::UnsupportedOperation {
            operation: OP_DOCUMENT_DESERIALIZATION_FAILED,
        }),
    }
}

fn reply_count(document: &Document, field: &'static str) -> Result<i64, PersistenceError> {
    match document.get(field) {
        Some(Bson::Int32(value)) => Ok(i64::from(*value)),
        Some(Bson::Int64(value)) => Ok(*value),
        Some(Bson::Double(value)) => Ok(*value as i64),
        None => Ok(0),
        _ => Err(PersistenceError::UnsupportedOperation {
            operation: OP_MONGODB_COMMAND_FAILED,
        }),
    }
}

fn first_reply_write_error(reply: &Document) -> Result<Option<ReplyWriteError>, PersistenceError> {
    let Some(first_error) = reply
        .get_array("writeErrors")
        .ok()
        .and_then(|errors| errors.first())
    else {
        return Ok(None);
    };
    let Some(first_error) = first_error.as_document() else {
        return Err(PersistenceError::UnsupportedOperation {
            operation: OP_MONGODB_COMMAND_FAILED,
        });
    };

    mongodb::bson::from_document::<ReplyWriteError>(first_error.clone())
        .map(Some)
        .map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_MONGODB_COMMAND_FAILED,
        })
}
