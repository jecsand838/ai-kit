use indexmap::IndexMap;
use rurr_core::action::{Action, ActionContext, ActionError, ActionResult};
use rurr_core::state::State;
use serde_json::json;
use std::cell::Cell;
use std::rc::Rc;

#[derive(Clone)]
struct NonSendRunAsyncAction;

impl Action for NonSendRunAsyncAction {
    fn name(&self) -> Option<&str> {
        Some("non_send")
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn with_name(&self, _name: impl Into<String>) -> Result<Self, ActionError> {
        Ok(self.clone())
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
    }

    async fn run_async(
        &self,
        _state: &State,
        _ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        let local = Rc::new(Cell::new(1));
        tokio::task::yield_now().await;
        local.set(local.get() + 1);
        Ok(ActionResult::new(
            IndexMap::from([("value".to_string(), json!(local.get()))]),
            IndexMap::new(),
        ))
    }
}

fn main() {}
