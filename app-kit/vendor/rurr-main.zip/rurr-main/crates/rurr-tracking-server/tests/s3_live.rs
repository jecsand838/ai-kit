use aws_sdk_s3::primitives::ByteStream;
use http::Request;
use http_body_util::BodyExt;
use indexmap::IndexMap;
use rurr_core::graph::{Graph, GraphAction, Transition};
use rurr_core::tracking::{ApplicationMetadataModel, ApplicationModel, S3TrackingConfig};
use rurr_core::{ApplicationBuilder, Condition, FunctionActionBuilder, LocalAction, TrackerSpec};
use rurr_testkit::env::EnvVarGuard;
use rurr_testkit::live_services::S3LiveBucketScenario;
use rurr_testkit::S3LiveHarness;
use rurr_tracking_server::backend::s3::{S3Backend, S3BackendConfig};
use rurr_tracking_server::backend::{BackendError, TrackingBackend};
use rurr_tracking_server::router::AppState;
use serde::de::DeserializeOwned;
use sqlx::Row;
use tempfile::TempDir;
use tower::ServiceExt;

fn live_enabled() -> bool {
    rurr_testkit::check_live_tests_enabled()
}

fn graph() -> Graph {
    Graph::new(vec![named_action("noop")], Vec::new(), "noop").expect("graph should build")
}

fn named_action(name: &str) -> GraphAction {
    let action = FunctionActionBuilder::new()
        .with_source_code(format!(
            "fn {name}(_state, _ctx) -> IndexMap<String, Value> {{ IndexMap::new() }}"
        ))
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("action should build")
        .with_name(name)
        .expect("action should be named");
    GraphAction::new(action).expect("graph action should build")
}

fn multi_step_graph() -> Graph {
    Graph::new(
        vec![
            named_action("first"),
            named_action("second"),
            named_action("third"),
        ],
        vec![
            Transition::new("first", "second", Condition::default()),
            Transition::new("second", "third", Condition::default()),
        ],
        "first",
    )
    .expect("graph should build")
}

struct S3BackendLiveScenario {
    bucket: S3LiveBucketScenario,
    db_dir: TempDir,
}

struct BackendScenarioConfig {
    credentials: bool,
    prior_snapshots_to_keep: usize,
    list_page_size: Option<i32>,
    aws_max_concurrency: Option<usize>,
}

const DEFAULT_BACKEND_SCENARIO: BackendScenarioConfig = BackendScenarioConfig {
    credentials: true,
    prior_snapshots_to_keep: 1,
    list_page_size: None,
    aws_max_concurrency: None,
};

struct RawTrackedAppArtifacts<'a> {
    project: &'a str,
    app_id: &'a str,
    partition_key: Option<&'a str>,
    tracker_id: &'a str,
    graph: fn() -> Graph,
    metadata: ApplicationMetadataModel,
    timestamp: &'a str,
    logs: Vec<RawLogArtifact<'a>>,
}

struct RawLogArtifact<'a> {
    key_suffix: &'a str,
    body: Vec<serde_json::Value>,
    metadata: &'a [(&'a str, &'a str)],
}

struct MalformedArtifactCase<'a> {
    bucket_prefix: &'a str,
    key: &'a str,
    body: &'static [u8],
    metadata: &'a [(&'a str, &'a str)],
    expected_error_fragment: &'a str,
}

impl RawTrackedAppArtifacts<'_> {
    fn base_key(&self) -> String {
        format!(
            "data/{}/{}/{}/{}",
            self.project,
            self.timestamp,
            self.partition_key.unwrap_or("__none__"),
            self.app_id
        )
    }
}

fn json_lines_bytes(values: Vec<serde_json::Value>) -> Vec<u8> {
    values
        .into_iter()
        .map(|value| serde_json::to_string(&value).expect("JSON line should serialize"))
        .collect::<Vec<_>>()
        .join("\n")
        .into_bytes()
}

impl S3BackendLiveScenario {
    async fn new(bucket_prefix: &str) -> Self {
        let bucket = S3LiveBucketScenario::new("rurr-tracking-server-s3-live-test", bucket_prefix)
            .await
            .expect("S3 live scenario should build");
        let db_dir = tempfile::tempdir().expect("temp dir should be available");
        Self { bucket, db_dir }
    }

    fn config(&self, scenario: BackendScenarioConfig) -> S3BackendConfig {
        let mut config = S3BackendConfig::new(
            self.bucket.bucket(),
            "us-east-1",
            self.db_dir.path().join("index.sqlite3"),
        )
        .expect("backend config should build");
        config.transport = config
            .transport
            .clone()
            .with_endpoint_url(self.bucket.harness().endpoint().to_string())
            .expect("endpoint should parse")
            .with_addressing_style(rurr_core::tracking::S3AddressingStyle::PathStyle);
        if scenario.credentials {
            config.transport = config
                .transport
                .clone()
                .with_credentials("minioadmin", "minioadmin", None)
                .expect("credentials should parse");
        }
        config.indexing.prior_snapshots_to_keep = scenario.prior_snapshots_to_keep;
        config.indexing.list_page_size = scenario.list_page_size;
        if let Some(max_concurrency) = scenario.aws_max_concurrency {
            config.indexing.aws_max_concurrency = max_concurrency;
        }
        config
    }

    async fn backend(&self, scenario: BackendScenarioConfig) -> S3Backend {
        S3Backend::new(self.config(scenario))
            .await
            .expect("backend should build")
    }

    fn tracker_config(&self, project: &str, tracker_id: &str) -> S3TrackingConfig {
        self.bucket
            .tracking_config(project, tracker_id)
            .expect("tracker config should build")
    }

    async fn write_tracked_app(
        &self,
        project: &str,
        app_id: &str,
        tracker_id: &str,
        graph: fn() -> Graph,
    ) {
        let mut app = ApplicationBuilder::new()
            .with_graph(graph())
            .expect("graph should attach")
            .with_identifiers(app_id, Some("pk".to_string()), None)
            .expect("identifiers should attach")
            .with_tracker(TrackerSpec::s3(self.tracker_config(project, tracker_id)))
            .expect("tracker should attach")
            .build()
            .expect("tracked app should build");
        app.run().expect("tracked app should run");
    }

    async fn write_burr_style_app(&self) {
        self.put_tracked_artifacts(RawTrackedAppArtifacts {
            project: "project-a",
            app_id: "app-burr",
            partition_key: Some("pk"),
            tracker_id: "tracker-burr",
            graph,
            metadata: ApplicationMetadataModel::new(Some("pk".to_string()), None, None),
            timestamp: "2026/05/07/14/00:01.123456",
            logs: Vec::new(),
        })
        .await;
    }

    async fn put_tracked_artifacts(&self, spec: RawTrackedAppArtifacts<'_>) {
        let base = spec.base_key();
        let graph_key = format!("{base}/graph.json");
        let metadata_key = format!("{base}/metadata.json");
        let graph_model =
            ApplicationModel::from_graph(&(spec.graph)()).expect("graph should serialize");
        self.put_object(
            &graph_key,
            ByteStream::from(
                serde_json::to_vec(&graph_model).expect("graph JSON should serialize"),
            ),
            &[("tracker_id", spec.tracker_id)],
        )
        .await;
        self.put_object(
            &metadata_key,
            ByteStream::from(
                serde_json::to_vec(&spec.metadata).expect("metadata JSON should serialize"),
            ),
            &[
                ("tracker_id", spec.tracker_id),
                ("parent_pointer", "None"),
                ("spawning_parent_pointer", "None"),
            ],
        )
        .await;
        for log in spec.logs {
            let log_key = format!("{base}/{}", log.key_suffix);
            self.put_object(
                &log_key,
                ByteStream::from(json_lines_bytes(log.body)),
                log.metadata,
            )
            .await;
        }
    }

    async fn put_object(&self, key: &str, body: ByteStream, metadata: &[(&str, &str)]) {
        self.bucket
            .put_object(key, body, metadata)
            .await
            .expect("object should upload");
    }

    async fn provider_keys(&self, prefix: impl Into<String>) -> Vec<String> {
        self.bucket
            .artifact_probe(prefix)
            .objects()
            .await
            .expect("provider keys should list")
    }

    async fn provider_head(&self, key: &str) -> std::collections::HashMap<String, String> {
        self.bucket
            .artifact_probe("")
            .head_required(key)
            .await
            .expect("object head should succeed")
    }

    async fn snapshot_db_bytes_for_tracked_app(&self, project: &str, app_id: &str) -> Vec<u8> {
        self.write_tracked_app(project, app_id, "tracker-server-live", graph)
            .await;
        let backend = self.backend(DEFAULT_BACKEND_SCENARIO).await;
        backend
            .update_index()
            .await
            .expect("snapshot source should index");
        tokio::fs::read(self.db_dir.path().join("index.sqlite3"))
            .await
            .expect("snapshot source DB should read")
    }

    async fn route_json<T: DeserializeOwned>(
        &self,
        backend: S3Backend,
        uri: &str,
        expected_status: http::StatusCode,
    ) -> T {
        let app = rurr_tracking_server::app_with_state(AppState::with_embedded_ui(
            std::sync::Arc::new(backend),
        ));
        let response = app
            .oneshot(
                Request::builder()
                    .uri(uri)
                    .body(axum::body::Body::empty())
                    .expect("request should build"),
            )
            .await
            .expect("route should respond");
        assert_eq!(response.status(), expected_status);
        let bytes = response
            .into_body()
            .collect()
            .await
            .expect("body should collect")
            .to_bytes();
        serde_json::from_slice(&bytes).expect("route body should be JSON")
    }

    async fn assert_malformed_index_case(case: MalformedArtifactCase<'_>) {
        let scenario = Self::new(case.bucket_prefix).await;
        scenario
            .put_object(case.key, ByteStream::from_static(case.body), case.metadata)
            .await;
        let backend = scenario.backend(DEFAULT_BACKEND_SCENARIO).await;
        let error = backend
            .update_index()
            .await
            .expect_err("index update should fail");
        assert!(
            error.to_string().contains(case.expected_error_fragment),
            "expected '{}' in error, got {error}",
            case.expected_error_fragment
        );
        let jobs = backend
            .indexing_jobs(0, 10, false)
            .await
            .expect("indexing jobs should list");
        assert_eq!(jobs[0].status, "FAILURE");
    }
}

#[tokio::test]
async fn s3_live_raw_helpers_preserve_provider_order_and_metadata_presence() {
    if !live_enabled() {
        return;
    }

    let scenario = S3BackendLiveScenario::new("rurr-server-s3-raw-provider").await;

    let plain_key = "data/raw-provider/a-without-metadata.txt";
    let metadata_key = "data/raw-provider/b-with-metadata.txt";
    let final_key = "data/raw-provider/c-final.txt";
    let truncated_jsonl_key = "data/raw-provider/d-truncated.jsonl";
    for key in [metadata_key, plain_key, final_key, truncated_jsonl_key] {
        let metadata = if key == metadata_key {
            &[("purpose", "strict-live-proof")][..]
        } else {
            &[]
        };
        let body: &[u8] = if key == truncated_jsonl_key {
            br#"{"id":"#
        } else {
            b"body"
        };
        scenario
            .put_object(key, ByteStream::from_static(body), metadata)
            .await;
    }

    let listed = scenario.provider_keys("data/raw-provider/").await;
    assert_eq!(
        listed,
        vec![
            plain_key.to_string(),
            metadata_key.to_string(),
            final_key.to_string(),
            truncated_jsonl_key.to_string(),
        ]
    );
    let valid_no_newline = S3LiveHarness::parse_jsonl(br#"{"id":0}"#)
        .expect("strict S3 JSONL helper should accept valid final JSON without newline");
    assert_eq!(valid_no_newline, vec![serde_json::json!({"id": 0})]);
    let truncated_body = scenario
        .bucket
        .harness()
        .get_object_bytes_raw(scenario.bucket.bucket(), truncated_jsonl_key)
        .await
        .expect("truncated object body should read");
    let error = S3LiveHarness::parse_jsonl(&truncated_body)
        .expect_err("strict S3 JSONL helper must reject truncated provider bodies");
    assert!(
        error.to_string().contains("EOF while parsing"),
        "truncated JSONL error should preserve serde failure: {error}"
    );

    let plain_metadata = scenario
        .bucket
        .harness()
        .head_metadata_raw(scenario.bucket.bucket(), plain_key)
        .await
        .expect("plain object head should succeed");
    assert!(
        plain_metadata
            .as_ref()
            .is_some_and(|metadata| metadata.is_empty()),
        "MinIO should expose absent user metadata as an empty metadata map, got {plain_metadata:?}"
    );

    let metadata = scenario
        .bucket
        .harness()
        .head_metadata_raw(scenario.bucket.bucket(), metadata_key)
        .await
        .expect("metadata object head should succeed")
        .expect("metadata object should include user metadata");
    assert_eq!(
        metadata.get("purpose").map(String::as_str),
        Some("strict-live-proof")
    );
}

#[tokio::test]
async fn s3_backend_accepts_complete_log_without_trailing_newline() {
    if !live_enabled() {
        return;
    }

    let scenario = S3BackendLiveScenario::new("rurr-server-s3-no-newline").await;
    scenario
        .put_tracked_artifacts(RawTrackedAppArtifacts {
            project: "project-no-newline",
            app_id: "app-no-newline",
            partition_key: None,
            tracker_id: "tracker-no-newline",
            graph,
            metadata: ApplicationMetadataModel::new(None, None, None),
            timestamp: "2026/05/07/14/00:01.123456",
            logs: vec![RawLogArtifact {
                key_suffix: "00000000000000000000_no_newline__log.jsonl",
                body: vec![
                    serde_json::json!({
                        "type": "begin_entry",
                        "start_time": "2026-04-11T20:51:59.096028Z",
                        "action": "noop",
                        "inputs": {},
                        "sequence_id": 0
                    }),
                    serde_json::json!({
                        "type": "end_entry",
                        "end_time": "2026-04-11T20:51:59.096382Z",
                        "action": "noop",
                        "result": {},
                        "exception": null,
                        "state": {},
                        "sequence_id": 0
                    }),
                ],
                metadata: &[
                    ("tracker_id", "tracker-no-newline"),
                    ("min_sequence_id", "0"),
                    ("max_sequence_id", "0"),
                ],
            }],
        })
        .await;

    let backend = scenario.backend(DEFAULT_BACKEND_SCENARIO).await;
    backend
        .update_index()
        .await
        .expect("complete no-newline S3 log should index");
    let detail = backend
        .read_app("project-no-newline", "app-no-newline", None)
        .await
        .expect("app detail should read");
    assert_eq!(detail.steps.len(), 1);
    let route_payload: serde_json::Value = scenario
        .route_json(
            backend,
            "/api/v0/project-no-newline/app-no-newline/__none__/apps",
            http::StatusCode::OK,
        )
        .await;
    assert_eq!(
        route_payload["steps"]
            .as_array()
            .expect("route steps should be an array")
            .len(),
        1
    );
}

#[tokio::test]
async fn s3_backend_indexes_and_reads_provider_backed_child_events() {
    if !live_enabled() {
        return;
    }

    let scenario = S3BackendLiveScenario::new("rurr-server-s3-children").await;
    scenario
        .put_tracked_artifacts(RawTrackedAppArtifacts {
            project: "project-children",
            app_id: "parent-app",
            partition_key: Some("pk"),
            tracker_id: "tracker-parent",
            graph,
            metadata: ApplicationMetadataModel::new(Some("pk".to_string()), None, None),
            timestamp: "2026/05/07/14/00:01.123456",
            logs: Vec::new(),
        })
        .await;

    let child_key = "data/project-children/2026/05/07/14/00:02.123456/pk/parent-app/00000000000000000000_child__children.jsonl";
    let child_body = serde_json::json!({
        "type": "child_application_data",
        "child": {
            "type": "pointer_data",
            "app_id": "child-app",
            "sequence_id": null,
            "partition_key": "child-pk",
        },
        "event_time": "2026-05-07T14:00:02.123456000Z",
        "event_type": "spawn_start",
        "sequence_id": 3,
    });
    scenario
        .put_object(
            child_key,
            ByteStream::from(format!("{child_body}\n").into_bytes()),
            &[("tracker_id", "tracker-parent")],
        )
        .await;
    let orphan_child_key = "data/project-children/2026/05/07/14/00:03.123456/pk/orphan-parent/00000000000000000001_orphan__children.jsonl";
    scenario
        .put_object(
            orphan_child_key,
            ByteStream::from(format!("{child_body}\n").into_bytes()),
            &[("tracker_id", "tracker-orphan")],
        )
        .await;

    let raw_keys = scenario.provider_keys("data/project-children/").await;
    assert!(
        raw_keys.iter().any(|key| key == child_key),
        "child object must exist in raw provider listing: {raw_keys:?}"
    );
    assert!(
        raw_keys.iter().any(|key| key == orphan_child_key),
        "orphan child object must exist in raw provider listing: {raw_keys:?}"
    );
    assert_eq!(
        scenario
            .provider_head(child_key)
            .await
            .get("tracker_id")
            .map(String::as_str),
        Some("tracker-parent")
    );
    assert_eq!(
        scenario
            .provider_head(orphan_child_key)
            .await
            .get("tracker_id")
            .map(String::as_str),
        Some("tracker-orphan")
    );

    let backend = scenario.backend(DEFAULT_BACKEND_SCENARIO).await;
    backend
        .update_index()
        .await
        .expect("S3 index should update");
    let page = backend
        .list_apps("project-children", Some("pk"), 100, 0)
        .await
        .expect("apps should list");
    assert_eq!(
        page.total, 1,
        "child-only provider objects must not create app rows"
    );

    let detail = backend
        .read_app("project-children", "parent-app", Some("pk"))
        .await
        .expect("app detail should read");
    assert_eq!(detail.children.len(), 1);
    assert_eq!(detail.children[0].child.app_id, "child-app");
    assert_eq!(detail.children[0].event_type, "spawn_start");
    assert_eq!(detail.children[0].sequence_id, Some(3));
    assert_eq!(
        detail.children[0].child.partition_key.as_deref(),
        Some("child-pk")
    );
}

#[tokio::test]
async fn s3_backend_indexes_snapshots_and_restores_from_minio() {
    if !live_enabled() {
        return;
    }

    let scenario = S3BackendLiveScenario::new("rurr-server-s3").await;
    scenario
        .write_tracked_app(
            "project-a",
            "app-a",
            "tracker-server-live",
            multi_step_graph,
        )
        .await;
    scenario.write_burr_style_app().await;
    let listed_objects = scenario
        .bucket
        .harness()
        .client()
        .list_objects_v2()
        .bucket(scenario.bucket.bucket())
        .prefix("data/project-a/")
        .send()
        .await
        .expect("provider objects should list");
    let provider_last_modified = listed_objects
        .contents()
        .iter()
        .map(|object| {
            object
                .last_modified()
                .expect("MinIO must provide LastModified for indexed objects")
                .to_string()
        })
        .collect::<Vec<_>>();
    assert!(
        !provider_last_modified.is_empty(),
        "strict live proof should index real provider objects"
    );

    let backend = scenario
        .backend(BackendScenarioConfig {
            list_page_size: Some(2),
            aws_max_concurrency: Some(2),
            ..DEFAULT_BACKEND_SCENARIO
        })
        .await;
    let spec = backend.app_spec().await.expect("app spec should build");
    assert_eq!(spec.backend, "s3");
    assert!(spec.indexing);
    assert!(spec.snapshotting);
    assert!(!spec.supports_annotations);

    backend
        .update_index()
        .await
        .expect("index update should succeed");
    let projects = backend.list_projects().await.expect("projects should list");
    assert_eq!(projects.len(), 1);
    assert_eq!(projects[0].name, "project-a");
    assert_eq!(projects[0].id, "project-a");
    assert_eq!(projects[0].num_apps, 2);
    assert_eq!(projects[0].uri, None);
    assert!(provider_last_modified.contains(&projects[0].created));
    assert!(provider_last_modified.contains(&projects[0].last_written));
    let first_jobs = backend
        .indexing_jobs(0, 1, false)
        .await
        .expect("jobs should list");
    assert!(
        first_jobs[0].records_processed > 2,
        "page size 2 should require continuation-token pagination, got {}",
        first_jobs[0].records_processed
    );
    let db_url = format!("sqlite://{}", backend.db_path().display());
    let pool = sqlx::SqlitePool::connect(&db_url)
        .await
        .expect("S3 index should open for timestamp proof");
    let timestamp_row =
        sqlx::query("SELECT created_at, last_written FROM projects WHERE project_id = 'project-a'")
            .fetch_one(&pool)
            .await
            .expect("project timestamps should be stored");
    assert_eq!(
        timestamp_row
            .try_get::<String, _>("created_at")
            .expect("created_at should read"),
        projects[0].created
    );
    assert_eq!(
        timestamp_row
            .try_get::<String, _>("last_written")
            .expect("last_written should read"),
        projects[0].last_written
    );

    let page = backend
        .list_apps("project-a", Some("pk"), 100, 0)
        .await
        .expect("apps should list");
    assert_eq!(page.total, 2);
    assert!(!page.has_another_page);
    let app_a = page
        .applications
        .iter()
        .find(|item| item.app_id == "app-a")
        .expect("normal tracked app should index");
    assert_eq!(app_a.num_steps, 3);
    assert!(provider_last_modified.contains(&app_a.first_written));
    assert!(provider_last_modified.contains(&app_a.last_written));
    assert!(page
        .applications
        .iter()
        .any(|item| item.app_id == "app-burr" && item.num_steps == 0));
    let detail = backend
        .read_app("project-a", "app-a", Some("pk"))
        .await
        .expect("app detail should read");
    let step_order = detail
        .steps
        .iter()
        .map(|step| {
            (
                step.step_start_log.sequence_id,
                step.step_start_log.action.clone(),
                step.step_end_log
                    .as_ref()
                    .expect("step should include an end log")
                    .action
                    .clone(),
            )
        })
        .collect::<Vec<_>>();
    assert_eq!(
        step_order,
        vec![
            (0, "first".to_string(), "first".to_string()),
            (1, "second".to_string(), "second".to_string()),
            (2, "third".to_string(), "third".to_string()),
        ]
    );
    let projects_route_payload: serde_json::Value = scenario
        .route_json(backend.clone(), "/api/v0/projects", http::StatusCode::OK)
        .await;
    assert_eq!(projects_route_payload[0]["uri"], serde_json::Value::Null);
    assert_ne!(projects_route_payload[0]["uri"], "TODO");
    let annotations_payload: serde_json::Value = scenario
        .route_json(
            backend.clone(),
            "/api/v0/project-a/annotations?app_id=app-a&partition_key=pk&step_sequence_id=0",
            http::StatusCode::NOT_FOUND,
        )
        .await;
    assert!(
        annotations_payload["error"]
            .as_str()
            .is_some_and(|message| message.contains("annotations")),
        "unsupported annotations error should name the feature: {annotations_payload}"
    );

    let route_payload: serde_json::Value = scenario
        .route_json(
            backend.clone(),
            "/api/v0/project-a/app-a/pk/apps",
            http::StatusCode::OK,
        )
        .await;
    assert!(route_payload.get("log").is_none());
    assert_eq!(
        route_payload["steps"]
            .as_array()
            .expect("steps should be an array")
            .len(),
        3
    );

    let jobs = backend
        .indexing_jobs(0, 10, true)
        .await
        .expect("indexing jobs should list");
    assert_eq!(jobs[0].status, "SUCCESS");
    assert!(jobs[0].records_processed >= 3);
    let jobs_route: serde_json::Value = scenario
        .route_json(
            backend.clone(),
            "/api/v0/indexing_jobs?filter_empty=false",
            http::StatusCode::OK,
        )
        .await;
    assert_eq!(jobs_route[0]["status"], "SUCCESS");

    scenario
        .write_tracked_app("project-a", "app-c", "tracker-c", graph)
        .await;
    let app_c_key_count = scenario
        .provider_keys("data/project-a/")
        .await
        .iter()
        .filter(|key| key.contains("/app-c/"))
        .count() as u64;
    backend
        .update_index()
        .await
        .expect("second index should succeed");
    let second_jobs = backend
        .indexing_jobs(0, 1, false)
        .await
        .expect("jobs should list");
    assert_eq!(
        second_jobs[0].records_processed, app_c_key_count,
        "high watermark should process only the app-c keys added after the first index"
    );

    backend.snapshot().await.expect("snapshot should upload");
    let first_snapshot = scenario
        .provider_keys("snapshots/")
        .await
        .iter()
        .find(|key| key.ends_with("/snapshot.db"))
        .expect("snapshot should upload")
        .clone();

    let restore_dir = tempfile::tempdir().expect("restore temp dir should exist");
    let mut restore_config = scenario.config(DEFAULT_BACKEND_SCENARIO);
    restore_config.indexing.db_path = restore_dir.path().join("index.sqlite3");
    let restored = S3Backend::new(restore_config)
        .await
        .expect("restored backend should build");
    let restored_projects = restored
        .list_projects()
        .await
        .expect("restored projects should list");
    assert_eq!(restored_projects.len(), 1);
    assert_eq!(restored_projects[0].name, "project-a");

    backend
        .snapshot()
        .await
        .expect("second snapshot should upload");
    let retained_snapshots = scenario.provider_keys("snapshots/").await;
    let retained_snapshot_keys = retained_snapshots
        .iter()
        .filter(|key| key.ends_with("/snapshot.db"))
        .collect::<Vec<_>>();
    assert_eq!(retained_snapshot_keys.len(), 1);
    assert_ne!(
        retained_snapshot_keys[0].as_str(),
        first_snapshot.as_str(),
        "retention must delete the older distinct snapshot instead of overwriting it"
    );
}

#[tokio::test]
async fn s3_backend_restores_newest_mixed_burr_and_rurr_snapshot_key() {
    if !live_enabled() {
        return;
    }

    let snapshot = S3BackendLiveScenario::new("rurr-s3-mixed-snap").await;
    let older_source = S3BackendLiveScenario::new("rurr-s3-old-src").await;
    let newer_source = S3BackendLiveScenario::new("rurr-s3-new-src").await;

    let older_db = older_source
        .snapshot_db_bytes_for_tracked_app("project-older", "app-older")
        .await;
    let newer_db = newer_source
        .snapshot_db_bytes_for_tracked_app("project-newer", "app-newer")
        .await;

    snapshot
        .put_object(
            "snapshots/4294965296-1970-01-01T00:33:20.000000000Z/backend/rurr-old/snapshot.db",
            ByteStream::from(older_db),
            &[],
        )
        .await;
    snapshot
        .put_object(
            "snapshots/4294965295-1970-01-01T00:33:21.123456+00:00/backend/burr-new/snapshot.db",
            ByteStream::from(newer_db),
            &[],
        )
        .await;

    let restored = snapshot
        .backend(BackendScenarioConfig {
            prior_snapshots_to_keep: 2,
            list_page_size: Some(1),
            ..DEFAULT_BACKEND_SCENARIO
        })
        .await;
    let restored_projects = restored
        .list_projects()
        .await
        .expect("restored projects should list");
    assert_eq!(restored_projects.len(), 1);
    assert_eq!(restored_projects[0].name, "project-newer");

    restored
        .snapshot()
        .await
        .expect("snapshot retention should run");
    let raw_snapshot_keys = snapshot.provider_keys("snapshots/").await;
    let snapshot_keys = raw_snapshot_keys
        .iter()
        .filter(|key| key.ends_with("/snapshot.db"))
        .cloned()
        .collect::<Vec<_>>();
    assert_eq!(snapshot_keys.len(), 2);
    assert!(
        snapshot_keys.iter().any(|key| key.contains("00:33:21")),
        "retention should keep the newer Burr timestamp alongside the fresh snapshot, got {snapshot_keys:?}"
    );
    assert!(
        snapshot_keys.iter().all(|key| !key.contains("00:33:20")),
        "retention should delete the older parsed timestamp, got {snapshot_keys:?}"
    );
}

#[tokio::test]
async fn s3_backend_fails_malformed_index_inputs_without_defaults() {
    if !live_enabled() {
        return;
    }

    let _env = EnvVarGuard::set([
        ("AWS_ACCESS_KEY_ID", None),
        ("AWS_SECRET_ACCESS_KEY", None),
        ("AWS_SESSION_TOKEN", None),
    ]);
    let missing_creds = S3BackendLiveScenario::new("rurr-server-s3-missing-creds").await;
    let error = match S3Backend::new(missing_creds.config(BackendScenarioConfig {
        credentials: false,
        ..DEFAULT_BACKEND_SCENARIO
    }))
    .await
    {
        Ok(_) => panic!("missing static credentials should fail before backend provider setup"),
        Err(error) => error,
    };
    match error {
        BackendError::Configuration { message } => assert!(
            message.contains("missing access_key_id for S3 backend"),
            "unexpected configuration error: {message}"
        ),
        other => panic!("expected backend configuration error, got {other:?}"),
    }
    assert!(
        missing_creds.provider_keys("data/").await.is_empty(),
        "missing credentials must not produce indexed S3 objects"
    );

    let cases = [
        MalformedArtifactCase {
            bucket_prefix: "rurr-server-s3-bad",
            key: "data/project-b/2026/05/07/14/00:00.000000000/__none__/app-b/bad__log.jsonl",
            body: br#"{"type":"begin_entry","sequence_id":1}"#,
            metadata: &[],
            expected_error_fragment: "missing required metadata 'min_sequence_id'",
        },
        MalformedArtifactCase {
            bucket_prefix: "rurr-server-s3-bad-num",
            key: "data/project-c/2026/05/07/14/00:00.000000000/__none__/app-c/bad__log.jsonl",
            body: br#"{"type":"begin_entry","sequence_id":7}"#,
            metadata: &[
                ("tracker_id", "tracker-bad"),
                ("min_sequence_id", "not-a-number"),
                ("max_sequence_id", "7"),
            ],
            expected_error_fragment: "invalid unsigned integer 'not-a-number'",
        },
        MalformedArtifactCase {
            bucket_prefix: "rurr-server-s3-bad-pointer",
            key: "data/project-p/2026/05/07/14/00:00/__none__/app-p/metadata.json",
            body: br#"{}"#,
            metadata: &[
                ("tracker_id", "tracker-bad-pointer"),
                ("parent_pointer", "not-json"),
                ("spawning_parent_pointer", "None"),
            ],
            expected_error_fragment: "parent_pointer",
        },
        MalformedArtifactCase {
            bucket_prefix: "rurr-server-s3-bad-key",
            key: "data/project-d/2026/99/07/14/00:00.000000000/__none__/app-d/graph.json",
            body: br#"{}"#,
            metadata: &[],
            expected_error_fragment: "invalid month",
        },
        MalformedArtifactCase {
            bucket_prefix: "rurr-server-s3-bad-jsonl",
            key: "data/project-e/2026/05/07/14/00:00.000000000/__none__/app-e/bad__log.jsonl",
            body: b"{not-json}\n",
            metadata: &[
                ("tracker_id", "tracker-bad-jsonl"),
                ("min_sequence_id", "7"),
                ("max_sequence_id", "7"),
            ],
            expected_error_fragment: "key must be a string",
        },
        MalformedArtifactCase {
            bucket_prefix: "rurr-server-s3-bad-entry",
            key: "data/project-f/2026/05/07/14/00:00.000000000/__none__/app-f/bad__log.jsonl",
            body: br#"{"type":"begin_entry","start_time":"2026-04-11T20:51:59.096000Z","action":"counter","inputs":{}}"#,
            metadata: &[
                ("tracker_id", "tracker-bad-entry"),
                ("min_sequence_id", "0"),
                ("max_sequence_id", "0"),
            ],
            expected_error_fragment: "sequence_id",
        },
        MalformedArtifactCase {
            bucket_prefix: "rurr-server-s3-truncated-jsonl",
            key: "data/project-g/2026/05/07/14/00:00.000000000/__none__/app-g/bad__log.jsonl",
            body: br#"{"type":"begin_entry","sequence_id":0"#,
            metadata: &[
                ("tracker_id", "tracker-truncated-jsonl"),
                ("min_sequence_id", "0"),
                ("max_sequence_id", "0"),
            ],
            expected_error_fragment: "EOF while parsing",
        },
    ];

    for case in cases {
        S3BackendLiveScenario::assert_malformed_index_case(case).await;
    }
}
