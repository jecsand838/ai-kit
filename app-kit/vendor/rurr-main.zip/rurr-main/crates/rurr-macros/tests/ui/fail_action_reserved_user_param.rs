use rurr_core::action::{ActionError, ActionResult};
use rurr_core::state::State;

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
fn reserved_input(state: &State, __count: i64) -> Result<ActionResult, ActionError> {
    let _ = (state, __count);
    Ok(ActionResult::new(Default::default(), Default::default()))
}

fn main() {}
