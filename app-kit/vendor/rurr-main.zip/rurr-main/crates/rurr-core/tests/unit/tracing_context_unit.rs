use crate::support_common::tracing::{tracer_with_recording_hooks, FailOnceHook, RecordingHooks};
use indexmap::IndexMap;
use rurr_core::action::ActionTracer;
use rurr_core::lifecycle::{LifecycleAdapterSet, SyncLifecycleAdapter};
use rurr_core::visibility::{trace, trace_async, TraceOptions, TraceSpanHandle, VisibilityError};
use serde_json::json;
use std::sync::Arc;

fn event_labels(recorder: &RecordingHooks) -> Vec<String> {
    recorder
        .events()
        .into_iter()
        .map(|event| format!("{}:{}", event.phase(), event.span_name()))
        .collect()
}

#[test]
fn trace_with_inactive_tracer_is_a_noop() {
    let result = trace(
        &ActionTracer::default(),
        "double",
        &IndexMap::from([("value".to_string(), json!(2))]),
        &TraceOptions::new(),
        |span: TraceSpanHandle| {
            assert!(span.span().is_none());
            4
        },
    )
    .expect("inactive trace should still succeed");
    assert_eq!(result, 4);
}

#[test]
fn explicit_tracer_scopes_span_handle_and_cleans_up_after_trace() {
    let recorder = Arc::new(RecordingHooks::default());
    let result = trace(
        &tracer_with_recording_hooks(0, Arc::clone(&recorder)),
        "double",
        &IndexMap::from([("value".to_string(), json!(2))]),
        &TraceOptions::new(),
        |span: TraceSpanHandle| {
            assert_eq!(span.span().map(|span| span.span_name()), Some("double"));
            span.log_attribute("inside", json!(true))
                .expect("attribute should log");
            4
        },
    )
    .expect("trace should succeed");

    assert_eq!(result, 4);
    assert_eq!(
        event_labels(&recorder),
        vec![
            "sync:start:double".to_string(),
            "sync:end:double".to_string()
        ]
    );
    let attributes = recorder.attributes();
    assert!(attributes
        .iter()
        .any(|(_, attrs)| attrs.get("value") == Some(&json!(2))));
    assert!(attributes
        .iter()
        .any(|(_, attrs)| attrs.get("inside") == Some(&json!(true))));
    assert!(attributes
        .iter()
        .any(|(_, attrs)| attrs.get("return") == Some(&json!(4))));
}

#[tokio::test]
async fn trace_async_scopes_span_handle_and_cleans_up_after_trace() {
    let recorder = Arc::new(RecordingHooks::default());
    let result = trace_async(
        &tracer_with_recording_hooks(0, Arc::clone(&recorder)),
        "triple",
        &IndexMap::from([("value".to_string(), json!(3))]),
        &TraceOptions::new(),
        |span: TraceSpanHandle| async move {
            assert_eq!(span.span().map(|span| span.span_name()), Some("triple"));
            span.log_attribute_async("seen_async", json!(2))
                .await
                .expect("attribute should log");
            9
        },
    )
    .await
    .expect("async trace should succeed");
    assert_eq!(result, 9);
    assert_eq!(
        event_labels(&recorder),
        vec![
            "sync:start:triple".to_string(),
            "async:start:triple".to_string(),
            "sync:end:triple".to_string(),
            "async:end:triple".to_string(),
        ]
    );
}

#[test]
fn failed_pre_start_hook_restores_tracer_for_reuse() {
    let recorder = Arc::new(FailOnceHook::default());
    let sync_recorder: Arc<dyn SyncLifecycleAdapter> = recorder;
    let tracer = ActionTracer::new(
        "test_action",
        0,
        LifecycleAdapterSet::new(vec![sync_recorder], Vec::new()),
        "test-app",
        None,
    );

    let error = trace(
        &tracer,
        "flaky",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_span: TraceSpanHandle| 1,
    )
    .expect_err("first trace should fail");
    assert!(matches!(error, VisibilityError::HookFailed { .. }));

    let recovered = trace(
        &tracer,
        "recovered",
        &IndexMap::new(),
        &TraceOptions::new(),
        |_span: TraceSpanHandle| 2,
    )
    .expect("second trace should recover");
    assert_eq!(recovered, 2);
}
