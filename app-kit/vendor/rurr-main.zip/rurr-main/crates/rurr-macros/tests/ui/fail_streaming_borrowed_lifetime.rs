use rurr_core::action::StreamOutput;
use rurr_core::state::State;

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
fn borrowed_stream_lifetime<'a>(state: &'a State) -> Box<dyn Iterator<Item = StreamOutput> + 'a> {
    Box::new(std::iter::from_fn(move || {
        let _ = state.get("count");
        None
    }))
}

fn main() {}
