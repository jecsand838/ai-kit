use rurr_tracking_store::resolve_home_dir_from_env;
use std::fs;
use std::path::{Path, PathBuf};
use uuid::Uuid;

const CONFIG_FILENAME: &str = ".rurr.conf";
const ENV_ENABLEMENT: &str = "BURR_TELEMETRY_ENABLED";

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct TelemetryReadyConfig {
    pub(crate) anonymous_id: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum TelemetryConfigLoad {
    Ready(TelemetryReadyConfig),
    Disabled(TelemetryDisabledReason),
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum TelemetryDisabledReason {
    MissingHomeDirectory,
    ConfigRead { path: PathBuf, message: String },
    ConfigWrite { path: PathBuf, message: String },
    InvalidEnablement,
    TelemetryDisabled,
    ProviderInit { message: String },
}

impl TelemetryReadyConfig {
    pub(crate) fn load_from_process() -> TelemetryConfigLoad {
        let Some(path) = config_path() else {
            return TelemetryConfigLoad::Disabled(TelemetryDisabledReason::MissingHomeDirectory);
        };
        let parsed = match fs::read_to_string(&path) {
            Ok(contents) => parse_config_file(&contents),
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => ParsedConfig::default(),
            Err(error) => {
                return TelemetryConfigLoad::Disabled(TelemetryDisabledReason::ConfigRead {
                    path,
                    message: error.to_string(),
                })
            }
        };

        let resolved_enablement =
            resolve_enabled(parsed.telemetry_enabled, std::env::var(ENV_ENABLEMENT).ok());
        if !resolved_enablement.is_valid() {
            return TelemetryConfigLoad::Disabled(TelemetryDisabledReason::InvalidEnablement);
        }
        if !resolved_enablement.enabled() {
            return TelemetryConfigLoad::Disabled(TelemetryDisabledReason::TelemetryDisabled);
        }

        let missing_anonymous_id = parsed.anonymous_id.is_none();
        let anonymous_id = parsed
            .anonymous_id
            .clone()
            .unwrap_or_else(|| Uuid::new_v4().to_string());
        let persisted_enabled = parsed
            .telemetry_enabled
            .and_then(ParsedEnablement::valid_value)
            .unwrap_or(true);

        if missing_anonymous_id {
            if let Err(error) = write_config(&path, persisted_enabled, &anonymous_id) {
                return TelemetryConfigLoad::Disabled(TelemetryDisabledReason::ConfigWrite {
                    path,
                    message: error.to_string(),
                });
            }
        }

        TelemetryConfigLoad::Ready(Self { anonymous_id })
    }
}

#[derive(Debug, Default)]
struct ParsedConfig {
    telemetry_enabled: Option<ParsedEnablement>,
    anonymous_id: Option<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ParsedEnablement {
    Valid(bool),
    Invalid,
}

impl ParsedEnablement {
    fn valid_value(self) -> Option<bool> {
        match self {
            Self::Valid(value) => Some(value),
            Self::Invalid => None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ResolvedEnablement {
    Valid(bool),
    Invalid,
}

impl ResolvedEnablement {
    fn enabled(self) -> bool {
        match self {
            Self::Valid(value) => value,
            Self::Invalid => false,
        }
    }

    fn is_valid(self) -> bool {
        matches!(self, Self::Valid(_))
    }
}

fn config_path() -> Option<PathBuf> {
    resolve_home_dir_from_env().map(|home| home.join(CONFIG_FILENAME))
}

fn parse_config_file(contents: &str) -> ParsedConfig {
    let mut parsed = ParsedConfig::default();
    let mut in_default = true;

    for raw_line in contents.lines() {
        let line = raw_line.trim();
        if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
            continue;
        }
        if line.starts_with('[') && line.ends_with(']') {
            in_default = &line[1..line.len() - 1] == "DEFAULT";
            continue;
        }
        if !in_default {
            continue;
        }
        let Some((key, value)) = line.split_once('=') else {
            continue;
        };
        let key = key.trim();
        let value = value.trim();
        match key {
            "telemetry_enabled" => {
                parsed.telemetry_enabled = Some(parse_enablement(value));
            }
            "anonymous_id" if !value.is_empty() => {
                parsed.anonymous_id = Some(value.to_string());
            }
            _ => {}
        }
    }

    parsed
}

fn parse_enablement(value: &str) -> ParsedEnablement {
    parse_bool(value)
        .map(ParsedEnablement::Valid)
        .unwrap_or(ParsedEnablement::Invalid)
}

fn parse_bool(value: &str) -> Option<bool> {
    if value.eq_ignore_ascii_case("1")
        || value.eq_ignore_ascii_case("true")
        || value.eq_ignore_ascii_case("yes")
        || value.eq_ignore_ascii_case("on")
    {
        return Some(true);
    }
    if value.eq_ignore_ascii_case("0")
        || value.eq_ignore_ascii_case("false")
        || value.eq_ignore_ascii_case("no")
        || value.eq_ignore_ascii_case("off")
    {
        return Some(false);
    }
    None
}

fn resolve_enabled(
    file_value: Option<ParsedEnablement>,
    env_value: Option<String>,
) -> ResolvedEnablement {
    let env_value = env_value.as_deref().map(parse_enablement);
    if matches!(file_value, Some(ParsedEnablement::Invalid))
        || matches!(env_value, Some(ParsedEnablement::Invalid))
    {
        return ResolvedEnablement::Invalid;
    }

    let enabled = env_value
        .or(file_value)
        .and_then(ParsedEnablement::valid_value)
        .unwrap_or(true);
    ResolvedEnablement::Valid(enabled)
}

fn write_config(
    path: &Path,
    file_enablement: bool,
    anonymous_id: &str,
) -> Result<(), std::io::Error> {
    let payload = format!(
        "[DEFAULT]\ntelemetry_enabled = {}\nanonymous_id = {}\n",
        if file_enablement { "true" } else { "false" },
        anonymous_id
    );
    fs::write(path, payload)
}

#[cfg(test)]
mod tests {
    use super::{TelemetryConfigLoad, TelemetryDisabledReason, TelemetryReadyConfig};
    use rurr_testkit::env::EnvVarGuard;
    use tempfile::tempdir;

    const INVALID_CONFIG_LIVE_PROOF: &str =
        "crates/rurr-telemetry/tests/invalid_config_live.rs::invalid_enablement_config_emits_no_telemetry";

    fn with_env<const N: usize, F>(vars: [(&str, Option<&str>); N], test: F)
    where
        F: FnOnce(),
    {
        let _env = EnvVarGuard::set(vars);
        test();
    }

    fn expect_ready(load: TelemetryConfigLoad) -> TelemetryReadyConfig {
        match load {
            TelemetryConfigLoad::Ready(config) => config,
            TelemetryConfigLoad::Disabled(reason) => {
                panic!("telemetry config should be ready, got disabled reason: {reason:?}")
            }
        }
    }

    fn expect_disabled(load: TelemetryConfigLoad) -> TelemetryDisabledReason {
        match load {
            TelemetryConfigLoad::Ready(config) => {
                panic!("telemetry config should be disabled, got ready config: {config:?}")
            }
            TelemetryConfigLoad::Disabled(reason) => reason,
        }
    }

    #[test]
    fn load_from_process_creates_and_persists_anonymous_id() {
        let home = tempdir().expect("tempdir should create");
        with_env(
            [
                (
                    "HOME",
                    Some(home.path().to_str().expect("home path should be utf-8")),
                ),
                ("USERPROFILE", None),
                ("HOMEDRIVE", None),
                ("HOMEPATH", None),
                ("BURR_TELEMETRY_ENABLED", None),
            ],
            || {
                let first = expect_ready(TelemetryReadyConfig::load_from_process());
                let second = expect_ready(TelemetryReadyConfig::load_from_process());
                assert_eq!(first.anonymous_id, second.anonymous_id);
                assert!(
                    home.path().join(".rurr.conf").exists(),
                    "config file should be written once anonymous id is created"
                );
            },
        );
    }

    #[test]
    fn file_enablement_is_respected() {
        let home = tempdir().expect("tempdir should create");
        std::fs::write(
            home.path().join(".rurr.conf"),
            "[DEFAULT]\ntelemetry_enabled = false\nanonymous_id = persisted-id\n",
        )
        .expect("config file should write");

        with_env(
            [
                (
                    "HOME",
                    Some(home.path().to_str().expect("home path should be utf-8")),
                ),
                ("USERPROFILE", None),
                ("HOMEDRIVE", None),
                ("HOMEPATH", None),
                ("BURR_TELEMETRY_ENABLED", None),
            ],
            || {
                let reason = expect_disabled(TelemetryReadyConfig::load_from_process());
                assert_eq!(reason, TelemetryDisabledReason::TelemetryDisabled);
            },
        );
    }

    #[test]
    fn env_enablement_overrides_file_state() {
        let home = tempdir().expect("tempdir should create");
        std::fs::write(
            home.path().join(".rurr.conf"),
            "[DEFAULT]\ntelemetry_enabled = false\nanonymous_id = persisted-id\n",
        )
        .expect("config file should write");

        with_env(
            [
                (
                    "HOME",
                    Some(home.path().to_str().expect("home path should be utf-8")),
                ),
                ("USERPROFILE", None),
                ("HOMEDRIVE", None),
                ("HOMEPATH", None),
                ("BURR_TELEMETRY_ENABLED", Some("true")),
            ],
            || {
                let config = expect_ready(TelemetryReadyConfig::load_from_process());
                assert_eq!(config.anonymous_id, "persisted-id");
            },
        );
    }

    #[test]
    fn env_disable_does_not_persist_false_for_new_config() {
        let home = tempdir().expect("tempdir should create");

        with_env(
            [
                (
                    "HOME",
                    Some(home.path().to_str().expect("home path should be utf-8")),
                ),
                ("USERPROFILE", None),
                ("HOMEDRIVE", None),
                ("HOMEPATH", None),
                ("BURR_TELEMETRY_ENABLED", Some("false")),
            ],
            || {
                let reason = expect_disabled(TelemetryReadyConfig::load_from_process());
                assert_eq!(reason, TelemetryDisabledReason::TelemetryDisabled);
                assert!(
                    !home.path().join(".rurr.conf").exists(),
                    "disabled telemetry should not create a synthetic config file"
                );
            },
        );
    }

    #[test]
    fn env_override_preserves_existing_file_enablement_when_adding_anonymous_id() {
        let home = tempdir().expect("tempdir should create");
        std::fs::write(
            home.path().join(".rurr.conf"),
            "[DEFAULT]\ntelemetry_enabled = false\n",
        )
        .expect("config file should write");

        with_env(
            [
                (
                    "HOME",
                    Some(home.path().to_str().expect("home path should be utf-8")),
                ),
                ("USERPROFILE", None),
                ("HOMEDRIVE", None),
                ("HOMEPATH", None),
                ("BURR_TELEMETRY_ENABLED", Some("true")),
            ],
            || {
                let config = expect_ready(TelemetryReadyConfig::load_from_process());
                let contents = std::fs::read_to_string(home.path().join(".rurr.conf"))
                    .expect("config file should be readable");

                assert!(!config.anonymous_id.is_empty());
                assert!(
                    contents.contains("telemetry_enabled = false"),
                    "existing file state should be preserved when env overrides runtime enablement: {contents}"
                );
                assert!(contents.contains("anonymous_id = "));
            },
        );
    }

    #[test]
    fn invalid_enablement_values_fail_closed_without_rewriting_config() {
        let home = tempdir().expect("tempdir should create");
        let config_path = home.path().join(".rurr.conf");
        let original = "[DEFAULT]\ntelemetry_enabled = definitely\n";
        std::fs::write(&config_path, original).expect("config file should write");

        with_env(
            [
                (
                    "HOME",
                    Some(home.path().to_str().expect("home path should be utf-8")),
                ),
                ("USERPROFILE", None),
                ("HOMEDRIVE", None),
                ("HOMEPATH", None),
                ("BURR_TELEMETRY_ENABLED", Some("absolutely-not")),
            ],
            || {
                let reason = expect_disabled(TelemetryReadyConfig::load_from_process());
                assert_eq!(
                    reason,
                    TelemetryDisabledReason::InvalidEnablement,
                    "invalid telemetry config must fail closed and emit no telemetry; strict live proof is {INVALID_CONFIG_LIVE_PROOF}"
                );
                let contents =
                    std::fs::read_to_string(&config_path).expect("config file should be readable");
                assert_eq!(
                    contents, original,
                    "invalid telemetry config should not be rewritten into a passing shape; strict live proof is {INVALID_CONFIG_LIVE_PROOF}"
                );
            },
        );
    }

    #[test]
    fn invalid_env_enablement_takes_precedence_over_file_state() {
        let home = tempdir().expect("tempdir should create");
        std::fs::write(
            home.path().join(".rurr.conf"),
            "[DEFAULT]\ntelemetry_enabled = true\nanonymous_id = persisted-id\n",
        )
        .expect("config file should write");

        with_env(
            [
                (
                    "HOME",
                    Some(home.path().to_str().expect("home path should be utf-8")),
                ),
                ("USERPROFILE", None),
                ("HOMEDRIVE", None),
                ("HOMEPATH", None),
                ("BURR_TELEMETRY_ENABLED", Some("absolutely-not")),
            ],
            || {
                let reason = expect_disabled(TelemetryReadyConfig::load_from_process());
                assert_eq!(
                    reason,
                    TelemetryDisabledReason::InvalidEnablement,
                    "invalid env enablement must fail closed even when the file enables telemetry; strict live proof is {INVALID_CONFIG_LIVE_PROOF}"
                );
            },
        );
    }

    #[test]
    fn unreadable_config_path_is_explicitly_disabled() {
        let home = tempdir().expect("tempdir should create");
        let config_path = home.path().join(".rurr.conf");
        std::fs::create_dir(&config_path).expect("config path directory should create");

        with_env(
            [
                (
                    "HOME",
                    Some(home.path().to_str().expect("home path should be utf-8")),
                ),
                ("USERPROFILE", None),
                ("HOMEDRIVE", None),
                ("HOMEPATH", None),
                ("BURR_TELEMETRY_ENABLED", Some("true")),
            ],
            || {
                let reason = expect_disabled(TelemetryReadyConfig::load_from_process());
                assert!(
                    matches!(
                        reason,
                        TelemetryDisabledReason::ConfigRead { path, .. } if path == config_path
                    ),
                    "config read errors should surface as explicit disabled reasons"
                );
            },
        );
    }
}
