use mongodb::bson::{Binary, Document};
use mongodb::sync::{Cursor, Database};
use serde::de::DeserializeOwned;
use std::sync::MutexGuard;

use super::error::connection_closed_error;
use crate::{MongoPersister, OP_CONNECTION_LOCK_POISONED, OP_MONGODB_COMMAND_FAILED};
use rurr_persistence::PersistenceError;

impl MongoPersister {
    pub(crate) fn database(&self) -> Result<Database, PersistenceError> {
        self.ensure_open()?;
        Ok(self.client.database(self.config.db_name.as_str()))
    }

    pub(crate) fn lock_cached_collection_uuid(
        &self,
    ) -> Result<MutexGuard<'_, Option<Binary>>, PersistenceError> {
        self.cached_collection_uuid
            .lock()
            .map_err(|_| PersistenceError::UnsupportedOperation {
                operation: OP_CONNECTION_LOCK_POISONED,
            })
    }

    pub(crate) fn cache_collection_uuid(
        &self,
        collection_uuid: Binary,
    ) -> Result<(), PersistenceError> {
        *self.lock_cached_collection_uuid()? = Some(collection_uuid);
        Ok(())
    }

    pub(crate) fn invalidate_cached_collection_uuid(&self) {
        if let Ok(mut guard) = self.cached_collection_uuid.lock() {
            *guard = None;
        }
    }

    pub(crate) fn cached_collection_uuid(&self) -> Result<Option<Binary>, PersistenceError> {
        Ok(self.lock_cached_collection_uuid()?.clone())
    }

    pub(crate) fn collection_uuid(&self) -> Result<Binary, PersistenceError> {
        self.ensure_open()?;
        if let Some(collection_uuid) = self.cached_collection_uuid()? {
            return Ok(collection_uuid);
        }

        let collection_uuid = self.fetch_collection_uuid()?;
        self.cache_collection_uuid(collection_uuid.clone())?;
        Ok(collection_uuid)
    }

    pub(crate) fn fetch_collection_uuid(&self) -> Result<Binary, PersistenceError> {
        let database = self.database()?;
        let mut cursor = database
            .list_collections()
            .filter(mongodb::bson::doc! { "name": self.config.collection_name.as_str() })
            .run()
            .map_err(|error| self.map_command_error(error, OP_MONGODB_COMMAND_FAILED))?;

        while let Some(specification) = self.cursor_next(&mut cursor)? {
            if specification.name == self.config.collection_name {
                return specification
                    .info
                    .uuid
                    .ok_or(PersistenceError::UnsupportedOperation {
                        operation: OP_MONGODB_COMMAND_FAILED,
                    });
            }
        }

        Err(self.track_persistence_error(PersistenceError::NotInitialized))
    }

    pub(crate) fn run_raw_cursor_command(
        &self,
        command: Document,
    ) -> Result<Cursor<Document>, PersistenceError> {
        self.database()?
            .run_cursor_command(command)
            .run()
            .map_err(|error| self.map_command_error(error, OP_MONGODB_COMMAND_FAILED))
    }

    pub(crate) fn cursor_next<T>(
        &self,
        cursor: &mut Cursor<T>,
    ) -> Result<Option<T>, PersistenceError>
    where
        T: DeserializeOwned,
    {
        if cursor
            .advance()
            .map_err(|error| self.map_command_error(error, OP_MONGODB_COMMAND_FAILED))?
        {
            cursor
                .deserialize_current()
                .map(Some)
                .map_err(|error| self.map_command_error(error, OP_MONGODB_COMMAND_FAILED))
        } else {
            Ok(None)
        }
    }
    pub(crate) fn ensure_open(&self) -> Result<(), PersistenceError> {
        if self.closed.load(std::sync::atomic::Ordering::Acquire) {
            Err(connection_closed_error())
        } else {
            Ok(())
        }
    }
}
