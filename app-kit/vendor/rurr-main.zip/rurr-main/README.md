# Rurr

Rurr is a Rust-native implementation of [Apache Burr](https://github.com/apache/burr).
The current `dev` branch targets behavioral parity with Burr `v0.41.0` while keeping the runtime
idiomatic to Rust: borrowed streaming, explicit sync/async surfaces, typed errors, and deterministic
tracking/persistence artifacts. Current execution parity includes tag-aware halt controls, and
current tracking parity treats required local artifacts as required instead of inventing empty
fallback histories.

The public user surface is centered on:

- `rurr` as the facade crate
- `ApplicationBuilder` + `Application` for runtime construction and execution
- feature-gated persistence backends for SQLite, Postgres, Redis, and MongoDB
- `rurr::tracking` for tracking helpers and local tracking access
- `rurr-macros` for attribute-style action definitions

## Quick Start

```rust
use indexmap::IndexMap;
use rurr::{ApplicationBuilder, FunctionActionBuilder, State};
use serde_json::{json, Value};

fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
    pairs
        .into_iter()
        .map(|(k, v)| (k.to_string(), v))
        .collect()
}

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let increment = FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .build_sync(|state, _ctx| {
            let next = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            map_from_pairs([("count", json!(next))])
        })?;

    let mut app = ApplicationBuilder::new()
        .with_state(State::new(map_from_pairs([("count", json!(0))])))?
        .with_actions(vec![("increment", increment)])?
        .with_transitions(Vec::new())?
        .with_entrypoint("increment")?
        .build()?;

    let output = app.run()?;
    println!("state = {:?}", output.state.get_all());
    Ok(())
}
```

## Features

| Feature | Crate | What it enables |
|---|---|---|
| `sqlite` | `rurr-sqlite` | SQLite persistence |
| `postgres` | `rurr-postgres` | Postgres persistence |
| `redis` | `rurr-redis` | Redis persistence |
| `mongodb` | `rurr-mongodb` | MongoDB persistence |
| `tracking` | `rurr` facade over `rurr-core` tracking | Tracking helpers and local tracking access |
| `s3` | `rurr-core/s3` through the facade | Burr-compatible S3 tracking helpers |
| `otel` | `rurr-otel` | OpenTelemetry export |
| `telemetry` | `rurr-telemetry` | Burr-style anonymous telemetry helpers |
| `macros` | `rurr-macros` | Proc-macro action definitions |

Tracking helpers and models live directly in `rurr-core` and surface through `rurr::tracking`.
S3 support is a concrete provider feature, so slim/default core builds do not compile AWS SDK
transport code unless `s3` is enabled.

## Async Build And Persistence

```rust
use std::sync::Arc;
use rurr::{ApplicationBuilder, FunctionActionBuilder, State};
use rurr_persistence::{
    ApplicationPersistenceSpec, AsyncInMemoryPersister, StatePersisterSpec,
};

let action = FunctionActionBuilder::new()
    .build_async(|_state, _ctx| async { indexmap::IndexMap::new() })?;
let persister = Arc::new(AsyncInMemoryPersister::new());

let mut app = ApplicationBuilder::new()
    .with_state(State::default())?
    .with_actions(vec![("step", action)])?
    .with_entrypoint("step")?
    .with_persistence_spec(
        ApplicationPersistenceSpec::new()
            .with_persister(StatePersisterSpec::async_persister(persister)),
    )?
    .abuild()
    .await?;

let _ = app.arun().await?;
```

`build()` enforces sync-only initializer/persister wiring.  
`abuild()` enforces async-only initializer/persister wiring.

## Tracking Server And CLI

```bash
cargo run -p rurr-cli -- serve --host 127.0.0.1 --port 7241 --no-open
cargo run -p rurr-cli -- serve --backend s3 --s3-bucket rurr-tracking --s3-region us-east-1 --s3-addressing-style path-style --no-open
cargo run -p rurr-cli -- ui build --out-dir ./rurr-ui
```

`rurr serve` uses an embedded UI bundle by default, and `rurr ui build` exports that same bundle
to disk. The CLI also exposes `test-case create` and `admin publish` workflows for local tracking
and packaging checks. The old Burr-style demo-data generator is not part of the current Rurr CLI
surface.

S3 tracking, indexing, and snapshotting are validated through the docker-backed MinIO lane in
`./scripts/check_live.sh`. The live S3 tests use raw AWS SDK `LIST`, `HEAD`, and `GET` calls against
MinIO to prove object keys, user metadata, bodies, indexing jobs, high-watermarks, pagination, and
snapshot retention/restore behavior. S3 paths require explicit static credentials from config or
standard AWS environment variables. The S3 tracking-server backend keeps a local SQLite index,
supports provider snapshots, and is selected explicitly with `rurr serve --backend s3`; local file
tracking remains the default backend.

OpenTelemetry lifecycle/tracking bridge types live in `rurr-otel` and re-export through
`rurr::otel` when the facade `otel` feature is enabled. Anonymous telemetry helpers are explicit
through `rurr-telemetry` or the facade `telemetry` feature; `rurr-core` does not emit telemetry on
its own.

## Proc-Macro Ergonomics

```rust
// In Cargo.toml: rurr-macros = "1.0"
use rurr_macros::action;
use rurr::{ActionResult, ActionError, State};

#[action(reads = ["count"], writes = ["count"])]
fn increment(state: &State) -> Result<ActionResult, ActionError> {
    // ...
    # unimplemented!()
}
```

The `rurr-macros` crate provides the `#[action]` and `#[streaming_action]` attribute macros. Add it as a direct dependency for the cleanest attribute syntax. Alternatively, enable the `macros` feature on `rurr` and use `#[rurr::rurr_macros::action(...)]`.

Actions implement `LocalAction` by default. The facade also exports the generated sendable
`Action` trait, `ErasedAction` for runtime graph dispatch, and `LocalAsyncStreamOutput` /
`SendAsyncStreamOutput` helpers for async streaming surfaces.

## Architecture And Docs

- [`ARCHITECTURE.md`](ARCHITECTURE.md): workspace-level system map and boundaries
- [`crates/rurr-core/ARCHITECTURE.md`](crates/rurr-core/ARCHITECTURE.md): runtime/build/session/streaming internals
- [`crates/rurr-macros/ARCHITECTURE.md`](crates/rurr-macros/ARCHITECTURE.md): proc-macro parse/validate/expand pipeline
- [`tools/burr_oracle/ARCHITECTURE.md`](tools/burr_oracle/ARCHITECTURE.md): oracle bootstrap, scenarios, and raw comparator
- [`docs/00_overview.md`](docs/00_overview.md): documentation map and reading order
- [`docs/02_api_surface.md`](docs/02_api_surface.md): stable public Rust API contract
- [`docs/03_test_plan.md`](docs/03_test_plan.md): validation/spec layers
- [`docs/04_oracle_and_goldens.md`](docs/04_oracle_and_goldens.md): raw Burr-vs-Rurr oracle flow
- [`docs/compatibility/README.md`](docs/compatibility/README.md): compatibility contract docs
- [`docs/05_documentation_inventory.md`](docs/05_documentation_inventory.md): reviewed markdown inventory

## Workspace Layout

The workspace is organized around a thin facade plus focused implementation crates:

- Runtime and public API: `rurr`, `rurr-core`, `rurr-macros`, `rurr-persistence`
- Persistence backends: `rurr-sqlite`, `rurr-postgres`, `rurr-redis`, `rurr-mongodb`
- Tracking and operations: `rurr-tracking-store`, `rurr-tracking-server`, `rurr-cli`
- Observability and support: `rurr-otel`, `rurr-telemetry`, `rurr-testkit`, `rurr-oracle-test-support`

For the fuller tree, including repo-local skills, generated artifacts, and historical docs, see
[`docs/01_repo_layout.md`](docs/01_repo_layout.md).

## Development

Examples:

```bash
cargo run --example counter -p rurr
cargo run --example streaming_counter -p rurr
cargo run --example macro_counter -p rurr --features macros
cargo run --example sqlite_resume -p rurr --features sqlite
```

Primary workspace checks:

```bash
./scripts/check.sh
./scripts/check_oracle.sh
./scripts/check_competition.sh
```

Refactor standard: reductive cleanup should collapse repeated domain logic into structs, enums,
and methods. Do not introduce helper macros or macro helper crates to abstract ordinary production
or test code; `rurr-macros` is reserved for the public proc-macro action surface.

Live local services:

```bash
./scripts/dev_up.sh     # starts Postgres, Redis, MongoDB, MinIO, and Grafana/OTEL
./scripts/check_live.sh # boots services, waits for health, then runs docker-backed live proofs
./scripts/dev_down.sh   # tears down with volume cleanup
```

| Service   |  Port |
|-----------|------:|
| MongoDB   | 27017 |
| Postgres  |  5432 |
| Redis     |  6379 |
| MinIO API |  9000 |
| MinIO UI  |  9001 |
| Grafana   |  3000 |
| OTLP gRPC |  4317 |
| OTLP HTTP |  4318 |

`./scripts/dev_up.sh` brings up MongoDB at `mongodb://127.0.0.1:27017` alongside the other live
backend services used by the parity gates, MinIO at `http://127.0.0.1:9000`, plus the local
OTEL/Grafana stack defined in
`docker-compose.dev.yml`. The OTEL collector mounts the repo-owned
`tools/otel/otelcol-config.yaml` and writes strict live-proof JSONL artifacts under
`/data/rurr-live/` inside the `otel-lgtm` container. The collector exposes both OTLP gRPC and
OTLP HTTP ports, and the `rurr-otel` Rust bootstrap supports both transports through the standard
OTLP protocol configuration.

For the full gate breakdown and operator workflow, use [`docs/03_test_plan.md`](docs/03_test_plan.md)
and [`AGENTS.md`](AGENTS.md).

## Private Git Workspace Consumption

Downstream applications can consume this repository directly as a private git workspace.
See [`docs/private-git-workspace.md`](docs/private-git-workspace.md) for the canonical dependency
form, SSH onboarding, tag pinning, and GitHub Actions setup.

## Bootstrap Context

This repository includes compatibility docs, goldens, and oracle tooling used to build and validate Rurr.

Start here:
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/07_architecture_streaming_and_lifecycle.md`
- `docs/compatibility/README.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/03_test_plan.md`
- `docs/04_oracle_and_goldens.md`

Historical refactor material under `docs/refactors/rurr-refactor/` is intentionally preserved as archive context only; use the files above for current implementation and operator guidance.
