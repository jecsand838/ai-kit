use super::keys::{ActionRootKey, ActiveSpanKey, StepKey};
use super::span_slot::SpanSlot;
use crate::opentelemetry::trace::SpanContext as OtelSpanContext;
use crate::opentelemetry::Context;
use rurr_core::lifecycle::{ExecuteCallContext, LifecycleError, PreStepContext, SpanContext};
use std::collections::hash_map::Entry;
use std::collections::HashMap;
use std::sync::{Mutex, MutexGuard};

#[derive(Debug, Clone)]
pub(super) struct ExecuteMetadata {
    pub(super) app_id: String,
    pub(super) partition_key: String,
    pub(super) action: String,
}

impl ExecuteMetadata {
    fn from_execute(context: &ExecuteCallContext) -> Self {
        Self {
            app_id: context.app_id().to_string(),
            partition_key: context.partition_key().to_string(),
            action: context.action_name().to_string(),
        }
    }

    fn from_span(context: &SpanContext) -> Option<Self> {
        let app_id = context.app_id()?;
        Some(Self {
            app_id: app_id.to_string(),
            partition_key: context.partition_key().unwrap_or("").to_string(),
            action: context.action_name().to_string(),
        })
    }
}

#[derive(Default)]
pub(super) struct OtelLifecycleState {
    maps: Mutex<OtelLifecycleMaps>,
}

#[derive(Default)]
struct OtelLifecycleMaps {
    spans: HashMap<ActiveSpanKey, SpanSlot>,
    step_spans: HashMap<StepKey, SpanSlot>,
    execute_context: HashMap<ActionRootKey, ExecuteMetadata>,
}

pub(super) struct RejectedSpanSlot {
    span: SpanSlot,
    error: LifecycleError,
}

impl RejectedSpanSlot {
    fn new(span: SpanSlot, error: LifecycleError) -> Self {
        Self { span, error }
    }

    pub(super) fn into_parts(self) -> (SpanSlot, LifecycleError) {
        (self.span, self.error)
    }
}

impl OtelLifecycleState {
    pub(super) fn new() -> Self {
        Self::default()
    }

    fn maps(&self) -> MutexGuard<'_, OtelLifecycleMaps> {
        self.maps
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner())
    }

    pub(super) fn begin_execute(&self, context: &ExecuteCallContext) {
        self.maps().execute_context.insert(
            ActionRootKey::from_execute(context),
            ExecuteMetadata::from_execute(context),
        );
    }

    pub(super) fn finish_execute(&self, context: &ExecuteCallContext) -> ActionRootKey {
        let key = ActionRootKey::from_execute(context);
        self.maps().execute_context.remove(&key);
        key
    }

    pub(super) fn metadata_for_span(
        &self,
        context: &SpanContext,
    ) -> Result<ExecuteMetadata, LifecycleError> {
        if let Some(metadata) = ExecuteMetadata::from_span(context) {
            return Ok(metadata);
        }
        self.metadata_for_execution(
            context.app_id(),
            context.sequence_id(),
            context.action_name(),
        )
    }

    pub(super) fn metadata_for_execution(
        &self,
        app_id: Option<&str>,
        sequence_id: u64,
        action_name: &str,
    ) -> Result<ExecuteMetadata, LifecycleError> {
        let key = ActionRootKey::from_optional(app_id, sequence_id, action_name)?;
        match self.maps().execute_context.get(&key) {
            Some(metadata) => Ok(metadata.clone()),
            None => Err(LifecycleError::hook_failed(
                "otel_required_attributes",
                format!(
                    "missing execute metadata for app {} sequence {} action {}",
                    key.app_id, key.sequence_id, action_name
                ),
            )),
        }
    }

    pub(super) fn step_context_for_pre(&self, context: &PreStepContext) -> Option<Context> {
        let step_key = StepKey::from_pre(context)?;
        self.maps()
            .step_spans
            .get(&step_key)
            .map(|span| span.context().clone())
    }

    pub(super) fn span_context_for(&self, context: &SpanContext) -> Option<Context> {
        let span_key = ActiveSpanKey::from_context(context);
        self.maps()
            .spans
            .get(&span_key)
            .map(|span| span.context().clone())
    }

    pub(super) fn visibility_span_context(
        &self,
        key: &ActiveSpanKey,
        phase: &'static str,
    ) -> Result<Context, LifecycleError> {
        self.maps()
            .spans
            .get(key)
            .map(|span| span.context().clone())
            .ok_or_else(|| Self::missing_visibility_span(key, phase))
    }

    pub(super) fn parent_span_context(
        &self,
        context: &SpanContext,
        parent_span_id: &str,
    ) -> Option<OtelSpanContext> {
        let parent_key = ActiveSpanKey::from_parent(context, parent_span_id);
        self.maps()
            .spans
            .get(&parent_key)
            .map(|span| span.span_context().clone())
    }

    pub(super) fn ensure_step_span_vacant(
        &self,
        key: &StepKey,
        phase: &'static str,
    ) -> Result<(), LifecycleError> {
        if self.maps().step_spans.contains_key(key) {
            return Err(Self::duplicate_step_span(key, phase));
        }
        Ok(())
    }

    pub(super) fn insert_step_span(
        &self,
        key: StepKey,
        span: SpanSlot,
        phase: &'static str,
    ) -> Result<(), Box<RejectedSpanSlot>> {
        let mut maps = self.maps();
        match maps.step_spans.entry(key) {
            Entry::Vacant(entry) => {
                entry.insert(span);
                Ok(())
            }
            Entry::Occupied(entry) => Err(Box::new(RejectedSpanSlot::new(
                span,
                Self::duplicate_step_span(entry.key(), phase),
            ))),
        }
    }

    pub(super) fn take_step_span(
        &self,
        key: &StepKey,
        phase: &'static str,
    ) -> Result<SpanSlot, LifecycleError> {
        self.maps().step_spans.remove(key).ok_or_else(|| {
            LifecycleError::hook_failed(
                phase,
                format!(
                    "missing OTEL step span for app {} sequence {} step {}",
                    key.app_id, key.sequence_id, key.step_id
                ),
            )
        })
    }

    pub(super) fn ensure_visibility_span_vacant(
        &self,
        key: &ActiveSpanKey,
        phase: &'static str,
    ) -> Result<(), LifecycleError> {
        if self.maps().spans.contains_key(key) {
            return Err(Self::duplicate_visibility_span(key, phase));
        }
        Ok(())
    }

    pub(super) fn insert_visibility_span(
        &self,
        key: ActiveSpanKey,
        span: SpanSlot,
        phase: &'static str,
    ) -> Result<(), Box<RejectedSpanSlot>> {
        let mut maps = self.maps();
        match maps.spans.entry(key) {
            Entry::Vacant(entry) => {
                entry.insert(span);
                Ok(())
            }
            Entry::Occupied(entry) => Err(Box::new(RejectedSpanSlot::new(
                span,
                Self::duplicate_visibility_span(entry.key(), phase),
            ))),
        }
    }

    pub(super) fn take_visibility_span(
        &self,
        key: &ActiveSpanKey,
        phase: &'static str,
    ) -> Result<SpanSlot, LifecycleError> {
        self.maps()
            .spans
            .remove(key)
            .ok_or_else(|| Self::missing_visibility_span(key, phase))
    }

    fn missing_visibility_span(key: &ActiveSpanKey, phase: &'static str) -> LifecycleError {
        LifecycleError::hook_failed(
            phase,
            format!("missing OTEL visibility span for {}", key.describe()),
        )
    }

    fn duplicate_step_span(key: &StepKey, phase: &'static str) -> LifecycleError {
        LifecycleError::hook_failed(
            phase,
            format!(
                "duplicate OTEL step span for app {} sequence {} step {}",
                key.app_id, key.sequence_id, key.step_id
            ),
        )
    }

    fn duplicate_visibility_span(key: &ActiveSpanKey, phase: &'static str) -> LifecycleError {
        LifecycleError::hook_failed(
            phase,
            format!("duplicate OTEL visibility span for {}", key.describe()),
        )
    }
}
