mod support;

mod api_contract {
    #[cfg(unix)]
    use crate::support::api::{
        assert_annotation_filesystem_mutation_rejected, AnnotationFilesystemMutation,
    };
    use crate::support::api::{
        build_fixture, build_single_app_fixture, fixture_tempdir_app, local_backend_app,
        local_backend_tempdir_app, single_app_tempdir_app, truncated_log_tempdir_app,
    };
    use crate::support::api_helpers::{
        annotation_body, annotation_create_request, annotation_list_request, annotation_out_json,
        annotation_update_request, api_get, app_detail_request, apps_request,
        assert_bad_request_response, assert_json_error_response,
        assert_json_error_response_without_spa_rewrite, default_annotation_path,
        default_annotation_request, pointerless_annotation_body, projects_request,
        sample_annotation, tracking_endpoint_request, AnnotationRequestKind, TrackingEndpointKind,
        DEFAULT_ANNOTATION_ID, DEFAULT_APP_ID, DEFAULT_PARTITION_KEY, DEFAULT_PROJECT_ID,
        DEFAULT_STEP_SEQUENCE_ID,
    };
    use crate::support::response_json::response_json;
    use async_trait::async_trait;
    use axum::body::Body;
    use axum::http::{Request, StatusCode};
    use fs2::FileExt;
    use rurr_persistence::storage_layout_version;
    use rurr_testkit::tracking_fixture::artifacts::{write_json, write_jsonl};
    use rurr_testkit::workspace_fixture::with_locked_current_dir_async;
    use rurr_tracking_server::backend::local::LocalBackend;
    use rurr_tracking_server::backend::{
        BackendCapabilities, BackendError, PartitionSelector, TrackingBackend,
    };
    use rurr_tracking_server::router::AppState;
    use rurr_tracking_server::schema::{burr_compat_version, AnnotationOut, IndexingJob};
    use rurr_tracking_server::schema::{ApplicationLogs, ApplicationPage, Project};
    use serde_json::{json, Value};
    use std::fs;
    use std::io::Write;
    use std::path::PathBuf;
    use std::sync::mpsc;
    use std::sync::{Arc, Mutex};
    use std::time::Duration;
    use tower::ServiceExt;

    mod annotations;
    mod app_path_hardening;
    mod indexing;
    mod metadata_and_version;
    mod projects_and_apps;
}
