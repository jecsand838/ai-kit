use super::{
    PersistenceError, ASYNC_POOL_IDLE_TIMEOUT, ASYNC_POOL_MAX_CONNECTIONS, ASYNC_POOL_MAX_LIFETIME,
    ASYNC_POOL_MIN_CONNECTIONS, MIGRATION_SQL, OP_INVALID_TABLE_NAME,
};
use sqlx::sqlite::SqlitePoolOptions;

/// Returns the canonical async pool options used by the SQLite backend.
pub fn default_async_pool_options() -> SqlitePoolOptions {
    SqlitePoolOptions::new()
        .max_connections(ASYNC_POOL_MAX_CONNECTIONS)
        .min_connections(ASYNC_POOL_MIN_CONNECTIONS)
        .idle_timeout(ASYNC_POOL_IDLE_TIMEOUT)
        .max_lifetime(ASYNC_POOL_MAX_LIFETIME)
}

/// Normalizes a SQLite path or special memory name into a `sqlx` database URL.
pub fn normalize_database_url(database: &str) -> String {
    if database.starts_with("sqlite:") {
        database.to_string()
    } else if database == ":memory:" {
        "sqlite::memory:".to_string()
    } else {
        format!("sqlite://{database}")
    }
}

/// Renders the bundled migration SQL for a specific table name.
pub fn render_migration_sql(table_name: &str) -> String {
    MIGRATION_SQL.replace("__TABLE_NAME__", table_name)
}

/// Validates that a SQLite table name is safe to interpolate into the bundled
/// migration templates.
pub fn validate_table_name(table_name: &str) -> Result<(), PersistenceError> {
    let mut characters = table_name.chars();
    let Some(first_character) = characters.next() else {
        return Err(PersistenceError::UnsupportedOperation {
            operation: OP_INVALID_TABLE_NAME,
        });
    };

    let is_valid = (first_character.is_ascii_alphabetic() || first_character == '_')
        && characters.all(|character| character.is_ascii_alphanumeric() || character == '_');
    if is_valid {
        Ok(())
    } else {
        Err(PersistenceError::UnsupportedOperation {
            operation: OP_INVALID_TABLE_NAME,
        })
    }
}
