use crate::test_support::{registry_test_guard, unique_registry_name};
use indexmap::IndexMap;
use rurr_core::serde::{self as core_serde, SerdeError, KEY};
use rurr_core::state::{register_field_serde, DefaultTypingSystem, State, StateError};
use serde_json::{json, Value};
use std::sync::Arc;

use super::support::pairs::map_from_pairs;

#[test]
fn test_serialize_primitive_types() {
    assert_eq!(core_serde::serialize(&json!(1)), json!(1));
    assert_eq!(core_serde::serialize(&json!(1.0)), json!(1.0));
    assert_eq!(core_serde::serialize(&json!("test")), json!("test"));
    assert_eq!(core_serde::serialize(&json!(true)), json!(true));
}

#[test]
fn test_serialize_list() {
    assert_eq!(core_serde::serialize(&json!([1, 2, 3])), json!([1, 2, 3]));
    assert_eq!(
        core_serde::serialize(&json!(["a", "b", "c"])),
        json!(["a", "b", "c"])
    );
}

#[test]
fn test_serialize_dict() {
    assert_eq!(
        core_serde::serialize(&json!({"key": "value"})),
        json!({"key": "value"})
    );
    assert_eq!(
        core_serde::serialize(&json!({"key1": 1, "key2": 2})),
        json!({"key1": 1, "key2": 2})
    );
}

#[test]
fn test_deserialize_primitive_types() {
    let dispatch = core_serde::StringDispatch::new();

    assert_eq!(
        core_serde::deserialize(&json!(1), &dispatch).expect("deserialize should succeed"),
        json!(1)
    );
    assert_eq!(
        core_serde::deserialize(&json!(1.0), &dispatch).expect("deserialize should succeed"),
        json!(1.0)
    );
    assert_eq!(
        core_serde::deserialize(&json!("test"), &dispatch).expect("deserialize should succeed"),
        json!("test")
    );
    assert_eq!(
        core_serde::deserialize(&json!(true), &dispatch).expect("deserialize should succeed"),
        json!(true)
    );
}

#[test]
fn test_deserialize_list() {
    let dispatch = core_serde::StringDispatch::new();

    assert_eq!(
        core_serde::deserialize(&json!([1, 2, 3]), &dispatch).expect("deserialize should succeed"),
        json!([1, 2, 3])
    );
    assert_eq!(
        core_serde::deserialize(&json!(["a", "b", "c"]), &dispatch)
            .expect("deserialize should succeed"),
        json!(["a", "b", "c"])
    );
}

#[test]
fn test_deserialize_dict() {
    let dispatch = core_serde::StringDispatch::new();

    assert_eq!(
        core_serde::deserialize(&json!({"key": "value"}), &dispatch)
            .expect("deserialize should succeed"),
        json!({"key": "value"})
    );
    assert_eq!(
        core_serde::deserialize(&json!({"key1": 1, "key2": 2}), &dispatch)
            .expect("deserialize should succeed"),
        json!({"key1": 1, "key2": 2})
    );
}

#[test]
fn test_string_dispatch_no_key() {
    let dispatch = core_serde::StringDispatch::new();

    let error = dispatch
        .call("nonexistent_key", &Value::Null)
        .expect_err("missing key should fail");
    assert_eq!(
        error,
        SerdeError::MissingDispatchKey {
            key: "nonexistent_key".to_string(),
        }
    );
}

#[test]
fn test_string_dispatch_with_key() {
    let mut dispatch = core_serde::StringDispatch::new();
    dispatch.register("test_key", |value| {
        let extracted = value
            .as_object()
            .and_then(|object| object.get("value"))
            .cloned()
            .unwrap_or(Value::Null);
        Ok(extracted)
    });

    let payload = json!({KEY: "test_key", "value": "test_value"});

    let dispatch_result = dispatch
        .call("test_key", &payload)
        .expect("dispatch key should resolve");
    assert_eq!(dispatch_result, json!("test_value"));
}

#[test]
fn state_deserialize_uses_global_registered_serde_dispatch() {
    let _guard = registry_test_guard();
    let dispatch_key = unique_registry_name("serde_contract_dispatch_key");
    core_serde::register_serde_deserializer(dispatch_key.clone(), |value| {
        let extracted = value
            .as_object()
            .and_then(|object| object.get("value"))
            .cloned()
            .unwrap_or(Value::Null);
        Value::String(format!(
            "decoded::{}",
            extracted.as_str().unwrap_or_default()
        ))
    })
    .expect("global dispatch registration should succeed");

    let deserialized = State::deserialize(
        IndexMap::from([(
            "payload".to_string(),
            json!({KEY: dispatch_key, "value": "test_value"}),
        )]),
        Arc::new(DefaultTypingSystem),
    )
    .expect("state deserialize should use global serde dispatch");

    assert_eq!(
        deserialized.get("payload"),
        Some(&json!("decoded::test_value"))
    );
}

#[test]
fn register_field_serde_is_global() {
    let _guard = registry_test_guard();
    let field_name = unique_registry_name("serde_contract_field");
    register_field_serde(
        field_name.clone(),
        |value| {
            let text = value
                .as_str()
                .map(str::to_string)
                .unwrap_or_else(|| value.to_string());
            json!({"value": format!("serialized::{text}")})
        },
        |value| {
            let extracted = value
                .as_object()
                .and_then(|object| object.get("value"))
                .cloned()
                .unwrap_or(Value::Null);
            Value::String(
                extracted
                    .as_str()
                    .unwrap_or_default()
                    .replace("serialized::", ""),
            )
        },
    )
    .expect("field serde registration should succeed");

    let serialized = State::new(map_from_pairs([("payload", json!("unchanged"))]))
        .serialize()
        .expect("plain state serialize should succeed");
    assert_eq!(serialized.get("payload"), Some(&json!("unchanged")));

    let state = State::new(IndexMap::from([(field_name.clone(), json!("test_value"))]));
    let serialized = state.serialize().expect("state serialize should succeed");
    assert_eq!(
        serialized.get(&field_name),
        Some(&json!({"value": "serialized::test_value"}))
    );

    let deserialized = State::deserialize(
        IndexMap::from([(
            field_name.clone(),
            json!({"value": "serialized::test_value"}),
        )]),
        Arc::new(DefaultTypingSystem),
    )
    .expect("state deserialization should use global field serde");
    assert_eq!(
        deserialized.get(&field_name).cloned(),
        Some(json!("test_value"))
    );
}

#[test]
fn field_serde_handler_failures_are_deterministic() {
    let _guard = registry_test_guard();
    let serializer_field = unique_registry_name("serde_contract_serializer_error");
    register_field_serde(
        serializer_field.clone(),
        |_value| Err("serializer exploded"),
        |value| value.clone(),
    )
    .expect("serializer error field registration should succeed");

    let serializer_error = State::new(IndexMap::from([(serializer_field.clone(), json!("value"))]))
        .serialize()
        .expect_err("serializer handler should fail deterministically");
    match serializer_error {
        StateError::FieldSerdeHandlerFailed {
            field,
            direction,
            message,
        } => {
            assert_eq!(field, serializer_field);
            assert_eq!(direction, "serialize");
            assert!(message.contains("exploded"));
        }
        other => panic!("expected serializer handler error, got {other:?}"),
    }

    let deserializer_field = unique_registry_name("serde_contract_deserializer_error");
    register_field_serde(
        deserializer_field.clone(),
        |value| json!({"value": value}),
        |_value| Err("deserializer exploded"),
    )
    .expect("deserializer error field registration should succeed");

    let deserializer_error = State::deserialize(
        IndexMap::from([(deserializer_field.clone(), json!({"value": "payload"}))]),
        Arc::new(DefaultTypingSystem),
    )
    .expect_err("deserializer handler should fail deterministically");
    match deserializer_error {
        StateError::FieldSerdeHandlerFailed {
            field,
            direction,
            message,
        } => {
            assert_eq!(field, deserializer_field);
            assert_eq!(direction, "deserialize");
            assert!(message.contains("exploded"));
        }
        other => panic!("expected deserializer handler error, got {other:?}"),
    }
}
