//! Shared streaming-observation helpers used by strict streaming contract tests.
//!
//! The helpers in this module build async applications around a caller-provided
//! streaming source and assert Rurr's chunk-agnostic lazy streaming semantics.
//! Provider-specific response text and wire behavior belong to the strict live
//! tests that supply the source.

mod actions;
mod apps;
mod assertions;
mod common;
mod observation;
mod outputs;
mod sources;

use apps::{build_async_class_streaming_app, build_async_function_streaming_app};
use observation::{collect_async_observation, StreamingObservation};
use std::io;

pub use assertions::assert_chunk_agnostic_observation;
pub use common::{ExampleError, ExampleResult};
pub use sources::{AsyncChunkSource, AsyncChunkStream, AsyncChunkStreamFuture};

/// Observe the async function-based streaming parity scenario without hard-coding chunk boundaries.
pub async fn observe_async_function_streaming_roundtrip<S: AsyncChunkSource>(
    source: S,
) -> ExampleResult<StreamingObservation> {
    collect_async_observation(
        &source,
        build_async_function_streaming_app(source.clone()).await?,
    )
    .await
}

/// Observe the async class-based streaming parity scenario without hard-coding chunk boundaries.
pub async fn observe_async_class_streaming_roundtrip<S: AsyncChunkSource>(
    source: S,
) -> ExampleResult<StreamingObservation> {
    collect_async_observation(
        &source,
        build_async_class_streaming_app(source.clone()).await?,
    )
    .await
}

/// Prove that dropping an async streaming handle before terminal completion rolls state back.
pub async fn probe_async_function_streaming_rolls_back_before_terminal<S: AsyncChunkSource>(
    source: S,
) -> ExampleResult<()> {
    let mut app = build_async_function_streaming_app(source.clone()).await?;
    let halt_after = vec![common::STREAMING_RESPONSE.to_string()];
    assert_eq!(source.starts(), 0);

    let (_action, mut stream_result) = app
        .astream_result_with_options(
            rurr_core::ExecutionOptions::new()
                .with_inputs(common::prompt_inputs(source.prompt()))
                .halt_after(halt_after),
        )
        .await?;
    let _first = stream_result
        .next_item()
        .await?
        .ok_or_else(|| io::Error::other("first pre-terminal item should exist"))?;
    drop(stream_result);

    assert_eq!(app.state().get("response"), None);
    Ok(())
}
