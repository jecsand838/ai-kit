use super::{
    schema::{render_migration_sql, validate_table_name},
    PersistenceError, PostgresPersisterConfig, ASYNC_POOL_IDLE_TIMEOUT, ASYNC_POOL_MAX_CONNECTIONS,
    ASYNC_POOL_MAX_LIFETIME, ASYNC_POOL_MIN_CONNECTIONS, OP_CONNECTION_CLOSED,
    OP_POSTGRES_CONNECT_FAILED,
};
use postgres::{Client, Config as PgClientConfig, NoTls, Row};
use rurr_persistence::{
    closed_connection_error, is_closed_connection_error, InitializationHint, PersistedRowTuple,
    PersistedStateQueries,
};
use sqlx::postgres::{PgConnectOptions, PgPoolOptions};
use std::str::FromStr;

/// Lifecycle of the lazily opened synchronous PostgreSQL client.
pub enum SyncClientState {
    /// No connection has been opened yet.
    Unopened,
    /// A live connection is currently available.
    Open(Box<Client>),
    /// The connection was explicitly closed or became unusable.
    Closed,
}

/// Shared configuration, query plans, and initialization state for PostgreSQL
/// persisters.
pub struct PostgresShared {
    config: PostgresPersisterConfig,
    query_plan: PersistedStateQueries,
    migration_sql: String,
    // Positive-only initialization hint: missing-table results clear it so the
    // next operation re-probes, while explicit close remains terminal.
    initialized: InitializationHint,
}

impl PostgresShared {
    pub(crate) fn new(
        database_url: String,
        table_name: impl Into<String>,
    ) -> Result<Self, PersistenceError> {
        let table_name = table_name.into();
        validate_table_name(&table_name)?;

        Ok(Self {
            query_plan: PersistedStateQueries::postgres(&table_name),
            migration_sql: render_migration_sql(&table_name),
            config: PostgresPersisterConfig {
                database_url,
                table_name,
            },
            initialized: InitializationHint::new(),
        })
    }

    pub(crate) fn config(&self) -> PostgresPersisterConfig {
        self.config.clone()
    }

    pub(crate) fn database_url(&self) -> &str {
        self.config.database_url.as_str()
    }

    pub(crate) fn table_name(&self) -> &str {
        self.config.table_name.as_str()
    }

    pub(crate) fn query_plan(&self) -> &PersistedStateQueries {
        &self.query_plan
    }

    pub(crate) fn migration_sql(&self) -> &str {
        self.migration_sql.as_str()
    }

    pub(crate) fn initialization_hint(&self) -> &InitializationHint {
        &self.initialized
    }
}

/// Validates a synchronous PostgreSQL connection string without opening a
/// connection.
pub fn validate_sync_database_url(database_url: &str) -> Result<(), PersistenceError> {
    PgClientConfig::from_str(database_url)
        .map(|_| ())
        .map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_POSTGRES_CONNECT_FAILED,
        })
}

/// Validates an async PostgreSQL connection string and returns parsed connect
/// options.
pub fn validate_async_database_url(
    database_url: &str,
) -> Result<PgConnectOptions, PersistenceError> {
    PgConnectOptions::from_str(database_url).map_err(|_| PersistenceError::UnsupportedOperation {
        operation: OP_POSTGRES_CONNECT_FAILED,
    })
}

/// Returns the canonical async pool options used by the PostgreSQL backend.
pub fn default_async_pool_options() -> PgPoolOptions {
    PgPoolOptions::new()
        .max_connections(ASYNC_POOL_MAX_CONNECTIONS)
        .min_connections(ASYNC_POOL_MIN_CONNECTIONS)
        .idle_timeout(ASYNC_POOL_IDLE_TIMEOUT)
        .max_lifetime(ASYNC_POOL_MAX_LIFETIME)
}

/// Opens a synchronous PostgreSQL client using the validated connection string.
pub fn connect_sync_client(database_url: &str) -> Result<Client, PersistenceError> {
    PgClientConfig::from_str(database_url)
        .map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_POSTGRES_CONNECT_FAILED,
        })?
        .connect(NoTls)
        .map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_POSTGRES_CONNECT_FAILED,
        })
}

/// Returns the standardized error used when a PostgreSQL connection has already
/// been closed.
pub fn connection_closed_error() -> PersistenceError {
    closed_connection_error(OP_CONNECTION_CLOSED)
}

/// Returns `true` when a persistence error represents a closed connection.
pub fn is_connection_closed(error: &PersistenceError) -> bool {
    is_closed_connection_error(error, OP_CONNECTION_CLOSED)
}

/// Extracts a persisted-state row tuple from a synchronous PostgreSQL row.
pub fn row_tuple_from_postgres(row: Row) -> PersistedRowTuple {
    (
        row.get("partition_key"),
        row.get("app_id"),
        row.get("sequence_id"),
        row.get("position"),
        row.get("state"),
        row.get("created_at"),
        row.get("status"),
    )
}
