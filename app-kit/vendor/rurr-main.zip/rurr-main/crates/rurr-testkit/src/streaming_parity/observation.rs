use super::common::{prompt_inputs, response_text, ExampleResult, STREAMING_RESPONSE};
use super::sources::AsyncChunkSource;
use rurr_core::Application;
use serde_json::Value;
use std::io;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StreamingObservation {
    pub streamed_deltas: Vec<String>,
    pub terminal_response: String,
    pub final_state_response: String,
    pub starts_before_first_poll: usize,
    pub starts_after_first_poll: usize,
}

pub(super) async fn collect_async_observation(
    source: &impl AsyncChunkSource,
    mut app: Application,
) -> ExampleResult<StreamingObservation> {
    let halt_after = vec![STREAMING_RESPONSE.to_string()];
    let starts_before_first_poll = source.starts();
    let (_action, mut stream_result) = app
        .astream_result_with_options(
            rurr_core::ExecutionOptions::new()
                .with_inputs(prompt_inputs(source.prompt()))
                .halt_after(halt_after),
        )
        .await?;
    let first = stream_result
        .next_item()
        .await?
        .ok_or_else(|| io::Error::other("first delta should exist"))?;
    let starts_after_first_poll = source.starts();

    let mut streamed_deltas = vec![response_text(&first)?];
    while let Some(item) = stream_result.next_item().await? {
        streamed_deltas.push(response_text(&item)?);
    }

    let (terminal_item, final_state) = stream_result.get().await?;
    let terminal_item =
        terminal_item.ok_or_else(|| io::Error::other("terminal streaming item should exist"))?;
    let terminal_response = response_text(&terminal_item)?;
    let final_state_response = final_state
        .get("response")
        .and_then(Value::as_str)
        .map(ToOwned::to_owned)
        .ok_or_else(|| io::Error::other("final state should contain response"))?;

    Ok(StreamingObservation {
        streamed_deltas,
        terminal_response,
        final_state_response,
        starts_before_first_poll,
        starts_after_first_poll,
    })
}
