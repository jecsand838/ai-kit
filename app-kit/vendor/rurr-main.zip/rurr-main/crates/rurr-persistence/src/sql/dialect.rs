/// Marker trait for supported SQL dialects in the shared SQLx persistence layer.
pub trait SqlDialect: private::Sealed {
    /// SQLx database type associated with this dialect.
    type Database: sqlx::Database;

    /// SQL query used to test whether the persisted-state table exists.
    fn table_exists_sql() -> &'static str;
}

/// SQLite dialect marker.
#[derive(Debug, Clone, Copy, Default)]
pub struct SqliteDialect;

/// Postgres dialect marker.
#[derive(Debug, Clone, Copy, Default)]
pub struct PostgresDialect;

impl SqlDialect for SqliteDialect {
    type Database = sqlx::Sqlite;

    fn table_exists_sql() -> &'static str {
        "SELECT EXISTS (SELECT 1 FROM sqlite_master WHERE type='table' AND name=?)"
    }
}

impl SqlDialect for PostgresDialect {
    type Database = sqlx::Postgres;

    fn table_exists_sql() -> &'static str {
        "SELECT EXISTS (\
         SELECT FROM information_schema.tables \
         WHERE table_schema = current_schema() AND table_name = $1\
         )"
    }
}

mod private {
    pub trait Sealed {}

    impl Sealed for super::SqliteDialect {}
    impl Sealed for super::PostgresDialect {}
}

#[cfg(test)]
mod tests {
    use super::{PostgresDialect, SqlDialect, SqliteDialect};

    #[test]
    fn sqlite_table_exists_sql_targets_sqlite_master() {
        assert_eq!(
            SqliteDialect::table_exists_sql(),
            "SELECT EXISTS (SELECT 1 FROM sqlite_master WHERE type='table' AND name=?)"
        );
    }

    #[test]
    fn postgres_table_exists_sql_targets_current_schema() {
        assert!(PostgresDialect::table_exists_sql().contains("information_schema.tables"));
    }
}
