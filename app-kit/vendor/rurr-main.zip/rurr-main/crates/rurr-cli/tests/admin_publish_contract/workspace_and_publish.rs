use crate::admin_publish::{
    admin_publish_command, canonical_cli_target, workspace_metadata_summary, workspace_root,
};
use rurr_testkit::command_fixture::{assert_success, run_command};
use std::env;
use std::ffi::OsString;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};

fn real_cargo_binary() -> OsString {
    env::var_os("CARGO").unwrap_or_else(|| OsString::from("cargo"))
}

fn cargo_wrapper_log_lines(path: &Path) -> io::Result<Vec<String>> {
    Ok(fs::read_to_string(path)?
        .lines()
        .map(str::to_string)
        .collect())
}

#[cfg(unix)]
fn cargo_wrapper_path(root: &Path) -> PathBuf {
    root.join("cargo-wrapper")
}

#[cfg(windows)]
fn cargo_wrapper_path(root: &Path) -> PathBuf {
    root.join("cargo-wrapper.cmd")
}

#[cfg(unix)]
fn install_cargo_wrapper(wrapper_path: &Path) -> io::Result<()> {
    use std::os::unix::fs::PermissionsExt;

    fs::write(
        wrapper_path,
        "#!/usr/bin/env bash\nset -euo pipefail\nprintf '%s\\n' \"$*\" >> \"$RURR_TEST_CARGO_LOG\"\nexec \"$RURR_TEST_REAL_CARGO\" \"$@\"\n",
    )?;
    let mut permissions = fs::metadata(wrapper_path)?.permissions();
    permissions.set_mode(0o755);
    fs::set_permissions(wrapper_path, permissions)
}

#[cfg(windows)]
fn install_cargo_wrapper(wrapper_path: &Path) -> io::Result<()> {
    fs::write(
        wrapper_path,
        "@echo off\r\nsetlocal\r\n>> \"%RURR_TEST_CARGO_LOG%\" echo %*\r\n\"%RURR_TEST_REAL_CARGO%\" %*\r\nexit /b %ERRORLEVEL%\r\n",
    )
}

#[test]
fn publishable_workspace_crates_do_not_depend_on_private_workspace_members() {
    let metadata = workspace_metadata_summary();
    let workspace_members = metadata
        .workspace_members
        .into_iter()
        .collect::<std::collections::BTreeSet<_>>();
    let private_members = metadata
        .packages
        .iter()
        .filter(|package| workspace_members.contains(&package.id))
        .filter(|package| {
            package
                .publish
                .as_ref()
                .is_some_and(|publish| publish.is_empty())
        })
        .map(|package| package.name.as_str())
        .collect::<std::collections::BTreeSet<_>>();

    let offenders = metadata
        .packages
        .iter()
        .filter(|package| workspace_members.contains(&package.id))
        .filter(|package| {
            !package
                .publish
                .as_ref()
                .is_some_and(|publish| publish.is_empty())
        })
        .filter_map(|package| {
            let private_deps = package
                .dependencies
                .iter()
                .filter(|dependency| dependency.kind.is_none())
                .filter(|dependency| private_members.contains(dependency.name.as_str()))
                .map(|dependency| dependency.name.as_str())
                .collect::<Vec<_>>();
            if private_deps.is_empty() {
                None
            } else {
                Some((package.name.as_str(), private_deps))
            }
        })
        .collect::<Vec<_>>();

    assert!(
        offenders.is_empty(),
        "publishable workspace crates must not depend on private workspace members: {offenders:?}"
    );
}

#[test]
fn workspace_metadata_uses_renamed_tracking_packages() {
    let metadata = workspace_metadata_summary();
    let package_names = metadata
        .packages
        .into_iter()
        .map(|package| package.name)
        .collect::<std::collections::BTreeSet<_>>();

    assert!(
        package_names.contains("rurr-tracking-server"),
        "expected workspace package rurr-tracking-server, got: {package_names:?}"
    );
    assert!(
        package_names.contains("rurr-tracking-store"),
        "expected workspace package rurr-tracking-store, got: {package_names:?}"
    );
}

#[test]
fn admin_publish_succeeds_end_to_end_with_real_cargo_package() {
    let scratch = tempfile::tempdir().expect("scratch dir should be created");
    let dist_dir = scratch.path().join("dist-root");
    let nested_cwd = workspace_root().join("crates").join("rurr-cli").join("src");

    let mut command = admin_publish_command(&nested_cwd, &canonical_cli_target(&dist_dir));
    let output = run_command(&mut command, "admin publish should run");
    assert_success(&output, "admin publish should succeed end-to-end");

    let ui_root = dist_dir.join("rurr-ui");
    assert!(
        ui_root.join("index.html").exists(),
        "admin publish should export UI"
    );
    assert!(
        ui_root.join("assets").join("app.js").exists(),
        "admin publish should export UI assets"
    );
}

#[test]
fn admin_publish_honors_cargo_env_for_metadata_and_package() {
    let scratch = tempfile::tempdir().expect("scratch dir should be created");
    let dist_dir = scratch.path().join("dist-root");
    let wrapper_path = cargo_wrapper_path(scratch.path());
    let wrapper_log = scratch.path().join("cargo-wrapper.log");
    let real_cargo = real_cargo_binary();
    let nested_cwd = workspace_root().join("crates").join("rurr-cli").join("src");

    install_cargo_wrapper(&wrapper_path).expect("cargo wrapper should be installed");

    let mut command = admin_publish_command(&nested_cwd, &canonical_cli_target(&dist_dir));
    command
        .env("CARGO", &wrapper_path)
        .env("RURR_TEST_REAL_CARGO", &real_cargo)
        .env("RURR_TEST_CARGO_LOG", &wrapper_log);
    let output = run_command(&mut command, "admin publish should run");
    assert_success(&output, "admin publish should succeed with a cargo wrapper");

    let invocations =
        cargo_wrapper_log_lines(&wrapper_log).expect("cargo wrapper log should be readable");
    assert!(
        invocations
            .iter()
            .any(|line| line == "metadata --format-version 1 --no-deps"),
        "expected cargo metadata to run through the wrapper, got: {invocations:?}"
    );
    assert!(
        invocations.iter().any(|line| line.starts_with("package ")),
        "expected cargo package to run through the wrapper, got: {invocations:?}"
    );
}
