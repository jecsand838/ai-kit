---
name: refresh-workspace-agentic-documentation
description: "Use when the user wants a workspace-wide refresh of README.md, AGENTS.md, ARCHITECTURE.md, AGENTS.override.md, or other Markdown docs so they match the current implementation and the current branch diff versus main, including plan-mode planning, full Markdown inventory, archive-pointer corrections, manifest refresh, and verification. Do not use for one-off README edits, single archive-pointer fixes, or standalone .agents/skills catalog maintenance."
---

# Refresh Workspace Agentic Documentation

Use this skill when the task is to plan and execute a repo-wide Markdown documentation refresh for the current workspace state.

## Quick start

Load, in order:

- `AGENTS.md`
- `README.md`
- `ARCHITECTURE.md`
- `docs/00_overview.md`
- `docs/05_documentation_inventory.md`
- `references/agentic-doc-standards.md`
- `references/rurr-doc-refresh-checklist.md`

Compare the current branch against `main` before planning edits.

If `.agents/skills/` is in scope, also load `$rurr-skill-catalog-maintenance`.

## Planning phase

In Plan Mode, produce a decision-complete `<proposed_plan>` first and use the Implementation phase only after the operator enables execution.

1. Inventory every tracked Markdown file that could carry current-state claims.
2. Compare the current branch against `main` and identify implementation changes the docs must reflect.
3. Separate document audiences before proposing edits:
   - `README.md` for humans and quick orientation
   - `AGENTS.md` and `AGENTS.override.md` for agent and operator workflow
   - `ARCHITECTURE.md` for the living system map, boundaries, and data flow
   - other Markdown for detailed living docs, compatibility contracts, or historical records
4. Classify each reviewed Markdown file as `living current-state rewrite`, `archive/pointer correction`, or `verified no-change`.
5. Call out stale terms, deleted concepts, or drifted navigation that must be removed or corrected.
6. When proof policy, live-proof expectations, or anti-shim guidance changed, ensure the plan updates `docs/ARCHITECTURE_GUARDRAILS.md`, `docs/03_test_plan.md`, the `AGENTS*.md` chain, and the relevant repo-local skills together.
7. Define the verification sequence before editing so manifest refresh, doc-map updates, and repo gates are explicit.
8. Produce a decision-complete `<proposed_plan>` that groups work by doc surface or behavior, not by file dump.

## Implementation phase

1. Reload the approved plan and the nearest `AGENTS*.md` instructions before editing.
2. Update living docs first so `README.md`, `ARCHITECTURE.md`, `docs/`, and other active Markdown reflect the current branch state.
3. Correct archive banners, stale navigation, and false present-tense claims without rewriting historical records.
4. Update doc maps and inventories when the doc set changes, including `.agents/skills/README.md` and `docs/05_documentation_inventory.md` when skill docs move.
5. When proof policy changed, propagate it across `docs/ARCHITECTURE_GUARDRAILS.md`, `docs/03_test_plan.md`, the `AGENTS*.md` chain, and any touched repo-local skills in the same pass.
6. Edit `AGENTS*.md` last so the instruction chain changes only after the rest of the refresh is stable.
7. Restart Codex before further edits if any `AGENTS*.md` file changed.
8. Refresh generated Markdown only through `./scripts/fix_manifest_freshness.sh`.
9. Run the smallest matching repo gates and finish with `./scripts/check.sh` unless the task is explicitly docs-only and narrower verification was requested.
10. Report changed doc surfaces, major terminology corrections, verification results, and any follow-up risk.

## Default rules

- Keep `README.md` human-facing, `AGENTS*.md` workflow-facing, and `ARCHITECTURE.md` system-facing.
- Prefer links to the living source-of-truth docs over duplicated prose.
- When anti-shim or proof-policy guidance changes, keep the root docs, overrides, and repo-local
  skills aligned in the same refresh.
- Preserve historical refactor records while fixing misleading current-state claims.
- Use local repo sources first; only consult external standards when they materially change the refresh.
- Treat manifest artifacts as generated outputs; do not hand edit them.

## Do not use this skill for

- single-file or one-paragraph README touchups
- isolated archive banner, pointer, or navigation fixes
- standalone `.agents/skills` catalog edits that do not drive a workspace-wide Markdown refresh

## Do not use this skill alone when

- the task also adds or edits repo-local skills under `.agents/skills/` -> also use `$rurr-skill-catalog-maintenance`
- the task is mainly a compatibility or parity guardrail rewrite -> also load the relevant subsystem guardrail skill
- the task is only final gate selection or handoff after docs already landed -> also use `$rurr-gate-closeout`
