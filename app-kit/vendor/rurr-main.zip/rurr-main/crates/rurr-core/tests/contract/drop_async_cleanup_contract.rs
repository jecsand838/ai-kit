use std::fs;
use std::path::PathBuf;

const FORBIDDEN_DROP_PATTERNS: [&str; 8] = [
    "block_in_place",
    "block_on(",
    "RuntimeFlavor",
    "runtime_flavor",
    "tokio::runtime::Builder",
    "new_current_thread",
    "Runtime::new",
    "Handle::current",
];

fn is_identifier_char(byte: u8) -> bool {
    byte.is_ascii_alphanumeric() || byte == b'_'
}

fn find_next_impl_keyword(source: &str, start: usize) -> Option<usize> {
    let bytes = source.as_bytes();
    let mut cursor = start;

    while let Some(relative_impl_start) = source[cursor..].find("impl") {
        let impl_start = cursor + relative_impl_start;
        let before_ok = impl_start == 0 || !is_identifier_char(bytes[impl_start - 1]);
        let after_index = impl_start + "impl".len();
        let after_ok = after_index >= bytes.len() || !is_identifier_char(bytes[after_index]);

        if before_ok && after_ok {
            return Some(impl_start);
        }

        cursor = impl_start + "impl".len();
    }

    None
}

fn header_contains_drop_for(header: &str) -> bool {
    let normalized_tokens: Vec<String> = header
        .split_whitespace()
        .map(|token| {
            token
                .trim_matches(|character: char| !character.is_ascii_alphanumeric())
                .to_string()
        })
        .filter(|token| !token.is_empty())
        .collect();

    normalized_tokens
        .windows(2)
        .any(|window| window[0] == "Drop" && window[1] == "for")
}

fn matching_brace_index(source: &str, open_brace_index: usize) -> Option<usize> {
    let bytes = source.as_bytes();
    let mut depth = 0usize;
    for (index, byte) in bytes.iter().enumerate().skip(open_brace_index) {
        match *byte {
            b'{' => depth += 1,
            b'}' => {
                depth = depth.saturating_sub(1);
                if depth == 0 {
                    return Some(index);
                }
            }
            _ => {}
        }
    }
    None
}

fn extract_impl_drop_blocks(source: &str) -> Vec<String> {
    let mut blocks = Vec::new();
    let mut cursor = 0usize;

    while let Some(impl_start) = find_next_impl_keyword(source, cursor) {
        let Some(relative_open_brace) = source[impl_start..].find('{') else {
            cursor = impl_start + "impl".len();
            continue;
        };
        let open_brace_index = impl_start + relative_open_brace;
        let Some(close_brace_index) = matching_brace_index(source, open_brace_index) else {
            cursor = open_brace_index + 1;
            continue;
        };
        let impl_header = &source[impl_start..open_brace_index];
        if header_contains_drop_for(impl_header) {
            blocks.push(source[impl_start..=close_brace_index].to_string());
        }
        cursor = close_brace_index + 1;
    }

    blocks
}

fn extract_drop_fn_bodies(source: &str) -> Vec<String> {
    let mut bodies = Vec::new();

    for impl_block in extract_impl_drop_blocks(source) {
        let mut cursor = 0usize;
        while let Some(relative_drop_start) = impl_block[cursor..].find("fn drop(") {
            let drop_start = cursor + relative_drop_start;
            let relative_open_brace = impl_block[drop_start..]
                .find('{')
                .expect("drop function should contain an opening brace");
            let open_brace_index = drop_start + relative_open_brace;
            let close_brace_index = matching_brace_index(&impl_block, open_brace_index)
                .expect("drop function should contain a matching closing brace");
            bodies.push(impl_block[open_brace_index + 1..close_brace_index].to_string());
            cursor = close_brace_index + 1;
        }
    }

    bodies
}

#[test]
fn extract_impl_drop_blocks_includes_non_generic_drop_impl() {
    let source = r#"
impl Drop for NonGeneric {
    fn drop(&mut self) {}
}
"#;

    let drop_impl_blocks = extract_impl_drop_blocks(source);
    assert_eq!(drop_impl_blocks.len(), 1);
}

#[test]
fn extract_impl_drop_blocks_ignores_non_drop_impls() {
    let source = r#"
impl SomethingElse for NonDropType {
    fn run(&self) {}
}
"#;

    let drop_impl_blocks = extract_impl_drop_blocks(source);
    assert!(drop_impl_blocks.is_empty());
}

#[test]
fn extract_impl_drop_blocks_handles_multiple_impl_blocks_in_order() {
    let source = r#"
impl SomethingElse for NonDropType {
    fn run(&self) {}
}

impl Drop for First {
    fn drop(&mut self) {}
}

impl<'a, I> Drop for Second<'a, I>
where
    I: Iterator<Item = u8>,
{
    fn drop(&mut self) {}
}
"#;

    let drop_impl_blocks = extract_impl_drop_blocks(source);
    assert_eq!(drop_impl_blocks.len(), 2);
    assert!(drop_impl_blocks[0].contains("Drop for First"));
    assert!(drop_impl_blocks[1].contains("Drop for Second"));
}

#[test]
fn drop_bodies_do_not_contain_forbidden_async_cleanup_patterns() {
    let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let source_files = [
        manifest_dir.join("src/lifecycle/guard.rs"),
        manifest_dir.join("src/action/streaming.rs"),
    ];

    for source_file in source_files {
        let source =
            fs::read_to_string(&source_file).expect("drop-bearing source file should be readable");
        let drop_bodies = extract_drop_fn_bodies(&source);
        assert!(
            !drop_bodies.is_empty(),
            "expected at least one drop function body in {}",
            source_file.display()
        );

        for drop_body in drop_bodies {
            for pattern in FORBIDDEN_DROP_PATTERNS {
                assert!(
                    !drop_body.contains(pattern),
                    "forbidden drop async cleanup pattern `{pattern}` found in {} drop body",
                    source_file.display()
                );
            }
        }
    }
}

#[test]
fn extract_impl_drop_blocks_includes_generic_drop_impl() {
    let source = r#"
impl<'a, I> Drop for Wrapper<'a, I>
where
    I: Iterator<Item = u8>,
{
    fn drop(&mut self) {}
}
"#;

    let drop_impl_blocks = extract_impl_drop_blocks(source);
    assert_eq!(drop_impl_blocks.len(), 1);
    assert!(
        drop_impl_blocks[0].contains("Drop for Wrapper"),
        "expected extracted impl block to be a Drop implementation"
    );
}

#[test]
fn extract_drop_fn_bodies_includes_generic_drop_drop_body() {
    let source = r#"
impl<'a, I> Drop for Wrapper<'a, I>
where
    I: Iterator<Item = u8>,
{
    fn drop(&mut self) {
        let _token = "new_current_thread";
    }
}
"#;

    let drop_bodies = extract_drop_fn_bodies(source);
    assert_eq!(drop_bodies.len(), 1);
    assert!(
        drop_bodies[0].contains("new_current_thread"),
        "expected to extract generic Drop body content"
    );
}
