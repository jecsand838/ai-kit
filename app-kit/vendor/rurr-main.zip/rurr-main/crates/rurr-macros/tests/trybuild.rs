use std::ffi::OsString;
use std::sync::Mutex;

#[cfg(any())]
mod ide_only;

static TRYBUILD_LOCK: Mutex<()> = Mutex::new(());

struct CargoBuildJobsGuard {
    previous: Option<OsString>,
}

impl CargoBuildJobsGuard {
    fn set_to_one() -> Self {
        let previous = std::env::var_os("CARGO_BUILD_JOBS");
        std::env::set_var("CARGO_BUILD_JOBS", "1");
        Self { previous }
    }
}

impl Drop for CargoBuildJobsGuard {
    fn drop(&mut self) {
        match &self.previous {
            Some(value) => std::env::set_var("CARGO_BUILD_JOBS", value),
            None => std::env::remove_var("CARGO_BUILD_JOBS"),
        }
    }
}

fn run_trybuild(test: impl FnOnce(&trybuild::TestCases)) {
    let _lock = TRYBUILD_LOCK
        .lock()
        .expect("trybuild lock should not be poisoned");
    let _jobs_guard = CargoBuildJobsGuard::set_to_one();
    let test_cases = trybuild::TestCases::new();
    test(&test_cases);
}

#[test]
fn pass_action_with_context() {
    run_trybuild(|t| t.pass("tests/ui/pass_action_with_context.rs"));
}

#[test]
fn pass_action_with_tracer() {
    run_trybuild(|t| t.pass("tests/ui/pass_action_with_tracer.rs"));
}

#[test]
fn pass_action_with_typed_inputs() {
    run_trybuild(|t| t.pass("tests/ui/pass_action_with_typed_inputs.rs"));
}

#[test]
fn pass_action_with_user_input_named_state() {
    run_trybuild(|t| t.pass("tests/ui/pass_action_with_user_input_named_state.rs"));
}

#[test]
fn pass_action_send_accepts_non_sync_future() {
    run_trybuild(|t| t.pass("tests/ui/pass_action_send_accepts_non_sync_future.rs"));
}

#[test]
fn pass_async_action() {
    run_trybuild(|t| t.pass("tests/ui/pass_async_action.rs"));
}

#[test]
fn pass_streaming_async() {
    run_trybuild(|t| t.pass("tests/ui/pass_streaming_async.rs"));
}

#[test]
fn pass_streaming_sync() {
    run_trybuild(|t| t.pass("tests/ui/pass_streaming_sync.rs"));
}

#[test]
fn pass_sync_action() {
    run_trybuild(|t| t.pass("tests/ui/pass_sync_action.rs"));
}

#[test]
fn ui_fail() {
    run_trybuild(|t| t.compile_fail("tests/ui/fail_*.rs"));
}
