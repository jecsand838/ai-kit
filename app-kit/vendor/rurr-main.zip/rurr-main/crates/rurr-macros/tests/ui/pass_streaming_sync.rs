use indexmap::IndexMap;
use rurr_core::action::{LocalAction, ActionContext, ActionTracer, StreamOutput};
use rurr_core::state::State;
use serde_json::json;

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
fn streaming_counter(state: &State) -> Box<dyn Iterator<Item = StreamOutput>> {
    let next = state
        .get("count")
        .and_then(serde_json::Value::as_i64)
        .unwrap_or(0)
        + 1;
    let item = IndexMap::from([("count".to_string(), json!(next))]);
    let final_state = state
        .update(IndexMap::from([("count".to_string(), json!(next))]))
        .expect("streaming action state update should succeed");
    let outputs = vec![Ok((item, Some(final_state)))];
    Box::new(outputs.into_iter())
}

fn assert_streaming_bounds<T: LocalAction + Send + Sync>(action: &T) {
    let _ = action;
}

fn main() {
    let action = streaming_counter_action().expect("macro-generated action should build");
    assert_streaming_bounds(&action);
    let state = State::new(IndexMap::new());
    let _ = action.stream_run(
        state,
        ActionContext::new(IndexMap::new(), ActionTracer::default(), None),
    );
}
