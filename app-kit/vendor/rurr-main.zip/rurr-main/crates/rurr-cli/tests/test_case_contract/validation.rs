use super::*;

#[test]
fn test_case_create_rejects_metadata_missing_type_field() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            serde_json::json!({"count": 0}),
            serde_json::json!({"count": 1}),
        ],
    );
    fs::write(
        storage_dir
            .path()
            .join("demo_counter")
            .join("counter-app-0001")
            .join("metadata.json"),
        r#"{"partition_key":null,"parent_pointer":null,"spawning_parent_pointer":null}"#,
    )
    .expect("invalid metadata should be written");

    let output = run_test_case_create(&[
        std::ffi::OsStr::new("--storage-dir"),
        storage_dir.path().as_os_str(),
        std::ffi::OsStr::new("--project-name"),
        std::ffi::OsStr::new("demo_counter"),
        std::ffi::OsStr::new("--app-id"),
        std::ffi::OsStr::new("counter-app-0001"),
        std::ffi::OsStr::new("--sequence-id"),
        std::ffi::OsStr::new("1"),
    ]);
    assert_failure(
        &output,
        "schema-invalid metadata should fail test-case create",
    );
}

#[test]
fn test_case_create_rejects_app_directory_without_metadata() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            serde_json::json!({"count": 0}),
            serde_json::json!({"count": 1}),
        ],
    );
    fs::remove_file(
        storage_dir
            .path()
            .join("demo_counter")
            .join("counter-app-0001")
            .join("metadata.json"),
    )
    .expect("metadata should be removed");

    let mut command = test_case_create_command();
    command
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--project-name")
        .arg("demo_counter")
        .arg("--app-id")
        .arg("counter-app-0001")
        .arg("--sequence-id")
        .arg("1");
    let output = run_command(&mut command, "test-case create should run");
    assert_test_case_failure_contains(
        &output,
        "missing metadata should fail test-case create",
        "metadata.json",
    );
}

#[cfg(unix)]
#[test]
fn test_case_create_rejects_symlink_escape_outside_storage_root() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let outside_root = tempfile::tempdir().expect("outside root should be created");
    let project_dir = storage_dir.path().join("demo_counter");
    let escaped_app_dir = outside_root.path().join("counter-app-0001");

    fs::create_dir_all(&project_dir).expect("project dir should be created");
    fs::create_dir_all(&escaped_app_dir).expect("escaped app dir should be created");
    fs::write(
        escaped_app_dir.join("metadata.json"),
        r#"{"partition_key":null}"#,
    )
    .expect("metadata should be written");
    fs::write(
        escaped_app_dir.join("log.jsonl"),
        r#"{"type":"end_entry","action":"counter","state":{"count":1},"sequence_id":1,"exception":null}"#,
    )
    .expect("log should be written");
    symlink(&escaped_app_dir, project_dir.join("counter-app-0001"))
        .expect("app symlink should be created");

    let mut command = test_case_create_command();
    command
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--project-name")
        .arg("demo_counter")
        .arg("--app-id")
        .arg("counter-app-0001")
        .arg("--sequence-id")
        .arg("1");
    let output = run_command(&mut command, "test-case create should run");
    assert_test_case_failure_contains(
        &output,
        "test-case create should reject symlink escapes",
        "resolves outside the configured",
    );
}

#[test]
fn test_case_create_fails_for_undecodable_serialized_state() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let app_dir = storage_dir
        .path()
        .join("demo_counter")
        .join("counter-app-0001");
    fs::create_dir_all(&app_dir).expect("app dir should be created");
    fs::write(
        app_dir.join("metadata.json"),
        r#"{"type":"application_metadata","partition_key":null,"parent_pointer":null,"spawning_parent_pointer":null}"#,
    )
    .expect("metadata should be written");
    fs::write(
        app_dir.join("log.jsonl"),
        serde_json::json!({
            "type": "end_entry",
            "end_time": "2026-03-20T00:00:00.000000000Z",
            "action": "counter",
            "result": {"count": 1},
            "exception": serde_json::Value::Null,
            "state": {
                "payload": {
                    "__burr_serde__": "missing_decode_handler",
                    "value": "serialized"
                }
            },
            "sequence_id": 1,
        })
        .to_string(),
    )
    .expect("log should be written");

    let mut command = test_case_create_command();
    command
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--project-name")
        .arg("demo_counter")
        .arg("--app-id")
        .arg("counter-app-0001")
        .arg("--sequence-id")
        .arg("1");
    let output = run_command(&mut command, "test-case create should run");
    assert_test_case_failure_contains(
        &output,
        "test-case create should fail for undecodable serialized state",
        "missing_decode_handler",
    );
}
