use super::evaluate_expr;
use crate::value::{coerce_index, EvalValue};
use crate::{ExprError, StateView};
use rustpython_parser::ast;

#[derive(Debug, Clone, Copy)]
struct NormalizedSlice {
    start: i128,
    stop: i128,
    step: i128,
}

pub(super) fn evaluate_slice_subscript<S: StateView>(
    container: EvalValue,
    slice: &ast::ExprSlice,
    state: &S,
) -> Result<EvalValue, ExprError> {
    match container {
        EvalValue::Array(items) => {
            let bounds = normalize_slice_bounds(items.len(), slice, state)?;
            let mut sliced = Vec::new();
            for_each_slice_index(bounds, |index| {
                sliced.push(items[index].clone());
                Ok(())
            })?;
            Ok(EvalValue::Array(sliced))
        }
        EvalValue::String(text) => {
            let chars = text.chars().collect::<Vec<_>>();
            let bounds = normalize_slice_bounds(chars.len(), slice, state)?;
            let mut sliced = String::new();
            for_each_slice_index(bounds, |index| {
                sliced.push(chars[index]);
                Ok(())
            })?;
            Ok(EvalValue::String(sliced))
        }
        other => Err(ExprError::InvalidSubscript {
            message: format!("cannot slice value {other:?}"),
        }),
    }
}

fn normalize_slice_bounds<S: StateView>(
    len: usize,
    slice: &ast::ExprSlice,
    state: &S,
) -> Result<NormalizedSlice, ExprError> {
    let len_i128 = i128::try_from(len).map_err(|_| ExprError::IntegerOverflow)?;
    let step = match &slice.step {
        Some(step_expr) => coerce_index(&evaluate_expr(step_expr, state)?)?,
        None => 1,
    };
    if step == 0 {
        return Err(ExprError::InvalidSubscript {
            message: "slice step cannot be zero".to_string(),
        });
    }

    let lower = match &slice.lower {
        Some(expr) => Some(coerce_index(&evaluate_expr(expr, state)?)?),
        None => None,
    };
    let upper = match &slice.upper {
        Some(expr) => Some(coerce_index(&evaluate_expr(expr, state)?)?),
        None => None,
    };

    if step > 0 {
        let mut start = lower.unwrap_or(0);
        if start < 0 {
            start = start
                .checked_add(len_i128)
                .ok_or(ExprError::IntegerOverflow)?;
        }
        start = start.clamp(0, len_i128);

        let mut stop = upper.unwrap_or(len_i128);
        if stop < 0 {
            stop = stop
                .checked_add(len_i128)
                .ok_or(ExprError::IntegerOverflow)?;
        }
        stop = stop.clamp(0, len_i128);
        Ok(NormalizedSlice { start, stop, step })
    } else {
        let max_index = len_i128.checked_sub(1).unwrap_or(-1);

        let mut start = match lower {
            Some(mut start) => {
                if start < 0 {
                    start = start
                        .checked_add(len_i128)
                        .ok_or(ExprError::IntegerOverflow)?;
                }
                start
            }
            None => max_index,
        };
        start = start.clamp(-1, max_index);

        let mut stop = match upper {
            Some(mut stop) => {
                if stop < 0 {
                    stop = stop
                        .checked_add(len_i128)
                        .ok_or(ExprError::IntegerOverflow)?;
                }
                stop
            }
            None => -1,
        };
        stop = stop.clamp(-1, max_index);
        Ok(NormalizedSlice { start, stop, step })
    }
}

fn for_each_slice_index<F>(bounds: NormalizedSlice, mut visit: F) -> Result<(), ExprError>
where
    F: FnMut(usize) -> Result<(), ExprError>,
{
    let mut index = bounds.start;
    if bounds.step > 0 {
        while index < bounds.stop {
            visit(usize::try_from(index).map_err(|_| ExprError::IntegerOverflow)?)?;
            index = index
                .checked_add(bounds.step)
                .ok_or(ExprError::IntegerOverflow)?;
        }
    } else {
        while index > bounds.stop {
            visit(usize::try_from(index).map_err(|_| ExprError::IntegerOverflow)?)?;
            index = index
                .checked_add(bounds.step)
                .ok_or(ExprError::IntegerOverflow)?;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::evaluate_slice_subscript;
    use crate::parse::parse;
    use crate::value::EvalValue;
    use crate::{ExprError, StateView};
    use rustpython_parser::ast;
    use serde_json::Value;
    use std::collections::HashMap;

    struct TestState {
        values: HashMap<String, Value>,
    }

    impl StateView for TestState {
        fn get_value(&self, key: &str) -> Option<&Value> {
            self.values.get(key)
        }
    }

    fn parse_slice(expression: &str) -> ast::ExprSlice {
        let ast = parse(expression).expect("slice expression should parse");
        let ast::Expr::Subscript(node) = ast.expr else {
            panic!("expected subscript expression");
        };
        let ast::Expr::Slice(slice) = node.slice.as_ref() else {
            panic!("expected slice expression");
        };
        slice.clone()
    }

    #[test]
    fn slice_rejects_zero_step() {
        let error = evaluate_slice_subscript(
            EvalValue::Array(vec![EvalValue::Int(1), EvalValue::Int(2)]),
            &parse_slice("items[::0]"),
            &TestState {
                values: HashMap::new(),
            },
        )
        .expect_err("zero step should fail");

        assert_eq!(
            error,
            ExprError::InvalidSubscript {
                message: "slice step cannot be zero".to_string(),
            }
        );
    }

    #[test]
    fn slice_rejects_unsupported_container_types() {
        let error = evaluate_slice_subscript(
            EvalValue::Int(5),
            &parse_slice("items[:]"),
            &TestState {
                values: HashMap::new(),
            },
        )
        .expect_err("non-sliceable containers should fail");

        assert_eq!(
            error,
            ExprError::InvalidSubscript {
                message: "cannot slice value Int(5)".to_string(),
            }
        );
    }
}
