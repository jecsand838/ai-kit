mod workspace_snapshot;

use rurr_testkit::command_fixture::{assert_success, stderr_lossy, stdout_lossy};
use std::fs;
use std::path::Path;
use std::process::{Command, Output};
use workspace_snapshot::{copy_tracked_workspace, tempdir_in_workspace, workspace_root};

fn tempdir(prefix: &str) -> tempfile::TempDir {
    tempfile::Builder::new()
        .prefix(prefix)
        .tempdir()
        .expect("tempdir should be created")
}

fn run(command: &mut Command, context: &str) -> Output {
    command
        .output()
        .unwrap_or_else(|error| panic!("{context}: {error}"))
}

fn run_and_assert_success(command: &mut Command, context: &str) -> Output {
    let output = run(command, context);
    assert_success(&output, context);
    output
}

fn git_command(repo_root: &Path, args: &[&str]) -> Output {
    let mut command = Command::new("git");
    command.current_dir(repo_root).args(args);
    run_and_assert_success(&mut command, &format!("git {:?} should succeed", args))
}

fn initialize_snapshot_repo(snapshot_root: &Path, tag: &str) {
    git_command(snapshot_root, &["init", "-q", "-b", "main"]);
    git_command(
        snapshot_root,
        &["config", "user.name", "Rurr Contract Tests"],
    );
    git_command(
        snapshot_root,
        &[
            "config",
            "user.email",
            "rurr-contract-tests@example.invalid",
        ],
    );
    git_command(snapshot_root, &["add", "."]);
    git_command(snapshot_root, &["commit", "-qm", "snapshot"]);
    git_command(snapshot_root, &["tag", "-a", tag, "-m", tag]);
}

fn write_consumer_project(project_root: &Path, repo_url: &str, tag: &str) {
    fs::create_dir_all(project_root.join("src")).expect("consumer src directory should exist");
    fs::write(
        project_root.join("Cargo.toml"),
        format!(
            r#"[package]
name = "private_git_workspace_consumer"
version = "0.1.0"
edition = "2021"

[dependencies]
rurr = {{ git = "{repo_url}", tag = "{tag}" }}
rurr_core_alias = {{ git = "{repo_url}", package = "rurr-core", tag = "{tag}" }}
"#
        ),
    )
    .expect("consumer Cargo.toml should be written");
    fs::write(
        project_root.join("src").join("lib.rs"),
        r#"pub fn touch_public_rurr_builders() {
    let _ = rurr::ApplicationBuilder::new();
    let _ = rurr_core_alias::ApplicationBuilder::new();
}
"#,
    )
    .expect("consumer lib.rs should be written");
}

fn cargo_command(project_root: &Path, target_dir: &Path, args: &[&str]) -> Command {
    let mut command = Command::new("cargo");
    command.current_dir(project_root).args(args);
    command
        .env("CARGO_NET_GIT_FETCH_WITH_CLI", "true")
        .env("CARGO_TARGET_DIR", target_dir);
    command
}

#[cfg(windows)]
fn windows_git_dependency_url(path: &Path) -> String {
    let raw = path.to_string_lossy();
    if let Some(unc_suffix) = raw.strip_prefix(r"\\?\UNC\") {
        return format!("file://{}", unc_suffix.replace('\\', "/"));
    }

    let normalized = raw.strip_prefix(r"\\?\").unwrap_or(&raw).replace('\\', "/");
    if let Some(unc_suffix) = normalized.strip_prefix("//") {
        return format!("file://{unc_suffix}");
    }
    if normalized.as_bytes().get(1) == Some(&b':') {
        return format!("file:///{normalized}");
    }
    if normalized.starts_with('/') {
        return format!("file://{normalized}");
    }

    format!("file:///{normalized}")
}

fn git_dependency_url(repo_root: &Path) -> String {
    let canonical_root = repo_root
        .canonicalize()
        .expect("snapshot repo root should canonicalize");
    #[cfg(windows)]
    {
        windows_git_dependency_url(&canonical_root)
    }
    #[cfg(not(windows))]
    {
        format!("file://{}", canonical_root.display())
    }
}

#[test]
fn downstream_consumer_builds_from_tagged_workspace_git_dependency() {
    let workspace_root = workspace_root();
    let snapshot_dir = tempdir_in_workspace("private-git-workspace-source-");
    let consumer_dir = tempdir("private-git-workspace-consumer-");
    let target_dir = tempdir("private-git-workspace-target-");
    let tag = format!("v{}", env!("CARGO_PKG_VERSION"));

    copy_tracked_workspace(&workspace_root, snapshot_dir.path());
    initialize_snapshot_repo(snapshot_dir.path(), &tag);

    let repo_url = git_dependency_url(snapshot_dir.path());
    write_consumer_project(consumer_dir.path(), &repo_url, &tag);

    let mut lock_command = cargo_command(
        consumer_dir.path(),
        target_dir.path(),
        &["generate-lockfile"],
    );
    let lock_output = run_and_assert_success(
        &mut lock_command,
        "cargo generate-lockfile should succeed for the downstream consumer",
    );
    let _ = lock_output;

    let cargo_lock = fs::read_to_string(consumer_dir.path().join("Cargo.lock"))
        .expect("consumer Cargo.lock should be readable");
    assert!(
        cargo_lock.contains("git+file://"),
        "Cargo.lock should record the git dependency source, got:\n{cargo_lock}"
    );

    let mut check_command = cargo_command(
        consumer_dir.path(),
        target_dir.path(),
        &["check", "-q", "--locked"],
    );
    let check_output = run(
        &mut check_command,
        "cargo check should run for the downstream consumer",
    );
    assert!(
        check_output.status.success(),
        "downstream git consumer should compile: stdout={} stderr={}",
        stdout_lossy(&check_output),
        stderr_lossy(&check_output)
    );
}

#[cfg(windows)]
#[test]
fn windows_git_dependency_url_strips_verbatim_drive_prefix() {
    assert_eq!(
        windows_git_dependency_url(Path::new(r"\\?\D:\a\rurr\workspace")),
        "file:///D:/a/rurr/workspace"
    );
}

#[cfg(windows)]
#[test]
fn windows_git_dependency_url_formats_unc_paths_for_git() {
    assert_eq!(
        windows_git_dependency_url(Path::new(r"\\?\UNC\server\share\rurr")),
        "file://server/share/rurr"
    );
}
