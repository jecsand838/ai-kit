use core::fmt;
use std::future::Future;
use std::path::Path;
use std::process::Stdio;
use std::time::Duration;

use anyhow::{Context, Result, bail};
use futures::{SinkExt, StreamExt};
use semver::Version;
use surrealdb_rpc::{DbResponse, DbResult};
use surrealdb_types::{Error as TypesError, Value};
use tokio::io::AsyncReadExt;
use tokio::net::TcpStream;
use tokio::process::{Child, Command};
use tokio::select;
use tokio_tungstenite::tungstenite::Message;
use tokio_tungstenite::tungstenite::handshake::client::generate_key;
use tokio_tungstenite::tungstenite::http::header::{
	CONNECTION, HOST, SEC_WEBSOCKET_KEY, SEC_WEBSOCKET_PROTOCOL, SEC_WEBSOCKET_VERSION,
};
use tokio_tungstenite::{MaybeTlsStream, WebSocketStream, connect_async};

use super::Config;
use super::protocol::{ProxyObject, ProxyValue};
use crate::cli::{DsVersion, UpgradeBackend};
use crate::tests::report::TestTaskResult;

/// The WebSocket subprotocol that every connection to a spawned binary asks for.
///
/// What the harness assumes, and why it names the subprotocol:
///
/// - [`SurrealConnection`] encodes each request and decodes each response as flatbuffers, so every
///   binary it starts, the releases the suite upgrades from and the checkout under test alike, has
///   to answer in flatbuffers.
/// - A server chooses the response format from the subprotocol the client offers, by name. A
///   release asked for `cbor` answers in CBOR, which the flatbuffers decoder rejects ("Failed to
///   decode fb value"). The harness therefore assumes that every release it starts accepts
///   `flatbuffers` by name, and that the checkout does too (checked by a unit test below).
/// - It offers the name, not a position in `PROTOCOLS`. The list is a detail of the checkout and
///   its order changes whenever a format is added, so a position does not name a format.
///
/// The Rust SDK makes the same choice by name (`surrealdb/src/engine/remote/ws`).
/// Clients that speak CBOR, such as the JavaScript SDK, offer `cbor` or `cbor.2`
/// and are covered by the server's CBOR end-to-end tests, not by this harness.
/// This is the short name, not the `application/vnd.surrealdb.flatbuffers` media
/// type.
const FLATBUFFERS_SUBPROTOCOL: &str = "flatbuffers";

pub struct ProcessOutput {
	pub stdout: String,
	pub stderr: String,
}

impl fmt::Display for ProcessOutput {
	fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
		write!(f, "  > process stdout:\n{}\n  > process stderr:\n{}\n", self.stdout, self.stderr)
	}
}

/// The last release whose server knows the `files` experimental target.
/// Buckets and file values need it up to here; every later version, release or
/// checkout, has them unconditionally and refuses the name at startup.
const LAST_FILES_TARGET_RELEASE: &str = "4.0.0-beta.1";

/// Whether a binary of `version` knows the `files` experimental target.
///
/// Compared by SemVer precedence, which ignores build metadata: a checkout at
/// `4.0.0-beta.1+local` is beta.1, and `Version`'s own ordering would put it
/// after.
fn accepts_files_target(version: &Version) -> bool {
	let last = Version::parse(LAST_FILES_TARGET_RELEASE).expect("a valid version");
	version.cmp_precedence(&last).is_le()
}

pub struct SurrealProcess {
	process: Child,
	port: u16,
}

impl SurrealProcess {
	pub async fn new(
		config: &Config,
		version: &DsVersion,
		resolved: &Version,
		tmp_dir: &str,
		port: u16,
		experimental: &[String],
		module_dir: Option<&Path>,
	) -> Result<SurrealProcess, anyhow::Error> {
		let mut command = match version {
			DsVersion::Path(x) => {
				let path = Path::new(x).join("target").join("debug").join("surreal");
				Command::new(path)
			}
			DsVersion::Version(x) => {
				let path = Path::new(".binary_cache").join(format!("surreal-v{x}"));
				Command::new(path)
			}
		};

		// A released binary writes RocksDB on the migration backend and the
		// checkout under test opens it as SurrealKV, so every hop but the last
		// of a chain runs on RocksDB.
		let scheme = match (config.backend, version) {
			(UpgradeBackend::RocksDbMigration, DsVersion::Version(_)) => "rocksdb",
			_ => "surrealkv",
		};
		let query = if config.versioned {
			"?versioned=true"
		} else {
			""
		};
		let endpoint = format!("{scheme}://{tmp_dir}/ds{query}");

		let bind = format!("127.0.0.1:{port}");
		let common_args =
			["start", "--bind", &bind, "--username", "root", "--password", "root", &endpoint];

		command
			.args(common_args)
			// Set the worker threads to 1 so the different processes interver less with eachother
			.env("SURREAL_RUNTIME_WORKER_THREADS", "1")
			// Lets the current checkout mint presigned URLs. A release that
			// predates presigning ignores the variable.
			.env("SURREAL_BUCKET_PRESIGN_SECRET", "language-tests-presign-secret-0000")
			// A 4.x checkout refuses to open a store a 3.x release wrote unless
			// the operator opts in, and every hop onto it is such an upgrade. A
			// release that predates the opt-in ignores the variable.
			.env("SURREAL_EXPERIMENTAL_UPGRADE_FROM_3X", "true")
			.stdin(Stdio::null())
			.stdout(Stdio::piped())
			.stderr(Stdio::piped())
			.kill_on_drop(true);

		// Experimental capabilities have no `surreal start` flag, but the server
		// reads them from this variable on every release the chain spans, so a
		// test needing one (a Surrealism extension) can be spawned for. A target
		// a binary does not recognise makes it exit during startup, which
		// surfaces as a failure to open the connection.
		//
		// A binary that still gates buckets and file values behind the `files`
		// target is started with it, so it accepts the bucket definitions and
		// file values a later one accepts unconditionally. A later one refuses
		// the name, so it never gets it.
		let mut experimental = experimental.to_vec();
		if accepts_files_target(resolved) && !experimental.iter().any(|t| t == "files") {
			experimental.push("files".to_owned());
		}
		if !experimental.is_empty() {
			command.env("SURREAL_CAPS_ALLOW_EXPERIMENTAL", experimental.join(","));
		}

		// A Surrealism module is loaded out of a file-backed bucket, so the
		// directory holding it has to be allowlisted, and the demo package
		// declares a loopback network capability the server must grant before it
		// will load the package at all. Passed per case rather than per run: a
		// binary spawned for a test that never asked for a module must not get
		// network access or an allowlisted path, or a test covering the denial
		// of either would pass for the wrong reason.
		if let Some(dir) = module_dir {
			command.env("SURREAL_BUCKET_FOLDER_ALLOWLIST", dir);
			command.env("SURREAL_CAPS_ALLOW_NET", "127.0.0.1");
		}

		let process = command.spawn().context("Failed to spawn process")?;

		Ok(SurrealProcess {
			process,
			port,
		})
	}

	#[cfg(any(unix, target_os = "macos"))]
	pub async fn stop(&self) -> anyhow::Result<()> {
		use anyhow::bail;

		let pid = match self.process.id() {
			None => return Ok(()),
			Some(x) => x,
		};
		let res = Command::new("kill").arg("-15").arg(pid.to_string()).output().await?;
		if !res.status.success() {
			bail!(
				"Kill command for datastore process failed.\n    STDOUT:{}\n    STDERR: {}",
				String::from_utf8_lossy(&res.stdout),
				String::from_utf8_lossy(&res.stderr)
			);
		}
		Ok(())
	}

	#[cfg(windows)]
	pub async fn stop(&self) -> anyhow::Result<()> {
		use anyhow::bail;

		let pid = match self.process.id() {
			None => return Ok(()),
			Some(x) => x,
		};
		let res = Command::new("taskkill").arg("/pid").arg(pid.to_string()).output().await?;
		if !res.status.success() {
			bail!(
				"Kill command for datastore process failed.\n    STDOUT:{}\n    STDERR: {}",
				String::from_utf8_lossy(&res.stdout),
				String::from_utf8_lossy(&res.stderr)
			);
		}
		Ok(())
	}

	pub async fn quit(mut self) -> anyhow::Result<()> {
		self.stop().await?;

		if tokio::time::timeout(Duration::from_secs(5), self.process.wait()).await.is_err() {
			self.process.kill().await?;
		}
		Ok(())
	}

	async fn retrieve_output(proc: &mut Child) -> Option<ProcessOutput> {
		let mut buffer = Vec::new();

		proc.stdout.take()?.read_to_end(&mut buffer).await.unwrap();
		let stdout = String::from_utf8_lossy(&buffer).into_owned();

		buffer.clear();
		proc.stderr.take().unwrap().read_to_end(&mut buffer).await.unwrap();
		let stderr = String::from_utf8_lossy(&buffer).into_owned();

		Some(ProcessOutput {
			stdout,
			stderr,
		})
	}

	pub async fn quit_with_output(mut self) -> anyhow::Result<Option<ProcessOutput>> {
		self.stop().await?;

		if tokio::time::timeout(Duration::from_secs(5), self.process.wait()).await.is_err() {
			self.process.kill().await?;
		}

		let output = Self::retrieve_output(&mut self.process).await;

		Ok(output)
	}

	pub async fn open_connection(&mut self) -> anyhow::Result<SurrealConnection> {
		let port = self.port;
		self.assert_running_while(async {
			let request = tokio_tungstenite::tungstenite::handshake::client::Request::builder()
				.uri(format!("ws://127.0.0.1:{}/rpc", port))
				.header(SEC_WEBSOCKET_PROTOCOL, FLATBUFFERS_SUBPROTOCOL)
				.header("Upgrade", "websocket")
				.header(SEC_WEBSOCKET_VERSION, "13")
				.header(SEC_WEBSOCKET_KEY, generate_key())
				.header(CONNECTION, "upgrade")
				.header(HOST, format!("127.0.0.1:{}", port))
				.body(())
				.context("failed to create request")?;

			let mut wait_duration = Duration::from_millis(5);
			let mut retries = 0;

			let socket = loop {
				tokio::time::sleep(wait_duration).await;
				match connect_async(request.clone()).await.context("Failed to connect to socket.") {
					Ok((x, _)) => break x,
					Err(e) => {
						if retries < 10 {
							wait_duration *= 2;
							retries += 1;
						} else {
							return Err(e);
						}
					}
				}
			};

			Ok(SurrealConnection {
				id: 0,
				socket,
			})
		})
		.await?
	}

	/// Ensures that the process is still running while the future is executing.
	///
	/// Will return an error if the process quit during the execution of the future.
	pub async fn assert_running_while<R, Fut: Future<Output = R>>(&mut self, f: Fut) -> Result<R> {
		select! {
			// Biased because if the process quit we want to know it first.
			biased;

			_ = self.process.wait() => {
				if let Some(output) = Self::retrieve_output(&mut self.process).await{
					bail!("Surrealdb process quit early.\n{}",output);
				}else{
					bail!("Surrealdb process quit early")
				}
			}
			res = f => {
				Ok(res)
			}
		}
	}
}

pub struct SurrealConnection {
	id: i64,
	socket: WebSocketStream<MaybeTlsStream<TcpStream>>,
}

impl SurrealConnection {
	pub async fn request(&mut self, mut object: ProxyObject) -> Result<DbResponse, TypesError> {
		let id = self.id;
		self.id += 1;

		object.insert("id".to_owned(), ProxyValue::from(id));

		// Convert ProxyObject to Value
		let value = object.into_value();

		let message = surrealdb_types::encode(&value)
			.map_err(|e| TypesError::serialization(e.to_string(), None))?;
		self.socket
			.send(Message::Binary(message.into()))
			.await
			.map_err(|e| TypesError::internal(format!("Failed to send query message: {e}")))?;

		loop {
			let Some(message) = self.socket.next().await else {
				return Err(TypesError::internal("Websocket connection closed early".to_string()));
			};
			let message = message
				.map_err(|e| TypesError::internal(format!("Surrealdb connection error: {e}")))?;

			let data = match message {
				Message::Ping(x) => {
					self.socket
						.send(Message::Pong(x))
						.await
						.map_err(|e| TypesError::internal(format!("Failed to send pong: {e}")))?;
					continue;
				}
				Message::Text(_) => {
					return Err(TypesError::internal(
						"Received a text message from the database, expecting only binary messages"
							.to_string(),
					));
				}
				Message::Binary(x) => x,
				Message::Pong(_) => continue,
				// Documentation says we don't get this message.
				Message::Frame(_) => unreachable!(),
				Message::Close(_) => {
					return Err(TypesError::internal(
						"Websocket connection to database closed early".to_string(),
					));
				}
			};

			let response: DbResponse = surrealdb_types::decode(&data).map_err(|e| {
				TypesError::serialization(format!("Failed to deserialize response: {e}"), None)
			})?;

			if response.result.is_err() {
				let Err(e) = response.result else {
					unreachable!()
				};
				return Err(TypesError::internal(format!(
					"Response returned a failure: {}",
					e.message()
				)));
			}

			if response.id != Some(Value::Number(surrealdb_types::Number::Int(id))) {
				continue;
			}

			return Ok(response);
		}
	}

	pub async fn query(&mut self, query: &str) -> anyhow::Result<TestTaskResult> {
		let mut request_obj = ProxyObject::default();
		request_obj.insert("method".to_owned(), ProxyValue::from("query"));
		request_obj.insert("params".to_owned(), ProxyValue::from(vec![ProxyValue::from(query)]));

		let response = match self.request(request_obj).await {
			Ok(x) => x,
			Err(e) => return Ok(TestTaskResult::RunningError(e.into())),
		};

		match response.result {
			Ok(DbResult::Query(e)) => {
				let results = e
					.into_iter()
					.map(|x| match x.result {
						Ok(value) => Ok(Ok(value)),
						Err(e) => Ok(Err(e.message().to_string())),
					})
					.collect::<Result<Vec<Result<Value, String>>, anyhow::Error>>()?;

				Ok(TestTaskResult::Results {
					did_timeout: false,
					res: results, trace: None,
				})
			}
			Ok(_) => bail!("Got invalid response type"),
			Err(e) => Ok(TestTaskResult::RunningError(anyhow::Error::msg(e.message().to_string()))),
		}
	}
}

#[cfg(test)]
mod tests {
	use surrealdb_core::rpc::format::{Format, PROTOCOLS};

	#[test]
	fn the_files_target_is_given_to_the_releases_that_know_it() {
		use super::{Version, accepts_files_target};
		let accepts = |v: &str| accepts_files_target(&Version::parse(v).unwrap());
		for known in ["3.0.0", "3.3.5", "4.0.0-alpha.1", "4.0.0-beta.1", "4.0.0-beta.1+local"] {
			assert!(accepts(known), "{known}");
		}
		for stable in ["4.0.0-beta.2", "4.0.0-nightly", "4.0.0-rc.1", "4.0.0", "4.1.0"] {
			assert!(!accepts(stable), "{stable}");
		}
	}

	use super::FLATBUFFERS_SUBPROTOCOL;

	/// The subprotocol the harness asks for must be one the checkout serves, and the
	/// format it selects must be the one the harness encodes and decodes. A server
	/// that picks any other format answers in bytes the flatbuffers decoder rejects,
	/// which fails every case of an upgrade run before a test statement is sent.
	#[test]
	fn requested_subprotocol_selects_flatbuffers() {
		assert!(
			PROTOCOLS.contains(&FLATBUFFERS_SUBPROTOCOL),
			"the checkout does not serve the `{FLATBUFFERS_SUBPROTOCOL}` subprotocol"
		);
		assert_eq!(Format::from(FLATBUFFERS_SUBPROTOCOL), Format::Flatbuffers);
	}
}
