use indexmap::IndexMap;
use rurr_core::action::{ActionContext, ActionError, ActionResult, Condition, LocalAction};
use rurr_core::application::ApplicationBuilder;
use rurr_core::graph::{GraphAction, GraphBuilder};
use rurr_core::state::State;
use rurr_testkit::test_dir_for_test;
use std::fs;

#[derive(Debug, Clone)]
struct ContractAction {
    name: Option<String>,
}

impl ContractAction {
    fn unnamed() -> Self {
        Self { name: None }
    }
}

impl LocalAction for ContractAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn tags(&self) -> &[String] {
        &[]
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }

        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
    }
}

fn graph_action(name: &str) -> GraphAction {
    let named = ContractAction::unnamed()
        .with_name(name)
        .expect("test action naming should succeed");
    GraphAction::new(named).expect("named action should create graph action")
}

fn test_graph() -> rurr_core::graph::Graph {
    GraphBuilder::new()
        .with_actions(vec![graph_action("counter"), graph_action("result")])
        .with_transition_when("counter", "counter", Condition::expr("count < 10"))
        .with_transition("counter", "result")
        .build()
        .expect("graph build should succeed")
}

#[test]
fn test_visualize_dot_output() {
    let graph = test_graph();
    let temp_root = test_dir_for_test().expect("temp dir setup should succeed");
    let cases = [
        ("app", false),
        ("app.png", false),
        ("app", true),
        ("app.png", true),
    ];

    for (index, (filename, write_dot)) in cases.into_iter().enumerate() {
        let case_dir = temp_root.join(format!("case_{index}"));
        fs::create_dir_all(&case_dir).expect("case dir creation should succeed");

        let output_file_path = case_dir.join(filename);
        let dot_output = graph
            .visualize(Some(output_file_path.as_path()), write_dot)
            .expect("visualize should succeed");
        let dot_file_path = output_file_path.with_extension("dot");

        assert_eq!(
            dot_file_path.exists(),
            write_dot,
            "dot file existence should match write_dot for filename '{filename}'"
        );

        if write_dot {
            let written = fs::read_to_string(&dot_file_path)
                .expect("written dot file should be readable as UTF-8");
            assert_eq!(written, dot_output, "written dot should match return value");
        }
    }
}

#[test]
fn test_visualize_no_dot_output() {
    let graph = test_graph();
    let temp_root = test_dir_for_test().expect("temp dir setup should succeed");
    let dot_file_path = temp_root.join("dag.dot");

    let with_write_dot = graph
        .visualize(None, true)
        .expect("visualize should succeed without output path");
    let without_write_dot = graph
        .visualize(None, false)
        .expect("visualize should succeed without output path");

    assert_eq!(
        with_write_dot, without_write_dot,
        "write_dot should not change returned DOT text"
    );
    assert!(
        !dot_file_path.exists(),
        "dot output should not be written when output_file_path is None"
    );
}

#[test]
fn application_visualize_matches_public_graph_view() {
    let app = ApplicationBuilder::new()
        .with_state(State::default())
        .expect("state should configure")
        .with_graph(test_graph())
        .expect("graph should configure")
        .build()
        .expect("application should build");

    let app_dot = app
        .visualize(None, false)
        .expect("application visualize should succeed");
    let graph_dot = app
        .graph()
        .visualize(None, false)
        .expect("graph visualize should succeed");

    assert_eq!(app_dot, graph_dot);
}
