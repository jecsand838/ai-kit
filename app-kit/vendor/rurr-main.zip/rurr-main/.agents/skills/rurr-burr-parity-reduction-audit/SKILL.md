---
name: rurr-burr-parity-reduction-audit
description: "Use when identifying high-yield delete-first reduction opportunities in Rurr before choosing a concrete plan, while preserving Apache Burr parity, oracle behavior, streaming/lifecycle guardrails, and current runtime semantics."
---

# Rurr Burr Parity Reduction Audit

Use this skill when the user wants to identify major code reduction opportunities in Rurr without regressing Burr parity or the current behavior contract.

## Quick start

Load, in order:

- `README.md`
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- relevant Burr source under `tools/burr_oracle/vendor/apache-burr/`

Load these companion skills:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`

Add these only when the audited subsystem needs them:

- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-dependencies-platforms`
- `$rurr-streaming-transaction-safety`
- `$rurr-anchored-filesystem-hardening`
- `$rurr-persistence-adapter-parity`
- `$rurr-proc-macro-ui-contract`

## When to use

Use it when the task:

- asks for workspace-wide or subsystem-level reductive refactor analysis
- asks where Rurr has too much layering, duplication, or dead compatibility scaffolding
- asks whether public API simplification is acceptable if it improves Burr alignment
- needs a ranked list of delete-first cleanup opportunities before planning implementation

## Workflow

1. Size the current implementation and identify the biggest duplication and over-modeling pools.
2. Compare Rurr subsystem shape to Burr source and the current compatibility docs.
3. Separate non-negotiable parity and guardrail boundaries from removable internal layering.
4. Estimate likely net deletion by subsystem and identify the safest delete-first order.
5. Reject macro-based reduction proposals; identify the struct, enum, method, or trait-boundary
   shape that would actually remove the layering.
6. Call out risks around streaming, lifecycle, tracking layout, persistence ordering, and proc-macro behavior.
7. Name the subsystem guardrail skill that should govern each high-risk cleanup pool.

## Output contract

Return:

- the top reduction pools, ordered by likely impact
- why each pool is over-layered, duplicated, or structurally redundant
- the expected deletion range or relative savings for each pool
- the behavior and parity constraints that must remain unchanged
- the recommended follow-on order for planning or execution

## Default rules

- Prefer concrete shared structs and enum-backed closed sets over parallel helper families.
- Do not use macros, proc-macro helpers, or macro helper crates as the reductive abstraction.
- Prefer merging thin crates or thin modules back into the owning domain boundary.
- Public API breaks are acceptable when they move Rurr closer to Burr and remove dead compatibility weight.
- Do not recommend compatibility shims, deprecated aliases, or dual internal paths unless Burr parity explicitly requires them.
- Do not recommend changes that violate `docs/ARCHITECTURE_GUARDRAILS.md`.

## Do not use this skill alone when

- the user needs a subsystem-level Rurr versus Burr comparison before deciding what may change: also use `$rurr-burr-source-parity-walk`
- the user wants a decision-complete implementation plan: also use `$rurr-delete-first-refactor-plan`
- the user wants a follow-up plan after a partial pass: also use `$rurr-follow-up-reduction-pass`
- the user wants the plan implemented: also use `$rurr-delete-first-refactor-plan` in implementation mode
- the user is resuming the archived Phase 1-8 refactor program under `docs/refactors/rurr-refactor/`: this skill is for current-state cleanup, not archive-program execution
