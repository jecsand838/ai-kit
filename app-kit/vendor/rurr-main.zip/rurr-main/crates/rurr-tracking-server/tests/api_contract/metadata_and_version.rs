use super::*;

#[tokio::test]
async fn ready_and_app_spec_endpoints_return_success() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    build_fixture(tempdir.path());
    let app = rurr_tracking_server::app_with_state(AppState::with_embedded_ui(Arc::new(
        LocalBackend::new(tempdir.path()).expect("local backend should build"),
    )));

    let ready = app
        .clone()
        .oneshot(
            Request::builder()
                .uri("/ready")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("ready request should succeed");
    assert_eq!(ready.status(), StatusCode::OK);

    let app_spec = app
        .clone()
        .oneshot(
            Request::builder()
                .uri("/api/v0/metadata/app_spec")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("app spec request should succeed");
    assert_eq!(app_spec.status(), StatusCode::OK);
    let app_spec_json = response_json(app_spec).await;
    assert_eq!(app_spec_json.get("backend"), Some(&json!("local")));
    assert_eq!(
        app_spec_json.get("storage_layout_version"),
        Some(&json!(storage_layout_version()))
    );
    assert_eq!(app_spec_json.get("indexing"), Some(&json!(false)));
    assert_eq!(app_spec_json.get("snapshotting"), Some(&json!(false)));
    assert_eq!(app_spec_json.get("supports_demos"), Some(&json!(false)));
    assert_eq!(
        app_spec_json.get("supports_annotations"),
        Some(&json!(true))
    );
}

#[tokio::test]
async fn version_endpoint_returns_documented_burr_compatibility_version() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    build_fixture(tempdir.path());
    let app = rurr_tracking_server::app_with_state(AppState::with_embedded_ui(Arc::new(
        LocalBackend::new(tempdir.path()).expect("local backend should build"),
    )));

    let response = app
        .oneshot(
            Request::builder()
                .uri("/api/v0/version")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("version request should succeed");

    assert_eq!(response.status(), StatusCode::OK);
    let payload = response_json(response).await;
    assert_eq!(payload, json!({ "version": burr_compat_version() }));
    assert_ne!(
        payload,
        json!({ "version": env!("CARGO_PKG_VERSION") }),
        "tracking server version must report the Burr compatibility target, not the server crate version"
    );
}
