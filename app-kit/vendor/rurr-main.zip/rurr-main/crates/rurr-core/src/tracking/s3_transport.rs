//! Shared S3 client and request-addressing helpers for tracking integrations.
//!
//! Core S3 writers and the tracking server use the same settings object so
//! endpoint parsing, path-style/virtual-hosted addressing, and explicit
//! credential validation do not drift between sync signing and async SDK calls.
//! Building a settings value is local-only; [`S3ClientSettings::sdk_client`]
//! performs provider setup when a caller needs an AWS SDK client. Both sync and
//! async lanes require explicit static credentials from settings or standard AWS
//! environment variables.
//!
//! # Examples
//!
//! ```
//! use rurr_core::tracking::{S3AddressingStyle, S3ClientSettings};
//!
//! let settings = S3ClientSettings::new(
//!     "tracking-bucket",
//!     "us-east-1",
//!     None,
//!     S3AddressingStyle::VirtualHosted,
//!     None,
//!     None,
//!     None,
//! )
//! .with_credentials("access-key", "secret-key", None)?;
//! settings.validate()?;
//!
//! let invalid = S3ClientSettings::new(
//!     "",
//!     "us-east-1",
//!     None,
//!     S3AddressingStyle::VirtualHosted,
//!     None,
//!     None,
//!     None,
//! );
//! assert!(invalid.validate().is_err());
//!
//! let partial_credentials = S3ClientSettings::new(
//!     "tracking-bucket",
//!     "us-east-1",
//!     None,
//!     S3AddressingStyle::VirtualHosted,
//!     Some("access-key".to_string()),
//!     None,
//!     None,
//! );
//! assert!(partial_credentials.validate().is_err());
//! # Ok::<(), Box<dyn std::error::Error>>(())
//! ```

use super::s3_layout::S3AddressingStyle;
use aws_credential_types::Credentials;
use aws_sdk_s3::config::Builder as S3ConfigBuilder;
use aws_types::region::Region;
use thiserror::Error;

const AWS_ACCESS_KEY_ID_ENV: &str = "AWS_ACCESS_KEY_ID";
const AWS_SECRET_ACCESS_KEY_ENV: &str = "AWS_SECRET_ACCESS_KEY";
const AWS_SESSION_TOKEN_ENV: &str = "AWS_SESSION_TOKEN";

/// Settings needed to build S3 SDK clients and signed request addresses.
///
/// The same value drives async AWS SDK client construction and the sync signed
/// PUT path used by synchronous lifecycle hooks. Static credentials are
/// required for both paths and are all or nothing: validation requires a
/// non-empty access key and secret key from this value or standard AWS
/// environment variables.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct S3ClientSettings {
    bucket: String,
    region: String,
    endpoint_url: Option<String>,
    addressing_style: S3AddressingStyle,
    access_key_id: Option<String>,
    secret_access_key: Option<String>,
    session_token: Option<String>,
}

impl S3ClientSettings {
    /// Creates S3 client settings from caller configuration.
    ///
    /// This constructor stores values without contacting a provider. Call
    /// [`validate`](Self::validate) to check local completeness and addressing
    /// safety, or [`sdk_client`](Self::sdk_client) to build an async AWS SDK
    /// client.
    pub fn new(
        bucket: impl Into<String>,
        region: impl Into<String>,
        endpoint_url: Option<String>,
        addressing_style: S3AddressingStyle,
        access_key_id: Option<String>,
        secret_access_key: Option<String>,
        session_token: Option<String>,
    ) -> Self {
        Self {
            bucket: bucket.into(),
            region: region.into(),
            endpoint_url,
            addressing_style,
            access_key_id,
            secret_access_key,
            session_token,
        }
    }

    /// Returns the configured S3 bucket.
    pub fn bucket(&self) -> &str {
        &self.bucket
    }

    /// Returns the configured AWS region.
    pub fn region(&self) -> &str {
        &self.region
    }

    /// Returns the configured request addressing style.
    pub fn addressing_style(&self) -> S3AddressingStyle {
        self.addressing_style
    }

    /// Returns a copy with a custom endpoint URL.
    ///
    /// The endpoint must be a non-empty base URL. Addressing validation happens
    /// in [`validate`](Self::validate), where dotted buckets over virtual-hosted
    /// HTTPS are rejected because they cannot be represented reliably.
    pub fn with_endpoint_url(
        mut self,
        endpoint_url: impl Into<String>,
    ) -> Result<Self, S3TransportError> {
        let endpoint_url = endpoint_url.into();
        if endpoint_url.trim().is_empty() {
            return Err(S3TransportError::MissingConfig("endpoint_url"));
        }
        self.endpoint_url = Some(endpoint_url);
        Ok(self)
    }

    /// Returns a copy with a different addressing style.
    pub fn with_addressing_style(mut self, addressing_style: S3AddressingStyle) -> Self {
        self.addressing_style = addressing_style;
        self
    }

    /// Returns a copy with static credentials.
    ///
    /// Access key and secret key must both be non-empty. Session tokens are
    /// optional, but a session token without the key pair is rejected.
    pub fn with_credentials(
        mut self,
        access_key_id: impl Into<String>,
        secret_access_key: impl Into<String>,
        session_token: Option<String>,
    ) -> Result<Self, S3TransportError> {
        self.access_key_id = Some(access_key_id.into());
        self.secret_access_key = Some(secret_access_key.into());
        self.session_token = session_token;
        self.validate()?;
        Ok(self)
    }

    /// Builds an AWS SDK S3 client.
    ///
    /// This is the first method that loads provider configuration. Static
    /// credentials must be configured explicitly in this settings value or in
    /// standard AWS environment variables before the SDK config is loaded.
    ///
    /// # Errors
    ///
    /// Returns a transport error for invalid local configuration before provider
    /// setup.
    pub async fn sdk_client(
        &self,
        credential_source: &'static str,
    ) -> Result<aws_sdk_s3::Client, S3TransportError> {
        self.validate()?;
        let mut loader = aws_config::defaults(aws_config::BehaviorVersion::latest())
            .region(Region::new(self.region.clone()));
        if let Some(endpoint_url) = &self.endpoint_url {
            loader = loader.endpoint_url(endpoint_url);
            if endpoint_url.starts_with("http://") {
                loader = loader.http_client(aws_smithy_http_client::Builder::new().build_http());
            }
        }
        let credentials = self.required_static_credentials(credential_source)?;
        loader = loader.credentials_provider(credentials);
        let shared_config = loader.load().await;
        let mut s3_config = S3ConfigBuilder::from(&shared_config);
        if self.addressing_style == S3AddressingStyle::PathStyle {
            s3_config = s3_config.force_path_style(true);
        }
        Ok(aws_sdk_s3::Client::from_conf(s3_config.build()))
    }

    /// Returns credentials from explicit settings or standard AWS environment variables.
    ///
    /// This method is used by the synchronous signed PUT path. It returns
    /// [`S3TransportError::MissingConfig`] when no static credential source is
    /// configured.
    pub fn credentials(
        &self,
        credential_source: &'static str,
    ) -> Result<Credentials, S3TransportError> {
        self.required_static_credentials(credential_source)
    }

    pub(crate) fn put_address(&self, key: &str) -> Result<S3PutAddress, S3TransportError> {
        self.validate_addressing()?;
        let encoded_key = encode_s3_key(key);
        match (&self.endpoint_url, self.addressing_style) {
            (Some(endpoint), S3AddressingStyle::PathStyle) => {
                let (scheme, endpoint_host) = endpoint_parts(endpoint)?;
                Ok(S3PutAddress {
                    url: format!("{scheme}://{endpoint_host}/{}/{}", self.bucket, encoded_key),
                    host: endpoint_host.to_string(),
                })
            }
            (Some(endpoint), S3AddressingStyle::VirtualHosted) => {
                let (scheme, endpoint_host) = endpoint_parts(endpoint)?;
                let host = format!("{}.{}", self.bucket, endpoint_host);
                Ok(S3PutAddress {
                    url: format!("{scheme}://{host}/{encoded_key}"),
                    host,
                })
            }
            (None, S3AddressingStyle::PathStyle) => {
                let host = format!("s3.{}.amazonaws.com", self.region);
                Ok(S3PutAddress {
                    url: format!("https://{}/{}/{}", host, self.bucket, encoded_key),
                    host,
                })
            }
            (None, S3AddressingStyle::VirtualHosted) => {
                let host = format!("{}.s3.{}.amazonaws.com", self.bucket, self.region);
                Ok(S3PutAddress {
                    url: format!("https://{}/{}", host, encoded_key),
                    host,
                })
            }
        }
    }

    /// Validates that the requested addressing mode can be represented safely.
    fn validate_addressing(&self) -> Result<(), S3TransportError> {
        if self.addressing_style != S3AddressingStyle::VirtualHosted || !self.bucket.contains('.') {
            return Ok(());
        }
        let https = self
            .endpoint_url
            .as_deref()
            .map(|endpoint| endpoint.starts_with("https://"))
            .unwrap_or(true);
        if https {
            return Err(S3TransportError::InvalidAddressing("virtual-hosted HTTPS S3 requests do not support dotted bucket names reliably; use path-style addressing or an http endpoint".to_string()));
        }
        Ok(())
    }

    /// Validates endpoint/addressing and required static credential completeness.
    pub fn validate(&self) -> Result<(), S3TransportError> {
        self.required_non_empty(&self.bucket, "bucket")?;
        self.required_non_empty(&self.region, "region")?;
        self.validate_addressing()?;
        let _ = self.required_static_credentials("validation")?;
        Ok(())
    }

    fn required_non_empty(&self, value: &str, field: &'static str) -> Result<(), S3TransportError> {
        if value.trim().is_empty() {
            Err(S3TransportError::MissingConfig(field))
        } else {
            Ok(())
        }
    }

    fn static_credentials(
        &self,
        credential_source: &'static str,
    ) -> Result<Option<Credentials>, S3TransportError> {
        if !self.credential_input_configured() {
            return Ok(None);
        }
        let access_key_id = self
            .credential_value(&self.access_key_id, AWS_ACCESS_KEY_ID_ENV, "access_key_id")?
            .ok_or(S3TransportError::MissingConfig("access_key_id"))?;
        let secret_access_key = self
            .credential_value(
                &self.secret_access_key,
                AWS_SECRET_ACCESS_KEY_ENV,
                "secret_access_key",
            )?
            .ok_or(S3TransportError::MissingConfig("secret_access_key"))?;
        let session_token =
            self.credential_value(&self.session_token, AWS_SESSION_TOKEN_ENV, "session_token")?;
        Ok(Some(Credentials::new(
            access_key_id,
            secret_access_key,
            session_token,
            None,
            credential_source,
        )))
    }

    fn required_static_credentials(
        &self,
        credential_source: &'static str,
    ) -> Result<Credentials, S3TransportError> {
        self.static_credentials(credential_source)?
            .ok_or(S3TransportError::MissingConfig("access_key_id"))
    }

    fn credential_input_configured(&self) -> bool {
        self.access_key_id.is_some()
            || self.secret_access_key.is_some()
            || self.session_token.is_some()
            || std::env::var_os(AWS_ACCESS_KEY_ID_ENV).is_some()
            || std::env::var_os(AWS_SECRET_ACCESS_KEY_ENV).is_some()
            || std::env::var_os(AWS_SESSION_TOKEN_ENV).is_some()
    }

    fn credential_value(
        &self,
        configured: &Option<String>,
        env_key: &'static str,
        field: &'static str,
    ) -> Result<Option<String>, S3TransportError> {
        let value = configured.clone().or_else(|| std::env::var(env_key).ok());
        match value {
            Some(value) if value.trim().is_empty() => Err(S3TransportError::MissingConfig(field)),
            Some(value) => Ok(Some(value)),
            None => Ok(None),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct S3PutAddress {
    pub(crate) url: String,
    pub(crate) host: String,
}

/// Errors raised while constructing S3 clients or request addresses.
#[derive(Debug, Error)]
pub enum S3TransportError {
    /// Required credential configuration is missing.
    #[error("missing s3 configuration: {0}")]
    MissingConfig(&'static str),
    /// The endpoint URL is malformed or unsupported.
    #[error("invalid s3 endpoint: {0}")]
    InvalidEndpoint(String),
    /// The requested addressing style is unsupported for the configured bucket/endpoint.
    #[error("invalid s3 addressing: {0}")]
    InvalidAddressing(String),
}

fn endpoint_parts(endpoint: &str) -> Result<(&str, &str), S3TransportError> {
    let trimmed = endpoint.trim_end_matches('/');
    let (scheme, host) = trimmed.split_once("://").ok_or_else(|| {
        S3TransportError::InvalidEndpoint(
            "endpoint_url must start with http:// or https://".to_string(),
        )
    })?;
    if !matches!(scheme, "http" | "https") {
        return Err(S3TransportError::InvalidEndpoint(
            "endpoint_url scheme must be http or https".to_string(),
        ));
    }
    if host.is_empty() || host.contains('/') {
        return Err(S3TransportError::InvalidEndpoint(
            "endpoint_url must contain only scheme, host, and optional port".to_string(),
        ));
    }
    Ok((scheme, host))
}

fn encode_s3_key(key: &str) -> String {
    key.split('/')
        .map(uri_encode_segment)
        .collect::<Vec<_>>()
        .join("/")
}

fn uri_encode_segment(segment: &str) -> String {
    let mut encoded = String::new();
    for byte in segment.bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                encoded.push(byte as char)
            }
            other => encoded.push_str(&format!("%{other:02X}")),
        }
    }
    encoded
}

#[cfg(test)]
mod tests {
    use super::*;
    use rurr_testkit::env::EnvVarGuard;

    fn settings(
        access_key_id: Option<&str>,
        secret_access_key: Option<&str>,
        session_token: Option<&str>,
    ) -> S3ClientSettings {
        S3ClientSettings::new(
            "bucket",
            "us-east-1",
            None,
            S3AddressingStyle::VirtualHosted,
            access_key_id.map(str::to_string),
            secret_access_key.map(str::to_string),
            session_token.map(str::to_string),
        )
    }

    fn clean_aws_credentials_env() -> EnvVarGuard {
        EnvVarGuard::set([
            (AWS_ACCESS_KEY_ID_ENV, None),
            (AWS_SECRET_ACCESS_KEY_ENV, None),
            (AWS_SESSION_TOKEN_ENV, None),
        ])
    }

    fn assert_missing_config(error: S3TransportError, expected_field: &'static str) {
        assert!(
            matches!(error, S3TransportError::MissingConfig(field) if field == expected_field),
            "unexpected error: {error}"
        );
    }

    #[test]
    fn complete_explicit_credentials_pass() {
        let _guard = clean_aws_credentials_env();
        let credentials = settings(Some("access"), Some("secret"), Some("session"))
            .credentials("test")
            .expect("complete credentials should pass");

        assert_eq!(credentials.access_key_id(), "access");
        assert_eq!(credentials.secret_access_key(), "secret");
        assert_eq!(credentials.session_token(), Some("session"));
    }

    #[test]
    fn sync_credentials_reject_partial_or_blank_explicit_credentials() {
        let _guard = clean_aws_credentials_env();

        assert_missing_config(
            settings(Some("access"), None, None)
                .credentials("test")
                .expect_err("access-only credentials should fail"),
            "secret_access_key",
        );
        assert_missing_config(
            settings(None, Some("secret"), None)
                .credentials("test")
                .expect_err("secret-only credentials should fail"),
            "access_key_id",
        );
        assert_missing_config(
            settings(None, None, Some("session"))
                .credentials("test")
                .expect_err("session-only credentials should fail"),
            "access_key_id",
        );
        assert_missing_config(
            settings(Some(""), Some("secret"), None)
                .credentials("test")
                .expect_err("blank access key should fail"),
            "access_key_id",
        );
        assert_missing_config(
            settings(Some("access"), Some(""), None)
                .credentials("test")
                .expect_err("blank secret key should fail"),
            "secret_access_key",
        );
        std::env::set_var(AWS_SECRET_ACCESS_KEY_ENV, "env-secret");
        assert_missing_config(
            settings(None, None, None)
                .credentials("test")
                .expect_err("secret-only AWS env credentials should fail"),
            "access_key_id",
        );
        std::env::remove_var(AWS_SECRET_ACCESS_KEY_ENV);
    }

    #[test]
    fn sdk_validation_rejects_partial_explicit_credentials_before_provider_chain() {
        let _guard = clean_aws_credentials_env();
        let error = settings(None, Some("secret"), None)
            .validate()
            .expect_err("secret-only credentials should fail before SDK config loads");

        assert_missing_config(error, "access_key_id");
    }
}
