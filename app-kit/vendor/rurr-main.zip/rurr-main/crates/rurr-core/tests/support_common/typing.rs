use indexmap::IndexMap;
use rurr_core::state::{StateError, StateOperation, TypingSystem};
use serde_json::Value;
use std::any::Any;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

#[derive(Debug, Default)]
pub(crate) struct PassthroughTypingSystem;

impl TypingSystem for PassthroughTypingSystem {}

#[derive(Debug, Default)]
pub(crate) struct NonNegativeCountTypingSystem {
    require_existing_count_before_increment: bool,
}

impl NonNegativeCountTypingSystem {
    pub(crate) fn requiring_existing_count_before_increment() -> Self {
        Self {
            require_existing_count_before_increment: true,
        }
    }
}

impl TypingSystem for NonNegativeCountTypingSystem {
    fn validate_pre_action(
        &self,
        state: &IndexMap<String, Value>,
        operation: &StateOperation,
    ) -> Result<(), StateError> {
        if self.require_existing_count_before_increment
            && matches!(operation, StateOperation::Increment(_))
            && !state.contains_key("count")
        {
            return Err(StateError::TypingSystem {
                phase: "validate_pre_action",
                message: "count must exist before increment".to_string(),
            });
        }
        Ok(())
    }

    fn validate_post_action(
        &self,
        _previous: &IndexMap<String, Value>,
        next: &IndexMap<String, Value>,
        _operation: &StateOperation,
    ) -> Result<(), StateError> {
        validate_non_negative_count(next, "validate_post_action")
    }

    fn validate_state(&self, state: &IndexMap<String, Value>) -> Result<(), StateError> {
        validate_non_negative_count(state, "validate_state")
    }
}

#[derive(Debug, Default)]
pub(crate) struct DeleteOnlyPostActionTypingSystem;

impl TypingSystem for DeleteOnlyPostActionTypingSystem {
    fn validate_post_action(
        &self,
        previous: &IndexMap<String, Value>,
        next: &IndexMap<String, Value>,
        operation: &StateOperation,
    ) -> Result<(), StateError> {
        if matches!(operation, StateOperation::Delete(_))
            && previous.contains_key("__SEQUENCE_ID")
            && !next.contains_key("__SEQUENCE_ID")
        {
            return Err(StateError::TypingSystem {
                phase: "validate_post_action",
                message: "__SEQUENCE_ID must survive delete operations".to_string(),
            });
        }
        Ok(())
    }

    fn validate_state(&self, state: &IndexMap<String, Value>) -> Result<(), StateError> {
        validate_non_negative_count(state, "validate_state")
    }
}

#[derive(Debug, Clone, Copy)]
pub(crate) struct RequireKeyTypingSystem {
    required_key: &'static str,
}

impl RequireKeyTypingSystem {
    pub(crate) const fn new(required_key: &'static str) -> Self {
        Self { required_key }
    }
}

impl TypingSystem for RequireKeyTypingSystem {
    fn validate_state(&self, state: &IndexMap<String, Value>) -> Result<(), StateError> {
        if state.contains_key(self.required_key) {
            Ok(())
        } else {
            Err(StateError::TypingSystem {
                phase: "validate_state",
                message: format!("{} is required", self.required_key),
            })
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub(crate) struct StringListTypingSystem {
    field: &'static str,
}

impl StringListTypingSystem {
    pub(crate) const fn new(field: &'static str) -> Self {
        Self { field }
    }
}

impl TypingSystem for StringListTypingSystem {
    fn validate_post_action(
        &self,
        _previous: &IndexMap<String, Value>,
        next: &IndexMap<String, Value>,
        _operation: &StateOperation,
    ) -> Result<(), StateError> {
        self.validate_state(next)
    }

    fn validate_state(&self, state: &IndexMap<String, Value>) -> Result<(), StateError> {
        match state.get(self.field).and_then(Value::as_array) {
            Some(values) if values.iter().all(Value::is_string) => Ok(()),
            Some(_) => Err(StateError::TypingSystem {
                phase: "validate_state",
                message: format!("{} must contain only strings", self.field),
            }),
            None => Err(StateError::TypingSystem {
                phase: "validate_state",
                message: format!("{} must be an array", self.field),
            }),
        }
    }
}

#[derive(Debug, Default)]
pub(crate) struct ResumeStateTypingSystem;

impl TypingSystem for ResumeStateTypingSystem {
    fn validate_state(&self, state: &IndexMap<String, Value>) -> Result<(), StateError> {
        if !state.contains_key("restored") {
            return Err(StateError::TypingSystem {
                phase: "validate_state",
                message: "restored is required".to_string(),
            });
        }

        match state.get("__SEQUENCE_ID").and_then(Value::as_u64) {
            Some(_) => {}
            None => {
                return Err(StateError::TypingSystem {
                    phase: "validate_state",
                    message: "__SEQUENCE_ID must be present".to_string(),
                });
            }
        }

        match state.get("__PRIOR_STEP").and_then(Value::as_str) {
            Some(_) => Ok(()),
            None => Err(StateError::TypingSystem {
                phase: "validate_state",
                message: "__PRIOR_STEP must be present".to_string(),
            }),
        }
    }
}

#[derive(Debug, Clone)]
struct RoundTripStateData {
    raw: IndexMap<String, Value>,
    fail_construct_state: bool,
}

#[derive(Debug, Default)]
pub(crate) struct RoundTripCountTypingSystem;

impl TypingSystem for RoundTripCountTypingSystem {
    fn construct_data(
        &self,
        state: &IndexMap<String, Value>,
    ) -> Result<Box<dyn Any + Send + Sync>, StateError> {
        match state.get("count").and_then(Value::as_i64) {
            Some(value) if value >= 0 => Ok(Box::new(RoundTripStateData {
                raw: state.clone(),
                fail_construct_state: false,
            })),
            Some(_) => Err(StateError::TypingSystem {
                phase: "construct_data",
                message: "count must stay non-negative".to_string(),
            }),
            None => Err(StateError::TypingSystem {
                phase: "construct_data",
                message: "count must be an integer".to_string(),
            }),
        }
    }

    fn construct_state(
        &self,
        data: &(dyn Any + Send + Sync),
    ) -> Result<IndexMap<String, Value>, StateError> {
        data.downcast_ref::<RoundTripStateData>()
            .map(|data| data.raw.clone())
            .ok_or_else(|| StateError::TypingSystem {
                phase: "construct_state",
                message: "expected RoundTripStateData payload".to_string(),
            })
    }
}

#[derive(Debug, Default)]
pub(crate) struct DeleteOnlyRoundTripCountTypingSystem;

impl TypingSystem for DeleteOnlyRoundTripCountTypingSystem {
    fn construct_data(
        &self,
        state: &IndexMap<String, Value>,
    ) -> Result<Box<dyn Any + Send + Sync>, StateError> {
        match state.get("count").and_then(Value::as_i64) {
            Some(value) if value >= 0 => Ok(Box::new(RoundTripStateData {
                raw: state.clone(),
                fail_construct_state: false,
            })),
            Some(_) => Err(StateError::TypingSystem {
                phase: "construct_data",
                message: "count must stay non-negative".to_string(),
            }),
            None => Err(StateError::TypingSystem {
                phase: "construct_data",
                message: "count must be an integer".to_string(),
            }),
        }
    }

    fn construct_state(
        &self,
        data: &(dyn Any + Send + Sync),
    ) -> Result<IndexMap<String, Value>, StateError> {
        data.downcast_ref::<RoundTripStateData>()
            .map(|data| data.raw.clone())
            .ok_or_else(|| StateError::TypingSystem {
                phase: "construct_state",
                message: "expected RoundTripStateData payload".to_string(),
            })
    }

    fn validate_post_action(
        &self,
        previous: &IndexMap<String, Value>,
        next: &IndexMap<String, Value>,
        operation: &StateOperation,
    ) -> Result<(), StateError> {
        if matches!(operation, StateOperation::Delete(_))
            && previous.contains_key("__SEQUENCE_ID")
            && !next.contains_key("__SEQUENCE_ID")
        {
            return Err(StateError::TypingSystem {
                phase: "validate_post_action",
                message: "__SEQUENCE_ID must survive delete operations".to_string(),
            });
        }
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct ResumeRoundTripTypingSystem;

impl TypingSystem for ResumeRoundTripTypingSystem {
    fn construct_data(
        &self,
        state: &IndexMap<String, Value>,
    ) -> Result<Box<dyn Any + Send + Sync>, StateError> {
        if !state.contains_key("restored") {
            return Err(StateError::TypingSystem {
                phase: "construct_data",
                message: "restored is required".to_string(),
            });
        }

        match state.get("__SEQUENCE_ID").and_then(Value::as_u64) {
            Some(_) => {}
            None => {
                return Err(StateError::TypingSystem {
                    phase: "construct_data",
                    message: "__SEQUENCE_ID must be present".to_string(),
                });
            }
        }

        match state.get("__PRIOR_STEP").and_then(Value::as_str) {
            Some(_) => Ok(Box::new(RoundTripStateData {
                raw: state.clone(),
                fail_construct_state: state
                    .get("fail_construct_state")
                    .and_then(Value::as_bool)
                    .unwrap_or(false),
            })),
            None => Err(StateError::TypingSystem {
                phase: "construct_data",
                message: "__PRIOR_STEP must be present".to_string(),
            }),
        }
    }

    fn construct_state(
        &self,
        data: &(dyn Any + Send + Sync),
    ) -> Result<IndexMap<String, Value>, StateError> {
        let data =
            data.downcast_ref::<RoundTripStateData>()
                .ok_or_else(|| StateError::TypingSystem {
                    phase: "construct_state",
                    message: "expected RoundTripStateData payload".to_string(),
                })?;

        if data.fail_construct_state {
            Err(StateError::TypingSystem {
                phase: "construct_state",
                message: "rebuilding raw state failed".to_string(),
            })
        } else {
            Ok(data.raw.clone())
        }
    }
}

#[derive(Debug, Clone, Default)]
pub(crate) struct NoRoundTripSpyTypingSystem {
    roundtrip_calls: Arc<AtomicUsize>,
    construct_data_calls: Arc<AtomicUsize>,
    construct_state_calls: Arc<AtomicUsize>,
}

impl NoRoundTripSpyTypingSystem {
    pub(crate) fn reset_counts(&self) {
        self.roundtrip_calls.store(0, Ordering::SeqCst);
        self.construct_data_calls.store(0, Ordering::SeqCst);
        self.construct_state_calls.store(0, Ordering::SeqCst);
    }

    pub(crate) fn roundtrip_calls(&self) -> usize {
        self.roundtrip_calls.load(Ordering::SeqCst)
    }

    pub(crate) fn construct_data_calls(&self) -> usize {
        self.construct_data_calls.load(Ordering::SeqCst)
    }

    pub(crate) fn construct_state_calls(&self) -> usize {
        self.construct_state_calls.load(Ordering::SeqCst)
    }
}

impl TypingSystem for NoRoundTripSpyTypingSystem {
    fn construct_data(
        &self,
        _state: &IndexMap<String, Value>,
    ) -> Result<Box<dyn Any + Send + Sync>, StateError> {
        self.construct_data_calls.fetch_add(1, Ordering::SeqCst);
        Err(StateError::TypingSystem {
            phase: "construct_data",
            message: "construct_data should be skipped when validate_roundtrip is overridden"
                .to_string(),
        })
    }

    fn construct_state(
        &self,
        _data: &(dyn Any + Send + Sync),
    ) -> Result<IndexMap<String, Value>, StateError> {
        self.construct_state_calls.fetch_add(1, Ordering::SeqCst);
        Err(StateError::TypingSystem {
            phase: "construct_state",
            message: "construct_state should be skipped when validate_roundtrip is overridden"
                .to_string(),
        })
    }

    fn validate_roundtrip(&self, _state: &IndexMap<String, Value>) -> Result<(), StateError> {
        self.roundtrip_calls.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
}

fn validate_non_negative_count(
    state: &IndexMap<String, Value>,
    phase: &'static str,
) -> Result<(), StateError> {
    match state.get("count").and_then(Value::as_i64) {
        Some(value) if value >= 0 => Ok(()),
        Some(_) => Err(StateError::TypingSystem {
            phase,
            message: "count must stay non-negative".to_string(),
        }),
        None => Err(StateError::TypingSystem {
            phase,
            message: "count must be an integer".to_string(),
        }),
    }
}
