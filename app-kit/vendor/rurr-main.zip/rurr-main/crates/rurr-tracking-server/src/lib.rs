#![deny(missing_docs)]

//! Local HTTP server for browsing Rurr tracking artifacts.
//!
//! The server exposes an Axum application backed by the local tracking-store
//! crate and can serve either the embedded UI bundle or a caller-provided UI
//! directory. The S3 backend uses the same schema behind a local SQLite index
//! plus provider snapshots; it is configured explicitly by CLI/server callers
//! rather than by the default [`app`] constructor.
//!
//! The default [`app`] helper is intentionally local-backend only. Use
//! [`router::AppState`] with a concrete backend when embedding the server with
//! custom storage, S3 indexing, or caller-provided UI assets.
//!
//! S3 support is explicit: callers construct an S3 backend with typed
//! configuration, a local SQLite index path, and provider credentials or SDK
//! environment. The server does not silently promote the default local backend
//! into a provider-backed one.
//!
//! Optional route families are capability-checked. Backends that do not support
//! annotations return typed unsupported-feature responses for annotation reads
//! and writes rather than synthetic empty payloads.

/// Backend traits and local backend implementations.
pub mod backend;
/// HTTP router construction and shared application state.
pub mod router;
/// Public response and query payload models.
pub mod schema;
/// Embedded UI bundle accessors and export helpers.
pub mod ui_assets;
/// Filesystem-backed UI serving helpers.
pub mod ui_fs;

use backend::local::LocalBackend;
use router::AppState;
use rurr_tracking_store::resolve_home_dir_from_env;
use std::path::PathBuf;
use std::sync::Arc;
use thiserror::Error;

/// Errors returned when resolving or pinning the tracking storage root.
#[derive(Debug, Error)]
pub enum StorageRootError {
    /// The process could not resolve a home directory for the default storage root.
    #[error("tracking storage root requires a resolved home directory or explicit --storage-dir")]
    MissingHomeDirectory,
    /// The caller supplied a relative storage path but the current directory could not be read.
    #[error(
        "relative tracking storage root '{path}' requires an available current working directory"
    )]
    RelativePathRequiresCurrentDir {
        /// Relative storage path that could not be pinned.
        path: PathBuf,
        /// Underlying `current_dir` failure.
        #[source]
        source: std::io::Error,
    },
}

/// Returns the default on-disk storage directory used by the local backend.
pub fn default_storage_dir() -> Result<PathBuf, StorageRootError> {
    resolve_home_dir_from_env()
        .map(|home| home.join(".burr"))
        .ok_or(StorageRootError::MissingHomeDirectory)
}

/// Builds the default tracking server router backed by the default local
/// storage directory and embedded UI assets.
pub fn app() -> Result<axum::Router, StorageRootError> {
    let backend = Arc::new(LocalBackend::new(default_storage_dir()?)?);
    let state = AppState::with_embedded_ui(backend);
    Ok(router::app(state))
}

/// Builds the tracking server router from a caller-provided [`AppState`].
pub fn app_with_state(state: AppState) -> axum::Router {
    router::app(state)
}
