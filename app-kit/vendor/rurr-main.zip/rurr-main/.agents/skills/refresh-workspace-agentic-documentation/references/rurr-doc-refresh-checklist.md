# Rurr Documentation Refresh Checklist

Use this checklist during execution after the plan is approved.

## Discovery

1. List tracked Markdown files with `rg --files -g '*.md'`.
2. Inspect the current branch diff versus `main`.
3. Read the living doc map first: `README.md`, `ARCHITECTURE.md`, and `docs/00_overview.md`.
4. Load subsystem or workflow docs only where the diff says they matter.

## Editing order

1. Update living docs that describe the current implementation.
2. Update doc maps and inventories when the doc set changes.
3. Correct archive banners and pointers without rewriting history.
4. Edit `AGENTS*.md` last.

## Rurr-specific checks

- Keep `.agents/skills/README.md` current when the repo-local skill catalog changes.
- Keep `docs/05_documentation_inventory.md` aligned with the actual tracked Markdown set and disposition choices.
- Remove stale references to deleted runtime layers, removed helper crates, or superseded remediation-era names.
- If skill docs change, keep `agents/openai.yaml` metadata aligned with the new `SKILL.md`.

## Verification

1. Stage intended tracked-file changes before manifest refresh when new files are involved.
2. Run `./scripts/fix_manifest_freshness.sh`.
3. Re-stage generated manifest artifacts if they changed.
4. Run `./scripts/check.sh`.
5. Restart Codex only if `AGENTS*.md` changed.
