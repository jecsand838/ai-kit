(() => {
  const NONE_PARTITION = "__none__";
  const state = {
    projects: [],
    selectedProject: null,
    selectedPartition: NONE_PARTITION,
  };

  const node = (id) => document.getElementById(id);

  function text(value) {
    if (value === null || value === undefined || value === "") {
      return "-";
    }
    return String(value);
  }

  function pathSegment(value) {
    return encodeURIComponent(value || NONE_PARTITION);
  }

  function partitionSegment(value) {
    const trimmed = String(value || "").trim();
    return trimmed ? pathSegment(trimmed) : NONE_PARTITION;
  }

  async function fetchJson(url) {
    const response = await fetch(url, {
      headers: { Accept: "application/json" },
    });
    if (!response.ok) {
      throw new Error(`${url} returned ${response.status}`);
    }
    return response.json();
  }

  function setServerStatus(label, isError = false) {
    const status = node("server-status");
    status.textContent = label;
    status.classList.toggle("error", isError);
  }

  function setState(id, message, isError = false) {
    const target = node(id);
    target.textContent = message;
    target.classList.toggle("error", isError);
    target.hidden = false;
  }

  function clearState(id) {
    const target = node(id);
    target.textContent = "";
    target.classList.remove("error");
    target.hidden = true;
  }

  async function loadServerMetadata() {
    const ready = await fetch("/ready", { headers: { Accept: "application/json" } });
    if (!ready.ok) {
      throw new Error(`/ready returned ${ready.status}`);
    }

    const [version, appSpec] = await Promise.all([
      fetchJson("/api/v0/version"),
      fetchJson("/api/v0/metadata/app_spec"),
    ]);
    node("server-summary").textContent = [
      `Burr ${text(version.version)}`,
      `backend ${text(appSpec.backend)}`,
      `storage ${text(appSpec.storage_layout_version)}`,
    ].join(" | ");
    setServerStatus("Ready");
  }

  async function loadProjects() {
    setState("projects-state", "Loading projects...");
    node("project-list").replaceChildren();
    state.projects = await fetchJson("/api/v0/projects");
    renderProjects();

    if (state.projects.length === 0) {
      state.selectedProject = null;
      node("applications-title").textContent = "Applications";
      node("applications-count").textContent = "";
      node("applications-table").hidden = true;
      setState("applications-state", "No projects found.");
      resetDetail("Select an application.");
      return;
    }

    if (
      !state.selectedProject ||
      !state.projects.some((project) => project.id === state.selectedProject)
    ) {
      state.selectedProject = state.projects[0].id;
    }
    renderProjects();
    await loadApplications();
  }

  function renderProjects() {
    const list = node("project-list");
    list.replaceChildren();

    if (state.projects.length === 0) {
      setState("projects-state", "No projects found.");
      return;
    }

    clearState("projects-state");
    for (const project of state.projects) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "project-button";
      button.textContent = project.name;
      button.setAttribute("aria-current", String(project.id === state.selectedProject));
      button.addEventListener("click", async () => {
        state.selectedProject = project.id;
        renderProjects();
        await loadApplications();
      });
      list.append(button);
    }
  }

  async function loadApplications() {
    if (!state.selectedProject) {
      return;
    }

    state.selectedPartition = node("partition-key").value || NONE_PARTITION;
    const project = state.selectedProject;
    const partition = partitionSegment(state.selectedPartition);
    node("applications-title").textContent = project;
    node("applications-count").textContent = "";
    node("applications-table").hidden = true;
    node("application-rows").replaceChildren();
    setState("applications-state", "Loading applications...");
    resetDetail("Select an application.");

    try {
      const page = await fetchJson(
        `/api/v0/${pathSegment(project)}/${partition}/apps?limit=100&offset=0`
      );
      renderApplications(project, page);
    } catch (error) {
      setState("applications-state", String(error), true);
    }
  }

  function renderApplications(project, page) {
    const rows = node("application-rows");
    rows.replaceChildren();
    const applications = Array.isArray(page.applications) ? page.applications : [];
    node("applications-count").textContent = `${applications.length} of ${text(page.total)} loaded`;

    if (applications.length === 0) {
      node("applications-table").hidden = true;
      setState("applications-state", "No applications for this partition.");
      return;
    }

    clearState("applications-state");
    node("applications-table").hidden = false;
    for (const app of applications) {
      const row = document.createElement("tr");
      row.append(
        tableCell(app.app_id, "mono"),
        tableCell(text(app.partition_key)),
        tableCell(text(app.last_written)),
        tableCell(text(app.num_steps), "mono"),
        tableCell(text(Object.keys(app.tags || {}).length), "mono"),
        actionCell(project, app)
      );
      rows.append(row);
    }
  }

  function tableCell(value, className = "") {
    const cell = document.createElement("td");
    cell.textContent = text(value);
    if (className) {
      cell.className = className;
    }
    return cell;
  }

  function actionCell(project, app) {
    const cell = document.createElement("td");
    const button = document.createElement("button");
    button.type = "button";
    button.className = "row-button";
    button.textContent = "Open";
    button.addEventListener("click", async () => {
      await loadAppDetail(project, app.app_id, app.partition_key);
    });
    cell.append(button);
    return cell;
  }

  async function loadAppDetail(project, appId, partitionKey) {
    const partition = partitionKey === null || partitionKey === undefined
      ? NONE_PARTITION
      : partitionSegment(partitionKey);
    setState("detail-state", "Loading application...");
    node("detail-content").hidden = true;

    try {
      const detail = await fetchJson(
        `/api/v0/${pathSegment(project)}/${pathSegment(appId)}/${partition}/apps`
      );
      renderAppDetail(detail, project, appId, partitionKey);
    } catch (error) {
      setState("detail-state", String(error), true);
    }
  }

  function renderAppDetail(detail, project, appId, partitionKey) {
    clearState("detail-state");
    node("detail-content").hidden = false;
    node("detail-title").textContent = appId;
    node("detail-subtitle").textContent = `Sequence ${latestSequence(detail.steps)}`;
    node("detail-project").textContent = text(project);
    node("detail-partition").textContent = text(partitionKey);
    node("detail-entrypoint").textContent = text(detail.application?.entrypoint);
    node("detail-children").textContent = String((detail.children || []).length);
    renderSteps(detail.steps || []);
  }

  function latestSequence(steps) {
    const entries = Array.isArray(steps) ? steps : [];
    for (let index = entries.length - 1; index >= 0; index -= 1) {
      const sequence = entries[index]?.step_start_log?.sequence_id;
      if (sequence !== undefined) {
        return sequence;
      }
    }
    return "-";
  }

  function renderSteps(steps) {
    const target = node("detail-log");
    target.replaceChildren();
    const entries = Array.isArray(steps) ? steps.slice(-6).reverse() : [];

    if (entries.length === 0) {
      const empty = document.createElement("p");
      empty.className = "state";
      empty.textContent = "No steps.";
      target.append(empty);
      return;
    }

    for (const step of entries) {
      const row = document.createElement("div");
      row.className = "log-row";
      const start = step.step_start_log || {};
      row.append(
        logPart(text(start.type), "mono"),
        logPart(text(start.action)),
        logPart(text(start.sequence_id), "mono")
      );
      target.append(row);
    }
  }

  function logPart(value, className = "") {
    const part = document.createElement("span");
    part.textContent = value;
    if (className) {
      part.className = className;
    }
    return part;
  }

  function resetDetail(message) {
    node("detail-title").textContent = "Application Detail";
    node("detail-subtitle").textContent = "";
    node("detail-content").hidden = true;
    setState("detail-state", message);
  }

  async function boot() {
    try {
      setServerStatus("Loading");
      await loadServerMetadata();
      await loadProjects();
    } catch (error) {
      setServerStatus("Error", true);
      setState("projects-state", String(error), true);
      setState("applications-state", "Tracking API is unavailable.", true);
      resetDetail("Application detail is unavailable.");
    }
  }

  node("refresh-projects").addEventListener("click", () => {
    void loadProjects();
  });

  node("partition-form").addEventListener("submit", (event) => {
    event.preventDefault();
    void loadApplications();
  });

  void boot();
})();
