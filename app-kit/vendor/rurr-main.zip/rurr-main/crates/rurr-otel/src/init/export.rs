use super::{OtlpConfig, OtlpEndpoint, OtlpError, OtlpSignal};
use opentelemetry_otlp::{LogExporter, SpanExporter, WithExportConfig};

const OTLP_HTTP_LOGS_PATH: &str = "/v1/logs";
const OTLP_HTTP_TRACES_PATH: &str = "/v1/traces";

pub(crate) fn build_otlp_span_exporter(config: &OtlpConfig) -> Result<SpanExporter, OtlpError> {
    let protocol = config.protocol_for(OtlpSignal::Traces)?;
    let endpoint = exporter_endpoint(config, OtlpSignal::Traces, &protocol)?;
    match protocol {
        opentelemetry_otlp::Protocol::HttpBinary | opentelemetry_otlp::Protocol::HttpJson => {
            SpanExporter::builder()
                .with_http()
                .with_protocol(protocol)
                .with_endpoint(endpoint)
                .build()
        }
        opentelemetry_otlp::Protocol::Grpc => SpanExporter::builder()
            .with_tonic()
            .with_endpoint(endpoint)
            .build(),
    }
    .map_err(|error| OtlpError::ExporterBuild(error.to_string()))
}

pub(crate) fn build_otlp_log_exporter(config: &OtlpConfig) -> Result<LogExporter, OtlpError> {
    let protocol = config.protocol_for(OtlpSignal::Logs)?;
    let endpoint = exporter_endpoint(config, OtlpSignal::Logs, &protocol)?;
    match protocol {
        opentelemetry_otlp::Protocol::HttpBinary | opentelemetry_otlp::Protocol::HttpJson => {
            LogExporter::builder()
                .with_http()
                .with_protocol(protocol)
                .with_endpoint(endpoint)
                .build()
        }
        opentelemetry_otlp::Protocol::Grpc => LogExporter::builder()
            .with_tonic()
            .with_endpoint(endpoint)
            .build(),
    }
    .map_err(|error| OtlpError::ExporterBuild(error.to_string()))
}

pub(super) fn join_otlp_http_path(base_url: &str, path: &str) -> String {
    let path = if base_url.ends_with('/') && path.starts_with('/') {
        path.trim_start_matches('/')
    } else {
        path
    };
    format!("{base_url}{path}")
}

fn exporter_endpoint(
    config: &OtlpConfig,
    signal: OtlpSignal,
    protocol: &opentelemetry_otlp::Protocol,
) -> Result<String, OtlpError> {
    let endpoint = config.endpoint(signal)?;
    Ok(match endpoint {
        OtlpEndpoint::CollectorBaseUrl(base_url)
            if matches!(
                protocol,
                opentelemetry_otlp::Protocol::HttpBinary | opentelemetry_otlp::Protocol::HttpJson
            ) =>
        {
            join_otlp_http_path(&base_url, signal_http_path(signal))
        }
        OtlpEndpoint::CollectorBaseUrl(base_url) => base_url.clone(),
        OtlpEndpoint::SignalUrl(url) => url.clone(),
    })
}

fn signal_http_path(signal: OtlpSignal) -> &'static str {
    match signal {
        OtlpSignal::Traces => OTLP_HTTP_TRACES_PATH,
        OtlpSignal::Logs => OTLP_HTTP_LOGS_PATH,
    }
}
