//! Note to implementers: any non-trivial function that is directly exposed from Python should call
//! Rust code from inside [Python::detach]. This releases the Global Interpreter Lock (GIL) and lets
//! other threads make progress while the Rust code is running.
//!
//! TODO crossing the FFI boundary back to Python to release the GIL might have a noticeable
//!  performance impact, especially when called on methods like [PyTursoStatement::run_io] and
//!  [PyTursoStatement::step], which are meant to be called in a Python loop. We should consider
//!  providing monolithic helpers like `next_row()` that would run a SM to its next row in
//!  Rust-land. This pattern of extracting loops to native code is not uncommon in Python libraries
//!  (e.g. the itertools library), since Python tends to be slow.
use pyo3::{
    prelude::*,
    types::{PyBytes, PyTuple},
};
use std::sync::Arc;
use turso_sdk_kit::rsapi::{self, EncryptionOpts, Numeric, TursoError, TursoStatusCode, Value};
pub use turso_sdk_kit::IoBackend;

use pyo3::create_exception;
use pyo3::exceptions::PyException;

// support equality for status codes
#[pyclass(eq, eq_int, skip_from_py_object)]
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)] // Add necessary traits for your use case
pub enum PyTursoStatusCode {
    Ok = 0,
    Done = 1,
    Row = 2,
    Io = 3,
}
create_exception!(turso, Busy, PyException, "database is locked");
create_exception!(
    turso,
    BusySnapshot,
    PyException,
    "database snapshot is stale"
);
create_exception!(turso, Interrupt, PyException, "interrupted");
create_exception!(turso, Error, PyException, "generic error");
create_exception!(turso, Misuse, PyException, "API misuse");
create_exception!(turso, Constraint, PyException, "constraint error");
create_exception!(turso, Readonly, PyException, "database is readonly");
create_exception!(turso, DatabaseFull, PyException, "database is full");
create_exception!(turso, NotAdb, PyException, "not a database`");
create_exception!(turso, Corrupt, PyException, "database corrupted");
create_exception!(turso, IoError, PyException, "I/O error");

pub(crate) fn turso_error_to_py_err(err: TursoError) -> PyErr {
    match err {
        rsapi::TursoError::Busy(message) => Busy::new_err(message),
        rsapi::TursoError::BusySnapshot(message) => BusySnapshot::new_err(message),
        rsapi::TursoError::Interrupt(message) => Interrupt::new_err(message),
        rsapi::TursoError::Error(message) => Error::new_err(message),
        rsapi::TursoError::Misuse(message) => Misuse::new_err(message),
        rsapi::TursoError::Constraint(message) => Constraint::new_err(message),
        rsapi::TursoError::Readonly(message) => Readonly::new_err(message),
        rsapi::TursoError::DatabaseFull(message) => DatabaseFull::new_err(message),
        rsapi::TursoError::NotAdb(message) => NotAdb::new_err(message),
        rsapi::TursoError::Corrupt(message) => Corrupt::new_err(message),
        rsapi::TursoError::IoError(kind, op) => IoError::new_err(format!("{op}: {kind:?}")),
    }
}

fn turso_status_to_py(status: TursoStatusCode) -> PyTursoStatusCode {
    match status {
        TursoStatusCode::Done => PyTursoStatusCode::Done,
        TursoStatusCode::Row => PyTursoStatusCode::Row,
        TursoStatusCode::Io => PyTursoStatusCode::Io,
    }
}

#[pyclass]
pub struct PyTursoExecutionResult {
    #[pyo3(get)]
    pub status: PyTursoStatusCode,
    #[pyo3(get)]
    pub rows_changed: u64,
}

#[pyclass]
pub struct PyTursoLog {
    #[pyo3(get)]
    pub message: String,
    #[pyo3(get)]
    pub target: String,
    #[pyo3(get)]
    pub file: String,
    #[pyo3(get)]
    pub timestamp: u64,
    #[pyo3(get)]
    pub line: usize,
    #[pyo3(get)]
    pub level: String,
}

#[pyclass]
pub struct PyTursoSetupConfig {
    pub logger: Option<Py<PyAny>>,
    pub log_level: Option<String>,
}

#[pymethods]
impl PyTursoSetupConfig {
    #[new]
    #[pyo3(signature = (logger, log_level))]
    fn new(logger: Option<Py<PyAny>>, log_level: Option<String>) -> Self {
        Self { logger, log_level }
    }
}

#[pyclass(skip_from_py_object)]
#[derive(Clone)]
pub struct PyTursoEncryptionConfig {
    pub cipher: String,
    pub hexkey: String,
}

#[pymethods]
impl PyTursoEncryptionConfig {
    #[new]
    #[pyo3(signature = (cipher, hexkey))]
    fn new(cipher: String, hexkey: String) -> Self {
        Self { cipher, hexkey }
    }
}

#[pyclass]
pub struct PyTursoDatabaseConfig {
    pub path: String,

    /// comma-separated list of experimental features to enable
    /// this field is intentionally just a string in order to make enablement of experimental features as flexible as possible
    pub experimental_features: Option<String>,

    /// optional VFS parameter explicitly specifying FS backend for the database.
    /// Available options are:
    /// - "memory": in-memory backend
    /// - "syscall": generic syscall backend
    /// - "io_uring": IO uring (supported only on Linux)
    pub vfs: IoBackend,

    /// optional encryption parameters
    /// as encryption is experimental - experimental_features must have "encryption" in the list
    pub encryption: Option<PyTursoEncryptionConfig>,
}

#[pymethods]
impl PyTursoDatabaseConfig {
    #[new]
    #[pyo3(signature = (path, experimental_features=None, vfs=None, encryption=None))]
    fn new(
        path: String,
        experimental_features: Option<String>,
        vfs: Option<String>,
        encryption: Option<&PyTursoEncryptionConfig>,
    ) -> Self {
        Self {
            path,
            experimental_features,
            vfs: vfs.map_or(IoBackend::Default, IoBackend::from),
            encryption: encryption.cloned(),
        }
    }
}

#[pyclass]
pub struct PyTursoDatabase {
    database: Arc<rsapi::TursoDatabase>,
}

/// Setup logging for the turso globally
/// Only first invocation has effect - all subsequent updates will be ignored
#[pyfunction]
pub fn py_turso_setup(py: Python, config: &PyTursoSetupConfig) -> PyResult<()> {
    rsapi::turso_setup(rsapi::TursoSetupConfig {
        logger: if let Some(logger) = &config.logger {
            let logger = logger.clone_ref(py);
            Some(Box::new(move |log| {
                Python::attach(|py| {
                    let py_log = PyTursoLog {
                        message: log.message.to_string(),
                        target: log.target.to_string(),
                        file: log.file.to_string(),
                        timestamp: log.timestamp,
                        line: log.line,
                        level: log.level.to_string(),
                    };
                    logger.call1(py, (py_log,)).unwrap();
                })
            }))
        } else {
            None
        },
        log_level: config.log_level.clone(),
    })
    .map_err(turso_error_to_py_err)?;
    Ok(())
}

/// Open the database
#[pyfunction]
pub fn py_turso_database_open(config: &PyTursoDatabaseConfig) -> PyResult<PyTursoDatabase> {
    let database = rsapi::TursoDatabase::new(rsapi::TursoDatabaseConfig {
        path: config.path.clone(),
        experimental_features: config.experimental_features.clone(),
        async_io: false,
        encryption: config.encryption.as_ref().map(|encryption| EncryptionOpts {
            cipher: encryption.cipher.clone(),
            hexkey: encryption.hexkey.clone(),
        }),
        vfs: config.vfs.clone(),
        io: None,
        db_file: None,
        page_codec: None,
        open_flags: Default::default(),
    });
    let result = database.open().map_err(turso_error_to_py_err)?;
    // async_io is false - so db.open() will return result immediately
    assert!(!result.is_io());
    Ok(PyTursoDatabase { database })
}

#[pymethods]
impl PyTursoDatabase {
    pub fn connect(&self) -> PyResult<PyTursoConnection> {
        Ok(PyTursoConnection {
            connection: self.database.connect().map_err(turso_error_to_py_err)?,
        })
    }
}

#[pyclass]
pub struct PyTursoConnection {
    pub(crate) connection: Arc<rsapi::TursoConnection>,
}

#[pymethods]
impl PyTursoConnection {
    /// prepare single statement from the string
    pub fn prepare_single(&self, sql: &str) -> PyResult<PyTursoStatement> {
        Ok(PyTursoStatement {
            statement: self
                .connection
                .prepare_single(sql)
                .map_err(turso_error_to_py_err)?,
        })
    }
    /// prepare first statement from the string which can have multiple statements separated by semicolon
    /// returns None if string has no statements
    /// returns Some with prepared statement and position in the string right after the prepared statement end
    pub fn prepare_first(&self, sql: &str) -> PyResult<Option<(PyTursoStatement, usize)>> {
        match self
            .connection
            .prepare_first(sql)
            .map_err(turso_error_to_py_err)?
        {
            Some((statement, tail_idx)) => Ok(Some((PyTursoStatement { statement }, tail_idx))),
            None => Ok(None),
        }
    }
    /// Get the auto_commmit mode for the connection
    pub fn get_auto_commit(&self) -> PyResult<bool> {
        Ok(self.connection.get_auto_commit())
    }
    /// Rowid of the most recent successful INSERT on this connection.
    pub fn last_insert_rowid(&self) -> i64 {
        self.connection.last_insert_rowid()
    }
    /// Request interruption of the statement currently executing on this connection.
    pub fn interrupt(&self) {
        self.connection.interrupt();
    }
    /// Set the maximum time (in milliseconds) a single statement may run before it
    /// is interrupted and raises [`Interrupt`]. A value of `0` disables the timeout.
    pub fn set_query_timeout(&self, milliseconds: u64) {
        self.connection
            .set_query_timeout(std::time::Duration::from_millis(milliseconds));
    }
    /// Get the current per-statement query timeout in milliseconds (`0` when disabled).
    pub fn get_query_timeout(&self) -> u64 {
        self.connection.get_query_timeout().as_millis() as u64
    }
    /// Close the connection
    /// (caller must ensure that no operations over connection or derived statements will happen after the call)
    pub fn close(&self) -> PyResult<()> {
        self.connection.close().map_err(turso_error_to_py_err)
    }
}

#[pyclass]
pub struct PyTursoStatement {
    statement: Box<rsapi::TursoStatement>,
}

#[pymethods]
impl PyTursoStatement {
    /// binds positional parameters to the statement
    pub fn bind(&mut self, parameters: Bound<PyTuple>) -> PyResult<()> {
        let len = parameters.len();
        for i in 0..len {
            let parameter = parameters.get_item(i)?;
            self.statement
                .bind_positional(i + 1, py_to_db_value(parameter)?)
                .map_err(turso_error_to_py_err)?;
        }
        Ok(())
    }

    /// bind one positional parameter (1-based index)
    pub fn bind_positional(&mut self, index: usize, parameter: Bound<PyAny>) -> PyResult<()> {
        self.statement
            .bind_positional(index, py_to_db_value(parameter)?)
            .map_err(turso_error_to_py_err)?;
        Ok(())
    }

    /// get statement parameter slot by name (e.g. :name, @name, $name, ?1)
    pub fn named_position(&mut self, name: &str) -> PyResult<usize> {
        self.statement
            .named_position(name)
            .map_err(turso_error_to_py_err)
    }

    /// step one iteration of the statement execution
    /// Returns [PyTursoStatusCode::Done] when execution is finished
    /// Returns [PyTursoStatusCode::Row] when execution generated a row which can be consumed with [Self::row] method
    /// Returns [PyTursoStatusCode::Io] when async_io is set and execution needs IO in order to make progress
    ///
    /// The caller must always either use [Self::step] or [Self::execute] methods for single statement - but never mix them together
    pub fn step(&mut self, py: Python) -> PyResult<PyTursoStatusCode> {
        // Release the GIL while the engine runs so other Python threads (parallel
        // readers, or a watchdog calling `interrupt()`) can make progress.
        let status = py
            .detach(|| self.statement.step(None))
            .map_err(turso_error_to_py_err)?;
        Ok(turso_status_to_py(status))
    }

    /// execute statement and ignore all rows generated by it
    /// Returns [PyTursoStatusCode::Done] when execution is finished
    /// Returns [PyTursoStatusCode::Io] when async_io is set and execution needs IO in order to make progress
    ///
    /// Note, that execute never returns Row status code
    ///
    /// The caller must always either use [Self::step] or [Self::execute] methods for single statement - but never mix them together
    pub fn execute(&mut self, py: Python) -> PyResult<PyTursoExecutionResult> {
        // Release the GIL while the engine runs (see `step`).
        let result = py
            .detach(|| self.statement.execute(None))
            .map_err(turso_error_to_py_err)?;
        Ok(PyTursoExecutionResult {
            status: turso_status_to_py(result.status),
            rows_changed: result.rows_changed,
        })
    }
    /// Run one iteration of IO backend
    pub fn run_io(&self, py: Python) -> PyResult<()> {
        // Release the GIL while IO is performed (see `step`).
        py.detach(|| self.statement.run_io())
            .map_err(turso_error_to_py_err)?;
        Ok(())
    }
    /// Get column names of the statement
    pub fn columns(&self, py: Python) -> PyResult<Py<PyTuple>> {
        let columns_count = self.statement.column_count();
        let mut columns = Vec::with_capacity(columns_count);
        for i in 0..columns_count {
            columns.push(
                self.statement
                    .column_name(i)
                    .map_err(turso_error_to_py_err)?
                    .to_string(),
            );
        }
        Ok(PyTuple::new(py, columns.into_iter())?.unbind())
    }
    /// Get tuple with current row values
    /// This method is only valid to call after [Self::step] returned [PyTursoStatusCode::Row] status code
    pub fn row(&self, py: Python) -> PyResult<Py<PyTuple>> {
        let columns_count = self.statement.column_count();
        let mut py_values = Vec::with_capacity(columns_count);
        for i in 0..columns_count {
            py_values.push(db_value_to_py(
                py,
                self.statement.row_value(i).map_err(turso_error_to_py_err)?,
            )?);
        }
        Ok(PyTuple::new(py, &py_values)?.into_pyobject(py)?.into())
    }
    /// Finalize statement execution
    /// This method must be called when statement is no longer need
    /// It will perform necessary cleanup and run any unfinished statement operations to completion
    /// (for example, in `INSERT INTO ... RETURNING ...` query, finalize is essential as it will make sure that all inserts will be completed, even if only few first rows were consumed by the caller)
    ///
    /// Note, that if statement wasn't started (no step / execute methods was called) - finalize will not execute the statement
    pub fn finalize(&mut self, py: Python) -> PyResult<PyTursoStatusCode> {
        // Release the GIL while the engine runs any pending work (see `step`).
        let status = py
            .detach(|| self.statement.finalize(None))
            .map_err(turso_error_to_py_err)?;
        Ok(turso_status_to_py(status))
    }
    /// Reset the statement by clearing bindings and reclaiming memory of the program from previous run
    /// This will also abort last operation if any was unfinished (but if transaction was opened before this statement - its state will be untouched, reset will only affect operation within current statement)
    pub fn reset(&mut self, py: Python) -> PyResult<()> {
        py.detach(|| self.statement.reset().map_err(turso_error_to_py_err))
    }
}

fn db_value_to_py(py: Python, value: Value) -> PyResult<Py<PyAny>> {
    match value {
        Value::Null => Ok(py.None()),
        Value::Numeric(Numeric::Integer(i)) => Ok(i.into_pyobject(py)?.into()),
        Value::Numeric(Numeric::Float(f)) => Ok(f64::from(f).into_pyobject(py)?.into()),
        Value::Text(s) => Ok(s.value.as_ref().into_pyobject(py)?.into()),
        Value::Blob(b) => Ok(PyBytes::new(py, &b).into()),
    }
}

/// Converts a Python object to a Turso Value
fn py_to_db_value(obj: Bound<PyAny>) -> PyResult<Value> {
    if obj.is_none() {
        Ok(Value::Null)
    } else if let Ok(integer) = obj.extract::<i64>() {
        Ok(Value::from_i64(integer))
    } else if let Ok(float) = obj.extract::<f64>() {
        Ok(Value::from_f64(float))
    } else if let Ok(string) = obj.extract::<String>() {
        Ok(Value::Text(string.into()))
    } else if let Ok(bytes) = obj.cast::<PyBytes>() {
        Ok(Value::Blob(bytes.as_bytes().to_vec()))
    } else {
        Err(Error::new_err(
            "unexpected parameter value, only None, numbers, strings and bytes are supported"
                .to_string(),
        ))
    }
}
