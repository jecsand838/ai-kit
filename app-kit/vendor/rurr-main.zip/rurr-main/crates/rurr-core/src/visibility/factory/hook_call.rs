use super::VisibilityError;
use crate::common::panic::panic_payload_to_string;
use crate::lifecycle::LifecycleError;
use futures::FutureExt;
use std::future::Future;
use std::panic::{self, AssertUnwindSafe};

pub(super) fn call_sync_hook(
    hook: &'static str,
    call: impl FnOnce() -> Result<(), LifecycleError>,
) -> Result<(), VisibilityError> {
    let result = panic::catch_unwind(AssertUnwindSafe(call));
    match result {
        Ok(Ok(())) => Ok(()),
        Ok(Err(error)) => Err(VisibilityError::HookFailed {
            hook,
            message: error.to_string(),
        }),
        Err(payload) => Err(VisibilityError::HookPanic {
            hook,
            message: panic_payload_to_string(payload),
        }),
    }
}

pub(super) async fn call_async_hook<Fut>(
    hook: &'static str,
    call: Fut,
) -> Result<(), VisibilityError>
where
    Fut: Future<Output = Result<(), LifecycleError>>,
{
    let result = AssertUnwindSafe(call).catch_unwind().await;
    match result {
        Ok(Ok(())) => Ok(()),
        Ok(Err(error)) => Err(VisibilityError::HookFailed {
            hook,
            message: error.to_string(),
        }),
        Err(payload) => Err(VisibilityError::HookPanic {
            hook,
            message: panic_payload_to_string(payload),
        }),
    }
}
