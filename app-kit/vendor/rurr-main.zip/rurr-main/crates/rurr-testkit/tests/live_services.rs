#![cfg(feature = "live-services")]

use rurr_testkit::live_services::{
    wait_for_mongodb_ready_sync, wait_for_postgres_ready, wait_for_redis_ready, LiveServiceError,
};
use std::time::{Duration, Instant};

#[tokio::test]
async fn invalid_postgres_url_fails_immediately() {
    let start = Instant::now();
    let error = wait_for_postgres_ready("not-a-url")
        .await
        .expect_err("invalid postgres urls must fail");

    assert!(matches!(
        error,
        LiveServiceError::InvalidConfiguration { .. }
    ));
    assert!(
        start.elapsed() < Duration::from_secs(1),
        "invalid postgres urls should fail without retrying"
    );
}

#[tokio::test]
async fn invalid_redis_url_fails_immediately() {
    let start = Instant::now();
    let error = wait_for_redis_ready("not-a-url")
        .await
        .expect_err("invalid redis urls must fail");

    assert!(matches!(
        error,
        LiveServiceError::InvalidConfiguration { .. }
    ));
    assert!(
        start.elapsed() < Duration::from_secs(1),
        "invalid redis urls should fail without retrying"
    );
}

#[test]
fn invalid_mongodb_url_fails_immediately() {
    let start = Instant::now();
    let error =
        wait_for_mongodb_ready_sync("not-a-url").expect_err("invalid mongodb URIs must fail");

    assert!(matches!(
        error,
        LiveServiceError::InvalidConfiguration { .. }
    ));
    assert!(
        start.elapsed() < Duration::from_secs(1),
        "invalid mongodb URIs should fail without retrying"
    );
}
