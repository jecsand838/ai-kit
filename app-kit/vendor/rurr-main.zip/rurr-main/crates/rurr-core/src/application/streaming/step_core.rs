use crate::action::api::{ActionContext, ActionInputs, StreamItem, StreamOutput};
use crate::application::session::ActionExecution;
use crate::application::step_txn::{
    capture_async_panic, capture_sync_panic, commit_async, commit_sync, rollback,
    PreparedInvocation, StepTransaction,
};
use crate::application::{Application, ApplicationError};
use crate::common::drop_finalizer::run_drop_finalizer;
use crate::lifecycle::{StepGuard, StepOutcome, StreamGuard, StreamItemContext};
use crate::state::State;
use futures::{Stream, StreamExt};
use std::pin::Pin;
use std::sync::Arc;

use super::{
    prefer_hook_error, prefer_hook_error_over_primary, stream_invariant, StreamProgress,
    StreamTerminal,
};

pub(super) type SharedActionInputs = Arc<ActionInputs>;
type SyncStepSource = Box<dyn Iterator<Item = StreamOutput>>;
type AsyncStepSource = Pin<Box<dyn Stream<Item = StreamOutput>>>;
type StepStartError<'a> = (Box<ApplicationError>, &'a mut Application);
type TerminalCommit<'a> = (&'a mut Application, &'a mut StepTransaction, String, State);
type PollFinish = (Option<ApplicationError>, GuardSet);

enum StepTransition {
    PostItem(StreamItem),
    Commit {
        item: StreamItem,
        final_state: State,
    },
    Finish(Box<PollFinish>),
}

struct GuardSet {
    step_guard: Option<StepGuard>,
    stream_guard: Option<StreamGuard>,
}

#[derive(Clone, Copy)]
struct StepLane {
    missing_app_on_commit: &'static str,
    missing_app_on_return: &'static str,
    missing_source: &'static str,
    missing_terminal: &'static str,
}

const SYNC_STEP_LANE: StepLane = StepLane {
    missing_app_on_commit: "sync step execution missing app on commit",
    missing_app_on_return: "sync step execution missing app while returning to session",
    missing_source: "sync step execution missing source",
    missing_terminal: "sync step execution missing terminal",
};

const ASYNC_STEP_LANE: StepLane = StepLane {
    missing_app_on_commit: "async step execution missing app on commit",
    missing_app_on_return: "async step execution missing app while returning to session",
    missing_source: "async step execution missing source",
    missing_terminal: "async step execution missing terminal",
};

pub(super) struct StepCore<'a> {
    app: Option<&'a mut Application>,
    invocation: PreparedInvocation,
    inputs: SharedActionInputs,
    step_guard: Option<StepGuard>,
    stream_guard: Option<StreamGuard>,
    item_index: usize,
    progress: StreamProgress,
}

impl<'a> StepCore<'a> {
    fn is_done(&self) -> bool {
        self.progress.is_done()
    }

    fn start_invocation(
        app: &Application,
        execution: ActionExecution,
    ) -> Result<PreparedInvocation, ApplicationError> {
        PreparedInvocation::new(app, execution)
    }

    fn start_sync(
        app: &'a mut Application,
        execution: ActionExecution,
        inputs: SharedActionInputs,
    ) -> Result<Self, StepStartError<'a>> {
        let invocation = match Self::start_invocation(app, execution) {
            Ok(invocation) => invocation,
            Err(error) => return Err((Box::new(error), app)),
        };
        let (step_guard, stream_guard) =
            match invocation.start_sync_stream_guards(app, inputs.as_ref()) {
                Ok(guards) => guards,
                Err(error) => return Err((Box::new(error), app)),
            };

        Ok(Self::from_started_parts(
            app,
            invocation,
            inputs,
            step_guard,
            stream_guard,
        ))
    }

    async fn start_async(
        app: &'a mut Application,
        execution: ActionExecution,
        inputs: SharedActionInputs,
    ) -> Result<Self, StepStartError<'a>> {
        let invocation = match Self::start_invocation(app, execution) {
            Ok(invocation) => invocation,
            Err(error) => return Err((Box::new(error), app)),
        };
        let (step_guard, stream_guard) = match invocation
            .start_async_stream_guards(app, inputs.as_ref())
            .await
        {
            Ok(guards) => guards,
            Err(error) => return Err((Box::new(error), app)),
        };

        Ok(Self::from_started_parts(
            app,
            invocation,
            inputs,
            step_guard,
            stream_guard,
        ))
    }

    fn from_started_parts(
        app: &'a mut Application,
        invocation: PreparedInvocation,
        inputs: SharedActionInputs,
        step_guard: StepGuard,
        stream_guard: StreamGuard,
    ) -> Self {
        Self {
            app: Some(app),
            invocation,
            inputs,
            step_guard: Some(step_guard),
            stream_guard: Some(stream_guard),
            item_index: 0,
            progress: StreamProgress::new(None),
        }
    }

    fn begin_terminal_transition(&mut self) {
        self.progress.begin_finalizing();
    }

    fn transition_for_poll(&mut self, output: Option<StreamOutput>) -> StepTransition {
        match output {
            Some(Ok((item, Some(final_state)))) => StepTransition::Commit { item, final_state },
            Some(Ok((item, None))) => StepTransition::PostItem(item),
            Some(Err(error)) => {
                let error = map_stream_error(error);
                let guards = prepare_rollback(self, Some(error.to_string()));
                StepTransition::Finish(Box::new((Some(error), guards)))
            }
            None => StepTransition::Finish(Box::new((None, prepare_rollback(self, None)))),
        }
    }

    fn prepare_terminal_commit(
        &mut self,
        lane: StepLane,
        final_state: State,
    ) -> Result<TerminalCommit<'_>, ApplicationError> {
        self.begin_terminal_transition();
        let action_name = self.invocation.action_name().to_string();
        let StepCore {
            app, invocation, ..
        } = self;
        let app = app
            .as_deref_mut()
            .ok_or_else(|| stream_invariant(lane.missing_app_on_commit))?;
        let transaction = invocation.transaction_mut();
        Ok((app, transaction, action_name, final_state))
    }

    fn mark_streaming_started(&mut self) {
        self.progress.mark_streaming_started();
    }

    fn make_action_context(&self) -> ActionContext {
        self.invocation.action_context(self.inputs.as_ref().clone())
    }

    fn source_start_parts(&self) -> (crate::graph::GraphAction, ActionContext, State) {
        (
            self.invocation.action().clone(),
            self.make_action_context(),
            self.invocation.working_state().clone(),
        )
    }

    fn item_context(&self) -> StreamItemContext {
        StreamItemContext::new(
            self.invocation.action_name(),
            self.invocation.sequence_id(),
            self.invocation.sequence_id(),
            self.item_index,
        )
        .with_app_id(self.invocation.app_id().to_string())
    }

    fn note_item_posted(&mut self) {
        self.item_index += 1;
    }

    fn finish_terminal_success(&mut self, terminal_result: Option<StreamItem>, app_state: State) {
        if let (Some(step_guard), Some(result)) =
            (self.step_guard.as_mut(), terminal_result.clone())
        {
            step_guard.record_outcome(StepOutcome::Success {
                result,
                state: app_state.clone(),
            });
        }
        self.progress
            .finish_with_terminal((terminal_result, app_state));
    }

    fn complete_posted_item(
        &mut self,
        post_result: Result<(), ApplicationError>,
        item: StreamItem,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        post_result?;
        self.note_item_posted();
        Ok(Some(item))
    }

    fn begin_rollback_terminal(&mut self, exception: Option<String>) {
        self.begin_terminal_transition();
        self.cache_rollback_terminal(exception);
    }

    fn cache_rollback_terminal(&mut self, exception: Option<String>) {
        if self.progress.is_done() {
            return;
        }
        if let Some(exception) = exception {
            self.invocation
                .record_optional_step_error(&mut self.step_guard, exception);
        }
        if let Some(app) = self.app.as_deref_mut() {
            rollback(app, self.invocation.transaction_mut());
        }
        self.progress
            .cache_current_state_if_missing(self.app.as_deref());
        self.progress.mark_done();
    }

    fn terminal(&self, lane: StepLane) -> Result<StreamTerminal, ApplicationError> {
        self.progress.terminal_or_invariant(lane.missing_terminal)
    }

    fn rollback_for_drop(&mut self, exception: Option<String>) {
        self.begin_rollback_terminal(exception);
        self.drop_guards();
    }

    fn drop_guards(&mut self) {
        let _ = self.step_guard.take();
        let _ = self.stream_guard.take();
    }

    fn take_app(&mut self, lane: StepLane) -> Result<&'a mut Application, ApplicationError> {
        self.app
            .take()
            .ok_or_else(|| stream_invariant(lane.missing_app_on_return))
    }
}

fn source_or_invariant<T>(
    source: &mut Option<T>,
    lane: StepLane,
) -> Result<&mut T, ApplicationError> {
    source
        .as_mut()
        .ok_or_else(|| stream_invariant(lane.missing_source))
}

fn ensure_source_started<T>(
    source: &mut Option<T>,
    create_source: impl FnOnce() -> Result<T, ApplicationError>,
) -> Result<bool, ApplicationError> {
    if source.is_some() {
        return Ok(false);
    }

    *source = Some(create_source()?);
    Ok(true)
}

fn take_guard_set(core: &mut StepCore<'_>) -> GuardSet {
    GuardSet {
        step_guard: core.step_guard.take(),
        stream_guard: core.stream_guard.take(),
    }
}

fn prepare_rollback(core: &mut StepCore<'_>, exception: Option<String>) -> GuardSet {
    core.begin_rollback_terminal(exception);
    take_guard_set(core)
}

fn finish_sync_guard_set(guards: GuardSet) -> Result<(), ApplicationError> {
    if let Some(step_guard) = guards.step_guard {
        step_guard.finish_sync()?;
    }
    if let Some(stream_guard) = guards.stream_guard {
        stream_guard.finish_sync()?;
    }
    Ok(())
}

async fn finish_async_guard_set(guards: GuardSet) -> Result<(), ApplicationError> {
    if let Some(step_guard) = guards.step_guard {
        step_guard.finish_async().await?;
    }
    if let Some(stream_guard) = guards.stream_guard {
        stream_guard.finish_async().await?;
    }
    Ok(())
}

fn sync_post_item_result(core: &StepCore<'_>) -> Result<(), ApplicationError> {
    let item_context = core.item_context();
    if let Some(stream_guard) = &core.stream_guard {
        stream_guard
            .post_stream_item_sync(&item_context)
            .map_err(Into::into)
    } else {
        Ok(())
    }
}

async fn async_post_item_result(core: &StepCore<'_>) -> Result<(), ApplicationError> {
    let item_context = core.item_context();
    if let Some(stream_guard) = &core.stream_guard {
        stream_guard
            .post_stream_item_async(&item_context)
            .await
            .map_err(Into::into)
    } else {
        Ok(())
    }
}

fn finish_poll(
    error: Option<ApplicationError>,
    guard_result: Result<(), ApplicationError>,
) -> Result<Option<StreamItem>, ApplicationError> {
    match error {
        Some(error) => Err(prefer_hook_error_over_primary(error, guard_result)),
        None => prefer_hook_error(Ok(None), guard_result),
    }
}

fn finish_sync_poll((error, guards): PollFinish) -> Result<Option<StreamItem>, ApplicationError> {
    finish_poll(error, finish_sync_guard_set(guards))
}

async fn finish_async_poll(
    (error, guards): PollFinish,
) -> Result<Option<StreamItem>, ApplicationError> {
    finish_poll(error, finish_async_guard_set(guards).await)
}

fn sync_terminal_commit_poll(
    core: &mut StepCore<'_>,
    item: StreamItem,
    final_state: State,
) -> Result<Option<StreamItem>, ApplicationError> {
    let app_state = {
        let (app, transaction, action_name, final_state) =
            core.prepare_terminal_commit(SYNC_STEP_LANE, final_state)?;
        match commit_sync(app, transaction, &action_name, final_state) {
            Ok(state) => state,
            Err(error) => {
                let rollback_result =
                    finish_sync_guard_set(prepare_rollback(core, Some(error.to_string())));
                return Err(prefer_hook_error_over_primary(error, rollback_result));
            }
        }
    };
    core.finish_terminal_success(Some(item), app_state);
    let finish_result = finish_sync_guard_set(take_guard_set(core));
    finish_result?;
    Ok(None)
}

async fn async_terminal_commit_poll(
    core: &mut StepCore<'_>,
    item: StreamItem,
    final_state: State,
) -> Result<Option<StreamItem>, ApplicationError> {
    let app_state = {
        let (app, transaction, action_name, final_state) =
            core.prepare_terminal_commit(ASYNC_STEP_LANE, final_state)?;
        match commit_async(app, transaction, &action_name, final_state).await {
            Ok(state) => state,
            Err(error) => {
                let rollback_result =
                    finish_async_guard_set(prepare_rollback(core, Some(error.to_string()))).await;
                return Err(prefer_hook_error_over_primary(error, rollback_result));
            }
        }
    };
    core.finish_terminal_success(Some(item), app_state);
    let finish_result = finish_async_guard_set(take_guard_set(core)).await;
    finish_result?;
    Ok(None)
}

fn resolve_sync_poll(
    core: &mut StepCore<'_>,
    output: Option<StreamOutput>,
) -> Result<Option<StreamItem>, ApplicationError> {
    match core.transition_for_poll(output) {
        StepTransition::PostItem(item) => {
            let post_result = sync_post_item_result(core);
            core.complete_posted_item(post_result, item)
        }
        StepTransition::Commit { item, final_state } => {
            sync_terminal_commit_poll(core, item, final_state)
        }
        StepTransition::Finish(finish) => finish_sync_poll(*finish),
    }
}

async fn resolve_async_poll(
    core: &mut StepCore<'_>,
    output: Option<StreamOutput>,
) -> Result<Option<StreamItem>, ApplicationError> {
    match core.transition_for_poll(output) {
        StepTransition::PostItem(item) => {
            let post_result = async_post_item_result(core).await;
            core.complete_posted_item(post_result, item)
        }
        StepTransition::Commit { item, final_state } => {
            async_terminal_commit_poll(core, item, final_state).await
        }
        StepTransition::Finish(finish) => finish_async_poll(*finish).await,
    }
}

fn drive_sync_next_item(
    core: &mut StepCore<'_>,
    source: &mut Option<SyncStepSource>,
) -> Result<Option<StreamItem>, ApplicationError> {
    if core.is_done() {
        return Ok(None);
    }

    let started = ensure_source_started(source, || {
        let (action, action_context, state) = core.source_start_parts();
        match capture_sync_panic("streaming.sync.start", || -> Result<_, ApplicationError> {
            Ok(action.action().stream_run_erased(state, action_context))
        }) {
            Ok(result) => result,
            Err(error) => {
                let rollback_result =
                    finish_sync_guard_set(prepare_rollback(core, Some(exception_message(&error))));
                Err(prefer_hook_error_over_primary(error, rollback_result))
            }
        }
    })?;
    if started {
        core.mark_streaming_started();
    }
    let stream = source_or_invariant(source, SYNC_STEP_LANE)?;
    let output =
        match capture_sync_panic("streaming.sync.next", || -> Result<_, ApplicationError> {
            Ok(stream.next())
        }) {
            Ok(result) => result?,
            Err(error) => {
                let rollback_result =
                    finish_sync_guard_set(prepare_rollback(core, Some(exception_message(&error))));
                return Err(prefer_hook_error_over_primary(error, rollback_result));
            }
        };
    resolve_sync_poll(core, output)
}

async fn drive_async_next_item(
    core: &mut StepCore<'_>,
    source: &mut Option<AsyncStepSource>,
) -> Result<Option<StreamItem>, ApplicationError> {
    if core.is_done() {
        return Ok(None);
    }

    if source.is_none() {
        let (action, action_context, state) = core.source_start_parts();
        let created_source = match capture_async_panic("streaming.async.start", async move {
            action
                .action()
                .stream_run_async_erased(state, action_context)
        })
        .await
        {
            Ok(result) => result,
            Err(error) => {
                let rollback_result =
                    finish_async_guard_set(prepare_rollback(core, Some(exception_message(&error))))
                        .await;
                return Err(prefer_hook_error_over_primary(error, rollback_result));
            }
        };
        *source = Some(created_source);
        core.mark_streaming_started();
    }
    let stream = source_or_invariant(source, ASYNC_STEP_LANE)?;
    let output =
        match capture_async_panic("streaming.async.next", async { stream.next().await }).await {
            Ok(result) => result,
            Err(error) => {
                let rollback_result =
                    finish_async_guard_set(prepare_rollback(core, Some(exception_message(&error))))
                        .await;
                return Err(prefer_hook_error_over_primary(error, rollback_result));
            }
        };
    resolve_async_poll(core, output).await
}

fn take_app_after_terminal<'a>(
    shared: &mut StepCore<'a>,
    lane: StepLane,
    terminal_result: Result<StreamTerminal, ApplicationError>,
) -> (
    Result<StreamTerminal, ApplicationError>,
    Result<&'a mut Application, ApplicationError>,
) {
    let app_result = shared.take_app(lane);
    (terminal_result, app_result)
}

fn take_app_after_abort<'a>(
    shared: &mut StepCore<'a>,
    lane: StepLane,
    abort_result: Result<(), ApplicationError>,
) -> (
    Result<&'a mut Application, ApplicationError>,
    Result<(), ApplicationError>,
) {
    let app_result = shared.take_app(lane);
    (app_result, abort_result)
}

pub(super) struct SyncStepExecution<'a> {
    shared: StepCore<'a>,
    source: Option<SyncStepSource>,
}

impl<'a> SyncStepExecution<'a> {
    pub(super) fn new(
        app: &'a mut Application,
        execution: ActionExecution,
        inputs: SharedActionInputs,
    ) -> Result<Self, StepStartError<'a>> {
        Ok(Self {
            shared: StepCore::start_sync(app, execution, inputs)?,
            source: None,
        })
    }

    pub(super) fn next_item(&mut self) -> Result<Option<StreamItem>, ApplicationError> {
        drive_sync_next_item(&mut self.shared, &mut self.source)
    }

    pub(super) fn get(&mut self) -> Result<StreamTerminal, ApplicationError> {
        while self.next_item()?.is_some() {}
        self.shared.terminal(SYNC_STEP_LANE)
    }

    pub(super) fn complete_and_take_app(
        self,
    ) -> (
        Result<StreamTerminal, ApplicationError>,
        Result<&'a mut Application, ApplicationError>,
    ) {
        let mut this = self;
        let terminal_result = this.get();
        take_app_after_terminal(&mut this.shared, SYNC_STEP_LANE, terminal_result)
    }

    pub(super) fn abort_and_take_app_with_hook_result(
        self,
    ) -> (
        Result<&'a mut Application, ApplicationError>,
        Result<(), ApplicationError>,
    ) {
        let mut this = self;
        let abort_result = finish_sync_guard_set(prepare_rollback(&mut this.shared, None));
        take_app_after_abort(&mut this.shared, SYNC_STEP_LANE, abort_result)
    }
}

impl Drop for SyncStepExecution<'_> {
    fn drop(&mut self) {
        run_drop_finalizer(|| {
            let _ = finish_sync_guard_set(prepare_rollback(&mut self.shared, None));
        });
    }
}

#[must_use]
pub(super) struct AsyncStepExecution<'a> {
    shared: StepCore<'a>,
    source: Option<AsyncStepSource>,
}

impl<'a> AsyncStepExecution<'a> {
    pub(super) async fn new(
        app: &'a mut Application,
        execution: ActionExecution,
        inputs: SharedActionInputs,
    ) -> Result<Self, StepStartError<'a>> {
        Ok(Self {
            shared: StepCore::start_async(app, execution, inputs).await?,
            source: None,
        })
    }

    pub(super) async fn next_item(&mut self) -> Result<Option<StreamItem>, ApplicationError> {
        drive_async_next_item(&mut self.shared, &mut self.source).await
    }

    pub(super) async fn get(&mut self) -> Result<StreamTerminal, ApplicationError> {
        while self.next_item().await?.is_some() {}
        self.shared.terminal(ASYNC_STEP_LANE)
    }

    pub(super) async fn complete_and_take_app(
        self,
    ) -> (
        Result<StreamTerminal, ApplicationError>,
        Result<&'a mut Application, ApplicationError>,
    ) {
        let mut this = self;
        let terminal_result = this.get().await;
        take_app_after_terminal(&mut this.shared, ASYNC_STEP_LANE, terminal_result)
    }

    pub(super) async fn abort_and_take_app_with_hook_result(
        self,
    ) -> (
        Result<&'a mut Application, ApplicationError>,
        Result<(), ApplicationError>,
    ) {
        let mut this = self;
        let abort_result = finish_async_guard_set(prepare_rollback(&mut this.shared, None)).await;
        take_app_after_abort(&mut this.shared, ASYNC_STEP_LANE, abort_result)
    }

    pub(super) fn abort_sync_only_and_take_app(
        self,
    ) -> Result<&'a mut Application, ApplicationError> {
        let mut this = self;
        this.shared.rollback_for_drop(None);
        this.shared.take_app(ASYNC_STEP_LANE)
    }
}

impl Drop for AsyncStepExecution<'_> {
    fn drop(&mut self) {
        self.shared.rollback_for_drop(None);
    }
}

fn exception_message(error: &ApplicationError) -> String {
    match error {
        ApplicationError::PanicCaptured { message, .. } => message.clone(),
        _ => error.to_string(),
    }
}

fn map_stream_error(error: crate::action::api::RurrError) -> ApplicationError {
    match error {
        crate::action::api::RurrError::Action(source) => ApplicationError::Action(source),
        crate::action::api::RurrError::Message(message) => {
            ApplicationError::StreamingActionFailed { message }
        }
    }
}
