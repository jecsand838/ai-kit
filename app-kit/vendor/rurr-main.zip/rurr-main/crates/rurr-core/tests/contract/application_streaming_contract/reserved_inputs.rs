use super::*;
use super::{actions::*, builders::*, cases::counting_hooks, hooks::StreamAbortHookCounts};
use rurr_core::application::ExecutionOptions;

fn reserved_runtime_inputs() -> IndexMap<String, serde_json::Value> {
    map_from_pairs([
        ("__context", json!({"forged": true})),
        ("__tracer", json!("forged")),
    ])
}

async fn assert_stream_result_rejects_user_supplied_reserved_runtime_inputs(mode: StreamMode) {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(Arc::clone(&stream_calls), 1, None);
    let mut app = build_streaming_app(action).expect("app should build");
    let inputs = reserved_runtime_inputs();

    let error = match mode
        .stream_result(&mut app, ExecutionOptions::new().with_inputs(inputs))
        .await
    {
        Ok(_) => panic!("reserved runtime inputs should be rejected"),
        Err(error) => error,
    };
    assert!(matches!(
        error,
        ApplicationError::ReservedRuntimeInputKeys { keys }
            if keys == vec!["__context".to_string(), "__tracer".to_string()]
    ));
    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);
}

async fn assert_stream_iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next_step(
    mode: StreamMode,
) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(Arc::clone(&stream_calls), 1, None);
    let mut app =
        build_streaming_app_with_hooks(action, counting_hooks(&counts)).expect("app should build");
    let inputs = reserved_runtime_inputs();

    let mut iterate = mode
        .stream_iterate(&mut app, ExecutionOptions::new().with_inputs(inputs))
        .await;
    let error = match iterate.next_step().await {
        Ok(_) => panic!("reserved runtime inputs should be rejected"),
        Err(error) => error,
    };
    assert!(matches!(
        error,
        ApplicationError::ReservedRuntimeInputKeys { keys }
            if keys == vec!["__context".to_string(), "__tracer".to_string()]
    ));
    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 0);
}

sync_stream_cases! {
    stream_result_rejects_user_supplied_reserved_runtime_inputs =>
        assert_stream_result_rejects_user_supplied_reserved_runtime_inputs(StreamMode::Sync),
    stream_iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next_step =>
        assert_stream_iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next_step(StreamMode::Sync)
}
async_stream_cases! {
    astream_result_rejects_user_supplied_reserved_runtime_inputs =>
        assert_stream_result_rejects_user_supplied_reserved_runtime_inputs(StreamMode::Async),
    astream_iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next_step =>
        assert_stream_iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next_step(StreamMode::Async)
}
