mod support;

use rurr_telemetry::{capture_cli_command, is_telemetry_enabled};
use rurr_testkit::env::EnvVarGuard;
use rurr_testkit::live_services::reset_otel_file_exports;
use std::fs;
use tempfile::tempdir;

#[tokio::test(flavor = "multi_thread")]
async fn config_write_failure_disables_telemetry_without_exporting() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let home = tempdir().expect("tempdir should create");
    let config_path = home.path().join(".rurr.conf");
    fs::write(&config_path, "[DEFAULT]\ntelemetry_enabled = true\n")
        .expect("config file should write");
    let mut permissions = fs::metadata(&config_path)
        .expect("config metadata should read")
        .permissions();
    permissions.set_readonly(true);
    fs::set_permissions(&config_path, permissions).expect("config should become read-only");
    let docker_config = support::inherited_docker_config();

    {
        let _env = EnvVarGuard::set([
            (
                "HOME",
                Some(home.path().to_str().expect("home path should be utf-8")),
            ),
            ("USERPROFILE", None),
            ("HOMEDRIVE", None),
            ("HOMEPATH", None),
            ("DOCKER_CONFIG", docker_config.as_deref()),
            ("BURR_TELEMETRY_ENABLED", Some("true")),
            ("OTEL_EXPORTER_OTLP_ENDPOINT", Some("http://127.0.0.1:4318")),
            ("OTEL_EXPORTER_OTLP_PROTOCOL", Some("http/protobuf")),
        ]);

        assert!(
            !is_telemetry_enabled(),
            "config write failure should leave telemetry disabled"
        );
        capture_cli_command("serve");
        support::assert_no_cli_telemetry_exports("config write failure").await;
    }
}
