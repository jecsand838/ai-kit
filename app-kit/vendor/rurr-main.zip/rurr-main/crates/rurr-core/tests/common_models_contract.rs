use indexmap::IndexMap;
use rurr_core::action::{ActionContext, ActionError, ActionResult, LocalAction};
use rurr_core::state::State;
use rurr_core::tracking::{ActionModel, TrackingError};

#[derive(Debug, Clone)]
struct ActionWithCustomSource {
    name: Option<String>,
}

impl ActionWithCustomSource {
    fn new() -> Self {
        Self { name: None }
    }
}

impl LocalAction for ActionWithCustomSource {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn source_code(&self) -> Option<String> {
        Some("custom source code".to_string())
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }

        let mut cloned = self.clone();
        cloned.name = Some(next_name);
        Ok(cloned)
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
    }
}

#[derive(Debug, Clone)]
struct ActionWithoutSource {
    name: Option<String>,
}

impl ActionWithoutSource {
    fn new() -> Self {
        Self { name: None }
    }
}

impl LocalAction for ActionWithoutSource {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }

        let mut cloned = self.clone();
        cloned.name = Some(next_name);
        Ok(cloned)
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
    }
}

#[test]
fn action_with_custom_source_is_reflected_in_action_model() {
    let action = ActionWithCustomSource::new()
        .with_name("foo")
        .expect("action should be named");

    let model = ActionModel::from_action(&action).expect("action model should build");
    assert_eq!(model.code, "custom source code");
}

#[test]
fn action_model_rejects_actions_without_provable_source() {
    let action = ActionWithoutSource::new()
        .with_name("source-less")
        .expect("action should be named");

    let error = ActionModel::from_action(&action).expect_err("source-less action should fail");
    assert!(matches!(
        error,
        TrackingError::MissingActionSource { action } if action == "source-less"
    ));
}
