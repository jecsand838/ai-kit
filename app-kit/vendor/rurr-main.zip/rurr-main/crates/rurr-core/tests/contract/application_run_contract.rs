use super::support::application::{
    assert_execute_drive_startup_error_prefers_post_execute_call_failure,
    assert_execute_drive_startup_error_still_fires_execute_call_hooks, assert_invalid_halt_actions,
    assert_iterate_advances_once_then_terminates,
    assert_iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next,
    assert_iterate_startup_error_prefers_post_execute_call_failure,
    assert_iterate_startup_error_still_fires_execute_call_hooks,
    assert_iterate_startup_failure_exhausts_iterator_after_pre_execute_hook_error,
    assert_no_execute_hooks, assert_reserved_runtime_inputs_rejected,
    assert_run_advances_to_expected_terminal_or_pending_action, async_counter_action,
    async_counter_with_inputs_action, count_zero_state, counter_action, counter_with_inputs_action,
    counting_hooks_for_run, halt_after_terminal_tag, halt_before_terminal_tag,
    invalid_halt_options, iterate_expectation, run_expectation, single_halt_validation_app,
    sync_counting_hooks, sync_panicking_post_execute_hooks, tagged_counter_run_app,
    ApplicationScenario, ExecuteContextRecorder, ExecuteDriveMode, HookCounts,
    ReservedRuntimeInputCase, RunMode, StepMode, RUN_HALT_ACTIONS,
};
use crate::test_support::{run_subprocess_fixture, subprocess_fixture_enabled};
use rurr_core::action::{ActionInputs, Condition, FunctionActionBuilder};
use rurr_core::application::{ApplicationBuilder, ApplicationError, ExecutionOptions};
use rurr_core::graph::Transition;
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_testkit::application_fixture::{map_from_pairs, state_from_pairs};
use serde_json::{json, Value};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

fn single_counter_scenario() -> Result<ApplicationScenario, ApplicationError> {
    ApplicationScenario::single_action(count_zero_state(), "counter", counter_action())
}

fn build_single_counter_app() -> rurr_core::Application {
    single_counter_scenario()
        .and_then(ApplicationScenario::build)
        .expect("app should build")
}

fn build_two_step_app() -> rurr_core::Application {
    ApplicationScenario::two_action_transition(
        count_zero_state(),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", Condition::default())],
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build")
}

fn build_three_step_app() -> rurr_core::Application {
    tagged_counter_run_app(RunMode::Sync)
}

fn build_two_step_app_for_mode(mode: RunMode) -> rurr_core::Application {
    match mode {
        RunMode::Sync => build_two_step_app(),
        RunMode::Async => ApplicationScenario::two_action_transition(
            count_zero_state(),
            "A",
            async_counter_action(),
            "B",
            async_counter_action(),
            vec![Transition::new("A", "B", Condition::default())],
        )
        .and_then(ApplicationScenario::build)
        .expect("app should build"),
    }
}

fn build_input_run_app_for_mode(mode: RunMode) -> rurr_core::Application {
    let first = match mode {
        RunMode::Sync => counter_with_inputs_action("additional_increment"),
        RunMode::Async => async_counter_with_inputs_action("additional_increment"),
    };
    let second = match mode {
        RunMode::Sync => counter_action(),
        RunMode::Async => async_counter_action(),
    };
    let result = match mode {
        RunMode::Sync => counter_action(),
        RunMode::Async => async_counter_action(),
    };

    ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![
            ("counter1", first),
            ("counter2", second),
            ("result", result),
        ])
        .expect("actions should configure")
        .with_transitions(vec![
            Transition::new("counter1", "counter2", Condition::default()),
            Transition::new("counter2", "result", Condition::default()),
        ])
        .expect("transitions should configure")
        .with_entrypoint("counter1")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build")
}

fn build_input_iterate_app() -> rurr_core::Application {
    ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![
            (
                "counter1",
                counter_with_inputs_action("additional_increment"),
            ),
            ("counter2", counter_action()),
        ])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "counter1",
            "counter2",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_entrypoint("counter1")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build")
}

fn assert_run_outputs_match(direct: &rurr_core::RunOutput, runner: &rurr_core::RunOutput) {
    assert_eq!(
        direct
            .action
            .as_ref()
            .map(|action| action.name().to_string()),
        runner
            .action
            .as_ref()
            .map(|action| action.name().to_string())
    );
    assert_eq!(direct.result, runner.result);
    assert_eq!(direct.state, runner.state);
}

async fn assert_run_direct_matches_runner(
    mode: RunMode,
    build_app: impl Fn() -> rurr_core::Application,
    options: ExecutionOptions,
) {
    let mut direct = build_app();
    let mut runner = build_app();

    let direct_output = match mode {
        RunMode::Sync => direct
            .run_with_options(options.clone())
            .expect("direct run should succeed"),
        RunMode::Async => direct
            .arun_with_options(options.clone())
            .await
            .expect("direct run should succeed"),
    };
    let runner_output = match mode {
        RunMode::Sync => runner
            .run_with_options(options)
            .expect("runner run should succeed"),
        RunMode::Async => runner
            .arun_with_options(options)
            .await
            .expect("runner run should succeed"),
    };

    assert_run_outputs_match(&direct_output, &runner_output);
    assert_eq!(direct.state(), runner.state());
}

async fn run_for_mode(
    mode: RunMode,
    app: &mut rurr_core::Application,
    options: ExecutionOptions,
) -> Result<rurr_core::RunOutput, ApplicationError> {
    match mode {
        RunMode::Sync => app.run_with_options(options),
        RunMode::Async => app.arun_with_options(options).await,
    }
}

async fn assert_run_halt_after_tag_expands_to_first_matching_action(mode: RunMode) {
    let mut app = tagged_counter_run_app(mode);
    let output = run_for_mode(mode, &mut app, halt_after_terminal_tag())
        .await
        .expect("run should halt after first tagged action");

    assert_eq!(
        output.action.as_ref().map(|action| action.name()),
        Some("B")
    );
    assert_eq!(
        output.result.as_ref().and_then(|item| item.get("count")),
        Some(&json!(2))
    );
    assert_eq!(output.state.get("count"), Some(&json!(2)));
}

async fn assert_run_halt_before_tag_returns_pending_action_without_executing_target(mode: RunMode) {
    let mut app = tagged_counter_run_app(mode);
    let output = run_for_mode(mode, &mut app, halt_before_terminal_tag())
        .await
        .expect("run should halt before first tagged action");

    assert_eq!(
        output.action.as_ref().map(|action| action.name()),
        Some("B")
    );
    assert!(
        output.result.is_none(),
        "halt_before target should be returned without executing"
    );
    assert_eq!(output.state.get("count"), Some(&json!(1)));
}

async fn assert_run_unknown_halt_actions_fail_before_execution(mode: RunMode) {
    let counts = Arc::new(HookCounts::default());
    let hooks = counting_hooks_for_run(mode, Arc::clone(&counts));
    let mut app = single_halt_validation_app(mode, hooks);

    let error = run_for_mode(mode, &mut app, invalid_halt_options())
        .await
        .expect_err("unknown halt selectors should fail before execution");

    assert_invalid_halt_actions(error, RUN_HALT_ACTIONS);
    assert_eq!(app.state().get("count"), Some(&json!(0)));
    assert_no_execute_hooks(&counts);
}

fn assert_iterate_halt_after_tag_expands_to_first_matching_action() {
    let mut app = tagged_counter_run_app(RunMode::Sync);
    let (steps, state) = collect_iterate_summary(&mut app, halt_after_terminal_tag());

    assert_eq!(
        steps,
        vec![
            ("A".to_string(), Some(json!(1)), false),
            ("B".to_string(), Some(json!(2)), true),
        ]
    );
    assert_eq!(state.get("count"), Some(&json!(2)));
}

fn assert_iterate_halt_before_tag_stops_without_executing_target() {
    let mut app = tagged_counter_run_app(RunMode::Sync);
    let (steps, state) = collect_iterate_summary(&mut app, halt_before_terminal_tag());

    assert_eq!(steps, vec![("A".to_string(), Some(json!(1)), false)]);
    assert_eq!(state.get("count"), Some(&json!(1)));
}

fn assert_iterate_unknown_halt_actions_fail_on_first_next_before_execution() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_counting_hooks(Arc::clone(&counts));
    let mut app = single_halt_validation_app(RunMode::Sync, hooks);

    let mut iter = app.iterate_with_options(invalid_halt_options());
    let error = iter
        .next()
        .expect("first iterate call should yield startup error")
        .expect_err("unknown halt selectors should fail before execution");

    assert_invalid_halt_actions(error, RUN_HALT_ACTIONS);
    drop(iter);
    assert_eq!(app.state().get("count"), Some(&json!(0)));
    assert_no_execute_hooks(&counts);
}

fn collect_iterate_summary(
    app: &mut rurr_core::Application,
    options: ExecutionOptions,
) -> (Vec<(String, Option<Value>, bool)>, rurr_core::State) {
    let mut steps = Vec::new();

    {
        let mut iter = app.iterate_with_options(options);
        for step in &mut iter {
            let step = step.expect("iterate step should succeed");
            steps.push((
                step.action.name().to_string(),
                step.result.get("count").cloned(),
                step.halted,
            ));
        }
    }

    (steps, app.state().clone())
}

fn build_resumed_two_step_app_with_transition(
    transition_condition: Condition,
    sequence_id: u64,
) -> rurr_core::Application {
    ApplicationBuilder::new()
        .with_state(state_from_pairs([
            ("flag", json!(true)),
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(sequence_id)),
        ]))
        .expect("state should configure")
        .with_actions(vec![("A", counter_action()), ("B", counter_action())])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new("A", "B", transition_condition)])
        .expect("transitions should configure")
        .with_entrypoint("A")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build")
}

fn assert_resumed_two_step_state(app: &rurr_core::Application, sequence_id: u64) {
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert_eq!(
        app.state().get("__SEQUENCE_ID").cloned(),
        Some(json!(sequence_id))
    );
    assert_eq!(app.state().get("__PRIOR_STEP").cloned(), Some(json!("A")));
}

const ITERATE_POST_EXECUTE_FAILURE_MARKER: &str = "intentional_iterate_post_execute_failure";
const ITERATE_PRE_EXECUTE_FAILURE_MARKER: &str = "intentional_iterate_pre_execute_failure";

macro_rules! run_contract_case {
    ($name:ident => $body:expr $(,)?) => {
        #[test]
        fn $name() {
            $body;
        }
    };
}

macro_rules! run_contract_cases {
    ($($name:ident => $body:expr),+ $(,)?) => {
        $(run_contract_case!($name => $body);)+
    };
}

macro_rules! sync_run_case {
    ($name:ident => $body:expr $(,)?) => {
        #[test]
        fn $name() {
            futures::executor::block_on($body);
        }
    };
}

macro_rules! iterate_case {
    ($name:ident, $app:expr, $options:expr, $expectation:expr $(,)?) => {
        #[test]
        fn $name() {
            assert_iterate_advances_once_then_terminates($app, $options, $expectation);
        }
    };
}

macro_rules! iterate_cases {
    ($($name:ident, $app:expr, $options:expr, $expectation:expr),+ $(,)?) => {
        $(iterate_case!($name, $app, $options, $expectation);)+
    };
}

macro_rules! run_case {
    ($name:ident, $app:expr, $options:expr, $expectation:expr $(,)?) => {
        #[test]
        fn $name() {
            assert_run_advances_to_expected_terminal_or_pending_action(
                $app,
                $options,
                $expectation,
            );
        }
    };
}

macro_rules! run_cases {
    ($($name:ident, $app:expr, $options:expr, $expectation:expr),+ $(,)?) => {
        $(run_case!($name, $app, $options, $expectation);)+
    };
}

#[test]
fn iterate_drop_during_unwind_panicking_post_execute_hook_does_not_abort_process() {
    run_subprocess_fixture(
        "contract::application_run_contract::iterate_drop_during_unwind_panicking_post_execute_hook_fixture",
    );
}

#[test]
fn iterate_drop_during_unwind_panicking_post_execute_hook_fixture() {
    if !subprocess_fixture_enabled() {
        return;
    }

    let counts = Arc::new(HookCounts::default());
    let hooks = sync_panicking_post_execute_hooks(Arc::clone(&counts));
    let mut app = ApplicationScenario::two_action_transition(
        state_from_pairs([("count", json!(0))]),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", Condition::default())],
    )
    .map(|scenario| scenario.with_hooks(hooks))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let panic_result = catch_unwind(AssertUnwindSafe(|| {
        let mut iter = app.iterate();
        let _ = iter
            .next()
            .expect("first iterate call should produce one step")
            .expect("first step should succeed");
        panic!("intentional outer panic while iterate handle is alive");
    }));

    assert!(panic_result.is_err(), "outer panic should be catchable");
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
}

iterate_cases! {
    iterate_stops_when_no_next_action_exists,
    build_single_counter_app(),
    ExecutionOptions::new(),
    iterate_expectation("counter", 1, false, 1, Some(0), None),
    iterate_stops_on_halt_before_action,
    build_two_step_app(),
    ExecutionOptions::new().halt_before(["B"]),
    iterate_expectation("A", 1, false, 1, None, Some("A")),
    iterate_halt_before_entrypoint_executes_once_then_stops,
    build_single_counter_app(),
    ExecutionOptions::new().halt_before(["counter"]),
    iterate_expectation("counter", 1, false, 1, Some(0), Some("counter")),
    iterate_stops_on_halt_after_action,
    build_two_step_app(),
    ExecutionOptions::new().halt_after(["A"]),
    iterate_expectation("A", 1, true, 1, None, None),
    iterate_halt_before_resolved_next_action_executes_once_then_stops,
    ApplicationScenario::two_action_transition(
        state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(41)),
        ]),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", Condition::default())],
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build"),
    ExecutionOptions::new().halt_before(["B"]),
    iterate_expectation("B", 1, false, 1, Some(42), Some("B")),
    iterate_halt_before_precedes_halt_after_when_both_match,
    build_two_step_app(),
    ExecutionOptions::new().halt_before(["B"]).halt_after(["A"]),
    iterate_expectation("A", 1, false, 1, None, None)
}

#[test]
fn iterate_execute_context_tracks_resolved_next_action_and_reserved_sequence_when_resumed() {
    let records: Arc<Mutex<Vec<(String, u64)>>> = Arc::new(Mutex::new(Vec::new()));
    let hooks = LifecycleAdapterSet::new(
        vec![Arc::new(ExecuteContextRecorder::new(Arc::clone(&records)))],
        Vec::new(),
    );
    let mut app = ApplicationScenario::two_action_transition(
        state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(41)),
        ]),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", Condition::default())],
    )
    .map(|scenario| scenario.with_hooks(hooks))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let mut iter = app.iterate();
    let first = iter
        .next()
        .expect("first iterate call should produce one step")
        .expect("first step should succeed");

    assert_eq!(first.action.name(), "B");
    assert_eq!(
        records
            .lock()
            .expect("records lock should not be poisoned")
            .as_slice(),
        &[("B".to_string(), 42)]
    );
}

#[test]
fn iterate_drop_before_first_next_does_not_emit_execute_context_when_never_started() {
    let records: Arc<Mutex<Vec<(String, u64)>>> = Arc::new(Mutex::new(Vec::new()));
    let hooks = LifecycleAdapterSet::new(
        vec![Arc::new(ExecuteContextRecorder::new(Arc::clone(&records)))],
        Vec::new(),
    );
    let mut app = ApplicationScenario::two_action_transition(
        state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(41)),
        ]),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", Condition::default())],
    )
    .map(|scenario| scenario.with_hooks(hooks))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    {
        let _iter = app.iterate();
    }

    assert_eq!(
        records
            .lock()
            .expect("records lock should not be poisoned")
            .as_slice(),
        &[]
    );
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert_eq!(app.state().get("__SEQUENCE_ID").cloned(), Some(json!(41)));
    assert_eq!(app.state().get("__PRIOR_STEP").cloned(), Some(json!("A")));
}

run_cases! {
    run_stops_when_no_next_action_exists,
    build_single_counter_app(),
    ExecutionOptions::new(),
    run_expectation("counter", Some(1), 1, None, None),
    run_stops_on_halt_before_action,
    build_two_step_app(),
    ExecutionOptions::new().halt_before(["B"]),
    run_expectation("B", None, 1, None, None),
    run_halt_before_entrypoint_executes_once_and_returns_terminal_step,
    build_single_counter_app(),
    ExecutionOptions::new().halt_before(["counter"]),
    run_expectation("counter", Some(1), 1, Some(0), Some("counter")),
    run_halt_before_resumed_action_executes_once_and_returns_terminal_step,
    ApplicationScenario::two_action_transition(
        state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(41)),
        ]),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", Condition::default())],
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build"),
    ExecutionOptions::new().halt_before(["B"]),
    run_expectation("B", Some(1), 1, Some(42), Some("B")),
    run_stops_on_halt_after_action,
    build_two_step_app(),
    ExecutionOptions::new().halt_after(["A"]),
    run_expectation("A", Some(1), 1, None, None),
    run_halt_before_precedes_halt_after_when_both_match,
    build_two_step_app(),
    ExecutionOptions::new().halt_before(["B"]).halt_after(["A"]),
    run_expectation("B", None, 1, None, None),
    run_halt_after_accepts_multiple_actions,
    build_three_step_app(),
    ExecutionOptions::new().halt_after(["B", "C"]),
    run_expectation("B", Some(2), 2, None, None)
}

sync_run_case!(
    run_halt_after_tag_expands_to_first_matching_action =>
        assert_run_halt_after_tag_expands_to_first_matching_action(RunMode::Sync)
);
sync_run_case!(
    arun_halt_after_tag_expands_to_first_matching_action =>
        assert_run_halt_after_tag_expands_to_first_matching_action(RunMode::Async)
);
sync_run_case!(
    run_halt_before_tag_returns_pending_action_without_executing_target =>
        assert_run_halt_before_tag_returns_pending_action_without_executing_target(RunMode::Sync)
);
sync_run_case!(
    arun_halt_before_tag_returns_pending_action_without_executing_target =>
        assert_run_halt_before_tag_returns_pending_action_without_executing_target(RunMode::Async)
);
sync_run_case!(
    run_unknown_halt_actions_fail_before_execution =>
        assert_run_unknown_halt_actions_fail_before_execution(RunMode::Sync)
);
sync_run_case!(
    arun_unknown_halt_actions_fail_before_execution =>
        assert_run_unknown_halt_actions_fail_before_execution(RunMode::Async)
);

run_contract_case!(
    iterate_halt_after_tag_expands_to_first_matching_action =>
        assert_iterate_halt_after_tag_expands_to_first_matching_action()
);
run_contract_case!(
    iterate_halt_before_tag_stops_without_executing_target =>
        assert_iterate_halt_before_tag_stops_without_executing_target()
);
run_contract_case!(
    iterate_unknown_halt_actions_fail_on_first_next_before_execution =>
        assert_iterate_unknown_halt_actions_fail_on_first_next_before_execution()
);

#[test]
fn iterate_is_lazy_and_does_not_execute_on_creation() {
    let call_count = Arc::new(AtomicUsize::new(0));
    let action = FunctionActionBuilder::new()
        .writes(["count"])
        .build_sync({
            let call_count = Arc::clone(&call_count);
            move |state, _ctx| {
                call_count.fetch_add(1, Ordering::SeqCst);
                let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
                map_from_pairs([("count", json!(count))])
            }
        })
        .expect("action should build");

    let mut app = ApplicationScenario::single_action(
        state_from_pairs([("count", json!(0))]),
        "counter",
        action,
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    assert_eq!(call_count.load(Ordering::SeqCst), 0);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    let mut iter = app.iterate();

    let _ = iter
        .next()
        .expect("first iterate call should produce one step")
        .expect("first step should succeed");
    assert_eq!(call_count.load(Ordering::SeqCst), 1);
}

#[test]
fn iterate_fires_post_execute_call_once_on_exhaustion() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_counting_hooks(Arc::clone(&counts));

    let mut app = single_counter_scenario()
        .map(|scenario| scenario.with_hooks(hooks))
        .and_then(ApplicationScenario::build)
        .expect("app should build");

    let mut iter = app.iterate();
    let _ = iter
        .next()
        .expect("first iterate call should produce one step")
        .expect("first step should succeed");
    assert!(iter.next().is_none(), "iterator should be exhausted");
    assert!(iter.next().is_none(), "iterator should stay exhausted");

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
}

#[test]
fn iterate_drop_after_start_fires_post_execute_call_once() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_counting_hooks(Arc::clone(&counts));

    let mut app = ApplicationScenario::two_action_transition(
        state_from_pairs([("count", json!(0))]),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", Condition::default())],
    )
    .map(|scenario| scenario.with_hooks(hooks))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    {
        let mut iter = app.iterate();
        let _ = iter
            .next()
            .expect("first iterate call should produce one step")
            .expect("first step should succeed");
    }

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
}

#[test]
fn iterate_drop_before_first_next_does_not_fire_execute_hooks() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_counting_hooks(Arc::clone(&counts));

    let mut app = single_counter_scenario()
        .map(|scenario| scenario.with_hooks(hooks))
        .and_then(ApplicationScenario::build)
        .expect("app should build");

    {
        let _iter = app.iterate();
    }

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 0);
}

run_contract_cases! {
    iterate_startup_failure_exhausts_iterator_after_pre_execute_hook_error =>
        assert_iterate_startup_failure_exhausts_iterator_after_pre_execute_hook_error(
            ITERATE_PRE_EXECUTE_FAILURE_MARKER,
        ),
    iterate_startup_error_prefers_post_execute_call_failure =>
        assert_iterate_startup_error_prefers_post_execute_call_failure(
            ITERATE_POST_EXECUTE_FAILURE_MARKER,
        )
}

#[test]
fn iterate_startup_errors_still_fire_execute_call_hooks() {
    assert_iterate_startup_error_still_fires_execute_call_hooks(
        state_from_pairs([("__SEQUENCE_ID", json!("bad-seq"))]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::InvalidSequenceIdType { .. }
            ))
        },
        |_| {},
    );
    assert_iterate_startup_error_still_fires_execute_call_hooks(
        state_from_pairs([("__SEQUENCE_ID", json!(0)), ("__PRIOR_STEP", json!(12))]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::InvalidPriorStepType { .. }
            ))
        },
        |_| {},
    );
    assert_iterate_startup_error_still_fires_execute_call_hooks(
        state_from_pairs([
            ("__SEQUENCE_ID", json!(0)),
            ("__PRIOR_STEP", json!("missing")),
        ]),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::Graph(rurr_core::graph::GraphError::ActionNotFound {
                    action_name,
                    ..
                }) if action_name == "missing"
            ));
        },
        |app| {
            assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("missing")));
            assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
        },
    );
}

#[test]
fn run_startup_errors_still_fire_execute_call_hooks() {
    futures::executor::block_on(
        assert_execute_drive_startup_error_still_fires_execute_call_hooks(
            ExecuteDriveMode::Run,
            StepMode::Sync,
            state_from_pairs([("__SEQUENCE_ID", json!("bad-seq"))]),
            |error| {
                assert!(matches!(
                    error,
                    ApplicationError::InvalidSequenceIdType { .. }
                ))
            },
            |_| {},
        ),
    );
    futures::executor::block_on(
        assert_execute_drive_startup_error_still_fires_execute_call_hooks(
            ExecuteDriveMode::Run,
            StepMode::Sync,
            state_from_pairs([("__SEQUENCE_ID", json!(0)), ("__PRIOR_STEP", json!(12))]),
            |error| {
                assert!(matches!(
                    error,
                    ApplicationError::InvalidPriorStepType { .. }
                ))
            },
            |_| {},
        ),
    );
    futures::executor::block_on(
        assert_execute_drive_startup_error_still_fires_execute_call_hooks(
            ExecuteDriveMode::Run,
            StepMode::Sync,
            state_from_pairs([
                ("__SEQUENCE_ID", json!(0)),
                ("__PRIOR_STEP", json!("missing")),
            ]),
            |error| {
                assert!(matches!(
                    error,
                    ApplicationError::Graph(rurr_core::graph::GraphError::ActionNotFound {
                        action_name,
                        ..
                    }) if action_name == "missing"
                ));
            },
            |app| {
                assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("missing")));
                assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
            },
        ),
    );
}

#[test]
fn run_startup_error_prefers_post_execute_call_failure() {
    futures::executor::block_on(
        assert_execute_drive_startup_error_prefers_post_execute_call_failure(
            ExecuteDriveMode::Run,
            StepMode::Sync,
            ITERATE_POST_EXECUTE_FAILURE_MARKER,
        ),
    );
}

#[test]
fn iterate_drop_before_first_next_keeps_state_machine_lazy() {
    let call_count = Arc::new(AtomicUsize::new(0));
    let action = FunctionActionBuilder::new()
        .writes(["count"])
        .build_sync({
            let call_count = Arc::clone(&call_count);
            move |state, _ctx| {
                call_count.fetch_add(1, Ordering::SeqCst);
                let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
                map_from_pairs([("count", json!(count))])
            }
        })
        .expect("action should build");

    let mut app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![("counter", action)])
        .expect("action should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");

    {
        let _iter = app.iterate();
    }

    assert_eq!(call_count.load(Ordering::SeqCst), 0);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
    assert!(!app.state().contains_key("__PRIOR_STEP"));
}

#[test]
fn iterate_drop_before_first_next_does_not_evaluate_transition_conditions() {
    let evaluation_count = Arc::new(AtomicUsize::new(0));
    let transition_condition = Condition::new(
        ["flag"],
        {
            let evaluation_count = Arc::clone(&evaluation_count);
            move |_state| {
                evaluation_count.fetch_add(1, Ordering::SeqCst);
                true
            }
        },
        "flag_counter",
    );

    let mut app = build_resumed_two_step_app_with_transition(transition_condition, 41);

    {
        let _iter = app.iterate();
    }

    assert_eq!(
        evaluation_count.load(Ordering::SeqCst),
        0,
        "drop before first next should not evaluate transitions"
    );
    assert_resumed_two_step_state(&app, 41);
}

#[test]
fn iterate_drop_before_first_next_does_not_panic_from_transition_predicate() {
    let transition_condition = Condition::new(
        ["flag"],
        |_state| panic!("transition predicate should not run on drop-before-next"),
        "panic_if_evaluated",
    );

    let mut app = build_resumed_two_step_app_with_transition(transition_condition, 41);

    let drop_result = catch_unwind(AssertUnwindSafe(|| {
        let _iter = app.iterate();
    }));

    assert!(
        drop_result.is_ok(),
        "drop before first next should not execute transition predicates"
    );
    assert_resumed_two_step_state(&app, 41);
}

#[test]
fn iterate_creation_does_not_evaluate_next_transition() {
    let evaluation_count = Arc::new(AtomicUsize::new(0));
    let transition_condition = Condition::new(
        ["flag"],
        {
            let evaluation_count = Arc::clone(&evaluation_count);
            move |_state| {
                evaluation_count.fetch_add(1, Ordering::SeqCst);
                true
            }
        },
        "flag_counter",
    );

    let mut app = build_resumed_two_step_app_with_transition(transition_condition, 0);

    let mut iter = app.iterate();
    assert_eq!(
        evaluation_count.load(Ordering::SeqCst),
        0,
        "iterate creation should not evaluate transitions"
    );

    let _ = iter
        .next()
        .expect("first iterate call should produce one step")
        .expect("first step should succeed");
    assert_eq!(evaluation_count.load(Ordering::SeqCst), 1);
}

#[test]
fn run_reuses_inputs_across_steps() {
    let mut app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![
            (
                "counter1",
                counter_with_inputs_action("additional_increment"),
            ),
            (
                "counter2",
                counter_with_inputs_action("additional_increment"),
            ),
            ("result", counter_action()),
        ])
        .expect("actions should configure")
        .with_transitions(vec![
            Transition::new("counter1", "counter2", Condition::default()),
            Transition::new("counter2", "result", Condition::default()),
        ])
        .expect("transitions should configure")
        .with_entrypoint("counter1")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");

    let mut inputs = ActionInputs::new();
    inputs.insert("additional_increment".to_string(), json!(10));

    let output = app
        .run_with_options(
            rurr_core::ExecutionOptions::new()
                .with_inputs(inputs)
                .halt_after(["result"]),
        )
        .expect("run should succeed");

    let action = output
        .action
        .expect("run should return executed action for halt_after");
    let result = output.result.expect("run should return terminal result");

    assert_eq!(action.name(), "result");
    assert_eq!(result.get("count"), Some(&json!(21)));
    assert_eq!(output.state.get("count").cloned(), Some(json!(21)));
}

#[test]
fn iterate_propagates_action_errors() {
    let async_only = FunctionActionBuilder::new()
        .writes(["count"])
        .build_async(|_state, _ctx| async move { map_from_pairs([("count", json!(1))]) })
        .expect("async action should build");

    let mut app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![("async_only", async_only)])
        .expect("action should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("async_only")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");

    let mut iter = app.iterate();
    let error = iter
        .next()
        .expect("first iterate call should yield an error item")
        .expect_err("sync iterate should fail on async-only action");

    assert!(matches!(
        error,
        ApplicationError::Action(rurr_core::action::ActionError::AsyncActionRequiresRunAsync)
    ));
    assert!(
        iter.next().is_none(),
        "iterator should terminate after error"
    );
}

sync_run_case!(
    run_rejects_user_supplied_reserved_runtime_inputs =>
        assert_reserved_runtime_inputs_rejected(RunMode::Sync, ReservedRuntimeInputCase::RunDirect)
);
run_contract_case!(
    iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next =>
        assert_iterate_rejects_user_supplied_reserved_runtime_inputs_on_first_next()
);

#[tokio::test]
async fn run_succeeds_when_called_inside_tokio_runtime() {
    let mut app = build_two_step_app();
    let output = app.run().expect("run should succeed");

    let action = output
        .action
        .expect("run should return final executed action");
    let result = output.result.expect("run should return terminal result");
    assert_eq!(action.name(), "B");
    assert_eq!(result.get("count"), Some(&json!(2)));
    assert_eq!(output.state.get("count").cloned(), Some(json!(2)));
}

#[test]
fn run_commits_application_inspection_state_at_terminal_output() {
    let mut app = build_two_step_app();

    assert!(app
        .has_next_action()
        .expect("initial next action lookup should succeed"));

    let output = app.run().expect("run should execute to completion");

    assert_eq!(
        app.sequence_id().expect("sequence_id should resolve"),
        Some(1)
    );
    assert!(!app
        .has_next_action()
        .expect("terminal next action lookup should succeed"));

    let context = app.context().expect("context should resolve after run");
    assert_eq!(context.sequence_id, Some(1));
    assert_eq!(context.prior_step.as_deref(), Some("B"));
    assert_eq!(output.state.get("__PRIOR_STEP"), Some(&json!("B")));
}

sync_run_case!(
    run_direct_execution_options_match_runner_defaults =>
        assert_run_direct_matches_runner(
            RunMode::Sync,
            || build_two_step_app_for_mode(RunMode::Sync),
            ExecutionOptions::new(),
        )
);

sync_run_case!(
    run_direct_execution_options_match_runner_with_inputs_and_halts =>
        assert_run_direct_matches_runner(
            RunMode::Sync,
            || build_input_run_app_for_mode(RunMode::Sync),
            ExecutionOptions::new()
                .with_inputs([("additional_increment", json!(10))])
                .halt_after(["result"]),
        )
);

sync_run_case!(
    arun_direct_execution_options_match_runner_defaults =>
        assert_run_direct_matches_runner(
            RunMode::Async,
            || build_two_step_app_for_mode(RunMode::Async),
            ExecutionOptions::new(),
        )
);

sync_run_case!(
    arun_direct_execution_options_match_runner_with_inputs_and_halts =>
        assert_run_direct_matches_runner(
            RunMode::Async,
            || build_input_run_app_for_mode(RunMode::Async),
            ExecutionOptions::new()
                .with_inputs([("additional_increment", json!(10))])
                .halt_after(["result"]),
        )
);

#[test]
fn iterate_direct_execution_options_match_runner_defaults() {
    let mut direct = build_two_step_app();
    let mut runner = build_two_step_app();

    let (direct_steps, direct_state) =
        collect_iterate_summary(&mut direct, ExecutionOptions::new());
    let (runner_steps, runner_state) =
        collect_iterate_summary(&mut runner, ExecutionOptions::new());

    assert_eq!(direct_steps, runner_steps);
    assert_eq!(direct_state, runner_state);
}

#[test]
fn iterate_direct_execution_options_match_runner_with_inputs_and_halts() {
    let mut direct = build_input_iterate_app();
    let mut runner = build_input_iterate_app();
    let options = ExecutionOptions::new()
        .with_inputs([("additional_increment", json!(10))])
        .halt_after(["counter1"]);

    let (direct_steps, direct_state) = collect_iterate_summary(&mut direct, options.clone());
    let (runner_steps, runner_state) = collect_iterate_summary(&mut runner, options);

    assert_eq!(direct_steps, runner_steps);
    assert_eq!(direct_state, runner_state);
}
