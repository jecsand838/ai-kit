use indexmap::IndexMap;
use rurr_core::{
    ActionError, FunctionAction, FunctionActionBuilder, GraphAction, LocalAction, State,
};
use serde_json::{json, Value};
use std::io;

/// Error type used by the streaming parity example helpers.
pub type ExampleError = Box<dyn std::error::Error + Send + Sync>;
/// Result type used by the streaming parity example helpers.
pub type ExampleResult<T> = Result<T, ExampleError>;

pub(super) const CAPTURE_PROMPT: &str = "capture_prompt";
pub(super) const STREAMING_RESPONSE: &str = "streaming_response";

pub(super) fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
    pairs
        .into_iter()
        .map(|(key, value)| (key.to_string(), value))
        .collect()
}

pub(super) fn prompt_inputs(prompt: &str) -> IndexMap<String, Value> {
    map_from_pairs([("prompt", json!(prompt))])
}

pub(super) fn response_item(text: &str) -> IndexMap<String, Value> {
    map_from_pairs([("response", json!(text))])
}

pub(super) fn response_text(item: &IndexMap<String, Value>) -> ExampleResult<String> {
    item.get("response")
        .and_then(Value::as_str)
        .map(ToOwned::to_owned)
        .ok_or_else(|| io::Error::other("stream item should contain response text").into())
}

pub(super) fn named_graph_action<A>(name: &str, action: A) -> ExampleResult<GraphAction>
where
    A: LocalAction + Send + Sync + 'static,
{
    Ok(GraphAction::new(action.with_name(name)?)?)
}

pub(super) fn build_capture_prompt_action() -> Result<FunctionAction, ActionError> {
    FunctionActionBuilder::new()
        .inputs(["prompt"])
        .writes(["prompt"])
        .build_sync(|_state, ctx| {
            let prompt = ctx
                .inputs
                .get("prompt")
                .and_then(Value::as_str)
                .unwrap_or_default();
            map_from_pairs([("prompt", json!(prompt))])
        })
}

pub(super) fn prompt_from_state(state: &State) -> String {
    state
        .get("prompt")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string()
}
