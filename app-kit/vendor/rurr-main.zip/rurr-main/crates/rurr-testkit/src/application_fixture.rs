//! Full-application fixtures and helper builders for tests.
//!
//! These helpers are the fastest way to stand up small sync or async
//! applications with realistic graphs, hooks, persistence specs, and tracking
//! configuration while keeping test code short and deterministic.

use indexmap::IndexMap;
use rurr_core::action::{
    ActionContext, ActionInputs, Condition, FunctionAction, FunctionActionBuilder, LocalAction,
};
use rurr_core::application::{Application, ApplicationBuilder, ApplicationError, TrackerSpec};
use rurr_core::graph::{Graph, Transition};
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::parallelism::ParallelExecutor;
use rurr_core::state::{register_field_serde, State, StateError};
use rurr_persistence::{
    ApplicationPersistenceSpec, AsyncBaseStatePersister, BaseStatePersister, StatePersisterSpec,
};
use serde_json::{json, Value};
use std::sync::Arc;

/// Builds an owned JSON map from fixed key/value pairs.
pub fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
    pairs
        .into_iter()
        .map(|(key, value)| (key.to_string(), value))
        .collect()
}

/// Registers a string field-serde pair that prefixes serialized values with `prefix`.
pub fn register_prefixed_string_field_serde(
    field_name: &str,
    prefix: &str,
) -> Result<(), StateError> {
    let serializer_prefix = prefix.to_string();
    let deserializer_prefix = prefix.to_string();

    register_field_serde(
        field_name,
        move |value| {
            let text = value
                .as_str()
                .map(str::to_string)
                .unwrap_or_else(|| value.to_string());
            json!({"value": format!("{serializer_prefix}{text}")})
        },
        move |value| {
            let text = value
                .get("value")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .strip_prefix(&deserializer_prefix)
                .unwrap_or_else(|| {
                    value
                        .get("value")
                        .and_then(Value::as_str)
                        .unwrap_or_default()
                })
                .to_string();
            json!(text)
        },
    )
}

/// Builds a [`State`] from fixed key/value pairs.
pub fn state_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> State {
    State::new(map_from_pairs(pairs))
}

/// Builds [`ActionInputs`] from fixed key/value pairs.
pub fn inputs_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> ActionInputs {
    map_from_pairs(pairs)
}

/// Returns a synchronous counter action that increments `count` by one.
pub fn counter_action() -> FunctionAction {
    build_counter_action(CounterMode::Sync, None, std::iter::empty::<&str>())
}

/// Returns a synchronous counter action with action tags.
///
/// # Examples
///
/// ```
/// use rurr_core::LocalAction;
/// use rurr_testkit::application_fixture::counter_action_with_tags;
///
/// let action = counter_action_with_tags(&["checkpoint"]);
/// let tags: Vec<_> = action.tags().iter().map(String::as_str).collect();
/// assert_eq!(tags, ["checkpoint"]);
/// ```
pub fn counter_action_with_tags(tags: &[&str]) -> FunctionAction {
    build_counter_action(CounterMode::Sync, None, tags.iter().copied())
}

/// Returns a synchronous counter action that reads its delta from one input.
pub fn counter_with_inputs_action(input_name: &'static str) -> FunctionAction {
    build_counter_action(
        CounterMode::Sync,
        Some(input_name),
        std::iter::empty::<&str>(),
    )
}

/// Returns an asynchronous counter action that increments `count` by one.
pub fn async_counter_action() -> FunctionAction {
    build_counter_action(CounterMode::Async, None, std::iter::empty::<&str>())
}

/// Returns an asynchronous counter action with action tags.
///
/// The returned action is useful for async contract tests that need
/// `@tag:<tag>` halt controls without duplicating action setup.
pub fn async_counter_action_with_tags(tags: &[&str]) -> FunctionAction {
    build_counter_action(CounterMode::Async, None, tags.iter().copied())
}

/// Returns an asynchronous counter action that reads its delta from one input.
pub fn async_counter_with_inputs_action(input_name: &'static str) -> FunctionAction {
    build_counter_action(
        CounterMode::Async,
        Some(input_name),
        std::iter::empty::<&str>(),
    )
}

/// Execution lane for reusable counter application fixtures.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CounterMode {
    /// Build synchronous counter actions.
    Sync,
    /// Build asynchronous counter actions.
    Async,
}

impl CounterMode {
    fn action_with_tags(self, tags: &[&str]) -> FunctionAction {
        match self {
            Self::Sync => counter_action_with_tags(tags),
            Self::Async => async_counter_action_with_tags(tags),
        }
    }
}

fn build_counter_action<I, T>(
    mode: CounterMode,
    input_name: Option<&'static str>,
    tags: I,
) -> FunctionAction
where
    I: IntoIterator<Item = T>,
    T: Into<String>,
{
    let builder = match input_name {
        Some(input_name) => FunctionActionBuilder::new()
            .inputs([input_name])
            .writes(["count"])
            .with_source_code(format!(
                "fn counter_with_inputs_action(state, ctx) {{ let delta = ctx.inputs.get(\"{input_name}\").and_then(Value::as_i64).expect(\"counter input should be provided\"); let count = state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + delta; map_from_pairs([(\"count\", json!(count))]) }}"
            )),
        None => match mode {
            CounterMode::Sync => FunctionActionBuilder::new()
                .writes(["count"])
                .with_source_code(
                    "fn counter_action(state) { let count = state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1; map_from_pairs([(\"count\", json!(count))]) }",
                ),
            CounterMode::Async => FunctionActionBuilder::new()
                .writes(["count"])
                .with_source_code(
                    "async fn async_counter_action(state) { let count = state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1; map_from_pairs([(\"count\", json!(count))]) }",
                ),
        },
    }
    .tags(tags);

    match mode {
        CounterMode::Sync => builder
            .build_sync(move |state, ctx| counter_result(state, counter_delta(ctx, input_name)))
            .expect("counter action should build"),
        CounterMode::Async => builder
            .build_async(move |state, ctx| async move {
                counter_result(&state, counter_delta(&ctx, input_name))
            })
            .expect("async counter action should build"),
    }
}

fn counter_delta(ctx: &ActionContext, input_name: Option<&'static str>) -> i64 {
    input_name.map_or(1, |input_name| {
        ctx.inputs
            .get(input_name)
            .and_then(Value::as_i64)
            .expect("counter input should be provided")
    })
}

fn counter_result(state: &State, delta: i64) -> IndexMap<String, Value> {
    let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + delta;
    map_from_pairs([("count", json!(count))])
}

/// Returns the canonical `{count: 0}` fixture state.
pub fn count_zero_state() -> State {
    state_from_pairs([("count", json!(0))])
}

/// Builder for small count-based application contract fixtures.
pub struct CounterApplicationFixture {
    state: State,
    actions: Vec<(&'static str, FunctionAction)>,
    transitions: Vec<Transition>,
    entrypoint: &'static str,
    hooks: Option<LifecycleAdapterSet>,
}

impl CounterApplicationFixture {
    /// Builds a three-step counter chain named `A -> B -> C`.
    pub fn three_step(mode: CounterMode) -> Self {
        Self::tagged_three_step(mode, &[])
    }

    /// Builds a three-step counter chain with `B` and `C` carrying `terminal_tags`.
    pub fn tagged_three_step(mode: CounterMode, terminal_tags: &[&str]) -> Self {
        Self {
            state: count_zero_state(),
            actions: vec![
                ("A", mode.action_with_tags(&[])),
                ("B", mode.action_with_tags(terminal_tags)),
                ("C", mode.action_with_tags(terminal_tags)),
            ],
            transitions: vec![
                Transition::new("A", "B", Condition::default()),
                Transition::new("B", "C", Condition::default()),
            ],
            entrypoint: "A",
            hooks: None,
        }
    }

    /// Adds lifecycle hooks to the fixture.
    pub fn with_hooks(mut self, hooks: LifecycleAdapterSet) -> Self {
        self.hooks = Some(hooks);
        self
    }

    /// Builds the application fixture.
    pub fn build(self) -> Result<Application, ApplicationError> {
        let builder = ApplicationBuilder::new()
            .with_state(self.state)?
            .with_actions(self.actions)?
            .with_transitions(self.transitions)?
            .with_entrypoint(self.entrypoint)?;
        match self.hooks {
            Some(hooks) => builder.with_hooks(hooks)?.build(),
            None => builder.build(),
        }
    }
}

/// Builds a one-action synchronous application fixture with explicit hooks.
pub fn build_sync_app<A: LocalAction + Send + Sync + 'static>(
    app_id: &str,
    action_name: &str,
    action: A,
    hooks: LifecycleAdapterSet,
) -> Application {
    ApplicationFixtureBuilder::single_action_with_test_identifiers(
        state_from_pairs([("count", json!(0))]),
        action_name,
        action,
        app_id,
    )
    .expect("action fixture should configure")
    .with_hooks(hooks)
    .expect("hooks should configure")
    .build()
    .expect("application should build")
}

/// Builder for small application fixtures used by tests and doctests.
pub struct ApplicationFixtureBuilder {
    builder: ApplicationBuilder,
}

impl ApplicationFixtureBuilder {
    /// Starts a fixture builder from explicit initial state.
    pub fn new(state: State) -> Result<Self, ApplicationError> {
        Ok(Self {
            builder: ApplicationBuilder::new().with_state(state)?,
        })
    }

    /// Creates a one-action fixture with no transitions.
    pub fn single_action<A: LocalAction + Send + Sync + 'static>(
        state: State,
        action_name: &str,
        action: A,
    ) -> Result<Self, ApplicationError> {
        Self::new(state)?
            .with_action(action_name, action)?
            .with_empty_transitions()?
            .with_entrypoint(action_name)
    }

    /// Creates a one-action fixture and assigns stable test identifiers.
    pub fn single_action_with_test_identifiers<A: LocalAction + Send + Sync + 'static>(
        state: State,
        action_name: &str,
        action: A,
        app_id: impl Into<String>,
    ) -> Result<Self, ApplicationError> {
        Self::single_action(state, action_name, action)?.with_test_identifiers(app_id)
    }

    /// Registers one action with the underlying [`ApplicationBuilder`].
    pub fn with_action<A: LocalAction + Send + Sync + 'static>(
        mut self,
        action_name: &str,
        action: A,
    ) -> Result<Self, ApplicationError> {
        self.builder = self.builder.with_actions(vec![(action_name, action)])?;
        Ok(self)
    }

    /// Replaces the graph with an explicit [`Graph`].
    pub fn with_graph(mut self, graph: Graph) -> Result<Self, ApplicationError> {
        self.builder = self.builder.with_graph(graph)?;
        Ok(self)
    }

    /// Adds transitions to the underlying application builder.
    pub fn with_transitions<I>(mut self, transitions: I) -> Result<Self, ApplicationError>
    where
        I: IntoIterator<Item = Transition>,
    {
        self.builder = self.builder.with_transitions(transitions)?;
        Ok(self)
    }

    /// Adds an empty transition list.
    pub fn with_empty_transitions(self) -> Result<Self, ApplicationError> {
        self.with_transitions(Vec::<Transition>::new())
    }

    /// Sets the fixture entrypoint action name.
    pub fn with_entrypoint(
        mut self,
        entrypoint: impl Into<String>,
    ) -> Result<Self, ApplicationError> {
        self.builder = self.builder.with_entrypoint(entrypoint)?;
        Ok(self)
    }

    /// Sets explicit application identifiers for the fixture.
    pub fn with_identifiers(
        mut self,
        app_id: impl Into<String>,
        partition_key: Option<String>,
        sequence_id: Option<u64>,
    ) -> Result<Self, ApplicationError> {
        self.builder = self
            .builder
            .with_identifiers(app_id, partition_key, sequence_id)?;
        Ok(self)
    }

    /// Sets deterministic identifiers commonly used in tests.
    pub fn with_test_identifiers(
        self,
        app_id: impl Into<String>,
    ) -> Result<Self, ApplicationError> {
        self.with_identifiers(app_id, Some("pk".to_string()), None)
    }

    /// Installs lifecycle hooks on the fixture application.
    pub fn with_hooks(mut self, hooks: LifecycleAdapterSet) -> Result<Self, ApplicationError> {
        self.builder = self.builder.with_hooks(hooks)?;
        Ok(self)
    }

    /// Installs lifecycle hooks when the option is present.
    pub fn with_optional_hooks(
        self,
        hooks: Option<LifecycleAdapterSet>,
    ) -> Result<Self, ApplicationError> {
        if let Some(hooks) = hooks {
            self.with_hooks(hooks)
        } else {
            Ok(self)
        }
    }

    /// Installs a tracker specification on the fixture application.
    pub fn with_tracker(mut self, tracker_spec: TrackerSpec) -> Result<Self, ApplicationError> {
        self.builder = self.builder.with_tracker(tracker_spec)?;
        Ok(self)
    }

    /// Installs a parallel executor on the fixture application.
    pub fn with_parallel_executor(
        mut self,
        parallel_executor: Arc<dyn ParallelExecutor>,
    ) -> Result<Self, ApplicationError> {
        self.builder = self.builder.with_parallel_executor(parallel_executor)?;
        Ok(self)
    }

    /// Installs a synchronous persister on the fixture application.
    pub fn with_sync_persister(
        mut self,
        persister: Arc<dyn BaseStatePersister>,
    ) -> Result<Self, ApplicationError> {
        self.builder = self.builder.with_persistence_spec(
            ApplicationPersistenceSpec::new().with_persister(StatePersisterSpec::sync(persister)),
        )?;
        Ok(self)
    }

    /// Installs a synchronous persister when the option is present.
    pub fn with_optional_sync_persister(
        self,
        persister: Option<Arc<dyn BaseStatePersister>>,
    ) -> Result<Self, ApplicationError> {
        if let Some(persister) = persister {
            self.with_sync_persister(persister)
        } else {
            Ok(self)
        }
    }

    /// Installs an asynchronous persister on the fixture application.
    pub fn with_async_persister(
        mut self,
        persister: Arc<dyn AsyncBaseStatePersister>,
    ) -> Result<Self, ApplicationError> {
        self.builder = self.builder.with_persistence_spec(
            ApplicationPersistenceSpec::new()
                .with_persister(StatePersisterSpec::async_persister(persister)),
        )?;
        Ok(self)
    }

    /// Returns the underlying [`ApplicationBuilder`].
    pub fn into_builder(self) -> ApplicationBuilder {
        self.builder
    }

    /// Builds the fixture application on the sync lane.
    pub fn build(self) -> Result<Application, ApplicationError> {
        self.builder.build()
    }

    /// Builds the fixture application on the async lane.
    pub async fn abuild(self) -> Result<Application, ApplicationError> {
        self.builder.abuild().await
    }
}

/// Scenario-style wrapper around [`ApplicationFixtureBuilder`] that lets tests
/// layer hooks and transitions incrementally.
pub struct ApplicationScenario {
    fixture: ApplicationFixtureBuilder,
    hooks: Option<LifecycleAdapterSet>,
}

impl ApplicationScenario {
    fn from_fixture(fixture: ApplicationFixtureBuilder) -> Self {
        Self {
            fixture,
            hooks: None,
        }
    }

    fn finish_fixture(self) -> ApplicationFixtureBuilder {
        match self.hooks {
            Some(hooks) => self
                .fixture
                .with_hooks(hooks)
                .expect("scenario hooks should configure"),
            None => self.fixture,
        }
    }

    /// Starts a scenario from explicit initial state.
    pub fn state(state: State) -> Result<Self, ApplicationError> {
        ApplicationFixtureBuilder::new(state).map(Self::from_fixture)
    }

    /// Starts a scenario from the canonical zero-count state.
    pub fn count_zero() -> Result<Self, ApplicationError> {
        Self::state(count_zero_state())
    }

    /// Builds a one-action scenario with an explicit entrypoint.
    pub fn single_action<A: LocalAction + Send + Sync + 'static>(
        state: State,
        action_name: &str,
        action: A,
    ) -> Result<Self, ApplicationError> {
        Self::state(state)?
            .with_action(action_name, action)?
            .with_entrypoint(action_name)
    }

    /// Builds a two-action scenario with explicit transitions.
    pub fn two_action_transition<
        A: LocalAction + Send + Sync + 'static,
        B: LocalAction + Send + Sync + 'static,
    >(
        state: State,
        first_name: &str,
        first_action: A,
        second_name: &str,
        second_action: B,
        transitions: Vec<Transition>,
    ) -> Result<Self, ApplicationError> {
        Self::state(state)?
            .with_action(first_name, first_action)?
            .with_action(second_name, second_action)?
            .with_transitions(transitions)?
            .with_entrypoint(first_name)
    }

    /// Adds one action to the scenario.
    pub fn with_action<A: LocalAction + Send + Sync + 'static>(
        mut self,
        action_name: &str,
        action: A,
    ) -> Result<Self, ApplicationError> {
        self.fixture = self.fixture.with_action(action_name, action)?;
        Ok(self)
    }

    /// Adds one transition to the scenario.
    pub fn with_transition(
        self,
        from: &str,
        to: &str,
        condition: Condition,
    ) -> Result<Self, ApplicationError> {
        self.with_transitions(vec![Transition::new(from, to, condition)])
    }

    /// Adds multiple transitions to the scenario.
    pub fn with_transitions(
        mut self,
        transitions: Vec<Transition>,
    ) -> Result<Self, ApplicationError> {
        self.fixture = self.fixture.with_transitions(transitions)?;
        Ok(self)
    }

    /// Sets the scenario entrypoint.
    pub fn with_entrypoint(mut self, entrypoint: &str) -> Result<Self, ApplicationError> {
        self.fixture = self.fixture.with_entrypoint(entrypoint)?;
        Ok(self)
    }

    /// Installs a synchronous persister when one is provided.
    pub fn with_optional_sync_persister(
        mut self,
        persister: Option<Arc<dyn BaseStatePersister>>,
    ) -> Result<Self, ApplicationError> {
        self.fixture = self.fixture.with_optional_sync_persister(persister)?;
        Ok(self)
    }

    /// Stores hooks that should be applied when the scenario is built.
    pub fn with_hooks(mut self, hooks: LifecycleAdapterSet) -> Self {
        self.hooks = Some(hooks);
        self
    }

    /// Stores optional hooks that should be applied when the scenario is built.
    pub fn with_optional_hooks(mut self, hooks: Option<LifecycleAdapterSet>) -> Self {
        self.hooks = hooks;
        self
    }

    /// Builds the scenario application.
    pub fn build(self) -> Result<Application, ApplicationError> {
        self.finish_fixture().build()
    }

    /// Returns the underlying fixture builder after applying stored hooks.
    pub fn into_fixture(self) -> ApplicationFixtureBuilder {
        self.finish_fixture()
    }
}
