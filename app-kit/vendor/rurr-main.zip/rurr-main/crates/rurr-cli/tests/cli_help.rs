mod help;

use help::run_help;
use rurr_testkit::command_fixture::{assert_failure, run_command, rurr_command, stderr_lossy};

#[test]
fn root_help_lists_primary_commands() {
    let stdout = run_help(&["--help"]);
    assert!(stdout.contains("serve"));
    assert!(stdout.contains("ui"));
    assert!(stdout.contains("test-case"));
    assert!(stdout.contains("admin"));
    assert!(!stdout.contains("demo"));
    assert!(!stdout.contains("__test-serde-decoder"));
}

#[test]
fn serve_help_lists_tracking_flags() {
    let stdout = run_help(&["serve", "--help"]);
    assert!(stdout.contains("--storage-dir"));
    assert!(stdout.contains("--ui-dir"));
    assert!(stdout.contains("--no-open"));
}

#[test]
fn ui_build_help_lists_output_flag() {
    let stdout = run_help(&["ui", "build", "--help"]);
    assert!(stdout.contains("--out-dir"));
}

#[test]
fn demo_subcommand_is_rejected() {
    let mut command = rurr_command();
    command.arg("demo");
    let output = run_command(&mut command, "demo should be rejected");
    assert_failure(&output, "demo should not be a supported subcommand");
    let stderr = stderr_lossy(&output);
    assert!(
        stderr.contains("unrecognized subcommand 'demo'"),
        "stderr should explain that demo is no longer supported: {stderr}"
    );
}

#[test]
fn test_case_create_help_lists_extraction_flags() {
    let stdout = run_help(&["test-case", "create", "--help"]);
    assert!(stdout.contains("--storage-dir"));
    assert!(stdout.contains("--project-name"));
    assert!(stdout.contains("--app-id"));
    assert!(stdout.contains("--sequence-id"));
    assert!(stdout.contains("--target-file-name"));
    assert!(stdout.contains("--serde-decoder"));
    assert!(stdout.contains("--serde-decoder-arg"));
    assert!(!stdout.contains("__test-serde-decoder"));
}

#[test]
fn admin_publish_help_lists_dist_dir_flag() {
    let stdout = run_help(&["admin", "publish", "--help"]);
    assert!(stdout.contains("--dist-dir"));
}
