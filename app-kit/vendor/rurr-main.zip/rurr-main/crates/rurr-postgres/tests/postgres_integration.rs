use futures::FutureExt;
use indexmap::IndexMap;
use rurr_core::action::{Condition, FunctionActionBuilder};
use rurr_core::application::ApplicationBuilder;
use rurr_core::common::panic::panic_payload_to_string;
use rurr_core::graph::Transition;
use rurr_persistence::{
    ApplicationPersistenceSpec, AsyncBaseStateLoader, AsyncBaseStateSaver, BaseStateLoader,
    BaseStateSaver, PersistedStateStatus, PersistenceError,
};
use rurr_postgres::{AsyncPostgresPersister, PostgresPersister, PostgresPersisterConfig};
use rurr_testkit::{
    application_fixture::register_prefixed_string_field_serde, persistence_cases,
    ready_postgres_url_sync,
};
use serde_json::{json, Value};
use std::panic::AssertUnwindSafe;
use std::sync::Arc;
pub mod support;

use support::{
    assert_connection_closed, build_counter_app, constructor_database_url, drop_table,
    drop_table_sync, live_database_url_for_lane, map_from_pairs, run_live_sync_case,
    run_sync_on_thread, sequence_id_column_data_type_sync, step_counter_app,
    terminate_backend_by_application_name_sync, unique_table_name, with_application_name,
    LivePostgresLane, PostgresLane, TestPersister,
};

const POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN: usize = 63 - "_created_at_index".len();

fn validate_table_name(
    lane: PostgresLane,
    table_name: impl Into<String>,
) -> Result<TestPersister, PersistenceError> {
    TestPersister::from_values(lane, constructor_database_url(), table_name)
}

fn assert_invalid_table_name_rejected(lane: PostgresLane, table_name: &str) {
    let error = match validate_table_name(lane, table_name.to_string()) {
        Ok(_) => panic!("invalid table names should be rejected"),
        Err(error) => error,
    };
    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation { operation } if operation == "invalid_table_name"
    ));
}

fn assert_from_config_rejects_mixed_case(lane: PostgresLane) {
    let config = PostgresPersisterConfig {
        database_url: constructor_database_url(),
        table_name: "fooBar".to_string(),
    };
    let error = match TestPersister::from_config(lane, config) {
        Ok(_) => panic!("mixed-case table names should be rejected via config"),
        Err(error) => error,
    };
    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation { operation } if operation == "invalid_table_name"
    ));
}

fn assert_from_values_valid_table_name_does_not_panic_without_tokio(lane: PostgresLane) {
    let prefix = format!("{}_from_values_no_tokio_ctor", lane.label());
    let result = std::panic::catch_unwind(|| validate_table_name(lane, unique_table_name(&prefix)));

    assert!(result.is_ok(), "constructor panicked in sync context");
    let ctor_result = result.expect("panic result should be captured");
    assert!(ctor_result.is_ok(), "constructor should succeed");
}

fn assert_from_config_valid_table_name_does_not_panic_without_tokio(lane: PostgresLane) {
    let prefix = format!("{}_from_config_no_tokio_ctor", lane.label());
    let config = PostgresPersisterConfig {
        database_url: constructor_database_url(),
        table_name: unique_table_name(&prefix),
    };
    let result = std::panic::catch_unwind(|| TestPersister::from_config(lane, config));

    assert!(result.is_ok(), "constructor panicked in sync context");
    let ctor_result = result.expect("panic result should be captured");
    assert!(ctor_result.is_ok(), "constructor should succeed");
}

async fn initialize_is_initialized_and_cleanup_are_explicit(lane: PostgresLane) {
    let prefix = format!("{}_initialize_is_initialized_cleanup", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::initialize_is_initialized_and_cleanup_are_explicit(
        &lane,
        assert_connection_closed,
    )
    .await
    .expect("initialize/cleanup assertions should succeed");
}

async fn save_load_latest_exact_and_list_app_ids_roundtrip(lane: PostgresLane) {
    let prefix = format!("{}_save_load_latest_exact", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::latest_partition_latest_app_exact_and_list(&lane)
        .await
        .expect("roundtrip assertions should succeed");
}

async fn failed_status_roundtrip_preserves_nested_state_shape(lane: PostgresLane) {
    let prefix = format!("{}_failed_status_nested_state", lane.label());
    let database_url = live_database_url_for_lane(lane).await;
    let table_name = unique_table_name(&prefix);
    let persister = TestPersister::from_values(lane, database_url.clone(), table_name.clone())
        .expect("persister should create");
    let expected_state = map_from_pairs([
        ("chat_history", json!(["a", "b"])),
        ("flags", json!({"retry": true, "attempt": 2})),
    ]);
    run_postgres_test_persister_with_cleanup(
        lane,
        &persister,
        database_url.as_str(),
        table_name.as_str(),
        async {
            persister
                .initialize()
                .await
                .expect("initialize should succeed");
            persister
                .save(
                    Some("partition"),
                    "app_id",
                    11,
                    "position_failed",
                    expected_state.clone(),
                    PersistedStateStatus::Failed,
                )
                .await
                .expect("save should succeed");

            let loaded = persister
                .load(Some("partition"), Some("app_id"), Some(11))
                .await
                .expect("load should succeed")
                .expect("state should exist");

            assert_eq!(loaded.status, PersistedStateStatus::Failed);
            assert_eq!(loaded.state, Some(expected_state));
            assert_eq!(loaded.position.as_deref(), Some("position_failed"));
            assert_eq!(loaded.sequence_id, 11);
        },
    )
    .await;

    let verification = TestPersister::from_values(lane, database_url, table_name)
        .expect("verification persister should create");
    let load_error = verification
        .load(Some("partition"), Some("app_id"), Some(11))
        .await
        .expect_err("cleanup should drop the failed-status roundtrip table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

async fn methods_before_initialize_and_after_table_drop_return_not_initialized(lane: PostgresLane) {
    let prefix = format!("{}_methods_not_initialized", lane.label());
    let first_lane = LivePostgresLane::new(lane, &format!("{prefix}_cold")).await;
    persistence_cases::not_initialized_for_load_save_and_list(&first_lane).await;

    let second_lane = LivePostgresLane::new(lane, &format!("{prefix}_dropped")).await;
    second_lane
        .persister()
        .initialize()
        .await
        .expect("initialize should succeed");
    match lane {
        PostgresLane::Sync => drop_table_sync(second_lane.database_url(), second_lane.table_name())
            .expect("table drop should succeed"),
        PostgresLane::Async => drop_table(second_lane.database_url(), second_lane.table_name())
            .await
            .expect("table drop should succeed"),
    }

    let load_error = second_lane
        .persister()
        .load(Some("partition"), Some("app_id"), None)
        .await
        .expect_err("load should fail after table drop");
    let save_error = second_lane
        .persister()
        .save(
            Some("partition"),
            "app_id",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect_err("save should fail after table drop");
    let list_error = second_lane
        .persister()
        .list_app_ids(Some("partition"))
        .await
        .expect_err("list_app_ids should fail after table drop");

    assert!(matches!(load_error, PersistenceError::NotInitialized));
    assert!(matches!(save_error, PersistenceError::NotInitialized));
    assert!(matches!(list_error, PersistenceError::NotInitialized));

    second_lane
        .persister()
        .cleanup()
        .await
        .expect("cleanup should succeed");
}

async fn same_instance_reprobes_after_external_initialize_and_recreate(lane: PostgresLane) {
    let prefix = format!("{}_same_instance_reprobe", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::same_instance_reprobes_after_external_initialize_and_recreate(&lane)
        .await
        .expect("reprobe assertions should succeed");
}

async fn config_roundtrip_rebuilds_persister_and_loads_saved_state(lane: PostgresLane) {
    let prefix = format!("{}_config_roundtrip", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::config_roundtrip_rebuilds_persister_and_loads_saved_state(&lane)
        .await
        .expect("config roundtrip assertions should succeed");
}

async fn save_load_supports_sequence_id_above_i32_max(lane: PostgresLane) {
    let prefix = format!("{}_sequence_id_above_i32_max", lane.label());
    let database_url = live_database_url_for_lane(lane).await;
    let table_name = unique_table_name(&prefix);
    let persister = TestPersister::from_values(lane, database_url.clone(), table_name.clone())
        .expect("persister should create");
    let sequence_id = i32::MAX as u64 + 1;
    run_postgres_test_persister_with_cleanup(
        lane,
        &persister,
        database_url.as_str(),
        table_name.as_str(),
        async {
            persister
                .initialize()
                .await
                .expect("initialize should succeed");
            persister
                .save(
                    Some("partition"),
                    "app_id",
                    sequence_id,
                    "position",
                    map_from_pairs([("key", json!("value"))]),
                    PersistedStateStatus::Completed,
                )
                .await
                .expect("save should succeed");

            let loaded = persister
                .load(Some("partition"), Some("app_id"), Some(sequence_id))
                .await
                .expect("load should succeed")
                .expect("state should exist");
            assert_eq!(loaded.sequence_id, sequence_id);
        },
    )
    .await;

    let verification = TestPersister::from_values(lane, database_url, table_name)
        .expect("verification persister should create");
    let load_error = verification
        .load(Some("partition"), Some("app_id"), Some(sequence_id))
        .await
        .expect_err("cleanup should drop the sequence-id roundtrip table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

async fn cleanup_postgres_test_persister_and_drop_table(
    lane: PostgresLane,
    persister: &TestPersister,
    database_url: &str,
    table_name: &str,
) -> Result<(), PersistenceError> {
    let cleanup_result = persister.cleanup().await;
    persistence_cases::finalize_cleanup_results([cleanup_result], async {
        match lane {
            PostgresLane::Sync => drop_table_sync(database_url, table_name),
            PostgresLane::Async => drop_table(database_url, table_name).await,
        }
    })
    .await
}

async fn run_postgres_test_persister_with_cleanup<F>(
    lane: PostgresLane,
    persister: &TestPersister,
    database_url: &str,
    table_name: &str,
    future: F,
) where
    F: std::future::Future<Output = ()>,
{
    let result = AssertUnwindSafe(future).catch_unwind().await;
    let cleanup_result =
        cleanup_postgres_test_persister_and_drop_table(lane, persister, database_url, table_name)
            .await;

    match result {
        Ok(()) => cleanup_result.expect("postgres test cleanup should succeed"),
        Err(payload) => match cleanup_result {
            Ok(()) => std::panic::resume_unwind(payload),
            Err(cleanup_error) => panic!(
                "postgres test cleanup should succeed: body_panic={}; cleanup_error={cleanup_error}",
                panic_payload_to_string(payload),
            ),
        },
    }
}

async fn save_accepts_same_sequence_with_different_position_and_rejects_exact_duplicate(
    lane: PostgresLane,
) {
    let prefix = format!("{}_duplicate_identity", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::duplicate_identity_behavior(&lane, "postgres_query_failed")
        .await
        .expect("duplicate identity assertions should succeed");
}

async fn load_exact_sequence_orders_by_created_at_then_position(lane: PostgresLane) {
    let prefix = format!("{}_exact_sequence_order", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::exact_sequence_prefers_latest_created_at_then_position(&lane)
        .await
        .expect("exact-sequence ordering assertions should succeed");
}

async fn list_app_ids_orders_by_latest_created_at_then_app_id(lane: PostgresLane) {
    let prefix = format!("{}_list_app_ids_order", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::list_app_ids_order(&lane)
        .await
        .expect("list_app_ids ordering assertions should succeed");
}

fn serde_resume_builder(
    field_name: &str,
    app_id: &str,
    persistence_spec: ApplicationPersistenceSpec,
) -> ApplicationBuilder {
    let start_field = field_name.to_string();
    let finish_field = field_name.to_string();

    let start_action = FunctionActionBuilder::new()
        .writes(vec![start_field.clone()])
        .build_sync(move |_state, _ctx| {
            IndexMap::from([(start_field.clone(), json!("persisted via serde"))])
        })
        .expect("start action should build");
    let finish_action = FunctionActionBuilder::new()
        .reads(vec![finish_field.clone()])
        .writes(["output"])
        .build_sync(move |state, _ctx| {
            IndexMap::from([(
                "output".to_string(),
                state.get(&finish_field).cloned().unwrap_or(Value::Null),
            )])
        })
        .expect("finish action should build");

    ApplicationBuilder::new()
        .with_actions(vec![("start", start_action), ("finish", finish_action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "start",
            "finish",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_identifiers(app_id, Some("tenant".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(persistence_spec)
        .expect("persistence spec should configure")
}

async fn build_serde_resume_app(
    lane: PostgresLane,
    persister: &TestPersister,
    field_name: &str,
    app_id: &str,
) -> rurr_core::application::Application {
    let persistence_spec = match persister {
        TestPersister::Sync(persister) => ApplicationPersistenceSpec::sync_resume(
            persister.clone(),
            true,
            IndexMap::new(),
            "start",
            None,
            None,
        ),
        TestPersister::Async(persister) => ApplicationPersistenceSpec::async_resume(
            persister.clone(),
            true,
            IndexMap::new(),
            "start",
            None,
            None,
        ),
    };
    let builder = serde_resume_builder(field_name, app_id, persistence_spec);

    match lane {
        PostgresLane::Sync => builder.build().expect("sync build should succeed"),
        PostgresLane::Async => builder.abuild().await.expect("async build should succeed"),
    }
}

async fn step_serde_resume_app(
    lane: PostgresLane,
    app: &mut rurr_core::application::Application,
) -> rurr_core::application::StepOutput {
    match lane {
        PostgresLane::Sync => app
            .step(None)
            .expect("step should succeed")
            .expect("step should execute"),
        PostgresLane::Async => app
            .astep(None)
            .await
            .expect("async step should succeed")
            .expect("async step should execute"),
    }
}

async fn persistence_spec_resume_roundtrips_registered_field_serde(lane: PostgresLane) {
    let lane_kind = lane;
    let prefix = format!("{}_serde_resume", lane_kind.label());
    let lane = LivePostgresLane::new(lane_kind, &prefix).await;
    let field_name = format!("{}_field", unique_table_name(&prefix));
    let app_id = format!("{prefix}_app");
    register_prefixed_string_field_serde(&field_name, "serialized::")
        .expect("field serde registration should succeed");
    persistence_cases::run_with_cleanup(&lane, async {
        lane.persister()
            .initialize()
            .await
            .expect("initialize should succeed");

        let mut first_app =
            build_serde_resume_app(lane_kind, lane.persister(), &field_name, &app_id).await;
        let first_step = step_serde_resume_app(lane_kind, &mut first_app).await;
        assert_eq!(first_step.action.name(), "start");
        assert_eq!(
            first_step.state.get(&field_name),
            Some(&json!("persisted via serde"))
        );

        let stored = lane
            .persister()
            .load(Some("tenant"), Some(&app_id), Some(0))
            .await
            .expect("load should succeed")
            .expect("stored state should exist");
        assert_eq!(
            stored
                .state
                .as_ref()
                .and_then(|state| state.get(&field_name)),
            Some(&json!({"value": "serialized::persisted via serde"}))
        );

        let mut resumed_app =
            build_serde_resume_app(lane_kind, lane.persister(), &field_name, &app_id).await;
        assert_eq!(
            resumed_app.state().get(&field_name),
            Some(&json!("persisted via serde"))
        );
        assert_eq!(resumed_app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
        assert_eq!(
            resumed_app.state().get("__PRIOR_STEP"),
            Some(&json!("start"))
        );

        let resumed_step = step_serde_resume_app(lane_kind, &mut resumed_app).await;
        assert_eq!(resumed_step.action.name(), "finish");
        assert_eq!(
            resumed_step.state.get("output"),
            Some(&json!("persisted via serde"))
        );

        Ok::<(), PersistenceError>(())
    })
    .await
    .expect("serde resume assertions should succeed");

    let verification_persister = TestPersister::from_values(
        lane_kind,
        lane.database_url().to_string(),
        lane.table_name().to_string(),
    )
    .expect("verification persister should create");
    let load_error = verification_persister
        .load(Some("tenant"), Some(&app_id), Some(0))
        .await
        .expect_err("cleanup should drop the serde-resume table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

async fn panic_cleanup_drops_postgres_table(lane: PostgresLane) {
    let prefix = format!("{}_panic_cleanup", lane.label());
    let live_lane = LivePostgresLane::new(lane, &prefix).await;
    let database_url = live_lane.database_url().to_string();
    let table_name = live_lane.table_name().to_string();

    let panic_result = AssertUnwindSafe(persistence_cases::run_with_cleanup(&live_lane, async {
        live_lane
            .persister()
            .initialize()
            .await
            .expect("initialize should succeed");
        panic!("synthetic postgres panic")
    }))
    .catch_unwind()
    .await;

    assert!(panic_result.is_err(), "panic fixture should unwind");

    let verification_persister = TestPersister::from_values(lane, database_url, table_name)
        .expect("verification persister should create");
    let load_error = verification_persister
        .load(Some("tenant"), Some("panic_cleanup_app"), Some(0))
        .await
        .expect_err("panic cleanup should drop the live test table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

async fn roundtrip_direct_persister_panic_cleanup_drops_table(lane: PostgresLane) {
    let prefix = format!("{}_roundtrip_direct_panic_cleanup", lane.label());
    let database_url = live_database_url_for_lane(lane).await;
    let table_name = unique_table_name(&prefix);
    let persister = TestPersister::from_values(lane, database_url.clone(), table_name.clone())
        .expect("persister should create");

    let panic_result = AssertUnwindSafe(run_postgres_test_persister_with_cleanup(
        lane,
        &persister,
        database_url.as_str(),
        table_name.as_str(),
        async {
            persister
                .initialize()
                .await
                .expect("initialize should succeed");
            persister
                .save(
                    Some("tenant"),
                    "direct_panic_cleanup_app",
                    3,
                    "position",
                    map_from_pairs([("key", json!("value"))]),
                    PersistedStateStatus::Completed,
                )
                .await
                .expect("save should succeed");
            panic!("synthetic direct persister panic");
        },
    ))
    .catch_unwind()
    .await;

    assert!(panic_result.is_err(), "panic fixture should unwind");

    let verification_persister = TestPersister::from_values(lane, database_url, table_name)
        .expect("verification persister should create");
    let load_error = verification_persister
        .load(Some("tenant"), Some("direct_panic_cleanup_app"), Some(3))
        .await
        .expect_err("panic cleanup should drop the direct persister test table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

macro_rules! lane_pair_test {
    ($sync_name:ident, $async_name:ident, $body:ident $(, $arg:expr )* $(,)?) => {
        #[test]
        fn $sync_name() {
            $body(PostgresLane::Sync $(, $arg )*);
        }

        #[test]
        fn $async_name() {
            $body(PostgresLane::Async $(, $arg )*);
        }
    };
}

macro_rules! live_lane_pair_test {
    ($sync_name:ident, $async_name:ident, $body:ident $(,)?) => {
        #[test]
        fn $sync_name() {
            rurr_testkit::require_check_live_tests!();
            run_live_sync_case($body(PostgresLane::Sync));
        }

        #[tokio::test]
        async fn $async_name() {
            rurr_testkit::require_check_live_tests!();
            $body(PostgresLane::Async).await;
        }
    };
}

lane_pair_test!(
    sync_from_values_rejects_table_name_longer_than_index_safe_limit,
    async_from_values_rejects_table_name_longer_than_index_safe_limit,
    assert_invalid_table_name_rejected,
    &"a".repeat(POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN + 1),
);

#[test]
fn sync_from_values_accepts_table_name_at_index_safe_limit() {
    let result = validate_table_name(
        PostgresLane::Sync,
        "a".repeat(POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN),
    );
    assert!(
        result.is_ok(),
        "table names at index-safe limit should be accepted"
    );
}

#[test]
fn async_from_values_accepts_table_name_at_index_safe_limit() {
    let result = validate_table_name(
        PostgresLane::Async,
        "a".repeat(POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN),
    );
    assert!(
        result.is_ok(),
        "table names at index-safe limit should be accepted"
    );
}

lane_pair_test!(
    sync_from_values_rejects_mixed_case_table_name,
    async_from_values_rejects_mixed_case_table_name,
    assert_invalid_table_name_rejected,
    "MyTable",
);

lane_pair_test!(
    sync_from_config_rejects_mixed_case_table_name,
    async_from_config_rejects_mixed_case_table_name,
    assert_from_config_rejects_mixed_case,
);

lane_pair_test!(
    sync_from_values_valid_table_name_does_not_panic_without_tokio,
    async_from_values_valid_table_name_does_not_panic_without_tokio,
    assert_from_values_valid_table_name_does_not_panic_without_tokio,
);

lane_pair_test!(
    sync_from_config_valid_table_name_does_not_panic_without_tokio,
    async_from_config_valid_table_name_does_not_panic_without_tokio,
    assert_from_config_valid_table_name_does_not_panic_without_tokio,
);

live_lane_pair_test!(
    sync_initialize_is_initialized_and_cleanup_are_explicit,
    async_initialize_is_initialized_and_cleanup_are_explicit,
    initialize_is_initialized_and_cleanup_are_explicit,
);

live_lane_pair_test!(
    sync_save_load_latest_exact_and_list_app_ids_roundtrip,
    async_save_load_latest_exact_and_list_app_ids_roundtrip,
    save_load_latest_exact_and_list_app_ids_roundtrip,
);

live_lane_pair_test!(
    sync_failed_status_roundtrip_preserves_nested_state_shape,
    async_failed_status_roundtrip_preserves_nested_state_shape,
    failed_status_roundtrip_preserves_nested_state_shape,
);

live_lane_pair_test!(
    sync_methods_before_initialize_and_after_table_drop_return_not_initialized,
    async_methods_before_initialize_and_after_table_drop_return_not_initialized,
    methods_before_initialize_and_after_table_drop_return_not_initialized,
);

live_lane_pair_test!(
    sync_same_instance_reprobes_after_external_initialize_and_recreate,
    async_same_instance_reprobes_after_external_initialize_and_recreate,
    same_instance_reprobes_after_external_initialize_and_recreate,
);

#[test]
fn sync_cached_closed_connection_returns_connection_closed() {
    rurr_testkit::require_check_live_tests!();

    let base_database_url =
        ready_postgres_url_sync().expect("postgres must be reachable for live tests");
    let application_name = unique_table_name("sync_close");
    let database_url = with_application_name(&base_database_url, &application_name);
    let table_name = unique_table_name("sync_cached_connection_closed");
    let persister = PostgresPersister::new(rurr_postgres::PostgresPersisterConfig::new(
        database_url.clone(),
        table_name.clone(),
    ))
    .expect("persister should create");
    let cleanup_database_url = database_url.clone();
    let cleanup_table_name = table_name.clone();
    run_postgres_sync_test_with_cleanup(
        &persister,
        cleanup_database_url,
        cleanup_table_name,
        || {
            persister.initialize().expect("initialize should succeed");
            persister
                .save(
                    Some("partition"),
                    "app_id",
                    1,
                    "position",
                    map_from_pairs([("value", json!("ok"))]),
                    PersistedStateStatus::Completed,
                )
                .expect("save should succeed");

            terminate_backend_by_application_name_sync(&base_database_url, &application_name);

            let error = persister
                .load(Some("partition"), Some("app_id"), Some(1))
                .expect_err("load should fail after backend termination");
            assert_connection_closed(error);
        },
    );

    let verification = PostgresPersister::new(rurr_postgres::PostgresPersisterConfig::new(
        database_url,
        table_name,
    ))
    .expect("verification persister should create");
    let load_error = verification
        .load(Some("partition"), Some("app_id"), Some(1))
        .expect_err("cleanup should drop the cached-connection test table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

#[test]
fn sync_initialize_creates_bigint_sequence_id_column() {
    rurr_testkit::require_check_live_tests!();

    let database_url =
        ready_postgres_url_sync().expect("postgres must be reachable for live tests");
    let table_name = unique_table_name("sync_bigint_sequence_id");
    let persister = PostgresPersister::new(rurr_postgres::PostgresPersisterConfig::new(
        database_url.clone(),
        table_name.clone(),
    ))
    .expect("persister should create");

    let cleanup_database_url = database_url.clone();
    let cleanup_table_name = table_name.clone();
    run_postgres_sync_test_with_cleanup(
        &persister,
        cleanup_database_url,
        cleanup_table_name,
        || {
            persister.initialize().expect("initialize should succeed");
            assert_eq!(
                sequence_id_column_data_type_sync(&database_url, &table_name),
                "bigint"
            );
        },
    );

    let verification = PostgresPersister::new(rurr_postgres::PostgresPersisterConfig::new(
        database_url,
        table_name,
    ))
    .expect("verification persister should create");
    let load_error = verification
        .load(Some("partition"), Some("app_id"), Some(1))
        .expect_err("cleanup should drop the bigint-sequence test table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

#[test]
fn sync_misc_panic_cleanup_drops_table() {
    rurr_testkit::require_check_live_tests!();

    let database_url =
        ready_postgres_url_sync().expect("postgres must be reachable for live tests");
    let table_name = unique_table_name("sync_misc_panic_cleanup");
    let verification_config =
        rurr_postgres::PostgresPersisterConfig::new(database_url.clone(), table_name.clone());
    let persister =
        PostgresPersister::new(verification_config.clone()).expect("persister should create");

    let panic_result = std::panic::catch_unwind(AssertUnwindSafe(|| {
        run_postgres_sync_test_with_cleanup(&persister, database_url, table_name, || {
            persister.initialize().expect("initialize should succeed");
            persister
                .save(
                    Some("partition"),
                    "panic_cleanup_app",
                    1,
                    "position",
                    map_from_pairs([("value", json!("panic"))]),
                    PersistedStateStatus::Completed,
                )
                .expect("save should succeed");
            panic!("synthetic postgres misc panic")
        });
    }));

    assert!(panic_result.is_err(), "panic fixture should unwind");

    let verification =
        PostgresPersister::new(verification_config).expect("verification persister should create");
    let load_error = verification
        .load(Some("partition"), Some("panic_cleanup_app"), Some(1))
        .expect_err("panic cleanup should drop the misc postgres table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

live_lane_pair_test!(
    sync_config_roundtrip_rebuilds_persister_and_loads_saved_state,
    async_config_roundtrip_rebuilds_persister_and_loads_saved_state,
    config_roundtrip_rebuilds_persister_and_loads_saved_state,
);

live_lane_pair_test!(
    sync_save_load_supports_sequence_id_above_i32_max,
    async_save_load_supports_sequence_id_above_i32_max,
    save_load_supports_sequence_id_above_i32_max,
);

live_lane_pair_test!(
    sync_save_accepts_same_sequence_with_different_position_and_rejects_exact_duplicate,
    async_save_accepts_same_sequence_with_different_position_and_rejects_exact_duplicate,
    save_accepts_same_sequence_with_different_position_and_rejects_exact_duplicate,
);

live_lane_pair_test!(
    sync_load_exact_sequence_orders_by_created_at_then_position,
    async_load_exact_sequence_orders_by_created_at_then_position,
    load_exact_sequence_orders_by_created_at_then_position,
);

live_lane_pair_test!(
    sync_list_app_ids_orders_by_latest_created_at_then_app_id,
    async_list_app_ids_orders_by_latest_created_at_then_app_id,
    list_app_ids_orders_by_latest_created_at_then_app_id,
);

#[tokio::test]
async fn sync_and_async_roundtrip_interoperate_bidirectionally() {
    rurr_testkit::require_check_live_tests!();

    let database_url = live_database_url_for_lane(PostgresLane::Async).await;
    let table_name = unique_table_name("sync_async_interop");
    let interop_config =
        rurr_postgres::PostgresPersisterConfig::new(database_url.clone(), table_name.clone());

    let sync = Arc::new(
        PostgresPersister::new(interop_config.clone()).expect("sync persister should create"),
    );
    let async_persister = Arc::new(
        AsyncPostgresPersister::new(interop_config.clone()).expect("async persister should create"),
    );

    run_postgres_interop_with_cleanup(
        sync.clone(),
        async_persister.clone(),
        database_url.clone(),
        table_name.clone(),
        async move {
            let sync_for_initialize = sync.clone();
            run_sync_on_thread(move || sync_for_initialize.initialize())
                .expect("sync initialize should succeed");
            let sync_for_save = sync.clone();
            run_sync_on_thread(move || {
                sync_for_save.save(
                    Some("partition"),
                    "sync_app",
                    11,
                    "sync_position",
                    map_from_pairs([("source", json!("sync"))]),
                    PersistedStateStatus::Failed,
                )
            })
            .expect("sync save should succeed");

            assert!(async_persister
                .is_initialized()
                .await
                .expect("async is_initialized should succeed"));
            let loaded_from_async = async_persister
                .load(Some("partition"), Some("sync_app"), Some(11))
                .await
                .expect("async load should succeed")
                .expect("sync-written state should exist");
            assert_eq!(loaded_from_async.status, PersistedStateStatus::Failed);
            assert_eq!(
                loaded_from_async.state,
                Some(map_from_pairs([("source", json!("sync"))]))
            );

            async_persister
                .save(
                    Some("partition"),
                    "async_app",
                    12,
                    "async_position",
                    map_from_pairs([("source", json!("async"))]),
                    PersistedStateStatus::Completed,
                )
                .await
                .expect("async save should succeed");

            let sync_for_load = sync.clone();
            let loaded_from_sync = run_sync_on_thread(move || {
                sync_for_load.load(Some("partition"), Some("async_app"), Some(12))
            })
            .expect("sync load should succeed")
            .expect("async-written state should exist");
            assert_eq!(loaded_from_sync.status, PersistedStateStatus::Completed);
            assert_eq!(
                loaded_from_sync.state,
                Some(map_from_pairs([("source", json!("async"))]))
            );
        },
    )
    .await;

    let verification =
        AsyncPostgresPersister::new(interop_config).expect("verification persister should create");
    let load_error = verification
        .load(Some("partition"), Some("sync_app"), Some(11))
        .await
        .expect_err("cleanup should drop the interop postgres table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

#[tokio::test]
async fn sync_and_async_roundtrip_panic_cleanup_drops_table() {
    rurr_testkit::require_check_live_tests!();

    let database_url = live_database_url_for_lane(PostgresLane::Async).await;
    let table_name = unique_table_name("sync_async_interop_panic_cleanup");
    let interop_config =
        rurr_postgres::PostgresPersisterConfig::new(database_url.clone(), table_name.clone());

    let sync = Arc::new(
        PostgresPersister::new(interop_config.clone()).expect("sync persister should create"),
    );
    let async_persister = Arc::new(
        AsyncPostgresPersister::new(interop_config.clone()).expect("async persister should create"),
    );

    let panic_result = AssertUnwindSafe(run_postgres_interop_with_cleanup(
        sync.clone(),
        async_persister.clone(),
        database_url.clone(),
        table_name.clone(),
        async move {
            let sync_for_initialize = sync.clone();
            run_sync_on_thread(move || sync_for_initialize.initialize())
                .expect("sync initialize should succeed");
            let sync_for_save = sync.clone();
            run_sync_on_thread(move || {
                sync_for_save.save(
                    Some("partition"),
                    "panic_sync_app",
                    21,
                    "sync_position",
                    map_from_pairs([("source", json!("sync"))]),
                    PersistedStateStatus::Failed,
                )
            })
            .expect("sync save should succeed");

            let loaded_from_async = async_persister
                .load(Some("partition"), Some("panic_sync_app"), Some(21))
                .await
                .expect("async load should succeed")
                .expect("sync-written state should exist");
            assert_eq!(loaded_from_async.status, PersistedStateStatus::Failed);

            panic!("synthetic postgres interop panic")
        },
    ))
    .catch_unwind()
    .await;

    assert!(panic_result.is_err(), "panic fixture should unwind");

    let verification =
        AsyncPostgresPersister::new(interop_config).expect("verification persister should create");
    let load_error = verification
        .load(Some("partition"), Some("panic_sync_app"), Some(21))
        .await
        .expect_err("panic cleanup should drop the interop postgres table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

async fn run_postgres_interop_with_cleanup<F>(
    sync: Arc<PostgresPersister>,
    async_persister: Arc<AsyncPostgresPersister>,
    database_url: String,
    table_name: String,
    future: F,
) where
    F: std::future::Future<Output = ()>,
{
    let result = AssertUnwindSafe(future).catch_unwind().await;
    let sync_cleanup = run_sync_on_thread({
        let sync = sync.clone();
        move || sync.cleanup()
    });
    let async_close = async_persister.close().await;
    let cleanup_result = persistence_cases::finalize_cleanup_results(
        [sync_cleanup, async_close],
        drop_table(&database_url, &table_name),
    )
    .await;

    match result {
        Ok(()) => cleanup_result.expect("interop cleanup should succeed"),
        Err(payload) => match cleanup_result {
            Ok(()) => std::panic::resume_unwind(payload),
            Err(cleanup_error) => panic!(
                "interop cleanup should succeed: body_panic={}; cleanup_error={cleanup_error}",
                panic_payload_to_string(payload),
            ),
        },
    }
}

fn run_postgres_sync_test_with_cleanup<F>(
    persister: &PostgresPersister,
    database_url: String,
    table_name: String,
    test: F,
) where
    F: FnOnce(),
{
    let result = std::panic::catch_unwind(AssertUnwindSafe(test));
    let cleanup_result = persistence_cases::run_sync_case(
        persistence_cases::finalize_cleanup_results([persister.cleanup()], async move {
            drop_table_sync(&database_url, &table_name)
        }),
    );

    match result {
        Ok(()) => cleanup_result.expect("sync postgres cleanup should succeed"),
        Err(payload) => match cleanup_result {
            Ok(()) => std::panic::resume_unwind(payload),
            Err(cleanup_error) => panic!(
                "sync postgres cleanup should succeed: body_panic={}; cleanup_error={cleanup_error}",
                panic_payload_to_string(payload),
            ),
        },
    }
}

async fn persistence_spec_resume_path_loads_state_and_resumes_next_action(lane: PostgresLane) {
    let prefix = format!("{}_resume", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::persistence_spec_resume_path_smoke(
        &lane,
        |lane, app_id, partition_key, load_target| {
            Box::pin(async move {
                build_counter_app(
                    lane.lane(),
                    lane.persister().persistence_spec(load_target),
                    app_id,
                    partition_key,
                )
                .await
            })
        },
        |lane, app| Box::pin(async move { step_counter_app(lane.lane(), app).await }),
    )
    .await
    .expect("resume assertions should succeed");
}

async fn persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer(
    lane: PostgresLane,
) {
    let prefix = format!("{}_fork", lane.label());
    let lane = LivePostgresLane::new(lane, &prefix).await;
    persistence_cases::persistence_spec_fork_smoke(
        &lane,
        |lane, app_id, partition_key, load_target| {
            Box::pin(async move {
                build_counter_app(
                    lane.lane(),
                    lane.persister().persistence_spec(load_target),
                    app_id,
                    partition_key,
                )
                .await
            })
        },
        |lane, app| Box::pin(async move { step_counter_app(lane.lane(), app).await }),
    )
    .await
    .expect("fork assertions should succeed");
}

live_lane_pair_test!(
    sync_persistence_spec_resume_path_loads_state_and_resumes_next_action,
    async_persistence_spec_resume_path_loads_state_and_resumes_next_action,
    persistence_spec_resume_path_loads_state_and_resumes_next_action,
);

live_lane_pair_test!(
    sync_persistence_spec_resume_roundtrips_registered_field_serde,
    async_persistence_spec_resume_roundtrips_registered_field_serde,
    persistence_spec_resume_roundtrips_registered_field_serde,
);

live_lane_pair_test!(
    sync_panic_cleanup_drops_postgres_table,
    async_panic_cleanup_drops_postgres_table,
    panic_cleanup_drops_postgres_table,
);

live_lane_pair_test!(
    sync_roundtrip_direct_persister_panic_cleanup_drops_table,
    async_roundtrip_direct_persister_panic_cleanup_drops_table,
    roundtrip_direct_persister_panic_cleanup_drops_table,
);

live_lane_pair_test!(
    sync_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer,
    async_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer,
    persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer,
);
