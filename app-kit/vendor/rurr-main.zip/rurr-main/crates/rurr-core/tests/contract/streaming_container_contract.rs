use futures::stream::{self, BoxStream};
use futures::{Stream, StreamExt};
use indexmap::IndexMap;
use rurr_core::action::{
    AsyncStreamingResultContainer, RurrError, StreamItem, StreamingResultContainer,
};
use rurr_core::state::State;
use serde_json::json;
use std::collections::VecDeque;
use std::pin::Pin;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::task::{Context, Poll};

#[derive(Debug)]
struct CountingIter {
    calls: Arc<AtomicUsize>,
    items: VecDeque<Result<(StreamItem, Option<State>), RurrError>>,
}

impl CountingIter {
    fn new(
        calls: Arc<AtomicUsize>,
        items: Vec<Result<(StreamItem, Option<State>), RurrError>>,
    ) -> Self {
        Self {
            calls,
            items: items.into(),
        }
    }
}

impl Iterator for CountingIter {
    type Item = Result<(StreamItem, Option<State>), RurrError>;

    fn next(&mut self) -> Option<Self::Item> {
        self.calls.fetch_add(1, Ordering::SeqCst);
        self.items.pop_front()
    }
}

#[derive(Debug)]
struct CountingStream {
    calls: Arc<AtomicUsize>,
    items: VecDeque<Result<(StreamItem, Option<State>), RurrError>>,
}

impl CountingStream {
    fn new(
        calls: Arc<AtomicUsize>,
        items: Vec<Result<(StreamItem, Option<State>), RurrError>>,
    ) -> Self {
        Self {
            calls,
            items: items.into(),
        }
    }
}

impl Stream for CountingStream {
    type Item = Result<(StreamItem, Option<State>), RurrError>;

    fn poll_next(mut self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Option<Self::Item>> {
        self.calls.fetch_add(1, Ordering::SeqCst);
        Poll::Ready(self.items.pop_front())
    }
}

fn stream_item(value: &str) -> StreamItem {
    IndexMap::from([("response".to_string(), json!(value))])
}

fn state_with_response(value: &str) -> State {
    State::new(IndexMap::from([("response".to_string(), json!(value))]))
}

fn initial_state() -> State {
    State::new(IndexMap::from([("foo".to_string(), json!("bar"))]))
}

#[test]
fn sync_iteration_yields_only_intermediate_items_and_get_returns_terminal() {
    let calls = Arc::new(AtomicUsize::new(0));
    let callback_calls = Arc::new(Mutex::new(Vec::new()));

    let source = CountingIter::new(
        Arc::clone(&calls),
        vec![
            Ok((stream_item("t"), None)),
            Ok((stream_item("e"), None)),
            Ok((stream_item("te"), Some(state_with_response("te")))),
        ],
    );

    let mut container = StreamingResultContainer::new(source, initial_state(), {
        let callback_calls = Arc::clone(&callback_calls);
        move |result, state, error| {
            callback_calls
                .lock()
                .expect("lock poisoned")
                .push((result, state, error));
        }
    });

    assert_eq!(calls.load(Ordering::SeqCst), 0, "container must be lazy");

    let streamed = (&mut container)
        .map(|item| item.expect("stream item should be Ok"))
        .collect::<Vec<_>>();

    assert_eq!(streamed, vec![stream_item("t"), stream_item("e")]);

    let (terminal_result, terminal_state) = container.get().expect("get should succeed");
    assert_eq!(terminal_result, Some(stream_item("te")));
    assert_eq!(terminal_state, state_with_response("te"));

    let (terminal_result_again, terminal_state_again) =
        container.get().expect("second get should succeed");
    assert_eq!(terminal_result_again, Some(stream_item("te")));
    assert_eq!(terminal_state_again, state_with_response("te"));

    let callback_snapshot = callback_calls.lock().expect("lock poisoned");
    assert_eq!(callback_snapshot.len(), 1, "callback must run exactly once");
    let (callback_result, callback_state, callback_error) = &callback_snapshot[0];
    assert_eq!(callback_result, &Some(stream_item("te")));
    assert_eq!(callback_state, &state_with_response("te"));
    assert_eq!(callback_error, &None);
}

#[test]
fn sync_get_exhausts_stream_and_returns_terminal_result() {
    let calls = Arc::new(AtomicUsize::new(0));
    let callback_calls = Arc::new(Mutex::new(Vec::new()));

    let source = CountingIter::new(
        Arc::clone(&calls),
        vec![
            Ok((stream_item("a"), None)),
            Ok((stream_item("b"), None)),
            Ok((stream_item("ab"), Some(state_with_response("ab")))),
        ],
    );

    let mut container = StreamingResultContainer::new(source, initial_state(), {
        let callback_calls = Arc::clone(&callback_calls);
        move |result, state, error| {
            callback_calls
                .lock()
                .expect("lock poisoned")
                .push((result, state, error));
        }
    });

    let (terminal_result, terminal_state) = container.get().expect("get should succeed");
    assert_eq!(terminal_result, Some(stream_item("ab")));
    assert_eq!(terminal_state, state_with_response("ab"));
    assert_eq!(
        calls.load(Ordering::SeqCst),
        3,
        "get should exhaust source lazily"
    );

    let callback_snapshot = callback_calls.lock().expect("lock poisoned");
    assert_eq!(callback_snapshot.len(), 1);
}

#[test]
fn sync_callback_runs_once_on_early_drop_and_rolls_back_to_initial_state() {
    let callback_calls = Arc::new(Mutex::new(Vec::new()));

    {
        let source = CountingIter::new(
            Arc::new(AtomicUsize::new(0)),
            vec![
                Ok((stream_item("x"), None)),
                Ok((stream_item("y"), None)),
                Ok((stream_item("xy"), Some(state_with_response("xy")))),
            ],
        );

        let mut container = StreamingResultContainer::new(source, initial_state(), {
            let callback_calls = Arc::clone(&callback_calls);
            move |result, state, error| {
                callback_calls
                    .lock()
                    .expect("lock poisoned")
                    .push((result, state, error));
            }
        });

        let first = container
            .next()
            .expect("first item should exist")
            .expect("first item should be Ok");
        assert_eq!(first, stream_item("x"));

        assert_eq!(
            callback_calls.lock().expect("lock poisoned").len(),
            0,
            "callback should not run until drop/get completes finalization"
        );
    }

    let callback_snapshot = callback_calls.lock().expect("lock poisoned");
    assert_eq!(callback_snapshot.len(), 1, "callback must run once on drop");
    let (callback_result, callback_state, callback_error) = &callback_snapshot[0];
    assert_eq!(callback_result, &None);
    assert_eq!(callback_state, &initial_state());
    assert_eq!(callback_error, &None);
}

#[test]
fn sync_generator_error_propagates_and_callback_receives_error() {
    let callback_calls = Arc::new(Mutex::new(Vec::new()));
    let expected_error = RurrError::Message("boom".to_string());

    let source = CountingIter::new(
        Arc::new(AtomicUsize::new(0)),
        vec![
            Ok((stream_item("ok"), None)),
            Err(expected_error.clone()),
            Ok((stream_item("never"), Some(state_with_response("never")))),
        ],
    );

    let mut container = StreamingResultContainer::new(source, initial_state(), {
        let callback_calls = Arc::clone(&callback_calls);
        move |result, state, error| {
            callback_calls
                .lock()
                .expect("lock poisoned")
                .push((result, state, error));
        }
    });

    let first = container
        .next()
        .expect("first item should exist")
        .expect("first item should be Ok");
    assert_eq!(first, stream_item("ok"));

    let second = container
        .next()
        .expect("second item should exist")
        .expect_err("second item should be error");
    assert_eq!(second, expected_error);

    let get_error = container
        .get()
        .expect_err("get should surface terminal error");
    assert_eq!(get_error, expected_error);

    let callback_snapshot = callback_calls.lock().expect("lock poisoned");
    assert_eq!(callback_snapshot.len(), 1, "callback must run exactly once");
    let (callback_result, callback_state, callback_error) = &callback_snapshot[0];
    assert_eq!(callback_result, &None);
    assert_eq!(callback_state, &initial_state());
    assert_eq!(callback_error, &Some(expected_error));
}

#[tokio::test]
async fn async_iteration_yields_only_intermediate_items_and_get_returns_terminal() {
    let calls = Arc::new(AtomicUsize::new(0));
    let callback_calls = Arc::new(Mutex::new(Vec::new()));

    let source: BoxStream<'static, Result<(StreamItem, Option<State>), RurrError>> =
        Box::pin(CountingStream::new(
            Arc::clone(&calls),
            vec![
                Ok((stream_item("t"), None)),
                Ok((stream_item("e"), None)),
                Ok((stream_item("te"), Some(state_with_response("te")))),
            ],
        ));

    let mut container = AsyncStreamingResultContainer::new(source, initial_state(), {
        let callback_calls = Arc::clone(&callback_calls);
        move |result, state, error| {
            callback_calls
                .lock()
                .expect("lock poisoned")
                .push((result, state, error));
        }
    });

    assert_eq!(calls.load(Ordering::SeqCst), 0, "container must be lazy");

    let mut streamed = Vec::new();
    while let Some(item) = container.next().await {
        streamed.push(item.expect("intermediate item should be Ok"));
    }

    assert_eq!(streamed, vec![stream_item("t"), stream_item("e")]);

    let (terminal_result, terminal_state) = container.get().await.expect("get should succeed");
    assert_eq!(terminal_result, Some(stream_item("te")));
    assert_eq!(terminal_state, state_with_response("te"));

    let (terminal_result_again, terminal_state_again) =
        container.get().await.expect("second get should succeed");
    assert_eq!(terminal_result_again, Some(stream_item("te")));
    assert_eq!(terminal_state_again, state_with_response("te"));

    let callback_snapshot = callback_calls.lock().expect("lock poisoned");
    assert_eq!(callback_snapshot.len(), 1, "callback must run exactly once");
    let (callback_result, callback_state, callback_error) = &callback_snapshot[0];
    assert_eq!(callback_result, &Some(stream_item("te")));
    assert_eq!(callback_state, &state_with_response("te"));
    assert_eq!(callback_error, &None);
}

#[tokio::test]
async fn async_get_exhausts_stream_and_returns_terminal_result() {
    let calls = Arc::new(AtomicUsize::new(0));
    let callback_calls = Arc::new(Mutex::new(Vec::new()));

    let source: BoxStream<'static, Result<(StreamItem, Option<State>), RurrError>> =
        Box::pin(CountingStream::new(
            Arc::clone(&calls),
            vec![
                Ok((stream_item("a"), None)),
                Ok((stream_item("b"), None)),
                Ok((stream_item("ab"), Some(state_with_response("ab")))),
            ],
        ));

    let mut container = AsyncStreamingResultContainer::new(source, initial_state(), {
        let callback_calls = Arc::clone(&callback_calls);
        move |result, state, error| {
            callback_calls
                .lock()
                .expect("lock poisoned")
                .push((result, state, error));
        }
    });

    let (terminal_result, terminal_state) = container.get().await.expect("get should succeed");
    assert_eq!(terminal_result, Some(stream_item("ab")));
    assert_eq!(terminal_state, state_with_response("ab"));
    assert_eq!(
        calls.load(Ordering::SeqCst),
        3,
        "get should exhaust source lazily"
    );

    let callback_snapshot = callback_calls.lock().expect("lock poisoned");
    assert_eq!(callback_snapshot.len(), 1);
}

#[tokio::test]
async fn async_callback_runs_once_on_early_drop_and_rolls_back_to_initial_state() {
    let callback_calls = Arc::new(Mutex::new(Vec::new()));

    {
        let source: BoxStream<'static, Result<(StreamItem, Option<State>), RurrError>> =
            Box::pin(CountingStream::new(
                Arc::new(AtomicUsize::new(0)),
                vec![
                    Ok((stream_item("x"), None)),
                    Ok((stream_item("y"), None)),
                    Ok((stream_item("xy"), Some(state_with_response("xy")))),
                ],
            ));

        let mut container = AsyncStreamingResultContainer::new(source, initial_state(), {
            let callback_calls = Arc::clone(&callback_calls);
            move |result, state, error| {
                callback_calls
                    .lock()
                    .expect("lock poisoned")
                    .push((result, state, error));
            }
        });

        let first = container
            .next()
            .await
            .expect("first item should exist")
            .expect("first item should be Ok");
        assert_eq!(first, stream_item("x"));

        assert_eq!(
            callback_calls.lock().expect("lock poisoned").len(),
            0,
            "callback should not run until drop/get completes finalization"
        );
    }

    let callback_snapshot = callback_calls.lock().expect("lock poisoned");
    assert_eq!(callback_snapshot.len(), 1, "callback must run once on drop");
    let (callback_result, callback_state, callback_error) = &callback_snapshot[0];
    assert_eq!(callback_result, &None);
    assert_eq!(callback_state, &initial_state());
    assert_eq!(callback_error, &None);
}

#[tokio::test]
async fn async_generator_error_propagates_and_callback_receives_error() {
    let callback_calls = Arc::new(Mutex::new(Vec::new()));
    let expected_error = RurrError::Message("boom".to_string());

    let source: BoxStream<'static, Result<(StreamItem, Option<State>), RurrError>> =
        Box::pin(CountingStream::new(
            Arc::new(AtomicUsize::new(0)),
            vec![
                Ok((stream_item("ok"), None)),
                Err(expected_error.clone()),
                Ok((stream_item("never"), Some(state_with_response("never")))),
            ],
        ));

    let mut container = AsyncStreamingResultContainer::new(source, initial_state(), {
        let callback_calls = Arc::clone(&callback_calls);
        move |result, state, error| {
            callback_calls
                .lock()
                .expect("lock poisoned")
                .push((result, state, error));
        }
    });

    let first = container
        .next()
        .await
        .expect("first item should exist")
        .expect("first item should be Ok");
    assert_eq!(first, stream_item("ok"));

    let second = container
        .next()
        .await
        .expect("second item should exist")
        .expect_err("second item should be error");
    assert_eq!(second, expected_error);

    let get_error = container
        .get()
        .await
        .expect_err("get should surface terminal error");
    assert_eq!(get_error, expected_error);

    let callback_snapshot = callback_calls.lock().expect("lock poisoned");
    assert_eq!(callback_snapshot.len(), 1, "callback must run exactly once");
    let (callback_result, callback_state, callback_error) = &callback_snapshot[0];
    assert_eq!(callback_result, &None);
    assert_eq!(callback_state, &initial_state());
    assert_eq!(callback_error, &Some(expected_error));
}

#[tokio::test]
async fn async_container_wraps_live_box_stream_without_buffering() {
    let calls = Arc::new(AtomicUsize::new(0));

    let source: BoxStream<'static, Result<(StreamItem, Option<State>), RurrError>> = Box::pin(
        stream::iter(vec![
            Ok((stream_item("m"), None)),
            Ok((stream_item("n"), None)),
            Ok((stream_item("mn"), Some(state_with_response("mn")))),
        ])
        .inspect({
            let calls = Arc::clone(&calls);
            move |_| {
                calls.fetch_add(1, Ordering::SeqCst);
            }
        }),
    );

    let mut container =
        AsyncStreamingResultContainer::new(source, initial_state(), |_r, _s, _e| {});

    assert_eq!(
        calls.load(Ordering::SeqCst),
        0,
        "must not pre-buffer stream items"
    );

    let first = container
        .next()
        .await
        .expect("first item should exist")
        .expect("first item should be Ok");
    assert_eq!(first, stream_item("m"));
    assert_eq!(
        calls.load(Ordering::SeqCst),
        1,
        "should advance one item per poll"
    );
}
