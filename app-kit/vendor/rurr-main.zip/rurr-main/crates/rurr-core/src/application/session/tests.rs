use super::{prepare_run_inputs, ExecutionPlan, ExecutionSessionCore};
use crate::action::{Condition, FunctionActionBuilder};
use crate::application::{ApplicationBuilder, ApplicationError};
use crate::graph::Transition;
use crate::state::State;
use indexmap::IndexMap;
use serde_json::{json, Value};

fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
    pairs
        .into_iter()
        .map(|(key, value)| (key.to_string(), value))
        .collect()
}

fn state_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> State {
    State::new(map_from_pairs(pairs))
}

fn counter_action() -> crate::FunctionAction {
    FunctionActionBuilder::new()
        .writes(["count"])
        .build_sync(|state, _ctx| {
            let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            map_from_pairs([("count", json!(count))])
        })
        .expect("counter action should build")
}

#[test]
fn advance_returns_finished_when_no_next_execution_exists() {
    let mut app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![("counter", counter_action())])
        .expect("action should configure")
        .with_transitions(vec![Transition::new(
            "counter",
            "counter",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");
    let mut loop_state = ExecutionSessionCore::new(Default::default());

    let advance = loop_state
        .advance(&mut app)
        .expect("terminal advance should succeed");

    assert!(advance.is_none());
}

#[test]
fn prepare_run_inputs_rejects_reserved_runtime_keys() {
    let mut inputs = crate::action::ActionInputs::new();
    inputs.insert("__context".to_string(), json!({"forged": true}));

    let error = prepare_run_inputs(Some(inputs)).expect_err("reserved keys should be rejected");

    assert!(matches!(
        error,
        ApplicationError::ReservedRuntimeInputKeys { keys }
            if keys == vec!["__context".to_string()]
    ));
}

#[test]
fn resolve_prepared_next_action_returns_next_action_name_when_valid() {
    let app = ApplicationBuilder::new()
        .with_state(State::new(
            [("__SEQUENCE_ID".to_string(), json!(6))]
                .into_iter()
                .collect(),
        ))
        .expect("state should configure")
        .with_actions(vec![("counter", counter_action())])
        .expect("action should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");

    let resolved = ExecutionPlan::new(&app)
        .resolve()
        .expect("preparation should resolve");

    assert_eq!(resolved.next_action_name.as_deref(), Some("counter"));
}

#[test]
fn resolve_prepared_next_action_returns_none_when_graph_is_exhausted() {
    let app = ApplicationBuilder::new()
        .with_state(State::new(
            [
                ("__PRIOR_STEP".to_string(), json!("counter")),
                ("__SEQUENCE_ID".to_string(), json!(6)),
            ]
            .into_iter()
            .collect(),
        ))
        .expect("state should configure")
        .with_actions(vec![("counter", counter_action())])
        .expect("action should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");

    let resolved = ExecutionPlan::new(&app)
        .resolve()
        .expect("preparation should resolve");

    assert_eq!(resolved.prior_step.as_deref(), Some("counter"));
    assert!(resolved.next_action_name.is_none());
    assert_eq!(resolved.reserved_sequence_id, 7);
}

#[test]
fn execution_plan_defers_invalid_sequence_until_resolution() {
    let app = ApplicationBuilder::new()
        .with_state(State::new(
            [("__SEQUENCE_ID".to_string(), json!("bad-seq"))]
                .into_iter()
                .collect(),
        ))
        .expect("state should configure")
        .with_actions(vec![("counter", counter_action())])
        .expect("action should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");

    let error = ExecutionPlan::new(&app)
        .resolve()
        .expect_err("resolution should surface invalid sequence type");

    assert!(matches!(
        error,
        ApplicationError::InvalidSequenceIdType { .. }
    ));
}
