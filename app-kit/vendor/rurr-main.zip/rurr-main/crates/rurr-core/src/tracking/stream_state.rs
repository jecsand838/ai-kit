use crate::lifecycle::LifecycleError;
use indexmap::IndexMap;
use std::fmt;
use std::hash::Hash;

pub(crate) fn record_stream_item<K>(
    state: &mut IndexMap<K, usize>,
    key: &K,
    phase: &'static str,
) -> Result<bool, LifecycleError>
where
    K: Eq + Hash + fmt::Display,
{
    let count = state
        .get_mut(key)
        .ok_or_else(|| missing_stream_state(phase, key))?;
    let should_log = *count == 0;
    *count += 1;
    Ok(should_log)
}

pub(crate) fn finish_stream<K>(
    state: &mut IndexMap<K, usize>,
    key: &K,
    phase: &'static str,
) -> Result<usize, LifecycleError>
where
    K: Eq + Hash + fmt::Display,
{
    state
        .shift_remove(key)
        .ok_or_else(|| missing_stream_state(phase, key))
}

fn missing_stream_state<K>(phase: &'static str, key: &K) -> LifecycleError
where
    K: fmt::Display,
{
    LifecycleError::hook_failed(
        phase,
        format!("missing stream state for {key}; pre_start_stream must run before {phase}"),
    )
}
