## Burr Parity Remediation Ledger

This file is the completed durable ledger for the standalone remediation program defined in `docs/refactors/burr-parity-remediation/README.md`.
Use `README.md`, `docs/00_overview.md`, `docs/02_api_surface.md`, and `docs/04_oracle_and_goldens.md`
for the current implementation narrative; this file is the durable operator ledger.

### Status legend
- `PENDING`: defined but not yet started
- `IN_PROGRESS`: reopened work currently in progress
- `COMPLETE`: implemented and recorded in this workspace
- `BLOCKED`: cannot complete without an external prerequisite
- `NOT_REQUIRED`: gate or phase not needed for the current change set

## Program metadata

| Field | Value |
| --- | --- |
| Program | `Burr Parity Remediation Program` |
| Baseline branch | `dev` |
| Remediation policy record | `docs/refactors/burr-parity-remediation/README.md` |
| Archived Phase 1–8 bundle | `docs/refactors/rurr-refactor/README.md` |
| Archived Phase 1–8 tracker | `docs/refactors/rurr-refactor/TASKS_PROGRESS.phase-1-8.archive.md` |
| Current phase | `COMPLETE - all five remediation phases are implemented and re-verified in this workspace` |
| Current blocker | `OPEN - the private OpenAI live lane is still environment-blocked because the locally sourced OPENAI_API_KEY value is not a valid HTTP header value` |
| Mandatory restart after instruction edits | `YES - update any AGENTS file only at the end of the session, then restart immediately` |
| Compatibility target | `Preserve current Apache Burr parity; removed private/test-only knobs are not compatibility commitments` |

## Reopening instructions
- Read in this order after any restart or before explicitly reopening parity-remediation work:
  - `AGENTS.md`
  - `TASKS_PROGRESS.md`
  - `docs/refactors/burr-parity-remediation/README.md`
  - `docs/00_overview.md`
- Next concrete step:
  - `NONE - the staged remediation program is complete through all five phases.`
- Recorded remediation work is closure-clean in this workspace after the gates below.

## Phase matrix

| Phase | Branch | Worktree | Status | Recorded loop stage | Findings closed | Gate summary |
| --- | --- | --- | --- | --- | --- | --- |
| 1. Docs and instructions | `refactor/parity-remediation-docs-and-instructions` | `../rurr-remediation-phase-01-docs` | `COMPLETE` | `Archive old program, replace program docs/tracker, prepare final instruction retarget` | `Program governance and tracking reset` | `Pre-instruction code gates passed; post-instruction restart still required by policy` |
| 2. Surface hooks and env overrides | `refactor/parity-remediation-surface-hooks` | `../rurr-remediation-phase-02-surfaces` | `COMPLETE` | `Removed hook/env surfaces and rebuilt affected black-box coverage` | `P1 exact-child shim`, `P1 admin publish stub path`, `P1 env override cleanup` | `Targeted CLI, tracking-store, and tracking-server suites passed; full ./scripts/check.sh passed; ./scripts/check_competition.sh passed` |
| 3. Fixture and filesystem cleanup | `refactor/parity-remediation-fixtures` | `../rurr-remediation-phase-03-fixtures` | `COMPLETE` | `Replaced deterministic roots and public happy-path seeding shortcuts` | `P2 deterministic temp roots`, `P2 happy-path synthetic setup` | `Targeted rurr-core/sqlite/core/macros suites passed; full ./scripts/check.sh passed` |
| 4. Oracle and golden parity | `refactor/parity-remediation-oracle-contracts` | `../rurr-remediation-phase-04-oracle` | `COMPLETE` | `Removed canonicalization, then hardened the raw oracle comparator to reject unexpected files/layout drift and schema-invalid graph actions` | `P1 tracking canonicalization`, `scenario-specific golden rewrites`, `review follow-up: strict file/layout/schema enforcement` | `Focused Python comparator regressions passed; `cargo test -q -p rurr-tracking-server --test tracking_golden`, `cargo test -q -p rurr-tracking-server --test schema_validation`, `./scripts/check_oracle.sh`, and `./scripts/check.sh` all passed after enforcing exact artifact sets plus schema-first graph validation` |
| 5. Policy closure | `refactor/parity-remediation-policy-closure` | `../rurr-remediation-phase-05-closure` | `COMPLETE` | `Decoder-path test_case fixtures now use public-producer tracked runs with no direct-log fallback` | `P2 polling/sleep/skip heuristics`, `P2 anti-hack allowlist exceptions`, `remaining happy-path synthetic setup` | `test_case integration and unit suites passed after removing the last direct-log snapshot path; final `./scripts/check_competition.sh` and `./scripts/check.sh` passed` |

## Finding-closure ledger

| Finding | Status | Closure proof |
| --- | --- | --- |
| Debug/test-only exact-child filesystem hook exposed through production source | `COMPLETE` | `crates/rurr-tracking-store/src/exact_child_file/test_support.rs` was deleted; the exact-child hook types/statics/guards were removed from `file_ops.rs`, `platform.rs`, and public exports; tracking-server contract support no longer mutates file opens through hidden guards` |
| Tracking golden contract canonicalized instead of compared as raw output | `COMPLETE` | `The Python oracle comparator is now the sole semantic authority with no canonicalization step; it rejects unexpected tracking files/layout drift, reserved-input semantic drift, exact graph-code drift, and schema-invalid graph actions before semantic comparison, while Rust tracking-golden coverage invokes that comparator directly and keeps only crate-local payload/schema assertions. The raw oracle set is now limited to bytewise-comparable scenarios, and non-comparable failed-step exception / map-states runtime-context proofs live in dedicated `rurr-core` contracts rather than comparator tolerance.` |
| Admin publish contract path used fake cargo/workspace shims behind a production env override | `COMPLETE` | `RURR_ADMIN_PUBLISH_CARGO` was removed from `crates/rurr-cli/src/commands/admin.rs`; fake cargo/workspace helpers were removed from test support; admin publish coverage now uses pure planning helpers plus real workspace dry-run behavior` |
| Synthetic deterministic filesystem roots and seeded happy-path tracking artifacts | `COMPLETE` | `Deterministic temp roots are removed, broad happy-path writers are gone from `crates/rurr-testkit/src/tracking_fixture/mod.rs`, and the current `test_case` decoder fixture helpers now build tracked histories through public application registration/execution with no direct `log.jsonl` fallback.` |
| Polling loops, fixed sleeps, permission heuristics, and restricted-environment early returns in contract coverage | `COMPLETE` | `serve_health_contract.rs`, `jsonl_locking_contract.rs`, tracking-server annotation contracts, and the remaining pending-poll assertions now use explicit signals/readiness acknowledgements or direct pending polls instead of fixed sleeps, skip heuristics, or permission-substring matching` |
| Anti-hack allowlist exceptions documented as accepted contract-test accommodations | `COMPLETE` | `tools/anti_hack_allowlist.toml` was deleted; `tools/anti_hack_audit.py` no longer supports allowlists or policy-boundary mode; check scripts and docs now reflect zero-exception audits` |

## Gate ledger

| Gate | Status | Notes |
| --- | --- | --- |
| `cargo test -q -p rurr-cli --test admin_publish_contract` | `PASS` | `Surface hook/env removal coverage` |
| `cargo test -q -p rurr-cli --test serve_health_contract` | `PASS` | `Rewritten readiness and failure coordination` |
| `cargo test -q -p rurr-tracking-server --test api_contract` | `PASS` | `No more exact-child hook guard path` |
| `cargo test -q -p rurr-tracking-store` | `PASS` | `Hook deletion fallout checked` |
| `cargo test -q -p rurr-core --test local_tracking_client_contract` | `PASS` | `Public-API fixture setup coverage` |
| `cargo test -q -p rurr-sqlite --test sqlite_sync_contract` | `PASS` | `Ephemeral-root contract coverage` |
| `cargo test -q -p rurr-sqlite --test sqlite_async_contract` | `PASS` | `Ephemeral-root contract coverage` |
| `cargo test -q -p rurr-core --test contract application_builder_contract::` | `PASS` | `Contract fixture cleanup` |
| `cargo test -q -p rurr-core --test contract lifecycle_contract::` | `PASS` | `Contract fixture cleanup` |
| `cargo test -q -p rurr-core --test contract graphviz_contract::` | `PASS` | `Contract fixture cleanup` |
| `cargo test -q -p rurr-macros --test minimal_consumer_contract` | `PASS` | `Macro consumer temp-root cleanup` |
| `python3 tools/tests/test_compare_tracking_dirs.py` | `PASS` | `Oracle comparator regression coverage for extra files, nested layout rejection, reserved-input drift, child-order drift, schema-invalid graph actions, and code-field semantic exceptions` |
| `cargo test -q -p rurr-tracking-server --test tracking_golden` | `PASS` | `Strict raw comparator coverage including reserved inputs, child ordering, and scenario-branch removal` |
| `cargo test -q -p rurr-tracking-server --test schema_validation` | `PASS` | `Raw schema validation` |
| `cargo test -q -p rurr-core --test contract pending_poll` | `PASS` | `Removed remaining timing shortcut from pending-poll contract assertions` |
| `cargo test -q -p rurr-testkit collector_reads_a_partially_written_request_body` | `PASS` | `Removed remaining collector test sleep shortcut` |
| `cargo test -q -p rurr-cli --test test_case_contract` | `PASS` | `Decoder-path fixtures now use pure public-producer tracked runs with no exact-log snapshot fallback` |
| `cargo test -q -p rurr-core --test contract -- --nocapture` | `PASS` | `Removed stale deleted-hook assertions from core contracts after hook deletion` |
| `cargo test -q -p rurr-mongodb --all-features --lib -- --nocapture` | `PASS` | `Mongo live raw-proof lane now covers real namespace errors, real save replies, and cache invalidation` |
| `cargo test -q -p rurr-mongodb --all-features --test mongodb_integration -- --nocapture` | `PASS` | `Mongo public duplicate-save and schema-drift behavior remains live-backed` |
| `cargo test -q -p rurr-cli test_case` | `PASS` | `Mirrors the public-producer fixture flow in unit coverage` |
| `./scripts/fix_manifest_freshness.sh` | `PASS` | `Regenerated tracked manifest artifacts after shim-removal edits and Cargo manifest cleanup` |
| `python3 tools/anti_hack_audit.py --mode production` | `PASS` | `Zero-exception production audit` |
| `python3 tools/anti_hack_audit.py --mode tests` | `PASS` | `Zero-exception production+test audit` |
| `./scripts/check_oracle.sh` | `PASS` | `Fresh Burr and Rurr raw tracking trees match with strict file-layout enforcement, schema-first artifact validation, and the narrowed bytewise-comparable oracle scenario set` |
| `./scripts/check_competition.sh` | `PASS` | `Full parity-sensitive competition gate passed after the strict comparator and fixture cleanup work` |
| `./scripts/check.sh` | `PASS` | `Full repo gate passed after the CLI decoder helper deletion, Mongo live-proof rewrite, and manifest refresh` |
| `./scripts/check_live.sh` | `PASS` | `2026-04-22 rerun passed end to end with the Mongo lib/integration live proof lanes` |
| `./scripts/check_openai_live.sh` | `BLOCKED` | `2026-04-22 still fails before the provider call because the locally sourced OPENAI_API_KEY value is not a valid HTTP header value` |

## Post-program follow-up log
- `2026-04-22 OpenAI proof-surface cleanup (COMPLETE): deleted the shared OpenAI SSE parser proof helpers from crates/rurr/tests/support/openai_streaming.rs, rebuilt the strict proof lane as a live-only raw-frame validator in crates/rurr/tests/support/openai_streaming_live.rs, narrowed chat_completions_delta_stream to extraction-only semantics, and replaced the synthetic support-contract fixtures with owned parser tests that cover only the minimal live-proven content subset plus non-data and truncated-frame failures. Targeted cargo test -q -p rurr --test openai_streaming_support_contract, cargo test -q -p rurr --test openai_streaming_live, and final ./scripts/check.sh all passed.`
- `2026-04-22 OpenAI proof-surface cleanup (RED PASS CAPTURED): after deleting the shared proof helpers and the synthetic SSE fixture tests, cargo test -q -p rurr --test openai_streaming_support_contract failed because chat_completions_delta_stream still referenced the deleted parser surface, and cargo test -q -p rurr --test openai_streaming_live failed because the shared validate_live_raw_chat_completions_contract helper no longer existed. This is the intentional red state before rebuilding the live-only contract.`

## Blocker log
- `Resolved: tracked-file manifest drift was handled through ./scripts/fix_manifest_freshness.sh during the remediation code phases before the final green check.sh/check_competition.sh runs.`
- `Resolved: scenario 08 no longer relies on deterministic oracle executors because map-states child-order and runtime-context proofs now live in dedicated `rurr-core` contracts instead of the raw oracle set.`
- `Resolved: the test_case decoder fixture helpers now generate tracked histories through public application registration/execution only; the last direct-log fallback was removed.`
- `Resolved: the review follow-up on raw oracle enforcement is closed; comparator and companion Rust tests now fail on unexpected artifacts, nested layout drift, and schema-invalid graph actions without introducing canonicalization or mocks.`
- `Resolved: 2026-04-19 follow-up reduction pass removed the Rust semantic tracking comparator in favor of direct Python-comparator invocation from tracking_golden, deleted the remaining streaming sync/async mirror helper families in the session-step lifecycle, refreshed manifest artifacts, and re-passed ./scripts/check_oracle.sh, ./scripts/check_competition.sh, and ./scripts/check.sh.`
- `Resolved: 2026-04-22 reran ./scripts/check_live.sh successfully once Docker-backed services were available.`
- `Open environment blocker: ./scripts/check_openai_live.sh currently fails before the provider call because the locally sourced OPENAI_API_KEY value is not a valid HTTP header value. This blocked only the private OpenAI live verification lane for the 2026-04-22 proof-surface cleanup; the delete-first cleanup itself was completed and verified through targeted tests plus final ./scripts/check.sh.`
