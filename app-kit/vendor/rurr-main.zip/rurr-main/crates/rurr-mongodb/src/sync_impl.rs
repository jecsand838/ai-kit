use indexmap::IndexMap;
use mongodb::bson::Document;
use rurr_persistence::{
    BaseStateLoader, BaseStateSaver, PersistedStateData, PersistedStateStatus, PersistenceError,
};
use serde_json::Value;

use crate::schema::{self, MongoPersistencePlan};
use crate::{
    document_to_persisted_state, is_namespace_exists_error, is_namespace_not_found_error,
    now_sortable_rfc3339_utc_string, parse_save_reply, MongoPersister, OP_MONGODB_COMMAND_FAILED,
};

impl BaseStateSaver for MongoPersister {
    fn initialize(&self) -> Result<(), PersistenceError> {
        let database = self.database()?;
        let collection_name = self.config.collection_name.as_str();

        if let Err(error) = database.create_collection(collection_name).run() {
            if !is_namespace_exists_error(&error) {
                return Err(self.map_command_error(error, OP_MONGODB_COMMAND_FAILED));
            }
        }

        let collection = database.collection::<Document>(collection_name);
        collection
            .create_indexes(schema::required_index_models())
            .run()
            .map_err(|error| self.map_command_error(error, OP_MONGODB_COMMAND_FAILED))?;

        let collection_uuid = self.fetch_collection_uuid()?;
        self.cache_collection_uuid(collection_uuid)?;
        Ok(())
    }

    fn is_initialized(&self) -> Result<bool, PersistenceError> {
        let collection_uuid = match self.fetch_collection_uuid() {
            Ok(collection_uuid) => collection_uuid,
            Err(PersistenceError::NotInitialized) => {
                self.invalidate_cached_collection_uuid();
                return Ok(false);
            }
            Err(error) => return Err(error),
        };
        let collection = self
            .database()?
            .collection::<Document>(self.config.collection_name.as_str());
        let mut cursor = match collection.list_indexes().run() {
            Ok(cursor) => cursor,
            Err(error) if is_namespace_not_found_error(&error) => {
                self.invalidate_cached_collection_uuid();
                return Ok(false);
            }
            Err(error) => return Err(self.map_command_error(error, OP_MONGODB_COMMAND_FAILED)),
        };
        let mut index_models = Vec::new();
        while let Some(index_model) = self.cursor_next(&mut cursor)? {
            index_models.push(index_model);
        }
        let initialized = schema::required_index_definitions_match(&index_models);

        if initialized {
            self.cache_collection_uuid(collection_uuid)?;
        } else {
            self.invalidate_cached_collection_uuid();
        }
        Ok(initialized)
    }

    fn cleanup(&self) -> Result<(), PersistenceError> {
        self.shutdown()
    }

    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        let collection_uuid = self.collection_uuid()?;
        let database = self.database()?;
        let plan = MongoPersistencePlan::save(
            partition_key,
            app_id,
            sequence_id,
            position,
            &state,
            status,
            now_sortable_rfc3339_utc_string()?,
        )?;

        let reply = database
            .run_command(
                plan.update_command(self.config.collection_name.as_str(), &collection_uuid),
            )
            .run()
            .map_err(|error| self.map_command_error(error, OP_MONGODB_COMMAND_FAILED))?;

        parse_save_reply(reply).map_err(|error| self.track_persistence_error(error))
    }
}

impl BaseStateLoader for MongoPersister {
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        let collection_uuid = self.collection_uuid()?;

        let Some(plan) = MongoPersistencePlan::load(partition_key, app_id, sequence_id)? else {
            return Ok(None);
        };

        let document = self
            .run_find_command(
                plan.find_command(self.config.collection_name.as_str(), &collection_uuid),
            )?
            .map(document_to_persisted_state)
            .transpose()?;

        Ok(document)
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        let collection_uuid = self.collection_uuid()?;
        let plan = MongoPersistencePlan::list_app_ids(partition_key);
        let mut cursor = self.run_raw_cursor_command(
            plan.aggregate_command(self.config.collection_name.as_str(), &collection_uuid),
        )?;

        let mut app_ids = Vec::new();
        while let Some(document) = self.cursor_next(&mut cursor)? {
            let app_id = document
                .get_str(rurr_persistence::layout::FIELD_APP_ID)
                .map_err(|_| PersistenceError::UnsupportedOperation {
                    operation: OP_MONGODB_COMMAND_FAILED,
                })?;
            app_ids.push(app_id.to_string());
        }

        Ok(app_ids)
    }
}

impl MongoPersister {
    fn run_find_command(&self, command: Document) -> Result<Option<Document>, PersistenceError> {
        let mut cursor = self.run_raw_cursor_command(command)?;
        self.cursor_next(&mut cursor)
    }
}
