pub(super) use rurr_testkit::application_fixture::{map_from_pairs, state_from_pairs};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::LazyLock;
use std::time::{SystemTime, UNIX_EPOCH};

static UNIQUE_COUNTER: AtomicUsize = AtomicUsize::new(0);
static RUN_NONCE: LazyLock<u64> = LazyLock::new(|| {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos() as u64
});

pub(super) fn unique_id(prefix: &str) -> String {
    let suffix = UNIQUE_COUNTER.fetch_add(1, Ordering::SeqCst);
    format!("{prefix}_{}_{suffix}", *RUN_NONCE)
}

#[cfg(any(
    not(feature = "sqlite"),
    not(feature = "postgres"),
    not(feature = "redis")
))]
pub(super) fn skip_feature(feature: &str) {
    eprintln!("skipped: enable `{feature}` feature to run this test");
}
