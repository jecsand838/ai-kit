use rurr_core as crate_api;

macro_rules! extra_surface_setup {
    () => {
        let _allowed_project_name: fn(&str, bool) -> bool =
            crate_api::tracking::allowed_project_name;
        let _append_jsonl_locked: fn(&std::path::Path, &serde_json::Value) -> std::io::Result<()> =
            crate_api::tracking::jsonl::append_jsonl_locked;
        let _lock_mode = crate_api::tracking::jsonl::JsonlLockMode::Shared;
        let _tracking_default_storage_dir: &str =
            crate_api::tracking::LocalTrackingClient::DEFAULT_STORAGE_DIR;
        let _ = _lock_mode;
        let _ = _allowed_project_name;
        let _ = _append_jsonl_locked;
        let _ = _tracking_default_storage_dir;
    };
}

macro_rules! extra_surface_types {
    () => {
        touch_type::<crate_api::tracking::ActionModel>();
        touch_type::<crate_api::tracking::ApplicationMetadataModel>();
        touch_type::<crate_api::tracking::LocalTrackingClient>();
        touch_type::<crate_api::tracking::TrackingError>();
        touch_type::<crate_api::tracking::jsonl::JsonlLockMode>();
        #[cfg(feature = "s3")]
        {
            touch_type::<crate_api::tracking::S3AddressingStyle>();
            touch_type::<crate_api::tracking::S3ClientSettings>();
            touch_type::<crate_api::tracking::S3TrackingClient>();
            touch_type::<crate_api::tracking::S3TrackingConfig>();
        }
        touch_type::<crate_api::AsyncStepExecutedAction>();
        touch_type::<std::sync::Arc<dyn crate_api::lifecycle::AsyncLifecycleContextPropagator>>();
        touch_type::<std::sync::Arc<dyn crate_api::lifecycle::AsyncLifecyclePollContext>>();
    };
}

include!("../../test_support/public_surface_contract.inc.rs");
