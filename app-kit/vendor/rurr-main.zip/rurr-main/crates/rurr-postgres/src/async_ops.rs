use super::{
    map_sqlx_error,
    shared::{connection_closed_error, default_async_pool_options, validate_async_database_url},
    AsyncPostgresPersister, PersistedStateData, PersistedStateStatus, PersistenceError,
    PostgresPersisterConfig, OP_POSTGRES_MIGRATION_FAILED, OP_POSTGRES_QUERY_FAILED,
    OP_STATE_SERIALIZATION_FAILED,
};
use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_persistence::{AsyncBaseStateLoader, AsyncBaseStateSaver};
use rurr_persistence::{AsyncSqlxPersistenceCore, PersistedStateSaveRequest, PostgresDialect};
use serde_json::Value;

impl AsyncPostgresPersister {
    /// Creates a lazy async PostgreSQL persister from a serialized config
    /// value.
    pub fn new(config: PostgresPersisterConfig) -> Result<Self, PersistenceError> {
        let connect_options = validate_async_database_url(&config.database_url)?;

        Ok(Self {
            pool: default_async_pool_options().connect_lazy_with(connect_options),
            shared: super::shared::PostgresShared::new(config.database_url, config.table_name)?,
            closed: std::sync::atomic::AtomicBool::new(false),
        })
    }

    /// Returns the configuration originally used to construct this persister.
    pub fn config(&self) -> PostgresPersisterConfig {
        self.shared.config()
    }

    /// Closes the underlying async pool and marks the persister as no longer
    /// usable.
    pub async fn close(&self) -> Result<(), PersistenceError> {
        self.shutdown().await
    }

    async fn shutdown(&self) -> Result<(), PersistenceError> {
        self.core().shutdown().await
    }

    fn core(&self) -> AsyncSqlxPersistenceCore<'_, PostgresDialect> {
        AsyncSqlxPersistenceCore::new(
            &self.pool,
            self.shared.query_plan(),
            self.shared.table_name(),
            self.shared.migration_sql(),
            self.shared.initialization_hint(),
            &self.closed,
            connection_closed_error,
        )
    }
}

#[async_trait]
impl AsyncBaseStateSaver for AsyncPostgresPersister {
    async fn initialize(&self) -> Result<(), PersistenceError> {
        self.core().initialize(map_migration_error).await
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.core().is_initialized(map_query_error).await
    }

    async fn cleanup(&self) -> Result<(), PersistenceError> {
        self.close().await
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.core()
            .save(
                PersistedStateSaveRequest::new(
                    partition_key,
                    app_id,
                    sequence_id,
                    position,
                    state,
                    status,
                ),
                map_query_error,
                OP_STATE_SERIALIZATION_FAILED,
            )
            .await
    }
}

#[async_trait]
impl AsyncBaseStateLoader for AsyncPostgresPersister {
    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.core()
            .load(partition_key, app_id, sequence_id, map_query_error)
            .await
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        self.core()
            .list_app_ids(partition_key, map_query_error)
            .await
    }
}

fn map_query_error(error: sqlx::Error) -> PersistenceError {
    map_sqlx_error(error, OP_POSTGRES_QUERY_FAILED)
}

/// Maps async migration failures into standardized persistence errors.
fn map_migration_error(error: sqlx::Error) -> PersistenceError {
    map_sqlx_error(error, OP_POSTGRES_MIGRATION_FAILED)
}
