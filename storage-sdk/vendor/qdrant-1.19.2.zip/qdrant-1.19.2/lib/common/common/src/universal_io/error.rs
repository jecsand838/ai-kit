use std::io;
use std::path::PathBuf;

/// `Result` extension for treating `NotFound` as `Ok(None)`
pub trait OkNotFound {
    type Ok;

    type Error;

    /// Treat the not found error as `Ok(None)`
    fn ok_not_found(self) -> Result<Option<Self::Ok>, Self::Error>;
}

pub trait IsNotFound {
    fn is_not_found(&self) -> bool;
}

impl IsNotFound for io::Error {
    fn is_not_found(&self) -> bool {
        self.kind() == io::ErrorKind::NotFound
    }
}

impl<T, E: IsNotFound> OkNotFound for Result<T, E> {
    type Ok = T;

    type Error = E;

    fn ok_not_found(self) -> Result<Option<T>, E> {
        match self {
            Ok(t) => Ok(Some(t)),
            Err(err) if err.is_not_found() => Ok(None),
            Err(err) => Err(err),
        }
    }
}

impl IsNotFound for UniversalIoError {
    fn is_not_found(&self) -> bool {
        match self {
            Self::NotFound { .. } => true,
            Self::Io(err) | Self::IoUringNotSupported(err) => err.is_not_found(),
            Self::Mmap(err) => err.is_not_found(),
            Self::Bincode(_)
            | Self::BytemuckCast(_)
            | Self::ZerocopySize(_)
            | Self::OutOfBounds { .. }
            | Self::InvalidFileIndex { .. }
            | Self::Uninitialized { .. }
            | Self::UnchangedOpen { .. }
            | Self::QueueIsFull
            | Self::AppendOffsetConflict { .. }
            | Self::AppendRewriteRequired { .. }
            | Self::AppendEntityTooSmall { .. }
            | Self::AppendEtagMismatch { .. }
            | Self::S3 { .. }
            | Self::S3Config { .. }
            | Self::TaskPanicked(_) => false,
        }
    }
}

pub trait OkUnchanged {
    type Ok;
    type Error;

    fn ok_unchanged(self) -> Result<Option<Self::Ok>, Self::Error>;
}

impl<T> OkUnchanged for Result<T, UniversalIoError> {
    type Ok = T;
    type Error = UniversalIoError;

    fn ok_unchanged(self) -> Result<Option<T>, UniversalIoError> {
        match self {
            Ok(t) => Ok(Some(t)),
            Err(UniversalIoError::UnchangedOpen { .. }) => Ok(None),
            Err(err) => Err(err),
        }
    }
}

#[derive(Debug, thiserror::Error)]
pub enum UniversalIoError {
    #[error(transparent)]
    Io(#[from] io::Error),

    #[error(transparent)]
    Mmap(#[from] crate::mmap::Error),

    #[error(transparent)]
    Bincode(#[from] bincode::Error),

    #[error("Bytemuck cast error: {0:?}")]
    BytemuckCast(bytemuck::PodCastError),

    #[error("Zerocopy size error: {0:?}")]
    ZerocopySize(String),

    #[error(transparent)]
    IoUringNotSupported(io::Error),

    /// Path does not exist or is not accessible; backends may use this instead of
    /// `Io(NotFound)` so callers can match without relying on a specific io::ErrorKind.
    #[error("path {path} not found")]
    NotFound { path: PathBuf },

    #[error("Did not open a new instance of {path} because it didn't change since {since:?}")]
    UnchangedOpen {
        path: PathBuf,
        since: Option<std::time::SystemTime>,
    },

    #[error("elements range {start}..{end} is out of bounds, file contains {elements} elements")]
    OutOfBounds {
        start: u64,
        end: u64,
        elements: usize,
    },

    /// Source id is not valid for this multi-source storage.
    #[error("invalid file index {file_index} during multi-file operation, {files} files provided")]
    InvalidFileIndex { file_index: usize, files: usize },

    #[error("Resource was not initialized: {description}")]
    Uninitialized { description: String },

    #[error("Request queue is full")]
    QueueIsFull,

    /// The append was rejected because the file's end is not at the provided
    /// `offset` (the append already landed, or the caller's view of the file
    /// is stale). Re-check the length before appending anew.
    #[error("append offset conflict at {path}: expected end-of-file offset {offset}")]
    AppendOffsetConflict { path: PathBuf, offset: u64 },

    /// A native append was rejected because the object reached the store's
    /// cap on appended blocks; the object can only keep growing through a
    /// whole-object rewrite.
    #[error("append to {path} rejected: appended-block limit reached, rewrite required")]
    AppendRewriteRequired { path: PathBuf },

    /// A server-side multipart rewrite was rejected because a copied part
    /// is below the store's minimum part size; the object can only be
    /// rebuilt by uploading it whole.
    #[error("multipart rewrite of {path} rejected: below the store's minimum part size")]
    AppendEntityTooSmall { path: PathBuf },

    /// The append was rejected because the object's entity tag no longer
    /// matches the one the caller last observed: the object was replaced
    /// behind the caller's back, which the end-of-file offset check alone
    /// cannot detect when the lengths happen to coincide.
    #[error("append to {path} rejected: entity tag mismatch, the object was replaced")]
    AppendEtagMismatch { path: PathBuf },

    #[error(
        "S3 object store error{}: {source}",
        .path.as_ref().map(|path| format!(" for {}", path.display())).unwrap_or_default(),
    )]
    S3 {
        /// Object the failed operation was addressing, where the call site knows it.
        /// `None` for failures that are not about one particular object.
        path: Option<PathBuf>,
        #[source]
        source: Box<dyn std::error::Error + Send + Sync>,
    },

    #[error("S3 configuration missing or invalid: {description}")]
    S3Config { description: String },

    #[error("Background read task panicked: {0}")]
    TaskPanicked(String),
}

impl UniversalIoError {
    pub fn is_append_offset_conflict(&self) -> bool {
        match self {
            Self::AppendOffsetConflict { .. } => true,
            Self::Io(_)
            | Self::Mmap(_)
            | Self::Bincode(_)
            | Self::BytemuckCast(_)
            | Self::ZerocopySize(_)
            | Self::IoUringNotSupported(_)
            | Self::NotFound { .. }
            | Self::OutOfBounds { .. }
            | Self::InvalidFileIndex { .. }
            | Self::Uninitialized { .. }
            | Self::QueueIsFull
            | Self::AppendRewriteRequired { .. }
            | Self::AppendEntityTooSmall { .. }
            | Self::AppendEtagMismatch { .. }
            | Self::S3 { .. }
            | Self::S3Config { .. }
            | Self::UnchangedOpen { .. }
            | Self::TaskPanicked(_) => false,
        }
    }

    pub fn is_append_rewrite_required(&self) -> bool {
        match self {
            Self::AppendRewriteRequired { .. } => true,
            Self::Io(_)
            | Self::Mmap(_)
            | Self::Bincode(_)
            | Self::BytemuckCast(_)
            | Self::ZerocopySize(_)
            | Self::IoUringNotSupported(_)
            | Self::NotFound { .. }
            | Self::OutOfBounds { .. }
            | Self::InvalidFileIndex { .. }
            | Self::Uninitialized { .. }
            | Self::QueueIsFull
            | Self::AppendOffsetConflict { .. }
            | Self::AppendEntityTooSmall { .. }
            | Self::AppendEtagMismatch { .. }
            | Self::S3 { .. }
            | Self::S3Config { .. }
            | Self::UnchangedOpen { .. }
            | Self::TaskPanicked(_) => false,
        }
    }

    pub fn is_append_entity_too_small(&self) -> bool {
        match self {
            Self::AppendEntityTooSmall { .. } => true,
            Self::Io(_)
            | Self::Mmap(_)
            | Self::Bincode(_)
            | Self::BytemuckCast(_)
            | Self::ZerocopySize(_)
            | Self::IoUringNotSupported(_)
            | Self::NotFound { .. }
            | Self::OutOfBounds { .. }
            | Self::InvalidFileIndex { .. }
            | Self::Uninitialized { .. }
            | Self::QueueIsFull
            | Self::AppendOffsetConflict { .. }
            | Self::AppendRewriteRequired { .. }
            | Self::AppendEtagMismatch { .. }
            | Self::S3 { .. }
            | Self::S3Config { .. }
            | Self::UnchangedOpen { .. }
            | Self::TaskPanicked(_) => false,
        }
    }

    pub fn extract_not_found(err: io::Error, path: impl Into<PathBuf>) -> Self {
        #[expect(clippy::wildcard_enum_match_arm, reason = "error handling")]
        match err.kind() {
            io::ErrorKind::NotFound => Self::NotFound { path: path.into() },
            _ => Self::Io(err),
        }
    }

    pub fn uninitialized(description: impl Into<String>) -> Self {
        Self::Uninitialized {
            description: description.into(),
        }
    }

    pub fn s3<E>(err: E) -> Self
    where
        E: std::error::Error + Send + Sync + 'static,
    {
        Self::S3 {
            path: None,
            source: Box::new(err),
        }
    }

    /// [`Self::s3`] for a failure that was addressing a known object.
    pub fn s3_at<E>(path: impl Into<PathBuf>, err: E) -> Self
    where
        E: std::error::Error + Send + Sync + 'static,
    {
        Self::S3 {
            path: Some(path.into()),
            source: Box::new(err),
        }
    }
}

impl From<serde_json::Error> for UniversalIoError {
    fn from(err: serde_json::Error) -> Self {
        Self::from(io::Error::from(err))
    }
}

impl From<bytemuck::PodCastError> for UniversalIoError {
    fn from(err: bytemuck::PodCastError) -> Self {
        Self::BytemuckCast(err)
    }
}

impl<Src, Dst: ?Sized> From<zerocopy::SizeError<Src, Dst>> for UniversalIoError {
    fn from(err: zerocopy::SizeError<Src, Dst>) -> Self {
        Self::ZerocopySize(format!("{err:?}"))
    }
}

impl From<tokio::task::JoinError> for UniversalIoError {
    fn from(err: tokio::task::JoinError) -> Self {
        if err.is_panic() {
            return Self::TaskPanicked(err.to_string());
        }
        Self::Io(io::Error::from(err))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::universal_io::UniversalKind;

    #[test]
    fn s3_kind_variant_exists() {
        let k = UniversalKind::S3;
        assert_ne!(k, UniversalKind::Mmap);
        assert_ne!(k, UniversalKind::IoUring);
        assert_ne!(k, UniversalKind::DiskCache);
    }

    #[test]
    fn s3_error_variants_format() {
        let e = UniversalIoError::S3Config {
            description: "missing bucket".into(),
        };
        assert!(e.to_string().contains("missing bucket"));
    }
}
