use super::common::{unique_name_suffix, LiveServiceError, ProbeSchedule, ServiceProbe};
use redis::Client;
use std::sync::atomic::AtomicU64;
use std::time::Duration;
use tokio::time::timeout;

const DEFAULT_REDIS_URL: &str = "redis://127.0.0.1:6379/0";
const REDIS_NAMESPACE_SCAN_COUNT: usize = 128;
const REDIS_NAMESPACE_DELETE_BATCH_SIZE: usize = 128;

static REDIS_NAMESPACE_COUNTER: AtomicU64 = AtomicU64::new(0);

/// Builds a unique Redis namespace for a live test run.
pub fn unique_redis_namespace(prefix: &str) -> String {
    let suffix = unique_name_suffix(&REDIS_NAMESPACE_COUNTER);
    format!("rurr_redis_{prefix}_{suffix}")
}

/// Removes all keys under a live-test Redis namespace.
pub fn cleanup_redis_namespace_sync(
    redis_url: &str,
    namespace: &str,
) -> Result<(), LiveServiceError> {
    cleanup_redis_namespace_sync_with_scan_count(redis_url, namespace, REDIS_NAMESPACE_SCAN_COUNT)?;
    Ok(())
}

/// Removes all keys under a live-test Redis namespace using the async client path.
pub async fn cleanup_redis_namespace_async(
    redis_url: &str,
    namespace: &str,
) -> Result<(), LiveServiceError> {
    cleanup_redis_namespace_async_with_scan_count(redis_url, namespace, REDIS_NAMESPACE_SCAN_COUNT)
        .await?;
    Ok(())
}

fn cleanup_redis_namespace_sync_with_scan_count(
    redis_url: &str,
    namespace: &str,
    scan_count: usize,
) -> Result<usize, LiveServiceError> {
    let Some((client, cleanup)) = RedisNamespaceCleanup::prepare(redis_url, namespace, scan_count)?
    else {
        return Ok(0);
    };
    let mut connection = client
        .get_connection()
        .map_err(|error| cleanup.unavailable(format!("cleanup connection failed: {error}")))?;
    let collected = cleanup.collect_keys_sync(&mut connection)?;
    cleanup.delete_keys_sync(&mut connection, &collected.keys)?;

    Ok(collected.scan_batches)
}

async fn cleanup_redis_namespace_async_with_scan_count(
    redis_url: &str,
    namespace: &str,
    scan_count: usize,
) -> Result<usize, LiveServiceError> {
    let Some((client, cleanup)) = RedisNamespaceCleanup::prepare(redis_url, namespace, scan_count)?
    else {
        return Ok(0);
    };
    let mut connection = client
        .get_multiplexed_async_connection()
        .await
        .map_err(|error| cleanup.unavailable(format!("cleanup connection failed: {error}")))?;
    let collected = cleanup.collect_keys_async(&mut connection).await?;
    cleanup
        .delete_keys_async(&mut connection, &collected.keys)
        .await?;

    Ok(collected.scan_batches)
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct NamespaceKeyCollection {
    keys: Vec<String>,
    scan_batches: usize,
}

struct RedisNamespace {
    raw: String,
    key_prefix: String,
    scan_pattern: String,
}

impl RedisNamespace {
    fn new(raw: &str) -> Self {
        Self {
            raw: raw.to_string(),
            key_prefix: format!("{raw}:"),
            scan_pattern: format!("{raw}:*"),
        }
    }

    fn raw(&self) -> &str {
        &self.raw
    }

    fn scan_pattern(&self) -> &str {
        &self.scan_pattern
    }

    fn contains_key(&self, key: &str) -> bool {
        key.starts_with(&self.key_prefix)
    }
}

struct RedisNamespaceCleanup<'a> {
    namespace: RedisNamespace,
    scan_count: usize,
    delete_batch_size: usize,
    probe: ServiceProbe<'a>,
}

struct RedisCleanupFlow<'c, 'a> {
    cleanup: &'c RedisNamespaceCleanup<'a>,
    cursor: u64,
    keys: Vec<String>,
    scan_batches: usize,
    complete: bool,
}

impl<'c, 'a> RedisCleanupFlow<'c, 'a> {
    fn new(cleanup: &'c RedisNamespaceCleanup<'a>) -> Self {
        Self {
            cleanup,
            cursor: 0,
            keys: Vec::new(),
            scan_batches: 0,
            complete: false,
        }
    }

    fn next_scan_command(&self) -> Option<redis::Cmd> {
        (!self.complete).then(|| self.cleanup.scan_command(self.cursor))
    }

    fn accept_scan_batch(&mut self, next_cursor: u64, mut batch: Vec<String>) {
        self.scan_batches += 1;
        self.keys.append(&mut batch);
        self.cursor = next_cursor;
        self.complete = next_cursor == 0;
    }

    fn finish_scan(self) -> Result<NamespaceKeyCollection, LiveServiceError> {
        self.cleanup.finish_keys(self.keys, self.scan_batches)
    }

    fn delete_batches(&self, keys: &'c [String]) -> impl Iterator<Item = &'c [String]> {
        keys.chunks(self.cleanup.delete_batch_size.max(1))
    }
}

#[derive(Clone, Copy)]
enum RedisCommandKind {
    Scan,
    Delete,
}

impl RedisCommandKind {
    fn failure_message(self, error: impl std::fmt::Display) -> String {
        match self {
            Self::Scan => format!("cleanup scan failed: {error}"),
            Self::Delete => format!("cleanup delete failed: {error}"),
        }
    }
}

impl<'a> RedisNamespaceCleanup<'a> {
    fn prepare(
        redis_url: &'a str,
        namespace: &'a str,
        scan_count: usize,
    ) -> Result<Option<(Client, Self)>, LiveServiceError> {
        if namespace.is_empty() {
            return Ok(None);
        }
        let client = validate_redis_url(redis_url)?;
        Ok(Some((client, Self::new(redis_url, namespace, scan_count))))
    }

    fn new(redis_url: &'a str, namespace: &'a str, scan_count: usize) -> Self {
        Self {
            namespace: RedisNamespace::new(namespace),
            scan_count: scan_count.max(1),
            delete_batch_size: REDIS_NAMESPACE_DELETE_BATCH_SIZE,
            probe: ServiceProbe::new("redis", redis_url, ProbeSchedule::live_defaults()),
        }
    }

    #[cfg(test)]
    fn for_namespace(namespace: &'a str, scan_count: usize, probe: ServiceProbe<'a>) -> Self {
        Self {
            namespace: RedisNamespace::new(namespace),
            scan_count: scan_count.max(1),
            delete_batch_size: REDIS_NAMESPACE_DELETE_BATCH_SIZE,
            probe,
        }
    }

    fn unavailable(&self, message: impl Into<String>) -> LiveServiceError {
        self.probe.unavailable(message)
    }

    fn scan_command(&self, cursor: u64) -> redis::Cmd {
        let mut command = redis::cmd("SCAN");
        command
            .arg(cursor)
            .arg("MATCH")
            .arg(self.namespace.scan_pattern())
            .arg("COUNT")
            .arg(self.scan_count);
        command
    }

    fn delete_command(&self, keys: &[String]) -> redis::Cmd {
        let mut command = redis::cmd("DEL");
        command.arg(keys);
        command
    }

    fn finish_keys(
        &self,
        mut keys: Vec<String>,
        scan_batches: usize,
    ) -> Result<NamespaceKeyCollection, LiveServiceError> {
        keys.sort();
        keys.dedup();
        if let Some(key) = keys.iter().find(|key| !self.namespace.contains_key(key)) {
            return Err(self.unavailable(format!(
                "cleanup scan returned key outside namespace '{}': {key}",
                self.namespace.raw()
            )));
        }
        Ok(NamespaceKeyCollection { keys, scan_batches })
    }

    fn query_sync<C, T>(
        &self,
        connection: &mut C,
        command: redis::Cmd,
        kind: RedisCommandKind,
    ) -> Result<T, LiveServiceError>
    where
        C: redis::ConnectionLike,
        T: redis::FromRedisValue,
    {
        command
            .query(connection)
            .map_err(|error| self.unavailable(kind.failure_message(error)))
    }

    async fn query_async<C, T>(
        &self,
        connection: &mut C,
        command: redis::Cmd,
        kind: RedisCommandKind,
    ) -> Result<T, LiveServiceError>
    where
        C: redis::aio::ConnectionLike + Send + Unpin,
        T: redis::FromRedisValue,
    {
        command
            .query_async(connection)
            .await
            .map_err(|error| self.unavailable(kind.failure_message(error)))
    }

    fn collect_keys_sync<C>(
        &self,
        connection: &mut C,
    ) -> Result<NamespaceKeyCollection, LiveServiceError>
    where
        C: redis::ConnectionLike,
    {
        let mut flow = RedisCleanupFlow::new(self);

        while let Some(command) = flow.next_scan_command() {
            let (next_cursor, batch) =
                self.query_sync(connection, command, RedisCommandKind::Scan)?;
            flow.accept_scan_batch(next_cursor, batch);
        }

        flow.finish_scan()
    }

    async fn collect_keys_async<C>(
        &self,
        connection: &mut C,
    ) -> Result<NamespaceKeyCollection, LiveServiceError>
    where
        C: redis::aio::ConnectionLike + Send + Unpin,
    {
        let mut flow = RedisCleanupFlow::new(self);

        while let Some(command) = flow.next_scan_command() {
            let (next_cursor, batch) = self
                .query_async(connection, command, RedisCommandKind::Scan)
                .await?;
            flow.accept_scan_batch(next_cursor, batch);
        }

        flow.finish_scan()
    }

    fn delete_keys_sync<C>(
        &self,
        connection: &mut C,
        keys: &[String],
    ) -> Result<(), LiveServiceError>
    where
        C: redis::ConnectionLike,
    {
        let flow = RedisCleanupFlow::new(self);
        for batch in flow.delete_batches(keys) {
            let _: usize = self.query_sync(
                connection,
                self.delete_command(batch),
                RedisCommandKind::Delete,
            )?;
        }
        Ok(())
    }

    async fn delete_keys_async<C>(
        &self,
        connection: &mut C,
        keys: &[String],
    ) -> Result<(), LiveServiceError>
    where
        C: redis::aio::ConnectionLike + Send + Unpin,
    {
        let flow = RedisCleanupFlow::new(self);
        for batch in flow.delete_batches(keys) {
            let _: usize = self
                .query_async(
                    connection,
                    self.delete_command(batch),
                    RedisCommandKind::Delete,
                )
                .await?;
        }
        Ok(())
    }
}

#[cfg(test)]
fn collect_namespace_keys_sync_with_scan_count<C>(
    connection: &mut C,
    namespace: &str,
    probe: ServiceProbe<'_>,
    scan_count: usize,
) -> Result<NamespaceKeyCollection, LiveServiceError>
where
    C: redis::ConnectionLike,
{
    RedisNamespaceCleanup::for_namespace(namespace, scan_count, probe).collect_keys_sync(connection)
}

#[cfg(test)]
async fn collect_namespace_keys_async_with_scan_count<C>(
    connection: &mut C,
    namespace: &str,
    probe: ServiceProbe<'_>,
    scan_count: usize,
) -> Result<NamespaceKeyCollection, LiveServiceError>
where
    C: redis::aio::ConnectionLike + Send + Unpin,
{
    RedisNamespaceCleanup::for_namespace(namespace, scan_count, probe)
        .collect_keys_async(connection)
        .await
}

/// Returns a validated Redis URL from `REDIS_URL` or the local default.
pub fn redis_url_from_env() -> Result<String, LiveServiceError> {
    let redis_url = std::env::var("REDIS_URL").unwrap_or_else(|_| DEFAULT_REDIS_URL.to_string());
    validate_redis_url(&redis_url)?;
    Ok(redis_url)
}

/// Waits for a Redis server to accept connections and respond to `PING`.
pub async fn wait_for_redis_ready(redis_url: &str) -> Result<(), LiveServiceError> {
    wait_for_redis_ready_with_schedule(redis_url, ProbeSchedule::live_defaults()).await
}

#[cfg(test)]
fn wait_for_redis_ready_sync_with_timeouts(
    redis_url: &str,
    attempt_timeout: Duration,
    total_timeout: Duration,
    retry_delay: Duration,
) -> Result<(), LiveServiceError> {
    wait_for_redis_ready_sync_with_schedule(
        redis_url,
        ProbeSchedule::new(attempt_timeout, total_timeout, retry_delay),
    )
}

fn wait_for_redis_ready_sync_with_schedule(
    redis_url: &str,
    schedule: ProbeSchedule,
) -> Result<(), LiveServiceError> {
    let client = validate_redis_url(redis_url)?;
    let probe = ServiceProbe::new("redis", redis_url, schedule);
    probe.retry_sync(|| probe_redis_sync(&client, schedule.attempt_timeout))
}

async fn wait_for_redis_ready_with_schedule(
    redis_url: &str,
    schedule: ProbeSchedule,
) -> Result<(), LiveServiceError> {
    let client = validate_redis_url(redis_url)?;
    let probe = ServiceProbe::new("redis", redis_url, schedule);
    probe
        .retry_async(|| {
            let client = client.clone();
            async move {
                let mut connection = match timeout(
                    schedule.attempt_timeout,
                    client.get_multiplexed_async_connection(),
                )
                .await
                {
                    Ok(Ok(connection)) => connection,
                    Ok(Err(error)) => return Err(format!("connection failed: {error}")),
                    Err(_) => return Err("connection timed out".to_string()),
                };

                match timeout(
                    schedule.attempt_timeout,
                    redis::cmd("PING").query_async::<String>(&mut connection),
                )
                .await
                {
                    Ok(Ok(_)) => Ok(()),
                    Ok(Err(error)) => Err(format!("ping failed: {error}")),
                    Err(_) => Err("ping timed out".to_string()),
                }
            }
        })
        .await
}

/// Waits synchronously for a Redis server to accept connections and respond to `PING`.
pub fn wait_for_redis_ready_sync(redis_url: &str) -> Result<(), LiveServiceError> {
    wait_for_redis_ready_sync_with_schedule(redis_url, ProbeSchedule::live_defaults())
}

fn validate_redis_url(redis_url: &str) -> Result<Client, LiveServiceError> {
    let probe = ServiceProbe::new("redis", redis_url, ProbeSchedule::live_defaults());
    Client::open(redis_url.to_string()).map_err(|error| probe.invalid(error.to_string()))
}

fn probe_redis_sync(client: &Client, attempt_timeout: Duration) -> Result<(), String> {
    let mut connection = client
        .get_connection_with_timeout(attempt_timeout)
        .map_err(|error| format!("connection failed: {error}"))?;
    connection
        .set_read_timeout(Some(attempt_timeout))
        .map_err(|error| format!("read timeout setup failed: {error}"))?;
    connection
        .set_write_timeout(Some(attempt_timeout))
        .map_err(|error| format!("write timeout setup failed: {error}"))?;
    redis::cmd("PING")
        .query::<String>(&mut connection)
        .map(|_| ())
        .map_err(|error| format!("ping failed: {error}"))
}

#[cfg(test)]
mod tests {
    use super::{
        cleanup_redis_namespace_async, cleanup_redis_namespace_async_with_scan_count,
        cleanup_redis_namespace_sync, cleanup_redis_namespace_sync_with_scan_count,
        collect_namespace_keys_async_with_scan_count, collect_namespace_keys_sync_with_scan_count,
        redis_url_from_env, unique_redis_namespace, validate_redis_url, wait_for_redis_ready,
        wait_for_redis_ready_sync, wait_for_redis_ready_sync_with_timeouts, LiveServiceError,
        NamespaceKeyCollection, RedisNamespaceCleanup, REDIS_NAMESPACE_SCAN_COUNT,
    };
    use crate::live_services::common::tests::StallServer;
    use crate::live_services::common::{ProbeSchedule, ServiceProbe};
    use crate::require_check_live_tests;
    use futures::FutureExt;
    use redis::{AsyncCommands, Commands};
    use std::panic::AssertUnwindSafe;
    use std::time::{Duration, Instant};

    #[test]
    fn wait_for_redis_ready_sync_times_out_against_stalled_server() {
        let server = StallServer::start();
        let redis_url = format!("redis://{}/0", server.address());
        let attempt_timeout = Duration::from_millis(40);
        let total_timeout = Duration::from_millis(120);
        let retry_delay = Duration::from_millis(10);
        let start = Instant::now();

        let error = wait_for_redis_ready_sync_with_timeouts(
            &redis_url,
            attempt_timeout,
            total_timeout,
            retry_delay,
        )
        .expect_err("stalled redis endpoint should time out");

        assert!(matches!(
            &error,
            LiveServiceError::Unavailable {
                service,
                endpoint,
                message,
            } if *service == "redis"
                && endpoint == &redis_url
                && message.contains("probe failed after")
        ));
        assert!(
            start.elapsed() < Duration::from_millis(750),
            "sync redis probe should honor injected timeout bounds"
        );
    }

    #[test]
    fn redis_namespace_cleanup_finish_sorts_and_dedupes_scan_keys() {
        let cleanup =
            RedisNamespaceCleanup::new("redis://127.0.0.1:6379/0", "rurr_test_namespace", 0);

        let collected = cleanup
            .finish_keys(
                vec![
                    "rurr_test_namespace:key:2".to_string(),
                    "rurr_test_namespace:key:1".to_string(),
                    "rurr_test_namespace:key:1".to_string(),
                ],
                3,
            )
            .expect("namespace keys should be valid");

        assert_eq!(collected.scan_batches, 3);
        assert_eq!(
            collected.keys,
            vec![
                "rurr_test_namespace:key:1".to_string(),
                "rurr_test_namespace:key:2".to_string(),
            ]
        );
    }

    #[test]
    fn redis_namespace_cleanup_finish_rejects_keys_outside_namespace() {
        let cleanup =
            RedisNamespaceCleanup::new("redis://127.0.0.1:6379/0", "rurr_test_namespace", 0);

        let error = cleanup
            .finish_keys(vec!["rurr_other_namespace:key".to_string()], 1)
            .expect_err("namespace cleanup should reject keys outside its namespace");

        assert!(matches!(
            &error,
            LiveServiceError::Unavailable {
                service,
                endpoint,
                message,
            } if *service == "redis"
                && endpoint == "redis://127.0.0.1:6379/0"
                && message.contains("outside namespace")
        ));
    }

    #[test]
    fn redis_namespace_cleanup_finish_rejects_adjacent_namespace_prefixes() {
        let cleanup = RedisNamespaceCleanup::new("redis://127.0.0.1:6379/0", "rurr_test", 0);

        for key in ["rurr_test_extra:key", "rurr_testx:key"] {
            let error = cleanup
                .finish_keys(vec![key.to_string()], 1)
                .expect_err("namespace cleanup should reject adjacent namespace prefixes");
            let LiveServiceError::Unavailable { message, .. } = error else {
                panic!("expected unavailable namespace cleanup error");
            };
            assert!(message.contains("outside namespace"));
            assert!(message.contains(key));
        }
    }

    struct RedisNamespaceLiveCase {
        redis_url: String,
        namespace: String,
        sibling_namespace: String,
    }

    impl RedisNamespaceLiveCase {
        fn sync(prefix: &str) -> Self {
            let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
            wait_for_redis_ready_sync(&redis_url).expect("redis must be reachable for live tests");
            Self::new(redis_url, prefix)
        }

        async fn async_case(prefix: &str) -> Self {
            let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
            wait_for_redis_ready(&redis_url)
                .await
                .expect("redis must be reachable for live tests");
            Self::new(redis_url, prefix)
        }

        fn new(redis_url: String, prefix: &str) -> Self {
            Self {
                redis_url,
                namespace: unique_redis_namespace(prefix),
                sibling_namespace: unique_redis_namespace(&format!("{prefix}_sibling")),
            }
        }

        fn seed_sync(&self, namespace: &str, count: usize) {
            let client = validate_redis_url(&self.redis_url).expect("redis URL should validate");
            let mut connection = client
                .get_connection()
                .expect("redis connection should open");
            for index in 0..count {
                connection
                    .set::<_, _, ()>(format!("{namespace}:key:{index:04}"), index)
                    .expect("seed key should succeed");
            }
        }

        async fn seed_async(&self, namespace: &str, count: usize) {
            let client = validate_redis_url(&self.redis_url).expect("redis URL should validate");
            let mut connection = client
                .get_multiplexed_async_connection()
                .await
                .expect("redis connection should open");
            for index in 0..count {
                connection
                    .set::<_, _, ()>(format!("{namespace}:key:{index:04}"), index)
                    .await
                    .expect("seed key should succeed");
            }
        }

        fn keys_sync(&self, namespace: &str) -> Vec<String> {
            let client = validate_redis_url(&self.redis_url).expect("redis URL should validate");
            let probe = ServiceProbe::new("redis", &self.redis_url, ProbeSchedule::live_defaults());
            let mut connection = client
                .get_connection()
                .expect("redis connection should open");
            namespace_keys_sync(&mut connection, namespace, probe).keys
        }

        async fn keys_async(&self, namespace: &str) -> Vec<String> {
            let client = validate_redis_url(&self.redis_url).expect("redis URL should validate");
            let probe = ServiceProbe::new("redis", &self.redis_url, ProbeSchedule::live_defaults());
            let mut connection = client
                .get_multiplexed_async_connection()
                .await
                .expect("redis connection should open");
            namespace_keys_async(&mut connection, namespace, probe)
                .await
                .keys
        }

        fn cleanup_sync(&self, namespace: &str) {
            let _ = cleanup_redis_namespace_sync(&self.redis_url, namespace);
        }

        async fn cleanup_async(&self, namespace: &str) {
            let _ = cleanup_redis_namespace_async(&self.redis_url, namespace).await;
        }
    }

    fn namespace_keys_sync<C>(
        connection: &mut C,
        namespace: &str,
        probe: ServiceProbe<'_>,
    ) -> NamespaceKeyCollection
    where
        C: redis::ConnectionLike,
    {
        collect_namespace_keys_sync_with_scan_count(
            connection,
            namespace,
            probe,
            REDIS_NAMESPACE_SCAN_COUNT,
        )
        .expect("namespace scan should succeed")
    }

    async fn namespace_keys_async<C>(
        connection: &mut C,
        namespace: &str,
        probe: ServiceProbe<'_>,
    ) -> NamespaceKeyCollection
    where
        C: redis::aio::ConnectionLike + Send + Unpin,
    {
        collect_namespace_keys_async_with_scan_count(
            connection,
            namespace,
            probe,
            REDIS_NAMESPACE_SCAN_COUNT,
        )
        .await
        .expect("namespace scan should succeed")
    }

    #[test]
    fn cleanup_redis_namespace_sync_exhausts_multi_batch_namespace() {
        require_check_live_tests!();

        const MULTI_BATCH_KEY_COUNT: usize = 512;

        let case = RedisNamespaceLiveCase::sync("cleanup_sync");
        case.seed_sync(&case.namespace, MULTI_BATCH_KEY_COUNT);
        case.seed_sync(&case.sibling_namespace, 3);

        let result = std::panic::catch_unwind(AssertUnwindSafe(|| {
            let scan_batches =
                cleanup_redis_namespace_sync_with_scan_count(&case.redis_url, &case.namespace, 1)
                    .expect("namespace cleanup should succeed");
            assert!(
                scan_batches > 1,
                "cleanup should traverse more than one scan batch",
            );
            assert!(
                case.keys_sync(&case.namespace).is_empty(),
                "cleanup should remove the full current namespace",
            );

            let sibling_keys = case.keys_sync(&case.sibling_namespace);
            assert_eq!(sibling_keys.len(), 3);
            assert!(
                sibling_keys
                    .iter()
                    .all(|key| key.starts_with(&format!("{}:", case.sibling_namespace))),
                "cleanup should preserve sibling namespace keys",
            );
        }));

        case.cleanup_sync(&case.namespace);
        case.cleanup_sync(&case.sibling_namespace);
        if let Err(payload) = result {
            std::panic::resume_unwind(payload);
        }
    }

    #[tokio::test]
    async fn cleanup_redis_namespace_async_exhausts_multi_batch_namespace() {
        require_check_live_tests!();

        const MULTI_BATCH_KEY_COUNT: usize = 512;

        let case = RedisNamespaceLiveCase::async_case("cleanup_async").await;
        case.seed_async(&case.namespace, MULTI_BATCH_KEY_COUNT)
            .await;
        case.seed_async(&case.sibling_namespace, 3).await;

        let result = AssertUnwindSafe(async {
            let scan_batches =
                cleanup_redis_namespace_async_with_scan_count(&case.redis_url, &case.namespace, 1)
                    .await
                    .expect("namespace cleanup should succeed");
            assert!(
                scan_batches > 1,
                "cleanup should traverse more than one scan batch",
            );
            assert!(
                case.keys_async(&case.namespace).await.is_empty(),
                "cleanup should remove the full current namespace",
            );

            let sibling_keys = case.keys_async(&case.sibling_namespace).await;
            assert_eq!(sibling_keys.len(), 3);
            assert!(
                sibling_keys
                    .iter()
                    .all(|key| key.starts_with(&format!("{}:", case.sibling_namespace))),
                "cleanup should preserve sibling namespace keys",
            );
        })
        .catch_unwind()
        .await;

        case.cleanup_async(&case.namespace).await;
        case.cleanup_async(&case.sibling_namespace).await;
        if let Err(payload) = result {
            std::panic::resume_unwind(payload);
        }
    }
}
