use super::{
    build_otlp_log_exporter, build_otlp_span_exporter, has_any_otlp_endpoint_configuration_reader,
    protocol_from_env_reader, OtlpConfig, OtlpEndpoint, OtlpEnv, OtlpError, OtlpSignal,
};
use opentelemetry_otlp::Protocol;
use std::collections::HashMap;

const OTEL_EXPORTER_OTLP_ENDPOINT_ENV: &str = "OTEL_EXPORTER_OTLP_ENDPOINT";
const OTEL_EXPORTER_OTLP_LOGS_ENDPOINT_ENV: &str = "OTEL_EXPORTER_OTLP_LOGS_ENDPOINT";
const OTEL_EXPORTER_OTLP_LOGS_PROTOCOL_ENV: &str = "OTEL_EXPORTER_OTLP_LOGS_PROTOCOL";
const OTEL_EXPORTER_OTLP_PROTOCOL_ENV: &str = "OTEL_EXPORTER_OTLP_PROTOCOL";
const OTEL_EXPORTER_OTLP_TRACES_ENDPOINT_ENV: &str = "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT";
const OTEL_EXPORTER_OTLP_TRACES_PROTOCOL_ENV: &str = "OTEL_EXPORTER_OTLP_TRACES_PROTOCOL";
const HTTP_OTLP_LIVE_PROOF: &str = "collector_file_export_contains_correlated_trace_and_log";
const GRPC_OTLP_LIVE_PROOF: &str = "collector_file_export_contains_grpc_trace_and_log";
const HTTP_JSON_OTLP_LIVE_PROOF: &str = "collector_file_export_contains_http_json_trace_and_log";

#[derive(Debug, Default)]
struct MapOtlpEnv {
    vars: HashMap<String, String>,
}

impl MapOtlpEnv {
    fn new(vars: impl IntoIterator<Item = (&'static str, &'static str)>) -> Self {
        Self {
            vars: vars
                .into_iter()
                .map(|(key, value)| (key.to_string(), value.to_string()))
                .collect(),
        }
    }
}

impl OtlpEnv for MapOtlpEnv {
    fn var(&self, key: &str) -> Option<String> {
        self.vars.get(key).cloned()
    }

    fn contains_key(&self, key: &str) -> bool {
        self.vars.contains_key(key)
    }
}

#[test]
fn from_env_reader_prefers_explicit_traces_endpoint() {
    let env = MapOtlpEnv::new([
        (
            OTEL_EXPORTER_OTLP_ENDPOINT_ENV,
            "http://collector.example/base",
        ),
        (
            OTEL_EXPORTER_OTLP_TRACES_ENDPOINT_ENV,
            "https://collector.example/custom/traces",
        ),
    ]);

    let config =
        OtlpConfig::from_env_reader(&env).expect("map-backed tracing config should resolve");

    assert_eq!(
        config.traces_endpoint,
        Some(OtlpEndpoint::SignalUrl(
            "https://collector.example/custom/traces".to_string(),
        )),
        "non-live endpoint precedence is limited to Rurr config parsing; provider export behavior is proven by {HTTP_OTLP_LIVE_PROOF}"
    );
}

#[test]
fn single_endpoint_model_resolves_signal_specific_and_base_urls() {
    let env = MapOtlpEnv::new([
        (
            OTEL_EXPORTER_OTLP_ENDPOINT_ENV,
            "http://collector.example/base",
        ),
        (
            OTEL_EXPORTER_OTLP_TRACES_ENDPOINT_ENV,
            "https://collector.example/custom/traces",
        ),
    ]);

    assert_eq!(
        OtlpEndpoint::from_env_reader(OtlpSignal::Traces, &env)
            .expect("trace endpoint should resolve"),
        OtlpEndpoint::SignalUrl("https://collector.example/custom/traces".to_string())
    );
    assert_eq!(
        OtlpEndpoint::from_env_reader(OtlpSignal::Logs, &env)
            .expect("logs endpoint should resolve"),
        OtlpEndpoint::CollectorBaseUrl("http://collector.example/base".to_string())
    );
}

#[test]
fn logs_endpoint_reader_prefers_explicit_logs_endpoint() {
    let env = MapOtlpEnv::new([
        (
            OTEL_EXPORTER_OTLP_ENDPOINT_ENV,
            "http://collector.example/base",
        ),
        (
            OTEL_EXPORTER_OTLP_LOGS_ENDPOINT_ENV,
            "https://collector.example/custom/logs",
        ),
    ]);

    let endpoint = OtlpConfig::default()
        .endpoint_with_env(OtlpSignal::Logs, &env)
        .expect("map-backed logging endpoint should resolve");

    assert_eq!(
        endpoint,
        OtlpEndpoint::SignalUrl("https://collector.example/custom/logs".to_string()),
        "non-live endpoint precedence is limited to Rurr config parsing; provider export behavior is proven by {HTTP_OTLP_LIVE_PROOF}"
    );
}

#[test]
fn collector_base_url_appends_standard_http_paths_for_traces_and_logs() {
    let config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://localhost:4318")
        .with_logs_collector_endpoint("http://localhost:4318")
        .with_protocol(Protocol::HttpBinary);

    let trace_exporter = build_otlp_span_exporter(&config);
    let log_exporter = build_otlp_log_exporter(&config);

    assert!(
        trace_exporter.is_ok(),
        "trace exporter should build from explicit collector base URL; strict provider behavior is proven by {HTTP_OTLP_LIVE_PROOF}, got {trace_exporter:?}"
    );
    assert!(
        log_exporter.is_ok(),
        "log exporter should build from explicit collector base URL; strict provider behavior is proven by {HTTP_OTLP_LIVE_PROOF}, got {log_exporter:?}"
    );
}

#[test]
fn signal_specific_protocol_env_overrides_generic_protocol_env() {
    let env = MapOtlpEnv::new([
        (OTEL_EXPORTER_OTLP_PROTOCOL_ENV, "http/json"),
        (OTEL_EXPORTER_OTLP_TRACES_PROTOCOL_ENV, "http/protobuf"),
        (OTEL_EXPORTER_OTLP_LOGS_PROTOCOL_ENV, "http/protobuf"),
    ]);

    assert_eq!(
        protocol_from_env_reader(OtlpSignal::Traces, &env)
            .expect("trace protocol should resolve"),
        Protocol::HttpBinary,
        "non-live protocol precedence is limited to Rurr config parsing; HTTP/protobuf export behavior is proven by {HTTP_OTLP_LIVE_PROOF}"
    );
    assert_eq!(
        protocol_from_env_reader(OtlpSignal::Logs, &env).expect("log protocol should resolve"),
        Protocol::HttpBinary,
        "non-live protocol precedence is limited to Rurr config parsing; HTTP/protobuf export behavior is proven by {HTTP_OTLP_LIVE_PROOF}"
    );
}

#[test]
fn invalid_protocol_env_is_rejected() {
    let env = MapOtlpEnv::new([(OTEL_EXPORTER_OTLP_TRACES_PROTOCOL_ENV, "smtp")]);

    let result = protocol_from_env_reader(OtlpSignal::Traces, &env);

    assert!(
        matches!(
            result,
            Err(OtlpError::InvalidProtocol {
                signal: OtlpSignal::Traces,
                ..
            })
        ),
        "invalid protocol config should fail explicitly instead of falling back; strict positive protocol lanes are {HTTP_OTLP_LIVE_PROOF}, {HTTP_JSON_OTLP_LIVE_PROOF}, and {GRPC_OTLP_LIVE_PROOF}, got {result:?}"
    );
}

#[test]
fn grpc_protocol_env_resolves_to_grpc() {
    let env = MapOtlpEnv::new([(OTEL_EXPORTER_OTLP_PROTOCOL_ENV, "grpc")]);

    assert_eq!(
        protocol_from_env_reader(OtlpSignal::Traces, &env)
            .expect("trace protocol should resolve"),
        Protocol::Grpc,
        "non-live protocol parsing is limited to Rurr config parsing; gRPC provider behavior is proven by {GRPC_OTLP_LIVE_PROOF}"
    );
    assert_eq!(
        protocol_from_env_reader(OtlpSignal::Logs, &env).expect("log protocol should resolve"),
        Protocol::Grpc,
        "non-live protocol parsing is limited to Rurr config parsing; gRPC provider behavior is proven by {GRPC_OTLP_LIVE_PROOF}"
    );
}

#[tokio::test]
async fn explicit_grpc_protocol_builds_tonic_exporters() {
    let config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4317")
        .with_logs_collector_endpoint("http://127.0.0.1:4317")
        .with_protocol(Protocol::Grpc);

    let trace_result = build_otlp_span_exporter(&config);
    let log_result = build_otlp_log_exporter(&config);

    assert!(
        trace_result.is_ok(),
        "explicit grpc protocol should build a tonic trace exporter; strict provider behavior is proven by {GRPC_OTLP_LIVE_PROOF}, got {trace_result:?}"
    );
    assert!(
        log_result.is_ok(),
        "explicit grpc protocol should build a tonic log exporter; strict provider behavior is proven by {GRPC_OTLP_LIVE_PROOF}, got {log_result:?}"
    );
}

#[test]
fn explicit_http_json_protocol_still_builds_http_exporters() {
    let config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_logs_collector_endpoint("http://127.0.0.1:4318")
        .with_protocol(Protocol::HttpJson);

    let trace_result = build_otlp_span_exporter(&config);
    let log_result = build_otlp_log_exporter(&config);

    assert!(
        trace_result.is_ok(),
        "http/json should remain supported by the HTTP trace exporter; strict provider behavior is proven by {HTTP_JSON_OTLP_LIVE_PROOF}, got {trace_result:?}"
    );
    assert!(
        log_result.is_ok(),
        "http/json should remain supported by the HTTP log exporter; strict provider behavior is proven by {HTTP_JSON_OTLP_LIVE_PROOF}, got {log_result:?}"
    );
}

#[test]
fn has_any_otlp_endpoint_configuration_reader_checks_base_and_signal_specific_vars() {
    let empty_env = MapOtlpEnv::default();
    assert!(
        !has_any_otlp_endpoint_configuration_reader(&empty_env),
        "empty map-backed OTLP env should not report endpoint configuration"
    );

    let logs_env = MapOtlpEnv::new([(
        OTEL_EXPORTER_OTLP_LOGS_ENDPOINT_ENV,
        "http://collector.example/logs",
    )]);
    assert!(
        has_any_otlp_endpoint_configuration_reader(&logs_env),
        "signal-specific OTLP endpoint env should count as configured; strict log export behavior is proven by {HTTP_OTLP_LIVE_PROOF}"
    );
}

#[test]
fn from_env_reader_requires_explicit_traces_endpoint() {
    let empty_env = MapOtlpEnv::default();

    let result = OtlpEndpoint::from_env_reader(OtlpSignal::Traces, &empty_env);

    assert!(
        matches!(
            result,
            Err(OtlpError::MissingEndpointConfiguration(OtlpSignal::Traces))
        ),
        "missing OTLP endpoint config should fail explicitly instead of inventing defaults, got {result:?}"
    );
}

#[test]
fn otlp_provider_builders_reject_missing_tokio_runtime() {
    let config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_logs_collector_endpoint("http://127.0.0.1:4318")
        .with_protocol(Protocol::HttpBinary);

    let trace_exporter = build_otlp_span_exporter(&config);
    let log_exporter = build_otlp_log_exporter(&config);
    let trace_provider = super::build_otlp_tracer_provider(&config);
    let log_provider = super::build_otlp_logger_provider(&config);

    assert!(
        trace_exporter.is_ok(),
        "exporter-only tests must not spawn OTEL batch workers"
    );
    assert!(
        log_exporter.is_ok(),
        "exporter-only tests must not spawn OTEL batch workers"
    );
    assert!(
        matches!(trace_provider, Err(OtlpError::ProviderRuntime(_))),
        "real OTLP trace providers must fail explicitly outside Tokio instead of panicking or spawning hidden runtimes; got {trace_provider:?}"
    );
    assert!(
        matches!(log_provider, Err(OtlpError::ProviderRuntime(_))),
        "real OTLP log providers must fail explicitly outside Tokio instead of panicking or spawning hidden runtimes; got {log_provider:?}"
    );
}

#[tokio::test]
async fn otlp_provider_builders_reject_current_thread_runtime() {
    let config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_protocol(Protocol::HttpBinary);

    let result = super::build_otlp_tracer_provider(&config);

    assert!(
        matches!(result, Err(OtlpError::ProviderRuntime(_))),
        "OTLP providers use async batch processors and must reject current-thread Tokio runtimes; strict positive behavior is proven by {HTTP_OTLP_LIVE_PROOF}, got {result:?}"
    );
}
