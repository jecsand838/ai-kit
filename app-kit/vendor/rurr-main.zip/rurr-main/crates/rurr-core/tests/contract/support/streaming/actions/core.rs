use futures::stream;
use rurr_core::action::{
    ActionError, ActionResult, LocalAsyncStreamOutput, RurrError, StreamOutput,
};
use rurr_core::state::State;
use rurr_testkit::action_fixture::ScriptedActionSpec;
use rurr_testkit::action_metadata::NamedActionMetadata;
use rurr_testkit::application_fixture::map_from_pairs;
use serde_json::{json, Value};
use std::cell::Cell;
use std::pin::Pin;
use std::rc::Rc;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::task::Poll;

#[derive(Debug, Clone, Copy)]
pub(super) enum StreamLane {
    Sync,
    Async,
}

#[derive(Clone)]
pub(super) enum StreamScript {
    Count {
        calls: Option<Arc<AtomicUsize>>,
        plan: CountStreamPlan,
    },
    IncrementOnce,
    AsyncRunFailure,
    NonSendTwoStep {
        calls: Arc<AtomicUsize>,
    },
    Empty,
    PreTargetError {
        attempts: Arc<AtomicUsize>,
    },
    PendingFirstPoll {
        calls: Arc<AtomicUsize>,
        pending_polls: Arc<AtomicUsize>,
    },
    NeverReady {
        pending_polls: Arc<AtomicUsize>,
    },
}

impl StreamScript {
    pub(super) fn count(calls: Option<Arc<AtomicUsize>>, plan: CountStreamPlan) -> Self {
        Self::Count { calls, plan }
    }

    fn into_sync_stream(self, state: State) -> Box<dyn Iterator<Item = StreamOutput>> {
        match self {
            Self::Count { calls, plan } => count_stream(state, calls, plan),
            Self::IncrementOnce
            | Self::AsyncRunFailure
            | Self::PendingFirstPoll { .. }
            | Self::NeverReady { .. } => increment_stream(state),
            Self::NonSendTwoStep { calls } => two_step_sync_stream(state, calls, "stream"),
            Self::Empty => Box::new(std::iter::empty()),
            Self::PreTargetError { attempts } => {
                attempts.fetch_add(1, Ordering::SeqCst);
                Box::new(std::iter::once(pre_target_stream_error()))
            }
        }
    }

    fn into_async_stream(self, state: State) -> LocalAsyncStreamOutput {
        match self {
            Self::Count { calls, plan } => scripted_async_count_stream(state, calls, plan),
            Self::IncrementOnce => Box::pin(stream::iter(increment_stream(state))),
            Self::AsyncRunFailure => Box::pin(stream::once(async {
                Err(RurrError::Action(ActionError::Internal {
                    message: "intentional async run failure".to_string(),
                }))
            })),
            Self::NonSendTwoStep { calls } => two_step_async_stream(state, calls, "poll stream"),
            Self::Empty => Box::pin(stream::empty()),
            Self::PreTargetError { attempts } => {
                attempts.fetch_add(1, Ordering::SeqCst);
                Box::pin(stream::iter([pre_target_stream_error()]))
            }
            Self::PendingFirstPoll {
                calls,
                pending_polls,
            } => pending_first_poll_stream(state, calls, pending_polls),
            Self::NeverReady { pending_polls } => never_ready_stream(pending_polls),
        }
    }
}

pub(super) trait StreamScriptSpecExt {
    fn with_stream_script(self, script: StreamScript) -> Self;
    fn with_stream_scripts(self, sync_script: StreamScript, async_script: StreamScript) -> Self;
}

impl StreamScriptSpecExt for ScriptedActionSpec {
    fn with_stream_script(self, script: StreamScript) -> Self {
        self.with_stream_scripts(script.clone(), script)
    }

    fn with_stream_scripts(self, sync_script: StreamScript, async_script: StreamScript) -> Self {
        self.with_streams(
            move |state, _ctx| sync_script.clone().into_sync_stream(state),
            move |state, _ctx| async_script.clone().into_async_stream(state),
        )
    }
}

#[derive(Debug, Clone)]
pub(super) enum CountStreamPlan {
    Steps {
        terminal_after: usize,
        panic_at: Option<usize>,
    },
    FirstItemError {
        message: &'static str,
    },
    IntermediateOnly {
        emitted: usize,
    },
}

pub(super) fn count_action_metadata() -> NamedActionMetadata {
    NamedActionMetadata::from_slices(&[], &["count"], &[])
}

pub(super) fn count_output(value: i64) -> indexmap::IndexMap<String, Value> {
    map_from_pairs([("count", json!(value))])
}

pub(super) fn increment_count_result(state: &State) -> ActionResult {
    let result = count_output(state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1);
    ActionResult::new(result.clone(), result)
}

pub(super) fn count_base(state: &State) -> i64 {
    state.get("count").and_then(Value::as_i64).unwrap_or(0)
}

pub(super) fn scripted_count_stream_output(
    state: &State,
    calls: Option<&Arc<AtomicUsize>>,
    plan: &CountStreamPlan,
    lane: StreamLane,
    next_index: usize,
) -> Option<StreamOutput> {
    match plan {
        CountStreamPlan::Steps {
            terminal_after,
            panic_at,
        } => {
            if next_index > *terminal_after {
                return None;
            }

            if let Some(calls) = calls {
                calls.fetch_add(1, Ordering::SeqCst);
            }
            if panic_at.is_some_and(|panic_index| panic_index == next_index) {
                let message = match lane {
                    StreamLane::Sync => "intentional panic in sync stream iterator",
                    StreamLane::Async => "intentional panic in async stream iterator",
                };
                panic!("{message}");
            }

            let value = count_base(state) + next_index as i64;
            let item = count_output(value);
            if next_index == *terminal_after {
                let final_state = state
                    .update(count_output(value))
                    .expect("stream terminal state update should succeed");
                Some(Ok((item, Some(final_state))))
            } else {
                Some(Ok((item, None)))
            }
        }
        CountStreamPlan::FirstItemError { message } => {
            (next_index == 1).then(|| Err(RurrError::Message((*message).to_string())))
        }
        CountStreamPlan::IntermediateOnly { emitted } => {
            if next_index > *emitted {
                return None;
            }

            if let Some(calls) = calls {
                calls.fetch_add(1, Ordering::SeqCst);
            }

            let item = count_output(count_base(state) + next_index as i64);
            Some(Ok((item, None)))
        }
    }
}

pub(super) fn scripted_async_count_stream(
    state: State,
    calls: Option<Arc<AtomicUsize>>,
    plan: CountStreamPlan,
) -> Pin<Box<dyn futures::Stream<Item = StreamOutput>>> {
    let stream = stream::unfold(0usize, move |index| {
        let state = state.clone();
        let calls = calls.clone();
        let plan = plan.clone();
        async move {
            let next_index = index + 1;
            scripted_count_stream_output(
                &state,
                calls.as_ref(),
                &plan,
                StreamLane::Async,
                next_index,
            )
            .map(|output| (output, next_index))
        }
    });
    Box::pin(stream)
}

fn count_stream(
    state: State,
    calls: Option<Arc<AtomicUsize>>,
    plan: CountStreamPlan,
) -> Box<dyn Iterator<Item = StreamOutput>> {
    let mut index = 0usize;
    Box::new(std::iter::from_fn(move || {
        index += 1;
        scripted_count_stream_output(&state, calls.as_ref(), &plan, StreamLane::Sync, index)
    }))
}

fn increment_stream(state: State) -> Box<dyn Iterator<Item = StreamOutput>> {
    let result = increment_count_result(&state);
    let output = state
        .update(result.writes().clone())
        .map_err(ActionError::from)
        .map(|next_state| (result.result().clone(), Some(next_state)))
        .map_err(RurrError::from);
    Box::new(std::iter::once(output))
}

fn two_step_sync_stream(
    state: State,
    calls: Arc<AtomicUsize>,
    context: &'static str,
) -> Box<dyn Iterator<Item = StreamOutput>> {
    let script = Rc::new(TwoStepStreamState::new(state, calls, context));
    Box::new(std::iter::from_fn(move || script.next()))
}

fn two_step_async_stream(
    state: State,
    calls: Arc<AtomicUsize>,
    context: &'static str,
) -> LocalAsyncStreamOutput {
    let script = Rc::new(TwoStepStreamState::new(state, calls, context));
    Box::pin(stream::poll_fn(move |_cx| Poll::Ready(script.next())))
}

fn pending_first_poll_stream(
    state: State,
    calls: Arc<AtomicUsize>,
    pending_polls: Arc<AtomicUsize>,
) -> LocalAsyncStreamOutput {
    let script = Rc::new(PendingFirstPollStream::new(state, calls, pending_polls));
    Box::pin(stream::poll_fn(move |cx| script.poll_next(cx)))
}

fn never_ready_stream(pending_polls: Arc<AtomicUsize>) -> LocalAsyncStreamOutput {
    let script = NeverReadyStream::new(pending_polls);
    Box::pin(stream::poll_fn(move |_cx| script.poll_next()))
}

struct TwoStepStreamState {
    state: State,
    base: i64,
    cursor: Cell<usize>,
    calls: Arc<AtomicUsize>,
    context: &'static str,
}

impl TwoStepStreamState {
    fn new(state: State, calls: Arc<AtomicUsize>, context: &'static str) -> Self {
        let base = count_base(&state);
        Self {
            state,
            base,
            cursor: Cell::new(0),
            calls,
            context,
        }
    }

    fn next(&self) -> Option<StreamOutput> {
        let next = self.cursor.get() + 1;
        if next > 2 {
            return None;
        }
        self.cursor.set(next);
        self.calls.fetch_add(1, Ordering::SeqCst);
        Some(self.item(next))
    }

    fn item(&self, next: usize) -> StreamOutput {
        let value = self.base + next as i64;
        let item = count_output(value);
        if next != 2 {
            return Ok((item, None));
        }

        self.state
            .update(count_output(value))
            .map(|final_state| (item, Some(final_state)))
            .map_err(|error| {
                RurrError::Action(ActionError::Internal {
                    message: format!("{} terminal state update failed: {error}", self.context),
                })
            })
    }
}

struct PendingFirstPollStream {
    emitted_pending: Cell<bool>,
    pending_polls: Arc<AtomicUsize>,
    inner: TwoStepStreamState,
}

impl PendingFirstPollStream {
    fn new(state: State, calls: Arc<AtomicUsize>, pending_polls: Arc<AtomicUsize>) -> Self {
        Self {
            emitted_pending: Cell::new(false),
            pending_polls,
            inner: TwoStepStreamState::new(state, calls, "poll async stream"),
        }
    }

    fn poll_next(&self, cx: &mut std::task::Context<'_>) -> Poll<Option<StreamOutput>> {
        if !self.emitted_pending.get() {
            self.emitted_pending.set(true);
            self.pending_polls.fetch_add(1, Ordering::SeqCst);
            cx.waker().wake_by_ref();
            return Poll::Pending;
        }

        Poll::Ready(self.inner.next())
    }
}

struct NeverReadyStream {
    pending_polls: Arc<AtomicUsize>,
}

impl NeverReadyStream {
    fn new(pending_polls: Arc<AtomicUsize>) -> Self {
        Self { pending_polls }
    }

    fn poll_next(&self) -> Poll<Option<StreamOutput>> {
        self.pending_polls.fetch_add(1, Ordering::SeqCst);
        Poll::Pending
    }
}

fn pre_target_stream_error() -> StreamOutput {
    Err(RurrError::Message(
        "pre-target streaming path should not execute".to_string(),
    ))
}
