use super::{
    executor::{execute_tasks_async, execute_tasks_sync, ParallelRuntimeContext},
    runtime::{app_error_to_action_error, runtime_context_for_parallel},
    types::SubGraphTask,
    CascadeMode,
};
use crate::{
    action::api::{ActionContext, ActionError, ActionResult, LocalAction},
    application::builder::ApplicationError,
    state::State,
};
use indexmap::IndexMap;
use serde_json::Value;

const CHILD_STATES_KEY: &str = "child_states";
const FINAL_STATE_KEY: &str = "final_state";

/// Action trait for task-based parallel graph execution.
pub trait TaskBasedParallelAction: LocalAction {
    /// Builds the child graph tasks for the current parent state.
    fn tasks(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<Vec<SubGraphTask>, ApplicationError>;
    /// Reduces child output states into the final action result.
    fn reduce(
        &self,
        parent_state: &State,
        child_states: Vec<State>,
    ) -> Result<ActionResult, ApplicationError>;

    /// Returns whether synchronous execution should feed each child state into the next task.
    fn pipeline_mode(&self) -> bool {
        false
    }

    /// Runs the task-based action on the synchronous path.
    fn run_task_sync(&self, state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError>
    where
        Self: Sized,
    {
        execute_task_based_action_sync(self, state, ctx)
    }

    /// Runs the task-based action on the asynchronous path.
    fn run_task_async(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> impl std::future::Future<Output = Result<ActionResult, ActionError>>
    where
        Self: Sized,
    {
        async move { execute_task_based_action_async(self, state, ctx).await }
    }
}

pub(super) fn execute_task_based_action_sync<A>(
    action: &A,
    state: &State,
    ctx: &ActionContext,
) -> Result<ActionResult, ActionError>
where
    A: TaskBasedParallelAction,
{
    let (tasks, runtime) = prepare_task_execution(action, state, ctx)?;
    finish_task_execution(
        action,
        state,
        execute_tasks_sync(tasks, &runtime, action.pipeline_mode()),
    )
}

pub(super) async fn execute_task_based_action_async<A>(
    action: &A,
    state: &State,
    ctx: &ActionContext,
) -> Result<ActionResult, ActionError>
where
    A: TaskBasedParallelAction,
{
    let (tasks, runtime) = prepare_task_execution(action, state, ctx)?;
    finish_task_execution(
        action,
        state,
        execute_tasks_async(tasks, &runtime, action.pipeline_mode()).await,
    )
}

fn prepare_task_execution<A>(
    action: &A,
    state: &State,
    ctx: &ActionContext,
) -> Result<(Vec<SubGraphTask>, ParallelRuntimeContext), ActionError>
where
    A: TaskBasedParallelAction,
{
    let tasks = action
        .tasks(state, ctx)
        .map_err(app_error_to_action_error)?;
    let runtime = runtime_context_for_parallel(ctx).map_err(app_error_to_action_error)?;
    Ok((tasks, runtime))
}

fn finish_task_execution<A>(
    action: &A,
    parent_state: &State,
    child_states: Result<Vec<State>, ApplicationError>,
) -> Result<ActionResult, ActionError>
where
    A: TaskBasedParallelAction,
{
    let child_states = child_states.map_err(app_error_to_action_error)?;
    action
        .reduce(parent_state, child_states)
        .map_err(app_error_to_action_error)
}

pub(super) fn collapse_child_states(
    _parent_state: &State,
    cascade_mode: &CascadeMode,
    child_states: Vec<State>,
) -> Result<ActionResult, ApplicationError> {
    let child_states_value = states_to_value(&child_states);

    match cascade_mode {
        CascadeMode::None => {
            let mut writes = IndexMap::new();
            writes.insert(CHILD_STATES_KEY.to_string(), child_states_value);
            let result = IndexMap::new();
            Ok(ActionResult::new(result, writes))
        }
        CascadeMode::Fixed(reducer) => {
            let final_state = reducer(child_states)?;
            let mut result = IndexMap::new();
            result.insert(CHILD_STATES_KEY.to_string(), child_states_value);
            result.insert(FINAL_STATE_KEY.to_string(), state_to_value(&final_state));
            Ok(ActionResult::new(result, final_state.get_all()))
        }
        CascadeMode::Pipeline => {
            let final_state = child_states.last().ok_or_else(|| {
                ApplicationError::Action(ActionError::UnsupportedOperation {
                    message: "CascadeMode::Pipeline requires at least one child task".to_string(),
                })
            })?;
            let mut result = IndexMap::new();
            result.insert(CHILD_STATES_KEY.to_string(), child_states_value);
            result.insert(FINAL_STATE_KEY.to_string(), state_to_value(final_state));
            Ok(ActionResult::new(result, final_state.get_all()))
        }
    }
}

fn states_to_value(states: &[State]) -> Value {
    Value::Array(states.iter().map(state_to_value).collect())
}

fn state_to_value(state: &State) -> Value {
    Value::Object(state.get_all().into_iter().collect())
}

#[cfg(test)]
mod tests;
