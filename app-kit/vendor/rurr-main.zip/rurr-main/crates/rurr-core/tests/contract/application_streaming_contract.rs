pub(super) use super::support::streaming::runtime::*;
pub(super) use super::support::streaming::{actions, assertions, builders, cases, hooks};
pub(super) use crate::test_support::{run_subprocess_fixture, subprocess_fixture_enabled};
pub(super) use futures::StreamExt;
pub(super) use indexmap::IndexMap;
pub(super) use rurr_core::action::Condition;
pub(super) use rurr_core::application::ApplicationError;
pub(super) use rurr_core::graph::{GraphError, Transition};
pub(super) use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, LifecycleAdapterSet, SyncLifecycleAdapter,
};
pub(super) use rurr_testkit::application_fixture::{map_from_pairs, state_from_pairs};
pub(super) use serde_json::json;
pub(crate) use std::panic::AssertUnwindSafe;
pub(super) use std::sync::atomic::{AtomicUsize, Ordering};
pub(super) use std::sync::Arc;
pub(super) use std::time::Duration;

macro_rules! sync_stream_case {
    ($name:ident => $body:expr $(,)?) => {
        #[test]
        fn $name() {
            futures::executor::block_on($body);
        }
    };
}

macro_rules! sync_stream_cases {
    ($($name:ident => $body:expr),+ $(,)?) => {
        $(sync_stream_case!($name => $body);)+
    };
}

macro_rules! async_stream_case {
    ($name:ident => $body:expr $(,)?) => {
        #[tokio::test]
        async fn $name() {
            $body.await;
        }
    };
}

macro_rules! async_stream_cases {
    ($($name:ident => $body:expr),+ $(,)?) => {
        $(async_stream_case!($name => $body);)+
    };
}

mod core_matrix;
mod error_and_abort_paths;
mod halt_controls;
mod next_step_guards;
mod reserved_inputs;
mod resumed_halts;
mod stream_handle_semantics;
