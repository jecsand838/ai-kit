use jsonschema::{Draft, JSONSchema};
use rurr_oracle_test_support::{burr_oracle_scenarios, run_oracle_scenario};
use rurr_testkit::test_dir_for_test;
use rurr_testkit::tracking_fixture::artifacts::{try_read_json, try_read_jsonl};
use rurr_tracking_server::schema::burr_compat_version;
use rurr_tracking_server::schema::{
    project_steps, visible_step_count, AnnotationCreate, AnnotationOut, AnnotationUpdate,
    AppSpecResponse, IndexingJob, Project, ReadyResponse, VersionResponse,
};
use serde_json::json;
use serde_json::Value;
use std::error::Error;
use std::fs;
use std::path::{Path, PathBuf};
use tempfile::tempdir;

const FIXED_TRACKING_START_TIME: &str = "2026-04-11T20:51:59.096000Z";
const FIXED_TRACKING_SPAN_TIME: &str = "2026-04-11T20:51:59.096100Z";

struct Schemas {
    tracking_graph: Value,
    tracking_metadata: Value,
    tracking_log_entry: Value,
    tracking_children_entry: Value,
    persisted_state: Value,
}

#[test]
fn tracking_log_schema_any_json_requires_no_runtime_rewrite() -> Result<(), Box<dyn Error>> {
    let schema_path = repo_root()?
        .join("goldens")
        .join("schema")
        .join("tracking.log_entry.schema.json");
    let schema: Value = serde_json::from_str(&fs::read_to_string(schema_path)?)?;
    assert!(
        schema.pointer("/$defs/any_json/anyOf").is_some(),
        "tracking.log_entry.schema.json must define $defs.any_json.anyOf directly"
    );
    assert!(
        schema.pointer("/$defs/any_json/oneOf").is_none(),
        "tracking.log_entry.schema.json must not rely on $defs.any_json.oneOf"
    );
    let _compiled = JSONSchema::options()
        .with_draft(Draft::Draft202012)
        .should_validate_formats(true)
        .compile(&schema)
        .map_err(|error| format!("tracking.log_entry.schema.json must compile as-is: {error}"))?;
    Ok(())
}

#[test]
fn schema_validation_for_oracle_goldens_and_rurr_outputs() -> Result<(), Box<dyn Error>> {
    let repo_root = repo_root()?;
    let schemas = load_schemas(&repo_root)?;

    let oracle_root = repo_root.join("goldens").join("tracking");
    for definition in burr_oracle_scenarios() {
        let scenario_id = definition.id.as_str();
        let oracle_dir = oracle_root.join(definition.id.as_str());
        if !oracle_dir.exists() {
            return Err(format!(
                "missing oracle tracking golden for {} at {}",
                scenario_id,
                oracle_dir.display()
            )
            .into());
        }

        validate_tracking_dir(
            &schemas,
            &oracle_dir,
            definition.expects_children_file,
            &format!("oracle:{scenario_id}"),
        )?;
    }

    let temp_storage_root = test_dir_for_test()?;
    for definition in burr_oracle_scenarios() {
        let scenario_id = definition.id.as_str();
        let run = run_oracle_scenario(definition, &temp_storage_root)?;
        validate_tracking_dir(
            &schemas,
            &run.app_dir,
            definition.expects_children_file,
            &format!("rurr:{scenario_id}"),
        )?;

        if scenario_id == "07_sqlite_persistence_resume" {
            assert!(
                !run.persisted_state_payloads.is_empty(),
                "scenario 07 should emit at least one persisted state payload"
            );
        }

        for (index, payload) in run.persisted_state_payloads.iter().enumerate() {
            assert_schema_valid(
                &schemas.persisted_state,
                payload,
                &format!("rurr:{scenario_id}:persisted_state[{index}]"),
            );
        }
    }

    Ok(())
}

#[test]
fn tracking_server_payload_models_accept_burr_compatible_json() -> Result<(), Box<dyn Error>> {
    let app_spec_json = json!({
        "backend": "local",
        "storage_layout_version": "v1",
        "indexing": false,
        "snapshotting": false,
        "supports_demos": false,
        "supports_annotations": true
    });
    let app_spec: AppSpecResponse = serde_json::from_value(app_spec_json.clone())?;
    assert_eq!(serde_json::to_value(&app_spec)?, app_spec_json);

    let version_json = json!({
        "version": burr_compat_version()
    });
    let version: VersionResponse = serde_json::from_value(version_json.clone())?;
    assert_eq!(serde_json::to_value(&version)?, version_json);

    let ready_json = json!({"ready": true});
    let ready: ReadyResponse = serde_json::from_value(ready_json.clone())?;
    assert_eq!(serde_json::to_value(&ready)?, ready_json);

    let project = Project {
        name: "demo_project".to_string(),
        id: "demo_project".to_string(),
        last_written: "2026-03-20T00:05:00.000000000Z".to_string(),
        created: "2026-03-20T00:00:00.000000000Z".to_string(),
        num_apps: 2,
        uri: None,
    };
    let project_json = serde_json::to_value(&project)?;
    assert_eq!(
        project_json,
        json!({
            "name": "demo_project",
            "id": "demo_project",
            "last_written": "2026-03-20T00:05:00.000000000Z",
            "created": "2026-03-20T00:00:00.000000000Z",
            "num_apps": 2,
            "uri": null
        })
    );
    let project_round_trip: Project = serde_json::from_value(project_json)?;
    assert_eq!(project_round_trip, project);

    let annotation_create_json = json!({
        "span_id": null,
        "step_name": "answer",
        "tags": ["needs-review"],
        "observations": [{
            "data_fields": {
                "note": "looks good",
                "ground_truth": "approved"
            },
            "thumbs_up_thumbs_down": true,
            "data_pointers": [{
                "type": "state_field",
                "field_name": "response",
                "span_id": null
            }]
        }]
    });
    let annotation_create: AnnotationCreate =
        serde_json::from_value(annotation_create_json.clone())?;
    assert_eq!(
        serde_json::to_value(&annotation_create)?,
        annotation_create_json
    );

    let annotation_update_json = json!({
        "span_id": "span-1",
        "step_name": "answer",
        "tags": ["updated"],
        "observations": [{
            "data_fields": {
                "note": "updated note"
            },
            "thumbs_up_thumbs_down": false,
            "data_pointers": [{
                "type": "attribute",
                "field_name": "score",
                "span_id": "span-1"
            }]
        }]
    });
    let annotation_update: AnnotationUpdate =
        serde_json::from_value(annotation_update_json.clone())?;
    assert_eq!(
        serde_json::to_value(&annotation_update)?,
        annotation_update_json
    );

    let annotation_update_missing_tags_json = json!({
        "span_id": "span-2",
        "step_name": "answer",
        "observations": [{
            "data_fields": {
                "note": "missing tags"
            },
            "thumbs_up_thumbs_down": null,
            "data_pointers": []
        }]
    });
    let annotation_update_missing_tags: AnnotationUpdate =
        serde_json::from_value(annotation_update_missing_tags_json)?;
    assert_eq!(
        serde_json::to_value(&annotation_update_missing_tags)?,
        json!({
            "span_id": "span-2",
            "step_name": "answer",
            "tags": [],
            "observations": [{
                "data_fields": {
                    "note": "missing tags"
                },
                "thumbs_up_thumbs_down": null,
                "data_pointers": []
            }]
        })
    );

    let annotation_update_null_tags_json = json!({
        "span_id": null,
        "step_name": "answer",
        "tags": null,
        "observations": [{
            "data_fields": {
                "note": "null tags"
            },
            "thumbs_up_thumbs_down": true,
            "data_pointers": []
        }]
    });
    let annotation_update_null_tags: AnnotationUpdate =
        serde_json::from_value(annotation_update_null_tags_json)?;
    assert_eq!(
        serde_json::to_value(&annotation_update_null_tags)?,
        json!({
            "span_id": null,
            "step_name": "answer",
            "tags": [],
            "observations": [{
                "data_fields": {
                    "note": "null tags"
                },
                "thumbs_up_thumbs_down": true,
                "data_pointers": []
            }]
        })
    );

    let annotation_out_json = json!({
        "span_id": "span-1",
        "step_name": "answer",
        "tags": ["updated"],
        "observations": [{
            "data_fields": {
                "note": "updated note"
            },
            "thumbs_up_thumbs_down": false,
            "data_pointers": [{
                "type": "attribute",
                "field_name": "score",
                "span_id": "span-1"
            }]
        }],
        "id": 7,
        "project_id": "demo_project",
        "app_id": "chat-1",
        "partition_key": null,
        "step_sequence_id": 4,
        "created": "2026-03-20T00:00:00.000000000Z",
        "updated": "2026-03-20T00:01:00.000000000Z"
    });
    let annotation_out: AnnotationOut = serde_json::from_value(annotation_out_json.clone())?;
    assert_eq!(serde_json::to_value(&annotation_out)?, annotation_out_json);

    let indexing_job_json = json!({
        "id": 3,
        "start_time": "2026-03-20T00:00:00.000000000Z",
        "end_time": "2026-03-20T00:05:00.000000000Z",
        "status": "completed",
        "records_processed": 12,
        "metadata": {
            "project": "demo_project"
        }
    });
    let indexing_job: IndexingJob = serde_json::from_value(indexing_job_json.clone())?;
    assert_eq!(serde_json::to_value(&indexing_job)?, indexing_job_json);

    Ok(())
}

#[test]
fn step_projection_preserves_span_first_seen_order() -> Result<(), Box<dyn Error>> {
    let mut log = vec![json!({
        "type": "begin_entry",
        "start_time": FIXED_TRACKING_START_TIME,
        "action": "counter",
        "inputs": {},
        "sequence_id": 0
    })];
    let expected_span_ids = (0..48)
        .map(|index| format!("span-{index:02}"))
        .collect::<Vec<_>>();
    for span_id in &expected_span_ids {
        log.push(json!({
            "type": "begin_span",
            "start_time": FIXED_TRACKING_SPAN_TIME,
            "action_sequence_id": 0,
            "span_id": span_id,
            "span_name": format!("work-{span_id}"),
            "parent_span_id": Value::Null,
            "span_dependencies": []
        }));
    }

    let steps = project_steps(log)?;
    let actual_span_ids = steps[0]
        .spans
        .iter()
        .map(|span| span.begin_entry.span_id.clone())
        .collect::<Vec<_>>();

    assert_eq!(actual_span_ids, expected_span_ids);
    Ok(())
}

#[test]
fn step_count_validates_recognized_log_entries_and_ignores_unknown_types() {
    let malformed_recognized = vec![json!({
        "type": "begin_entry",
        "start_time": FIXED_TRACKING_START_TIME,
        "action": "counter",
        "inputs": {},
        "sequence_id": "not-a-number"
    })];

    assert!(
        visible_step_count(&malformed_recognized).is_err(),
        "recognized malformed entries should fail instead of returning a synthetic count"
    );

    let unknown = vec![json!({
        "type": "unknown_tracking_event",
        "sequence_id": "not-a-number"
    })];
    let count = visible_step_count(&unknown).expect("unknown entries should be ignored");
    assert_eq!(count, 0);
}

fn load_schemas(repo_root: &Path) -> Result<Schemas, Box<dyn Error>> {
    let schema_root = repo_root.join("goldens").join("schema");
    Ok(Schemas {
        tracking_graph: read_schema(&schema_root.join("tracking.graph.schema.json"))?,
        tracking_metadata: read_schema(&schema_root.join("tracking.metadata.schema.json"))?,
        tracking_log_entry: read_schema(&schema_root.join("tracking.log_entry.schema.json"))?,
        tracking_children_entry: read_schema(
            &schema_root.join("tracking.children_entry.schema.json"),
        )?,
        persisted_state: read_schema(&schema_root.join("persistence.persisted_state.schema.json"))?,
    })
}

fn read_schema(path: &Path) -> Result<Value, Box<dyn Error>> {
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

fn validate_tracking_dir(
    schemas: &Schemas,
    dir: &Path,
    expects_children_file: bool,
    label_prefix: &str,
) -> Result<(), Box<dyn Error>> {
    let expected_files: &[&str] = if expects_children_file {
        &["children.jsonl", "graph.json", "log.jsonl", "metadata.json"]
    } else {
        &["graph.json", "log.jsonl", "metadata.json"]
    };
    validate_tracking_dir_layout(dir, expected_files, label_prefix)?;

    let graph_path = dir.join("graph.json");
    let metadata_path = dir.join("metadata.json");
    let log_path = dir.join("log.jsonl");
    let children_path = dir.join("children.jsonl");

    if !graph_path.exists() {
        return Err(format!("{label_prefix} missing graph.json").into());
    }
    if !metadata_path.exists() {
        return Err(format!("{label_prefix} missing metadata.json").into());
    }
    if !log_path.exists() {
        return Err(format!("{label_prefix} missing log.jsonl").into());
    }

    let graph = try_read_json(&graph_path)?;
    assert_schema_valid(
        &schemas.tracking_graph,
        &graph,
        &format!("{label_prefix}:graph.json"),
    );

    let metadata = try_read_json(&metadata_path)?;
    assert_schema_valid(
        &schemas.tracking_metadata,
        &metadata,
        &format!("{label_prefix}:metadata.json"),
    );

    let log_entries = try_read_jsonl(&log_path)?;
    for (index, entry) in log_entries.iter().enumerate() {
        assert_schema_valid(
            &schemas.tracking_log_entry,
            entry,
            &format!("{label_prefix}:log.jsonl[{index}]"),
        );
    }

    if expects_children_file && !children_path.exists() {
        return Err(format!("{label_prefix} missing children.jsonl").into());
    }

    if children_path.exists() {
        let children_entries = try_read_jsonl(&children_path)?;
        for (index, entry) in children_entries.iter().enumerate() {
            assert_schema_valid(
                &schemas.tracking_children_entry,
                entry,
                &format!("{label_prefix}:children.jsonl[{index}]"),
            );
        }
    }

    Ok(())
}

fn validate_tracking_dir_layout(
    dir: &Path,
    expected_files: &[&str],
    label_prefix: &str,
) -> Result<(), Box<dyn Error>> {
    let mut found = Vec::new();
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let path = entry.path();
        if !path.is_file() {
            return Err(
                format!("{label_prefix} unexpected tracking path {}", path.display()).into(),
            );
        }

        let Some(name) = path.file_name().and_then(|item| item.to_str()) else {
            continue;
        };
        if !expected_files.contains(&name) {
            return Err(
                format!("{label_prefix} unexpected tracking file {}", path.display()).into(),
            );
        }
        found.push(name.to_string());
    }

    found.sort();
    let mut expected = expected_files
        .iter()
        .map(|name| name.to_string())
        .collect::<Vec<_>>();
    expected.sort();
    if found != expected {
        return Err(format!(
            "{label_prefix} tracking file set differs: found={found:?} expected={expected:?}"
        )
        .into());
    }
    Ok(())
}

#[test]
fn validate_tracking_dir_rejects_unexpected_extra_files() -> Result<(), Box<dyn Error>> {
    let repo_root = repo_root()?;
    let schemas = load_schemas(&repo_root)?;
    let dir = tempdir()?;
    write_minimal_tracking_dir(dir.path())?;
    fs::write(dir.path().join("extra.json"), "{}")?;

    let error = validate_tracking_dir(&schemas, dir.path(), false, "fixture")
        .expect_err("extra tracking files must be rejected");
    assert!(
        error.to_string().contains("unexpected tracking file"),
        "unexpected error: {error}"
    );
    Ok(())
}

fn assert_schema_valid(schema: &Value, instance: &Value, label: &str) {
    let compiled = JSONSchema::options()
        .with_draft(Draft::Draft202012)
        .should_validate_formats(true)
        .compile(schema)
        .unwrap_or_else(|error| panic!("invalid schema for {label}: {error}"));
    let validation = compiled.validate(instance);
    if let Err(errors) = validation {
        let details = errors
            .map(|error| error.to_string())
            .collect::<Vec<_>>()
            .join("; ");
        panic!("schema validation failed for {label}: {details}");
    }
}

fn repo_root() -> Result<PathBuf, Box<dyn Error>> {
    let crate_root = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    Ok(crate_root.join("../..").canonicalize()?)
}

fn write_minimal_tracking_dir(dir: &Path) -> Result<(), Box<dyn Error>> {
    fs::write(dir.join("graph.json"), minimal_graph_json())?;
    fs::write(dir.join("metadata.json"), minimal_metadata_json())?;
    fs::write(dir.join("log.jsonl"), minimal_log_jsonl())?;
    Ok(())
}

fn minimal_graph_json() -> String {
    serde_json::json!({
        "type": "application",
        "entrypoint": "counter",
        "actions": [{
            "type": "action",
            "name": "counter",
            "reads": ["count"],
            "writes": ["count"],
            "code": "def counter(state): return state",
            "inputs": [],
            "optional_inputs": []
        }],
        "transitions": []
    })
    .to_string()
}

fn minimal_metadata_json() -> String {
    serde_json::json!({
        "type": "application_metadata",
        "partition_key": "pk",
        "parent_pointer": Value::Null,
        "spawning_parent_pointer": Value::Null
    })
    .to_string()
}

fn minimal_log_jsonl() -> String {
    [
        serde_json::json!({
            "type": "begin_entry",
            "start_time": "2026-04-11T20:51:59.096028Z",
            "action": "counter",
            "inputs": {},
            "sequence_id": 0
        }),
        serde_json::json!({
            "type": "end_entry",
            "end_time": "2026-04-11T20:51:59.096382Z",
            "action": "counter",
            "result": {"count": 1},
            "exception": Value::Null,
            "state": {"count": 1, "__SEQUENCE_ID": 0, "__PRIOR_STEP": "counter"},
            "sequence_id": 0
        }),
    ]
    .into_iter()
    .map(|entry| entry.to_string())
    .collect::<Vec<_>>()
    .join("\n")
}
