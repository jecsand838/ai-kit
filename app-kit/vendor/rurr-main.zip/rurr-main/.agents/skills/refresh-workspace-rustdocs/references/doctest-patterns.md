# Doctest Patterns

Use these patterns to keep examples runnable and local-only.

## Sync example pattern

```rust
/// Short summary.
///
/// # Examples
///
/// ```
/// # fn demo() -> anyhow::Result<()> {
/// let value = 1 + 1;
/// assert_eq!(value, 2);
/// # Ok(())
/// # }
/// # demo()?;
/// ```
```

## Async example pattern

```rust
/// Async summary.
///
/// # Examples
///
/// ```no_run
/// # async fn demo() -> anyhow::Result<()> {
/// // Prepare local-only inputs here.
/// # Ok(())
/// # }
/// # tokio_test::block_on(demo())?;
/// ```
```

Prefer a hidden async `main` or crate-local runtime helper when the workspace already exposes one and it passes the repo guardrails better than `tokio_test`.

## Filesystem and config pattern

- Use temp directories, in-memory stores, or local constructors.
- Avoid examples that depend on secrets, external services, or mutable machine-global state.
- Hide setup lines that only exist to make the example compile.

## Re-export pattern

- Put the full runnable example on the defining item.
- Keep the re-export docs short and point users at the canonical source docs when needed.

## Fallback rule

If a stable self-contained doctest is not feasible, explain why in the docs and add the runnable example to the nearest crate, module, or type where local setup is possible.
