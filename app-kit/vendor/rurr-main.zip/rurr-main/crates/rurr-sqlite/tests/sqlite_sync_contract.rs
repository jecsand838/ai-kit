use rurr_core::application::ApplicationBuilder;
use rurr_persistence::{
    ApplicationPersistenceSpec, BaseStateLoader, BaseStateSaver, PersistedStateStatus,
    PersistenceError, StateInitializerSpec,
};
use rurr_sqlite::SqlitePersister;
use rurr_testkit::persistence_cases::{self, map_from_pairs, run_sync_case};
use rurr_testkit::test_dir_for_test;
use serde_json::json;
use std::sync::Arc;

mod support;

use support::{assert_resumed_state, noop_action, SqliteSyncLane};

macro_rules! sync_case_tests {
    ($(($name:ident, $db:literal, $table:literal, $case:path, $message:literal)),+ $(,)?) => {
        $(
            #[test]
            fn $name() {
                let lane = SqliteSyncLane::new($db, $table);
                run_sync_case($case(&lane)).expect($message);
            }
        )+
    };
}

#[test]
fn initialize_creates_table() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let db_path = temp_dir.join("initialize.db");
    let persister = SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path,
        "sync_initialize",
    ))
    .expect("persister should create");

    assert!(!persister
        .is_initialized()
        .expect("is_initialized should work"));

    persister.initialize().expect("initialize should succeed");

    assert!(persister
        .is_initialized()
        .expect("is_initialized should work"));
    assert_eq!(
        persister
            .list_app_ids(Some("partition_key"))
            .expect("list_app_ids should succeed"),
        Vec::<String>::new()
    );
}

#[test]
fn from_values_rejects_digit_prefixed_table_name_sync() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let db_path = temp_dir.join("invalid-table-name.db");

    let error = match SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path,
        "1invalid_table",
    )) {
        Ok(_) => panic!("digit-prefixed table name should be rejected"),
        Err(error) => error,
    };

    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation { operation } if operation == "invalid_table_name"
    ));
}

sync_case_tests!(
    (
        save_load_and_list_app_ids_roundtrip,
        "roundtrip.db",
        "sync_roundtrip",
        persistence_cases::latest_partition_latest_app_exact_and_list,
        "roundtrip assertions should succeed"
    ),
    (
        list_app_ids_orders_by_latest_created_at_not_sequence_id_sync,
        "sync-created-at-order.db",
        "sync_created_order",
        persistence_cases::list_app_ids_order,
        "list_app_ids ordering assertions should succeed"
    ),
    (
        load_without_app_id_orders_by_latest_created_at_not_sequence_id_sync,
        "sync-load-created-at-order.db",
        "sync_load_created_order",
        persistence_cases::latest_partition_prefers_newest_created_at,
        "latest partition ordering assertions should succeed"
    ),
    (
        load_exact_sequence_orders_by_created_at_then_position_sync,
        "sync-load-sequence-order.db",
        "sync_load_sequence_order",
        persistence_cases::exact_sequence_prefers_latest_created_at_then_position,
        "exact-sequence ordering assertions should succeed"
    ),
    (
        load_with_sequence_id_and_no_app_id_returns_none_sync,
        "sync-load-seq-without-app-id.db",
        "sync_load_seq_without_app_id",
        persistence_cases::load_with_sequence_id_and_no_app_id_returns_none,
        "missing-app-id assertions should succeed"
    )
);

#[test]
fn save_accepts_same_sequence_with_different_position_and_rejects_exact_duplicate_sync() {
    let lane = SqliteSyncLane::new("sync-duplicate-identity.db", "sync_duplicate_identity");
    run_sync_case(persistence_cases::duplicate_identity_behavior(
        &lane,
        "sqlite_query_failed",
    ))
    .expect("duplicate identity assertions should succeed");
}

#[test]
fn new_connection_detects_initialized_table() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let db_path = temp_dir.join("new-connection.db");

    let persister = SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path,
        "sync_new_connection",
    ))
    .expect("persister should create");
    persister.initialize().expect("initialize should succeed");

    let new_connection = SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path,
        "sync_new_connection",
    ))
    .expect("persister should create");
    assert!(new_connection
        .is_initialized()
        .expect("is_initialized should work"));
}

#[test]
fn methods_before_initialize_return_not_initialized() {
    let lane = SqliteSyncLane::new("not-initialized.db", "sync_not_initialized");
    run_sync_case(persistence_cases::not_initialized_for_load_save_and_list(
        &lane,
    ));
}

#[test]
fn same_instance_reprobes_after_external_initialize_and_recreate_sync() {
    let lane = SqliteSyncLane::new("sync-reprobe.db", "sync_reprobe");
    run_sync_case(
        persistence_cases::same_instance_reprobes_after_external_initialize_and_recreate(&lane),
    )
    .expect("reprobe assertions should succeed");
}

#[test]
fn methods_support_none_partition_key() {
    let lane = SqliteSyncLane::new("none-partition.db", "sync_none_partition");
    run_sync_case(persistence_cases::none_partition_key_roundtrip(&lane))
        .expect("none-partition assertions should succeed");
}

#[test]
fn initializer_spec_resume_end_to_end_uses_sqlite_persister() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let db_path = temp_dir.join("resume.db");
    let persister = SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path,
        "sync_resume",
    ))
    .expect("persister should create");
    persister.initialize().expect("initialize should succeed");
    persister
        .save(
            Some("sqlite"),
            "test_1",
            7,
            "noop",
            map_from_pairs([("chat_history", json!([1, 2]))]),
            PersistedStateStatus::Completed,
        )
        .expect("save should succeed");

    let initializer: Arc<dyn BaseStateLoader> = Arc::new(persister);
    let app = ApplicationBuilder::new()
        .with_actions(vec![("noop", noop_action())])
        .expect("actions should configure")
        .with_identifiers("test_1", Some("sqlite".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(ApplicationPersistenceSpec::new().with_initializer(
            StateInitializerSpec::sync(
                initializer,
                true,
                map_from_pairs([("chat_history", json!([]))]),
                "noop",
                None,
            ),
        ))
        .expect("initializer spec should configure")
        .build()
        .expect("build should succeed");

    assert_resumed_state(&app, 7);
}
