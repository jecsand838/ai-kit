use crate::state::State;
use indexmap::IndexMap;
use rurr_expr::{condition_rule_name, ExprError};
use serde_json::Value;
use std::collections::HashSet;
use std::fmt;
use std::ops::{BitAnd, BitOr, Not};
use std::sync::Arc;
use thiserror::Error;

type ConditionPredicate = dyn Fn(&State) -> Result<bool, ConditionError> + Send + Sync + 'static;

/// Burr-style operator used by [`ConditionRule`].
pub use rurr_expr::ComparisonOperator as ConditionOperator;

/// Error returned while validating or evaluating a transition condition.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum ConditionError {
    /// One or more required state keys were absent during evaluation.
    #[error(
        "condition '{condition_name}' requires missing state keys: {missing_keys:?}. available keys: {available_keys:?}"
    )]
    MissingRequiredKeys {
        /// Condition name used in diagnostics.
        condition_name: String,
        /// Keys that were required but absent.
        missing_keys: Vec<String>,
        /// Keys that were available in the evaluated state.
        available_keys: Vec<String>,
    },
    /// Burr expression parsing or evaluation failed.
    #[error("failed to evaluate expression '{expression}': {source}")]
    Expr {
        /// Original expression string.
        expression: String,
        /// Underlying expression engine error.
        source: ExprError,
    },
    /// A Burr-style `when(...)` rule failed while comparing an existing state key.
    #[error(
        "failed to evaluate when condition '{condition_name}' for key '{key}' with operator '{operator}': {source}"
    )]
    When {
        /// Condition name used in diagnostics.
        condition_name: String,
        /// State key being compared.
        key: String,
        /// Operator used by the failed rule.
        operator: ConditionOperator,
        /// Underlying expression comparison error.
        source: ExprError,
    },
}

/// One Rust-native Burr-style `when(...)` comparison rule.
#[derive(Debug, Clone, PartialEq)]
pub struct ConditionRule {
    key: String,
    operator: ConditionOperator,
    value: Value,
}

impl ConditionRule {
    /// Creates an explicit equality rule, matching Burr's `key__eq=value`.
    pub fn eq(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::Eq, value)
    }

    /// Creates an inequality rule, matching Burr's `key__ne=value`.
    pub fn ne(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::NotEq, value)
    }

    /// Creates a greater-than rule, matching Burr's `key__gt=value`.
    pub fn gt(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::Gt, value)
    }

    /// Creates a greater-than-or-equal rule, matching Burr's `key__gte=value`.
    pub fn gte(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::GtE, value)
    }

    /// Creates a less-than rule, matching Burr's `key__lt=value`.
    pub fn lt(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::Lt, value)
    }

    /// Creates a less-than-or-equal rule, matching Burr's `key__lte=value`.
    pub fn lte(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::LtE, value)
    }

    /// Creates a membership rule, matching Burr's `key__in=value`.
    pub fn in_(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::In, value)
    }

    /// Creates a negated membership rule, matching Burr's `key__notin=value`.
    pub fn not_in(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::NotIn, value)
    }

    /// Creates a contains rule, matching Burr's `key__contains=value`.
    pub fn contains(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::Contains, value)
    }

    /// Creates an identity-style rule, matching Burr's `key__is=value`.
    pub fn is(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::Is, value)
    }

    /// Creates a negated identity-style rule, matching Burr's `key__isnot=value`.
    pub fn is_not(key: impl Into<String>, value: impl Into<Value>) -> Self {
        Self::new(key, ConditionOperator::IsNot, value)
    }

    /// Returns the state key this rule reads.
    pub fn key(&self) -> &str {
        &self.key
    }

    /// Returns the operator used by this rule.
    pub fn operator(&self) -> ConditionOperator {
        self.operator
    }

    /// Returns the comparison value used by this rule.
    pub fn value(&self) -> &Value {
        &self.value
    }

    fn new(key: impl Into<String>, operator: ConditionOperator, value: impl Into<Value>) -> Self {
        Self {
            key: key.into(),
            operator,
            value: value.into(),
        }
    }

    fn name_part(&self) -> String {
        condition_rule_name(&self.key, self.operator, &self.value)
    }
}

impl<K, V> From<(K, V)> for ConditionRule
where
    K: Into<String>,
    V: Into<Value>,
{
    fn from((key, value): (K, V)) -> Self {
        Self::eq(key, value)
    }
}

/// Boolean transition condition evaluated against application state.
#[derive(Clone)]
pub struct Condition {
    reads: Vec<String>,
    kind: ConditionKind,
    name: String,
}

#[derive(Clone)]
enum ConditionKind {
    Default,
    Expr(ExprCondition),
    When(WhenCondition),
    Custom(Arc<ConditionPredicate>),
    Not(Box<Condition>),
    And(Box<Condition>, Box<Condition>),
    Or(Box<Condition>, Box<Condition>),
}

#[derive(Clone)]
struct ExprCondition {
    expression: String,
    parsed: Result<rurr_expr::ExprAst, ExprError>,
}

impl ExprCondition {
    fn new(expression: String) -> Self {
        Self {
            parsed: rurr_expr::parse(&expression),
            expression,
        }
    }

    fn reads(&self) -> Vec<String> {
        self.parsed
            .as_ref()
            .map(rurr_expr::referenced_names)
            .unwrap_or_default()
    }

    fn evaluate(&self, state: &State) -> Result<bool, ConditionError> {
        match &self.parsed {
            Ok(ast) => {
                rurr_expr::evaluate_bool(ast, state).map_err(|source| ConditionError::Expr {
                    expression: self.expression.clone(),
                    source,
                })
            }
            Err(source) => Err(ConditionError::Expr {
                expression: self.expression.clone(),
                source: source.clone(),
            }),
        }
    }
}

#[derive(Clone)]
struct WhenCondition {
    rules: Vec<ConditionRule>,
}

impl WhenCondition {
    fn new(rules: Vec<ConditionRule>) -> Self {
        Self { rules }
    }

    fn reads(&self) -> Vec<String> {
        let mut reads = Vec::new();
        let mut seen = HashSet::new();
        for rule in &self.rules {
            if seen.insert(rule.key.clone()) {
                reads.push(rule.key.clone());
            }
        }
        reads
    }

    fn name(&self) -> String {
        let mut indexed_rules: Vec<(usize, &ConditionRule)> =
            self.rules.iter().enumerate().collect();
        indexed_rules.sort_by(|(left_index, left), (right_index, right)| {
            left.key
                .cmp(&right.key)
                .then_with(|| left_index.cmp(right_index))
        });
        indexed_rules
            .into_iter()
            .map(|(_index, rule)| rule.name_part())
            .collect::<Vec<_>>()
            .join(", ")
    }

    fn evaluate(&self, state: &State, condition_name: &str) -> Result<bool, ConditionError> {
        for rule in &self.rules {
            let actual =
                state
                    .get(rule.key())
                    .ok_or_else(|| ConditionError::MissingRequiredKeys {
                        condition_name: condition_name.to_string(),
                        missing_keys: vec![rule.key().to_string()],
                        available_keys: state.keys(),
                    })?;
            let matches = rurr_expr::compare_json_values(actual, rule.operator(), rule.value())
                .map_err(|source| ConditionError::When {
                    condition_name: condition_name.to_string(),
                    key: rule.key().to_string(),
                    operator: rule.operator(),
                    source,
                })?;
            if !matches {
                return Ok(false);
            }
        }
        Ok(true)
    }
}

impl ConditionKind {
    fn evaluate_unvalidated(
        &self,
        state: &State,
        condition_name: &str,
    ) -> Result<bool, ConditionError> {
        match self {
            Self::Default => Ok(true),
            Self::Expr(condition) => condition.evaluate(state),
            Self::When(condition) => condition.evaluate(state, condition_name),
            Self::Custom(predicate) => predicate(state),
            Self::Not(condition) => Ok(!condition.evaluate_unvalidated(state)?),
            Self::And(left, right) => {
                if !left.evaluate_unvalidated(state)? {
                    return Ok(false);
                }
                right.evaluate_unvalidated(state)
            }
            Self::Or(left, right) => {
                if left.evaluate_unvalidated(state)? {
                    return Ok(true);
                }
                right.evaluate_unvalidated(state)
            }
        }
    }
}

impl Condition {
    /// Field name used by [`Condition::run`] to return the boolean result.
    pub const KEY: &'static str = "PROCEED";

    /// Creates a condition from explicit read keys, predicate, and display
    /// name.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use indexmap::IndexMap;
    /// use rurr_core::{Condition, State};
    /// use serde_json::json;
    ///
    /// let condition = Condition::new(["count"], |state| {
    ///     state.get("count").and_then(|value| value.as_i64()).unwrap_or(0) > 0
    /// }, "count_positive");
    /// let state = State::new(IndexMap::from([("count".to_string(), json!(2))]));
    /// assert!(condition.evaluate(&state)?);
    /// # Ok::<(), rurr_core::ConditionError>(())
    /// ```
    pub fn new<K, I, F>(keys: I, predicate: F, name: impl Into<String>) -> Self
    where
        K: Into<String>,
        I: IntoIterator<Item = K>,
        F: Fn(&State) -> bool + Send + Sync + 'static,
    {
        Self {
            reads: keys.into_iter().map(Into::into).collect(),
            kind: ConditionKind::Custom(Arc::new(move |state| Ok(predicate(state)))),
            name: name.into(),
        }
    }

    /// Creates a Burr-style `when(...)` condition from equality or operator rules.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use rurr_core::{Condition, ConditionRule, State};
    /// use indexmap::IndexMap;
    /// use serde_json::json;
    ///
    /// let exact = Condition::when([("route", json!("done"))]);
    /// let adult = Condition::when([ConditionRule::gte("age", json!(18))]);
    /// let state = State::new(IndexMap::from([
    ///     ("route".to_string(), json!("done")),
    ///     ("age".to_string(), json!(20)),
    /// ]));
    ///
    /// assert!(exact.evaluate(&state)?);
    /// assert!(adult.evaluate(&state)?);
    /// # Ok::<(), rurr_core::ConditionError>(())
    /// ```
    pub fn when<R, I>(rules: I) -> Self
    where
        R: Into<ConditionRule>,
        I: IntoIterator<Item = R>,
    {
        let rules: Vec<ConditionRule> = rules.into_iter().map(Into::into).collect();
        let condition = WhenCondition::new(rules);
        Self {
            reads: condition.reads(),
            name: condition.name(),
            kind: ConditionKind::When(condition),
        }
    }

    /// Creates a condition backed by a Burr-compatible boolean expression.
    ///
    /// Expressions use Rurr's bounded evaluator, including Python-style `is`
    /// and `is not` for JSON null and boolean singleton checks.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use indexmap::IndexMap;
    /// use rurr_core::{Condition, State};
    /// use serde_json::json;
    ///
    /// let condition = Condition::expr("count > 1");
    /// let state = State::new(IndexMap::from([("count".to_string(), json!(2))]));
    /// assert!(condition.evaluate(&state)?);
    /// # Ok::<(), rurr_core::ConditionError>(())
    /// ```
    pub fn expr(expression: impl Into<String>) -> Self {
        let expression = expression.into();
        let condition = ExprCondition::new(expression);
        Self {
            reads: condition.reads(),
            name: condition.expression.clone(),
            kind: ConditionKind::Expr(condition),
        }
    }

    /// Returns the display name used in diagnostics and graph output.
    pub fn name(&self) -> &str {
        &self.name
    }

    /// Returns the state keys read by the condition.
    pub fn reads(&self) -> &[String] {
        &self.reads
    }

    /// Validates that the referenced state keys are present.
    pub fn validate(&self, state: &State) -> Result<(), ConditionError> {
        let mut missing_keys = Vec::new();
        let mut seen = HashSet::new();
        for key in &self.reads {
            if !state.contains_key(key) && seen.insert(key.clone()) {
                missing_keys.push(key.clone());
            }
        }

        if missing_keys.is_empty() {
            return Ok(());
        }

        Err(ConditionError::MissingRequiredKeys {
            condition_name: self.name.clone(),
            missing_keys,
            available_keys: state.keys(),
        })
    }

    /// Evaluates the condition against the provided state.
    pub fn evaluate(&self, state: &State) -> Result<bool, ConditionError> {
        self.validate(state)?;
        self.evaluate_unvalidated(state)
    }

    /// Runs the condition and returns a Burr-style `{"PROCEED": bool}` map.
    pub fn run(&self, state: &State) -> Result<IndexMap<String, Value>, ConditionError> {
        let should_proceed = self.evaluate(state)?;
        Ok(IndexMap::from([(
            Self::KEY.to_string(),
            Value::Bool(should_proceed),
        )]))
    }

    fn evaluate_unvalidated(&self, state: &State) -> Result<bool, ConditionError> {
        self.kind.evaluate_unvalidated(state, &self.name)
    }
}

impl Default for Condition {
    fn default() -> Self {
        Self {
            reads: Vec::new(),
            kind: ConditionKind::Default,
            name: "default".to_string(),
        }
    }
}

impl fmt::Debug for Condition {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Condition")
            .field("name", &self.name)
            .field("reads", &self.reads)
            .finish()
    }
}

impl Not for Condition {
    type Output = Condition;

    fn not(self) -> Self::Output {
        let name = format!("~{}", self.name);
        let reads = self.reads.clone();
        Self {
            reads,
            kind: ConditionKind::Not(Box::new(self)),
            name,
        }
    }
}

impl BitAnd for Condition {
    type Output = Condition;

    fn bitand(self, rhs: Self) -> Self::Output {
        let mut reads = self.reads.clone();
        reads.extend(rhs.reads.clone());

        let name = format!("{} & {}", self.name, rhs.name);

        Self {
            reads,
            kind: ConditionKind::And(Box::new(self), Box::new(rhs)),
            name,
        }
    }
}

impl BitOr for Condition {
    type Output = Condition;

    fn bitor(self, rhs: Self) -> Self::Output {
        let mut reads = self.reads.clone();
        reads.extend(rhs.reads.clone());

        let name = format!("{} | {}", self.name, rhs.name);

        Self {
            reads,
            kind: ConditionKind::Or(Box::new(self), Box::new(rhs)),
            name,
        }
    }
}
