use indexmap::IndexMap;
use rurr_core::application::ApplicationBuilder;

#[rustfmt::skip]
fn main() {
    let _ = ApplicationBuilder::new().initialize_from(
        unimplemented!(),
        true,
        IndexMap::new(),
    );
}
