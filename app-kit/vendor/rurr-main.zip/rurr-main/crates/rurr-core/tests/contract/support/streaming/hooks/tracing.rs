use rurr_core::lifecycle::LifecycleError;
use rurr_core::lifecycle::{AsyncLifecycleAdapter, SpanContext, SyncLifecycleAdapter};
use std::sync::{Arc, Mutex};

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct UpdateTraceSpanStartEvent {
    pub(crate) span_id: String,
    pub(crate) span_name: String,
}

#[derive(Debug, Default)]
pub(crate) struct UpdateTraceSpanEvents {
    pre_start: Mutex<Vec<UpdateTraceSpanStartEvent>>,
    post_end: Mutex<Vec<String>>,
}

impl UpdateTraceSpanEvents {
    pub(crate) fn pre_start_events(&self) -> Vec<UpdateTraceSpanStartEvent> {
        self.pre_start
            .lock()
            .expect("pre_start lock should not be poisoned")
            .clone()
    }

    pub(crate) fn post_end_events(&self) -> Vec<String> {
        self.post_end
            .lock()
            .expect("post_end lock should not be poisoned")
            .clone()
    }
}

#[derive(Debug)]
pub(crate) struct UpdateTraceSpanHook {
    events: Arc<UpdateTraceSpanEvents>,
}

impl UpdateTraceSpanHook {
    pub(crate) fn new(events: Arc<UpdateTraceSpanEvents>) -> Self {
        Self { events }
    }
}

impl SyncLifecycleAdapter for UpdateTraceSpanHook {
    fn pre_start_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.events
            .pre_start
            .lock()
            .expect("pre_start lock should not be poisoned")
            .push(UpdateTraceSpanStartEvent {
                span_id: context.span_id().to_string(),
                span_name: context.span_name().unwrap_or(context.span_id()).to_string(),
            });
        Ok(())
    }

    fn post_end_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.events
            .post_end
            .lock()
            .expect("post_end lock should not be poisoned")
            .push(context.span_id().to_string());
        Ok(())
    }
}

impl AsyncLifecycleAdapter for UpdateTraceSpanHook {}
