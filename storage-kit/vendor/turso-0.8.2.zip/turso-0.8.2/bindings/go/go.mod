module turso.tech/database/tursogo

go 1.24.0

toolchain go1.24.10

require (
	github.com/ebitengine/purego v0.9.1
	github.com/stretchr/testify v1.11.1
	github.com/tursodatabase/turso-go-platform-libs v0.0.0-20251210190052-57d6c2f7db38
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/mattn/go-sqlite3 v1.14.42 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	golang.org/x/sys v0.38.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
