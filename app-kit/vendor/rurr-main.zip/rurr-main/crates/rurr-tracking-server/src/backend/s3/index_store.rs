use super::super::BackendError;
use crate::schema::{ApplicationPage, ApplicationSummary, IndexingJob, Project};
use rurr_core::tracking::{
    partition_segment, PointerModel, S3ArtifactIndexPayload, S3TrackingObjectKey,
};
use rurr_core::ParentPointer;
use serde_json::Value;
use sqlx::sqlite::{SqliteConnectOptions, SqlitePoolOptions, SqliteRow};
use sqlx::{Row, Sqlite, SqlitePool, Transaction};
use std::collections::BTreeMap;
use std::path::Path;

/// SQLite index store for the S3 tracking backend.
#[derive(Clone)]
pub(super) struct S3IndexStore {
    pool: SqlitePool,
}

pub(super) struct IndexingJobRun<'store> {
    store: &'store S3IndexStore,
    job_id: i64,
    bucket: &'store str,
}

impl<'store> IndexingJobRun<'store> {
    pub(super) async fn start(
        store: &'store S3IndexStore,
        bucket: &'store str,
    ) -> Result<Self, BackendError> {
        let job_id = store.record_indexing_job_started(bucket).await?;
        Ok(Self {
            store,
            job_id,
            bucket,
        })
    }

    pub(super) async fn finish(
        self,
        result: Result<u64, BackendError>,
    ) -> Result<(), BackendError> {
        match result {
            Ok(records) => {
                self.store
                    .finish_indexing_job(
                        self.job_id,
                        "SUCCESS",
                        records,
                        serde_json::json!({"bucket": self.bucket}),
                    )
                    .await
            }
            Err(error) => {
                let error_message = error.to_string();
                match self
                    .store
                    .finish_indexing_job(
                        self.job_id,
                        "FAILURE",
                        0,
                        serde_json::json!({"error": error_message}),
                    )
                    .await
                {
                    Ok(()) => Err(error),
                    Err(recording) => Err(BackendError::IndexingJobFinalization {
                        operation: "finish_indexing_job",
                        primary: Box::new(error),
                        recording: Box::new(recording),
                    }),
                }
            }
        }
    }
}

impl S3IndexStore {
    pub(super) async fn open(db_path: &Path) -> Result<Self, BackendError> {
        if let Some(parent) = db_path.parent() {
            tokio::fs::create_dir_all(parent).await?;
        }
        let options = SqliteConnectOptions::new()
            .filename(db_path)
            .create_if_missing(true);
        let pool = SqlitePoolOptions::new()
            .max_connections(1)
            .connect_with(options)
            .await?;
        migrate(&pool).await?;
        Ok(Self { pool })
    }

    pub(super) fn pool(&self) -> &SqlitePool {
        &self.pool
    }

    pub(super) async fn record_indexing_job_started(
        &self,
        bucket: &str,
    ) -> Result<i64, BackendError> {
        let metadata = serde_json::json!({"bucket": bucket});
        let result = sqlx::query(
            "INSERT INTO indexing_jobs (start_time, status, records_processed, metadata_json)
             VALUES (?1, 'RUNNING', 0, ?2)",
        )
        .bind(now_string("record_indexing_job_started")?)
        .bind(metadata.to_string())
        .execute(&self.pool)
        .await?;
        Ok(result.last_insert_rowid())
    }

    pub(super) async fn finish_indexing_job(
        &self,
        job_id: i64,
        status: &str,
        records_processed: u64,
        metadata: Value,
    ) -> Result<(), BackendError> {
        sqlx::query(
            "UPDATE indexing_jobs
             SET end_time = ?1, status = ?2, records_processed = ?3, metadata_json = ?4
             WHERE id = ?5",
        )
        .bind(now_string("finish_indexing_job")?)
        .bind(status)
        .bind(records_processed as i64)
        .bind(metadata.to_string())
        .bind(job_id)
        .execute(&self.pool)
        .await?;
        Ok(())
    }

    pub(super) async fn high_watermark(
        &self,
        project: &str,
    ) -> Result<Option<String>, BackendError> {
        let row = sqlx::query("SELECT high_watermark_key FROM index_status WHERE project_id = ?1")
            .bind(project)
            .fetch_optional(&self.pool)
            .await?;
        Ok(row
            .map(|row| row.try_get::<Option<String>, _>("high_watermark_key"))
            .transpose()?
            .flatten())
    }

    pub(super) async fn apply_project_updates(
        &self,
        project: &str,
        updates: &[IndexedArtifact],
        high_watermark: &str,
    ) -> Result<u64, BackendError> {
        let mut tx = self.pool.begin().await?;
        for update in updates {
            apply_artifact_update(&mut tx, update).await?;
        }
        set_high_watermark(&mut tx, project, high_watermark).await?;
        tx.commit().await?;
        Ok(updates.len() as u64)
    }

    pub(super) async fn list_projects(&self) -> Result<Vec<Project>, BackendError> {
        let rows = sqlx::query(
            "SELECT projects.project_id,
                    projects.created_at,
                    projects.last_written,
                    COUNT(applications.app_id) AS num_apps
             FROM projects
             LEFT JOIN applications
               ON applications.project_id = projects.project_id
             GROUP BY projects.project_id, projects.created_at, projects.last_written
             ORDER BY projects.project_id",
        )
        .fetch_all(&self.pool)
        .await?;
        rows.into_iter()
            .map(|row| {
                let name = row.try_get::<String, _>("project_id")?;
                Ok(Project {
                    name: name.clone(),
                    id: name,
                    last_written: row.try_get("last_written")?,
                    created: row.try_get("created_at")?,
                    num_apps: row.try_get::<i64, _>("num_apps")? as usize,
                    uri: None,
                })
            })
            .collect()
    }

    pub(super) async fn list_apps(
        &self,
        project_id: &str,
        partition_key: Option<&str>,
        limit: usize,
        offset: usize,
    ) -> Result<ApplicationPage, BackendError> {
        let partition_norm = partition_key.map(|value| partition_segment(Some(value)));
        let rows = sqlx::query(
            "WITH filtered_apps AS (
               SELECT app_id, partition_key, partition_norm, created_at, last_written,
                      parent_pointer_json, spawning_parent_pointer_json
               FROM applications
               WHERE project_id = ?1 AND (?2 IS NULL OR partition_norm = ?2)
             ),
             total_count AS (
               SELECT COUNT(*) AS total FROM filtered_apps
             ),
             selected_apps AS (
               SELECT app_id, partition_key, partition_norm, created_at, last_written,
                      parent_pointer_json, spawning_parent_pointer_json
               FROM filtered_apps
               ORDER BY last_written DESC, app_id LIMIT ?3 OFFSET ?4
             ),
             app_step_counts AS (
               SELECT log_files.app_id, log_files.partition_norm,
                      COALESCE(MAX(log_files.max_sequence_id) + 1, 0) AS num_steps
               FROM log_files
               JOIN selected_apps
                 ON selected_apps.app_id = log_files.app_id
                AND selected_apps.partition_norm = log_files.partition_norm
               WHERE log_files.project_id = ?1
               GROUP BY log_files.app_id, log_files.partition_norm
             )
             SELECT total_count.total,
                    selected_apps.app_id,
                    selected_apps.partition_key,
                    selected_apps.created_at,
                    selected_apps.last_written,
                    selected_apps.parent_pointer_json,
                    selected_apps.spawning_parent_pointer_json,
                    COALESCE(app_step_counts.num_steps, 0) AS num_steps
             FROM total_count
             LEFT JOIN selected_apps ON 1 = 1
             LEFT JOIN app_step_counts
               ON app_step_counts.app_id = selected_apps.app_id
              AND app_step_counts.partition_norm = selected_apps.partition_norm
             ORDER BY selected_apps.last_written DESC, selected_apps.app_id",
        )
        .bind(project_id)
        .bind(partition_norm.as_deref())
        .bind(limit as i64)
        .bind(offset as i64)
        .fetch_all(&self.pool)
        .await?;

        let total = rows
            .first()
            .map(|row| row.try_get::<i64, _>("total"))
            .transpose()?
            .unwrap_or_default() as usize;
        let mut applications = Vec::new();
        for row in rows {
            let Some(app_id) = row.try_get::<Option<String>, _>("app_id")? else {
                continue;
            };
            applications.push(ApplicationSummary {
                app_id,
                partition_key: row.try_get("partition_key")?,
                first_written: row.try_get("created_at")?,
                last_written: row.try_get("last_written")?,
                num_steps: row.try_get::<i64, _>("num_steps")? as u64,
                tags: BTreeMap::new(),
                parent_pointer: pointer_model_from_json(row.try_get("parent_pointer_json")?)?,
                spawning_parent_pointer: pointer_model_from_json(
                    row.try_get("spawning_parent_pointer_json")?,
                )?,
            });
        }

        Ok(ApplicationPage {
            has_another_page: total > offset.saturating_add(limit),
            applications,
            total,
        })
    }

    pub(super) async fn app_object_keys(
        &self,
        project_id: &str,
        app_id: &str,
        partition_norm: &str,
    ) -> Result<(String, String), BackendError> {
        let row = sqlx::query(
            "SELECT graph_key, metadata_key FROM applications
             WHERE project_id = ?1 AND app_id = ?2 AND partition_norm = ?3",
        )
        .bind(project_id)
        .bind(app_id)
        .bind(partition_norm)
        .fetch_optional(&self.pool)
        .await?
        .ok_or_else(|| BackendError::NotFound {
            resource: format!("app:{project_id}/{app_id}"),
        })?;
        let graph_key = row
            .try_get::<Option<String>, _>("graph_key")?
            .ok_or_else(|| BackendError::InvalidRequest {
                message: format!("indexed app {project_id}/{app_id} is missing graph_key"),
            })?;
        let metadata_key = row
            .try_get::<Option<String>, _>("metadata_key")?
            .ok_or_else(|| BackendError::InvalidRequest {
                message: format!("indexed app {project_id}/{app_id} is missing metadata_key"),
            })?;
        Ok((graph_key, metadata_key))
    }

    pub(super) async fn ordered_app_log_keys(
        &self,
        project_id: &str,
        app_id: &str,
        partition_norm: &str,
    ) -> Result<Vec<String>, BackendError> {
        let rows = sqlx::query(
            "SELECT log_key FROM log_files
             WHERE project_id = ?1 AND app_id = ?2 AND partition_norm = ?3
             ORDER BY min_sequence_id, log_key",
        )
        .bind(project_id)
        .bind(app_id)
        .bind(partition_norm)
        .fetch_all(&self.pool)
        .await?;
        rows.into_iter()
            .map(|row| row.try_get("log_key").map_err(BackendError::from))
            .collect()
    }

    pub(super) async fn ordered_app_child_keys(
        &self,
        project_id: &str,
        app_id: &str,
        partition_norm: &str,
    ) -> Result<Vec<String>, BackendError> {
        let rows = sqlx::query(
            "SELECT child_key FROM child_files
             WHERE project_id = ?1 AND app_id = ?2 AND partition_norm = ?3
             ORDER BY child_key",
        )
        .bind(project_id)
        .bind(app_id)
        .bind(partition_norm)
        .fetch_all(&self.pool)
        .await?;
        rows.into_iter()
            .map(|row| row.try_get("child_key").map_err(BackendError::from))
            .collect()
    }

    pub(super) async fn indexing_jobs(
        &self,
        offset: usize,
        limit: usize,
        filter_empty: bool,
    ) -> Result<Vec<IndexingJob>, BackendError> {
        let rows = if filter_empty {
            sqlx::query(
                "SELECT id, start_time, end_time, status, records_processed, metadata_json
                 FROM indexing_jobs WHERE records_processed > 0
                 ORDER BY id DESC LIMIT ?1 OFFSET ?2",
            )
        } else {
            sqlx::query(
                "SELECT id, start_time, end_time, status, records_processed, metadata_json
                 FROM indexing_jobs ORDER BY id DESC LIMIT ?1 OFFSET ?2",
            )
        }
        .bind(limit as i64)
        .bind(offset as i64)
        .fetch_all(&self.pool)
        .await?;
        rows.into_iter().map(indexing_job_from_row).collect()
    }
}

#[derive(Debug)]
pub(super) struct IndexedArtifact {
    file: S3TrackingObjectKey,
    last_modified: String,
    payload: S3ArtifactIndexPayload,
}

struct ArtifactIdentity<'a> {
    project_id: &'a str,
    app_id: &'a str,
    partition_norm: &'a str,
    partition_key: Option<&'a str>,
    object_key: &'a str,
    last_modified: &'a str,
}

struct ArtifactMutation<'a> {
    identity: ArtifactIdentity<'a>,
    application: ApplicationMutation<'a>,
    payload: Option<PayloadMutation<'a>>,
}

enum ApplicationMutation<'a> {
    None,
    TouchOnly,
    Graph {
        graph_key: &'a str,
    },
    Metadata {
        metadata_key: &'a str,
        parent_pointer_json: Option<&'a str>,
        spawning_parent_pointer_json: Option<&'a str>,
    },
}

enum PayloadMutation<'a> {
    Log {
        min_sequence_id: u64,
        max_sequence_id: u64,
        tracker_id: &'a str,
    },
    Child {
        tracker_id: &'a str,
    },
}

impl IndexedArtifact {
    pub(super) fn new(
        file: S3TrackingObjectKey,
        last_modified: String,
        payload: S3ArtifactIndexPayload,
    ) -> Self {
        Self {
            file,
            last_modified,
            payload,
        }
    }

    pub(super) fn key(&self) -> &str {
        self.file.key()
    }

    async fn apply(&self, tx: &mut Transaction<'_, Sqlite>) -> Result<(), BackendError> {
        self.mutation().apply(tx).await
    }

    fn mutation(&self) -> ArtifactMutation<'_> {
        let identity = ArtifactIdentity {
            project_id: self.file.project_id(),
            app_id: self.file.app_id(),
            partition_norm: self.file.partition_segment(),
            partition_key: self.file.partition_key(),
            object_key: self.file.key(),
            last_modified: &self.last_modified,
        };
        let (application, payload) = match &self.payload {
            S3ArtifactIndexPayload::Graph => (
                ApplicationMutation::Graph {
                    graph_key: self.file.key(),
                },
                None,
            ),
            S3ArtifactIndexPayload::Metadata {
                parent_pointer_json,
                spawning_parent_pointer_json,
            } => (
                ApplicationMutation::Metadata {
                    metadata_key: self.file.key(),
                    parent_pointer_json: parent_pointer_json.as_deref(),
                    spawning_parent_pointer_json: spawning_parent_pointer_json.as_deref(),
                },
                None,
            ),
            S3ArtifactIndexPayload::Log {
                min_sequence_id,
                max_sequence_id,
                tracker_id,
            } => (
                ApplicationMutation::TouchOnly,
                Some(PayloadMutation::Log {
                    min_sequence_id: *min_sequence_id,
                    max_sequence_id: *max_sequence_id,
                    tracker_id,
                }),
            ),
            S3ArtifactIndexPayload::Child { tracker_id } => (
                ApplicationMutation::None,
                Some(PayloadMutation::Child { tracker_id }),
            ),
        };
        ArtifactMutation {
            identity,
            application,
            payload,
        }
    }
}

impl ArtifactMutation<'_> {
    async fn apply(self, tx: &mut Transaction<'_, Sqlite>) -> Result<(), BackendError> {
        upsert_project_key(tx, self.identity.project_id, self.identity.last_modified).await?;
        self.application.apply(tx, &self.identity).await?;
        if let Some(payload) = self.payload {
            payload.apply_file_table(tx, &self.identity).await?;
        }
        Ok(())
    }
}

impl ApplicationMutation<'_> {
    async fn apply(
        self,
        tx: &mut Transaction<'_, Sqlite>,
        identity: &ArtifactIdentity<'_>,
    ) -> Result<(), BackendError> {
        match self {
            Self::None => Ok(()),
            mutation => upsert_application(tx, identity, mutation).await,
        }
    }
}

impl PayloadMutation<'_> {
    async fn apply_file_table(
        self,
        tx: &mut Transaction<'_, Sqlite>,
        identity: &ArtifactIdentity<'_>,
    ) -> Result<(), BackendError> {
        let query = sqlx::query(self.sql())
            .bind(identity.project_id)
            .bind(identity.app_id)
            .bind(identity.partition_norm)
            .bind(identity.object_key)
            .bind(identity.last_modified);
        match self {
            Self::Log {
                min_sequence_id,
                max_sequence_id,
                tracker_id,
            } => {
                query
                    .bind(min_sequence_id as i64)
                    .bind(max_sequence_id as i64)
                    .bind(tracker_id)
                    .execute(tx.as_mut())
                    .await?;
            }
            Self::Child { tracker_id } => {
                query.bind(tracker_id).execute(tx.as_mut()).await?;
            }
        }
        Ok(())
    }

    fn sql(&self) -> &'static str {
        match self {
            Self::Log { .. } => {
                "INSERT INTO log_files
                 (project_id, app_id, partition_norm, log_key, created_at, min_sequence_id,
                  max_sequence_id, tracker_id)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)
                 ON CONFLICT(log_key) DO UPDATE SET
                   created_at = excluded.created_at,
                   min_sequence_id = excluded.min_sequence_id,
                   max_sequence_id = excluded.max_sequence_id,
                   tracker_id = excluded.tracker_id"
            }
            Self::Child { .. } => {
                "INSERT INTO child_files
                 (project_id, app_id, partition_norm, child_key, created_at, tracker_id)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6)
                 ON CONFLICT(child_key) DO UPDATE SET
                   created_at = excluded.created_at,
                   tracker_id = excluded.tracker_id"
            }
        }
    }
}

async fn migrate(pool: &SqlitePool) -> Result<(), BackendError> {
    for statement in [
        "CREATE TABLE IF NOT EXISTS projects (
            project_id TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            last_written TEXT NOT NULL
        )",
        "CREATE TABLE IF NOT EXISTS applications (
            project_id TEXT NOT NULL,
            app_id TEXT NOT NULL,
            partition_norm TEXT NOT NULL,
            partition_key TEXT,
            created_at TEXT NOT NULL,
            last_written TEXT NOT NULL,
            graph_key TEXT,
            metadata_key TEXT,
            parent_pointer_json TEXT,
            spawning_parent_pointer_json TEXT,
            PRIMARY KEY (project_id, app_id, partition_norm)
        )",
        "CREATE TABLE IF NOT EXISTS log_files (
            project_id TEXT NOT NULL,
            app_id TEXT NOT NULL,
            partition_norm TEXT NOT NULL,
            log_key TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            min_sequence_id INTEGER NOT NULL,
            max_sequence_id INTEGER NOT NULL,
            tracker_id TEXT NOT NULL
        )",
        "CREATE TABLE IF NOT EXISTS child_files (
            project_id TEXT NOT NULL,
            app_id TEXT NOT NULL,
            partition_norm TEXT NOT NULL,
            child_key TEXT PRIMARY KEY,
            created_at TEXT NOT NULL,
            tracker_id TEXT NOT NULL
        )",
        "CREATE TABLE IF NOT EXISTS index_status (
            project_id TEXT PRIMARY KEY,
            high_watermark_key TEXT NOT NULL
        )",
        "CREATE TABLE IF NOT EXISTS indexing_jobs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_time TEXT NOT NULL,
            end_time TEXT,
            status TEXT NOT NULL,
            records_processed INTEGER NOT NULL,
            metadata_json TEXT NOT NULL
        )",
        "CREATE INDEX IF NOT EXISTS applications_project_partition_app_idx
            ON applications(project_id, partition_norm, last_written DESC, app_id)",
        "CREATE INDEX IF NOT EXISTS log_files_app_summary_idx
            ON log_files(project_id, app_id, partition_norm, max_sequence_id DESC, log_key DESC)",
        "CREATE INDEX IF NOT EXISTS log_files_app_order_idx
            ON log_files(project_id, app_id, partition_norm, min_sequence_id, log_key)",
        "CREATE INDEX IF NOT EXISTS child_files_app_order_idx
            ON child_files(project_id, app_id, partition_norm, child_key)",
    ] {
        sqlx::query(statement).execute(pool).await?;
    }
    Ok(())
}

async fn apply_artifact_update(
    tx: &mut Transaction<'_, Sqlite>,
    update: &IndexedArtifact,
) -> Result<(), BackendError> {
    update.apply(tx).await
}

async fn upsert_application(
    tx: &mut Transaction<'_, Sqlite>,
    identity: &ArtifactIdentity<'_>,
    mutation: ApplicationMutation<'_>,
) -> Result<(), BackendError> {
    let (graph_key, metadata_key, parent_pointer_json, spawning_parent_pointer_json) =
        match mutation {
            ApplicationMutation::TouchOnly => (None, None, None, None),
            ApplicationMutation::Graph { graph_key } => (Some(graph_key), None, None, None),
            ApplicationMutation::Metadata {
                metadata_key,
                parent_pointer_json,
                spawning_parent_pointer_json,
            } => (
                None,
                Some(metadata_key),
                parent_pointer_json,
                spawning_parent_pointer_json,
            ),
            ApplicationMutation::None => return Ok(()),
        };
    sqlx::query(
        "INSERT INTO applications
         (project_id, app_id, partition_norm, partition_key, graph_key, metadata_key,
          created_at, last_written, parent_pointer_json, spawning_parent_pointer_json)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?7, ?8, ?9)
         ON CONFLICT(project_id, app_id, partition_norm) DO UPDATE SET
           partition_key = COALESCE(excluded.partition_key, applications.partition_key),
           created_at = MIN(applications.created_at, excluded.created_at),
           last_written = MAX(applications.last_written, excluded.last_written),
           graph_key = COALESCE(excluded.graph_key, applications.graph_key),
           metadata_key = COALESCE(excluded.metadata_key, applications.metadata_key),
           parent_pointer_json = COALESCE(excluded.parent_pointer_json, applications.parent_pointer_json),
           spawning_parent_pointer_json =
             COALESCE(excluded.spawning_parent_pointer_json, applications.spawning_parent_pointer_json)",
    )
    .bind(identity.project_id)
    .bind(identity.app_id)
    .bind(identity.partition_norm)
    .bind(identity.partition_key)
    .bind(graph_key)
    .bind(metadata_key)
    .bind(identity.last_modified)
    .bind(parent_pointer_json)
    .bind(spawning_parent_pointer_json)
    .execute(tx.as_mut())
    .await?;
    Ok(())
}

async fn upsert_project_key(
    tx: &mut Transaction<'_, Sqlite>,
    project_id: &str,
    last_modified: &str,
) -> Result<(), BackendError> {
    sqlx::query(
        "INSERT INTO projects (project_id, created_at, last_written)
         VALUES (?1, ?2, ?2)
         ON CONFLICT(project_id) DO UPDATE SET
           created_at = MIN(projects.created_at, excluded.created_at),
           last_written = MAX(projects.last_written, excluded.last_written)",
    )
    .bind(project_id)
    .bind(last_modified)
    .execute(tx.as_mut())
    .await?;
    Ok(())
}

async fn set_high_watermark(
    tx: &mut Transaction<'_, Sqlite>,
    project: &str,
    high_watermark: &str,
) -> Result<(), BackendError> {
    sqlx::query(
        "INSERT INTO index_status (project_id, high_watermark_key)
         VALUES (?1, ?2)
         ON CONFLICT(project_id) DO UPDATE SET high_watermark_key = excluded.high_watermark_key",
    )
    .bind(project)
    .bind(high_watermark)
    .execute(tx.as_mut())
    .await?;
    Ok(())
}

fn indexing_job_from_row(row: SqliteRow) -> Result<IndexingJob, BackendError> {
    let metadata_json = row.try_get::<String, _>("metadata_json")?;
    let metadata_value = serde_json::from_str::<Value>(&metadata_json)?;
    let Value::Object(metadata) = metadata_value else {
        return Err(BackendError::InvalidRequest {
            message: "indexing job metadata_json must be a JSON object".to_string(),
        });
    };
    Ok(IndexingJob {
        id: row.try_get::<i64, _>("id")? as u64,
        start_time: row.try_get("start_time")?,
        end_time: row.try_get("end_time")?,
        status: row.try_get("status")?,
        records_processed: row.try_get::<i64, _>("records_processed")? as u64,
        metadata,
    })
}

fn now_string(operation: &'static str) -> Result<String, BackendError> {
    rurr_persistence::wire::sortable_rfc3339_utc_string(std::time::SystemTime::now()).map_err(
        |error| BackendError::Timestamp {
            operation,
            message: error.to_string(),
        },
    )
}

fn pointer_model_from_json(raw: Option<String>) -> Result<Option<PointerModel>, BackendError> {
    raw.map(|raw| {
        serde_json::from_str::<ParentPointer>(&raw)
            .map(|pointer| PointerModel::from_parent_pointer(&pointer))
            .map_err(BackendError::from)
    })
    .transpose()
}

#[cfg(test)]
mod tests {
    use super::*;
    use rurr_core::tracking::S3Prefix;

    #[tokio::test]
    async fn project_update_rolls_back_high_watermark_on_failure() {
        let dir = tempfile::tempdir().expect("tempdir should create");
        let store = S3IndexStore::open(&dir.path().join("index.sqlite3"))
            .await
            .expect("store should open");
        sqlx::query("DROP TABLE log_files")
            .execute(store.pool())
            .await
            .expect("table drop should succeed");

        let update = log_update(
            "data/demo/2026/05/07/14/00:01/__none__/app-1/first__log.jsonl",
            1,
            "first",
        );
        let error = store
            .apply_project_updates("demo", &[update], "data/demo/high")
            .await
            .expect_err("missing log table should fail the transaction");
        assert!(
            error.to_string().contains("log_files"),
            "unexpected error: {error}"
        );

        let project_count: i64 =
            sqlx::query_scalar("SELECT COUNT(*) FROM projects WHERE project_id = 'demo'")
                .fetch_one(store.pool())
                .await
                .expect("project count should query");
        assert_eq!(project_count, 0);
        assert_eq!(
            store
                .high_watermark("demo")
                .await
                .expect("high watermark should query"),
            None
        );
    }

    #[tokio::test]
    async fn high_watermark_propagates_sqlite_decode_errors() {
        let dir = tempfile::tempdir().expect("tempdir should create");
        let store = S3IndexStore::open(&dir.path().join("index.sqlite3"))
            .await
            .expect("store should open");
        sqlx::query(
            "INSERT INTO index_status (project_id, high_watermark_key) VALUES ('demo', x'80')",
        )
        .execute(store.pool())
        .await
        .expect("corrupt watermark row should insert");

        let error = store
            .high_watermark("demo")
            .await
            .expect_err("decode failure should propagate");
        match error {
            BackendError::Sqlx(sqlx::Error::ColumnDecode { index, .. }) => {
                assert!(
                    index.contains("high_watermark_key"),
                    "decode error should name high_watermark_key, got {index}"
                )
            }
            other => panic!("expected sqlx column decode error, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn list_apps_uses_latest_summary_and_preserves_empty_page_total() {
        let dir = tempfile::tempdir().expect("tempdir should create");
        let store = S3IndexStore::open(&dir.path().join("index.sqlite3"))
            .await
            .expect("store should open");
        let updates = [
            log_update(
                "data/demo/2026/05/07/14/00:01/__none__/app-1/first__log.jsonl",
                1,
                "first",
            ),
            log_update(
                "data/demo/2026/05/07/14/00:02/__none__/app-1/second__log.jsonl",
                2,
                "second",
            ),
        ];
        store
            .apply_project_updates("demo", &updates, updates[1].key())
            .await
            .expect("updates should apply");

        let page = store
            .list_apps("demo", None, 10, 0)
            .await
            .expect("apps should list");
        assert_eq!(page.total, 1);
        assert_eq!(page.applications.len(), 1);
        assert_eq!(page.applications[0].app_id, "app-1");
        assert_eq!(page.applications[0].num_steps, 3);
        assert!(page.applications[0].first_written <= page.applications[0].last_written);

        let empty_page = store
            .list_apps("demo", None, 10, 10)
            .await
            .expect("empty page should list");
        assert_eq!(empty_page.total, 1);
        assert!(empty_page.applications.is_empty());
    }

    #[tokio::test]
    async fn ordered_app_log_keys_orders_by_sequence_then_key() {
        let dir = tempfile::tempdir().expect("tempdir should create");
        let store = S3IndexStore::open(&dir.path().join("index.sqlite3"))
            .await
            .expect("store should open");
        let updates = [
            log_update(
                "data/demo/2026/05/07/14/00:03/__none__/app-1/c__log.jsonl",
                2,
                "c",
            ),
            log_update(
                "data/demo/2026/05/07/14/00:01/__none__/app-1/b__log.jsonl",
                0,
                "b",
            ),
            log_update(
                "data/demo/2026/05/07/14/00:02/__none__/app-1/a__log.jsonl",
                0,
                "a",
            ),
        ];
        store
            .apply_project_updates("demo", &updates, updates[0].key())
            .await
            .expect("updates should apply");

        let keys = store
            .ordered_app_log_keys("demo", "app-1", "__none__")
            .await
            .expect("log keys should list");

        assert_eq!(
            keys,
            vec![
                "data/demo/2026/05/07/14/00:01/__none__/app-1/b__log.jsonl",
                "data/demo/2026/05/07/14/00:02/__none__/app-1/a__log.jsonl",
                "data/demo/2026/05/07/14/00:03/__none__/app-1/c__log.jsonl",
            ]
        );
    }

    #[tokio::test]
    async fn child_keys_order_by_provider_key_and_do_not_create_apps() {
        let dir = tempfile::tempdir().expect("tempdir should create");
        let store = S3IndexStore::open(&dir.path().join("index.sqlite3"))
            .await
            .expect("store should open");
        let updates = [
            child_update(
                "data/demo/2026/05/07/14/00:03/pk/parent/c__children.jsonl",
                "c",
            ),
            child_update(
                "data/demo/2026/05/07/14/00:01/pk/parent/a__children.jsonl",
                "a",
            ),
            child_update(
                "data/demo/2026/05/07/14/00:02/pk/parent/b__children.jsonl",
                "b",
            ),
        ];
        store
            .apply_project_updates("demo", &updates, updates[0].key())
            .await
            .expect("updates should apply");

        let page = store
            .list_apps("demo", Some("pk"), 10, 0)
            .await
            .expect("apps should list");
        assert_eq!(page.total, 0);
        assert!(page.applications.is_empty());

        let child_keys = store
            .ordered_app_child_keys("demo", "parent", "pk")
            .await
            .expect("child keys should list");
        assert_eq!(
            child_keys,
            vec![
                "data/demo/2026/05/07/14/00:01/pk/parent/a__children.jsonl",
                "data/demo/2026/05/07/14/00:02/pk/parent/b__children.jsonl",
                "data/demo/2026/05/07/14/00:03/pk/parent/c__children.jsonl",
            ]
        );
    }

    fn log_update(key: &str, sequence_id: u64, _action: &str) -> IndexedArtifact {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        IndexedArtifact::new(
            S3TrackingObjectKey::parse(&prefix, key).expect("log key should parse"),
            format!("2026-03-20T00:00:0{sequence_id}Z"),
            S3ArtifactIndexPayload::Log {
                min_sequence_id: sequence_id,
                max_sequence_id: sequence_id,
                tracker_id: "tracker".to_string(),
            },
        )
    }

    fn child_update(key: &str, tracker_id: &str) -> IndexedArtifact {
        let prefix = S3Prefix::new("data").expect("prefix should parse");
        IndexedArtifact::new(
            S3TrackingObjectKey::parse(&prefix, key).expect("child key should parse"),
            format!("2026-03-20T00:00:0{tracker_id}Z"),
            S3ArtifactIndexPayload::Child {
                tracker_id: tracker_id.to_string(),
            },
        )
    }
}
