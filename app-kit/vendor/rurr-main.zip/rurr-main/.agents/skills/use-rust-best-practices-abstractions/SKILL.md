---
name: use-rust-best-practices-abstractions
description: "Apply this when refactoring Rust code to remove duplication, designing or extending structs and methods, choosing between concrete code, generics, traits, trait objects, or enums, handling errors and panics, introducing or simplifying lifetimes, or implementing enum-dispatcher style backends. Use it when Codex must decide whether to keep code concrete, extract a reusable abstraction, or redesign an API to be more idiomatic and maintainable."
---

# Rust abstractions, lifetimes, and errors best practices

Use this skill when a Rust task changes APIs, data structures, traits, generics, lifetimes, error types, or duplicated domain logic.

## When to use

Use it when the task:

- removes duplicated Rust logic
- introduces or redesigns a struct, method, or trait
- chooses between concrete types, generics, trait objects, or enums
- introduces or simplifies lifetimes
- defines or refactors error types
- asks about panic policy
- needs an enum-dispatch / config-driven backend pattern
- touches `unsafe` boundaries or safe wrappers

## Do not use this skill alone when

- the task is mostly about workspace/package/module structure → also load `$use-rust-best-practices-architecture`
- the task is mostly about async tasks/shutdown/concurrency shape → also load `$use-rust-best-practices-async`
- the task is mostly about HTTP/gRPC/database clients → also load `$use-rust-best-practices-networking`

## Workflow

1. Keep code concrete until duplication or extension pressure is real.
2. Refactor repeated data + behavior into structs with methods.
3. Introduce traits at the usage boundary when multiple implementations or test doubles are genuinely useful.
4. Choose enums for closed sets, generics for static polymorphism, and trait objects for open runtime-extensible sets.
5. In Rurr, do not use macros as the deduplication or abstraction mechanism for ordinary code;
   use the structures above instead.
6. Use explicit lifetimes only when the borrow relationship cannot be elided.
7. Return `Result` for recoverable failures and reserve panic for bugs or impossible invariants.
8. Keep `unsafe` small and wrap it behind safe APIs when it is truly necessary.

## Default rules

- Prefer small, coherent structs over piles of parallel free-function arguments.
- Prefer owned data in long-lived structs and spawned-task boundaries.
- Prefer borrowed inputs (`&str`, `&[T]`, `&T`) for read-only operations.
- Prefer typed library errors; add `anyhow` context at application boundaries.
- Avoid creating traits or generics with only speculative benefit.
- Avoid helper macros and macro helper crates for cleanup refactors; the Rurr standard is
  struct/method/enum/trait extraction, not macro indirection.
- Avoid blanket `unsafe_code = "forbid"` guidance in generic reusable skills; some crates legitimately need narrow `unsafe`.

## Load these references directly when needed

- `references/abstractions.md` — refactor triggers, structs/methods, traits/generics/enums/lifetimes, enum dispatcher, errors, panics, and unsafe guidance.

## Load these templates when useful

- `assets/templates/enum_dispatch.rs`
- `assets/templates/typed_error.rs`

## Companion skills

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
