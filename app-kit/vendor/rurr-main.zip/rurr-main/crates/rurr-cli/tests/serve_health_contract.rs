use rurr_core::tracking::LocalTrackingClient;
use rurr_core::{
    ApplicationBuilder, FunctionActionBuilder, State, Tracker, TrackerSpec, Transition,
};
use rurr_testkit::application_fixture::map_from_pairs;
use rurr_testkit::command_fixture::{rurr_binary_path, rurr_command, rurr_command_in};
use std::io::{BufRead, BufReader, Read, Write};
use std::net::TcpStream;
use std::path::Path;
use std::process::{Child, Command, Stdio};
use std::sync::mpsc;
use std::sync::Arc;
use std::thread;
use std::time::{Duration, Instant};

const STARTUP_PREFIX: &str = "rurr serve listening at ";
const STARTUP_STDERR_CAPTURE_TIMEOUT: Duration = Duration::from_millis(500);

fn build_tracking_fixture(root: &Path, project_id: &str, app_id: &str, partition_key: &str) {
    let tracker = Arc::new(
        LocalTrackingClient::new(project_id, root).expect("tracking client should initialize"),
    );
    let tracker_trait: Arc<dyn Tracker> = tracker.clone();
    let action = FunctionActionBuilder::new()
        .writes(["count"])
        .with_source_code("fn noop(state, _ctx) -> count { state[\"count\"] + 1 }")
        .build_sync(|state, _ctx| {
            let next = state
                .get("count")
                .and_then(serde_json::Value::as_i64)
                .unwrap_or(0)
                + 1;
            map_from_pairs([("count", serde_json::json!(next))])
        })
        .expect("noop tracking action should build");
    let mut app = ApplicationBuilder::new()
        .with_state(State::default())
        .expect("state should configure")
        .with_actions(vec![("noop", action)])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("noop")
        .expect("entrypoint should configure")
        .with_identifiers(app_id, Some(partition_key.to_string()), None)
        .expect("identifiers should configure")
        .with_tracker(TrackerSpec::provided(tracker_trait))
        .expect("tracker should configure")
        .build()
        .expect("application should build");
    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("registration should succeed");
    app.step(None).expect("step should succeed");
}

struct ChildGuard {
    child: Child,
}

impl ChildGuard {
    fn new(child: Child) -> Self {
        Self { child }
    }

    fn terminate(&mut self) {
        if let Ok(None) = self.child.try_wait() {
            let _ = self.child.kill();
        }
        let _ = self.child.wait();
    }
}

impl Drop for ChildGuard {
    fn drop(&mut self) {
        self.terminate();
    }
}

fn spawn_line_capture(reader: impl Read + Send + 'static) -> mpsc::Receiver<String> {
    let (tx, rx) = mpsc::channel::<String>();
    thread::spawn(move || {
        let reader = BufReader::new(reader);
        for line in reader.lines() {
            match line {
                Ok(line) => {
                    let _ = tx.send(line);
                }
                Err(_) => break,
            }
        }
    });
    rx
}

fn collect_startup_failure_stderr(guard: &mut ChildGuard) -> String {
    let stderr_rx = guard.child.stderr.take().map(spawn_line_capture);
    // Ensure the target process is terminated before draining diagnostics.
    guard.terminate();
    stderr_rx
        .map(|rx| collect_captured_lines(&rx, STARTUP_STDERR_CAPTURE_TIMEOUT))
        .map(|lines| lines.join("\n"))
        .unwrap_or_default()
}

fn collect_captured_lines(rx: &mpsc::Receiver<String>, timeout: Duration) -> Vec<String> {
    let start = Instant::now();
    let mut captured = Vec::new();
    loop {
        if start.elapsed() >= timeout {
            break;
        }
        match rx.recv_timeout(Duration::from_millis(25)) {
            Ok(line) => captured.push(line),
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(mpsc::RecvTimeoutError::Disconnected) => break,
        }
    }
    captured
}

fn wait_for_captured_line(
    rx: &mpsc::Receiver<String>,
    expected: &str,
    timeout: Duration,
) -> Result<Vec<String>, String> {
    let start = Instant::now();
    let mut captured = Vec::new();
    while start.elapsed() < timeout {
        match rx.recv_timeout(Duration::from_millis(25)) {
            Ok(line) => {
                let matched = line.contains(expected);
                captured.push(line);
                if matched {
                    return Ok(captured);
                }
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                return Err(format!(
                    "stderr disconnected before line containing {expected:?} was observed"
                ));
            }
        }
    }

    Err(format!(
        "timed out waiting for stderr line containing {expected:?}"
    ))
}

fn spawn_startup_failure_fixture() -> (Child, mpsc::Receiver<String>) {
    let mut command = if cfg!(windows) {
        let mut command = Command::new("powershell");
        command
            .arg("-NoProfile")
            .arg("-NonInteractive")
            .arg("-Command")
            .arg(
                "$ErrorActionPreference = 'Stop'; \
             [Console]::Out.WriteLine('fixture-ready'); \
             [Console]::Error.WriteLine('startup-failure'); \
             Start-Sleep -Seconds 30",
            );
        command
    } else {
        let mut command = Command::new("sh");
        command
            .arg("-c")
            .arg("printf 'fixture-ready\\n'; printf 'startup-failure\\n' >&2; sleep 30");
        command
    };

    command
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map(|mut child| {
            let stderr = child.stderr.take().expect("fixture stderr should be piped");
            (child, spawn_line_capture(stderr))
        })
        .expect("fixture process should start")
}

fn wait_for_line(
    stdout: impl Read + Send + 'static,
    prefix: &str,
    timeout: Duration,
) -> Result<String, String> {
    let (tx, rx) = mpsc::channel::<String>();
    thread::spawn(move || {
        let reader = BufReader::new(stdout);
        for line in reader.lines() {
            match line {
                Ok(line) => {
                    let _ = tx.send(line);
                }
                Err(_) => break,
            }
        }
    });

    let start = Instant::now();
    while start.elapsed() < timeout {
        match rx.recv_timeout(Duration::from_millis(100)) {
            Ok(line) => {
                if let Some(value) = line.strip_prefix(prefix) {
                    return Ok(value.trim().to_string());
                }
            }
            Err(mpsc::RecvTimeoutError::Timeout) => {}
            Err(mpsc::RecvTimeoutError::Disconnected) => {
                return Err(format!(
                    "stdout disconnected before line with prefix {prefix:?} was observed"
                ));
            }
        }
    }

    Err(format!("timed out waiting for line with prefix {prefix:?}"))
}

fn wait_for_startup_url(
    stdout: impl Read + Send + 'static,
    timeout: Duration,
) -> Result<String, String> {
    wait_for_line(stdout, STARTUP_PREFIX, timeout)
}

fn wait_for_fixture_ready(
    stdout: impl Read + Send + 'static,
    timeout: Duration,
) -> Result<(), String> {
    wait_for_line(stdout, "fixture-ready", timeout).map(|_| ())
}

fn parse_host_port(url: &str) -> Result<(String, u16), String> {
    let without_scheme = url
        .strip_prefix("http://")
        .ok_or_else(|| format!("unsupported startup URL scheme: {url}"))?;
    let mut parts = without_scheme.split(':');
    let host = parts
        .next()
        .ok_or_else(|| format!("missing host in startup URL: {url}"))?;
    let port_str = parts
        .next()
        .ok_or_else(|| format!("missing port in startup URL: {url}"))?;
    if parts.next().is_some() {
        return Err(format!("unexpected URL format: {url}"));
    }
    let port = port_str
        .parse::<u16>()
        .map_err(|error| format!("invalid port in startup URL ({url}): {error}"))?;
    Ok((host.to_string(), port))
}

fn request_ready(host: &str, port: u16) -> Result<String, String> {
    request_path(host, port, "/ready")
}

fn request_path(host: &str, port: u16, path: &str) -> Result<String, String> {
    let mut stream = TcpStream::connect((host, port))
        .map_err(|error| format!("tcp connect to {host}:{port} failed: {error}"))?;
    stream
        .set_read_timeout(Some(Duration::from_secs(1)))
        .map_err(|error| format!("set_read_timeout failed: {error}"))?;
    stream
        .set_write_timeout(Some(Duration::from_secs(1)))
        .map_err(|error| format!("set_write_timeout failed: {error}"))?;

    let request =
        format!("GET {path} HTTP/1.1\r\nHost: {host}:{port}\r\nConnection: close\r\n\r\n");
    stream
        .write_all(request.as_bytes())
        .map_err(|error| format!("write request failed: {error}"))?;

    let mut response = String::new();
    stream
        .read_to_string(&mut response)
        .map_err(|error| format!("read response failed: {error}"))?;
    Ok(response)
}

#[test]
fn serve_command_reports_bound_url_and_serves_ready() {
    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let work_dir = tempfile::tempdir().expect("work tempdir should be created");

    let child = rurr_command_in(work_dir.path())
        .arg("serve")
        .arg("--host")
        .arg("127.0.0.1")
        .arg("--port")
        .arg("0")
        .arg("--no-open")
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("serve process should start");
    let mut guard = ChildGuard::new(child);

    let stdout = guard
        .child
        .stdout
        .take()
        .expect("serve stdout should be piped");
    let startup_url = match wait_for_startup_url(stdout, Duration::from_secs(10)) {
        Ok(url) => url,
        Err(wait_error) => {
            let stderr = collect_startup_failure_stderr(&mut guard);
            panic!("serve should emit startup URL line: {wait_error}; stderr: {stderr}");
        }
    };

    let (host, port) = parse_host_port(&startup_url).expect("startup URL should parse");
    let response = request_ready(&host, port).expect("ready endpoint should become healthy");
    assert!(
        response.contains("\"ready\":true"),
        "ready payload should include Burr readiness"
    );
    let root_response =
        request_path(&host, port, "/").expect("root request should succeed in embedded mode");
    assert!(
        root_response.starts_with("HTTP/1.1 200") || root_response.starts_with("HTTP/1.0 200"),
        "root should be healthy with default embedded UI: {root_response}"
    );

    guard.terminate();
}

#[test]
fn serve_command_embedded_ui_is_real_tracking_surface() {
    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let work_dir = tempfile::tempdir().expect("work tempdir should be created");
    build_tracking_fixture(storage_dir.path(), "embedded-ui-project", "app-real", "pk");

    let child = rurr_command_in(work_dir.path())
        .arg("serve")
        .arg("--host")
        .arg("127.0.0.1")
        .arg("--port")
        .arg("0")
        .arg("--no-open")
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("serve process should start");
    let mut guard = ChildGuard::new(child);

    let stdout = guard
        .child
        .stdout
        .take()
        .expect("serve stdout should be piped");
    let startup_url = match wait_for_startup_url(stdout, Duration::from_secs(10)) {
        Ok(url) => url,
        Err(wait_error) => {
            let stderr = collect_startup_failure_stderr(&mut guard);
            panic!("serve should emit startup URL line: {wait_error}; stderr: {stderr}");
        }
    };

    let (host, port) = parse_host_port(&startup_url).expect("startup URL should parse");
    let root_response = request_path(&host, port, "/").expect("root request should succeed");
    assert!(
        root_response.starts_with("HTTP/1.1 200") || root_response.starts_with("HTTP/1.0 200"),
        "embedded UI root should return 200: {root_response}"
    );
    assert!(root_response.contains("Rurr Tracking"));
    assert!(root_response.contains("data-view=\"projects\""));
    assert!(root_response.contains("data-view=\"applications\""));
    assert!(root_response.contains("data-view=\"detail\""));
    assert!(
        !root_response.to_ascii_lowercase().contains("placeholder"),
        "embedded root must not expose placeholder copy: {root_response}"
    );

    let asset_response =
        request_path(&host, port, "/assets/app.js").expect("embedded asset should be served");
    assert!(
        asset_response.starts_with("HTTP/1.1 200") || asset_response.starts_with("HTTP/1.0 200"),
        "embedded app.js should return 200: {asset_response}"
    );
    assert!(asset_response.contains("/api/v0/projects"));
    assert!(asset_response.contains("/api/v0/version"));
    assert!(asset_response.contains("/api/v0/metadata/app_spec"));
    assert!(asset_response.contains("loadAppDetail"));
    assert!(!asset_response.contains("Rurr UI bundle booted"));

    let projects_response =
        request_path(&host, port, "/api/v0/projects").expect("projects request should succeed");
    assert!(
        projects_response.contains("embedded-ui-project"),
        "served UI should be backed by the real tracking API: {projects_response}"
    );

    guard.terminate();
}

#[test]
fn serve_command_fails_fast_when_explicit_ui_dir_is_invalid() {
    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let home_dir = tempfile::tempdir().expect("home tempdir should be created");
    let invalid_ui_dir = storage_dir.path().join("missing-ui-dir");
    let mut child = rurr_command()
        .arg("serve")
        .arg("--host")
        .arg("127.0.0.1")
        .arg("--port")
        .arg("0")
        .arg("--no-open")
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--ui-dir")
        .arg(&invalid_ui_dir)
        .env("HOME", home_dir.path())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("serve process should start");

    let start = Instant::now();
    let status = child.wait().expect("wait should succeed");
    assert!(
        start.elapsed() < Duration::from_secs(5),
        "serve should fail fast when --ui-dir is invalid"
    );
    assert!(!status.success(), "serve should fail for invalid --ui-dir");

    let mut stderr = String::new();
    child
        .stderr
        .take()
        .expect("stderr should be piped")
        .read_to_string(&mut stderr)
        .expect("stderr should be readable");
    assert!(
        stderr.contains("index.html") || stderr.contains("ui_dir"),
        "error output should explain missing UI directory/index.html: {stderr}"
    );
}

#[test]
fn serve_command_uses_userprofile_backed_default_storage_dir_when_home_is_unset() {
    let userprofile_dir = tempfile::tempdir().expect("userprofile tempdir should be created");
    let work_dir = tempfile::tempdir().expect("work tempdir should be created");
    build_tracking_fixture(
        &userprofile_dir.path().join(".burr"),
        "windows-home-project",
        "app1",
        "pk",
    );

    let child = rurr_command_in(work_dir.path())
        .arg("serve")
        .arg("--host")
        .arg("127.0.0.1")
        .arg("--port")
        .arg("0")
        .arg("--no-open")
        .env_remove("HOME")
        .env("USERPROFILE", userprofile_dir.path())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("serve process should start");
    let mut guard = ChildGuard::new(child);

    let stdout = guard
        .child
        .stdout
        .take()
        .expect("serve stdout should be piped");
    let startup_url = match wait_for_startup_url(stdout, Duration::from_secs(10)) {
        Ok(url) => url,
        Err(wait_error) => {
            let stderr = collect_startup_failure_stderr(&mut guard);
            panic!("serve should emit startup URL line: {wait_error}; stderr: {stderr}");
        }
    };

    let (host, port) = parse_host_port(&startup_url).expect("startup URL should parse");
    request_ready(&host, port).expect("ready endpoint should become healthy");
    let response = request_path(&host, port, "/api/v0/projects")
        .expect("projects request should succeed against default storage dir");
    assert!(
        response.contains("windows-home-project"),
        "default storage dir should come from USERPROFILE when HOME is unset: {response}"
    );

    guard.terminate();
}

#[test]
fn serve_command_fails_when_default_storage_dir_cannot_resolve_home() {
    let work_dir = tempfile::tempdir().expect("work tempdir should be created");
    let mut child = rurr_command_in(work_dir.path())
        .arg("serve")
        .arg("--host")
        .arg("127.0.0.1")
        .arg("--port")
        .arg("0")
        .arg("--no-open")
        .env_remove("HOME")
        .env_remove("USERPROFILE")
        .env_remove("HOMEDRIVE")
        .env_remove("HOMEPATH")
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("serve process should start");

    let start = Instant::now();
    let status = child.wait().expect("wait should succeed");
    assert!(
        start.elapsed() < Duration::from_secs(5),
        "serve should fail fast when no home dir or storage dir is available"
    );
    assert!(
        !status.success(),
        "serve should fail when the default storage dir cannot resolve"
    );

    let mut stderr = String::new();
    child
        .stderr
        .take()
        .expect("stderr should be piped")
        .read_to_string(&mut stderr)
        .expect("stderr should be readable");
    assert!(
        stderr.contains("MissingHomeDirectory")
            || stderr.contains("resolved home directory")
            || stderr.contains("explicit --storage-dir"),
        "error output should explain the missing home-backed storage root: {stderr}"
    );
}

#[cfg(unix)]
#[test]
fn serve_command_fails_when_relative_storage_dir_cannot_pin_deleted_cwd() {
    let cwd_parent = tempfile::tempdir().expect("cwd parent tempdir should be created");
    let deleted_cwd = cwd_parent.path().join("deleted-cwd");
    std::fs::create_dir(&deleted_cwd).expect("deleted cwd should be created");
    let home_dir = tempfile::tempdir().expect("home tempdir should be created");
    let binary = rurr_binary_path();

    let mut child = Command::new("sh")
        .arg("-c")
        .arg("cd \"$1\" && rmdir \"$1\" && exec \"$2\" serve --host 127.0.0.1 --port 0 --no-open --storage-dir relative-storage")
        .arg("sh")
        .arg(&deleted_cwd)
        .arg(&binary)
        .env("HOME", home_dir.path())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("serve process should start");

    let start = Instant::now();
    let status = child.wait().expect("wait should succeed");
    assert!(
        start.elapsed() < Duration::from_secs(5),
        "serve should fail fast when a relative storage dir cannot be pinned"
    );
    assert!(
        !status.success(),
        "serve should fail when the current directory is unavailable for a relative storage root"
    );

    let mut stderr = String::new();
    child
        .stderr
        .take()
        .expect("stderr should be piped")
        .read_to_string(&mut stderr)
        .expect("stderr should be readable");
    assert!(
        stderr.contains("RelativePathRequiresCurrentDir")
            || stderr.contains("relative tracking storage root")
            || stderr.contains("current working directory"),
        "error output should explain the unpinned relative storage root: {stderr}"
    );
}

#[test]
fn startup_failure_diagnostics_are_bounded_for_running_child() {
    let (child, stderr_rx) = spawn_startup_failure_fixture();
    let mut guard = ChildGuard::new(child);

    let stdout = guard
        .child
        .stdout
        .take()
        .expect("fixture stdout should be piped");
    wait_for_fixture_ready(stdout, Duration::from_secs(2))
        .expect("fixture process should signal stderr readiness before termination");
    let start = Instant::now();
    let mut stderr_lines = wait_for_captured_line(
        &stderr_rx,
        "startup-failure",
        STARTUP_STDERR_CAPTURE_TIMEOUT,
    )
    .expect("fixture stderr should include the startup failure line");
    guard.terminate();
    stderr_lines.extend(collect_captured_lines(
        &stderr_rx,
        Duration::from_millis(50),
    ));
    let elapsed = start.elapsed();
    let stderr = stderr_lines.join("\n");

    assert!(
        elapsed < Duration::from_secs(1),
        "startup diagnostics should remain bounded, took {elapsed:?}"
    );
    assert!(
        stderr.contains("startup-failure"),
        "expected stderr output to be captured, got: {stderr}"
    );
    assert!(
        matches!(guard.child.try_wait(), Ok(Some(_))),
        "child should be terminated before stderr drain completes"
    );
}
