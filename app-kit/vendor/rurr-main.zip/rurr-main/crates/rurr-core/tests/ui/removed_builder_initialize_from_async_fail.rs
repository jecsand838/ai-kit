use indexmap::IndexMap;
use rurr_core::application::ApplicationBuilder;

fn main() {
    let _ = ApplicationBuilder::new().initialize_from_async(
        unimplemented!(),
        true,
        IndexMap::new(),
        "noop",
        None,
    );
}
