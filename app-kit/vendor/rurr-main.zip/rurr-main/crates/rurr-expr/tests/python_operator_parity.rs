use rurr_expr::{evaluate_bool, parse, ExprError, StateView};
use serde_json::{json, Value};
use std::collections::HashMap;

struct MapState {
    values: HashMap<String, Value>,
}

impl MapState {
    fn from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> Self {
        Self {
            values: pairs
                .into_iter()
                .map(|(key, value)| (key.to_string(), value))
                .collect(),
        }
    }
}

impl StateView for MapState {
    fn get_value(&self, key: &str) -> Option<&Value> {
        self.values.get(key)
    }
}

#[test]
fn supports_python_identity_operators_for_json_singletons() {
    let cases = [
        (
            "generated_topic is None",
            MapState::from_pairs([("generated_topic", Value::Null)]),
            true,
        ),
        (
            "generated_topic is None",
            MapState::from_pairs([("generated_topic", json!("topic"))]),
            false,
        ),
        (
            "topic_feedback is not None",
            MapState::from_pairs([("topic_feedback", json!("approved"))]),
            true,
        ),
        (
            "topic_feedback is not None",
            MapState::from_pairs([("topic_feedback", Value::Null)]),
            false,
        ),
        (
            "flag is True",
            MapState::from_pairs([("flag", json!(true))]),
            true,
        ),
        (
            "flag is not False",
            MapState::from_pairs([("flag", json!(true))]),
            true,
        ),
        (
            "count is True",
            MapState::from_pairs([("count", json!(1))]),
            false,
        ),
        (
            "payload is payload_alias",
            MapState::from_pairs([
                ("payload", json!({"topic": "parity"})),
                ("payload_alias", json!({"topic": "parity"})),
            ]),
            false,
        ),
    ];

    for (expression, state, expected) in cases {
        let ast = parse(expression).expect("identity expression should parse");
        let actual = evaluate_bool(&ast, &state).expect("identity expression should evaluate");
        assert_eq!(actual, expected, "unexpected result for {expression}");
    }
}

#[test]
fn supports_if_expression_and_short_circuit_branching() {
    let ast = parse("(missing if flag else fallback) == 1").expect("parse should succeed");
    let state = MapState::from_pairs([("flag", json!(false)), ("fallback", json!(1))]);
    assert!(evaluate_bool(&ast, &state).expect("evaluation should succeed"));
}

#[test]
fn supports_floor_division_and_power_operators() {
    let floor_div = parse("5 // 2 == 2").expect("parse should succeed");
    assert!(
        evaluate_bool(&floor_div, &MapState::from_pairs([])).expect("floor div should evaluate")
    );

    let power = parse("2 ** 5 == 32").expect("parse should succeed");
    assert!(evaluate_bool(&power, &MapState::from_pairs([])).expect("power should evaluate"));
}

#[test]
fn zero_to_negative_power_returns_division_by_zero_error_for_ints() {
    let ast = parse("0 ** -1").expect("parse should succeed");
    assert!(
        matches!(
            evaluate_bool(&ast, &MapState::from_pairs([])),
            Err(ExprError::DivisionByZero)
        ),
        "0 ** -1 should raise division by zero for parity with Python"
    );
}

#[test]
fn zero_to_negative_power_returns_division_by_zero_error_for_floats() {
    let ast = parse("0.0 ** -1").expect("parse should succeed");
    assert!(
        matches!(
            evaluate_bool(&ast, &MapState::from_pairs([])),
            Err(ExprError::DivisionByZero)
        ),
        "0.0 ** -1 should raise division by zero for parity with Python"
    );
}

#[test]
fn supports_slice_syntax_for_lists_and_strings() {
    let list_slice = parse("arr[1:][0] == 2").expect("parse should succeed");
    let list_state = MapState::from_pairs([("arr", json!([1, 2, 3, 4]))]);
    assert!(evaluate_bool(&list_slice, &list_state).expect("list slice should evaluate"));

    let string_slice = parse("text[:3] == prefix").expect("parse should succeed");
    let string_state = MapState::from_pairs([("text", json!("abcdef")), ("prefix", json!("abc"))]);
    assert!(evaluate_bool(&string_slice, &string_state).expect("string slice should evaluate"));
}

#[test]
fn supports_reverse_slice_defaults_for_lists_and_strings() {
    let reversed_list = parse("arr[::-1][0] == 4").expect("parse should succeed");
    let list_state = MapState::from_pairs([("arr", json!([1, 2, 3, 4]))]);
    assert!(evaluate_bool(&reversed_list, &list_state).expect("list reverse slice should evaluate"));

    let reversed_text = parse("text[::-1] == reversed").expect("parse should succeed");
    let text_state =
        MapState::from_pairs([("text", json!("abcdef")), ("reversed", json!("fedcba"))]);
    assert!(
        evaluate_bool(&reversed_text, &text_state).expect("string reverse slice should evaluate")
    );
}

#[test]
fn supports_attribute_access_against_object_values() {
    let ast = parse("obj.score >= threshold").expect("parse should succeed");
    let state = MapState::from_pairs([("obj", json!({"score": 9})), ("threshold", json!(9))]);
    assert!(evaluate_bool(&ast, &state).expect("attribute access should evaluate"));
}
