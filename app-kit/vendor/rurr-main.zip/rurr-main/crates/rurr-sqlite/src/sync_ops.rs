use super::{
    map_rusqlite_error, row_tuple_from_rusqlite,
    shared::{connection_closed_error, SqliteShared},
    PersistedStateData, PersistedStateStatus, PersistenceError, SqlitePersister,
    SqlitePersisterConfig, OP_CONNECTION_LOCK_POISONED, OP_SQLITE_CONNECT_FAILED,
    OP_SQLITE_MIGRATION_FAILED, OP_SQLITE_QUERY_FAILED, OP_STATE_SERIALIZATION_FAILED,
};
use indexmap::IndexMap;
use rurr_persistence::{
    BaseStateLoader, BaseStateSaver, InitializationHint, PersistedStateSaveRequest,
    SqlInitializationPlan, SqlListAppIdsPlan, SqlSavePlan, SyncSqlBackend, SyncSqlPersistenceCore,
};
use rusqlite::{params, Connection, OptionalExtension, Params, Statement};
use serde_json::Value;
use std::sync::{Mutex, MutexGuard};

struct SqliteSyncBackend<'a> {
    persister: &'a SqlitePersister,
}

impl<'a> SqliteSyncBackend<'a> {
    fn query_optional_persisted_row<P>(
        &self,
        query: &str,
        params: P,
    ) -> Result<Option<rurr_persistence::PersistedRowTuple>, PersistenceError>
    where
        P: Params,
    {
        self.persister.with_connection(|connection| {
            let mut statement = self.prepare_query(connection, query)?;
            statement
                .query_row(params, row_tuple_from_rusqlite)
                .optional()
                .map_err(|error| self.query_failed(error))
        })
    }

    fn query_app_id_list<P>(&self, query: &str, params: P) -> Result<Vec<String>, PersistenceError>
    where
        P: Params,
    {
        self.persister.with_connection(|connection| {
            let mut statement = self.prepare_query(connection, query)?;
            let rows = statement
                .query_map(params, |row| row.get::<_, String>(0))
                .map_err(|error| self.query_failed(error))?;

            rows.collect::<Result<Vec<_>, _>>()
                .map_err(|error| self.query_failed(error))
        })
    }

    fn prepare_query<'conn>(
        &self,
        connection: &'conn Connection,
        query: &str,
    ) -> Result<Statement<'conn>, PersistenceError> {
        connection
            .prepare(query)
            .map_err(|error| self.query_failed(error))
    }

    fn query_failed(&self, error: rusqlite::Error) -> PersistenceError {
        self.persister
            .map_query_error(error, OP_SQLITE_QUERY_FAILED)
    }
}

impl<'a> SyncSqlBackend for SqliteSyncBackend<'a> {
    fn ensure_open(&self) -> Result<(), PersistenceError> {
        let connection = self.persister.lock_connection()?;
        if connection.is_none() {
            Err(connection_closed_error())
        } else {
            Ok(())
        }
    }

    fn run_migration(&self, plan: &SqlInitializationPlan<'_>) -> Result<(), PersistenceError> {
        self.persister.with_connection(|connection| {
            connection
                .execute_batch(plan.migration_sql)
                .map_err(|error| {
                    self.persister
                        .map_query_error(error, OP_SQLITE_MIGRATION_FAILED)
                })
        })
    }

    fn table_exists(&self, plan: &SqlInitializationPlan<'_>) -> Result<bool, PersistenceError> {
        self.persister.with_connection(|connection| {
            let mut statement = connection
                .prepare("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?1 LIMIT 1")
                .map_err(|error| {
                    self.persister
                        .map_query_error(error, OP_SQLITE_QUERY_FAILED)
                })?;
            statement
                .query_row([plan.table_name], |row| row.get::<_, i64>(0))
                .optional()
                .map(|row| row.is_some())
                .map_err(|error| {
                    self.persister
                        .map_query_error(error, OP_SQLITE_QUERY_FAILED)
                })
        })
    }

    fn save(&self, plan: &SqlSavePlan<'_, '_>) -> Result<(), PersistenceError> {
        self.persister.with_connection(|connection| {
            connection
                .execute(
                    plan.query,
                    params![
                        &plan.partition_key,
                        plan.app_id,
                        plan.sequence_id,
                        plan.position,
                        &plan.state_json,
                        plan.status
                    ],
                )
                .map_err(|error| {
                    self.persister
                        .map_query_error(error, OP_SQLITE_QUERY_FAILED)
                })?;
            Ok(())
        })
    }

    fn load_latest_partition(
        &self,
        query: &str,
        partition_key: &str,
    ) -> Result<Option<rurr_persistence::PersistedRowTuple>, PersistenceError> {
        self.query_optional_persisted_row(query, [partition_key])
    }

    fn load_latest_app(
        &self,
        query: &str,
        partition_key: &str,
        app_id: &str,
    ) -> Result<Option<rurr_persistence::PersistedRowTuple>, PersistenceError> {
        self.query_optional_persisted_row(query, params![partition_key, app_id])
    }

    fn load_exact_sequence(
        &self,
        query: &str,
        partition_key: &str,
        app_id: &str,
        sequence_id: i64,
    ) -> Result<Option<rurr_persistence::PersistedRowTuple>, PersistenceError> {
        self.query_optional_persisted_row(query, params![partition_key, app_id, sequence_id])
    }

    fn list_app_ids(&self, plan: &SqlListAppIdsPlan<'_>) -> Result<Vec<String>, PersistenceError> {
        self.query_app_id_list(plan.query, [&plan.partition_key])
    }
}

impl SqlitePersister {
    /// Opens a synchronous SQLite persister from a serialized config value.
    pub fn new(config: SqlitePersisterConfig) -> Result<Self, PersistenceError> {
        let connection = Connection::open(&config.database).map_err(|_| {
            PersistenceError::UnsupportedOperation {
                operation: OP_SQLITE_CONNECT_FAILED,
            }
        })?;

        Ok(Self {
            config: config.clone(),
            connection: Mutex::new(Some(connection)),
            shared: SqliteShared::new(config.table_name)?,
            initialized: InitializationHint::new(),
        })
    }

    /// Returns the configuration originally used to construct this persister.
    pub fn config(&self) -> SqlitePersisterConfig {
        self.config.clone()
    }

    /// Closes the current SQLite connection and clears the initialization hint.
    pub fn cleanup(&self) -> Result<(), PersistenceError> {
        self.shutdown()
    }

    fn sync_core(&self) -> SyncSqlPersistenceCore<'_, SqliteSyncBackend<'_>> {
        SyncSqlPersistenceCore::new(
            SqliteSyncBackend { persister: self },
            self.shared.sync_query_plan(),
            self.shared.table_name(),
            self.shared.migration_sql(),
            &self.initialized,
        )
    }

    fn shutdown(&self) -> Result<(), PersistenceError> {
        let mut connection = self.lock_connection()?;
        if let Some(connection) = connection.take() {
            connection
                .close()
                .map_err(|_| PersistenceError::UnsupportedOperation {
                    operation: OP_SQLITE_QUERY_FAILED,
                })?;
        }
        self.initialized.clear();
        Ok(())
    }

    fn map_query_error(&self, error: rusqlite::Error, operation: &'static str) -> PersistenceError {
        self.initialized
            .track_error(map_rusqlite_error(error, operation))
    }

    fn lock_connection(&self) -> Result<MutexGuard<'_, Option<Connection>>, PersistenceError> {
        self.connection
            .lock()
            .map_err(|_| PersistenceError::UnsupportedOperation {
                operation: OP_CONNECTION_LOCK_POISONED,
            })
    }

    fn with_connection<T>(
        &self,
        operation: impl FnOnce(&Connection) -> Result<T, PersistenceError>,
    ) -> Result<T, PersistenceError> {
        let connection = self.lock_connection()?;
        let connection = connection.as_ref().ok_or_else(connection_closed_error)?;
        operation(connection)
    }
}

impl BaseStateSaver for SqlitePersister {
    fn initialize(&self) -> Result<(), PersistenceError> {
        self.sync_core().initialize()
    }

    fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.sync_core().is_initialized()
    }

    fn cleanup(&self) -> Result<(), PersistenceError> {
        self.shutdown()
    }

    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.sync_core().save(
            PersistedStateSaveRequest::new(
                partition_key,
                app_id,
                sequence_id,
                position,
                state,
                status,
            ),
            OP_STATE_SERIALIZATION_FAILED,
        )
    }
}

impl BaseStateLoader for SqlitePersister {
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.sync_core().load(partition_key, app_id, sequence_id)
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        self.sync_core().list_app_ids(partition_key)
    }
}
