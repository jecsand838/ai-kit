use rurr_core::action::FunctionActionBuilder;
use rurr_core::application::ApplicationBuilder;
use rurr_core::graph::Transition;
use rurr_core::state::State;
use serde_json::json;

fn main() {
    let counter = FunctionActionBuilder::new()
        .writes(["count"])
        .build_sync(|state, _ctx| {
            let count = state
                .get("count")
                .and_then(serde_json::Value::as_i64)
                .unwrap_or(0)
                + 1;
            [("count".to_string(), json!(count))].into_iter().collect()
        })
        .expect("counter action should build");

    let mut app = ApplicationBuilder::new()
        .with_state(State::new(
            [("count".to_string(), json!(0))].into_iter().collect(),
        ))
        .expect("state should configure")
        .with_actions(vec![("counter", counter)])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("app should build");

    let mut iterate = app.stream_iterate();
    let (_action, _step) = iterate
        .next_step()
        .expect("first next_step should succeed")
        .expect("step should exist");

    let _ = iterate.next_step();
}
