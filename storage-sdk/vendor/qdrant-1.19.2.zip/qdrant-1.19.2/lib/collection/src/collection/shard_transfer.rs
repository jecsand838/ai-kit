use std::future::Future;
use std::path::PathBuf;
use std::sync::Arc;
use std::time::Duration;

use common::defaults;
use parking_lot::Mutex;
use semver::Version;
use tokio_util::task::AbortOnDropHandle;

use super::Collection;
use super::resharding::AbortReshardingScope;
use crate::operations::cluster_ops::ReshardingDirection;
use crate::operations::types::{CollectionError, CollectionResult};
use crate::shards::local_shard::LocalShard;
use crate::shards::replica_set::replica_set_state::ReplicaState;
use crate::shards::shard::{PeerId, ShardId};
use crate::shards::shard_holder::ShardHolder;
use crate::shards::transfer;
use crate::shards::transfer::transfer_tasks_pool::{TransferTaskItem, TransferTaskProgress};
use crate::shards::transfer::{
    ShardTransfer, ShardTransferConsensus, ShardTransferKey, ShardTransferMethod,
};

impl Collection {
    pub async fn get_related_transfers(&self, current_peer_id: PeerId) -> Vec<ShardTransfer> {
        self.shards_holder.read().await.get_transfers(|transfer| {
            transfer.from == current_peer_id || transfer.to == current_peer_id
        })
    }

    pub async fn check_transfer_exists(&self, transfer_key: &ShardTransferKey) -> bool {
        self.shards_holder
            .read()
            .await
            .check_transfer_exists(transfer_key)
    }

    /// Validate that a transfer with the given key exists, to prevent double handling
    pub async fn validate_transfer_exists(
        &self,
        transfer_key: &ShardTransferKey,
    ) -> CollectionResult<()> {
        if !self.check_transfer_exists(transfer_key).await {
            return Err(CollectionError::bad_request(format!(
                "There is no transfer for shard {} from {} to {}",
                transfer_key.shard_id, transfer_key.from, transfer_key.to,
            )));
        }
        Ok(())
    }

    async fn is_prevent_unoptimized(&self) -> bool {
        self.effective_optimizers_config()
            .await
            .map(|config| config.prevent_unoptimized.unwrap_or(false))
            .unwrap_or(false)
    }

    /// Legacy default shard transfer method for Qdrant <1.18.0
    pub async fn legacy_default_shard_transfer_method(&self) -> ShardTransferMethod {
        if self.is_prevent_unoptimized().await {
            // With prevent_unoptimized, use snapshot as the default method.
            // For automatic transfers, mod.rs prefers WalDelta when all peers
            // support it and falls back to this default otherwise.
            log::info!("Using snapshot transfer method because prevent_unoptimized is enabled");
            ShardTransferMethod::Snapshot
        } else {
            self.shared_storage_config
                .default_shard_transfer_method
                .unwrap_or(ShardTransferMethod::StreamRecords)
        }
    }

    /// Default shard transfer method for Qdrant 1.18.0+
    pub fn default_shard_transfer_method(&self) -> ShardTransferMethod {
        self.shared_storage_config
            .default_shard_transfer_method
            .unwrap_or(ShardTransferMethod::Snapshot)
    }

    /// The initial replica state of a transfer's destination for the given
    /// transfer `method`. For resharding transfers this depends on the current
    /// resharding direction (up -> `Resharding`, down -> `ReshardingScaleDown`),
    /// so it errors if no resharding is in progress.
    async fn initial_replica_state_for_transfer(
        &self,
        method: ShardTransferMethod,
    ) -> CollectionResult<ReplicaState> {
        let initial_state = match method {
            ShardTransferMethod::StreamRecords => ReplicaState::Partial,
            ShardTransferMethod::Snapshot | ShardTransferMethod::WalDelta => ReplicaState::Recovery,
            ShardTransferMethod::ReshardingStreamRecords => {
                let direction = self.resharding_state().await.map(|state| state.direction);

                let Some(direction) = direction else {
                    return Err(CollectionError::bad_input(
                        "can't start resharding transfer, because resharding is not in progress",
                    ));
                };

                match direction {
                    ReshardingDirection::Up => ReplicaState::Resharding,
                    ReshardingDirection::Down => ReplicaState::ReshardingScaleDown,
                }
            }
        };

        Ok(initial_state)
    }

    pub async fn start_shard_transfer<T, F>(
        &self,
        mut shard_transfer: ShardTransfer,
        consensus: Box<dyn ShardTransferConsensus>,
        temp_dir: PathBuf,
        on_finish: T,
        on_error: F,
    ) -> CollectionResult<bool>
    where
        T: Future<Output = ()> + Send + 'static,
        F: Future<Output = ()> + Send + 'static,
    {
        // The coordinating peer must pick the transfer method before submitting
        // to consensus, so that every peer applies the same method for a given
        // transfer.
        //
        // Once every peer is at 1.18.0+, all submission sites guarantee the
        // method is set, so a missing method indicates a bug — refuse it.
        // For mixed clusters (some peers <1.18.0), an older submission site
        // may still send `None`; fall back to this peer's local default to
        // preserve compatibility.
        if shard_transfer.method.is_none() {
            let all_peers_enforce = self
                .channel_service
                .all_peers_at_version(&Version::new(1, 18, 0));
            if all_peers_enforce {
                return Err(CollectionError::service_error(format!(
                    "Shard transfer {}:{} -> {} has no method set; the coordinating peer must \
                     pick a transfer method before submitting to consensus",
                    shard_transfer.shard_id, shard_transfer.from, shard_transfer.to,
                )));
            }
            let default_method = self.legacy_default_shard_transfer_method().await;
            log::warn!(
                "No shard transfer method selected, defaulting to {default_method:?} \
                 (cluster contains peers older than 1.18.0)",
            );
            shard_transfer.method = Some(default_method);
        }

        // Staging-only: pause the sender before it registers anything of the `Start`, so a test
        // can kill this peer while the entry is committed but not yet applied. On restart the
        // entry is replayed before this peer rejoins consensus, spawning a driver for a transfer
        // the rest of the cluster may have aborted since.
        #[cfg(feature = "staging")]
        if consensus.this_peer_id() == shard_transfer.from
            && let Ok(secs) = std::env::var("QDRANT_STAGING_SHARD_TRANSFER_START_DELAY_SEC")
            && let Ok(secs) = secs.parse::<f64>()
        {
            tokio::time::sleep(std::time::Duration::from_secs_f64(secs)).await;
        }

        let do_transfer = {
            let this_peer_id = consensus.this_peer_id();
            let is_receiver = this_peer_id == shard_transfer.to;
            let is_sender = this_peer_id == shard_transfer.from;

            // Get the source and target shards, in case of resharding the target shard is different
            let from_shard_id = shard_transfer.shard_id;
            let to_shard_id = shard_transfer
                .to_shard_id
                .unwrap_or(shard_transfer.shard_id);

            let shards_holder = self.shards_holder.read().await;

            let from_replica_set = shards_holder.get_shard(from_shard_id).ok_or_else(|| {
                CollectionError::bad_request(format!("shard {from_shard_id} doesn't exist"))
            })?;

            let to_replica_set = shards_holder.get_shard(to_shard_id).ok_or_else(|| {
                CollectionError::bad_request(format!("shard {to_shard_id} doesn't exist"))
            })?;

            // Checked at the top of the function — the method is always set by the
            // peer that submitted this transfer to consensus.
            let transfer_method = shard_transfer.method.expect("transfer method must be set");
            let initial_state = self
                .initial_replica_state_for_transfer(transfer_method)
                .await?;

            let _was_not_transferred =
                shards_holder.register_start_shard_transfer(shard_transfer.clone())?;

            let from_is_local = from_replica_set.is_local().await;
            let to_is_local = to_replica_set.is_local().await;

            // Create local shard if it does not exist on receiver, or simply set replica state otherwise
            // (on all peers, regardless if shard is local or remote on that peer).
            //
            // This should disable queries to receiver replica even if it was active before.
            if !to_is_local && is_receiver {
                let effective_optimizers_config = self.effective_optimizers_config().await?;

                let shard = LocalShard::build(
                    to_shard_id,
                    self.name().to_string(),
                    &to_replica_set.shard_path,
                    self.collection_config.clone(),
                    self.shared_storage_config.clone(),
                    self.payload_index_schema.clone(),
                    self.update_runtime.clone(),
                    self.search_runtime.clone(),
                    self.optimizer_resource_budget.clone(),
                    effective_optimizers_config,
                )
                .await?;

                let old_shard = to_replica_set.set_local(shard, Some(initial_state)).await?;
                if let Some(old_shard) = old_shard {
                    debug_assert!(false, "We should not have a local shard yet");
                    old_shard.stop_gracefully().await;
                }
            } else {
                to_replica_set
                    .ensure_replica_with_state(shard_transfer.to, initial_state)
                    .await?;
            }

            from_is_local && is_sender
        };
        if do_transfer {
            self.send_shard(shard_transfer, consensus, temp_dir, on_finish, on_error)
                .await;
        }
        Ok(do_transfer)
    }

    async fn send_shard<OF, OE>(
        &self,
        transfer: ShardTransfer,
        consensus: Box<dyn ShardTransferConsensus>,
        temp_dir: PathBuf,
        on_finish: OF,
        on_error: OE,
    ) where
        OF: Future<Output = ()> + Send + 'static,
        OE: Future<Output = ()> + Send + 'static,
    {
        let mut active_transfer_tasks = self.transfer_tasks.lock().await;
        let task_result = active_transfer_tasks.stop_task(&transfer.key()).await;

        debug_assert!(task_result.is_none(), "Transfer task already exists");
        debug_assert!(
            transfer.method.is_some(),
            "When sending shard, a transfer method must have been selected",
        );

        let shard_holder = self.shards_holder.clone();
        let collection_id = self.id.clone();
        let channel_service = self.channel_service.clone();

        let progress = Arc::new(Mutex::new(TransferTaskProgress::new()));

        // With prevent_unoptimized, fall back to snapshot which preserves deferred
        // point state exactly (raw segment copy). stream_records sends deferred
        // points but they won't be deferred on the target.
        // Otherwise use the configured cluster default transfer method, except
        // never fall back to wal_delta: it's the method most likely to be
        // failing (the only currently-fallible automatic transfer), and a same-
        // method fallback would just be refused in the driver. Use snapshot as
        // a safe fallback in that case, which is also the 1.18.0+ default.
        let fallback_method = if self.is_prevent_unoptimized().await {
            ShardTransferMethod::Snapshot
        } else {
            match self.default_shard_transfer_method() {
                ShardTransferMethod::WalDelta => ShardTransferMethod::Snapshot,
                method @ (ShardTransferMethod::StreamRecords
                | ShardTransferMethod::Snapshot
                | ShardTransferMethod::ReshardingStreamRecords) => method,
            }
        };
        let transfer_task = transfer::driver::spawn_transfer_task(
            shard_holder,
            progress.clone(),
            transfer.clone(),
            consensus,
            collection_id,
            channel_service,
            self.snapshots_path.clone(),
            temp_dir,
            fallback_method,
            on_finish,
            on_error,
        );

        active_transfer_tasks.add_task(
            &transfer,
            TransferTaskItem {
                task: transfer_task,
                started_at: chrono::Utc::now(),
                progress,
            },
        );
    }

    /// Restart a shard transfer with new method, updating transfer record in place
    /// instead of aborting and re-starting it.
    ///
    /// `transfer_key` identifies the existing record; `new_transfer` is replacement,
    /// with new method and old record's `sync` flag preserved.
    ///
    /// Every step is individually idempotent, and record's method update
    /// (`register_restart_transfer`) is the *last* durable write, so it gates the
    /// whole operation:
    ///
    /// - If we crash *before* the method update, on replay the record still carries
    ///   the old method, so every step re-runs and converges.
    /// - If we crash *after*, on replay the record carries the new method, and the
    ///   check below returns an idempotent no-op.
    ///
    /// The record is never removed at any point, so a replay always finds it.
    /// If it is missing, this is a stale duplicate restart and is rejected.
    pub async fn restart_shard_transfer<T, F>(
        &self,
        transfer_key: ShardTransferKey,
        new_transfer: ShardTransfer,
        consensus: Box<dyn ShardTransferConsensus>,
        temp_dir: PathBuf,
        on_finish: T,
        on_error: F,
    ) -> CollectionResult<()>
    where
        T: Future<Output = ()> + Send + 'static,
        F: Future<Output = ()> + Send + 'static,
    {
        let new_method = new_transfer
            .method
            .expect("restart transfer method must be set");

        // 1. Proceed only if the record exists and still carries the old method.
        //    The record is never removed during a restart, so a missing record means
        //    a stale duplicate restart (reject it), and a record already carrying the
        //    new method means this restart already applied (idempotent no-op).
        {
            let shard_holder = self.shards_holder.read().await;
            let Some(existing) = shard_holder.get_transfer(&transfer_key) else {
                return Err(CollectionError::bad_request(format!(
                    "There is no transfer for shard {} from {} to {}",
                    transfer_key.shard_id, transfer_key.from, transfer_key.to,
                )));
            };
            if existing.method == Some(new_method) {
                log::warn!(
                    "Restart of shard transfer {transfer_key:?} to method {new_method:?} \
                     was already applied, treating as idempotent no-op",
                );
                return Ok(());
            }
        }

        let this_peer_id = consensus.this_peer_id();
        let is_sender = this_peer_id == new_transfer.from;
        let is_receiver = this_peer_id == new_transfer.to;
        let dest_shard_id = new_transfer.to_shard_id.unwrap_or(new_transfer.shard_id);

        let initial_state = self.initial_replica_state_for_transfer(new_method).await?;

        // 2. Stop the running transfer task for the old record.
        let _ = self
            .transfer_tasks
            .lock()
            .await
            .stop_task(&transfer_key)
            .await;

        {
            let shard_holder = self.shards_holder.read().await;

            // 3. Sender: revert the queue/proxy back to a plain local shard.
            if is_sender {
                transfer::driver::revert_proxy_shard_to_local(&shard_holder, new_transfer.shard_id)
                    .await?;
            }

            // The destination replica set exists on every peer (remote elsewhere,
            // local on the receiver).
            let Some(dest_replica_set) = shard_holder.get_shard(dest_shard_id) else {
                return Err(CollectionError::bad_request(format!(
                    "Shard {dest_shard_id} doesn't exist"
                )));
            };

            // 4. Receiver: reset the destination local shard to empty, discarding
            //    any partially-transferred data. Safe because a restart is only ever
            //    proposed as a WAL-delta transfer fallback (never resharding), and the
            //    fallback method fully re-populates the destination.
            if is_receiver {
                dest_replica_set.init_empty_local_shard(&self.path).await?;
            }

            // 5. All peers: set the destination replica to the new method's
            //    initial state.
            dest_replica_set
                .ensure_replica_with_state(new_transfer.to, initial_state)
                .await?;

            // 6. Update the record's method in place. This is the last durable
            //    write, so it gates the whole operation on replay (see the doc comment).
            shard_holder.register_restart_transfer(&transfer_key, new_method)?;
        }

        // 7. Sender: (re)spawn the transfer driver for the new transfer.
        if is_sender {
            self.send_shard(new_transfer, consensus, temp_dir, on_finish, on_error)
                .await;
        }

        Ok(())
    }

    /// Handles finishing of the shard transfer.
    ///
    /// Returns true if state was changed, false otherwise.
    pub async fn finish_shard_transfer(
        &self,
        transfer: ShardTransfer,
        shard_holder: Option<&ShardHolder>,
    ) -> CollectionResult<()> {
        let transfer_result = self
            .transfer_tasks
            .lock()
            .await
            .stop_task(&transfer.key())
            .await;

        log::debug!("Transfer result: {transfer_result:?}");

        let mut shard_holder_guard = None;

        let shard_holder = match shard_holder {
            Some(shard_holder) => shard_holder,
            None => shard_holder_guard.insert(self.shards_holder.read().await),
        };

        let is_resharding_transfer = transfer.method.is_some_and(|method| method.is_resharding());

        // Handle *destination* replica
        let mut is_dest_replica_active = false;

        let dest_replica_set =
            shard_holder.get_shard(transfer.to_shard_id.unwrap_or(transfer.shard_id));

        if let Some(replica_set) = dest_replica_set
            && replica_set.peer_state(transfer.to).is_some()
        {
            // Promote *destination* replica/shard to `Active` if:
            //
            // - replica *exists*
            //   - replica should be created when shard transfer (or resharding) is started
            //   - replica might *not* exist, if it (or the whole *peer*) was removed right
            //     before transfer is finished
            // - transfer is *not* resharding
            //   - resharding requires multiple transfers, so destination shard is promoted
            //     *explicitly* when all transfers are finished

            // TODO(resharding): Do not change replica state at all, when finishing resharding transfer?
            //
            // We switch replica into correct state when *starting* resharding transfer, and
            // we want to *keep* it in the same state *after* resharding transfer is finished...
            let state = if is_resharding_transfer {
                let resharding_direction =
                    self.resharding_state().await.map(|state| state.direction);

                match resharding_direction {
                    Some(ReshardingDirection::Up) => ReplicaState::Resharding,
                    Some(ReshardingDirection::Down) => ReplicaState::ReshardingScaleDown,
                    None => {
                        log::error!(
                            "Can't finish resharding shard transfer correctly, \
                                 because resharding is not in progress anymore!",
                        );

                        ReplicaState::Dead
                    }
                }
            } else {
                ReplicaState::Active
            };

            if transfer.to == self.this_peer_id {
                replica_set.set_replica_state(transfer.to, state).await?;
            } else {
                replica_set.add_remote(transfer.to, state).await?;
            }

            is_dest_replica_active = state == ReplicaState::Active;
        }

        // Handle *source* replica
        let src_replica_set = shard_holder.get_shard(transfer.shard_id);

        if let Some(replica_set) = src_replica_set {
            if transfer.sync || is_resharding_transfer {
                // If transfer is *sync* (or *resharding*), we *keep* source replica

                if transfer.from == self.this_peer_id {
                    // If current peer is *transfer-sender*, we need to unproxify local shard

                    replica_set.un_proxify_local().await?;
                }
            } else if is_dest_replica_active {
                // If transfer is *not* sync (and *not* resharding) and *destination* replica is `Active`,
                // we *remove* source replica

                if transfer.from == self.this_peer_id {
                    self.invalidate_clean_local_shards([transfer.shard_id])
                        .await;
                    replica_set.remove_local().await?;
                } else {
                    replica_set.remove_remote(transfer.from).await?;
                }
            }
        }

        let is_finish_registered = shard_holder.register_finish_transfer(&transfer.key())?;
        log::debug!("Transfer finish registered: {is_finish_registered}");

        Ok(())
    }

    /// Return if it was a resharding transfer so it can be handled correctly (aborted or ignored)
    pub async fn abort_shard_transfer(
        &self,
        transfer: ShardTransfer,
        shard_holder: &ShardHolder,
    ) -> CollectionResult<()> {
        // TODO: Ensure cancel safety!
        let transfer_key = transfer.key();
        log::debug!("Aborting shard transfer {transfer:?}");

        let _transfer_result = self
            .transfer_tasks
            .lock()
            .await
            .stop_task(&transfer_key)
            .await;

        let is_resharding_transfer = transfer.is_resharding();

        let shard_id = transfer_key.to_shard_id.unwrap_or(transfer_key.shard_id);

        if let Some(replica_set) = shard_holder.get_shard(shard_id) {
            if replica_set.peer_state(transfer.to).is_some() {
                if is_resharding_transfer {
                    // If *resharding* shard transfer failed, we don't need/want to change replica state:
                    // - on transfer failure, the whole resharding would be aborted (see below),
                    //   and so all changes to replicas would be discarded/rolled-back anyway
                    // - during resharding *up*, we transfer points to a single new shard replica;
                    //   it is expected that this node is initially empty/incomplete, and so failed
                    //   transfer should not strictly introduce inconsistency (it just means the node
                    //   is *still* empty/incomplete); marking this new replica as `Dead` would only
                    //   make requests to return explicit errors
                    // - during resharding *down*, we transfer points from shard-to-be-removed
                    //   to all other shards; all other shards are expected to be `Active`,
                    //   and so failed transfer does not introduce any inconsistencies to points
                    //   that are not affected by resharding in all other shards
                } else if transfer.sync {
                    replica_set
                        .set_replica_state(transfer.to, ReplicaState::Dead)
                        .await?;
                } else {
                    self.invalidate_clean_local_shards([transfer
                        .to_shard_id
                        .unwrap_or(transfer.shard_id)])
                        .await;
                    replica_set.remove_peer(transfer.to).await?;
                }
            }
        } else {
            log::warn!(
                "Aborting shard transfer {transfer_key:?}, but shard {shard_id} does not exist"
            );
        }

        if transfer.from == self.this_peer_id {
            transfer::driver::revert_proxy_shard_to_local(shard_holder, transfer.shard_id).await?;
        }

        shard_holder.register_abort_transfer(&transfer_key)?;

        Ok(())
    }

    /// Handles abort of the transfer and also aborts resharding if the transfer was related to resharding
    ///
    /// 1. Unregister the transfer
    /// 2. Stop transfer task
    /// 3. Unwrap the proxy
    /// 4. Remove temp shard, or mark it as dead
    pub async fn abort_shard_transfer_and_resharding(
        &self,
        transfer_key: ShardTransferKey,
    ) -> CollectionResult<()> {
        // Look up transfer and any resharding state we need to abort
        let resharding_state = {
            let shard_holder = self.shards_holder.read().await;

            let Some(transfer) = shard_holder.get_transfer(&transfer_key) else {
                return Ok(());
            };

            if transfer.is_resharding() {
                shard_holder.resharding_state.read().clone()
            } else {
                None
            }
        };

        // Abort resharding *before* aborting the transfer.
        // Exclude this transfer from `abort_resharding` transfer cleanup (`skip_transfer`),
        // and abort transfer *last*, after resharding state is cleared.
        //
        // On replay after a crash:
        // - transfer registered, resharding state set: re-run the whole operation
        // - transfer registered, resharding state cleared: skip resharding abort,
        //   abort the transfer
        // - transfer not registered: everything already applied, no-op

        #[cfg(feature = "staging")]
        let is_resharding_abort = resharding_state.is_some();

        if let Some(state) = resharding_state {
            self.abort_resharding(
                state.key(),
                false,
                AbortReshardingScope {
                    skip_transfer: Some(transfer_key),
                    ..Default::default()
                },
            )
            .await?;
        }

        // Staging-only: pause after clearing resharding state, but before aborting
        // transfer, so test can kill this peer mid-abort (resharding state cleared,
        // transfer still registered) and verify that replay converges.
        #[cfg(feature = "staging")]
        if is_resharding_abort
            && let Ok(secs) = std::env::var("QDRANT_STAGING_RESHARDING_ABORT_DELAY_SEC")
            && let Ok(secs) = secs.parse::<f64>()
        {
            tokio::time::sleep(std::time::Duration::from_secs_f64(secs)).await;
        }

        let shard_holder = self.shards_holder.read().await;

        // Abort resharding must *not* abort this transfer
        let transfer = shard_holder
            .get_transfer(&transfer_key)
            .expect("shard transfer exists");

        self.abort_shard_transfer(transfer, &shard_holder).await
    }

    /// Initiate local partial shard
    ///
    /// # Cancel safety
    ///
    /// This is cancel safe. If the future is dropped, initialization is aborted.
    ///
    /// If the shard was in dummy state, it will be recreated. Aborting this may leave it in
    /// partial state. In that case it will remain a dummy shard, signaled by the initialization
    /// flag on disk. It may then be fully reinitialized on the next transfer attempt.
    ///
    /// If `from_peer_id` is given, only a transfer from that peer is accepted. A sender that
    /// drives a transfer consensus has since aborted must not be able to piggyback on another
    /// transfer into this shard.
    pub fn initiate_shard_transfer(
        &self,
        shard_id: ShardId,
        from_peer_id: Option<PeerId>,
    ) -> impl Future<Output = CollectionResult<()>> + 'static {
        let shards_holder = self.shards_holder.clone();

        let collection_path = self.path.clone();

        async move {
            let shards_holder_guard = shards_holder.clone().read_owned().await;

            let Some(replica_set) = shards_holder_guard.get_shard(shard_id) else {
                return Err(CollectionError::service_error(format!(
                    "Shard {shard_id} doesn't exist, repartition is not supported yet"
                )));
            };

            // Wait for the replica set to have the local shard initialized
            // This can take some time as this is arranged through consensus
            replica_set
                .wait_for_local(defaults::CONSENSUS_META_OP_WAIT)
                .await?;

            let this_peer_id = replica_set.this_peer_id();
            let replica_set = Arc::clone(replica_set);

            let shard_transfer_requested = tokio::task::spawn_blocking(move || {
                // Wait for transfer targeting this replica
                let shard_transfer_registered = shards_holder_guard.shard_transfers.wait_for(
                    |shard_transfers| {
                        shard_transfers
                            .iter()
                            .any(|shard_transfer| shard_transfer.is_target(this_peer_id, shard_id))
                    },
                    Duration::from_secs(60),
                );

                // Reject request, if no transfer was registered within 60 seconds
                if !shard_transfer_registered {
                    return Ok(false);
                }

                // Check that request comes from expected sender
                if let Some(from_peer_id) = from_peer_id {
                    let transfers = shards_holder_guard
                        .get_transfers(|transfer| transfer.is_target(this_peer_id, shard_id));

                    let is_expected_sender = transfers
                        .iter()
                        .any(|transfer| transfer.from == from_peer_id);

                    if !is_expected_sender {
                        return Err(CollectionError::bad_request(format!(
                            "Refusing to initiate shard transfer from peer {from_peer_id} into shard {shard_id}: \
                             there is no registered transfer from peer {from_peer_id}",
                        )));
                    }
                }

                // Transfer is registered before the replica state is set.
                // Wait until the local replica switches to a shard transfer state.
                Ok(replica_set.wait_for_state_condition_sync(
                    |state| {
                        state
                            .get_peer_state(this_peer_id)
                            .is_some_and(|peer_state| peer_state.is_partial_or_recovery())
                    },
                    defaults::CONSENSUS_META_OP_WAIT,
                ))
            });

            match AbortOnDropHandle::new(shard_transfer_requested).await {
                Ok(Ok(true)) => Ok(()),

                Ok(Ok(false)) => {
                    let description = "\
                        Failed to initiate shard transfer: \
                        Didn't receive shard transfer notification from consensus in 60 seconds";

                    Err(CollectionError::Timeout {
                        description: description.into(),
                    })
                }

                Ok(Err(err)) => Err(err),

                Err(err) => Err(CollectionError::service_error(format!(
                    "Failed to initiate shard transfer: \
                     Failed to execute wait-for-consensus-notification task: \
                     {err}"
                ))),
            }?;

            // At this point we made sure that receiver replica is synced and expecting incoming
            // shard transfer.
            // Further checks are an extra safety net, in normal situation they should not fail.

            let shards_holder_guard = shards_holder.read_owned().await;

            let Some(replica_set) = shards_holder_guard.get_shard(shard_id) else {
                return Err(CollectionError::service_error(format!(
                    "Shard {shard_id} doesn't exist, repartition is not supported yet"
                )));
            };

            if replica_set.is_proxy().await {
                debug_assert!(false, "We should not have proxy shard here");
                // We have proxy or something, we need to unwrap it
                log::error!("Unwrapping proxy shard {shard_id}");
                replica_set.un_proxify_local().await?;
            }

            if replica_set.is_dummy().await {
                // We can reach here because of either of these:
                // 1. Qdrant is in recovery mode, and user intentionally triggered a transfer
                // 2. Shard is dirty (shard initializing flag), and Qdrant triggered a transfer to recover from Dead state after an update fails
                //
                // In both cases, it's safe to drop existing local shard data
                log::debug!(
                    "Initiating transfer to dummy shard {}. Initializing empty local shard first",
                    replica_set.shard_id,
                );
                // Also removes the initializing flag. We can do this without waiting for the
                // transfer to finish, because if the transfer fails in between, Qdrant will retry it.
                replica_set.init_empty_local_shard(&collection_path).await?;
            }

            Ok(())
        }
    }

    /// Whether we have reached the automatic shard transfer limit based on the given incoming and
    /// outgoing transfers.
    pub(super) fn check_auto_shard_transfer_limit(&self, incoming: usize, outgoing: usize) -> bool {
        let incoming_shard_transfer_limit_reached = self
            .shared_storage_config
            .incoming_shard_transfers_limit
            .is_some_and(|limit| incoming >= limit);

        let outgoing_shard_transfer_limit_reached = self
            .shared_storage_config
            .outgoing_shard_transfers_limit
            .is_some_and(|limit| outgoing >= limit);

        incoming_shard_transfer_limit_reached || outgoing_shard_transfer_limit_reached
    }
}
