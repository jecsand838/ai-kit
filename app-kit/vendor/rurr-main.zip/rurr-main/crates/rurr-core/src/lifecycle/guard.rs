use crate::common::drop_finalizer::run_drop_finalizer;
use crate::lifecycle::context::{
    ExecuteCallContext, PostStepContext, PreStepContext, StreamContext, StreamItemContext,
};
use crate::lifecycle::{LifecycleAdapterSet, LifecycleError};
use crate::state::State;
use indexmap::IndexMap;
use serde_json::Value;

mod core;
use core::finish_sync_once;

/// RAII guard that brackets an execute-style application call.
pub struct ExecuteCallGuard {
    adapters: LifecycleAdapterSet,
    context: ExecuteCallContext,
    closed: bool,
}

impl ExecuteCallGuard {
    /// Starts a synchronous execute-call guard and runs pre-execute hooks.
    pub fn start_sync(
        adapters: &LifecycleAdapterSet,
        context: ExecuteCallContext,
    ) -> Result<Self, LifecycleError> {
        adapters.pre_execute_call_sync(&context)?;
        Ok(Self {
            adapters: adapters.clone(),
            context,
            closed: false,
        })
    }

    /// Starts an asynchronous execute-call guard and runs pre-execute hooks.
    pub async fn start_async(
        adapters: &LifecycleAdapterSet,
        context: ExecuteCallContext,
    ) -> Result<Self, LifecycleError> {
        adapters.pre_execute_call_async(&context).await?;
        Ok(Self {
            adapters: adapters.clone(),
            context,
            closed: false,
        })
    }

    /// Finishes the guard synchronously and runs post-execute hooks once.
    pub fn finish_sync(mut self) -> Result<(), LifecycleError> {
        self.finish_sync_inner()
    }

    /// Finishes the guard and then runs async-only post-execute hooks.
    pub async fn finish_async(mut self) -> Result<(), LifecycleError> {
        self.finish_sync_inner()?;
        self.adapters
            .post_execute_call_async_only(&self.context)
            .await
    }

    fn finish_sync_inner(&mut self) -> Result<(), LifecycleError> {
        finish_sync_once(&mut self.closed, || {
            self.adapters.post_execute_call_sync(&self.context)
        })
    }
}

impl Drop for ExecuteCallGuard {
    fn drop(&mut self) {
        run_drop_finalizer(|| {
            let _ = self.finish_sync_inner();
        });
    }
}

/// RAII guard that brackets a single application step.
pub struct StepGuard {
    adapters: LifecycleAdapterSet,
    pre_context: PreStepContext,
    outcome: Option<StepOutcome>,
    post_context: Option<PostStepContext>,
    closed: bool,
}

/// The final outcome recorded for a completed step.
pub enum StepOutcome {
    /// The step completed successfully.
    Success {
        /// The result payload returned by the action.
        result: IndexMap<String, Value>,
        /// The state produced by the action.
        state: State,
    },
    /// The step completed with an error.
    Error {
        /// The captured error message.
        exception: String,
        /// The state snapshot that should be reported with the failure.
        state: State,
    },
}

impl StepGuard {
    /// Starts a synchronous step guard and runs pre-step hooks.
    pub fn start_sync(
        adapters: &LifecycleAdapterSet,
        context: PreStepContext,
    ) -> Result<Self, LifecycleError> {
        adapters.pre_run_step_sync(&context)?;
        Ok(Self {
            adapters: adapters.clone(),
            pre_context: context,
            outcome: None,
            post_context: None,
            closed: false,
        })
    }

    /// Starts an asynchronous step guard and runs pre-step hooks.
    pub async fn start_async(
        adapters: &LifecycleAdapterSet,
        context: PreStepContext,
    ) -> Result<Self, LifecycleError> {
        adapters.pre_run_step_async(&context).await?;
        Ok(Self {
            adapters: adapters.clone(),
            pre_context: context,
            outcome: None,
            post_context: None,
            closed: false,
        })
    }

    /// Finishes the step guard synchronously and runs post-step hooks once.
    pub fn finish_sync(mut self) -> Result<(), LifecycleError> {
        self.finish_sync_inner()
    }

    /// Finishes the step guard and then runs async-only post-step hooks.
    pub async fn finish_async(mut self) -> Result<(), LifecycleError> {
        self.finish_sync_inner()?;
        let post = self.post_context().clone();
        self.adapters.post_run_step_async_only(&post).await
    }

    /// Records the eventual success or failure details for the step.
    pub fn record_outcome(&mut self, outcome: StepOutcome) {
        self.outcome = Some(outcome);
    }

    fn build_post_context(
        pre_context: &PreStepContext,
        outcome: Option<StepOutcome>,
    ) -> PostStepContext {
        let mut post = PostStepContext::new(
            pre_context.action_name(),
            pre_context.sequence_id(),
            pre_context.step_id(),
            pre_context.started_at(),
        );
        if let Some(app_id) = pre_context.app_id() {
            post = post.with_app_id(app_id);
        }
        post = post.with_execution_mode(pre_context.execution_mode());
        match outcome {
            Some(StepOutcome::Success { result, state }) => {
                post = post.with_result(result).with_state(state);
            }
            Some(StepOutcome::Error { exception, state }) => {
                post = post.with_exception(exception).with_state(state);
            }
            None => {}
        }
        post
    }

    fn post_context(&mut self) -> &PostStepContext {
        let pre_context = &self.pre_context;
        let outcome = &mut self.outcome;
        self.post_context
            .get_or_insert_with(|| Self::build_post_context(pre_context, outcome.take()))
    }

    fn finish_sync_inner(&mut self) -> Result<(), LifecycleError> {
        let post = self.post_context().clone();
        finish_sync_once(&mut self.closed, || self.adapters.post_run_step_sync(&post))
    }
}

impl Drop for StepGuard {
    fn drop(&mut self) {
        run_drop_finalizer(|| {
            let _ = self.finish_sync_inner();
        });
    }
}

/// RAII guard that brackets a streaming action lifecycle.
pub struct StreamGuard {
    adapters: LifecycleAdapterSet,
    context: StreamContext,
    closed: bool,
}

impl StreamGuard {
    /// Starts a synchronous stream guard and runs pre-stream hooks.
    pub fn start_sync(
        adapters: &LifecycleAdapterSet,
        context: StreamContext,
    ) -> Result<Self, LifecycleError> {
        adapters.pre_start_stream_sync(&context)?;
        Ok(Self {
            adapters: adapters.clone(),
            context,
            closed: false,
        })
    }

    /// Starts an asynchronous stream guard and runs pre-stream hooks.
    pub async fn start_async(
        adapters: &LifecycleAdapterSet,
        context: StreamContext,
    ) -> Result<Self, LifecycleError> {
        adapters.pre_start_stream_async(&context).await?;
        Ok(Self {
            adapters: adapters.clone(),
            context,
            closed: false,
        })
    }

    /// Reports an emitted item to synchronous stream-item hooks.
    pub fn post_stream_item_sync(
        &self,
        item_context: &StreamItemContext,
    ) -> Result<(), LifecycleError> {
        self.adapters.post_stream_item_sync(item_context)
    }

    /// Reports an emitted item to asynchronous stream-item hooks.
    pub async fn post_stream_item_async(
        &self,
        item_context: &StreamItemContext,
    ) -> Result<(), LifecycleError> {
        self.adapters.post_stream_item_async(item_context).await
    }

    /// Finishes the guard synchronously and runs end-of-stream hooks once.
    pub fn finish_sync(mut self) -> Result<(), LifecycleError> {
        self.finish_sync_inner()
    }

    /// Finishes the guard and then runs async-only end-of-stream hooks.
    pub async fn finish_async(mut self) -> Result<(), LifecycleError> {
        self.finish_sync_inner()?;
        self.adapters
            .post_end_stream_async_only(&self.context)
            .await
    }

    fn finish_sync_inner(&mut self) -> Result<(), LifecycleError> {
        finish_sync_once(&mut self.closed, || {
            self.adapters.post_end_stream_sync(&self.context)
        })
    }
}

impl Drop for StreamGuard {
    fn drop(&mut self) {
        run_drop_finalizer(|| {
            let _ = self.finish_sync_inner();
        });
    }
}
