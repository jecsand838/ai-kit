---
name: use-rust-best-practices-dependencies-platforms
description: "Apply this when choosing or updating Rust dependencies, setting Cargo versions/features/workspace inheritance, auditing supply-chain risk, deciding between common ecosystem crates, or making code portable across Windows, Linux, and macOS. Use it to enforce Cargo hygiene, explicit MSRV and dependency policy, security checks, target-specific dependency patterns, and portable path/process abstractions."
---

# Rust dependency and platform best practices

Use this skill when the task changes `Cargo.toml`, dependency selection, features, security posture, toolchain policy, or OS-specific code.

## When to use

Use it when the task:

- adds, removes, or updates crates
- changes workspace dependency inheritance or feature flags
- discusses MSRV / `rust-version`
- evaluates supply-chain risk or maintenance quality
- adds target-specific dependencies
- adds platform-specific code for Windows/Linux/macOS
- touches filesystem paths, standard directories, or subprocesses

## Do not use this skill alone when

- the task is mostly about HTTP/gRPC/database runtime code → also load `$use-rust-best-practices-networking`
- the task is mostly about crate/workspace structure → also load `$use-rust-best-practices-architecture`
- the task is mostly about trait/lifetime/error design → also load `$use-rust-best-practices-abstractions`

## Workflow

1. Prefer `std` and Cargo-native features before adding dependencies.
2. Centralize shared versions and lints in the workspace where that improves consistency.
3. Avoid wildcard versions and accidental default features.
4. Evaluate crates for maintenance, docs, MSRV/toolchain fit, feature surface, unsafe/FFI footprint, and platform support.
5. Keep platform-specific behavior isolated behind `cfg(...)` modules and portable path/process abstractions.

## Default rules

- Treat the Rust book, Cargo book, edition guide, and project-maintained docs as authoritative.
- Maintain an organization-local allowlist of commonly trusted crates, but avoid pretending there is a universal static “blessed list” for all Rust projects.
- Use `cargo audit`, `cargo deny`, and optionally `cargo vet`; use `cargo-semver-checks` for public crates when API compatibility matters.
- Prefer `Path` / `PathBuf`, `ProjectDirs`, and `std::process::Command` over stringly-typed OS assumptions.
- Add `rust-version` only when the repository intentionally commits to an MSRV or support floor.

## Load these references directly when needed

- `references/dependencies-and-platforms.md` — dependency policy, Cargo patterns, supply-chain tooling, MSRV guidance, and cross-platform examples.

## Load these templates when useful

- `assets/templates/project_dirs.rs`
- `assets/templates/target_specific_deps.toml`
- `assets/templates/member_with_workspace_lints.toml`

## Companion skills

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-abstractions`
