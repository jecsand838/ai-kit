# Rurr Rustdoc Checklist

Use this checklist during implementation after the plan is approved.

## Audit order

1. Start with crate roots and public modules.
2. Cover canonical source items before re-export crates.
3. Prioritize large runtime or facade surfaces first, then support crates.
4. Review doctest feasibility before writing long examples.

## Writing checks

- Keep docs in Rust doc comments.
- Add end-user-facing examples only where they clarify real usage.
- Prefer local-only setup and deterministic outputs.
- Keep companion skills loaded only when example complexity requires them.

## Validation order

1. `cargo doc --workspace --no-deps --all-features`
2. `cargo test --workspace --doc --all-features`
3. `cargo test -p rurr --examples --all-features`
4. `./scripts/doc_site.sh build`
5. `./scripts/doc_site.sh check`

If a tracked-file change triggers manifest freshness fallout, run `./scripts/fix_manifest_freshness.sh` and rerun the failed command.

## Lint rollout

- Add or tighten `#![deny(missing_docs)]` only after the affected surface is fully documented.
- Keep residual gaps explicit in the final report when coverage is still incomplete.
