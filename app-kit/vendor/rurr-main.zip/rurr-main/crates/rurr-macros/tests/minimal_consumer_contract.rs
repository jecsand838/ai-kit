use std::fs;
use std::path::PathBuf;
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

fn unique_temp_dir() -> PathBuf {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .expect("system time should be after unix epoch")
        .as_nanos();
    std::env::temp_dir().join(format!("rurr-macros-minimal-consumer-{nanos}"))
}

#[test]
fn macro_expansion_works_without_hidden_dependencies() {
    let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let core_path = manifest_dir
        .parent()
        .expect("rurr-macros should be under crates/")
        .join("rurr-core");

    let project_dir = unique_temp_dir();
    fs::create_dir_all(project_dir.join("src")).expect("temp project should be created");

    let cargo_toml = format!(
        r#"[package]
name = "minimal_consumer"
version = "0.1.0"
edition = "2021"

[dependencies]
rurr-core = {{ path = "{}" }}
rurr-macros = {{ path = "{}" }}
"#,
        core_path.display(),
        manifest_dir.display(),
    );
    fs::write(project_dir.join("Cargo.toml"), cargo_toml).expect("Cargo.toml should be written");

    let source = r#"
use rurr_core::action::{
    boxed_local_async_stream, ActionError, ActionResult, LocalAsyncStreamOutput, StreamOutput,
};
use rurr_core::state::State;

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
pub fn sync_typed(_state: &State, amount: i64) -> Result<ActionResult, ActionError> {
    let _ = amount;
    Ok(ActionResult::new(Default::default(), Default::default()))
}

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
pub async fn async_action(_state: &State) -> Result<ActionResult, ActionError> {
    Ok(ActionResult::new(Default::default(), Default::default()))
}

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
pub async fn async_stream(
    _state: &State,
) -> LocalAsyncStreamOutput {
    boxed_local_async_stream(::rurr_core::common::async_utils::asyncify_iter(
        ::std::iter::empty::<StreamOutput>(),
    ))
}

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
pub fn sync_stream(
    _state: &State,
) -> Box<dyn Iterator<Item = StreamOutput>> {
    Box::new(::std::iter::empty::<StreamOutput>())
}
"#;
    fs::write(project_dir.join("src/lib.rs"), source).expect("source should be written");

    let status = Command::new("cargo")
        .args(["check", "-q", "--offline"])
        .current_dir(&project_dir)
        .status()
        .expect("cargo check should run");

    assert!(status.success(), "minimal consumer compilation should pass");
}
