use rurr_core::lifecycle::{
    ExecuteCallContext, LifecycleError, PostStepContext, PreStepContext, SpanContext,
};

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) enum OtelContextGuardKey {
    Step(StepKey),
    Span(ActiveSpanKey),
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub(super) struct ActionRootKey {
    pub(super) app_id: String,
    pub(super) sequence_id: u64,
}

impl ActionRootKey {
    pub(super) fn new(app_id: impl Into<String>, sequence_id: u64) -> Self {
        Self {
            app_id: app_id.into(),
            sequence_id,
        }
    }

    pub(super) fn from_execute(context: &ExecuteCallContext) -> Self {
        Self::new(context.app_id(), context.sequence_id())
    }

    pub(super) fn from_optional(
        app_id: Option<&str>,
        sequence_id: u64,
        action_name: &str,
    ) -> Result<Self, LifecycleError> {
        app_id
            .map(|app_id| Self::new(app_id, sequence_id))
            .ok_or_else(|| {
                LifecycleError::hook_failed(
                    "otel_required_attributes",
                    format!(
                        "missing execution app id for sequence {sequence_id} action {action_name}"
                    ),
                )
            })
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub(super) struct ActiveSpanKey {
    pub(super) app_id: Option<String>,
    pub(super) sequence_id: u64,
    pub(super) span_id: String,
}

impl ActiveSpanKey {
    fn new(context: &SpanContext, span_id: impl Into<String>) -> Self {
        Self {
            app_id: context.app_id().map(str::to_string),
            sequence_id: context.sequence_id(),
            span_id: span_id.into(),
        }
    }

    pub(super) fn from_context(context: &SpanContext) -> Self {
        Self::new(context, context.span_id())
    }

    pub(super) fn from_parent(context: &SpanContext, parent_span_id: &str) -> Self {
        Self::new(context, parent_span_id)
    }

    pub(super) fn describe(&self) -> String {
        format!(
            "app {:?} sequence {} span {}",
            self.app_id, self.sequence_id, self.span_id
        )
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub(super) struct StepKey {
    pub(super) app_id: String,
    pub(super) sequence_id: u64,
    pub(super) step_id: u64,
}

impl StepKey {
    fn from_parts(app_id: Option<&str>, sequence_id: u64, step_id: u64) -> Option<Self> {
        app_id.map(|app_id| Self {
            app_id: app_id.to_string(),
            sequence_id,
            step_id,
        })
    }

    pub(super) fn from_pre(context: &PreStepContext) -> Option<Self> {
        Self::from_parts(context.app_id(), context.sequence_id(), context.step_id())
    }

    pub(super) fn from_post(context: &PostStepContext) -> Option<Self> {
        Self::from_parts(context.app_id(), context.sequence_id(), context.step_id())
    }
}
