use super::*;
use super::{assertions::*, fixtures::*, graphs::*};

#[test]
fn parallel_actions_expose_no_reserved_optional_inputs() {
    let child_graph = runnable_graph_from_action(
        "child",
        FunctionActionBuilder::new()
            .writes(["value"])
            .build_sync(|_state, _ctx| map_from_pairs([("value", json!(1))]))
            .expect("action should build"),
    );

    let map_actions = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![child_graph.clone()],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        Vec::new(),
        Vec::new(),
        Vec::new(),
        CascadeMode::None,
    );
    assert!(map_actions.optional_inputs().is_empty());

    let map_states = ParallelMap::new(
        ParallelTaskSource::states(
            child_graph.clone(),
            Arc::new(|_state: &State, _ctx: &ActionContext| Ok(vec![State::default()])),
        ),
        Vec::new(),
        Vec::new(),
        Vec::new(),
        CascadeMode::None,
    );
    assert!(map_states.optional_inputs().is_empty());

    let map_actions_and_states = ParallelMap::new(
        ParallelTaskSource::pairs(Arc::new(move |_state, _ctx| {
            Ok(vec![(child_graph.clone(), State::default())])
        })),
        Vec::new(),
        Vec::new(),
        Vec::new(),
        CascadeMode::None,
    );
    assert!(map_actions_and_states.optional_inputs().is_empty());
}

#[test]
fn all_parallel_map_actions_share_missing_parent_sequence_id_errors_sync() {
    let child_graph = runnable_graph_from_action(
        "child",
        FunctionActionBuilder::new()
            .writes(["value"])
            .build_sync(|_state, _ctx| map_from_pairs([("value", json!(1))]))
            .expect("action should build"),
    );

    assert_parallel_action_missing_parent_sequence_id_sync(
        "parallel_map_actions_sync",
        ParallelMap::new(
            ParallelTaskSource::graphs(
                vec![child_graph.clone()],
                Arc::new(|state, _ctx| Ok(state.clone())),
            ),
            vec![],
            vec![],
            vec![],
            CascadeMode::None,
        ),
    );
    assert_parallel_action_missing_parent_sequence_id_sync(
        "parallel_map_states_sync",
        ParallelMap::new(
            ParallelTaskSource::states(
                child_graph.clone(),
                Arc::new(|_state, _ctx| Ok(vec![State::default()])),
            ),
            vec![],
            vec![],
            vec![],
            CascadeMode::None,
        ),
    );
    assert_parallel_action_missing_parent_sequence_id_sync(
        "parallel_map_actions_and_states_sync",
        ParallelMap::new(
            ParallelTaskSource::pairs(Arc::new(move |_state, _ctx| {
                Ok(vec![(child_graph.clone(), State::default())])
            })),
            vec![],
            vec![],
            vec![],
            CascadeMode::None,
        ),
    );
}

#[tokio::test]
async fn all_parallel_map_actions_share_missing_parent_sequence_id_errors_async() {
    let child_graph = runnable_graph_from_action(
        "child",
        FunctionActionBuilder::new()
            .writes(["value"])
            .build_sync(|_state, _ctx| map_from_pairs([("value", json!(1))]))
            .expect("action should build"),
    );

    assert_parallel_action_missing_parent_sequence_id_async(
        "parallel_map_actions_async",
        ParallelMap::new(
            ParallelTaskSource::graphs(
                vec![child_graph.clone()],
                Arc::new(|state, _ctx| Ok(state.clone())),
            ),
            vec![],
            vec![],
            vec![],
            CascadeMode::None,
        ),
    )
    .await;
    assert_parallel_action_missing_parent_sequence_id_async(
        "parallel_map_states_async",
        ParallelMap::new(
            ParallelTaskSource::states(
                child_graph.clone(),
                Arc::new(|_state, _ctx| Ok(vec![State::default()])),
            ),
            vec![],
            vec![],
            vec![],
            CascadeMode::None,
        ),
    )
    .await;
    assert_parallel_action_missing_parent_sequence_id_async(
        "parallel_map_actions_and_states_async",
        ParallelMap::new(
            ParallelTaskSource::pairs(Arc::new(move |_state, _ctx| {
                Ok(vec![(child_graph.clone(), State::default())])
            })),
            vec![],
            vec![],
            vec![],
            CascadeMode::None,
        ),
    )
    .await;
}

#[test]
fn map_actions_merges_three_graphs_same_state() {
    let graphs = three_constant_output_sync_child_graphs(("g1", 111), ("g2", 211), ("g3", 311));

    let reducer = Arc::new(|states: Vec<State>| -> Result<State, ApplicationError> {
        Ok(state_from_pairs([(
            "merged_outputs",
            Value::Array(
                states
                    .iter()
                    .map(|state| state.get("output").cloned().expect("output should exist"))
                    .collect(),
            ),
        )]))
    });

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec!["merged_outputs".to_string()],
        vec![],
        CascadeMode::Fixed(reducer),
    );

    let mut app = build_single_action_app(
        state_from_pairs([("seed", json!(1))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        output.state.get("merged_outputs"),
        Some(&json!([111, 211, 311]))
    );
}

#[test]
fn map_states_merges_one_graph_over_three_states() {
    let graph = runnable_graph_from_action(
        "adder",
        FunctionActionBuilder::new()
            .reads(["input"])
            .writes(["output"])
            .build_sync(|state, _ctx| {
                let value = state
                    .get("input")
                    .and_then(Value::as_i64)
                    .expect("input should be an i64");
                map_from_pairs([("output", json!(value + 10))])
            })
            .expect("action should build"),
    );

    let splitter = Arc::new(
        |state: &State, _ctx: &ActionContext| -> Result<Vec<State>, ApplicationError> {
            let inputs = state
                .get("inputs")
                .and_then(Value::as_array)
                .ok_or_else(|| app_error("inputs must be an array"))?;
            Ok(inputs
                .iter()
                .map(|value| State::new(IndexMap::from([("input".to_string(), value.clone())])))
                .collect())
        },
    );

    let reducer = Arc::new(|states: Vec<State>| -> Result<State, ApplicationError> {
        Ok(state_from_pairs([(
            "merged_outputs",
            Value::Array(
                states
                    .iter()
                    .map(|state| state.get("output").cloned().expect("output should exist"))
                    .collect(),
            ),
        )]))
    });

    let action = ParallelMap::new(
        ParallelTaskSource::states(graph, splitter),
        vec!["inputs".to_string()],
        vec!["merged_outputs".to_string()],
        vec![],
        CascadeMode::Fixed(reducer),
    );

    let mut app = build_single_action_app(
        state_from_pairs([("inputs", json!([101, 201, 301]))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        output.state.get("merged_outputs"),
        Some(&json!([111, 211, 311]))
    );
}

#[test]
fn map_actions_and_states_merges_three_pairs() {
    let make_graph = |name: &'static str, delta: i64| {
        runnable_graph_from_action(
            name,
            FunctionActionBuilder::new()
                .reads(["base"])
                .writes(["output"])
                .build_sync(move |state, _ctx| {
                    let base = state
                        .get("base")
                        .and_then(Value::as_i64)
                        .expect("base should be an i64");
                    map_from_pairs([("output", json!(base + delta))])
                })
                .expect("action should build"),
        )
    };

    let action = ParallelMap::new(
        ParallelTaskSource::pairs(Arc::new(move |_state, _ctx| {
            Ok(vec![
                (
                    make_graph("g1", 10),
                    state_from_pairs([("base", json!(100))]),
                ),
                (
                    make_graph("g2", 20),
                    state_from_pairs([("base", json!(200))]),
                ),
                (
                    make_graph("g3", 30),
                    state_from_pairs([("base", json!(300))]),
                ),
            ])
        })),
        vec!["base".to_string()],
        vec!["merged_outputs".to_string()],
        vec![],
        CascadeMode::Fixed(Arc::new(|states: Vec<State>| {
            Ok(state_from_pairs([(
                "merged_outputs",
                Value::Array(
                    states
                        .iter()
                        .map(|state| state.get("output").cloned().expect("output should exist"))
                        .collect(),
                ),
            )]))
        })),
    );

    let mut app = build_single_action_app(
        state_from_pairs([("seed", json!(1))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        output.state.get("merged_outputs"),
        Some(&json!([110, 220, 330]))
    );
}

#[test]
fn map_actions_state_mapper_reads_runtime_inputs() {
    let graphs = vec![runnable_graph_from_action(
        "child_map_actions_inputs",
        FunctionActionBuilder::new()
            .reads(["input_number", "number_to_add"])
            .writes(["output_number"])
            .build_sync(|state, _ctx| {
                let input = state
                    .get("input_number")
                    .and_then(Value::as_i64)
                    .expect("input_number should be present");
                let to_add = state
                    .get("number_to_add")
                    .and_then(Value::as_i64)
                    .expect("number_to_add should be present");
                map_from_pairs([("output_number", json!(input + to_add))])
            })
            .expect("action should build"),
    )];

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            graphs,
            Arc::new(|state: &State, ctx: &ActionContext| {
                let to_add = ctx
                    .inputs
                    .get("number_to_add")
                    .and_then(Value::as_i64)
                    .expect("runtime input number_to_add should be present");
                let input_number = state
                    .get("input_number")
                    .cloned()
                    .expect("input_number should be present");
                Ok(state_from_pairs([
                    ("input_number", input_number),
                    ("number_to_add", json!(to_add)),
                ]))
            }),
        ),
        vec!["input_number".to_string()],
        vec!["output_number".to_string()],
        vec!["number_to_add".to_string()],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("input_number", json!(100))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(Some(IndexMap::from([(
            "number_to_add".to_string(),
            json!(10),
        )])))
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        child_i64_values_in_state(&step.state, "output_number"),
        vec![110]
    );
}

#[test]
fn map_states_splitter_reads_runtime_inputs() {
    let graph = runnable_graph_from_action(
        "child_map_states_inputs",
        FunctionActionBuilder::new()
            .reads(["input_number", "number_to_add"])
            .writes(["output_number"])
            .build_sync(|state, _ctx| {
                let input = state
                    .get("input_number")
                    .and_then(Value::as_i64)
                    .expect("input_number should be present");
                let to_add = state
                    .get("number_to_add")
                    .and_then(Value::as_i64)
                    .expect("number_to_add should be present");
                map_from_pairs([("output_number", json!(input + to_add))])
            })
            .expect("action should build"),
    );

    let action = ParallelMap::new(
        ParallelTaskSource::states(
            graph,
            Arc::new(|state: &State, ctx: &ActionContext| {
                let to_add = ctx
                    .inputs
                    .get("number_to_add")
                    .and_then(Value::as_i64)
                    .expect("runtime input number_to_add should be present");
                let numbers = state
                    .get("input_numbers")
                    .and_then(Value::as_array)
                    .expect("input_numbers should be an array");
                Ok(numbers
                    .iter()
                    .map(|number| {
                        state_from_pairs([
                            (
                                "input_number",
                                json!(number.as_i64().expect("input number should be an integer")),
                            ),
                            ("number_to_add", json!(to_add)),
                        ])
                    })
                    .collect())
            }),
        ),
        vec!["input_numbers".to_string()],
        vec!["child_states".to_string()],
        vec!["number_to_add".to_string()],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("input_numbers", json!([100, 200, 300]))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(Some(IndexMap::from([(
            "number_to_add".to_string(),
            json!(10),
        )])))
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        child_i64_values_in_state(&step.state, "output_number"),
        vec![110, 210, 310]
    );
}

#[test]
fn map_actions_and_states_pair_builder_reads_runtime_inputs() {
    let child_graph = runnable_graph_from_action(
        "child_map_actions_and_states_inputs",
        FunctionActionBuilder::new()
            .reads(["input_number", "number_to_add"])
            .writes(["output_number"])
            .build_sync(|state, _ctx| {
                let input = state
                    .get("input_number")
                    .and_then(Value::as_i64)
                    .expect("input_number should be present");
                let to_add = state
                    .get("number_to_add")
                    .and_then(Value::as_i64)
                    .expect("number_to_add should be present");
                map_from_pairs([("output_number", json!(input + to_add))])
            })
            .expect("action should build"),
    );

    let action = ParallelMap::new(
        ParallelTaskSource::pairs(Arc::new(move |state: &State, ctx: &ActionContext| {
            let to_add = ctx
                .inputs
                .get("number_to_add")
                .and_then(Value::as_i64)
                .expect("runtime input number_to_add should be present");
            let numbers = state
                .get("input_numbers")
                .and_then(Value::as_array)
                .expect("input_numbers should be an array");
            Ok(numbers
                .iter()
                .map(|number| {
                    (
                        child_graph.clone(),
                        state_from_pairs([
                            (
                                "input_number",
                                json!(number.as_i64().expect("input number should be an integer")),
                            ),
                            ("number_to_add", json!(to_add)),
                        ]),
                    )
                })
                .collect())
        })),
        vec!["input_numbers".to_string()],
        vec!["child_states".to_string()],
        vec!["number_to_add".to_string()],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("input_numbers", json!([100, 200, 300]))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(Some(IndexMap::from([(
            "number_to_add".to_string(),
            json!(10),
        )])))
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        child_i64_values_in_state(&step.state, "output_number"),
        vec![110, 210, 310]
    );
}

#[test]
fn sync_parallel_execution_is_sequential_and_ordered() {
    let call_order = Arc::new(Mutex::new(Vec::<String>::new()));

    let make_graph = |name: &'static str, output: i64, order: Arc<Mutex<Vec<String>>>| {
        runnable_graph_from_action(
            name,
            FunctionActionBuilder::new()
                .writes(["output"])
                .build_sync(move |_state, _ctx| {
                    order
                        .lock()
                        .expect("order lock should not be poisoned")
                        .push(name.to_string());
                    map_from_pairs([("output", json!(output))])
                })
                .expect("action should build"),
        )
    };

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![
                make_graph("first", 1, Arc::clone(&call_order)),
                make_graph("second", 2, Arc::clone(&call_order)),
                make_graph("third", 3, Arc::clone(&call_order)),
            ],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        *call_order
            .lock()
            .expect("order lock should not be poisoned"),
        vec![
            "first".to_string(),
            "second".to_string(),
            "third".to_string(),
        ]
    );
    assert!(
        step.result.is_empty(),
        "CascadeMode::None should emit an empty result map for Burr parity"
    );
    let outputs = step
        .state
        .get("child_states")
        .and_then(Value::as_array)
        .expect("state.child_states should be present")
        .iter()
        .map(|child| {
            child
                .as_object()
                .and_then(|object| object.get("output"))
                .and_then(Value::as_i64)
                .expect("child output should be present")
        })
        .collect::<Vec<_>>();
    assert_eq!(outputs, vec![1, 2, 3]);
}

#[tokio::test]
async fn async_parallel_execution_is_concurrent_via_join_all_and_ordered() {
    let make_graph = |name: &'static str, output: i64| {
        runnable_graph_from_action(
            name,
            FunctionActionBuilder::new()
                .writes(["output"])
                .build_async(move |_state, _ctx| async move {
                    sleep(Duration::from_millis(100)).await;
                    map_from_pairs([("output", json!(output))])
                })
                .expect("action should build"),
        )
    };

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![
                make_graph("first_async", 1),
                make_graph("second_async", 2),
                make_graph("third_async", 3),
            ],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );

    let mut app = build_single_action_app(
        State::default(),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let start = Instant::now();
    let step = app
        .astep(None)
        .await
        .expect("astep should succeed")
        .expect("astep should execute");
    let elapsed = start.elapsed();

    assert!(
        elapsed < Duration::from_millis(220),
        "expected concurrent execution, elapsed={elapsed:?}"
    );
    assert!(
        step.result.is_empty(),
        "CascadeMode::None should emit an empty result map for Burr parity"
    );
    let outputs = step
        .state
        .get("child_states")
        .and_then(Value::as_array)
        .expect("state.child_states should be present")
        .iter()
        .map(|child| {
            child
                .as_object()
                .and_then(|object| object.get("output"))
                .and_then(Value::as_i64)
                .expect("child output should be present")
        })
        .collect::<Vec<_>>();
    assert_eq!(outputs, vec![1, 2, 3]);
}
