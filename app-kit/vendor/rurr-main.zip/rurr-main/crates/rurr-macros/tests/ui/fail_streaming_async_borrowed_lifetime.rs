use futures::stream::unfold;
use futures::stream::BoxStream;
use futures::StreamExt;
use rurr_core::action::StreamOutput;
use rurr_core::state::State;

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
async fn borrowed_async_stream_lifetime<'a>(state: &'a State) -> BoxStream<'a, StreamOutput> {
    unfold((), move |_| async move {
        let _ = state.get("count");
        None::<(StreamOutput, ())>
    })
    .boxed()
}

fn main() {}
