use super::{LifecycleError, PostStepContext, PreStepContext, SyncLifecycleAdapter};
use indexmap::IndexMap;
use rurr_persistence::wire::sortable_rfc3339_utc_string;
use rurr_tracking_store::jsonl::JsonlWriter;
use serde::Serialize;
use serde_json::Value;
use std::fs::{File, OpenOptions};
use std::io::{self, Write};
use std::sync::Mutex;
use std::thread;
use std::time::{Duration, SystemTime};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
/// File opening mode for the full state/results logger.
pub enum StateAndResultsLogMode {
    /// Append new records to the existing log file.
    #[default]
    Append,
    /// Truncate the existing log file before writing.
    Truncate,
}

#[derive(Debug)]
/// Lifecycle hook that writes one JSONL record per completed step.
///
/// Each record contains the action name, optional result, optional exception,
/// timing data, and the committed post-step state. If a lifecycle context is
/// missing that committed state, the hook returns an error rather than writing
/// a synthetic empty state.
///
/// # Examples
///
/// ```
/// use std::time::SystemTime;
///
/// use indexmap::IndexMap;
/// use rurr_core::{
///     PostStepContext, State, StateAndResultsFullLogger, StateAndResultsLogMode,
///     SyncLifecycleAdapter,
/// };
/// use serde_json::json;
///
/// let path = std::env::temp_dir()
///     .join(format!("rurr-state-results-doc-{}.jsonl", std::process::id()));
/// let _ = std::fs::remove_file(&path);
///
/// let logger = StateAndResultsFullLogger::new(path.clone(), StateAndResultsLogMode::Truncate)?;
/// let context = PostStepContext::new("count", 1, 1, SystemTime::now())
///     .with_state(State::new(IndexMap::from([("count".to_string(), json!(1))])));
/// logger.post_run_step(&context)?;
///
/// let payload = std::fs::read_to_string(&path)?;
/// assert!(payload.contains("\"action\":\"count\""));
/// assert!(payload.contains("\"count\":1"));
/// let _ = std::fs::remove_file(&path);
/// # Ok::<(), Box<dyn std::error::Error + Send + Sync>>(())
/// ```
pub struct StateAndResultsFullLogger {
    file: Mutex<File>,
}

#[derive(Debug, Serialize)]
struct StateAndResultsRecord {
    state: IndexMap<String, Value>,
    action: String,
    result: Option<IndexMap<String, Value>>,
    exception: Option<String>,
    start_time: String,
    end_time: String,
}

impl StateAndResultsFullLogger {
    /// Creates a new full logger backed by a `.jsonl` file.
    pub fn new(
        path: impl Into<std::path::PathBuf>,
        mode: StateAndResultsLogMode,
    ) -> io::Result<Self> {
        let jsonl_path = path.into();
        if jsonl_path.extension().and_then(|ext| ext.to_str()) != Some("jsonl") {
            return Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!(
                    "jsonl_path must end with .jsonl. Got: {}",
                    jsonl_path.display()
                ),
            ));
        }

        let mut options = OpenOptions::new();
        options.create(true).read(true);
        match mode {
            StateAndResultsLogMode::Append => {
                options.append(true);
            }
            StateAndResultsLogMode::Truncate => {
                options.write(true);
                options.truncate(true);
            }
        }

        let file = options.open(&jsonl_path)?;
        Ok(Self {
            file: Mutex::new(file),
        })
    }

    fn timestamp_string(
        timestamp: SystemTime,
        operation: &'static str,
    ) -> Result<String, LifecycleError> {
        sortable_rfc3339_utc_string(timestamp)
            .map_err(|error| LifecycleError::hook_failed(operation, error.to_string()))
    }
}

impl SyncLifecycleAdapter for StateAndResultsFullLogger {
    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        let end_time = SystemTime::now();
        let state = context.require_state_for("post_run_step", "state/results logger")?;
        let record = StateAndResultsRecord {
            state: state.get_all(),
            action: context.action_name().to_string(),
            result: context.result().cloned(),
            exception: context.exception().map(str::to_string),
            start_time: Self::timestamp_string(context.started_at(), "post_run_step")?,
            end_time: Self::timestamp_string(end_time, "post_run_step")?,
        };

        let mut file = self.file.lock().map_err(|_| {
            LifecycleError::hook_failed("post_run_step", "logger file lock poisoned")
        })?;
        {
            let mut writer = JsonlWriter::new(&mut file).map_err(|error| {
                LifecycleError::hook_failed(
                    "post_run_step",
                    format!("initialize state/results jsonl writer: {error}"),
                )
            })?;
            writer.write_value(&record).map_err(|error| {
                LifecycleError::hook_failed(
                    "post_run_step",
                    format!("write state/results log: {error}"),
                )
            })?;
        }
        file.flush().map_err(|error| {
            LifecycleError::hook_failed(
                "post_run_step",
                format!("flush state/results log: {error}"),
            )
        })?;
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Lifecycle hook that sleeps before and after each step.
pub struct SlowDownHook {
    pre_sleep: Duration,
    post_sleep: Duration,
}

impl SlowDownHook {
    /// Creates a hook with explicit pre-step and post-step sleep durations.
    pub fn new(pre_sleep: Duration, post_sleep: Duration) -> Self {
        Self {
            pre_sleep,
            post_sleep,
        }
    }
}

impl Default for SlowDownHook {
    fn default() -> Self {
        Self::new(Duration::from_millis(500), Duration::from_millis(500))
    }
}

impl SyncLifecycleAdapter for SlowDownHook {
    fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        thread::sleep(self.pre_sleep);
        Ok(())
    }

    fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        thread::sleep(self.post_sleep);
        Ok(())
    }
}
