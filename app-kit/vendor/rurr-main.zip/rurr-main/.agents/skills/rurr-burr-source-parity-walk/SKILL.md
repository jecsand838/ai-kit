---
name: rurr-burr-source-parity-walk
description: "Use when comparing a Rurr subsystem or behavior against vendored Apache Burr source, oracle artifacts, and compatibility docs before deciding what may safely change."
---

# Rurr Burr Source Parity Walk

Use this skill when the user needs a source-backed Rurr versus Burr comparison before a parity-sensitive refactor, cleanup, or bug fix.

## Quick start

Load, in order:

- `README.md`
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- the relevant Rurr tests, oracle fixtures, or goldens for the subsystem
- the matching Burr source under `tools/burr_oracle/vendor/apache-burr/`

Load these companion skills:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`

Add these only when the compared subsystem needs them:

- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-dependencies-platforms`

## When to use

Use it when the task:

- asks how a Rurr subsystem maps to vendored Burr before a refactor
- asks what behavior is parity-critical versus internally simplifiable
- needs the current Rurr tests, docs, and Burr source reconciled before planning
- asks whether a proposed cleanup would still align with Burr behavior

## Workflow

1. Pin the Rurr subsystem behavior using the current docs, tests, or goldens.
2. Inspect the matching Burr source and any oracle evidence for the same behavior.
3. Separate parity-critical invariants from Rurr-specific internal layering.
4. Identify the safe simplification space without violating guardrails or oracle expectations.
5. Cite the specific Rurr and Burr files or tests that support the conclusion.

## Output contract

Return:

- the current Rurr behavior being compared
- the corresponding Burr behavior or source shape
- the parity-critical invariants that must stay fixed
- the safe simplification or refactor space that remains
- the cited Rurr and Burr files, tests, or goldens that support the answer

## Default rules

- Prefer evidence from current tests, goldens, and source over vague architectural memory.
- Treat `docs/ARCHITECTURE_GUARDRAILS.md` and the compatibility docs as the behavioral boundary for any recommendation.
- Do not treat internal structural similarity to Burr as required unless tests, docs, or source behavior make it required.
- Call out uncertainty explicitly when Rurr and Burr evidence do not line up cleanly.

## Do not use this skill alone when

- the user wants a workspace-wide or subsystem-wide reduction ranking first: also use `$rurr-burr-parity-reduction-audit`
- the user wants a decision-complete implementation plan: also use `$rurr-delete-first-refactor-plan`
- the user wants a residual next-pass plan after partial cleanup: also use `$rurr-follow-up-reduction-pass`
- the user wants implementation rather than comparison: also use `$rurr-delete-first-refactor-plan` in implementation mode
- the user only needs gate selection and final closeout: also use `$rurr-gate-closeout`
