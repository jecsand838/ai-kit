mod support;

use axum::body::Body;
use axum::http::{Request, StatusCode};
use rurr_testkit::workspace_fixture::with_locked_current_dir_async;
use rurr_tracking_server::backend::local::LocalBackend;
use rurr_tracking_server::router::AppState;
use std::fs;
use std::path::Path;
use std::sync::Arc;
use support::response_text::response_text;
use tower::ServiceExt;

fn seed_directory_ui(ui_dir: &Path, index_html: &str, assets: &[(&str, &str)]) {
    fs::create_dir_all(ui_dir).expect("ui dir should be created");
    fs::write(ui_dir.join("index.html"), index_html).expect("index should be written");
    for (relative_path, contents) in assets {
        let asset_path = ui_dir.join(relative_path);
        if let Some(parent) = asset_path.parent() {
            fs::create_dir_all(parent).expect("asset parent dir should be created");
        }
        fs::write(&asset_path, contents).expect("asset file should be written");
    }
}

fn directory_ui_app(storage_root: &Path, ui_dir: &Path) -> axum::Router {
    rurr_tracking_server::app_with_state(
        AppState::with_ui_dir(
            Arc::new(LocalBackend::new(storage_root).expect("local backend should build")),
            ui_dir,
        )
        .expect("ui directory state should configure"),
    )
}

async fn ui_response(app: &axum::Router, uri: &str) -> (StatusCode, String) {
    let response = app
        .clone()
        .oneshot(Request::builder().uri(uri).body(Body::empty()).unwrap())
        .await
        .expect("request should succeed");
    let status = response.status();
    let body = response_text(response).await;
    (status, body)
}

#[cfg(unix)]
#[derive(Clone, Copy)]
enum DirectoryUiAssetMutationCase {
    SymlinkedFileEscape,
    SymlinkedAssetsRootEscape,
    LeafSwap,
    AssetsRootSwap,
    SamePathAssetsReplacement,
    DeletedAssetsRoot,
}

#[cfg(unix)]
async fn assert_directory_ui_asset_mutation_case(case: DirectoryUiAssetMutationCase) {
    use std::os::unix::fs as unix_fs;

    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let ui_dir = tempfile::tempdir().expect("ui tempdir should be created");
    let assets_dir = ui_dir.path().join("assets");

    match case {
        DirectoryUiAssetMutationCase::SymlinkedFileEscape => {
            seed_directory_ui(ui_dir.path(), "<html>ok</html>", &[("assets/.keep", "")]);
        }
        DirectoryUiAssetMutationCase::SymlinkedAssetsRootEscape => {
            seed_directory_ui(ui_dir.path(), "<html>ok</html>", &[]);
        }
        DirectoryUiAssetMutationCase::LeafSwap
        | DirectoryUiAssetMutationCase::AssetsRootSwap
        | DirectoryUiAssetMutationCase::SamePathAssetsReplacement
        | DirectoryUiAssetMutationCase::DeletedAssetsRoot => {
            seed_directory_ui(
                ui_dir.path(),
                "<html>ok</html>",
                &[("assets/js/app.js", "console.log('safe');")],
            );
        }
    }

    let (app, uri, leaked_contents) = match case {
        DirectoryUiAssetMutationCase::SymlinkedFileEscape => {
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            let marker = "LEAK_MARKER_SHOULD_NOT_BE_EXPOSED";
            let secret_path = outside_dir.path().join("secret.txt");
            fs::write(&secret_path, marker).expect("secret file should be written");
            unix_fs::symlink(&secret_path, assets_dir.join("leak.txt"))
                .expect("symlink should be created");
            (
                directory_ui_app(storage_dir.path(), ui_dir.path()),
                "/assets/leak.txt",
                Some(marker),
            )
        }
        DirectoryUiAssetMutationCase::SymlinkedAssetsRootEscape => {
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            fs::write(outside_dir.path().join("secret.txt"), "secret")
                .expect("secret file should be written");
            unix_fs::symlink(outside_dir.path(), &assets_dir)
                .expect("assets symlink should be created");
            (
                directory_ui_app(storage_dir.path(), ui_dir.path()),
                "/assets/secret.txt",
                None,
            )
        }
        DirectoryUiAssetMutationCase::LeafSwap => {
            let app = directory_ui_app(storage_dir.path(), ui_dir.path());
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            let marker = "LEAF_SWAP_MARKER_SHOULD_NOT_BE_EXPOSED";
            let leaked_asset = outside_dir.path().join("app.js");
            fs::write(&leaked_asset, marker).expect("outside asset should be written");
            let asset_path = assets_dir.join("js").join("app.js");
            fs::remove_file(&asset_path).expect("safe asset should be removed");
            unix_fs::symlink(&leaked_asset, &asset_path).expect("asset symlink should be created");
            (app, "/assets/js/app.js", Some(marker))
        }
        DirectoryUiAssetMutationCase::AssetsRootSwap => {
            let app = directory_ui_app(storage_dir.path(), ui_dir.path());
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            let marker = "ASSET_ROOT_SWAP_MARKER_SHOULD_NOT_BE_EXPOSED";
            fs::create_dir_all(outside_dir.path().join("js")).expect("outside js dir should exist");
            fs::write(outside_dir.path().join("js").join("app.js"), marker)
                .expect("outside asset should be written");
            let moved_assets_dir = ui_dir.path().join("assets-real");
            fs::rename(&assets_dir, &moved_assets_dir).expect("assets dir should move away");
            unix_fs::symlink(outside_dir.path(), &assets_dir)
                .expect("assets-root symlink replacement should be created");
            (app, "/assets/js/app.js", Some(marker))
        }
        DirectoryUiAssetMutationCase::SamePathAssetsReplacement => {
            let app = directory_ui_app(storage_dir.path(), ui_dir.path());
            let marker = "ASSETS_REPLACEMENT_MARKER_SHOULD_NOT_BE_EXPOSED";
            let moved_assets_dir = ui_dir.path().join("assets-real");
            fs::rename(&assets_dir, &moved_assets_dir).expect("assets dir should move away");
            fs::create_dir_all(assets_dir.join("js")).expect("replacement assets dir should exist");
            fs::write(assets_dir.join("js").join("app.js"), marker)
                .expect("replacement asset should write");
            (app, "/assets/js/app.js", Some(marker))
        }
        DirectoryUiAssetMutationCase::DeletedAssetsRoot => {
            let app = directory_ui_app(storage_dir.path(), ui_dir.path());
            fs::remove_file(assets_dir.join("js").join("app.js")).expect("asset should be removed");
            fs::remove_dir(assets_dir.join("js")).expect("nested assets dir should be removed");
            fs::remove_dir(&assets_dir).expect("assets dir should be removed");
            (app, "/assets/app.js", None)
        }
    };

    let (status, body) = ui_response(&app, uri).await;
    assert_eq!(status, StatusCode::BAD_REQUEST);
    if matches!(case, DirectoryUiAssetMutationCase::SymlinkedFileEscape) {
        assert!(
            body.contains("\"error\""),
            "error response should be json: {body}"
        );
    }
    if let Some(marker) = leaked_contents {
        assert!(
            !body.contains(marker),
            "asset response must not expose swapped content: {body}"
        );
    }
}

#[cfg(unix)]
#[derive(Clone, Copy)]
enum DirectoryUiRootMutationCase {
    DeletedRoot,
    SamePathRootReplacement,
    IndexSymlinkSwap,
    FallbackIndexAliasSwap,
    ParentDirectorySwap,
}

#[cfg(unix)]
#[derive(Clone, Copy)]
enum DirectoryUiInvalidIndexCase {
    SymlinkEscape,
    SameRootAlias,
}

#[cfg(unix)]
async fn assert_directory_ui_root_mutation_case(case: DirectoryUiRootMutationCase) {
    use std::os::unix::fs as unix_fs;

    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let root = tempfile::tempdir().expect("root tempdir should be created");
    let ui_dir = root.path().join("ui");
    match case {
        DirectoryUiRootMutationCase::DeletedRoot => {
            seed_directory_ui(
                &ui_dir,
                "<html>safe</html>",
                &[("assets/app.js", "console.log('safe');")],
            );
        }
        DirectoryUiRootMutationCase::SamePathRootReplacement => {
            seed_directory_ui(
                &ui_dir,
                "<html>safe</html>",
                &[("assets/app.js", "console.log('safe');")],
            );
        }
        DirectoryUiRootMutationCase::IndexSymlinkSwap => {
            seed_directory_ui(&ui_dir, "<html>safe</html>", &[]);
        }
        DirectoryUiRootMutationCase::FallbackIndexAliasSwap => {
            fs::create_dir_all(&ui_dir).expect("ui dir should be created");
            seed_directory_ui(&ui_dir, "<html>safe</html>", &[]);
        }
        DirectoryUiRootMutationCase::ParentDirectorySwap => {
            seed_directory_ui(&ui_dir, "<html>safe</html>", &[]);
        }
    }

    let app = directory_ui_app(storage_dir.path(), &ui_dir);
    let mut leaked_contents = None;
    let uri = match case {
        DirectoryUiRootMutationCase::DeletedRoot => {
            fs::remove_file(ui_dir.join("assets").join("app.js")).expect("asset should be removed");
            fs::remove_file(ui_dir.join("index.html")).expect("index should be removed");
            fs::remove_dir(ui_dir.join("assets")).expect("assets dir should be removed");
            fs::remove_dir(&ui_dir).expect("ui dir should be removed");
            "/"
        }
        DirectoryUiRootMutationCase::SamePathRootReplacement => {
            let marker = "ROOT_REPLACEMENT_MARKER_SHOULD_NOT_BE_EXPOSED";
            let moved_ui_dir = root.path().join("ui-real");
            fs::rename(&ui_dir, &moved_ui_dir).expect("ui dir should move away");
            fs::create_dir_all(ui_dir.join("assets")).expect("replacement ui dir should exist");
            fs::write(ui_dir.join("index.html"), marker).expect("replacement index should write");
            fs::write(
                ui_dir.join("assets").join("app.js"),
                "console.log('replacement');",
            )
            .expect("replacement asset should write");
            leaked_contents = Some(marker);
            "/"
        }
        DirectoryUiRootMutationCase::IndexSymlinkSwap => {
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            let marker = "LEAK_MARKER_SHOULD_NOT_BE_EXPOSED";
            let leaked_index = outside_dir.path().join("index.html");
            fs::write(&leaked_index, marker).expect("outside index should be written");
            fs::remove_file(ui_dir.join("index.html")).expect("safe index should be removed");
            unix_fs::symlink(&leaked_index, ui_dir.join("index.html"))
                .expect("index symlink should be created");
            leaked_contents = Some(marker);
            "/"
        }
        DirectoryUiRootMutationCase::FallbackIndexAliasSwap => {
            let sibling_dir = root.path().join("sibling");
            let marker = "ALIAS_MARKER_SHOULD_NOT_BE_EXPOSED";
            fs::create_dir_all(&sibling_dir).expect("sibling dir should be created");
            let sibling_index = sibling_dir.join("index.html");
            fs::write(&sibling_index, marker).expect("sibling index should be written");
            fs::remove_file(ui_dir.join("index.html")).expect("safe index should be removed");
            unix_fs::symlink(&sibling_index, ui_dir.join("index.html"))
                .expect("index alias should be created");
            leaked_contents = Some(marker);
            "/dashboard/non-existent-route"
        }
        DirectoryUiRootMutationCase::ParentDirectorySwap => {
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            let moved_ui_dir = root.path().join("ui-real");
            let marker = "PARENT_SWAP_MARKER_SHOULD_NOT_BE_EXPOSED";
            fs::write(outside_dir.path().join("index.html"), marker)
                .expect("outside index should be written");
            fs::rename(&ui_dir, &moved_ui_dir)
                .expect("ui dir should move out of the original path");
            unix_fs::symlink(outside_dir.path(), &ui_dir)
                .expect("ui dir symlink replacement should be created");
            leaked_contents = Some(marker);
            "/"
        }
    };

    let (status, body) = ui_response(&app, uri).await;
    assert_eq!(status, StatusCode::BAD_REQUEST);
    if let Some(marker) = leaked_contents {
        assert!(
            !body.contains(marker),
            "root response must not expose swapped content: {body}"
        );
    }
}

#[cfg(unix)]
fn assert_directory_ui_configuration_rejects_invalid_index(case: DirectoryUiInvalidIndexCase) {
    use std::os::unix::fs as unix_fs;

    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let error = match case {
        DirectoryUiInvalidIndexCase::SymlinkEscape => {
            let ui_dir = tempfile::tempdir().expect("ui tempdir should be created");
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            let leaked_index = outside_dir.path().join("index.html");
            fs::write(&leaked_index, "<html>escaped</html>")
                .expect("outside index should be written");
            unix_fs::symlink(&leaked_index, ui_dir.path().join("index.html"))
                .expect("index symlink should be created");
            AppState::with_ui_dir(
                Arc::new(
                    LocalBackend::new(storage_dir.path()).expect("local backend should build"),
                ),
                ui_dir.path(),
            )
        }
        DirectoryUiInvalidIndexCase::SameRootAlias => {
            let root = tempfile::tempdir().expect("root tempdir should be created");
            let ui_dir = root.path().join("ui");
            let sibling_dir = root.path().join("sibling");
            fs::create_dir_all(&ui_dir).expect("ui dir should be created");
            fs::create_dir_all(&sibling_dir).expect("sibling dir should be created");
            let sibling_index = sibling_dir.join("index.html");
            fs::write(&sibling_index, "<html>aliased</html>")
                .expect("sibling index should be written");
            unix_fs::symlink(&sibling_index, ui_dir.join("index.html"))
                .expect("index alias should be created");
            AppState::with_ui_dir(
                Arc::new(
                    LocalBackend::new(storage_dir.path()).expect("local backend should build"),
                ),
                &ui_dir,
            )
        }
    }
    .err()
    .expect("invalid index targets must fail closed");

    assert!(matches!(
        error,
        rurr_tracking_server::backend::BackendError::InvalidRequest { .. }
    ));
}

#[tokio::test]
async fn ui_root_and_spa_fallback_return_index_html_with_directory_source() {
    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let ui_dir = tempfile::tempdir().expect("ui tempdir should be created");
    let marker = "<h1>Rurr UI Contract Marker</h1>";
    let asset_marker = "console.log('Rurr UI Asset Marker');";
    seed_directory_ui(ui_dir.path(), marker, &[("assets/app.js", asset_marker)]);

    let app = directory_ui_app(storage_dir.path(), ui_dir.path());

    for uri in ["/", "/dashboard/non-existent-route"] {
        let (status, body) = ui_response(&app, uri).await;
        assert_eq!(status, StatusCode::OK);
        assert!(body.contains(marker));
    }

    let (asset_status, asset_body) = ui_response(&app, "/assets/app.js").await;
    assert_eq!(asset_status, StatusCode::OK);
    assert!(asset_body.contains(asset_marker));

    let (missing_asset_status, missing_asset_body) = ui_response(&app, "/assets/missing.js").await;
    assert_eq!(missing_asset_status, StatusCode::NOT_FOUND);
    assert!(
        !missing_asset_body.contains(marker),
        "missing asset must not be rewritten to index html"
    );
}

#[tokio::test]
async fn embedded_ui_source_serves_root_spa_and_assets() {
    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let app = rurr_tracking_server::app_with_state(AppState::with_embedded_ui(Arc::new(
        LocalBackend::new(storage_dir.path()).expect("local backend should build"),
    )));

    let (root_status, root_body) = ui_response(&app, "/").await;
    assert_eq!(root_status, StatusCode::OK);
    assert!(root_body.contains("Rurr Tracking"));
    assert!(
        !root_body.to_ascii_lowercase().contains("placeholder"),
        "embedded root must not describe itself as a placeholder"
    );
    assert!(root_body.contains("data-view=\"projects\""));
    assert!(root_body.contains("data-view=\"applications\""));
    assert!(root_body.contains("data-view=\"detail\""));

    let (fallback_status, _) = ui_response(&app, "/dashboard/non-existent-route").await;
    assert_eq!(fallback_status, StatusCode::OK);

    let (asset_status, asset_body) = ui_response(&app, "/assets/app.js").await;
    assert_eq!(asset_status, StatusCode::OK);
    assert!(
        !asset_body.contains("Rurr UI bundle booted"),
        "embedded asset must not keep the placeholder boot marker"
    );
    assert!(
        !asset_body.contains("API availability"),
        "embedded asset must not keep the old availability-check UI"
    );
    assert!(asset_body.contains("/api/v0/metadata/app_spec"));
    assert!(asset_body.contains("/api/v0/version"));
    assert!(asset_body.contains("/api/v0/projects"));
    assert!(asset_body.contains("loadAppDetail"));

    let (missing_asset_status, _) = ui_response(&app, "/assets/does-not-exist.js").await;
    assert_eq!(missing_asset_status, StatusCode::NOT_FOUND);
}

#[cfg(unix)]
#[tokio::test]
async fn absolute_ui_dir_still_configures_when_current_dir_is_deleted() {
    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let ui_dir = tempfile::tempdir().expect("ui tempdir should be created");
    let cwd_parent = tempfile::tempdir().expect("cwd parent tempdir should be created");
    let deleted_cwd = cwd_parent.path().join("deleted-cwd");
    let marker = "<html>absolute ui root</html>";
    let asset_marker = "console.log('absolute ui asset');";

    seed_directory_ui(ui_dir.path(), marker, &[("assets/app.js", asset_marker)]);

    fs::create_dir(&deleted_cwd).expect("deleted cwd should be created");
    with_locked_current_dir_async(&deleted_cwd, || async {
        fs::remove_dir(&deleted_cwd).expect("deleted cwd should be removed");
        assert!(
            std::env::current_dir().is_err(),
            "current dir should be unavailable after deletion"
        );

        let app = directory_ui_app(storage_dir.path(), ui_dir.path());

        let (root_status, root_body) = ui_response(&app, "/").await;
        assert_eq!(root_status, StatusCode::OK);
        assert!(root_body.contains(marker));

        let (asset_status, asset_body) = ui_response(&app, "/assets/app.js").await;
        assert_eq!(asset_status, StatusCode::OK);
        assert!(asset_body.contains(asset_marker));
    })
    .await;
}

#[cfg(unix)]
#[tokio::test]
async fn directory_ui_assets_reject_runtime_mutations() {
    for case in [
        DirectoryUiAssetMutationCase::SymlinkedFileEscape,
        DirectoryUiAssetMutationCase::SymlinkedAssetsRootEscape,
        DirectoryUiAssetMutationCase::LeafSwap,
        DirectoryUiAssetMutationCase::AssetsRootSwap,
        DirectoryUiAssetMutationCase::SamePathAssetsReplacement,
        DirectoryUiAssetMutationCase::DeletedAssetsRoot,
    ] {
        assert_directory_ui_asset_mutation_case(case).await;
    }
}

#[tokio::test]
async fn directory_ui_assets_missing_nested_parent_returns_not_found() {
    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let ui_dir = tempfile::tempdir().expect("ui tempdir should be created");

    seed_directory_ui(ui_dir.path(), "<html>ok</html>", &[("assets/.keep", "")]);

    let app = directory_ui_app(storage_dir.path(), ui_dir.path());

    let (status, _) = ui_response(&app, "/assets/js/app.js").await;
    assert_eq!(status, StatusCode::NOT_FOUND);
}

#[cfg(unix)]
#[tokio::test]
async fn symlinked_ui_root_serves_from_canonical_target_and_stays_pinned_after_retarget() {
    use std::os::unix::fs as unix_fs;

    let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
    let root = tempfile::tempdir().expect("root tempdir should be created");
    let requested_ui_dir = root.path().join("requested-ui");
    let real_ui_dir = root.path().join("real-ui");
    let outside_ui_dir = root.path().join("outside-ui");
    let index_marker = "<html>pinned ui</html>";
    let asset_marker = "console.log('pinned asset');";
    let outside_index_marker = "<html>outside ui</html>";
    let outside_asset_marker = "console.log('outside asset');";

    seed_directory_ui(
        &real_ui_dir,
        index_marker,
        &[("assets/app.js", asset_marker)],
    );
    seed_directory_ui(
        &outside_ui_dir,
        outside_index_marker,
        &[("assets/app.js", outside_asset_marker)],
    );
    unix_fs::symlink(&real_ui_dir, &requested_ui_dir).expect("ui root symlink should be created");

    let app = directory_ui_app(storage_dir.path(), &requested_ui_dir);

    let (root_status, root_body) = ui_response(&app, "/").await;
    assert_eq!(root_status, StatusCode::OK);
    assert!(root_body.contains(index_marker));

    let (asset_status, asset_body) = ui_response(&app, "/assets/app.js").await;
    assert_eq!(asset_status, StatusCode::OK);
    assert!(asset_body.contains(asset_marker));

    fs::remove_file(&requested_ui_dir).expect("ui root symlink should be removable");
    unix_fs::symlink(&outside_ui_dir, &requested_ui_dir).expect("ui root symlink should retarget");

    let (root_status, root_body) = ui_response(&app, "/").await;
    assert_eq!(root_status, StatusCode::OK);
    assert!(root_body.contains(index_marker));
    assert!(
        !root_body.contains(outside_index_marker),
        "root response must stay pinned to the canonical ui root"
    );

    let (asset_status, asset_body) = ui_response(&app, "/assets/app.js").await;
    assert_eq!(asset_status, StatusCode::OK);
    assert!(asset_body.contains(asset_marker));
    assert!(
        !asset_body.contains(outside_asset_marker),
        "asset response must stay pinned to the canonical ui root"
    );
}

#[cfg(unix)]
#[test]
fn directory_ui_configuration_rejects_invalid_index_targets() {
    for case in [
        DirectoryUiInvalidIndexCase::SymlinkEscape,
        DirectoryUiInvalidIndexCase::SameRootAlias,
    ] {
        assert_directory_ui_configuration_rejects_invalid_index(case);
    }
}

#[cfg(unix)]
#[tokio::test]
async fn directory_ui_root_and_fallback_requests_reject_runtime_mutations() {
    for case in [
        DirectoryUiRootMutationCase::DeletedRoot,
        DirectoryUiRootMutationCase::SamePathRootReplacement,
        DirectoryUiRootMutationCase::IndexSymlinkSwap,
        DirectoryUiRootMutationCase::FallbackIndexAliasSwap,
        DirectoryUiRootMutationCase::ParentDirectorySwap,
    ] {
        assert_directory_ui_root_mutation_case(case).await;
    }
}
