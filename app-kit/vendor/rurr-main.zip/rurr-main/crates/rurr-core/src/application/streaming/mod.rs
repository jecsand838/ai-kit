//! Streaming session internals for lazy Burr-compatible result and step
//! streaming.
//!
//! Public streaming handles keep an exclusive application borrow, resolve
//! execution settings once at startup, and apply halt controls at step
//! boundaries without buffering stream items.

use crate::action::api::StreamItem;
use crate::application::session::{ExecutionPlan, ExecutionSessionSettings};
use crate::application::{Application, ApplicationError};
use crate::lifecycle::ExecuteCallGuard;
use crate::state::State;

mod step_core;
use step_core::{AsyncStepExecution, SyncStepExecution};
mod stream_iterate;
mod stream_result;

mod completion;
mod progress;
mod step_lifecycle;
#[cfg(test)]
mod tests;

use completion::{
    combine_optional_primary_with_hook, prefer_hook_error, prefer_hook_error_over_primary,
    stream_invariant,
};
use progress::StreamProgress;
pub(crate) use stream_iterate::{astream_iterate, stream_iterate};
pub use stream_iterate::{
    AStreamIterate, AStreamStepHandle, ExecutedAction, StreamIterate, StreamStepHandle,
};
pub(crate) use stream_result::{astream_result, stream_result};
pub use stream_result::{AStreamResult, StreamResult};

type StreamTerminal = (Option<StreamItem>, State);

#[derive(Clone, Copy)]
struct StreamOrigin {
    missing_application: &'static str,
    missing_execution: &'static str,
    missing_completion: &'static str,
    missing_abort: &'static str,
    missing_terminal: &'static str,
}

const ITERATE_SYNC_ORIGIN: StreamOrigin = StreamOrigin {
    missing_application: "stream_iterate missing application while starting step execution",
    missing_execution: "stream step handle missing execution while polling next item",
    missing_completion: "stream step handle missing execution during completion",
    missing_abort: "stream step handle missing execution during rollback",
    missing_terminal: "stream step handle missing terminal after completion",
};

const ITERATE_ASYNC_ORIGIN: StreamOrigin = StreamOrigin {
    missing_application: "astream_iterate missing application while starting step execution",
    missing_execution: "astream step handle missing execution while polling next item",
    missing_completion: "astream step handle missing execution during completion",
    missing_abort: "astream step handle missing execution during rollback",
    missing_terminal: "astream step handle missing terminal after completion",
};

const RESULT_SYNC_ORIGIN: StreamOrigin = StreamOrigin {
    missing_application: "stream_result missing application while starting target step",
    missing_execution: "stream_result missing active step after target resolution",
    missing_completion: "stream_result missing active step during completion",
    missing_abort: "stream_result missing active step during rollback",
    missing_terminal: "stream_result missing terminal state after completion",
};

const RESULT_ASYNC_ORIGIN: StreamOrigin = StreamOrigin {
    missing_application: "astream_result missing application while starting target step",
    missing_execution: "astream_result missing active step after target resolution",
    missing_completion: "astream_result missing active step during completion",
    missing_abort: "astream_result missing active step during rollback",
    missing_terminal: "astream_result missing terminal state after completion",
};

struct SessionCore<'a> {
    app: Option<&'a mut Application>,
    settings: ExecutionSessionSettings,
    execute_guard: Option<ExecuteCallGuard>,
    progress: StreamProgress,
    startup_error: Option<ApplicationError>,
    deferred_abort_error: Option<ApplicationError>,
    has_committed_step: bool,
    pending_plan: Option<ExecutionPlan>,
}

impl<'a> SessionCore<'a> {
    fn new(
        app: &'a mut Application,
        settings: ExecutionSessionSettings,
        execute_guard: Option<ExecuteCallGuard>,
        terminal: Option<StreamTerminal>,
        pending_plan: Option<ExecutionPlan>,
        startup_error: Option<ApplicationError>,
    ) -> Self {
        let has_committed_step = terminal
            .as_ref()
            .is_some_and(|(result, _state)| result.is_some());
        Self {
            app: Some(app),
            settings,
            execute_guard,
            progress: StreamProgress::new(terminal),
            startup_error,
            deferred_abort_error: None,
            has_committed_step,
            pending_plan,
        }
    }

    fn is_done(&self) -> bool {
        self.progress.is_done()
    }

    fn has_terminal(&self) -> bool {
        self.progress.has_terminal()
    }

    fn terminal(&self, origin: StreamOrigin) -> Result<StreamTerminal, ApplicationError> {
        self.progress.terminal_or_invariant(origin.missing_terminal)
    }

    fn take_deferred_abort_error(&mut self) -> Option<ApplicationError> {
        self.deferred_abort_error.take()
    }

    fn set_deferred_abort_error(&mut self, error: ApplicationError) {
        if self.deferred_abort_error.is_none() {
            self.deferred_abort_error = Some(error);
        }
    }

    fn closed_iterate_handle_result(&self) -> Result<Option<StreamItem>, ApplicationError> {
        if self.has_terminal() {
            Ok(None)
        } else {
            Err(ApplicationError::StreamStepHandleClosed)
        }
    }

    fn closed_iterate_handle_terminal(
        &self,
        origin: StreamOrigin,
    ) -> Result<StreamTerminal, ApplicationError> {
        if self.has_terminal() {
            self.terminal(origin)
        } else {
            Err(ApplicationError::StreamStepHandleClosed)
        }
    }
}
