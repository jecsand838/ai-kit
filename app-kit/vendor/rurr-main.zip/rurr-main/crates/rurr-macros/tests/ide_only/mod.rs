mod fail_action_tracer_param {
    include!("../ui/fail_action_tracer_param.rs");
}

mod fail_no_state_param {
    include!("../ui/fail_no_state_param.rs");
}

mod fail_reserved_param_wrong_type {
    include!("../ui/fail_reserved_param_wrong_type.rs");
}

mod fail_streaming_async_borrowed_lifetime {
    include!("../ui/fail_streaming_async_borrowed_lifetime.rs");
}

mod fail_streaming_borrowed_lifetime {
    include!("../ui/fail_streaming_borrowed_lifetime.rs");
}

mod fail_streaming_wrong_return {
    include!("../ui/fail_streaming_wrong_return.rs");
}

mod fail_wrong_return_type {
    include!("../ui/fail_wrong_return_type.rs");
}

mod pass_action_with_context {
    include!("../ui/pass_action_with_context.rs");
}

mod pass_action_with_tracer {
    include!("../ui/pass_action_with_tracer.rs");
}

mod pass_action_with_typed_inputs {
    include!("../ui/pass_action_with_typed_inputs.rs");
}

mod pass_action_with_user_input_named_state {
    include!("../ui/pass_action_with_user_input_named_state.rs");
}

mod pass_async_action {
    include!("../ui/pass_async_action.rs");
}

mod pass_streaming_async {
    include!("../ui/pass_streaming_async.rs");
}

mod pass_streaming_sync {
    include!("../ui/pass_streaming_sync.rs");
}

mod pass_sync_action {
    include!("../ui/pass_sync_action.rs");
}
