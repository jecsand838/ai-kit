use crate::{
    action::api::ActionInputs,
    application::{
        build::{
            assemble_resources, build_graph_with_resources_async, build_graph_with_resources_sync,
            BuildMode,
        },
        builder::ApplicationError,
        context::ParentPointer,
        Application, Tracker,
    },
    graph::{Graph, GraphAction, Transition},
    lifecycle::LifecycleAdapterSet,
    state::State,
};
use rurr_persistence::{StateLoaderRef, StatePersisterRef};
use std::sync::Arc;

/// Reusable graph definition used by task-based parallel executors.
#[derive(Clone)]
pub struct RunnableGraph {
    actions: Vec<GraphAction>,
    transitions: Vec<Transition>,
    entrypoint: Option<String>,
}

impl RunnableGraph {
    /// Creates a runnable graph from explicit actions, transitions, and an
    /// optional entrypoint override.
    pub fn new(
        actions: Vec<GraphAction>,
        transitions: Vec<Transition>,
        entrypoint: Option<String>,
    ) -> Self {
        Self {
            actions,
            transitions,
            entrypoint,
        }
    }

    /// Builds a validated [`Graph`] from the stored graph definition.
    pub fn build_graph(&self) -> Result<Graph, ApplicationError> {
        let entrypoint = self.resolved_entrypoint();
        Graph::new(self.actions.clone(), self.transitions.clone(), entrypoint).map_err(Into::into)
    }

    /// Builds a sync-lane child application from this graph definition.
    pub fn build_application_sync(
        &self,
        state: State,
        app_id: String,
        partition_key: Option<String>,
        spawning_parent_pointer: Option<ParentPointer>,
        hooks: LifecycleAdapterSet,
        persister: Option<StatePersisterRef>,
    ) -> Result<Application, ApplicationError> {
        let graph = self.build_graph()?;
        build_graph_with_resources_sync(
            graph,
            state,
            app_id,
            partition_key,
            spawning_parent_pointer,
            assemble_resources(BuildMode::Sync, hooks, None, None, persister, None),
            self.entrypoint.clone(),
        )
    }

    /// Builds an async-lane child application from this graph definition.
    pub async fn build_application_async(
        &self,
        state: State,
        app_id: String,
        partition_key: Option<String>,
        spawning_parent_pointer: Option<ParentPointer>,
        hooks: LifecycleAdapterSet,
        persister: Option<StatePersisterRef>,
    ) -> Result<Application, ApplicationError> {
        let graph = self.build_graph()?;
        build_graph_with_resources_async(
            graph,
            state,
            app_id,
            partition_key,
            spawning_parent_pointer,
            assemble_resources(BuildMode::Async, hooks, None, None, persister, None),
            self.entrypoint.clone(),
        )
        .await
    }

    fn resolved_entrypoint(&self) -> String {
        self.entrypoint.clone().unwrap_or_else(|| {
            self.actions
                .first()
                .map(|first_action| first_action.name().to_string())
                .unwrap_or_default()
        })
    }
}

/// One subgraph invocation submitted to a parallel executor.
#[derive(Clone)]
pub struct SubGraphTask {
    /// Child graph that should be executed.
    pub graph: RunnableGraph,
    /// Initial state passed into the child graph.
    pub state: State,
    /// Stable task key used to correlate child results.
    pub task_key: String,
    /// Runtime inputs supplied to the child application.
    pub inputs: ActionInputs,
    /// Optional tracking client inherited by the child application.
    pub tracker: Option<Arc<dyn Tracker>>,
    /// Optional state persister used by the child application.
    pub state_persister: Option<StatePersisterRef>,
    /// Optional state loader used for initialization or resume.
    pub state_initializer: Option<StateLoaderRef>,
    /// Optional explicit child application id override.
    pub child_app_id: Option<String>,
}

impl SubGraphTask {
    /// Creates a subgraph task with empty inputs and no optional integrations.
    ///
    /// # Examples
    ///
    /// ```rust
    /// use indexmap::IndexMap;
    /// use rurr_core::LocalAction;
    /// use rurr_core::parallelism::{RunnableGraph, SubGraphTask};
    /// use rurr_core::{FunctionActionBuilder, GraphAction, State};
    ///
    /// let step = FunctionActionBuilder::new()
    ///     .build_sync(|_state, _ctx| IndexMap::new())?
    ///     .with_name("step")?;
    ///
    /// let graph = RunnableGraph::new(
    ///     vec![GraphAction::new(step)?],
    ///     Vec::new(),
    ///     Some("step".to_string()),
    /// );
    /// let task = SubGraphTask::new(graph, State::default(), "child-1");
    /// assert_eq!(task.task_key, "child-1");
    /// # Ok::<(), Box<dyn std::error::Error>>(())
    /// ```
    pub fn new(graph: RunnableGraph, state: State, task_key: impl Into<String>) -> Self {
        Self {
            graph,
            state,
            task_key: task_key.into(),
            inputs: ActionInputs::new(),
            tracker: None,
            state_persister: None,
            state_initializer: None,
            child_app_id: None,
        }
    }

    /// Replaces the task's runtime inputs.
    pub fn with_inputs(mut self, inputs: ActionInputs) -> Self {
        self.inputs = inputs;
        self
    }

    /// Attaches a tracker that the child application should use.
    pub fn with_tracker(mut self, tracker: Arc<dyn Tracker>) -> Self {
        self.tracker = Some(tracker);
        self
    }

    /// Attaches a state persister for the child application.
    pub fn with_state_persister(mut self, state_persister: StatePersisterRef) -> Self {
        self.state_persister = Some(state_persister);
        self
    }

    /// Attaches a state loader for the child application.
    pub fn with_state_initializer(mut self, state_initializer: StateLoaderRef) -> Self {
        self.state_initializer = Some(state_initializer);
        self
    }

    /// Overrides the generated child application id.
    pub fn with_child_app_id(mut self, child_app_id: impl Into<String>) -> Self {
        self.child_app_id = Some(child_app_id.into());
        self
    }

    pub(super) fn replace_state(self, state: State) -> Self {
        Self { state, ..self }
    }
}

/// Merge strategy used by task-based parallel actions.
#[derive(Clone)]
pub enum CascadeMode {
    /// Do not merge child state back into the parent automatically.
    None,
    /// Use the provided reducer to combine child states.
    Fixed(Arc<dyn Fn(Vec<State>) -> Result<State, ApplicationError> + Send + Sync>),
    /// Feed each child state into the next child as a pipeline.
    Pipeline,
}
