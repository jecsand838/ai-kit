use super::support::application::{
    assert_execute_drive_startup_error_prefers_post_execute_call_failure,
    assert_execute_drive_startup_error_still_fires_execute_call_hooks,
    assert_reserved_runtime_inputs_rejected, assert_step_error_rolls_back_without_partial_commit,
    assert_step_execute_context_tracks_resolved_next_action_and_reserved_sequence,
    assert_step_injects_application_context_with_reserved_sequence_id,
    assert_step_keeps_context_active_through_update, assert_step_simple_case, count_zero_state,
    counter_action, sync_counting_hooks, ApplicationScenario, ExecuteDriveMode, HookCounts,
    ReservedRuntimeInputCase, StepMode, StepSimpleCase,
};
use rurr_core::action::{
    ActionContext, ActionError, ActionResult, Condition, FunctionActionBuilder, LocalAction,
};
use rurr_core::application::{
    adjust_single_step_output, normalize_single_step_output, ApplicationError, SingleStepOutput,
};
use rurr_core::graph::Transition;
use rurr_core::state::State;
use rurr_testkit::application_fixture::{map_from_pairs, state_from_pairs};
use serde_json::{json, Value};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;

const INTENTIONAL_STEP_POST_EXECUTE_FAILURE: &str = "intentional_step_post_execute_failure";

macro_rules! sync_step_case {
    ($name:ident => $body:expr $(,)?) => {
        #[test]
        fn $name() {
            futures::executor::block_on($body);
        }
    };
}

macro_rules! sync_step_cases {
    ($($name:ident => $body:expr),+ $(,)?) => {
        $(sync_step_case!($name => $body);)+
    };
}

#[derive(Debug, Clone)]
struct UpdatePanickingAction {
    name: Option<String>,
    writes: Vec<String>,
}

impl UpdatePanickingAction {
    fn new() -> Self {
        Self {
            name: None,
            writes: vec!["count".to_string()],
        }
    }
}

impl LocalAction for UpdatePanickingAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &self.writes
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }
        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        let result = map_from_pairs([("count", json!(1))]);
        Ok(ActionResult::new(result.clone(), result))
    }

    fn update(
        &self,
        _result: &ActionResult,
        _state: &State,
        _ctx: &ActionContext,
    ) -> Result<State, ActionError> {
        panic!("intentional panic in action update");
    }
}

sync_step_cases! {
    step_executes_and_commits_internal_keys_at_commit_time =>
        assert_step_simple_case(StepMode::Sync, StepSimpleCase::CommitsInternalKeys),
    step_keeps_context_active_through_update =>
        assert_step_keeps_context_active_through_update(StepMode::Sync),
    step_returns_none_when_no_next_action_exists =>
        assert_step_simple_case(StepMode::Sync, StepSimpleCase::ReturnsNoneWhenNoNextActionExists),
    step_rejects_reserved_runtime_inputs_without_execute_hooks =>
        assert_reserved_runtime_inputs_rejected(StepMode::Sync, ReservedRuntimeInputCase::StepWithoutExecuteHooks),
    step_error_rolls_back_without_partial_commit =>
        assert_step_error_rolls_back_without_partial_commit(StepMode::Sync)
}

#[test]
fn step_startup_errors_still_fire_execute_call_hooks() {
    futures::executor::block_on(
        assert_execute_drive_startup_error_still_fires_execute_call_hooks(
            ExecuteDriveMode::Step,
            StepMode::Sync,
            state_from_pairs([("__SEQUENCE_ID", json!("bad-seq"))]),
            |error| {
                assert!(matches!(
                    error,
                    ApplicationError::InvalidSequenceIdType { .. }
                ))
            },
            |_| {},
        ),
    );
    futures::executor::block_on(
        assert_execute_drive_startup_error_still_fires_execute_call_hooks(
            ExecuteDriveMode::Step,
            StepMode::Sync,
            state_from_pairs([("__SEQUENCE_ID", json!(0)), ("__PRIOR_STEP", json!(12))]),
            |error| {
                assert!(matches!(
                    error,
                    ApplicationError::InvalidPriorStepType { .. }
                ))
            },
            |_| {},
        ),
    );
    futures::executor::block_on(
        assert_execute_drive_startup_error_still_fires_execute_call_hooks(
            ExecuteDriveMode::Step,
            StepMode::Sync,
            state_from_pairs([
                ("__SEQUENCE_ID", json!(0)),
                ("__PRIOR_STEP", json!("missing")),
            ]),
            |error| {
                assert!(matches!(
                    error,
                    ApplicationError::Graph(rurr_core::graph::GraphError::ActionNotFound {
                        action_name,
                        ..
                    }) if action_name == "missing"
                ));
            },
            |app| {
                assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("missing")));
                assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
            },
        ),
    );
}

#[test]
fn step_startup_error_prefers_post_execute_call_failure() {
    futures::executor::block_on(
        assert_execute_drive_startup_error_prefers_post_execute_call_failure(
            ExecuteDriveMode::Step,
            StepMode::Sync,
            INTENTIONAL_STEP_POST_EXECUTE_FAILURE,
        ),
    );
}

#[test]
fn step_panic_in_run_captures_action_run_scope() {
    let panic_action = FunctionActionBuilder::new()
        .writes(["count"])
        .build_sync(|_state, _ctx| panic!("intentional panic in action run"))
        .expect("panic action should build");

    let mut app = ApplicationScenario::single_action(
        state_from_pairs([("count", json!(0))]),
        "panic_run",
        panic_action,
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let error = app
        .step(None)
        .expect_err("panic in run should map to typed application error");
    assert!(matches!(
        error,
        ApplicationError::PanicCaptured {
            scope: "action.run",
            ..
        }
    ));
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

#[test]
fn step_panic_in_update_captures_action_update_scope() {
    let mut app = ApplicationScenario::single_action(
        state_from_pairs([("count", json!(0))]),
        "panic_update",
        UpdatePanickingAction::new(),
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let error = app
        .step(None)
        .expect_err("panic in update should map to typed application error");
    assert!(matches!(
        error,
        ApplicationError::PanicCaptured {
            scope: "action.update",
            ..
        }
    ));
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

#[test]
fn step_lifecycle_guards_wrap_execute_and_step_paths() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_counting_hooks(Arc::clone(&counts));

    let mut app = ApplicationScenario::single_action(
        state_from_pairs([("count", json!(0))]),
        "counter",
        counter_action(),
    )
    .map(|scenario| scenario.with_optional_hooks(Some(hooks)))
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let _ = app
        .step(None)
        .expect("executed step should succeed")
        .expect("step should execute");
    let _ = app.step(None).expect("terminal step should succeed");

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 2);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 2);
    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
}

sync_step_case!(
    step_execute_context_tracks_resolved_next_action_and_reserved_sequence =>
        assert_step_execute_context_tracks_resolved_next_action_and_reserved_sequence(StepMode::Sync)
);

#[test]
fn step_uses_single_transition_resolution_for_hooks_and_execution() {
    let should_take_transition = Arc::new(AtomicBool::new(true));
    let transition_condition = Condition::new(
        ["flag"],
        {
            let should_take_transition = Arc::clone(&should_take_transition);
            move |_state| should_take_transition.swap(false, Ordering::SeqCst)
        },
        "flag_once",
    );

    let mut app = ApplicationScenario::two_action_transition(
        state_from_pairs([
            ("flag", json!(true)),
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(0)),
        ]),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", transition_condition)],
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute action B");

    assert_eq!(output.action.name(), "B");
    assert_eq!(output.result.get("count"), Some(&json!(1)));
}

#[test]
fn step_evaluates_transition_condition_once_per_call() {
    let evaluation_count = Arc::new(AtomicUsize::new(0));
    let transition_condition = Condition::new(
        ["flag"],
        {
            let evaluation_count = Arc::clone(&evaluation_count);
            move |_state| {
                evaluation_count.fetch_add(1, Ordering::SeqCst);
                true
            }
        },
        "flag_counter",
    );

    let mut app = ApplicationScenario::two_action_transition(
        state_from_pairs([
            ("flag", json!(true)),
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(0)),
        ]),
        "A",
        counter_action(),
        "B",
        counter_action(),
        vec![Transition::new("A", "B", transition_condition)],
    )
    .and_then(ApplicationScenario::build)
    .expect("app should build");

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute action B");

    assert_eq!(output.action.name(), "B");
    assert_eq!(evaluation_count.load(Ordering::SeqCst), 1);
}

sync_step_cases! {
    step_injects_application_context_with_reserved_sequence_id =>
        assert_step_injects_application_context_with_reserved_sequence_id(StepMode::Sync)
}

#[tokio::test]
async fn step_succeeds_when_called_inside_tokio_runtime() {
    let mut app =
        ApplicationScenario::single_action(count_zero_state(), "counter", counter_action())
            .and_then(ApplicationScenario::build)
            .expect("app should build");
    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute action");

    assert_eq!(output.result.get("count"), Some(&json!(1)));
    assert_eq!(output.state.get("count"), Some(&json!(1)));
}

#[tokio::test]
async fn step_inside_tokio_runtime_runs_post_run_step_once() {
    let counts = Arc::new(HookCounts::default());
    let hooks = sync_counting_hooks(Arc::clone(&counts));

    let mut app =
        ApplicationScenario::single_action(count_zero_state(), "counter", counter_action())
            .map(|scenario| scenario.with_hooks(hooks))
            .and_then(ApplicationScenario::build)
            .expect("app should build");

    let output = app
        .step(None)
        .expect("step should succeed inside tokio runtime")
        .expect("step should execute action");

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(output.result.get("count"), Some(&json!(1)));
    assert_eq!(app.state().get("count").cloned(), Some(json!(1)));
    assert_eq!(app.state().get("__SEQUENCE_ID").cloned(), Some(json!(0)));
}

#[test]
fn adjust_single_step_output_accepts_result_and_state() {
    let state = state_from_pairs([("count", json!(1))]);
    let result = map_from_pairs([("count", json!(1))]);

    assert_eq!(
        adjust_single_step_output((result.clone(), state.clone()), "test_action"),
        SingleStepOutput::ResultAndState(result, state)
    );
}

#[test]
fn adjust_single_step_output_accepts_state_only() {
    let state = state_from_pairs([("count", json!(1))]);

    assert_eq!(
        adjust_single_step_output(state.clone(), "test_action"),
        SingleStepOutput::StateOnly(state)
    );
}

#[test]
fn adjust_single_step_output_rejects_invalid_top_level_type() {
    match adjust_single_step_output(Value::String("foo".to_string()), "test_action") {
        SingleStepOutput::Invalid { message } => {
            assert!(message.contains("must return either"));
        }
        other => panic!("expected invalid output, got {other:?}"),
    }
}

#[test]
fn adjust_single_step_output_rejects_invalid_result_type_in_tuple_form() {
    let state = state_from_pairs([("count", json!(1))]);
    match adjust_single_step_output((Value::String("bar".to_string()), state), "test_action") {
        SingleStepOutput::Invalid { message } => {
            assert!(message.contains("non-dict"));
        }
        other => panic!("expected invalid output, got {other:?}"),
    }
}

#[test]
fn normalize_single_step_output_invalid_maps_to_application_error() {
    let output = SingleStepOutput::Invalid {
        message: "bad-shape".to_string(),
    };

    let error = normalize_single_step_output(output, "test_action")
        .expect_err("invalid single-step output should map to application error");

    assert!(matches!(
        error,
        ApplicationError::InvalidSingleStepOutput { .. }
    ));
}

#[test]
fn normalize_single_step_output_valid_variants_map_successfully() {
    let state = state_from_pairs([("count", json!(3))]);
    let result = map_from_pairs([("count", json!(3))]);

    let (mapped_result, mapped_state) = normalize_single_step_output(
        SingleStepOutput::ResultAndState(result.clone(), state.clone()),
        "action",
    )
    .expect("result-and-state should map");
    assert_eq!(mapped_result, result);
    assert_eq!(mapped_state, state);

    let state_only = state_from_pairs([("count", json!(7))]);
    let (mapped_result, mapped_state) =
        normalize_single_step_output(SingleStepOutput::StateOnly(state_only.clone()), "action")
            .expect("state-only should map");
    assert!(mapped_result.is_empty());
    assert_eq!(mapped_state, state_only);
}

sync_step_case!(
    step_commits_application_sequence_and_context_state =>
        assert_step_simple_case(
            StepMode::Sync,
            StepSimpleCase::CommitsApplicationSequenceAndContextState,
        )
);
