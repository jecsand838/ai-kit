use indexmap::IndexMap;
use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
/// Log entry emitted when an action begins.
///
/// Begin/end action entries form the core JSONL stream consumed by the tracking
/// server and Burr-parity checks.
pub struct BeginEntryModel {
    /// Record discriminator used in the JSONL log.
    #[serde(rename = "type")]
    pub r#type: String,
    /// RFC3339 timestamp for when the action started.
    pub start_time: String,
    /// Action name.
    pub action: String,
    /// Runtime inputs captured for the action.
    pub inputs: IndexMap<String, Value>,
    /// Sequence id assigned to the action execution.
    pub sequence_id: u64,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
/// Log entry emitted when an action ends.
///
/// Failed actions carry `exception`; successful actions carry the action result
/// and the committed state snapshot observed at the end of the step.
pub struct EndEntryModel {
    /// Record discriminator used in the JSONL log.
    #[serde(rename = "type")]
    pub r#type: String,
    /// RFC3339 timestamp for when the action ended.
    pub end_time: String,
    /// Action name.
    pub action: String,
    /// Result payload returned by the action, when present.
    pub result: Option<IndexMap<String, Value>>,
    /// Exception message captured for failed actions.
    pub exception: Option<String>,
    /// State snapshot recorded at the end of the action.
    pub state: IndexMap<String, Value>,
    /// Sequence id assigned to the action execution.
    pub sequence_id: u64,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Log entry emitted when a visibility span begins.
///
/// Span entries are emitted by Rurr visibility helpers and by OTEL tracking
/// mirroring when external child spans are observed.
pub struct BeginSpanModel {
    /// Record discriminator used in the JSONL log.
    #[serde(rename = "type")]
    pub r#type: String,
    /// RFC3339 timestamp for when the span started.
    pub start_time: String,
    /// Sequence id of the action that owns the span.
    pub action_sequence_id: u64,
    /// Span identifier.
    pub span_id: String,
    /// Human-readable span name.
    pub span_name: String,
    /// Parent span identifier, if this span is nested.
    pub parent_span_id: Option<String>,
    /// Upstream span ids this span depends on.
    pub span_dependencies: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Log entry emitted when a visibility span ends.
///
/// The matching begin entry supplies span name and parent metadata.
pub struct EndSpanModel {
    /// Record discriminator used in the JSONL log.
    #[serde(rename = "type")]
    pub r#type: String,
    /// RFC3339 timestamp for when the span ended.
    pub end_time: String,
    /// Sequence id of the action that owns the span.
    pub action_sequence_id: u64,
    /// Span identifier.
    pub span_id: String,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
/// Log entry emitted when an attribute is recorded.
///
/// Attributes may be action-scoped or span-scoped depending on whether
/// `span_id` is present.
pub struct AttributeModel {
    /// Record discriminator used in the JSONL log.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Attribute key.
    pub key: String,
    /// Sequence id of the action that owns the attribute.
    pub action_sequence_id: u64,
    /// Span identifier when the attribute belongs to a span.
    pub span_id: Option<String>,
    /// JSON attribute value.
    pub value: Value,
    /// Extra string tags associated with the attribute.
    pub tags: IndexMap<String, String>,
    /// RFC3339 timestamp for when the attribute was logged, when explicitly captured.
    pub time_logged: Option<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Log entry emitted when a stream is initialized.
///
/// Stream lifecycle entries describe lazy streaming timing without forcing the
/// runtime to buffer the stream.
pub struct InitializeStreamModel {
    /// Record discriminator used in the JSONL log.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Sequence id of the action that owns the stream.
    pub action_sequence_id: u64,
    /// Span identifier when the stream belongs to a span.
    pub span_id: Option<String>,
    /// RFC3339 timestamp for when the stream was initialized.
    pub stream_init_time: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Log entry emitted when the first stream item is observed.
pub struct FirstItemStreamModel {
    /// Record discriminator used in the JSONL log.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Sequence id of the action that owns the stream.
    pub action_sequence_id: u64,
    /// Span identifier when the stream belongs to a span.
    pub span_id: Option<String>,
    /// RFC3339 timestamp for when the first item was emitted.
    pub first_item_time: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Log entry emitted when a stream ends.
pub struct EndStreamModel {
    /// Record discriminator used in the JSONL log.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Sequence id of the action that owns the stream.
    pub action_sequence_id: u64,
    /// Span identifier when the stream belongs to a span.
    pub span_id: Option<String>,
    /// RFC3339 timestamp for when the stream ended.
    pub end_time: String,
    /// Number of items emitted before the stream ended.
    pub items_streamed: usize,
}
