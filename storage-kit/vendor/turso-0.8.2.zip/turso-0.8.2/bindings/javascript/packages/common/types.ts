export type ExperimentalFeature = 'views' | 'strict' | 'encryption' | 'index_method' | 'custom_types' | 'autovacuum' | 'vacuum' | 'triggers' | 'attach' | 'generated_columns' | 'multiprocess_wal' | 'without_rowid';

/** Supported encryption ciphers for local database encryption. */
export type EncryptionCipher = 'aes128gcm' | 'aes256gcm' | 'aegis256' | 'aegis256x2' | 'aegis128l' | 'aegis128x2' | 'aegis128x4'

/** Encryption configuration for local encryption. */
export interface EncryptionOpts {
    cipher: EncryptionCipher
    /** The hex-encoded encryption key */
    hexkey: string
}

export interface DatabaseOpts {
    readonly?: boolean,
    fileMustExist?: boolean,
    timeout?: number
    /** Default maximum query execution time in milliseconds before interruption. */
    defaultQueryTimeout?: number
    tracing?: 'info' | 'debug' | 'trace'
    /** Experimental features to enable */
    experimental?: ExperimentalFeature[]
    /** Optional local encryption configuration */
    encryption?: EncryptionOpts
}

export interface QueryOptions {
    /** Per-query timeout in milliseconds. Overrides defaultQueryTimeout for this call. */
    queryTimeout?: number
}

export interface NativeDatabase {
    memory: boolean,
    path: string,
    readonly: boolean;
    open: boolean;
    new(path: string): NativeDatabase;

    connectSync();
    connectAsync(): Promise<void>;

    ioLoopSync();
    ioLoopAsync(): Promise<void>;

    prepare(sql: string): NativeStatement;
    executor(sql: string, queryOptions?: QueryOptions): NativeExecutor;

    defaultSafeIntegers(toggle: boolean);
    inTransaction(): boolean;
    totalChanges(): number;
    changes(): number;
    lastInsertRowid(): number;
    close();
}


// Step result constants
export const STEP_ROW = 1;
export const STEP_DONE = 2;
export const STEP_IO = 3;
export const STEP_SLEEP = 4;

export interface TableColumn {
    name: string,
    type: string | null,
    column: null,
    table: null,
    database: null
}

/** [step constant, milliseconds to wait before stepping again (nonzero only for STEP_SLEEP)] */
export type StepResult = [number, number];

export interface NativeExecutor {
    stepSync(): StepResult;
    reset();
}
export interface NativeStatement {
    setQueryTimeout(queryOptions?: QueryOptions): void;
    stepAsync(): Promise<StepResult>;
    stepSync(): StepResult;

    pluck(pluckMode: boolean);
    safeIntegers(toggle: boolean);
    raw(toggle: boolean);
    columns(): TableColumn[];
    row(): any;
    reset();
    finalize();
}
