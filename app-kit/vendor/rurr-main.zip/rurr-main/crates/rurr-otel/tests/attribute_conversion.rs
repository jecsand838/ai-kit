use opentelemetry::{Array as OtelArray, StringValue, Value as OtelValue};
use rurr_otel::convert_to_otel_attribute;
use serde_json::json;

const PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF: &str =
    "crates/rurr-otel/tests/collector_file_live.rs::collector_file_export_proves_primitive_and_homogeneous_array_any_values";
const COMPLEX_STRING_ANY_VALUE_LIVE_PROOF: &str =
    "crates/rurr-otel/tests/collector_file_live.rs::collector_file_export_proves_complex_attribute_string_values";
const NULL_OMISSION_LIVE_PROOF: &str =
    "crates/rurr-otel/tests/collector_file_live.rs::collector_file_export_proves_json_null_attributes_are_omitted";

#[test]
fn test_convert_to_otel_attribute_string() {
    assert_eq!(
        convert_to_otel_attribute(&json!("hello")),
        Some(OtelValue::String(StringValue::from("hello"))),
        "internal conversion contract; raw provider behavior is proven by {PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_int() {
    assert_eq!(
        convert_to_otel_attribute(&json!(1)),
        Some(OtelValue::I64(1)),
        "internal conversion contract; raw provider behavior is proven by {PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_float() {
    assert_eq!(
        convert_to_otel_attribute(&json!(1.5)),
        Some(OtelValue::F64(1.5)),
        "internal conversion contract; raw provider behavior is proven by {PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_bool() {
    assert_eq!(
        convert_to_otel_attribute(&json!(true)),
        Some(OtelValue::Bool(true)),
        "internal conversion contract; raw provider behavior is proven by {PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_null() {
    assert_eq!(
        convert_to_otel_attribute(&json!(null)),
        None,
        "internal conversion contract; raw omission behavior is proven by {NULL_OMISSION_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_array_homogeneous() {
    assert_eq!(
        convert_to_otel_attribute(&json!([1, 2, 3])),
        Some(OtelValue::Array(OtelArray::I64(vec![1, 2, 3]))),
        "internal conversion contract; raw provider behavior is proven by {PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_array_homogeneous_bool() {
    assert_eq!(
        convert_to_otel_attribute(&json!([true, false])),
        Some(OtelValue::Array(OtelArray::Bool(vec![true, false]))),
        "internal conversion contract; raw provider behavior is proven by {PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_array_homogeneous_float() {
    assert_eq!(
        convert_to_otel_attribute(&json!([1.25, 2.5])),
        Some(OtelValue::Array(OtelArray::F64(vec![1.25, 2.5]))),
        "internal conversion contract; raw provider behavior is proven by {PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_array_homogeneous_string() {
    assert_eq!(
        convert_to_otel_attribute(&json!(["alpha", "beta"])),
        Some(OtelValue::Array(OtelArray::String(vec![
            StringValue::from("alpha"),
            StringValue::from("beta"),
        ]))),
        "internal conversion contract; raw provider behavior is proven by {PRIMITIVE_AND_ARRAY_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_array_mixed() {
    assert_eq!(
        convert_to_otel_attribute(&json!([1, "x"])),
        Some(OtelValue::String(StringValue::from(r#"[1, "x"]"#))),
        "internal conversion contract; raw provider behavior is proven by {COMPLEX_STRING_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_array_mixed_numeric_stringified() {
    assert_eq!(
        convert_to_otel_attribute(&json!([1, 1.5])),
        Some(OtelValue::String(StringValue::from("[1, 1.5]"))),
        "internal conversion contract; raw provider behavior is proven by {COMPLEX_STRING_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_object() {
    assert_eq!(
        convert_to_otel_attribute(&json!({"foo": 1, "bar": true})),
        Some(OtelValue::String(StringValue::from(
            r#"{"foo": 1, "bar": true}"#
        ))),
        "internal conversion contract; raw provider behavior is proven by {COMPLEX_STRING_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_empty_array_stringified() {
    assert_eq!(
        convert_to_otel_attribute(&json!([])),
        Some(OtelValue::String(StringValue::from("[]"))),
        "internal conversion contract; raw provider behavior is proven by {COMPLEX_STRING_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_large_u64_stringified_losslessly() {
    let value = json!(9_223_372_036_854_775_808_u64);
    assert_eq!(
        convert_to_otel_attribute(&value),
        Some(OtelValue::String(StringValue::from("9223372036854775808"))),
        "internal conversion contract; raw provider behavior is proven by {COMPLEX_STRING_ANY_VALUE_LIVE_PROOF}"
    );
}

#[test]
fn test_convert_to_otel_attribute_array_large_u64_stringified_losslessly() {
    let value = json!([9_223_372_036_854_775_808_u64, 9_223_372_036_854_775_809_u64]);
    assert_eq!(
        convert_to_otel_attribute(&value),
        Some(OtelValue::String(StringValue::from(
            "[9223372036854775808, 9223372036854775809]"
        ))),
        "internal conversion contract; raw provider behavior is proven by {COMPLEX_STRING_ANY_VALUE_LIVE_PROOF}"
    );
}
