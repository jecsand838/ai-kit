use std::panic::{catch_unwind, AssertUnwindSafe};

/// Runs a `Drop` finalizer without allowing a nested panic to abort the process.
pub fn run_drop_finalizer(finalize: impl FnOnce()) {
    if std::thread::panicking() {
        // During unwind, avoid process abort from a second panic raised by user hooks.
        let _ = catch_unwind(AssertUnwindSafe(finalize));
    } else {
        finalize();
    }
}
