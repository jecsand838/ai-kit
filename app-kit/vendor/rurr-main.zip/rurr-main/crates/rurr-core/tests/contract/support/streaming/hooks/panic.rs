use rurr_core::lifecycle::LifecycleError;
use rurr_core::lifecycle::{ExecuteCallContext, PostStepContext, SyncLifecycleAdapter};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::Arc;

#[derive(Debug, Default)]
pub(crate) struct PanickingPostExecuteState {
    pub(crate) post_execute_call: AtomicUsize,
    pub(crate) did_panic: AtomicBool,
}

#[derive(Debug)]
pub(crate) struct PanickingPostExecuteCallHook {
    state: Arc<PanickingPostExecuteState>,
}

impl PanickingPostExecuteCallHook {
    pub(crate) fn new(state: Arc<PanickingPostExecuteState>) -> Self {
        Self { state }
    }
}

impl SyncLifecycleAdapter for PanickingPostExecuteCallHook {
    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.state.post_execute_call.fetch_add(1, Ordering::SeqCst);
        if !self.state.did_panic.swap(true, Ordering::SeqCst) {
            panic!("intentional panic in sync post_execute_call hook");
        }
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct PanickingPostStepState {
    pub(crate) post_run_step: AtomicUsize,
    pub(crate) did_panic: AtomicBool,
}

#[derive(Debug)]
pub(crate) struct PanickingPostStepHook {
    state: Arc<PanickingPostStepState>,
}

impl PanickingPostStepHook {
    pub(crate) fn new(state: Arc<PanickingPostStepState>) -> Self {
        Self { state }
    }
}

impl SyncLifecycleAdapter for PanickingPostStepHook {
    fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        self.state.post_run_step.fetch_add(1, Ordering::SeqCst);
        if !self.state.did_panic.swap(true, Ordering::SeqCst) {
            panic!("intentional panic in sync post_run_step hook");
        }
        Ok(())
    }
}
