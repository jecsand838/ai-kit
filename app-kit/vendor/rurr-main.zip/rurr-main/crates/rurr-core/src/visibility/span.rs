use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

#[derive(Debug)]
struct ActionSpanNode {
    factory_id: u64,
    action: String,
    action_sequence_id: u64,
    span_name: String,
    sequence_id: u64,
    // Parent is kept strongly to keep ancestry/uid stable even if external parent handles drop.
    // This is cycle-safe because parents do not retain references to child nodes.
    parent: Option<Arc<ActionSpanNode>>,
    child_count: AtomicU64,
    span_dependencies: Vec<String>,
}

/// Trace span identifier with stable ancestry and child sequencing.
#[derive(Debug, Clone)]
pub struct ActionSpan {
    node: Arc<ActionSpanNode>,
}

impl ActionSpan {
    /// Creates a root span for one action execution.
    pub fn create_initial(
        action: impl Into<String>,
        span_name: impl Into<String>,
        sequence_id: u64,
        action_sequence_id: u64,
    ) -> Self {
        Self::create_initial_with_factory(
            action,
            span_name,
            sequence_id,
            action_sequence_id,
            0,
            Vec::new(),
        )
    }

    pub(crate) fn create_initial_with_factory(
        action: impl Into<String>,
        span_name: impl Into<String>,
        sequence_id: u64,
        action_sequence_id: u64,
        factory_id: u64,
        span_dependencies: Vec<String>,
    ) -> Self {
        Self {
            node: Arc::new(ActionSpanNode {
                factory_id,
                action: action.into(),
                action_sequence_id,
                span_name: span_name.into(),
                sequence_id,
                parent: None,
                child_count: AtomicU64::new(0),
                span_dependencies,
            }),
        }
    }

    /// Creates a child span without explicit dependencies.
    pub fn spawn(&self, span_name: impl Into<String>) -> Self {
        self.spawn_with_dependencies(span_name, Vec::new())
    }

    /// Creates a child span with explicit dependency ids.
    pub fn spawn_with_dependencies(
        &self,
        span_name: impl Into<String>,
        span_dependencies: Vec<String>,
    ) -> Self {
        let sequence_id = self.node.child_count.fetch_add(1, Ordering::Relaxed);
        Self {
            node: Arc::new(ActionSpanNode {
                factory_id: self.factory_id(),
                action: self.action().to_string(),
                action_sequence_id: self.action_sequence_id(),
                span_name: span_name.into(),
                sequence_id,
                parent: Some(Arc::clone(&self.node)),
                child_count: AtomicU64::new(0),
                span_dependencies,
            }),
        }
    }

    /// Returns the action name that owns the span.
    pub fn action(&self) -> &str {
        &self.node.action
    }

    /// Returns the action sequence id.
    pub fn action_sequence_id(&self) -> u64 {
        self.node.action_sequence_id
    }

    /// Returns the human-readable span name.
    pub fn span_name(&self) -> &str {
        &self.node.span_name
    }

    /// Returns the span-local sequence id.
    pub fn sequence_id(&self) -> u64 {
        self.node.sequence_id
    }

    /// Returns how many child spans have been allocated from this span.
    pub fn child_count(&self) -> u64 {
        self.node.child_count.load(Ordering::Relaxed)
    }

    /// Returns the parent span, when this span is not a root.
    pub fn parent(&self) -> Option<Self> {
        self.node.parent.as_ref().map(|node| Self {
            node: Arc::clone(node),
        })
    }

    /// Returns the explicit dependency ids recorded for the span.
    pub fn span_dependencies(&self) -> &[String] {
        &self.node.span_dependencies
    }

    pub(crate) fn factory_id(&self) -> u64 {
        self.node.factory_id
    }

    /// Returns the stable Burr-style span uid.
    pub fn uid(&self) -> String {
        let mut path = vec![self.sequence_id().to_string()];
        let mut current = self.parent();
        while let Some(parent) = current {
            path.push(parent.sequence_id().to_string());
            current = parent.parent();
        }
        path.reverse();
        format!("{}:{}", self.action_sequence_id(), path.join("."))
    }
}
