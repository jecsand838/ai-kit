use indexmap::IndexMap;
use rurr_core::action::{LocalAction, ActionError, ActionResult};
use rurr_core::state::State;
use serde_json::json;

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
fn action_with_user_input_named_state(
    current: &State,
    state: i64,
) -> Result<ActionResult, ActionError> {
    let next = current
        .get("count")
        .and_then(serde_json::Value::as_i64)
        .unwrap_or(0)
        + state;
    let result = IndexMap::from([("count".to_string(), json!(next))]);
    Ok(ActionResult::new(result.clone(), result))
}

fn assert_action_bounds<T: LocalAction + Send + Sync>(action: &T) {
    let _ = action;
}

fn main() {
    let action =
        action_with_user_input_named_state_action().expect("macro-generated action should build");
    assert_action_bounds(&action);
}
