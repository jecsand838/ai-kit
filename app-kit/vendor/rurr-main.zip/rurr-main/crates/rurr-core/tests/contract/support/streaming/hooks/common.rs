#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum LifecycleHookLane {
    Sync,
    Async,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum LifecycleHookPhase {
    PostExecuteCall,
    PostRunStep,
    PostEndStream,
    PreStartStream,
    PostStreamItem,
}

impl LifecycleHookPhase {
    pub(super) fn phase_name(self) -> &'static str {
        match self {
            Self::PostExecuteCall => "post_execute_call",
            Self::PostRunStep => "post_run_step",
            Self::PostEndStream => "post_end_stream",
            Self::PreStartStream => "pre_start_stream",
            Self::PostStreamItem => "post_stream_item",
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub(super) struct LifecycleFailure {
    pub(super) lane: LifecycleHookLane,
    pub(super) phase: LifecycleHookPhase,
    pub(super) marker: &'static str,
}
