use super::span::ActionSpan;
use std::cell::RefCell;
use std::future::Future;

#[derive(Clone)]
struct CurrentSpanEntry {
    session_id: u64,
    span: ActionSpan,
}

tokio::task_local! {
    static TASK_SPAN_STACK: RefCell<Vec<CurrentSpanEntry>>;
}

thread_local! {
    static THREAD_SPAN_STACK: RefCell<Vec<CurrentSpanEntry>> = const { RefCell::new(Vec::new()) };
}

pub(super) fn current_span_for_session(session_id: u64) -> Option<ActionSpan> {
    current_stack_snapshot()
        .into_iter()
        .rev()
        .find(|entry| entry.session_id == session_id)
        .map(|entry| entry.span)
}

pub(super) fn scope_sync<F, R>(session_id: u64, span: ActionSpan, function: F) -> R
where
    F: FnOnce() -> R,
{
    let entry = CurrentSpanEntry { session_id, span };
    if TASK_SPAN_STACK
        .try_with(|stack| stack.borrow_mut().push(entry.clone()))
        .is_ok()
    {
        let _guard = SyncScopeGuard::task();
        return function();
    }

    THREAD_SPAN_STACK.with(|stack| stack.borrow_mut().push(entry));
    let _guard = SyncScopeGuard::thread();
    function()
}

pub(super) async fn scope_async<Fut>(session_id: u64, span: ActionSpan, future: Fut) -> Fut::Output
where
    Fut: Future,
{
    let mut scoped = current_stack_snapshot();
    scoped.push(CurrentSpanEntry { session_id, span });
    TASK_SPAN_STACK.scope(RefCell::new(scoped), future).await
}

fn current_stack_snapshot() -> Vec<CurrentSpanEntry> {
    TASK_SPAN_STACK
        .try_with(|stack| stack.borrow().clone())
        .unwrap_or_else(|_| THREAD_SPAN_STACK.with(|stack| stack.borrow().clone()))
}

enum SyncScopeGuard {
    Task,
    Thread,
}

impl SyncScopeGuard {
    fn task() -> Self {
        Self::Task
    }

    fn thread() -> Self {
        Self::Thread
    }
}

impl Drop for SyncScopeGuard {
    fn drop(&mut self) {
        match self {
            Self::Task => {
                let _ = TASK_SPAN_STACK.try_with(|stack| {
                    stack.borrow_mut().pop();
                });
            }
            Self::Thread => {
                THREAD_SPAN_STACK.with(|stack| {
                    stack.borrow_mut().pop();
                });
            }
        }
    }
}
