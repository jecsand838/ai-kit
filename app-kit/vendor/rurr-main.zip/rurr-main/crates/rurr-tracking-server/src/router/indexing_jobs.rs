use super::{unsupported_feature, ApiError, AppState};
use crate::schema::IndexingJobsQuery;
use axum::extract::{Query, State};
use axum::response::{IntoResponse, Response};
use axum::routing::get;
use axum::{Json, Router};

/// Builds the indexing-job routes mounted under `/api/v0`.
pub fn routes() -> Router<AppState> {
    Router::new().route("/indexing_jobs", get(indexing_jobs))
}

async fn indexing_jobs(
    Query(query): Query<IndexingJobsQuery>,
    State(state): State<AppState>,
) -> Result<Response, ApiError> {
    if !state.backend().backend_capabilities().indexing {
        return Err(unsupported_feature("indexing jobs"));
    }
    let offset = query.offset.unwrap_or(0);
    let limit = query.limit.unwrap_or(100);
    let filter_empty = query.filter_empty.unwrap_or(true);
    let payload = state
        .backend()
        .indexing_jobs(offset, limit, filter_empty)
        .await?;
    Ok(Json(payload).into_response())
}
