use super::fixtures::child_states_in_state;
use rurr_core::action::{ActionContext, ActionError, ActionInputs, ActionTracer, LocalAction};
use rurr_core::application::{Application, ApplicationContext, ApplicationError};
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::state::State;
use rurr_core::tracking::LocalTrackingClient;
use rurr_testkit::tracking_fixture::artifacts::{project_app_dir, read_json, read_jsonl};
use serde_json::{json, Value};
use std::collections::BTreeSet;
use std::path::Path;

pub(crate) fn assert_parallel_failure_keeps_parent_state_clean(app: &Application) {
    assert_eq!(app.state().get("sentinel"), Some(&json!(1)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
    assert!(!app.state().contains_key("__PRIOR_STEP"));
}

pub(crate) fn assert_parallel_internal_error_message(error: ApplicationError, expected: &str) {
    assert!(matches!(
        error,
        ApplicationError::Action(ActionError::Internal { message }) if message == expected
    ));
}

pub(crate) fn is_lower_hex_64(value: &str) -> bool {
    value.len() == 64
        && value
            .chars()
            .all(|ch| ch.is_ascii_digit() || ('a'..='f').contains(&ch))
}

pub(crate) fn assert_parallel_action_missing_parent_sequence_id_sync<A>(
    action_name: &str,
    action: A,
) where
    A: LocalAction + Send + Sync + 'static,
{
    let tracer = ActionTracer::new(
        action_name,
        7,
        LifecycleAdapterSet::default(),
        "parent-app",
        Some("pk".to_string()),
    );
    let context = ApplicationContext {
        app_id: "parent-app".to_string(),
        partition_key: Some("pk".to_string()),
        sequence_id: None,
        prior_step: None,
        parent_pointer: None,
        spawning_parent_pointer: None,
    };

    let named_action = action
        .with_name(action_name)
        .expect("action naming should succeed");
    let error = named_action
        .run(
            &State::default(),
            &ActionContext::new(ActionInputs::new(), tracer, Some(context)),
        )
        .expect_err("run should fail without application-managed execution scope");

    match error {
        ActionError::RuntimeContextUnavailable { message } => {
            assert_eq!(
                message,
                "parallel action requires application-managed execution scope"
            )
        }
        other => panic!("expected runtime context error, got {other:?}"),
    }
}

pub(crate) async fn assert_parallel_action_missing_parent_sequence_id_async<A>(
    action_name: &str,
    action: A,
) where
    A: LocalAction + Send + Sync + 'static,
{
    let tracer = ActionTracer::new(
        action_name,
        7,
        LifecycleAdapterSet::default(),
        "parent-app",
        Some("pk".to_string()),
    );
    let named_action = action
        .with_name(action_name)
        .expect("action naming should succeed");

    let error = named_action
        .run_async(
            &State::default(),
            &ActionContext::new(
                ActionInputs::new(),
                tracer,
                Some(ApplicationContext {
                    app_id: "parent-app".to_string(),
                    partition_key: Some("pk".to_string()),
                    sequence_id: None,
                    prior_step: None,
                    parent_pointer: None,
                    spawning_parent_pointer: None,
                }),
            ),
        )
        .await
        .expect_err("run_async should fail without application-managed execution scope");

    match error {
        ActionError::RuntimeContextUnavailable { message } => {
            assert_eq!(
                message,
                "parallel action requires application-managed execution scope"
            )
        }
        other => panic!("expected runtime context error, got {other:?}"),
    }
}

pub(crate) fn child_seen_app_ids_in_state(state: &State) -> BTreeSet<String> {
    child_states_in_state(state)
        .iter()
        .map(|child_state| {
            child_state
                .get("seen_app_id")
                .and_then(Value::as_str)
                .expect("seen_app_id should be present")
                .to_string()
        })
        .collect()
}

pub(crate) fn assert_child_tracker_registration_and_logs(
    storage_root: &Path,
    project: &str,
    child_app_id: &str,
    parent_app_id: &str,
) {
    let child_app_dir = project_app_dir(storage_root, project, child_app_id);
    let graph_path = child_app_dir.join(LocalTrackingClient::GRAPH_FILENAME);
    let metadata_path = child_app_dir.join(LocalTrackingClient::METADATA_FILENAME);
    let log_path = child_app_dir.join(LocalTrackingClient::LOG_FILENAME);

    assert!(
        graph_path.exists(),
        "child graph.json should exist in override tracker storage: {}",
        graph_path.display()
    );
    assert!(
        metadata_path.exists(),
        "child metadata.json should exist in override tracker storage: {}",
        metadata_path.display()
    );
    assert!(
        log_path.exists(),
        "child log.jsonl should exist in override tracker storage: {}",
        log_path.display()
    );

    let metadata = read_json(&metadata_path);
    assert_eq!(metadata["type"], json!("application_metadata"));
    assert_eq!(
        metadata["spawning_parent_pointer"]["app_id"],
        json!(parent_app_id)
    );

    let log_entries = read_jsonl(&log_path);
    assert!(
        log_entries
            .iter()
            .any(|entry| entry["type"] == json!("begin_entry")),
        "child tracker log should contain begin_entry: {log_entries:?}"
    );
    assert!(
        log_entries
            .iter()
            .any(|entry| entry["type"] == json!("end_entry")),
        "child tracker log should contain end_entry: {log_entries:?}"
    );
}
