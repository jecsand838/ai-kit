use super::BackendError;
use tokio::sync::oneshot;

const ANNOTATION_EXECUTOR_LANES: usize = 4;

type AnnotationExecutorJob = Box<dyn FnOnce() + Send + 'static>;

#[derive(Debug)]
struct AnnotationExecutorLane {
    sender: std::sync::mpsc::Sender<AnnotationExecutorJob>,
}

#[derive(Debug)]
pub(super) struct AnnotationExecutor {
    lanes: Vec<AnnotationExecutorLane>,
}

impl AnnotationExecutor {
    pub(super) fn start() -> std::io::Result<Self> {
        let mut lanes = Vec::with_capacity(ANNOTATION_EXECUTOR_LANES);
        for lane_index in 0..ANNOTATION_EXECUTOR_LANES {
            let (sender, receiver) = std::sync::mpsc::channel::<AnnotationExecutorJob>();
            std::thread::Builder::new()
                .name(format!("rurr-tracking-annotations-{lane_index}"))
                .spawn(move || {
                    while let Ok(job) = receiver.recv() {
                        job();
                    }
                })?;
            lanes.push(AnnotationExecutorLane { sender });
        }
        Ok(Self { lanes })
    }

    fn lane_index(project_id: &str) -> usize {
        project_id.bytes().fold(0usize, |acc, byte| {
            acc.wrapping_mul(131).wrapping_add(byte as usize)
        }) % ANNOTATION_EXECUTOR_LANES
    }

    pub(super) async fn run<R, F>(
        &self,
        project_id: &str,
        operation: &'static str,
        f: F,
    ) -> Result<R, BackendError>
    where
        R: Send + 'static,
        F: FnOnce() -> Result<R, BackendError> + Send + 'static,
    {
        let (response_tx, response_rx) = oneshot::channel();
        self.lanes[Self::lane_index(project_id)]
            .sender
            .send(Box::new(move || {
                let _ = response_tx.send(f());
            }))
            .map_err(|_| BackendError::AnnotationExecutorClosed { operation })?;
        response_rx
            .await
            .map_err(|source| BackendError::AnnotationExecutorPanic { operation, source })?
    }
}
