use super::actions::{
    empty_streaming_source_action, error_first_item_streaming_action, failing_update_action,
    never_ready_async_stream_action, non_send_streaming_action, non_streaming_count_action,
    pre_target_run_only_action, streaming_count_action, uncommitted_streaming_action,
};
use super::assertions::{
    assert_single_update_trace_span, ASYNC_POST_END_STREAM_FAILURE_MARKER,
    ASYNC_POST_EXECUTE_FAILURE_MARKER, ASYNC_POST_RUN_STEP_FAILURE_MARKER,
    SYNC_POST_END_STREAM_FAILURE_MARKER, SYNC_POST_EXECUTE_FAILURE_MARKER,
    SYNC_POST_RUN_STEP_FAILURE_MARKER,
};
use super::builders::{
    build_async_run_failure_non_streaming_app_with_hooks, build_count_zero_action_app,
    build_count_zero_action_app_with_hooks, build_count_zero_transition_app,
    build_empty_streaming_source_app, build_error_streaming_app,
    build_error_streaming_app_with_hooks, build_failing_update_non_streaming_app_with_hooks,
    build_never_ready_async_streaming_app_with_hooks, build_non_send_streaming_app,
    build_pre_target_failure_app, build_pre_target_stream_guard_app, build_streaming_app,
    build_streaming_app_with_hooks, build_streaming_app_with_hooks_and_persister,
    build_uncommitted_streaming_app, build_update_tracing_non_streaming_app_with_hooks,
    FailingCommitPersister,
};
use super::hooks::{
    LifecycleFailureHook, LifecycleHookRecorder, PostStepExceptionRecorder, StreamAbortHookCounts,
    UpdateTraceSpanEvents, UpdateTraceSpanHook,
};
use super::runtime::StreamMode;
use futures::StreamExt;
use indexmap::IndexMap;
use rurr_core::action::{ActionError, Condition, StreamItem};
use rurr_core::application::{Application, ApplicationError, ExecutionOptions};
use rurr_core::graph::Transition;
use rurr_core::lifecycle::{AsyncLifecycleAdapter, LifecycleAdapterSet, SyncLifecycleAdapter};
use rurr_persistence::BaseStatePersister;
use serde_json::json;
use std::future::poll_fn;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::task::Poll;
use std::time::Duration;

fn assert_zero_count_without_sequence_id_in_app(app: &Application) {
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

fn assert_zero_count_without_sequence_id_in_state(state: &rurr_core::state::State) {
    assert_eq!(state.get("count").cloned(), Some(json!(0)));
    assert!(!state.contains_key("__SEQUENCE_ID"));
}

fn assert_uncommitted_stream_state(state: &rurr_core::state::State) {
    assert_eq!(state.get("count").cloned(), Some(json!(0)));
    assert!(!state.contains_key("__PRIOR_STEP"));
    assert!(!state.contains_key("__SEQUENCE_ID"));
}

#[derive(Clone, Copy)]
enum MidStreamRollbackMode {
    Drop,
    PanicOnSecondItem,
}

#[derive(Clone, Copy)]
enum UncommittedStreamCompletion {
    GetOnly,
    DriveToTerminalThenGet,
}

fn build_runner_parity_stream_result_app() -> Application {
    build_count_zero_transition_app(
        "prepare",
        non_streaming_count_action(Arc::new(AtomicUsize::new(0))),
        "stream",
        streaming_count_action(Arc::new(AtomicUsize::new(0)), 2, None),
        vec![Transition::new("prepare", "stream", Condition::default())],
    )
    .expect("app should build")
}

fn build_runner_parity_single_stream_app() -> Application {
    build_streaming_app(streaming_count_action(
        Arc::new(AtomicUsize::new(0)),
        3,
        None,
    ))
    .expect("app should build")
}

async fn collect_stream_result_summary(
    mode: StreamMode,
    app: &mut Application,
    options: ExecutionOptions,
) -> (
    String,
    Vec<StreamItem>,
    Option<StreamItem>,
    rurr_core::state::State,
) {
    let (action, mut handle) = mode
        .stream_result(app, options)
        .await
        .expect("stream_result should succeed");

    let mut items = Vec::new();
    while let Some(item) = handle.next_item().await.expect("next_item should succeed") {
        items.push(item);
    }
    let (terminal, state) = handle.get().await.expect("get should succeed");

    (action.name().to_string(), items, terminal, state)
}

async fn collect_stream_iterate_summary(
    mode: StreamMode,
    app: &mut Application,
    options: ExecutionOptions,
) -> (
    Vec<(String, Vec<StreamItem>, Option<StreamItem>)>,
    rurr_core::state::State,
) {
    let mut iterate = mode.stream_iterate(app, options).await;
    let mut steps = Vec::new();

    while let Some((action_name, mut step)) =
        iterate.next_step().await.expect("next_step should succeed")
    {
        let mut items = Vec::new();
        while let Some(item) = step
            .next_item()
            .await
            .expect("step next_item should succeed")
        {
            items.push(item);
        }
        let (terminal, _state) = step.get().await.expect("step get should succeed");
        steps.push((action_name, items, terminal));
    }
    drop(iterate);

    (steps, app.state().clone())
}

async fn assert_stream_result_direct_matches_runner(
    mode: StreamMode,
    options: ExecutionOptions,
    build_app: impl Fn() -> Application,
) {
    let mut direct = build_app();
    let mut runner = build_app();
    let direct_summary = collect_stream_result_summary(mode, &mut direct, options.clone()).await;
    let runner_summary = collect_stream_result_summary(mode, &mut runner, options).await;
    assert_eq!(direct_summary, runner_summary);
    assert_eq!(direct.state(), runner.state());
}

async fn assert_stream_iterate_direct_matches_runner(
    mode: StreamMode,
    options: ExecutionOptions,
    build_app: impl Fn() -> Application,
) {
    let mut direct = build_app();
    let mut runner = build_app();
    let direct_summary = collect_stream_iterate_summary(mode, &mut direct, options.clone()).await;
    let runner_summary = collect_stream_iterate_summary(mode, &mut runner, options).await;
    assert_eq!(direct_summary, runner_summary);
    assert_eq!(direct.state(), runner.state());
}

pub(crate) async fn assert_stream_result_direct_matches_runner_default(mode: StreamMode) {
    assert_stream_result_direct_matches_runner(
        mode,
        ExecutionOptions::new(),
        build_runner_parity_single_stream_app,
    )
    .await;
}

pub(crate) async fn assert_stream_result_direct_matches_runner_with_halt_after(mode: StreamMode) {
    assert_stream_result_direct_matches_runner(
        mode,
        ExecutionOptions::new().halt_after(["stream"]),
        build_runner_parity_stream_result_app,
    )
    .await;
}

pub(crate) async fn assert_stream_iterate_direct_matches_runner_default(mode: StreamMode) {
    assert_stream_iterate_direct_matches_runner(
        mode,
        ExecutionOptions::new(),
        build_runner_parity_single_stream_app,
    )
    .await;
}

pub(crate) async fn assert_stream_iterate_direct_matches_runner_with_halt_after(mode: StreamMode) {
    assert_stream_iterate_direct_matches_runner(
        mode,
        ExecutionOptions::new().halt_after(["stream"]),
        build_runner_parity_stream_result_app,
    )
    .await;
}

pub(crate) async fn assert_result_is_lazy_and_advances_one_item_per_next_item_call(
    mode: StreamMode,
) {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(Arc::clone(&stream_calls), 3, None);
    let mut app = build_streaming_app(action).expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = mode
        .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("stream_result should create");

    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);
    let first = stream_result
        .next_item()
        .await
        .expect("next_item should succeed")
        .expect("first item should exist");
    assert_eq!(first.get("count"), Some(&json!(1)));
    assert_eq!(stream_calls.load(Ordering::SeqCst), 1);

    let _second = stream_result
        .next_item()
        .await
        .expect("second next_item should succeed")
        .expect("second item should exist");
}

pub(crate) async fn assert_result_terminal_close_surfaces_post_execute_call_failure(
    mode: StreamMode,
) {
    let calls = Arc::new(AtomicUsize::new(0));
    let action = non_streaming_count_action(calls);
    let hook = match mode {
        StreamMode::Sync => Arc::new(LifecycleFailureHook::sync_post_execute()),
        StreamMode::Async => Arc::new(LifecycleFailureHook::async_post_execute()),
    };
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = hook;
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook]);

    let mut app = build_count_zero_action_app_with_hooks("non_stream", action, hooks)
        .expect("app should build");
    let halt_after = vec!["non_stream".to_string()];
    let (_action, mut stream_result) = mode
        .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("stream_result should create");

    let error = stream_result
        .get()
        .await
        .expect_err("post_execute_call failure should surface");
    assert!(
        matches!(
            error,
            ApplicationError::LifecycleHookFailed {
                phase: "post_execute_call",
                ..
            }
        ),
        "expected post_execute_call lifecycle failure, got: {error}"
    );
    assert!(
        error.to_string().contains(match mode {
            StreamMode::Sync => SYNC_POST_EXECUTE_FAILURE_MARKER,
            StreamMode::Async => ASYNC_POST_EXECUTE_FAILURE_MARKER,
        }),
        "error should include post_execute_call marker: {error}"
    );
    drop(stream_result);
    assert_eq!(app.state().get("count").cloned(), Some(json!(1)));
    assert_eq!(app.state().get("__SEQUENCE_ID").cloned(), Some(json!(0)));
}

pub(crate) async fn assert_result_failed_first_item_finishes_terminally(mode: StreamMode) {
    let mut app = build_streaming_error_app();
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = mode
        .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("stream_result should create");

    let error = stream_result
        .next_item()
        .await
        .expect_err("first stream item failure should surface");
    assert!(matches!(
        error,
        ApplicationError::StreamingActionFailed { .. }
    ));
    assert!(stream_result
        .next_item()
        .await
        .expect("subsequent next_item should be terminal")
        .is_none());

    fn build_streaming_error_app() -> Application {
        build_count_zero_action_app("stream", error_first_item_streaming_action())
            .expect("app should build")
    }
}

async fn assert_result_mid_stream_rolls_back_state_and_sequence_id(
    mode: StreamMode,
    rollback: MidStreamRollbackMode,
) {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let panic_after_item = match rollback {
        MidStreamRollbackMode::Drop => None,
        MidStreamRollbackMode::PanicOnSecondItem => Some(2),
    };
    let action = streaming_count_action(Arc::clone(&stream_calls), 3, panic_after_item);
    let mut app = build_streaming_app(action).expect("app should build");
    let halt_after = vec!["stream".to_string()];

    let (_action, mut stream_result) = mode
        .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("stream_result should create");
    let _ = stream_result
        .next_item()
        .await
        .expect("first next_item should succeed")
        .expect("first item should exist");
    if matches!(rollback, MidStreamRollbackMode::PanicOnSecondItem) {
        let second_error = stream_result
            .next_item()
            .await
            .expect_err("panic in stream iterator should return typed error");
        assert!(matches!(
            second_error,
            ApplicationError::PanicCaptured { scope, .. } if scope == mode.next_panic_scope()
        ));
    }
    drop(stream_result);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_result_drop_mid_stream_rolls_back_state_and_sequence_id(
    mode: StreamMode,
) {
    assert_result_mid_stream_rolls_back_state_and_sequence_id(mode, MidStreamRollbackMode::Drop)
        .await;
}

pub(crate) async fn assert_result_panic_mid_stream_rolls_back_state_and_sequence_id(
    mode: StreamMode,
) {
    assert_result_mid_stream_rolls_back_state_and_sequence_id(
        mode,
        MidStreamRollbackMode::PanicOnSecondItem,
    )
    .await;
}

pub(crate) async fn assert_iterate_is_lazy_until_next_step(mode: StreamMode) {
    let calls = Arc::new(AtomicUsize::new(0));
    let action = non_streaming_count_action(Arc::clone(&calls));
    let mut app = build_count_zero_action_app("non_stream", action).expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    assert_eq!(calls.load(Ordering::SeqCst), 0);

    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");
    let (_result, _state) = handle.get().await.expect("step get should succeed");
    drop(handle);
    assert_eq!(calls.load(Ordering::SeqCst), 1);
    assert!(
        iterate
            .next_step()
            .await
            .expect("second next_step should succeed")
            .is_none(),
        "{} should stop after the terminal step",
        mode.iterate_event_name()
    );
}

pub(crate) async fn assert_iterate_terminal_session_stays_terminal(mode: StreamMode) {
    let calls = Arc::new(AtomicUsize::new(0));
    let action = non_streaming_count_action(Arc::clone(&calls));
    let mut app = build_count_zero_action_app("non_stream", action).expect("app should build");

    let run_output = match mode {
        StreamMode::Sync => app.run().expect("run should complete"),
        StreamMode::Async => app.arun().await.expect("run should complete"),
    };
    assert_eq!(
        run_output.state.get("count").cloned(),
        Some(json!(1)),
        "setup run should leave the app terminal"
    );
    assert_eq!(calls.load(Ordering::SeqCst), 1);

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    assert!(
        iterate
            .next_step()
            .await
            .expect("terminal next_step should succeed")
            .is_none(),
        "completed {} should terminate immediately",
        mode.iterate_event_name()
    );
    assert_eq!(
        calls.load(Ordering::SeqCst),
        1,
        "completed {} must not execute another step",
        mode.iterate_event_name()
    );
    assert!(
        iterate
            .next_step()
            .await
            .expect("subsequent terminal next_step should succeed")
            .is_none(),
        "subsequent terminal {} polls should remain terminal",
        mode.iterate_event_name()
    );
}

#[derive(Clone, Copy)]
pub(crate) enum StreamResultFastForwardCase {
    ResolvedHaltAfter,
    HaltBeforeTarget,
    HaltBeforeCurrentTerminal,
    MissingHaltTarget,
    ResumedOverlapPrefersHaltAfter,
    PreTargetRunOnlyGuard,
}

fn build_fast_forward_target_app() -> (Application, Arc<AtomicUsize>, Arc<AtomicUsize>) {
    let non_stream_calls = Arc::new(AtomicUsize::new(0));
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let non_stream = non_streaming_count_action(Arc::clone(&non_stream_calls));
    let stream_action = streaming_count_action(Arc::clone(&stream_calls), 3, None);
    let app = build_count_zero_transition_app(
        "A",
        non_stream,
        "B",
        stream_action,
        vec![Transition::new("A", "B", Condition::default())],
    )
    .expect("app should build");
    (app, non_stream_calls, stream_calls)
}

pub(crate) async fn assert_stream_result_fast_forward_case(
    mode: StreamMode,
    case: StreamResultFastForwardCase,
) {
    match case {
        StreamResultFastForwardCase::ResolvedHaltAfter => {
            let (mut app, non_stream_calls, stream_calls) = build_fast_forward_target_app();
            let halt_after = vec!["B".to_string()];
            let (action, mut stream_result) = mode
                .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
                .await
                .expect("stream_result should create");

            assert_eq!(action.name(), "B");
            assert_eq!(non_stream_calls.load(Ordering::SeqCst), 1);
            assert_eq!(stream_calls.load(Ordering::SeqCst), 0);
            let first = stream_result
                .next_item()
                .await
                .expect("next_item should succeed")
                .expect("first item should exist");
            assert_eq!(first.get("count"), Some(&json!(2)));
            assert_eq!(stream_calls.load(Ordering::SeqCst), 1);
        }
        StreamResultFastForwardCase::HaltBeforeTarget => {
            let (mut app, non_stream_calls, stream_calls) = build_fast_forward_target_app();
            let halt_before = vec!["B".to_string()];
            let (action, mut stream_result) = mode
                .stream_result(&mut app, ExecutionOptions::new().halt_before(halt_before))
                .await
                .expect("stream_result should create");

            assert_eq!(action.name(), "B");
            assert_eq!(non_stream_calls.load(Ordering::SeqCst), 1);
            assert_eq!(stream_calls.load(Ordering::SeqCst), 0);
            assert!(stream_result
                .next_item()
                .await
                .expect("next_item should succeed")
                .is_none());
            let (result, state) = stream_result.get().await.expect("get should succeed");
            assert!(result.is_none());
            assert_eq!(state.get("count").cloned(), Some(json!(1)));
        }
        StreamResultFastForwardCase::HaltBeforeCurrentTerminal => {
            let calls = Arc::new(AtomicUsize::new(0));
            let action = non_streaming_count_action(Arc::clone(&calls));
            let mut app = build_count_zero_action_app("A", action).expect("app should build");

            let halt_before = vec!["A".to_string()];
            let (action, mut stream_result) = mode
                .stream_result(&mut app, ExecutionOptions::new().halt_before(halt_before))
                .await
                .expect("stream_result should create");

            assert_eq!(action.name(), "A");
            assert_eq!(calls.load(Ordering::SeqCst), 1);
            assert!(stream_result
                .next_item()
                .await
                .expect("next_item should succeed")
                .is_none());

            let (result, state) = stream_result.get().await.expect("get should succeed");
            assert_eq!(
                result,
                Some(indexmap::IndexMap::from([("count".to_string(), json!(1))]))
            );
            assert_eq!(state.get("count").cloned(), Some(json!(1)));
        }
        StreamResultFastForwardCase::MissingHaltTarget => {
            let calls = Arc::new(AtomicUsize::new(0));
            let target_calls = Arc::new(AtomicUsize::new(0));
            let action = non_streaming_count_action(Arc::clone(&calls));
            let target = non_streaming_count_action(Arc::clone(&target_calls));
            let mut app = build_count_zero_transition_app("A", action, "B", target, Vec::new())
                .expect("app should build");

            let halt_before = vec!["B".to_string()];
            let err = match mode
                .stream_result(&mut app, ExecutionOptions::new().halt_before(halt_before))
                .await
            {
                Ok(_) => panic!("missing halt target should still error on graph exhaustion"),
                Err(err) => err,
            };

            assert!(matches!(
                err,
                ApplicationError::NoNextActionForStreaming { prior_step: Some(ref prior_step) }
                    if prior_step == "A"
            ));
            assert_eq!(calls.load(Ordering::SeqCst), 1);
            assert_eq!(target_calls.load(Ordering::SeqCst), 0);
            assert_eq!(app.state().get("count").cloned(), Some(json!(1)));
        }
        StreamResultFastForwardCase::ResumedOverlapPrefersHaltAfter => {
            let (mut app, non_stream_calls, stream_calls) = build_fast_forward_target_app();
            let first_step = match mode {
                StreamMode::Sync => app.step(None).expect("first step should execute"),
                StreamMode::Async => app.astep(None).await.expect("first step should execute"),
            }
            .expect("first step output should exist");
            assert_eq!(first_step.action.name(), "A");
            assert_eq!(non_stream_calls.load(Ordering::SeqCst), 1);
            assert_eq!(app.state().get("count").cloned(), Some(json!(1)));

            let overlap_halt_before = vec!["B".to_string()];
            let overlap_halt_after = vec!["B".to_string()];
            let (action, mut stream_result) = mode
                .stream_result(
                    &mut app,
                    ExecutionOptions::new()
                        .halt_before(overlap_halt_before)
                        .halt_after(overlap_halt_after),
                )
                .await
                .expect("stream_result should create");

            assert_eq!(action.name(), "B");
            assert_eq!(non_stream_calls.load(Ordering::SeqCst), 1);
            assert_eq!(stream_calls.load(Ordering::SeqCst), 0);

            let first = stream_result
                .next_item()
                .await
                .expect("next_item should succeed")
                .expect("overlap should stream target instead of halting before");
            assert_eq!(first.get("count"), Some(&json!(2)));
            assert_eq!(stream_calls.load(Ordering::SeqCst), 1);

            let (result, state) = stream_result.get().await.expect("get should succeed");
            assert_eq!(
                result,
                Some(indexmap::IndexMap::from([("count".to_string(), json!(4))]))
            );
            assert_eq!(state.get("count").cloned(), Some(json!(4)));
        }
        StreamResultFastForwardCase::PreTargetRunOnlyGuard => {
            let pre_target_run_calls = Arc::new(AtomicUsize::new(0));
            let pre_target_stream_attempts = Arc::new(AtomicUsize::new(0));
            let pre_target = pre_target_run_only_action(
                Arc::clone(&pre_target_run_calls),
                Arc::clone(&pre_target_stream_attempts),
            );
            let target_calls = Arc::new(AtomicUsize::new(0));
            let target = streaming_count_action(Arc::clone(&target_calls), 2, None);
            let mut app =
                build_pre_target_stream_guard_app(pre_target, target).expect("app should build");

            let halt_after = vec!["B".to_string()];
            let (action, mut stream_result) = mode
                .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
                .await
                .expect("stream_result should create");

            assert_eq!(action.name(), "B");
            assert_eq!(pre_target_run_calls.load(Ordering::SeqCst), 1);
            assert_eq!(pre_target_stream_attempts.load(Ordering::SeqCst), 0);
            assert_eq!(target_calls.load(Ordering::SeqCst), 0);

            let first = stream_result
                .next_item()
                .await
                .expect("next_item should succeed")
                .expect("first stream item should exist");
            assert_eq!(first.get("count"), Some(&json!(2)));
            assert_eq!(target_calls.load(Ordering::SeqCst), 1);
        }
    }
}

#[derive(Clone, Copy)]
pub(crate) enum UpdateTraceDrive {
    Iterate,
    Result,
}

pub(crate) async fn assert_non_streaming_update_trace_emits_span_hooks(
    mode: StreamMode,
    drive: UpdateTraceDrive,
) {
    let events = Arc::new(UpdateTraceSpanEvents::default());
    let sync_hook: Arc<dyn SyncLifecycleAdapter> =
        Arc::new(UpdateTraceSpanHook::new(Arc::clone(&events)));
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![]);
    let mut app = build_update_tracing_non_streaming_app_with_hooks(hooks).expect("app builds");

    match drive {
        UpdateTraceDrive::Iterate => {
            let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
            let (executed, mut handle) = iterate
                .next_step()
                .await
                .expect("next_step should succeed")
                .expect("step should exist");
            assert_eq!(executed, "non_stream");
            assert!(handle
                .next_item()
                .await
                .expect("next_item should evaluate non-streaming action")
                .is_none());
            let (terminal, state) = handle
                .get()
                .await
                .expect("get should return cached terminal");
            assert_eq!(
                terminal,
                Some(IndexMap::from([("count".to_string(), json!(1))]))
            );
            assert_eq!(state.get("count").cloned(), Some(json!(1)));
        }
        UpdateTraceDrive::Result => {
            let halt_after = vec!["non_stream".to_string()];
            let (_action, mut stream_result) = mode
                .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
                .await
                .expect("stream_result should create");
            assert!(stream_result
                .next_item()
                .await
                .expect("next_item should evaluate non-streaming action")
                .is_none());
            let (terminal, state) = stream_result
                .get()
                .await
                .expect("get should return terminal");
            assert_eq!(
                terminal,
                Some(IndexMap::from([("count".to_string(), json!(1))]))
            );
            assert_eq!(state.get("count").cloned(), Some(json!(1)));
        }
    }

    assert_single_update_trace_span(events.as_ref());
}

#[derive(Clone, Copy)]
pub(crate) enum SyncFinishFailurePhase {
    PostRunStep,
    PostEndStream,
}

impl SyncFinishFailurePhase {
    fn hook(self) -> LifecycleFailureHook {
        match self {
            Self::PostRunStep => LifecycleFailureHook::sync_post_run_step(),
            Self::PostEndStream => LifecycleFailureHook::sync_post_end_stream(),
        }
    }

    const fn phase_name(self) -> &'static str {
        match self {
            Self::PostRunStep => "post_run_step",
            Self::PostEndStream => "post_end_stream",
        }
    }

    const fn marker(self) -> &'static str {
        match self {
            Self::PostRunStep => SYNC_POST_RUN_STEP_FAILURE_MARKER,
            Self::PostEndStream => SYNC_POST_END_STREAM_FAILURE_MARKER,
        }
    }
}

fn assert_sync_finish_failure(error: &ApplicationError, phase: SyncFinishFailurePhase) {
    assert!(
        matches!(
            error,
            ApplicationError::LifecycleHookFailed {
                phase: actual_phase,
                ..
            } if *actual_phase == phase.phase_name()
        ),
        "expected {} lifecycle failure, got: {error}",
        phase.phase_name()
    );
    assert!(
        error.to_string().contains(phase.marker()),
        "error should include {} marker: {error}",
        phase.phase_name()
    );
}

pub(crate) async fn assert_sync_stream_result_rollback_surfaces_finish_failure(
    phase: SyncFinishFailurePhase,
) {
    let action = error_first_item_streaming_action();
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = Arc::new(phase.hook());
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![]);
    let mut app = build_error_streaming_app_with_hooks(action, hooks).expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = app
        .stream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .expect("stream_result should create");

    let error = stream_result
        .next_item()
        .expect_err("rollback should surface finish-hook failure");
    assert_sync_finish_failure(&error, phase);
    drop(stream_result);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_sync_step_handle_drop_mid_stream_surfaces_finish_failure(
    phase: SyncFinishFailurePhase,
) {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(Arc::clone(&stream_calls), 3, None);
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = Arc::new(phase.hook());
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![]);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");

    let mut iterate = app.stream_iterate();
    let (_action, mut handle) = iterate
        .next_step()
        .expect("next_step should succeed")
        .expect("step should exist");
    let first = handle
        .next_item()
        .expect("first next_item should succeed")
        .expect("first item should exist");
    assert_eq!(first.get("count"), Some(&json!(1)));
    drop(handle);

    let error = match iterate.next_step() {
        Ok(_) => panic!("drop cleanup should surface finish-hook failure"),
        Err(error) => error,
    };
    assert_sync_finish_failure(&error, phase);
    assert!(
        !matches!(error, ApplicationError::StreamInvariantViolation { .. }),
        "drop cleanup must not degrade into stream invariant noise: {error}"
    );

    drop(iterate);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_sync_result_post_stream_item_failure_preserves_rollback_state() {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(Arc::clone(&stream_calls), 3, None);
    let sync_hook: Arc<dyn SyncLifecycleAdapter> =
        Arc::new(LifecycleFailureHook::sync_post_stream_item_and_post_run_step());
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![]);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");
    let halt_after = vec!["stream".to_string()];

    let (_action, mut stream_result) = app
        .stream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .expect("stream_result should create");

    let error = stream_result
        .next_item()
        .expect_err("post_stream_item failure should surface hook failure");
    assert!(
        matches!(
            error,
            ApplicationError::LifecycleHookFailed {
                phase: "post_run_step",
                ..
            }
        ),
        "expected post_run_step lifecycle failure to remain visible, got: {error}"
    );
    assert!(
        error
            .to_string()
            .contains(SYNC_POST_RUN_STEP_FAILURE_MARKER),
        "error should include sync post_run_step marker: {error}"
    );
    assert!(
        !matches!(error, ApplicationError::StreamInvariantViolation { .. }),
        "error must not degrade into stream invariant noise: {error}"
    );

    let (terminal, state) = stream_result
        .get()
        .expect("get should return rolled-back state after hook failure");
    assert!(
        terminal.is_none(),
        "rollback should not commit terminal item"
    );
    assert_zero_count_without_sequence_id_in_state(&state);

    drop(stream_result);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_async_result_post_stream_item_failure_preserves_rollback_state() {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(Arc::clone(&stream_calls), 3, None);
    let async_hook: Arc<dyn AsyncLifecycleAdapter> =
        Arc::new(LifecycleFailureHook::async_post_stream_item_and_post_run_step());
    let hooks = LifecycleAdapterSet::new(vec![], vec![async_hook]);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");
    let halt_after = vec!["stream".to_string()];

    let (_action, mut stream_result) = app
        .astream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("astream_result should create");

    let error = stream_result
        .next_item()
        .await
        .expect_err("async post_stream_item failure should surface hook failure");
    assert!(
        matches!(
            error,
            ApplicationError::LifecycleHookFailed {
                phase: "post_run_step",
                ..
            }
        ),
        "expected async post_run_step lifecycle failure to remain visible, got: {error}"
    );
    assert!(
        error
            .to_string()
            .contains(ASYNC_POST_RUN_STEP_FAILURE_MARKER),
        "error should include async post_run_step marker: {error}"
    );
    assert!(
        !matches!(error, ApplicationError::StreamInvariantViolation { .. }),
        "error must not degrade into stream invariant noise: {error}"
    );

    let (terminal, state) = stream_result
        .get()
        .await
        .expect("get should return rolled-back state after async hook failure");
    assert!(
        terminal.is_none(),
        "rollback should not commit terminal item"
    );
    assert_zero_count_without_sequence_id_in_state(&state);

    drop(stream_result);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) fn counting_hooks(counts: &Arc<StreamAbortHookCounts>) -> LifecycleAdapterSet {
    let hook = Arc::new(LifecycleHookRecorder::counting(Arc::clone(counts)));
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = hook;
    LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook])
}

pub(crate) fn assert_execute_boundary_counts(counts: &StreamAbortHookCounts, mode: StreamMode) {
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    match mode {
        StreamMode::Sync => {
            assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 0);
            assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 0);
        }
        StreamMode::Async => {
            assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 1);
            assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 1);
        }
    }
}

fn assert_all_stream_phase_counts_once(counts: &StreamAbortHookCounts) {
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_end_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_end_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 1);
}

pub(crate) async fn assert_iterate_error_boundary_surfaces_post_execute_call_failure(
    mode: StreamMode,
) {
    let hook = match mode {
        StreamMode::Sync => Arc::new(LifecycleFailureHook::sync_post_execute()),
        StreamMode::Async => Arc::new(LifecycleFailureHook::async_post_execute()),
    };
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = hook;
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook]);
    let action = error_first_item_streaming_action();
    let mut app = build_error_streaming_app_with_hooks(action, hooks).expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");

    let error = handle
        .next_item()
        .await
        .expect_err("post_execute_call failure should override stream item error");
    assert!(
        matches!(
            error,
            ApplicationError::LifecycleHookFailed {
                phase: "post_execute_call",
                ..
            }
        ),
        "expected post_execute_call lifecycle failure, got: {error}"
    );
    assert!(
        error.to_string().contains(match mode {
            StreamMode::Sync => SYNC_POST_EXECUTE_FAILURE_MARKER,
            StreamMode::Async => ASYNC_POST_EXECUTE_FAILURE_MARKER,
        }),
        "error should include post_execute_call marker: {error}"
    );

    drop(handle);
    drop(iterate);
    assert_zero_count_without_sequence_id_in_app(&app);
}

#[derive(Clone, Copy)]
enum IterateErrorAccess {
    NextItem,
    Get,
}

async fn assert_iterate_error_access_closes_session_immediately(
    mode: StreamMode,
    access: IterateErrorAccess,
) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let mut app = build_error_streaming_app_with_hooks(
        error_first_item_streaming_action(),
        counting_hooks(&counts),
    )
    .expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");

    match access {
        IterateErrorAccess::NextItem => assert!(matches!(
            handle.next_item().await,
            Err(ApplicationError::StreamingActionFailed { .. })
        )),
        IterateErrorAccess::Get => assert!(matches!(
            handle.get().await,
            Err(ApplicationError::StreamingActionFailed { .. })
        )),
    }
    drop(handle);

    assert_execute_boundary_counts(counts.as_ref(), mode);
    assert!(iterate
        .next_step()
        .await
        .expect("errored stream iterate session should be terminal")
        .is_none());
    drop(iterate);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_iterate_next_item_error_closes_session_immediately(mode: StreamMode) {
    assert_iterate_error_access_closes_session_immediately(mode, IterateErrorAccess::NextItem)
        .await;
}

pub(crate) async fn assert_iterate_get_error_closes_session_immediately(mode: StreamMode) {
    assert_iterate_error_access_closes_session_immediately(mode, IterateErrorAccess::Get).await;
}

#[derive(Clone, Copy)]
pub(crate) enum AsyncNonStreamingFailureKind {
    Run,
    Update,
}

pub(crate) async fn assert_astream_iterate_non_streaming_failure_runs_post_step_once(
    failure: AsyncNonStreamingFailureKind,
) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let hooks = counting_hooks(&counts);

    let mut app = match failure {
        AsyncNonStreamingFailureKind::Run => {
            build_async_run_failure_non_streaming_app_with_hooks(hooks)
        }
        AsyncNonStreamingFailureKind::Update => build_failing_update_non_streaming_app_with_hooks(
            failing_update_action(Arc::new(AtomicUsize::new(0))),
            hooks,
        ),
    }
    .expect("app should build");

    let mut iterate = app.astream_iterate().await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");

    let err = handle.get().await;
    assert!(matches!(
        err,
        Err(ApplicationError::Action(ActionError::Internal { .. }))
    ));
    drop(handle);

    assert_all_stream_phase_counts_once(counts.as_ref());
    assert!(iterate
        .next_step()
        .await
        .expect("errored async stream iterate session should be terminal")
        .is_none());
    drop(iterate);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_iterate_commit_failure_records_post_step_exception_and_rolls_back(
    mode: StreamMode,
) {
    let exception_recorder = Arc::new(PostStepExceptionRecorder::default());
    let recorder_hook = Arc::new(LifecycleHookRecorder::exceptions(Arc::clone(
        &exception_recorder,
    )));
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = recorder_hook.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = recorder_hook;
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook]);
    let persister: Arc<dyn BaseStatePersister> = Arc::new(FailingCommitPersister);
    let action = streaming_count_action(Arc::new(AtomicUsize::new(0)), 1, None);
    let mut app = build_streaming_app_with_hooks_and_persister(action, hooks, persister)
        .expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");

    let error = handle
        .get()
        .await
        .expect_err("terminal commit should fail when persister save fails");
    assert!(
        error
            .to_string()
            .contains("intentional_stream_commit_failure"),
        "error should include persister failure details: {error}"
    );

    drop(handle);
    assert!(iterate
        .next_step()
        .await
        .expect("failed stream iterate session should be terminal")
        .is_none());
    drop(iterate);

    assert_zero_count_without_sequence_id_in_app(&app);
    let sync_exceptions = exception_recorder.sync_exceptions();
    assert_eq!(sync_exceptions.len(), 1, "expected one sync post_run_step");
    assert!(
        sync_exceptions[0]
            .as_deref()
            .is_some_and(|exception| exception.contains("intentional_stream_commit_failure")),
        "sync post_run_step should include commit failure exception: {sync_exceptions:?}"
    );

    if mode == StreamMode::Async {
        let async_exceptions = exception_recorder.async_exceptions();
        assert_eq!(
            async_exceptions.len(),
            1,
            "expected one async post_run_step"
        );
        assert!(
            async_exceptions[0]
                .as_deref()
                .is_some_and(|exception| exception.contains("intentional_stream_commit_failure")),
            "async post_run_step should include commit failure exception: {async_exceptions:?}"
        );
    }
}

pub(crate) async fn assert_iterate_abort_closes_session_immediately(mode: StreamMode) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let action = streaming_count_action(Arc::new(AtomicUsize::new(0)), 3, None);
    let mut app =
        build_streaming_app_with_hooks(action, counting_hooks(&counts)).expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    iterate.abort().await.expect("abort should close session");

    assert_execute_boundary_counts(counts.as_ref(), mode);
    assert!(iterate
        .next_step()
        .await
        .expect("aborted stream iterate session should be terminal")
        .is_none());
    drop(iterate);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    if mode == StreamMode::Async {
        assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 1);
    }
    assert_zero_count_without_sequence_id_in_app(&app);
}

#[derive(Clone, Copy)]
pub(crate) enum AsyncDropWithoutAbortTarget {
    Iterate,
    Result,
}

pub(crate) async fn assert_astream_drop_without_abort_runs_sync_post_execute_call_only(
    target: AsyncDropWithoutAbortTarget,
) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(stream_calls, 3, None);
    let mut app =
        build_streaming_app_with_hooks(action, counting_hooks(&counts)).expect("app should build");

    match target {
        AsyncDropWithoutAbortTarget::Iterate => {
            let iterate = app.astream_iterate().await;
            drop(iterate);
        }
        AsyncDropWithoutAbortTarget::Result => {
            let halt_after = vec!["stream".to_string()];
            let (_action, stream_result) = app
                .astream_result_with_options(
                    rurr_core::ExecutionOptions::new().halt_after(halt_after),
                )
                .await
                .expect("astream_result should create");
            drop(stream_result);
        }
    }

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 0);
    assert_zero_count_without_sequence_id_in_app(&app);
}

#[derive(Clone, Copy)]
pub(crate) enum AsyncAbortFailurePhase {
    PostRunStep,
    PostEndStream,
}

impl AsyncAbortFailurePhase {
    fn hook(self) -> LifecycleFailureHook {
        match self {
            Self::PostRunStep => LifecycleFailureHook::async_post_run_step(),
            Self::PostEndStream => LifecycleFailureHook::async_post_end_stream(),
        }
    }

    const fn phase_name(self) -> &'static str {
        match self {
            Self::PostRunStep => "post_run_step",
            Self::PostEndStream => "post_end_stream",
        }
    }

    const fn marker(self) -> &'static str {
        match self {
            Self::PostRunStep => ASYNC_POST_RUN_STEP_FAILURE_MARKER,
            Self::PostEndStream => ASYNC_POST_END_STREAM_FAILURE_MARKER,
        }
    }
}

pub(crate) async fn assert_astream_step_handle_abort_surfaces_async_finish_failure(
    phase: AsyncAbortFailurePhase,
) {
    let action = streaming_count_action(Arc::new(AtomicUsize::new(0)), 3, None);
    let hook: Arc<dyn AsyncLifecycleAdapter> = Arc::new(phase.hook());
    let hooks = LifecycleAdapterSet::new(vec![], vec![hook]);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");

    let mut iterate = app.astream_iterate().await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");

    let error = handle
        .abort()
        .await
        .expect_err("abort should surface async finish-hook failure");
    assert!(
        matches!(
            error,
            ApplicationError::LifecycleHookFailed {
                phase: actual_phase,
                ..
            } if actual_phase == phase.phase_name()
        ),
        "expected {} lifecycle failure, got: {error}",
        phase.phase_name()
    );
    assert!(
        error.to_string().contains(phase.marker()),
        "error should include {} marker: {error}",
        phase.phase_name()
    );
    assert!(
        !matches!(error, ApplicationError::StreamInvariantViolation { .. }),
        "abort should surface hook failure, not stream invariant noise: {error}"
    );

    drop(handle);
    iterate
        .abort()
        .await
        .expect("session abort should remain valid after handle abort failure");
    drop(iterate);
    assert_zero_count_without_sequence_id_in_app(&app);
}

#[derive(Clone, Copy)]
pub(crate) enum AsyncPendingPollCleanup {
    Abort,
    Drop,
}

fn assert_async_pending_poll_cleanup_counts(
    counts: &StreamAbortHookCounts,
    cleanup: AsyncPendingPollCleanup,
) {
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_end_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(
        counts.async_post_execute_call.load(Ordering::SeqCst),
        usize::from(matches!(cleanup, AsyncPendingPollCleanup::Abort))
    );
    assert_eq!(counts.async_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(
        counts.async_post_run_step.load(Ordering::SeqCst),
        usize::from(matches!(cleanup, AsyncPendingPollCleanup::Abort))
    );
    assert_eq!(counts.async_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(
        counts.async_post_end_stream.load(Ordering::SeqCst),
        usize::from(matches!(cleanup, AsyncPendingPollCleanup::Abort))
    );
}

pub(crate) async fn assert_astream_result_cleanup_after_pending_poll_runs_expected_hooks(
    cleanup: AsyncPendingPollCleanup,
) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let pending_polls = Arc::new(AtomicUsize::new(0));
    let action = never_ready_async_stream_action(Arc::clone(&pending_polls));
    let mut app = build_never_ready_async_streaming_app_with_hooks(action, counting_hooks(&counts))
        .expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = app
        .astream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("astream_result should create");

    {
        let next_future = stream_result.next();
        tokio::pin!(next_future);
        poll_fn(
            |cx| match std::future::Future::poll(next_future.as_mut(), cx) {
                Poll::Pending => Poll::Ready(()),
                Poll::Ready(output) => {
                    panic!("never-ready stream unexpectedly produced output: {output:?}")
                }
            },
        )
        .await;
    }

    match cleanup {
        AsyncPendingPollCleanup::Abort => {
            tokio::time::timeout(Duration::from_millis(100), stream_result.abort())
                .await
                .expect("abort should complete after cancelling the in-flight poll")
                .expect("abort should succeed");
            drop(stream_result);
        }
        AsyncPendingPollCleanup::Drop => drop(stream_result),
    }

    assert_async_pending_poll_cleanup_counts(counts.as_ref(), cleanup);
    assert!(
        pending_polls.load(Ordering::SeqCst) > 0,
        "pending path should have been polled at least once"
    );
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_result_pre_target_failure_does_not_poison_session_or_state(
    mode: StreamMode,
) {
    let failing_calls = Arc::new(AtomicUsize::new(0));
    let mut app = build_pre_target_failure_app(Arc::clone(&failing_calls)).expect("app builds");
    let halt_after = vec!["target".to_string()];
    let error = match mode
        .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
        .await
    {
        Ok(_) => panic!("pre-target failure should surface during stream_result construction"),
        Err(error) => error,
    };
    assert!(matches!(
        error,
        ApplicationError::Action(ActionError::Internal { .. })
    ));
    assert_eq!(failing_calls.load(Ordering::SeqCst), 1);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_result_empty_custom_stream_does_not_invoke_run_fallback(
    mode: StreamMode,
) {
    let run_calls = Arc::new(AtomicUsize::new(0));
    let run_async_calls = Arc::new(AtomicUsize::new(0));
    let action =
        empty_streaming_source_action(Arc::clone(&run_calls), Arc::clone(&run_async_calls));
    let mut app = build_empty_streaming_source_app(action).expect("app should build");

    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = mode
        .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("stream_result should create");
    assert!(stream_result
        .next_item()
        .await
        .expect("next_item should succeed")
        .is_none());
    let (terminal, state) = stream_result.get().await.expect("get should succeed");
    assert!(
        terminal.is_none(),
        "empty custom stream must remain uncommitted"
    );
    assert_eq!(state.get("count").cloned(), Some(json!(0)));
    assert_eq!(run_calls.load(Ordering::SeqCst), 0);
    assert_eq!(run_async_calls.load(Ordering::SeqCst), 0);
    assert!(stream_result
        .next_item()
        .await
        .expect("subsequent next_item should remain terminal")
        .is_none());
}

async fn assert_iterate_uncommitted_stream_does_not_mark_session_committed(
    mode: StreamMode,
    completion: UncommittedStreamCompletion,
) {
    let calls = Arc::new(AtomicUsize::new(0));
    let action = uncommitted_streaming_action(Arc::clone(&calls));
    let mut app = build_uncommitted_streaming_app(action).expect("app should build");

    let halt_before = vec!["stream".to_string()];
    let mut iterate = mode
        .stream_iterate(&mut app, ExecutionOptions::new().halt_before(halt_before))
        .await;
    {
        let (executed, mut handle) = iterate
            .next_step()
            .await
            .expect("first next_step should succeed")
            .expect("first step should exist");
        assert_eq!(executed, "stream");
        if matches!(
            completion,
            UncommittedStreamCompletion::DriveToTerminalThenGet
        ) {
            let first = handle
                .next_item()
                .await
                .expect("first next_item should succeed")
                .expect("first uncommitted stream item should exist");
            assert_eq!(first.get("count"), Some(&json!(1)));
            assert!(handle
                .next_item()
                .await
                .expect("second next_item should finalize the uncommitted stream")
                .is_none());
        }
        let (terminal, state) = handle.get().await.expect(match completion {
            UncommittedStreamCompletion::GetOnly => "uncommitted step get should succeed",
            UncommittedStreamCompletion::DriveToTerminalThenGet => {
                "get should return cached terminal after completion"
            }
        });
        assert!(
            terminal.is_none(),
            "uncommitted stream should not have terminal item"
        );
        assert_uncommitted_stream_state(&state);
    }
    assert_eq!(calls.load(Ordering::SeqCst), 1);

    let (executed_again, _handle) = iterate
        .next_step()
        .await
        .expect("second next_step should succeed")
        .expect("halt_before should not trigger for an uncommitted prior step");
    assert_eq!(executed_again, "stream");
}

pub(crate) async fn assert_iterate_uncommitted_stream_get_does_not_mark_session_committed(
    mode: StreamMode,
) {
    assert_iterate_uncommitted_stream_does_not_mark_session_committed(
        mode,
        UncommittedStreamCompletion::GetOnly,
    )
    .await;
}

pub(crate) async fn assert_iterate_uncommitted_stream_next_item_completion_does_not_mark_session_committed(
    mode: StreamMode,
) {
    assert_iterate_uncommitted_stream_does_not_mark_session_committed(
        mode,
        UncommittedStreamCompletion::DriveToTerminalThenGet,
    )
    .await;
}

pub(crate) async fn assert_step_handle_get_is_idempotent_after_next_item_completion(
    mode: StreamMode,
) {
    let calls = Arc::new(AtomicUsize::new(0));
    let action = non_streaming_count_action(Arc::clone(&calls));
    let mut app = build_count_zero_action_app("non_stream", action).expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");

    assert!(handle
        .next_item()
        .await
        .expect("next_item should evaluate non-streaming action")
        .is_none());
    let (terminal, state) = handle
        .get()
        .await
        .expect("get should return cached terminal");
    assert_eq!(
        terminal,
        Some(IndexMap::from([("count".to_string(), json!(1))]))
    );
    assert_eq!(state.get("count").cloned(), Some(json!(1)));
}

pub(crate) async fn assert_step_handle_error_then_next_item_is_terminal_none(mode: StreamMode) {
    let action = error_first_item_streaming_action();
    let mut app = build_error_streaming_app(action).expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");

    let first = handle.next_item().await;
    assert!(matches!(
        first,
        Err(ApplicationError::StreamingActionFailed { .. })
    ));

    assert!(handle
        .next_item()
        .await
        .expect("subsequent next_item should be terminal")
        .is_none());
    let (terminal, state) = handle
        .get()
        .await
        .expect("get should return cached terminal after error");
    assert!(terminal.is_none());
    assert_zero_count_without_sequence_id_in_state(&state);

    drop(handle);
    drop(iterate);
    assert_zero_count_without_sequence_id_in_app(&app);
}

pub(crate) async fn assert_result_accepts_non_send_stream_sources(mode: StreamMode) {
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = non_send_streaming_action(Arc::clone(&stream_calls));
    let mut app = build_non_send_streaming_app(action).expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = mode
        .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("stream_result should create");

    let first = stream_result
        .next_item()
        .await
        .expect("next_item should succeed")
        .expect("first item should exist");
    assert_eq!(first.get("count"), Some(&json!(1)));
    assert_eq!(stream_calls.load(Ordering::SeqCst), 1);

    assert!(stream_result
        .next_item()
        .await
        .expect("terminal advance should succeed")
        .is_none());
    let (terminal, state) = stream_result.get().await.expect("get should succeed");
    assert_eq!(
        terminal,
        Some(IndexMap::from([("count".to_string(), json!(2))]))
    );
    assert_eq!(state.get("count").cloned(), Some(json!(2)));
}
