#[cfg(any(feature = "postgres", feature = "redis", feature = "mongodb"))]
use super::support::map_from_pairs;
#[cfg(any(
    not(feature = "postgres"),
    not(feature = "redis"),
    not(feature = "mongodb")
))]
use super::support::skip_feature;
#[cfg(any(feature = "postgres", feature = "redis", feature = "mongodb"))]
use super::support::unique_id;
#[cfg(any(feature = "postgres", feature = "redis"))]
use futures::FutureExt;
#[cfg(feature = "postgres")]
use indexmap::IndexMap;
#[cfg(feature = "postgres")]
use rurr_core::action::FunctionActionBuilder;
#[cfg(feature = "postgres")]
use rurr_core::application::ApplicationBuilder;
#[cfg(any(feature = "postgres", feature = "redis", feature = "mongodb"))]
use rurr_core::common::panic::panic_payload_to_string;
#[cfg(feature = "postgres")]
use rurr_core::graph::Transition;
#[cfg(feature = "postgres")]
use rurr_core::state::State;
#[cfg(feature = "postgres")]
use rurr_core::GraphAction;
#[cfg(any(feature = "postgres", feature = "redis", feature = "mongodb"))]
use rurr_persistence::BaseStateSaver;
#[cfg(any(feature = "postgres", feature = "redis", feature = "mongodb"))]
use serde_json::{json, Value};
#[cfg(any(feature = "postgres", feature = "redis"))]
use std::future::Future;
#[cfg(any(feature = "postgres", feature = "redis", feature = "mongodb"))]
use std::panic::{catch_unwind, AssertUnwindSafe};
#[cfg(feature = "postgres")]
use std::sync::Arc;

#[cfg(any(feature = "postgres", feature = "redis", feature = "mongodb"))]
fn assert_sync_persistence_smoke<P>(persister: &P, app_id: &str)
where
    P: rurr_persistence::BaseStateLoader + rurr_persistence::BaseStateSaver,
{
    use rurr_persistence::PersistedStateStatus;

    persister
        .save(
            Some("pk"),
            app_id,
            1,
            "step",
            map_from_pairs([("value", json!("ok"))]),
            PersistedStateStatus::Completed,
        )
        .expect("sync persistence save should succeed");

    let loaded = persister
        .load(Some("pk"), Some(app_id), None)
        .expect("sync persistence load should succeed")
        .expect("sync persistence should return saved state");

    assert_eq!(loaded.app_id, app_id);
    assert_eq!(loaded.sequence_id, 1);
    assert_eq!(
        loaded
            .state
            .as_ref()
            .and_then(|state| state.get("value"))
            .and_then(Value::as_str),
        Some("ok")
    );
}

#[cfg(any(feature = "postgres", feature = "redis", feature = "mongodb"))]
fn run_live_sync_smoke_case_with_cleanup<Body, Cleanup, Verify, E>(
    body: Body,
    cleanup: Cleanup,
    verify_cleanup: Verify,
) where
    Body: FnOnce(),
    Cleanup: FnOnce() -> Result<(), E>,
    Verify: FnOnce(),
    E: std::fmt::Display,
{
    let result = catch_unwind(AssertUnwindSafe(body));
    let cleanup_result = cleanup();

    match result {
        Ok(()) => {
            cleanup_result.unwrap_or_else(|error| panic!("live cleanup should succeed: {error}"));
            verify_cleanup();
        }
        Err(payload) => match cleanup_result {
            Ok(()) => std::panic::resume_unwind(payload),
            Err(cleanup_error) => panic!(
                "live cleanup should succeed: body_panic={}; cleanup_error={cleanup_error}",
                panic_payload_to_string(payload),
            ),
        },
    }
}

#[cfg(any(feature = "postgres", feature = "redis"))]
async fn run_live_async_smoke_case_with_cleanup<
    BodyFuture,
    Cleanup,
    CleanupFuture,
    Verify,
    VerifyFuture,
    E,
>(
    body: BodyFuture,
    cleanup: Cleanup,
    verify_cleanup: Verify,
) where
    BodyFuture: Future<Output = ()>,
    Cleanup: FnOnce() -> CleanupFuture,
    CleanupFuture: Future<Output = Result<(), E>>,
    Verify: FnOnce() -> VerifyFuture,
    VerifyFuture: Future<Output = ()>,
    E: std::fmt::Display,
{
    let result = AssertUnwindSafe(body).catch_unwind().await;
    let cleanup_result = cleanup().await;

    match result {
        Ok(()) => {
            cleanup_result.unwrap_or_else(|error| panic!("live cleanup should succeed: {error}"));
            verify_cleanup().await;
        }
        Err(payload) => match cleanup_result {
            Ok(()) => std::panic::resume_unwind(payload),
            Err(cleanup_error) => panic!(
                "live cleanup should succeed: body_panic={}; cleanup_error={cleanup_error}",
                panic_payload_to_string(payload),
            ),
        },
    }
}

#[cfg(feature = "postgres")]
fn assert_postgres_cleanup_removed_state(
    config: &rurr_postgres::PostgresPersisterConfig,
    app_id: &str,
) {
    use rurr_persistence::{BaseStateLoader, PersistenceError};
    use rurr_postgres::PostgresPersister;

    let verification =
        PostgresPersister::new(config.clone()).expect("verification persister should build");
    let load_error = verification
        .load(Some("pk"), Some(app_id), None)
        .expect_err("cleanup should drop the live test postgres table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

#[cfg(feature = "postgres")]
fn cleanup_live_postgres_table(
    config: &rurr_postgres::PostgresPersisterConfig,
) -> Result<(), rurr_testkit::LiveServiceError> {
    rurr_testkit::drop_postgres_table_sync(&config.database_url, &config.table_name)
}

#[cfg(feature = "postgres")]
async fn cleanup_live_postgres_table_async(
    config: &rurr_postgres::PostgresPersisterConfig,
) -> Result<(), rurr_testkit::LiveServiceError> {
    rurr_testkit::drop_postgres_table(&config.database_url, &config.table_name).await
}

#[cfg(feature = "postgres")]
async fn assert_postgres_cleanup_removed_state_async(
    config: &rurr_postgres::PostgresPersisterConfig,
    app_id: &str,
) {
    use rurr_persistence::{AsyncBaseStateLoader, PersistenceError};
    use rurr_postgres::AsyncPostgresPersister;

    let verification =
        AsyncPostgresPersister::new(config.clone()).expect("verification persister should build");
    let load_error = verification
        .load(Some("pk"), Some(app_id), None)
        .await
        .expect_err("cleanup should drop the live test postgres table");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

#[cfg(feature = "redis")]
fn assert_redis_cleanup_removed_state(config: &rurr_redis::RedisPersisterConfig, app_id: &str) {
    use rurr_persistence::BaseStateLoader;
    use rurr_redis::RedisPersister;

    let verification =
        RedisPersister::new(config.clone()).expect("verification persister should build");
    let loaded = verification
        .load(Some("pk"), Some(app_id), None)
        .expect("cleanup should make the persisted redis state disappear");
    assert!(loaded.is_none());
}

#[cfg(feature = "redis")]
fn cleanup_live_redis_namespace(
    config: &rurr_redis::RedisPersisterConfig,
) -> Result<(), rurr_testkit::LiveServiceError> {
    rurr_testkit::cleanup_redis_namespace_sync(&config.redis_url, &config.namespace)
}

#[cfg(feature = "redis")]
async fn cleanup_live_redis_namespace_async(
    config: &rurr_redis::RedisPersisterConfig,
) -> Result<(), rurr_testkit::LiveServiceError> {
    rurr_testkit::cleanup_redis_namespace_async(&config.redis_url, &config.namespace).await
}

#[cfg(feature = "mongodb")]
fn assert_mongodb_cleanup_removed_state(config: &rurr_mongodb::MongoPersisterConfig, app_id: &str) {
    use rurr_mongodb::MongoPersister;
    use rurr_persistence::{BaseStateLoader, PersistenceError};

    let verification =
        MongoPersister::new(config.clone()).expect("verification persister should build");
    let load_error = verification
        .load(Some("pk"), Some(app_id), None)
        .expect_err("cleanup should drop the live test mongodb collection");
    assert!(matches!(load_error, PersistenceError::NotInitialized));
}

#[cfg(feature = "mongodb")]
fn cleanup_live_mongodb_collection(
    config: &rurr_mongodb::MongoPersisterConfig,
) -> Result<(), rurr_testkit::LiveServiceError> {
    rurr_testkit::drop_mongodb_collection_sync(
        &config.uri,
        &config.db_name,
        &config.collection_name,
    )
}

#[cfg(feature = "postgres")]
#[test]
fn postgres_sync_integration_smoke_feature_gated() {
    rurr_testkit::require_check_live_tests!();

    use rurr_postgres::PostgresPersister;
    use rurr_testkit::postgres_url_from_env;

    let config = rurr_postgres::PostgresPersisterConfig::new(
        postgres_url_from_env().expect("postgres URL must be valid for live tests"),
        unique_id("core_e2e_pg_sync"),
    );
    let persister =
        PostgresPersister::new(config.clone()).expect("postgres persister should build");
    persister
        .initialize()
        .expect("postgres initialization should succeed");
    let app_id = unique_id("smoke_app");
    let cleanup_config = config.clone();

    run_live_sync_smoke_case_with_cleanup(
        || assert_sync_persistence_smoke(&persister, &app_id),
        || cleanup_live_postgres_table(&cleanup_config),
        || assert_postgres_cleanup_removed_state(&config, &app_id),
    );
}

#[cfg(feature = "postgres")]
#[tokio::test]
async fn postgres_async_integration_smoke_feature_gated() {
    rurr_testkit::require_check_live_tests!();

    use rurr_persistence::{AsyncBaseStateLoader, AsyncBaseStateSaver, PersistedStateStatus};
    use rurr_postgres::AsyncPostgresPersister;
    use rurr_testkit::ready_postgres_url;

    let config = rurr_postgres::PostgresPersisterConfig::new(
        ready_postgres_url()
            .await
            .expect("postgres must be reachable for live tests"),
        unique_id("core_e2e_pg_async"),
    );
    let persister =
        AsyncPostgresPersister::new(config.clone()).expect("postgres persister should build");
    persister
        .initialize()
        .await
        .expect("postgres initialization should succeed");
    let app_id = unique_id("smoke_app");
    let cleanup_config = config.clone();

    run_live_async_smoke_case_with_cleanup(
        async {
            persister
                .save(
                    Some("pk"),
                    &app_id,
                    1,
                    "step",
                    map_from_pairs([("value", json!("ok"))]),
                    PersistedStateStatus::Completed,
                )
                .await
                .expect("postgres save should succeed");

            let loaded = persister
                .load(Some("pk"), Some(&app_id), None)
                .await
                .expect("postgres load should succeed")
                .expect("postgres should return saved state");

            assert_eq!(loaded.app_id, app_id);
            assert_eq!(loaded.sequence_id, 1);
            assert_eq!(
                loaded
                    .state
                    .as_ref()
                    .and_then(|state| state.get("value"))
                    .and_then(Value::as_str),
                Some("ok")
            );
        },
        || cleanup_live_postgres_table_async(&cleanup_config),
        || assert_postgres_cleanup_removed_state_async(&config, &app_id),
    )
    .await;
}

#[cfg(not(feature = "postgres"))]
#[test]
fn postgres_integration_smoke_requires_feature() {
    skip_feature("postgres");
}

#[cfg(feature = "redis")]
#[test]
fn redis_sync_integration_smoke_feature_gated() {
    rurr_testkit::require_check_live_tests!();

    use rurr_redis::RedisPersister;
    use rurr_testkit::{redis_url_from_env, wait_for_redis_ready_sync};

    let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
    wait_for_redis_ready_sync(&redis_url).expect("redis must be reachable for live tests");

    let config = rurr_redis::RedisPersisterConfig::new(redis_url, unique_id("core_e2e_redis_sync"));
    let persister = RedisPersister::new(config.clone()).expect("redis persister should build");
    persister
        .initialize()
        .expect("redis initialization should succeed");
    let app_id = unique_id("smoke_app");
    let cleanup_config = config.clone();

    run_live_sync_smoke_case_with_cleanup(
        || assert_sync_persistence_smoke(&persister, &app_id),
        || cleanup_live_redis_namespace(&cleanup_config),
        || assert_redis_cleanup_removed_state(&config, &app_id),
    );
}

#[cfg(not(feature = "redis"))]
#[test]
fn redis_integration_smoke_requires_feature() {
    skip_feature("redis");
}

#[cfg(feature = "mongodb")]
#[test]
fn mongodb_sync_integration_smoke_feature_gated() {
    rurr_testkit::require_check_live_tests!();

    use rurr_mongodb::MongoPersister;
    use rurr_testkit::ready_mongodb_uri_sync;

    let mongodb_uri = ready_mongodb_uri_sync().expect("mongodb must be reachable for live tests");
    let config = rurr_mongodb::MongoPersisterConfig::new(
        mongodb_uri,
        "rurr_core_e2e",
        unique_id("core_e2e_mongo_sync"),
    );
    let persister = MongoPersister::new(config.clone()).expect("mongodb persister should build");
    persister
        .initialize()
        .expect("mongodb initialization should succeed");
    let app_id = unique_id("smoke_app");
    let cleanup_config = config.clone();

    run_live_sync_smoke_case_with_cleanup(
        || assert_sync_persistence_smoke(&persister, &app_id),
        || cleanup_live_mongodb_collection(&cleanup_config),
        || assert_mongodb_cleanup_removed_state(&config, &app_id),
    );
}

#[cfg(not(feature = "mongodb"))]
#[test]
fn mongodb_integration_smoke_requires_feature() {
    skip_feature("mongodb");
}

#[cfg(feature = "redis")]
#[tokio::test]
async fn redis_async_integration_smoke_feature_gated() {
    rurr_testkit::require_check_live_tests!();

    use rurr_persistence::{AsyncBaseStateLoader, AsyncBaseStateSaver, PersistedStateStatus};
    use rurr_redis::AsyncRedisPersister;
    use rurr_testkit::{redis_url_from_env, wait_for_redis_ready};

    let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
    wait_for_redis_ready(&redis_url)
        .await
        .expect("redis must be reachable for live tests");

    let config =
        rurr_redis::RedisPersisterConfig::new(redis_url, unique_id("core_e2e_redis_async"));
    let persister = AsyncRedisPersister::new(config.clone()).expect("redis persister should build");
    persister
        .initialize()
        .await
        .expect("redis initialization should succeed");
    let app_id = unique_id("smoke_app");
    let cleanup_config = config.clone();

    run_live_async_smoke_case_with_cleanup(
        async {
            persister
                .save(
                    Some("pk"),
                    &app_id,
                    1,
                    "step",
                    map_from_pairs([("value", json!("ok"))]),
                    PersistedStateStatus::Completed,
                )
                .await
                .expect("redis save should succeed");

            let loaded = persister
                .load(Some("pk"), Some(&app_id), None)
                .await
                .expect("redis load should succeed")
                .expect("redis should return saved state");

            assert_eq!(loaded.app_id, app_id);
            assert_eq!(loaded.sequence_id, 1);
            assert_eq!(
                loaded
                    .state
                    .as_ref()
                    .and_then(|state| state.get("value"))
                    .and_then(Value::as_str),
                Some("ok")
            );
        },
        || cleanup_live_redis_namespace_async(&cleanup_config),
        || async { assert_redis_cleanup_removed_state(&config, &app_id) },
    )
    .await;
}

#[cfg(feature = "postgres")]
#[test]
fn postgres_parallelism_child_override_smoke_feature_gated() {
    rurr_testkit::require_check_live_tests!();

    use rurr_core::action::{ActionContext, ActionError, ActionResult, LocalAction};
    use rurr_core::parallelism::{RunnableGraph, SubGraphTask, TaskBasedParallelAction};
    use rurr_persistence::{
        BaseStateLoader, PersistedStateStatus, StateLoaderRef, StatePersisterRef,
    };
    use rurr_postgres::PostgresPersister;
    use rurr_testkit::postgres_url_from_env;

    #[derive(Clone)]
    struct ExplicitTaskAction {
        name: Option<String>,
        child_graph: RunnableGraph,
        child_persister: Arc<dyn rurr_persistence::BaseStatePersister>,
    }

    impl LocalAction for ExplicitTaskAction {
        fn name(&self) -> Option<&str> {
            self.name.as_deref()
        }

        fn reads(&self) -> &[String] {
            &[]
        }

        fn writes(&self) -> &[String] {
            &[]
        }

        fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
            let next_name = name.into();
            if let Some(current_name) = &self.name {
                return Err(ActionError::NameAlreadySet {
                    current_name: current_name.clone(),
                    attempted_name: next_name,
                });
            }
            let mut copied = self.clone();
            copied.name = Some(next_name);
            Ok(copied)
        }

        fn run(&self, state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError> {
            self.run_task_sync(state, ctx)
        }
    }

    impl TaskBasedParallelAction for ExplicitTaskAction {
        fn tasks(
            &self,
            _state: &State,
            _ctx: &ActionContext,
        ) -> Result<Vec<SubGraphTask>, rurr_core::application::ApplicationError> {
            Ok(vec![SubGraphTask::new(
                self.child_graph.clone(),
                State::default(),
                "0-0",
            )
            .with_child_app_id("postgres-child")
            .with_state_persister(StatePersisterRef::from(self.child_persister.clone()))
            .with_state_initializer(StateLoaderRef::from(
                self.child_persister.clone(),
            ))])
        }

        fn reduce(
            &self,
            _parent_state: &State,
            child_states: Vec<State>,
        ) -> Result<ActionResult, rurr_core::application::ApplicationError> {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_count", json!(child_states.len()))]),
            ))
        }
    }

    let config = rurr_postgres::PostgresPersisterConfig::new(
        postgres_url_from_env().expect("postgres URL must be valid for live tests"),
        unique_id("pg_par_child"),
    );
    let persister =
        Arc::new(PostgresPersister::new(config.clone()).expect("postgres persister should build"));
    persister
        .initialize()
        .expect("postgres initialization should succeed");
    let cleanup_config = config.clone();
    let child_app_id = "postgres-child";

    run_live_sync_smoke_case_with_cleanup(
        || {
            persister
                .save(
                    Some("pk"),
                    child_app_id,
                    1,
                    "child_step",
                    map_from_pairs([("value", json!(41))]),
                    PersistedStateStatus::Failed,
                )
                .expect("seed child state save should succeed");

            let child_action = FunctionActionBuilder::new()
                .writes(["value"])
                .build_sync(|state, _ctx| {
                    let next = state
                        .get("value")
                        .and_then(Value::as_i64)
                        .unwrap_or_default()
                        + 1;
                    map_from_pairs([("value", json!(next))])
                })
                .expect("child action should build");
            let child_graph = RunnableGraph::new(
                vec![GraphAction::new(
                    child_action
                        .with_name("child_step")
                        .expect("child action should name"),
                )
                .expect("graph action should build")],
                Vec::<Transition>::new(),
                Some("child_step".to_string()),
            );

            let child_persister_trait: Arc<dyn rurr_persistence::BaseStatePersister> =
                persister.clone();
            let explicit_task_action = ExplicitTaskAction {
                name: None,
                child_graph,
                child_persister: child_persister_trait,
            };

            let mut app = ApplicationBuilder::new()
                .with_state(State::default())
                .expect("state should configure")
                .with_actions(vec![("parallel", explicit_task_action)])
                .expect("action should configure")
                .with_transitions(Vec::<Transition>::new())
                .expect("transitions should configure")
                .with_entrypoint("parallel")
                .expect("entrypoint should configure")
                .with_identifiers("parent-app", Some("pk".to_string()), None)
                .expect("identifiers should configure")
                .build()
                .expect("application should build");

            let _ = app
                .step(None)
                .expect("step should succeed")
                .expect("step should execute");

            let loaded = persister
                .load(Some("pk"), Some(child_app_id), None)
                .expect("postgres load should succeed")
                .expect("postgres should return saved child state");
            assert_eq!(
                loaded
                    .state
                    .as_ref()
                    .and_then(|state| state.get("value"))
                    .and_then(Value::as_i64),
                Some(42)
            );
        },
        || cleanup_live_postgres_table(&cleanup_config),
        || assert_postgres_cleanup_removed_state(&config, child_app_id),
    );
}

#[cfg(feature = "postgres")]
#[test]
fn postgres_sync_panic_cleanup_drops_table() {
    rurr_testkit::require_check_live_tests!();

    use rurr_postgres::PostgresPersister;
    use rurr_testkit::postgres_url_from_env;

    let config = rurr_postgres::PostgresPersisterConfig::new(
        postgres_url_from_env().expect("postgres URL must be valid for live tests"),
        unique_id("core_e2e_pg_sync_panic"),
    );
    let persister =
        PostgresPersister::new(config.clone()).expect("postgres persister should build");
    persister
        .initialize()
        .expect("postgres initialization should succeed");
    let app_id = unique_id("smoke_app");
    let cleanup_config = config.clone();

    let panic_result = catch_unwind(AssertUnwindSafe(|| {
        run_live_sync_smoke_case_with_cleanup(
            || {
                assert_sync_persistence_smoke(&persister, &app_id);
                panic!("synthetic postgres smoke panic");
            },
            || cleanup_live_postgres_table(&cleanup_config),
            || {},
        );
    }));

    assert!(panic_result.is_err(), "panic fixture should unwind");
    assert_postgres_cleanup_removed_state(&config, &app_id);
}

#[cfg(feature = "redis")]
#[tokio::test]
async fn redis_async_panic_cleanup_reclaims_namespace() {
    rurr_testkit::require_check_live_tests!();

    use rurr_persistence::{AsyncBaseStateSaver, PersistedStateStatus};
    use rurr_redis::AsyncRedisPersister;
    use rurr_testkit::{redis_url_from_env, wait_for_redis_ready};

    let redis_url = redis_url_from_env().expect("REDIS_URL must be valid for live tests");
    wait_for_redis_ready(&redis_url)
        .await
        .expect("redis must be reachable for live tests");

    let config =
        rurr_redis::RedisPersisterConfig::new(redis_url, unique_id("core_e2e_redis_async_panic"));
    let persister = AsyncRedisPersister::new(config.clone()).expect("redis persister should build");
    persister
        .initialize()
        .await
        .expect("redis initialization should succeed");
    let app_id = unique_id("smoke_app");
    let cleanup_config = config.clone();

    let panic_result = AssertUnwindSafe(run_live_async_smoke_case_with_cleanup(
        async {
            persister
                .save(
                    Some("pk"),
                    &app_id,
                    1,
                    "step",
                    map_from_pairs([("value", json!("ok"))]),
                    PersistedStateStatus::Completed,
                )
                .await
                .expect("redis save should succeed");
            panic!("synthetic redis async smoke panic");
        },
        || cleanup_live_redis_namespace_async(&cleanup_config),
        || async {},
    ))
    .catch_unwind()
    .await;

    assert!(panic_result.is_err(), "panic fixture should unwind");
    assert_redis_cleanup_removed_state(&config, &app_id);
}
