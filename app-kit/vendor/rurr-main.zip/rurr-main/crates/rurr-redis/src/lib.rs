//! Redis-backed persistence adapters and contract helpers for Rurr.
//!
//! The Redis backend stores each persisted state snapshot in a hash and keeps
//! secondary indexes in sorted sets so the latest partition and latest app
//! lookups remain efficient.
//! Sync and async persisters share the same key layout and save/load contract.
//! Constructors validate local URL/namespace shape without proving a live Redis
//! server; command behavior belongs to the live backend proof lane.
//!
//! ```rust
//! use rurr_redis::{AsyncRedisPersister, RedisPersister, RedisPersisterConfig};
//!
//! let config = RedisPersisterConfig {
//!     redis_url: "redis://127.0.0.1/".to_string(),
//!     namespace: "docs".to_string(),
//! };
//!
//! let sync = RedisPersister::new(config.clone())?;
//! let async_persister = AsyncRedisPersister::new(config.clone())?;
//!
//! assert_eq!(sync.config(), config);
//! assert_eq!(async_persister.config().namespace, "docs");
//! # Ok::<(), rurr_persistence::PersistenceError>(())
//! ```
#![deny(missing_docs)]

use async_trait::async_trait;
use contract_logic::{drive_partition_app_id_scan_async, finish_save_result, RedisPersistencePlan};
use indexmap::IndexMap;
use redis::aio::ConnectionManager;
use redis::{AsyncCommands, Client};
use rurr_persistence::{
    AsyncBaseStateLoader, AsyncBaseStateSaver, PersistedStateData, PersistedStateStatus,
    PersistenceError,
};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::sync::{LazyLock, Mutex, MutexGuard};

mod contract_logic;
mod redis_impl;
mod sync_impl;

use redis_impl::commands::{invoke_save_if_not_exists_async, open_client};
use redis_impl::load::{
    load_record_async, load_record_key_async, partition_index_members_batch_async,
};
/// Synchronous Redis persister backed by a lazily opened `redis::Connection`.
pub use sync_impl::RedisPersister;

const OP_CONNECTION_LOCK_POISONED: &str = "connection_lock_poisoned";
const OP_RECORD_ALREADY_EXISTS: &str = "record_already_exists";
const OP_REDIS_CLIENT_OPEN_FAILED: &str = "redis_client_open_failed";
const OP_REDIS_COMMAND_FAILED: &str = "redis_command_failed";
const OP_REDIS_CONNECT_FAILED: &str = "redis_connect_failed";
const OP_REDIS_WRITE_OUTCOME_UNKNOWN: &str = "redis_write_outcome_unknown";

const LUA_SAVE_IF_NOT_EXISTS: &str = r#"
if redis.call('EXISTS', KEYS[1]) == 1 then
    return 0
end

redis.call(
    'HSET',
    KEYS[1],
    'partition_key', ARGV[1],
    'app_id', ARGV[2],
    'sequence_id', ARGV[3],
    'position', ARGV[4],
    'state', ARGV[5],
    'status', ARGV[6],
    'created_at', ARGV[7]
)
redis.call('ZADD', KEYS[2], 0, ARGV[8])
redis.call('ZADD', KEYS[3], 0, ARGV[9])
redis.call('SADD', KEYS[4], ARGV[2])
return 1
"#;

static SAVE_IF_NOT_EXISTS_SCRIPT: LazyLock<redis::Script> =
    LazyLock::new(|| redis::Script::new(LUA_SAVE_IF_NOT_EXISTS));

pub(crate) use contract_logic::SaveInvocation;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serializable configuration for constructing Redis persisters.
pub struct RedisPersisterConfig {
    /// Redis connection string for the target server.
    pub redis_url: String,
    /// Namespace prefix applied to every stored key.
    pub namespace: String,
}

impl RedisPersisterConfig {
    /// Builds a Redis persister config from a Redis URL and namespace.
    pub fn new(redis_url: impl Into<String>, namespace: impl Into<String>) -> Self {
        Self {
            redis_url: redis_url.into(),
            namespace: namespace.into(),
        }
    }
}

/// Asynchronous Redis persister backed by a lazy `ConnectionManager`.
pub struct AsyncRedisPersister {
    client: Client,
    config: RedisPersisterConfig,
    connection_manager: Mutex<Option<ConnectionManager>>,
}

impl AsyncRedisPersister {
    /// Creates an async Redis persister from a serialized config value.
    pub fn new(config: RedisPersisterConfig) -> Result<Self, PersistenceError> {
        let (client, config) = open_client(config.redis_url, config.namespace)?;
        Ok(Self {
            client,
            config,
            connection_manager: Mutex::new(None),
        })
    }

    /// Returns the configuration originally used to construct this persister.
    pub fn config(&self) -> RedisPersisterConfig {
        self.config.clone()
    }

    fn lock_connection_manager(
        &self,
    ) -> Result<MutexGuard<'_, Option<ConnectionManager>>, PersistenceError> {
        self.connection_manager
            .lock()
            .map_err(|_| PersistenceError::UnsupportedOperation {
                operation: OP_CONNECTION_LOCK_POISONED,
            })
    }

    async fn connection_manager(&self) -> Result<ConnectionManager, PersistenceError> {
        if let Some(existing) = self.lock_connection_manager()?.as_ref().cloned() {
            return Ok(existing);
        }

        let manager = self.client.get_connection_manager().await.map_err(|_| {
            PersistenceError::UnsupportedOperation {
                operation: OP_REDIS_CONNECT_FAILED,
            }
        })?;

        let mut guard = self.lock_connection_manager()?;
        if let Some(existing) = guard.as_ref() {
            return Ok(existing.clone());
        }
        *guard = Some(manager.clone());
        Ok(manager)
    }

    async fn ping(&self) -> Result<(), PersistenceError> {
        let mut connection = self.connection_manager().await?;
        redis::cmd("PING")
            .query_async::<String>(&mut connection)
            .await
            .map_err(|_| PersistenceError::UnsupportedOperation {
                operation: OP_REDIS_COMMAND_FAILED,
            })?;
        Ok(())
    }
}

#[async_trait]
impl AsyncBaseStateSaver for AsyncRedisPersister {
    async fn initialize(&self) -> Result<(), PersistenceError> {
        self.ping().await
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.ping().await?;
        Ok(true)
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        let prepared_save = RedisPersistencePlan::save(
            &self.config.namespace,
            partition_key,
            app_id,
            sequence_id,
            position,
            &state,
            status,
        )?;
        let save_invocation = prepared_save.invocation();

        let mut connection = self.connection_manager().await?;
        let result: i32 =
            invoke_save_if_not_exists_async(&mut connection, &save_invocation).await?;

        finish_save_result(result, OP_RECORD_ALREADY_EXISTS)
    }
}

#[async_trait]
impl AsyncBaseStateLoader for AsyncRedisPersister {
    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        let mut connection = self.connection_manager().await?;
        let query =
            RedisPersistencePlan::load(&self.config.namespace, partition_key, app_id, sequence_id)?;
        let Some(record_key) = load_record_key_async(&mut connection, &query).await? else {
            return Ok(None);
        };
        load_record_async(&mut connection, &record_key).await
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        let mut connection = self.connection_manager().await?;
        let plan = RedisPersistencePlan::list_app_ids(&self.config.namespace, partition_key);
        let app_ids: Vec<String> =
            connection
                .smembers(plan.app_members_key())
                .await
                .map_err(|_| PersistenceError::UnsupportedOperation {
                    operation: OP_REDIS_COMMAND_FAILED,
                })?;
        let scan = plan.scan(app_ids);
        drive_partition_app_id_scan_async(scan, |partition_index_key, start, end| {
            let mut connection = connection.clone();
            async move {
                partition_index_members_batch_async(
                    &mut connection,
                    partition_index_key.as_str(),
                    start,
                    end,
                )
                .await
            }
        })
        .await
    }
}

#[cfg(test)]
mod tests;
