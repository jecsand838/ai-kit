//! Persistence traits, configuration types, and lightweight built-in
//! implementations shared across Rurr backends.
//!
//! This crate defines the stable persistence contract used by the runtime and
//! adapter crates. Concrete storage backends translate their rows/documents into
//! these shared records so application resume, fork, and save behavior remains
//! backend-independent.
//!
//! The public traits are intentionally split into sync and async lanes. Builder
//! validation chooses the lane before execution starts, and adapter crates keep
//! their concrete connection/pool behavior behind the shared v1 record layout:
//! `partition_key`, `app_id`, `sequence_id`, `position`, `state`,
//! `created_at`, and `status`.
//!
//! ```rust
//! use indexmap::IndexMap;
//! use rurr_persistence::{
//!     BaseStateLoader, BaseStateSaver, InMemoryPersister, PersistedStateStatus,
//! };
//! use serde_json::json;
//!
//! let persister = InMemoryPersister::new();
//! persister
//!     .save(
//!         None,
//!         "example-app",
//!         1,
//!         "count",
//!         IndexMap::from([("count".to_string(), json!(1))]),
//!         PersistedStateStatus::Completed,
//!     )
//!     ?;
//!
//! let loaded = persister
//!     .load(None, Some("example-app"), None)?
//!     .ok_or(rurr_persistence::PersistenceError::NotInitialized)?;
//! assert_eq!(loaded.sequence_id, 1);
//! # Ok::<(), rurr_persistence::PersistenceError>(())
//! ```
#![deny(missing_docs)]

mod in_memory;
/// Canonical persisted-state field names and data structures.
pub mod layout;
/// Shared persisted-record assembly helpers used across backend adapters.
pub mod record;
mod refs;
/// Builder-friendly persistence configuration types.
pub mod spec;
/// Shared SQL persistence helpers used by the SQLite and Postgres backends.
pub mod sql;
mod traits;
/// Serialization and normalization helpers for persisted-state records.
pub mod wire;

/// In-memory persistence implementations.
pub use in_memory::{AsyncInMemoryPersister, InMemoryPersister};
/// Persisted-state layout constants and value types.
pub use layout::{
    storage_layout_version, PersistedStateData, PersistedStateStatus, FIELD_APP_ID,
    FIELD_CREATED_AT, FIELD_PARTITION_KEY, FIELD_POSITION, FIELD_SEQUENCE_ID, FIELD_STATE,
    FIELD_STATUS, PERSISTED_STATE_FIELD_ORDER, STATUS_COMPLETED, STATUS_FAILED,
    STORAGE_LAYOUT_VERSION,
};
pub use record::{persisted_state_from_record_parts, PersistedRecordParts};
/// Type-erased loader and persister references for builder configuration.
pub use refs::{StateLoaderRef, StatePersisterRef};
/// High-level persistence configuration types.
pub use spec::{
    ApplicationPersistenceSpec, PersistenceLane, PersistenceLoadTarget, StateInitializerSpec,
    StatePersisterSpec,
};
/// Shared async SQL helpers re-exported from the SQL persistence module.
pub use sql::async_ops;
/// Shared SQL persistence helpers and types.
pub use sql::{
    closed_connection_error, is_closed_connection_error, sequence_id_i64_to_u64,
    sequence_id_u64_to_i64, tuple_to_persisted_state, AsyncSqlxPersistenceCore, InitializationHint,
    LoadSelector, PersistedRowTuple, PersistedStateQueries, PersistedStateSaveRequest,
    PostgresDialect, SqlDialect, SqlInitializationPlan, SqlListAppIdsPlan, SqlSavePlan,
    SqliteDialect, SyncSqlBackend, SyncSqlPersistenceCore,
};
/// Core persistence traits and errors.
pub use traits::{
    AsyncBaseStateLoader, AsyncBaseStatePersister, AsyncBaseStateSaver, BaseStateLoader,
    BaseStatePersister, BaseStateSaver, PersistenceError,
};
