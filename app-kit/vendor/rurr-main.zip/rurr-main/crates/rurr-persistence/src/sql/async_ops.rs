use crate::{
    sql::{core_plan::LoadOperation, row_models::PersistedStateRow},
    SqlDialect, SqlListAppIdsPlan, SqlSavePlan,
};
use crate::{PersistedStateData, PersistenceError};
use sqlx::{ColumnIndex, Decode, Encode, Executor, FromRow, IntoArguments, Pool, Type};

/// Executes raw migration SQL for the selected dialect.
pub async fn execute_sqlx_statements<D, F>(
    pool: &Pool<D::Database>,
    sql: &str,
    map_error: F,
) -> Result<(), PersistenceError>
where
    D: SqlDialect,
    F: Fn(sqlx::Error) -> PersistenceError + Copy,
    for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
{
    sqlx::raw_sql(sql).execute(pool).await.map_err(map_error)?;
    Ok(())
}

/// Checks whether `table_name` exists for the selected dialect.
pub async fn is_initialized<D, F>(
    pool: &Pool<D::Database>,
    table_name: &str,
    map_error: F,
) -> Result<bool, PersistenceError>
where
    D: SqlDialect,
    F: Fn(sqlx::Error) -> PersistenceError + Copy,
    for<'r> bool: Decode<'r, D::Database> + Type<D::Database>,
    usize: ColumnIndex<<D::Database as sqlx::Database>::Row>,
    for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
    for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
    for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
{
    sqlx::query_scalar::<D::Database, bool>(D::table_exists_sql())
        .bind(table_name)
        .fetch_one(pool)
        .await
        .map_err(map_error)
}

/// Saves a persisted-state record through SQLx.
pub async fn save<D, F>(
    pool: &Pool<D::Database>,
    plan: &SqlSavePlan<'_, '_>,
    map_error: F,
) -> Result<(), PersistenceError>
where
    D: SqlDialect,
    F: Fn(sqlx::Error) -> PersistenceError + Copy,
    for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
    for<'q> i64: Encode<'q, D::Database> + Type<D::Database>,
    for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
    for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
{
    sqlx::query::<D::Database>(plan.query)
        .bind(plan.partition_key.as_str())
        .bind(plan.app_id)
        .bind(plan.sequence_id)
        .bind(plan.position)
        .bind(plan.state_json.as_str())
        .bind(plan.status)
        .execute(pool)
        .await
        .map_err(map_error)?;
    Ok(())
}

pub(crate) async fn load_operation<D, F>(
    pool: &Pool<D::Database>,
    operation: LoadOperation<'_, '_>,
    map_error: F,
) -> Result<Option<PersistedStateData>, PersistenceError>
where
    D: SqlDialect,
    F: Fn(sqlx::Error) -> PersistenceError + Copy,
    for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
    for<'q> i64: Encode<'q, D::Database> + Type<D::Database>,
    for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
    for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
    for<'r> PersistedStateRow: FromRow<'r, <D::Database as sqlx::Database>::Row>,
{
    let row = match operation {
        LoadOperation::NoRecord => None,
        LoadOperation::LatestPartition {
            query,
            partition_key,
        } => sqlx::query_as::<D::Database, PersistedStateRow>(query)
            .bind(partition_key.as_str())
            .fetch_optional(pool)
            .await
            .map_err(map_error)?,
        LoadOperation::LatestApp {
            query,
            partition_key,
            app_id,
        } => sqlx::query_as::<D::Database, PersistedStateRow>(query)
            .bind(partition_key.as_str())
            .bind(app_id)
            .fetch_optional(pool)
            .await
            .map_err(map_error)?,
        LoadOperation::ExactSequence {
            query,
            partition_key,
            app_id,
            sequence_id,
        } => sqlx::query_as::<D::Database, PersistedStateRow>(query)
            .bind(partition_key.as_str())
            .bind(app_id)
            .bind(sequence_id)
            .fetch_optional(pool)
            .await
            .map_err(map_error)?,
    };

    row.map(PersistedStateRow::into_persisted_state).transpose()
}

pub(crate) async fn list_app_ids_operation<D, F>(
    pool: &Pool<D::Database>,
    plan: &SqlListAppIdsPlan<'_>,
    map_error: F,
) -> Result<Vec<String>, PersistenceError>
where
    D: SqlDialect,
    F: Fn(sqlx::Error) -> PersistenceError + Copy,
    for<'r> String: Decode<'r, D::Database> + Type<D::Database>,
    usize: ColumnIndex<<D::Database as sqlx::Database>::Row>,
    for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
    for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
    for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
{
    sqlx::query_scalar::<D::Database, String>(plan.query)
        .bind(plan.partition_key.as_str())
        .fetch_all(pool)
        .await
        .map_err(map_error)
}
