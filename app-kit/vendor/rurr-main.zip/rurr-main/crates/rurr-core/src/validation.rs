use thiserror::Error;

/// Shared compatibility-prefixed validation banner used in builder errors.
pub const BASE_ERROR_MESSAGE: &str = concat!(
    "-------------------------------------------------------------------\n",
    "Oh no an error! Need help with Burr?\n",
    "Join our discord and ask for help! https://discord.gg/4FxBMyzW5n\n",
    "-------------------------------------------------------------------\n",
);

/// Error returned when a builder-style API is missing a required value.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum ValidationError {
    /// One required builder value was never set before build time.
    #[error(
        "{base_error_message}Must call `{method}` before building application! Do so with ApplicationBuilder.",
        base_error_message = BASE_ERROR_MESSAGE
    )]
    MissingRequiredValue {
        /// Internal field name that was missing.
        field: String,
        /// Builder method the caller should invoke.
        method: String,
    },
}

/// Returns an error when a required builder field is not set.
pub fn assert_set<T>(value: Option<T>, field: &str, method: &str) -> Result<(), ValidationError> {
    if value.is_none() {
        return Err(ValidationError::MissingRequiredValue {
            field: field.to_string(),
            method: method.to_string(),
        });
    }

    Ok(())
}
