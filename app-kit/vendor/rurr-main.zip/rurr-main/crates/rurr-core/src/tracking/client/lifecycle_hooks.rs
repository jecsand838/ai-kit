use super::registration::ResolvedTrackingApp;
use super::validation::tracking_to_lifecycle_error;
use super::*;
use crate::tracking::lifecycle_events;
use std::sync::Arc;
use store_util::tracking_repository::{artifacts::TrackingArtifact, write as repository_write};

impl LocalTrackingClient {
    fn append_lifecycle_log_entry(
        &self,
        app: &ResolvedTrackingApp,
        value: &Value,
        op_label: &'static str,
    ) -> Result<(), LifecycleError> {
        self.with_write_lock(|| {
            repository_write::append_required_jsonl_artifact(
                &app.anchor,
                TrackingArtifact::Log,
                value,
            )
        })
        .map_err(|error| tracking_to_lifecycle_error(op_label, error))
    }

    fn write_lifecycle_log_entry(
        &self,
        app_id: Option<&str>,
        value: &Value,
        op_label: &'static str,
    ) -> Result<ResolvedTrackingApp, LifecycleError> {
        let app = self
            .resolve_required_tracking_app(app_id, op_label)
            .map_err(|error| tracking_to_lifecycle_error(op_label, error))?;
        self.append_lifecycle_log_entry(&app, value, op_label)?;
        Ok(app)
    }
}

impl lifecycle_events::TrackingLifecycleSink for LocalTrackingClient {
    fn write_lifecycle_event(
        &self,
        app_id: Option<&str>,
        value: &Value,
        op_label: &'static str,
    ) -> Result<String, LifecycleError> {
        self.write_lifecycle_log_entry(app_id, value, op_label)
            .map(|app| app.app_id)
    }
}

#[async_trait]
impl lifecycle_events::AsyncTrackingLifecycleSink for LocalTrackingClient {
    async fn write_lifecycle_event_async(
        &self,
        app_id: Option<&str>,
        value: &Value,
        op_label: &'static str,
    ) -> Result<String, LifecycleError> {
        lifecycle_events::TrackingLifecycleSink::write_lifecycle_event(
            self, app_id, value, op_label,
        )
    }
}

impl lifecycle_events::TrackingLifecycleAdapter for LocalTrackingClient {
    fn tracking_log(&self) -> &lifecycle_events::TrackingLifecycleLog {
        self.lifecycle_log()
    }

    fn register_tracking_application(
        &self,
        registration: lifecycle_events::TrackingRegistration<'_>,
    ) -> Result<(), LifecycleError> {
        self.register_application_with_child_relationships(
            registration.app_id,
            registration.partition_key,
            registration.graph,
            registration.parent_pointer.cloned(),
            registration.spawning_parent_pointer.cloned(),
            registration.child_relationships,
        )
        .map_err(|error| tracking_to_lifecycle_error(registration.operation, error))
    }
}

impl Tracker for LocalTrackingClient {
    fn sync_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn SyncLifecycleAdapter>> {
        Some(self)
    }

    fn async_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn AsyncLifecycleAdapter>> {
        Some(self)
    }
}
