use super::*;
use super::{actions::*, builders::*, cases::*};

sync_stream_cases! {
    stream_result_pre_target_failure_does_not_poison_session_or_state =>
        assert_result_pre_target_failure_does_not_poison_session_or_state(StreamMode::Sync),
    stream_result_empty_custom_stream_does_not_invoke_run_fallback =>
        assert_result_empty_custom_stream_does_not_invoke_run_fallback(StreamMode::Sync),
    stream_iterate_uncommitted_stream_get_does_not_mark_session_committed =>
        assert_iterate_uncommitted_stream_get_does_not_mark_session_committed(StreamMode::Sync),
    stream_iterate_uncommitted_stream_next_item_completion_does_not_mark_session_committed =>
        assert_iterate_uncommitted_stream_next_item_completion_does_not_mark_session_committed(StreamMode::Sync),
    stream_step_handle_get_is_idempotent_after_next_item_completion =>
        assert_step_handle_get_is_idempotent_after_next_item_completion(StreamMode::Sync),
    stream_step_handle_error_then_next_item_is_terminal_none =>
        assert_step_handle_error_then_next_item_is_terminal_none(StreamMode::Sync)
}
async_stream_cases! {
    astream_result_pre_target_failure_does_not_poison_session_or_state =>
        assert_result_pre_target_failure_does_not_poison_session_or_state(StreamMode::Async),
    astream_result_empty_custom_stream_does_not_invoke_run_fallback =>
        assert_result_empty_custom_stream_does_not_invoke_run_fallback(StreamMode::Async),
    astream_iterate_uncommitted_stream_get_does_not_mark_session_committed =>
        assert_iterate_uncommitted_stream_get_does_not_mark_session_committed(StreamMode::Async),
    astream_iterate_uncommitted_stream_next_item_completion_does_not_mark_session_committed =>
        assert_iterate_uncommitted_stream_next_item_completion_does_not_mark_session_committed(StreamMode::Async),
    astream_step_handle_get_is_idempotent_after_next_item_completion =>
        assert_step_handle_get_is_idempotent_after_next_item_completion(StreamMode::Async),
    astream_iterate_non_streaming_update_trace_emits_span_hooks =>
        assert_non_streaming_update_trace_emits_span_hooks(StreamMode::Async, UpdateTraceDrive::Iterate),
    astream_result_non_streaming_update_trace_emits_span_hooks =>
        assert_non_streaming_update_trace_emits_span_hooks(StreamMode::Async, UpdateTraceDrive::Result)
}

#[test]
fn stream_step_handle_iterator_adapter_stops_after_first_error() {
    let action = error_first_item_streaming_action();
    let mut app = build_error_streaming_app(action).expect("app should build");

    let mut iterate = app.stream_iterate();
    let (_action, mut handle) = iterate
        .next_step()
        .expect("next_step should succeed")
        .expect("step should exist");

    let first = handle.next().expect("first iterator item should exist");
    assert!(matches!(
        first,
        Err(ApplicationError::StreamingActionFailed { .. })
    ));
    assert!(
        handle.next().is_none(),
        "step handle iterator should terminate after surfacing the first error"
    );

    drop(handle);
    drop(iterate);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

async_stream_cases! {
    astream_step_handle_error_then_next_item_is_terminal_none =>
        assert_step_handle_error_then_next_item_is_terminal_none(StreamMode::Async),
    astream_step_handle_abort_surfaces_async_post_step_failure =>
        assert_astream_step_handle_abort_surfaces_async_finish_failure(AsyncAbortFailurePhase::PostRunStep),
    astream_step_handle_abort_surfaces_async_post_stream_failure =>
        assert_astream_step_handle_abort_surfaces_async_finish_failure(AsyncAbortFailurePhase::PostEndStream),
    astream_step_handle_abort_failure_does_not_degrade_into_stream_invariant_noise =>
        assert_astream_step_handle_abort_surfaces_async_finish_failure(AsyncAbortFailurePhase::PostRunStep)
}

#[tokio::test]
async fn astream_step_handle_get_returns_cached_terminal_after_error() {
    let action = error_first_item_streaming_action();
    let mut app = build_error_streaming_app(action).expect("app should build");

    let mut iterate = app.astream_iterate().await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");

    let first = handle.next_item().await;
    assert!(matches!(
        first,
        Err(ApplicationError::StreamingActionFailed { .. })
    ));

    let (terminal, state) = handle
        .get()
        .await
        .expect("get should return cached terminal after error");
    assert!(terminal.is_none());
    assert_eq!(state.get("count").cloned(), Some(json!(0)));
    assert!(!state.contains_key("__SEQUENCE_ID"));
    assert!(handle
        .next_item()
        .await
        .expect("next_item after cached terminal should be terminal")
        .is_none());

    drop(handle);
    drop(iterate);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}
