use crate::model::{is_box_iterator_stream_output, type_is_ident};
use syn::spanned::Spanned;
use syn::{GenericArgument, PathArguments, ReturnType, Type};

pub(crate) fn validate_action_return_type(signature: &syn::Signature) -> syn::Result<()> {
    let ReturnType::Type(_, ty) = &signature.output else {
        return Err(syn::Error::new(
            signature.span(),
            "`#[action]` functions must return `Result<ActionResult, ActionError>`",
        ));
    };

    if !is_result_of(ty, "ActionResult", "ActionError") {
        return Err(syn::Error::new(
            ty.span(),
            "`#[action]` functions must return `Result<ActionResult, ActionError>`",
        ));
    }

    Ok(())
}

pub(crate) fn validate_streaming_return_type(signature: &syn::Signature) -> syn::Result<()> {
    let ReturnType::Type(_, ty) = &signature.output else {
        return Err(syn::Error::new(
            signature.span(),
            "`#[streaming_action]` must return an owning stream type",
        ));
    };

    if signature.asyncness.is_some() {
        if !type_is_ident(ty, "LocalAsyncStreamOutput") {
            return Err(syn::Error::new(
                ty.span(),
                "`#[streaming_action] async functions must return `LocalAsyncStreamOutput`",
            ));
        }
    } else if !is_box_iterator_stream_output(ty, true) {
        return Err(syn::Error::new(
            ty.span(),
            "`#[streaming_action]` functions must return `Box<dyn Iterator<Item = StreamOutput>>`",
        ));
    }

    Ok(())
}

fn is_result_of(ty: &Type, ok_ty: &str, err_ty: &str) -> bool {
    let Type::Path(type_path) = ty else {
        return false;
    };
    let Some(segment) = type_path.path.segments.last() else {
        return false;
    };
    if segment.ident != "Result" {
        return false;
    }
    let PathArguments::AngleBracketed(args) = &segment.arguments else {
        return false;
    };
    if args.args.len() != 2 {
        return false;
    }
    let mut iter = args.args.iter();
    let Some(GenericArgument::Type(ok)) = iter.next() else {
        return false;
    };
    let Some(GenericArgument::Type(err)) = iter.next() else {
        return false;
    };
    type_is_ident(ok, ok_ty) && type_is_ident(err, err_ty)
}
