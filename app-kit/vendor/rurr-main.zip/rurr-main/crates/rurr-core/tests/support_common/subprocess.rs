use std::process::Command;

const SUBPROCESS_FIXTURE_ENV: &str = "RURR_RUN_SUBPROCESS_FIXTURE";
const FIXTURE_ENV_REMOVALS: [&str; 4] = ["HOME", "USERPROFILE", "HOMEDRIVE", "HOMEPATH"];

pub(crate) fn subprocess_fixture_enabled() -> bool {
    matches!(std::env::var(SUBPROCESS_FIXTURE_ENV).as_deref(), Ok("1"))
}

pub(crate) fn run_subprocess_fixture(test_name: &str) {
    let exe = std::env::current_exe().expect("current test binary should resolve");
    let mut command = Command::new(exe);
    command
        .arg("--exact")
        .arg(test_name)
        .arg("--nocapture")
        .env(SUBPROCESS_FIXTURE_ENV, "1");
    for name in FIXTURE_ENV_REMOVALS {
        command.env_remove(name);
    }
    let output = command.output().expect("fixture subprocess should start");

    assert!(
        output.status.success(),
        "fixture `{test_name}` failed\nstatus={:?}\nstdout:\n{}\nstderr:\n{}",
        output.status.code(),
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr),
    );
    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.contains("running 1 test"),
        "fixture `{test_name}` did not execute exactly one test\nstdout:\n{stdout}\nstderr:\n{}",
        String::from_utf8_lossy(&output.stderr),
    );
}
