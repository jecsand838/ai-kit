---
name: use-rust-best-practices-networking
description: "Apply this when writing or reviewing Rust networking code: HTTP/REST clients and servers, gRPC with tonic, database access and pools, retries, timeouts, backpressure, and connection reuse. Use it to reuse reqwest clients and tonic channels correctly, choose crate-provided pools over custom pools, separate transport DTOs from domain code, and avoid rebuilding clients, over-pooling, unsafe retries, and weak network error handling."
---

# Rust networking best practices

Use this skill for HTTP/REST, gRPC, database client, connection-pool, and network-bound application code.

## When to use

Use it when the task:

- adds or reviews HTTP/REST client or server code
- adds or reviews tonic/gRPC client or server code
- configures retries, timeouts, backpressure, or concurrency limits
- chooses or tunes connection pools
- asks whether to build a custom pool
- maps transport DTOs to domain types

## Do not use this skill alone when

- the task is mostly about spawned tasks/shutdown/concurrency primitives → also load `$use-rust-best-practices-async`
- the task is mostly about dependency policy or target-specific setup → also load `$use-rust-best-practices-dependencies-platforms`
- the task is mostly about test strategy → also load `$use-rust-best-practices-testing`

## Workflow

1. Reuse long-lived clients, channels, and pools.
2. Prefer crate-provided pools before building a custom pool.
3. Set timeouts, surface status/error context, and apply retries only when safe.
4. Keep transport DTOs and transport errors separate from domain models and domain errors.
5. Choose the simplest concurrency model that preserves backpressure.

## Default rules

- Prefer one configured `reqwest::Client` per destination profile, not one per request.
- Prefer one configured tonic `Endpoint` / `Channel` path and cheap client clones, not reconnecting for every RPC.
- Prefer `sqlx::Pool` or crate-native pools for databases.
- Reach for a generic/custom pool only when the dependency offers no production-ready reuse mechanism.
- Avoid ad-hoc retry loops around non-idempotent operations.
- Bound network fan-out to protect upstreams and your own process.

## Load these references directly when needed

- `references/networking.md` — REST, gRPC, pools, retries, timeouts, backpressure, and bad-vs-best examples.

## Load these templates when useful

- `assets/templates/typed_http_client.rs`
- `assets/templates/grpc_client.rs`
- `assets/templates/sqlx_pool.rs`

## Companion skills

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-async`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-dependencies-platforms`
