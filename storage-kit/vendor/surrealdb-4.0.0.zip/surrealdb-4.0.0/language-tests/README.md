# SurrealQL Language Tests

This directory contains the surrealql language test suite, consisting of a
directory of tests specified in surrealql as well as a command line tool able
to run the files and verify their output.

## SurrealQL Language Test CLI tool

The surrealql language test CLI tool is the thing which will actually run the
test and verify its output. It can be run within this directory with a simple
`cargo run run` (the second run is a command to the tool itself). This will use
the `test` directory as the test root and run all the tests contained within.

The tool can take some flags to change it's behavior. Of note are the filter,
and the `--results` flag.

When you run `cargo run run foo` you are running the tests with a filter. In
this case only test which contain the word `foo` within its path will be run.
This is usefull for running a single or more test you are working on.

The `--results` flag will change what the tool does with it's result. If you run
the test with `--results accept` the tool will automatically fill in results for
any tests which did not specify any results. This is useful for quickly
generating expected output for new tests. You can also specify `--results
overwrite`, which will overwrite the specified results of test if they do not
match the actual results of the test. This flag should be used sparingly and
only after inspecting if the new results are actually valid.

The `--backend` flag allows you to specify which storage engine to use for running
the tests. By default, tests run using the in-memory storage engine (`mem` or `memory`).
Other supported backends include:
- `memory` or `mem` (default): In-memory storage engine, fastest for testing
- `surrealkv`: SurrealKV file-based storage engine (requires `backend-surrealkv` feature)
- `tikv`: not built in. Run a server built from [surrealdb-tikv](https://github.com/surrealdb/surrealdb-tikv) and use `--endpoint`

Note that some backends require the corresponding Cargo feature to be enabled when building:
```bash
# Example: Running tests with SurrealKV backend
cargo run --features backend-surrealkv run --backend surrealkv
```

The repeatable `--config KEY=VALUE` flag sets a datastore configuration key for
every datastore the run opens, for example `--config memory_limit=8MiB` to run
the suite under a small node memory limit. The runner prints the memory limits
the first datastore holds, and stops if a `memory_limit`, `query_memory_max` or
`memory_wait` given this way is not the one the datastore holds. The
environment's `SURREAL_*` variables are not read: only the keys a run names
reach its datastores. It is refused with `--endpoint`, whose datastores belong
to the server and are configured where that was started.

The `--unordered-rows` flag grades the rows of a `SELECT` of a table or a record
range that has no `ORDER BY`, `LIMIT` or `START` as a multiset, for a run under
settings that leave the order of such rows unspecified, such as
`--config morsel_split_rows=1 --config morsel_split_pass_ppm=1000000` (the second cuts a range
whatever share of its rows passes its `WHERE`; add `--config morsel_needs_view=false` on a backend
that gives workers no read view, to cut ranges there as well). A row nested in a result, the rows of every
other statement, and every error are still compared exactly: a test that must
accept one of several errors states them with a `match` expression.

## Running against a remote endpoint

By default the suite runs against an embedded, in-process datastore. Build with
the `remote` feature and pass `--endpoint` to instead run every test against a
**running** SurrealDB instance over the API, exercising the full network and
serialization path rather than just the engine:

```bash
# ws:// (or wss/http/https). Credentials default to root/root.
cargo run --features remote run --endpoint ws://127.0.0.1:8000
cargo run --features remote run --endpoint http://127.0.0.1:8000 --username root --password root
```

The run signs in as `--username` between tests, so that account must be one no
test writes. The corpus names root users freely, and a test that removed or
redefined the login account would lock the run out of the server partway
through; a run whose `--username` collides with a scheduled test is refused
before it starts, naming the tests. `root` is safe: the two tests that define
it declare `[env] remote-skip`.

`--backend` names the server's storage engine, since a test declaring `[env]
backend` asserts how the engines it lists behave. Pass `--backend other` for an
engine the flag has no name for: every test that names its backends is skipped
there.

Results are compared identically to embedded runs: SurrealQL goes through the
SDK (flatbuffers, so types round-trip exactly), and GraphQL/GQL are POSTed
to the server's `/graphql` and `/gql` routes.

**The server must be started so its datastore matches the one the embedded
harness builds** — otherwise tests that exercise scripting, file functions,
GQL, `TEMPFILES` sorting, or `INFO` output fail spuriously:

```bash
SURREAL_FILE_ALLOWLIST="$(pwd)/tests" \
surreal start --user root --pass root \
  --allow-all --allow-experimental '*' \
  --temporary-directory /tmp/surreal-lt --no-defaults \
  memory
```

Each flag mirrors a setting in the harness's `Datastore::builder()`:

| Server flag / env | Mirrors (embedded) | Why it's needed |
|---|---|---|
| `--allow-all` | `Capabilities::all()` | scripting, all functions, net, guests, arbitrary query |
| `--allow-experimental '*'` | `.with_experimental(Targets::All)` | `surrealism`, `kvexport`. **Startup-only**, not implied by `--allow-all`. |
| `--temporary-directory <dir>` | `.with_temporary_directory(..)` | `... ORDER BY .. TEMPFILES` routes through `ExternalSortByKey` |
| `SURREAL_FILE_ALLOWLIST=<abs tests dir>` | `file_allowlist = "../tests"` | `DEFINE ANALYZER .. mapper('<path>')` and file functions reading under `tests/` |
| `--no-defaults` | (core datastore has no default ns/db) | the embedded datastore has no `main` namespace, so `INFO FOR ROOT` matches |
| `--user root --pass root` | `.with_auth(true)` | the harness provisions per-test auth users as root |

`SURREAL_FILE_ALLOWLIST` must be an **absolute** path to this directory's
`tests/` folder (the server's CWD differs from the harness's); paths are
`:`-separated.

Remote runs are **concurrent**, `--jobs` deep like an embedded run. Each test
is given a namespace of its own named `lt_<run>_<n>` and dropped whole at
cleanup, which is the whole of its isolation — so a test that reaches outside
one declares `[env] remote-exclusive` and is run on its own, in the namespace its
config names, with a snapshot-diff cleanup removing whatever it created at the
root level. A test that needs that and does not declare it fails rather than
races; see [`[env.remote-exclusive]`](#envremote-exclusive).

Run a dedicated instance for the suite. It creates and drops namespaces freely
and owns the root configs (`GRAPHQL`, `API`, `DEFAULT`), so anything else using
that server will lose state.

Two ways of destroying a namespace are caught rather than reported after the
fact. An exclusive test keeps its configured namespace name — the corpus default
is `test` — and drops that name before it starts; and a test's body may remove a
namespace by name, which reaches names no config mentions (a test declaring
`namespace = false` has no configured name at all, yet is exclusive precisely
because it works at root). Either way a namespace the endpoint already held goes
with every database under it, and the second is invisible afterwards as well as
irreversible: the snapshots compare name sets, so a test that removes a name and
defines it again leaves the set unchanged while the data under it is gone.

A run against an endpoint holding such a namespace is refused before any test
runs, naming the namespace and the tests claiming it:

```
ws://127.0.0.1:8000 already holds 1 namespace(s) that a test claims or removes,
which the run would drop whole and could not restore: `test` (claimed by 1
test(s): reproductions/903_use_ns_db_expression_argument.surql). Point the run
at an instance that does not hold them, or remove them yourself first.
```

The end-of-run sweep reports such a loss too, but only once it has happened and
with no way to undo it, so the check is worth making while the data is there.

Some tests can't be faithfully reproduced over the API and are reported as
**skipped** (with a reason and a count, never failing the run): tests requiring
non-default capabilities, datastore configuration keys or a versioned datastore
(all server-startup config), record-auth tests, and tests written in a wire dialect (`.pgsql`,
`.mysql`), which the server accepts on its own protocol port rather than through
the SurrealQL RPC this harness connects over. The embedded-only
retained-key/tombstone leak check is also skipped (no raw KV access over the
API).

## Features a run can be without

A test names the engine features it cannot pass without in `[test] requires`:

```toml
[test]
requires = ["scripting"]
```

`--without <features>` (comma-separated, repeatable) reports every test that requires any
of them as **skipped**, with the missing feature as the reason, on embedded and remote runs
alike. A skipped test stays in the counts, so a run without a feature reads as partly
unsupported rather than smaller. Imports count: a test importing a file that requires a
feature requires it too, and a `.graphql` file requires `graphql` without saying so.

```bash
cargo run run --without graphql,scripting,diskann,changefeed,regex
```

| Feature | A test requires it when it uses |
|---|---|
| `scripting` | embedded JavaScript functions, Surrealism modules |
| `graphql` | the GraphQL endpoint (`.graphql` files require it implicitly) |
| `diskann` | `DEFINE INDEX .. DISKANN` |
| `changefeed` | `CHANGEFEED` on a table or database, `SHOW CHANGES` |
| `regex` | the regex value type, as a result, a parameter or a literal |

The set is closed: an unknown name in a test or on the command line fails the load, so a
typo cannot become a tag that matches nothing. Adding a feature means adding it to
`Feature` in `src/tests/feature.rs` and to this table.

Tag a test that depends on a feature even where the feature is available: the tag costs an
embedded run nothing and is what lets a run against a server without it skip the test
instead of failing it.

## GraphQL tests

Besides `.surql` files the test directory can also contain `.graphql` files.
These are executed against the dynamic GraphQL schema which surrealdb-core
generates from the database catalog — the same code path as the server's
`/graphql` endpoint — instead of the SurrealQL parser. A GraphQL test produces
a single result: the response `data` on success, or the response errors joined
into an error string, so `[[test.results]]` has exactly one entry (`value` or
`error`).

Because GraphQL requires a configured database, a `.graphql` test imports a
`.surql` file (see `tests/graphql/_schema.surql`) which defines
`DEFINE CONFIG GRAPHQL`, the tables, and the data. Imports must always be
`.surql` files. The `/** ... */` config comment is not valid GraphQL syntax,
so the harness blanks it out (preserving line numbers) before execution.

A `.graphql` test can additionally set request options in a `[graphql]`
config section:

```toml
[graphql]
# GraphQL request variables for the operation.
variables = { personId = "bob", minViews = 10 }
# The operation to execute when the document defines multiple named operations.
operation = "FetchData"
```

The suite lives under `tests/graphql/`. GraphQL benches work too — see
`tests/bench/graphql/` — with the schema generated once up front so the timed
iterations measure query execution only.

## Benchmarking

The same `.surql` corpus doubles as a benchmark suite. The entry point is the
`cargo make bench` task: it **measures** timing by default, or records a
**flamegraph** with `--profile`. Pass the bench filter (a path substring) and any
flags after `--`:

```bash
# measure one bench — times the statement(s) and compares to the saved baseline
cargo make bench -- scans/count

# persist this run as the new comparison baseline
cargo make bench -- scans/count --save

# profile the measured statements with samply (opens an interactive flamegraph)
cargo make bench -- scans/where_integer_in_many_full --profile

# restrict a matrix scan to a single dataset variant (see "dataset matrix" below)
cargo make bench -- scans/where_integer_in_many_full --dataset indexed

# fast, coarse run: shrinks every timing knob ~10x (see "--quick" below)
cargo make bench -- scans/count --quick

# write per-bench results + the comparison verdict to a JSON file
cargo make bench -- scans/count --json results.json

# set a datastore configuration key for every datastore the run builds (see "--config" below)
cargo make bench -- scans/count --config morsel_split_rows=18446744073709551615 --json off.json
```

Benches run **strictly serially** (never in parallel — that would corrupt
timings). Each bench warms up, then collects `sample_size` samples and reports
mean / median / std-dev / MAD with confidence intervals, plus a comparison
against the saved baseline (improved / regressed / within-noise, with a
p-value).

`--quick` overrides every bench's timing config with much smaller values (250ms
warmup, 10 samples, 2s measurement, 10s cap) for a fast, low-power local pass: it
reliably surfaces **large** regressions but is too coarse for few-percent drift.
A bench whose single iteration, re-import included, outlasts that cap
(`QUICK_MAX_TIME` in `src/cmd/bench/run.rs`) can never collect the two samples
statistics need there, so it sets `quick = false` and quick runs skip it by
name.

`--json <path>` writes a machine-readable report — for each bench its median /
mean times and, when a baseline was found, the baseline's median, percentage
change, p-value and verdict. Used to render the PR-comparison comment.

`--config KEY=VALUE` (repeatable) sets a datastore configuration key for every datastore the
run builds, as `run --config` does: `--config morsel_split_rows=18446744073709551615` turns morsel
splitting and hand-off off, to compare a bench with and without them. Stores built under different
keys are never shared between benches, a key a bench sets itself cannot be overridden, and a run
that sets one cannot be saved with `--save`, so it cannot replace the stored baseline.

`--store-url <ws>` compares against (and, with `--save`, writes to) a remote
SurrealDB bench datastore instead of the local one. The harness `fetch_latest`es
the most recent stored measurement per bench and compares the current run against
it — which is how the PR workflow compares against the nightly `main` baseline.
Requires the `bench-remote-store` feature.

#### PR comparison (PR vs nightly `main`)

The `Language bench (PR)` GitHub Actions workflow
([`.github/workflows/language-bench-quick.yml`](../.github/workflows/language-bench-quick.yml))
manages a single sticky comment on every PR:

1. **On open**, the comment explains how to opt in (add the **`benchmark`** label).
2. **When the label is added** (and on every push while it's set), it benchmarks
   **only the PR head** (full run, on the `runner-arm-bench` pool) and compares it,
   read-only, against the latest `main` baseline in the shared bench datastore.

`main` itself is **not** benchmarked by this workflow — it's benchmarked by the
[nightly run](../.github/workflows/nightly-bench.yml) (also full, also
`runner-arm-bench`), which `--save`s `main`'s results to that store. So the
baseline is full-quality, measured on the same runner pool, and refreshes whenever
nightly re-runs (or nightly is dispatched manually after a notable change). Remove
the label to stop.

By default benches run on the in-memory engine. `--backend surrealkv` (build with
`--features backend-surrealkv`) runs
them on the file-backed engine instead, in a temporary directory that's removed
afterwards. TiKV is unsupported (it needs an external cluster). Mutating
(`rebuild = true`) benches run on `mem` only — on a file backend they'd re-import
the dataset to disk every iteration — and are skipped (with a notice) otherwise,
unless the bench sets `rebuild-file-backend = true` (see below):

```bash
cargo make bench -- scans/count --backend surrealkv
```

### `[bench]` config

```toml
[bench]
run = true                    # include this file in `bench run`
rebuild = false               # see below; defaults to false
rebuild-file-backend = false  # see below; defaults to false
quick = true                  # include in `bench run --quick`; defaults to true
warmup = "2s"                 # warmup duration
sample-size = 50              # number of samples (note: kebab-case keys)
measurement-time = "20s"      # target total measurement window
```

`rebuild` controls datastore lifecycle:

- `rebuild = false` (default): the datastore is built and imports are run **once**
  before timing, then every measured iteration executes the bench statement
  against that same stable, pre-populated dataset. This is what you want for
  **read-only** benches (scans/selects) — it lets the import populate e.g. 100k
  rows a single time and then measures only the query.
- `rebuild = true`: the datastore is rebuilt and imports re-run before **every**
  iteration. Required for **mutating** benches (CREATE / UPDATE / DELETE) which
  need a clean slate each time, otherwise state accumulates across iterations and
  the workload drifts.

`rebuild-file-backend = true` lets a `rebuild = true` bench also run under
`--backend surrealkv`, where rebuild benches are otherwise
skipped. Set it when the bench's subject is the storage layer — an index build,
say, whose cost is dominated by KV reads and which therefore measures the wrong
thing on `mem`. Each iteration builds a fresh datastore in a directory of its
own, and shuts it down and reclaims the directory once its statement has been
timed, so a run holds one copy of the dataset on disk rather than one per sample.
The re-import and the shutdown are paid every iteration, outside the timed
region, so keep `sample-size` small on a large dataset.

**Dataset sharing.** Read-only (`rebuild = false`) benches that resolve to the
same dataset — same effective import chain, capabilities, backend, and target
namespace/database — are grouped, and their dataset is built and imported **once**
then reused across the whole group (the big `records-100000` set, for example, is
imported once for the ~26 benches that share it instead of once each). Only the
timed `execute` is measured, so this changes wall-clock only, not the reported
numbers. Dataset-matrix variants (`[unindexed]` vs `[indexed]`) have different
import chains, so they form separate groups with separate datastores.

> ⚠️ Because grouped benches share one live datastore, a `rebuild = false` bench
> whose query **mutates** state (CREATE/UPDATE/DELETE/…) would corrupt the results
> of every other bench in its group. Any bench that writes data **must** set
> `rebuild = true`.

The crud-bench ports live under [tests/bench/](tests/bench) in the `scans/`,
`batches/`, and `util/` folders. The read-only scan ports set `rebuild = false`
and import a shared dataset from `util/` (100k rows mirroring
`crud-bench/config/bench.toml`'s `[value]` shape). They also set `[test] run =
false` so the 100k-row, randomly-generated dataset is exercised only by `bench
run` and not by the regular `cargo run run` correctness suite (where it would
blow the timeout and produce non-deterministic results).

Layout (under `tests/bench/`):

```
util/                                # import-only datasets (never run on their own)
  records-100000.surql               # 100k rows, NO indexes (the row generation, in one place)
  records-100000-indexed.surql       # imports records-100000 + adds the standard indexes
  records-100000-fulltext.surql      # imports records-100000 + adds analyzer + BM25 fulltext index
  records-seq-100000.surql           # 100k rows with sequential ids (for record-range scans)
  records-100.surql / records-1000.surql       # small row counts for batch CRUD
  graph-sparse-5000.surql            # 5k person nodes + ~2 `knows` edges each (sparse)
  graph-dense-5000.surql             # 5k person nodes + ~10 `knows` edges each (dense)
  graph-sparse-50000.surql           # 50k person nodes + ~2 `knows` edges each (large, uniform degree)
  graph-hub-50000.surql              # 50k person nodes; 20 fixed hubs w/ 250 edges, rest w/ 2 (degree-skewed)
  embeddings-hnsw-5000.surql         # 5k 8-d vectors + HNSW index
  embeddings-diskann-5000.surql      # 5k 8-d vectors + DiskANN index
  embeddings-flat-5000.surql         # 5k 8-d vectors, no index (brute-force KNN)
  references-5000.surql              # 5k users (+ `friends` link array) + 15k comments whose `author` is a record REFERENCE
  records-100000-perms-full.surql    # imports records-100000 + RECORD access + table PERMISSIONS … FULL (baseline)
  records-100000-perms-where.surql   # imports records-100000 + RECORD access + row-level PERMISSIONS … WHERE
  records-10000-perms-semijoin.surql # 10k + table PERMISSIONS … WHERE age IN (SELECT … FROM allow) (subquery policy)
  records-10000-fieldperms-one.surql  # 10k + perms-full + ONE field-level SELECT permission (always satisfied)
  records-10000-fieldperms-many.surql # 10k + perms-full + EIGHT field-level SELECT permissions (always satisfied)
  records-10000-indexed-perms-full.surql      # 10k + indexes + perms-full (baseline for the indexed fast paths)
  records-10000-indexed-fieldperms-one.surql  # …+ a field permission on the indexed `number` field
  records-10000-computed.surql       # 10k + three read-time COMPUTED fields (owner)
  records-10000-bucket-stored.surql  # 10k with `bucket` alone stored, equal to what records-10000-computed derives
  records-10000-computed-stored.surql # 10k with all three of those fields stored (the whole stored twin)
  records-10000-computed-chain.surql # 10k + a three-deep COMPUTED dependency chain (rank1 → rank2 → rank3)
  records-10000-computed-flat.surql  # 10k + that whole chain inlined into a single COMPUTED `rank3`
  records-10000-computed-perms.surql # imports records-10000-computed + perms-full, + a NONE-tolerant COMPUTED field
  records-10000-computed-guarded-open.surql   # …+ a field permission that withholds nothing
  records-10000-computed-guarded-cut.surql    # …+ one that withholds a field for half the rows (forces re-derivation)
  records-10000-computed-deps-static.surql    # …+ a field permission whose dependencies are statically resolvable
  records-10000-computed-deps-opaque.surql    # …+ one written with `$auth` (dependencies unresolvable)
  records-10000-perms-where-computed.surql    # row-level table permission + COMPUTED fields on the same table
  events-timeseries-100000.surql     # 100k events with timestamps spread across one year (bounded, for bucketing)
  readings-keyed-100000.surql        # 100k readings over 50 cities, record id `[city: string, time: datetime]` (named components, sub-second times)
  readings-unkeyed-100000.surql      # the same rows under random ids with `city` / `time` stored in the body (no index)
  readings-unkeyed-100000-indexed.surql # …+ a compound (city, time) index: the unkeyed answer to a per-city time window
  readings-{keyed,unkeyed}-100000-time-indexed.surql # …+ an index on `time` (the derived component / the stored field), for retention deletes
  readings-array-ids-100000.surql    # the rows under array ids `[city, time]` with no named components and equal `city` / `time` copies in the body
  readings-{keyed,unkeyed,unkeyed-indexed}-empty.surql # empty tables, for the create-throughput matrix
  geo-points-100000.surql            # 100k places each with a `location` point spread across the globe
  recursion-functions.surql          # recursive user functions (fn::fib branching, fn::sum_to linear)
  recursion-items-dynamic-1000.surql  # imports recursion-functions + 1000 items with a recursive DYNAMIC (VALUE, write-time) field
  recursion-items-computed-1000.surql # imports recursion-functions + 1000 items with a recursive COMPUTED (read-time) field
scans/
  count / limit / start_limit        # no filter — indexing is irrelevant
  where_*.surql                      # filter scans — run against BOTH datasets (see below)
  aggregate_* / subquery_*           # GROUP BY / GROUP ALL stats / uncorrelated subqueries
  order_by_score_desc / range_scan_* # full sort; contiguous record-id range (± ORDER BY)
fulltext/                            # BM25 search: single / multi-AND / multi-OR (`@@`)
graph/                               # 1-/2-hop (+ counts), filtered, mid-path filter, inbound,
                                     #   bidirectional, recursive, path-collect, shortest-path traversals
                                     #   (each runs against BOTH the sparse and dense graph; two_hop and
                                     #   shortest_path also carry a `large` arm against graph-sparse-50000)
                                     #   plus deep_recursion (6 hops), hub_fanout (250-edge hub node,
                                     #   graph-hub-50000 only), and traverse_aggregate (math::mean over
                                     #   a traversed neighbour set)
vector/                              # KNN: HNSW vs DiskANN vs brute-force
references/                          # record references: reverse (`<~`) traversal/count/filtered, FETCH single + array
mutate/                              # UPDATE/DELETE … WHERE, batch UPSERT, explicit transaction
crud/                                # batch create/read/update/delete (100, 1000)
permissions/                         # per-record permission cost as a RECORD user: table-level SELECT +
                                     #   UPDATE over a row-level `WHERE` vs. `FULL` matrix; a table policy
                                     #   written as a subquery vs. a scalar predicate; and the field-level
                                     #   guards that withhold the scan fast paths — full read, filter scan
                                     #   (pre-decode filter), ORDER BY … LIMIT (TopK threshold probe),
                                     #   indexed COUNT, and COUNT fallback
computed/                            # read-time COMPUTED field materialisation: full read, selective
                                     #   projection, dependency chain, filter / COUNT / ORDER BY … LIMIT
                                     #   over a computed key, and the intersection with field permissions
                                     #   (unreduced-record clone, re-derivation against the reduced record)
timeseries/                          # temporal bucketing: GROUP BY time::group(…) by day / hour (± per-bucket stats)
                                     #   plus named record-id components: a one-hour key-range window (one city, IN over
                                     #   three), the latest ten rows of a city, a LET-cutoff retention delete over an index
                                     #   on the derived `time`, create throughput, a full `SELECT *` (derived vs stored
                                     #   components), and the define-time scan of 100k records. The matrix benches run the keyed
                                     #   table against its unkeyed twin (`--dataset keyed` / `unkeyed` / `stored` / `unkeyed_indexed`)
geo/                                 # FULL-SCAN geo functions (no spatial index yet, #219): geo::distance
                                     #   proximity & nearest-N, point-in-polygon containment (INSIDE)
recursion/                           # recursive USER functions (fn::fib, per-row fn::sum_to) + recursive
                                     #   DYNAMIC (VALUE, write-time) vs. COMPUTED (read-time) fields
```

The derived datasets import the base via `[env] imports = ["./records-100000.surql"]`
and only add their indexes — the 100k-row generation block lives in exactly one
file. Imports are resolved transitively, so a scan importing
`records-100000-indexed` runs `records-100000` first.

Each conditional (`WHERE`) scan is a single file that runs against **both**
datasets via the dataset matrix — `[bench].datasets` is a name → import map:

```toml
[bench]
rebuild = false
datasets = { unindexed = "../util/records-100000.surql", indexed = "../util/records-100000-indexed.surql" }
```

The harness expands this into one run per named dataset (labelled `[unindexed]`
and `[indexed]`), so the identical query is measured both doing a full table scan
and using the index — from one file, no duplication. Run the whole set or one
query (both variants run):

```bash
cargo make bench -- scans
cargo make bench -- scans/where_integer_eq_full
```

To run a single matrix variant, add `--dataset <name>` (matched exactly against
the dataset names):

```bash
cargo make bench -- scans/where_integer_eq_full --dataset unindexed
cargo make bench -- scans/where_integer_eq_full --dataset indexed
```

`--dataset` only affects matrix benches; non-matrix benches (count, limit,
fulltext, …) are unaffected.

The `permissions/` benches reuse the matrix for a different axis: instead of
unindexed-vs-indexed they run a `full`-vs-`where` permission pair, and the bench
file sets `[env].auth` to a **record user** (`Session::for_record`). Per-record
table permissions are only evaluated for record-level actors — owner/editor/viewer
sessions take a fast path that skips them entirely (so the existing `scans/` and
`mutate/` benches, which run as owner, never pay this cost). The `full` variant
allows every action with no predicate; the `where` variant attaches a row-level
`WHERE` clause that is satisfied by every row, so both arms return the same data
and the delta isolates the per-record predicate-evaluation cost.

Field-level permissions are measured the same way, and every guard in these
datasets is written so that it is **satisfied by every row** unless the bench is
specifically about withholding: the arms then return identical documents and the
delta is the enforcement machinery, not a different result set. Enforcing them
costs more than the guard predicates, because it withdraws the scan-side fast
paths that read a field straight from revision-encoded bytes — the pre-decode
WHERE filter, the TopK threshold probe, and the indexed-COUNT paths all require
every field they touch to carry an `Allow` SELECT permission. Read-time COMPUTED
fields disqualify the same paths, which is why `computed/` and `permissions/`
share a shape: each bench pairs the restricted or computed arm against an
otherwise identical one whose field is plain and stored.

Where the two features meet, a table pays more than the sum: a row carrying both
computed fields and a restricted field is cloned per record so guards and
re-derivation each have the view they must read, and withholding a stored field
re-derives *every* computed field on the table. `computed/guarded_reread` measures
the three tiers (no guard / guard satisfied / guard withholding), and
`computed/select_projected` measures the projection pruning that a guard written
with a parameter gives up.

Not every combination costs anything, and one arm is there to pin that: the
conditional-permission COUNT fallback judges the table permission against the
decoded record without ever building field state, so computed fields on that
table are free to it. `permissions/count_scan[where_computed]` is a control that
should stay level with `where`; a count that genuinely needs a derived value —
because its WHERE reads one — is `computed/count_filter`.

### Profiling & flamegraphs

Add `--profile` to record a flamegraph of the measured statements with
[`samply`](https://github.com/mstange/samply), built through the `profiling`
cargo profile (release + `line-tables-only` debug info, unstripped,
`panic=unwind`, thin-LTO for fast iterative rebuilds):

```bash
cargo make bench -- scans/where_integer_in_many_full --profile
# saves target/bench-profile/<slug>.json.gz (+ a <slug>.json.syms.json symbol
# sidecar next to it), then:
samply load target/bench-profile/<slug>.json.gz   # interactive flamegraph in the browser

# one variant of a matrix scan (one import, one measured region):
cargo make bench -- scans/where_integer_in_many_full --profile --dataset indexed
```

The profiler records with `--unstable-presymbolicate`, which resolves symbols at
record time (the binary + its `.o` debug-map files are present then) into the
`.syms.json` sidecar. `samply load` reads it automatically, so frames show
function names rather than raw hex addresses — keep the sidecar next to the
profile. (Attach-mode samply otherwise defers symbolication to load time and
can't find the debug info.)

**The profile covers only the measured statements — not the dataset setup.** For
a `rebuild = false` scan, the one-time 100k-row import (document generation +
index build) would otherwise dominate the flamegraph even though it isn't timed.
To avoid that, the harness prints a `__BENCH_MEASURE_START__` marker on stderr
(when `BENCH_MARKERS=1`) just before the timed loop; the profiler runs the import
and warmup un-sampled, waits for that marker, then attaches `samply record -p
<pid>` for the measured region only.

samply is used instead of `cargo flamegraph` because it samples without `sudo`
on both macOS and Linux (`cargo flamegraph` relies on `dtrace`, which is
SIP-restricted on macOS). On macOS the script runs `samply setup --yes` once to
codesign the sampler.

### Under the hood

`cargo make bench` runs `scripts/bench/bench.sh`, which forwards the filter and
flags to `scripts/bench/measure.sh` (timing, the default) or, with `--profile`,
`scripts/bench/profile.sh` (samply). You can call those scripts directly with the
same arguments, or drive the harness binary yourself:

```bash
# run every bench (no filter), or one by path substring; flags are all optional
cargo run --features bench -- bench run [--save] [--dataset NAME] [--backend mem] [--quick] [--json PATH] [<filter>]
```

### Determinism

Two process-wide sources of randomness would otherwise make a bench measure a
different amount of work on each run; the harness pins both, so a local run and a
CI run see the same data and the same index structures:

- **Generated data.** Every dataset build reseeds the engine RNG, so `rand::*`
  values and `|record:N|` ids are identical across runs and independent of
  benchmark order. Override with `SURREAL_RAND_SEED=<u64>` to redraw the datasets
  from a different, still fixed, seed.
- **HNSW graph construction.** HNSW picks each element's layer at random, so an
  unseeded build gives the same kNN query a different graph to traverse on every
  run — worth far more than any regression the suite could catch. The harness
  pins the seed; override with `SURREAL_HNSW_BUILD_SEED=<u64>`.

Re-run a surprising ANN result with a different `SURREAL_HNSW_BUILD_SEED` on both
sides before trusting it: a fixed seed removes the variance between runs, but it
does not prove the change generalises beyond that one graph.

`scripts/bench/optimise.workflow.js` is a workflow recipe driving an AI
optimisation loop: baseline → inspect the profile → propose & apply one engine
change → re-measure → keep only if the harness reports a significant speedup. See
the header of that file for how to launch it.

## SurrealQL Language Test Format

Language test are plain surrealql files that are parse-able by the normal
surrealql parser. Any surrealql file can be a surrealql test, however for a test
to be useful it needs to specify a test configuration. This is done by
including a special comment, called here after a test comment, in the surrealql
file which specifies how the test should be run and their results verified.

Test comments are either single line forward slash comments in the form of `//!`
or a multi line comment in the form of `/** */` (note the `!` and extra `*`).
When a test is run all the tests comments are concatenated and parsed as TOML.

See below an example of a surrealql test file.

```surrealql
/**
# The env map configures the general environment of the test
[env]
namespace = false
database = false
auth = { level = "owner" }
signin = {}
signup = {}

[test]
# Sets the reason behind this test; what exactly this test is testing.
reason = "Ensure multi line comments are properly parsed as toml."
# Whether to actually run this file, some files might only be used as an import,
# setting this to false disables running that test.
run = true

# set the expected result for this test
# Can also be a plain array i.e. results = ["foo",{ error = true }]
[[test.results]]
# the first result should be foo
value = "'foo'"

[[test.results]]
# the second result should be an error.
# You can error to a string for an error test, then the test will ensure that
# the error has the same text. Otherwise it will just check for an error without
# checking it's value.
error = true
*/

// The actual queries tested in the test.
RETURN "foo";
1 + "1";
```

## SurrealQL Language Test Config Format.

The surrealql test config is specified within the test comment. It is formatted
in toml and contains the following sections:

- `[test]` Defines the information about the test

    - `reason` a string for detailing why the test exists.
    - `run` a flag whether this file should be run as a test
    - `issue` the github issue number to which this test is related.
    - `wip` whether this test is of a known issue or a work in progress feature
    - `version` the version requirement for the test running datastore.
    - `importing-version` the version requirement for the importing datastore.
    - `[results]` an table which specifies the expected results of the test

- `[env]` Defines information about how the test should be run.
    - `sequential` should the test be run without any other test running in
      parallel
    - `clean` should the test be run in a completely clean database.
    - `namespace` the namespace, if any, to run the test in
    - `database` the database, if any, to run the test in
    - `imports` a list of files to run before the test.
    - `timeout` a duration in milliseconds that the test is allowed to take.
    - `[login]` the login configuration into the dataset.
    - `[capabilities]` a configuration of database capabilities in which the
      test should run.
    - `remote-skip` a reason string that excludes the test from remote
      (`--endpoint`) runs.
    - `remote-exclusive` the test reaches outside its own namespace, so a remote
      (`--endpoint`) run gives it the endpoint to itself.

All keys in the config are optional and have default values if not explicitly
specified.

### `[test]`

The `[test]` table specifies the information about the test itself.

#### `[test.run]`

Sometimes you want to include a SurrealQL file into the testing suite but not
actually care about it's results, for example when the file is intended for as
an import for other test files. In this case you can disable running the file as
a test by setting `[test.run]` to false. Defaults to `true`

#### `[test.wip]`

Some tests can be test for a work in progress feature or a known issue or bug
that we cannot fix right now. We can still test these these bugs and features by
setting `[test.wip]` to true. Doing so will turn errors in the
tests results into warnings which prevents a test run which includes such a test
from failing. Furthermore it will also exclude the tests from having it's
results automatically be updated by the CI tool when running with
`--results accept` or `--results overwrite`. Defaults to `false`

#### `[test.reason]` and `[test.issue]`

Information about the test it's reason to exist and the issue from which it
originated. These are mostly just for documentation however when a test is
`wip` and has an issue specified the CLI will then suggest closing the issue if
the test succeeded. Both default to `None` i.e. have no value.

#### `[test.version]`

The version requirement for this test. If the test is run with a surrealdb
version which does not meet the version requirement it will not be run.

The field expects a string with a version requirement with the semantic
versioning format. The same format that is used for specifying rust dependency
versions in `Cargo.toml`.

When importing a file with this field the version is still checked against the
importing datastore version and if it does not match the entire test will not
run.

Defaults to `"*"`

#### `[test.importing-version]`

The version requirement for the imports of this test. If the import is run with
a version which does not meet the version requirement the entire test will not
be run.

The field expects a string with a version requirement with the semantic
versioning format. The same format that is used for specifying rust dependency
versions in `Cargo.toml`.

It also takes an array of such requirements, and then a version any one of
them admits is accepted. That is for a set of releases that is not one range:
a fix can reach an older line in a patch that ships after a newer line's early
releases, which leaves the releases still carrying a defect on both sides of
the ones that fixed it, as in `["<3.2.5", ">=3.3.0-beta.1, <3.3.0-beta.5"]`.

This field is not that usefull for normal test as the importing datastore and
the test running datastore are always the same. Instead this field is intended
for upgrade tests where the upgrading datastore version can differ from the
test running datastore.

Defaults to `"*"`

#### `[test.legacy-syntax]`

Marks an upgrade helper written in the SurrealQL of the released binary that
replays it, in a spelling the current parser no longer accepts. `DEFINE MODULE`
is the standing example: the releases in the upgrade matrix spell the module
source `AS f"bucket:/key"` and have no `UNSIGNED` keyword, so a script that
writes one on those binaries cannot also be a document the current parser reads.

The current parser's language-test corpus check reads this flag and leaves such
a file alone, which is why it is a declared key and not a comment. Only a script
replayed against a spawned release may set it — an `[env] imports` entry or a
`[test.chain] setup`. A test body and a `[test.chain] mutate` run on the upgrade
target, so the runner refuses the flag on either.

Defaults to `false`

#### `[test.results]`

The test results table specifies the expected out of the test. The command line
tool will warn about every test that does not include this table in its
configuration. This table can either be a straight table or an array of tables.

Examples:

```toml
[test.results]
parsing-error = "foo"
```

This tests if the test returns a parsing error with the text `foo`. A test is
parsed once and can only return a single parsing error. So when testing for a
parsing error only a single result is allowed to be specified.

```surql
/**
[test]

[test.results]
parsing-error = """
Invalid function/constant path, did you maybe mean `type::record`
  --> [16:1]
   |
16 | type::thing("person", "one");
   | ^^^^^^^^^^^
"""

*/

type::thing("person", "one");

// Can't add this extra assertion inside the same file
// Must be a separate file with its own [test.results]
// string::slayce();
```

Note that the following are also allowed:

```toml
[test.results]
parsing-error = true

[test.results]
parsing-error = false
```

Specifying a boolean will check for the presence or absence of a parsing error
but will not check the value of the error.

If the test is not intended to return a parsing error it is general best to
specify the actual expected output of the tests. A single SurrealQL query can
consist of multiple statements which produce either zero or one result. The test
allow specifying the expected number and value of the results. Generally
specified test results will look like the following:

```toml
[[test.results]]
value = "[{ id: foo:bar, name: 'bar' }]"

[[test.results]]
error = "Some error is happening here"

[[test.results]]
error = false

[[test.results]]
error = true
```

For long string expectations (for example multi-line `EXPLAIN` output), use a TOML
multiline basic string (`"""…"""`) so each logical line is a real newline in the
file instead of `\n` escapes. The value is still SurrealQL parsed like any other
`value` field; literal newlines inside quoted strings are valid SurrealQL. The
`EXPLAIN` text helpers in the database end the string with a newline before the
closing quote, so keep that final line break before `'` (often with the closing
`'` alone on the last line) so the expected value matches.

```toml
[[test.results]]
value = """
'SelectProject [ctx: Db] [projections: *]
    TableScan [ctx: Db] [table: item, direction: Forward, predicate: score > 15, pre_decode_filter: yes]
'"""
```

Above we specify that the test should return two results. The first should be a
value as described by the value in the string. When specifying a value in TOML
strings containing SurrealQL are used. The second result should be an error with
the given string as the error text. The third result just specifies that that
result should not be an error but gives no details about what the actual value
should be. The final result only specifies that the result should be an error
but not what the error text should be.

A test with these results will fail if the test returned less or more values and
the results are not equal to the given results.

##### Rough equality

There are some values in SurrealQL which are inherently indeterministic and so
would cause problems for test which check if the output is always the same.
Generic record-id's is an example, they generally have a ULID key which is
always random.

This can be solve with matching expressions but for some common situations it
is possible to ignore some parts of the value when matching with the following
fields: `skip-datetime`, `skip-record-id-key`, or `skip-uuid`. Setting any of
these fields in a `[[test.results]]` record will skip equality testing the
corresponding values.

For example:

```toml
[[test.results]]
value = "foo:bar"
skip-record-id-key = true
```

Will match any record-id as long as the table is `foo` but the record-id-key is
ignored.

##### Matching expressions

When matching against a value is not possible you can also fall back to running
a SurrealQL expression to match the output. Results which should be validated
with a matching expression are created by setting the `match` field on
`[[test.results]]`. The match expression must be a valid surrealql expression
which should return a boolean true when the expression found the output to be
valid. The matching expression can access the value with either the `$result`
param or the `$error` param. The latter being defined when the output of the
current matched statement was an error, being defined with the text of the error
as a string. It is often the case that a matching expression should only match a
value or an error but not both. In this case you can set the `error` field on
the same `[[test.results]]` to either true or false depending on if an error was
expected or not. See below for some examples of matching expressions:

```toml

# Tests if the statement output was either the string foo or an error: 'An error
# occurred: foo'
[[test.results]]
match = "$result == 'foo' || $error == 'An error occurred: foo'"

# Tests an error with a regex as some parts of the error are non-deterministic.
[[test.results]]
match = "$error = /Found record: `thing:.*` which is not a relation, but expected a  NORMAL/"
# This matching should only match errors.
error = true

# Test whether the field of a result matched the regex
[[test.results]]
match = """
$result.users.test = /DEFINE USER test ON ROOT PASSHASH '\\$argon2id\\$.*' ROLES VIEWER DURATION FOR TOKEN 1h, FOR SESSION NONE/
"""
error = false
```

##### Traces

A test that sets [`[env.trace]`](#envtrace) runs its query as a traced request,
and each statement's trace is graded beside its value. A result written as a
table states the trace under `trace`, in SurrealQL like `value`:

```toml
[[test.results]]
value = "[place:cafe, place:lib]"
trace = "{ relations: [[person:a, customer_of:a_cafe, place:cafe], [person:a, customer_of:a_lib, place:lib]] }"

# A statement whose trace must be empty states none.
[[test.results]]
value = "[{ id: person:a }]"

# A match expectation can carry a trace too.
[[test.results]]
match = "type::is_uuid($result)"
trace = "{ subscriptions: [u'00000000-0000-0000-0000-000000000000'] }"
```

A result that states no `trace` expects the statement to send none, so a traced
test fixes what every statement reports, the empty ones included. A failed
statement sends no trace and is written as an error.

Traces are compared after the entries of `relations`, `references`, `links` and
`subscriptions` are sorted, because the engine orders them by when it walked
them. Duplicates are kept, so an entry reported twice is a mismatch. Uuids are
compared loosely, because a live query's id is new on each run.
`--results accept` writes the `trace` of every statement that sent one.

### `[env]`

The `[env]` table specifies the environment in which the test must be run.

#### `[env.clean]`

To ensure test run quickly the CLI will generally try to reuse databases between
tests. When a test is completed the database and namespace it ran in will be
removed so that the next test can be ran in a clean environment. If a test can
cause a database to be altered even after the database and namespace where
removed then the test should be run within a fully clean database. This can be
done with this flag which will cause the test to be run in a freshly create
database which will be destroyed after the test completes. Defaults to `false`.

#### `[env.sequential]`

To run test as quickly as possible test the CLI will try to run tests in
parallel when possible. If this would cause issues or if this test consume a lot
of threads it might be better to ensure that no other test is running at the
same time. Setting `[env.sequential]` will ensure that a test is run when no
other test is running. Defaults to `false`.

#### `[env.namespace]` and `[env.database]`

These keys set the name of the namespace and database the test is run in. These
can either be a string or a boolean. When the key is a string the string will be
the name for the namespace or database. If the key is false then the test will
not be run in a namespace or database. If the key is true it will default to the
default namespace and database name: `"test"`. Defaults to `true`

#### `[env.imports]`

An array of string which you can use to specify files to run before running the
test. If the path starts with `./` or `../` the path is relative to the directory
of the current file otherwise the path is relative to the root of the test
directory. Each of these files will be run in a database with full capabilities
and the given namespace and database. The test is only run after the files in
imports are run to completion.

When importing a test the `[test.version]` field of the imported test is
checked against the version of the importing datastore. If it does not match
than the entire test is not run.

This can be used to import a dataset before running queries, importing
utility functions, or setting up a database with root access before running 
permission specific tests.

Defaults to `[]`

#### `[env.trace]`

The trace kinds the test's query asks for, the names a `query` call's `trace`
option takes: `"relations"`, `"references"`, `"links"`, `"variables"` and
`"subscriptions"`. A test that names any runs as a traced request with those
kinds, and its results state each statement's trace (see
[Traces](#traces)). A test that names `"subscriptions"` runs on a session that
may open live queries, and declares [`[env.clean]`](#envclean), because a live
query stays registered on the node after the namespace is removed.

Traced tests run only in-process; `run --endpoint` skips them.

```toml
[env]
imports = ["language/trace/graph_import.surql"]
trace = ["relations", "links"]
```

Defaults to `[]`

#### `[env.backend]`

Specifies which backends (storage engines) the test should run on. This is useful 
when a test is specific to certain backend implementations or when testing 
backend-specific features like compaction.

The value should be an array of strings with valid backend identifiers:
- `"mem"`: In-memory storage engine
- `"surrealkv"`: SurrealKV file-based storage engine
- `"tikv"`: TiKV distributed storage engine

**Behavior:**
- If the array is **empty** (default): The test runs on all backends
- If the array is **specified**: The test only runs when the selected backend (via `--backend` CLI flag) is in the list
- If no `[env]` section exists: The test runs on all backends

**Examples:**

```toml
# Test that only runs on SurrealKV
[env]
backend = ["surrealkv"]
```

```toml
# Test that runs on both memory and SurrealKV backends
[env]
backend = ["mem", "surrealkv"]
```

```toml
# Test that runs on all backends (empty array)
[env]
backend = []
```

```toml
# Test that runs on all backends (no backend field specified)
[env]
namespace = "test"
# No backend field means run on all backends
```

This feature is particularly useful for testing backend-specific operations. For 
example, the `ALTER TABLE COMPACT` statement behaves differently on different 
backends: it returns an error on both the memory and SurrealKV backends, which do not support compaction.

Defaults to `[]` (runs on all backends)

#### `[env.versioned]`

Specifies whether the test requires MVCC versioning to be enabled on the datastore.
When set to `true`, the datastore is created with versioning support, enabling
temporal queries using the `VERSION` clause.

Tests with `versioned = true` always get a fresh datastore (they cannot reuse the
shared datastore pool) since they require different datastore configuration.

Versioning is available only on the `surrealkv` backend, which the
runner opens with `?versioned=true`. `mem` and `tikv` are opened without it and
reject a versioned statement, so versioned tests are skipped on those two and a
test that does not name `surrealkv` runs nowhere.

**Examples:**

```toml
# Test that requires versioning on the SurrealKV backend
[env]
backend = ["surrealkv"]
versioned = true
```

```toml
# Test with versioning on all backends that support it (mem and tikv are skipped)
[env]
versioned = true
```

Defaults to `false`

#### `[env.config]`

Datastore configuration keys the test needs, as `--config KEY=VALUE` gives them to a run. Each
takes the place of the same key given to the run, and the run's other keys stay. A test that names
a key gets a datastore of its own. Values are strings, since a count can exceed what a TOML integer
holds. A remote (`--endpoint`) run skips such a test, since the endpoint's datastore is configured
where it started.

A test that holds a property only when its scans do not split pins it this way under a run that
forces morsels:

```toml
[env.config]
morsel_split_rows = "18446744073709551615"
```

Defaults to no keys.

#### `[env.timeout]`

Specifies a duration in milliseconds within which the entire test should finish. 
This controls the overall test execution time from start to finish. If the test 
takes longer than the given duration it will be considered an error and it will 
cause a test run to fail. This key can also be set to `false` to disable the 
timeout altogether or `true` to default to 5 seconds. Defaults to `5000` (5 seconds).

#### `[env.timeout-tikv]`, `[env.timeout-surrealkv]`

Backend-specific timeout overrides in milliseconds. When running tests against a 
specific backend, these values take precedence over the base `timeout`. This is 
useful for tests that are known to be slower on certain backends (e.g., TiKV due 
to network latency).

**Example:**
```toml
[env]
timeout = 5000           # Timeout for memory backend
timeout-tikv = 10000     # TiKV needs 2x more time due to network latency
timeout-surrealkv = 6000 # SurrealKV may need slightly more time for disk I/O
```

#### `[env.context_timeout]`

Specifies a duration in milliseconds for individual query execution within the 
datastore context. This controls how long each query is allowed to run. If a 
query takes longer than the given duration, it will be terminated. This key can 
also be set to `false` to disable the context timeout altogether or `true` to 
default to 5 seconds. Defaults to `5000` (5 seconds).

#### `[env.context-timeout-tikv]`, `[env.context-timeout-surrealkv]`

Backend-specific context timeout overrides in milliseconds. Similar to the timeout 
overrides, these allow setting different query execution limits per backend.

**Example:**
```toml
[env]
context-timeout = 5000           # Default context timeout
context-timeout-tikv = 10000      # TiKV queries may take longer
```

Note: `[env.timeout]` and `[env.context_timeout]` serve different purposes:
- `timeout`: Controls the entire test execution time (end-to-end)
- `context_timeout`: Controls individual query execution time within the test


#### `[env.signin]` `[env.signup]`
Specifies how to signin and signup into to the datastore. This field expects a
object with fields similar to the fields passed to signin/signup RPC methods.
For example:
```toml
[env]
signin = """{
	ns: "test",
	user: "ns_user",
	pass: "pass",
 """
```
Will run a signin to the namespace `test` with the username `ns_user` and the
password `pass`. 

Signin and signup happen before the test is run but after the imports are run.
The imports are always run as root. If an error happens during signin or signup
than that error will be the result of a test. This error can be matched against
just like a parsing error.


This field is not supported for upgrade tests.

#### `[env.auth]`
Specify the authority with which the test is run, unlike `[env.signin]` and
`[env.signup]` this field bypasses the normal checks and code run to validate
signin and signups. This field can be one of 4 different variants:
```toml
[env]
auth = { level = "viewer" }
```
Will authenticate with the viewer role on the datastore root.
```toml
[env]
auth = { namespace = "ns", level = "viewer" }
```
Will authenticate with the viewer role on the namespace `ns` .
```toml
[env]
auth = { namespace = "ns", database = "db", level = "viewer" }
```
Will authenticate with the viewer role on the namespace `ns` and the database `db`.
```toml
[env]
auth = { namespace = "ns", database = "db", access = "access_definition", rid = "user:account" }
```
Will authenticate on the namespace `ns` and database `db` as the access method `access_definition` with the record id `user:acount`.

This field is not supported for upgrade tests.

#### `[env.capabilities]`

This is a table which can be used to specify the capabilities with which the
database should be run. This can be used to disable functions, net targets,
http routs and scripting just like with the SurrealDB binary/rust SDK. Defaults
to all capabilities enabled.

Upgrade tests accept exactly one key here, `allow-experimental`, which is
passed to each spawned binary; every other key is rejected, and writing the
table without that key is a load error. It must sit on the graded test case —
on an import or a chain script it is inert.

#### `[env.remote-skip]`

Excludes the test from remote (`--endpoint`) runs, reporting the given string as
the skip reason. Embedded runs ignore it entirely.

It is for the narrow case of a test whose expectation only holds against an
embedded, in-process datastore, and which would therefore fail over the API for
a reason that is not a defect — a connection-less `$session`, the absence of a
bootstrap root user, or a path resolved against the harness's working directory.
Everything the harness can decide for itself (non-default capabilities,
datastore configuration keys, a versioned datastore, record auth, wire dialects, and GraphQL/GQL under non-owner
auth) is skipped automatically and needs no key.

The string is shown in the run summary, grouped by reason, so write it as the
reason the test cannot be reproduced rather than as a label:

```toml
[env]
remote-skip = "asserts $session.id, which over the API is the per-connection id but is NONE for the embedded harness's connection-less session"
```

Reach for it last. A test skipped here is coverage the remote run does not have,
so prefer fixing the test to be transport-independent where that is possible.

#### `[env.remote-exclusive]`

Remote (`--endpoint`) runs execute tests concurrently against the one server,
and what keeps them apart is a namespace each: a test is given one named
`lt_<run>_<n>`, and everything it writes there goes away with it at cleanup.
Embedded runs ignore this key — every test there already has a datastore of its
own, so there is nothing to share.

Set it when a test does not fit inside a namespace:

- it creates a root user, root access method, or namespace, or changes a system
  setting (`ALTER SYSTEM`, `CONFIG DEFAULT`);
- it asserts on the literal name of the namespace it runs in — `USE DB other`
  answers `{ database: 'other', namespace: 'test' }`, and `session::ns()`
  returns the same;
- it names a namespace in SurrealQL that the harness would otherwise rename
  under it, e.g. `USE NS test DB test` in the body.

Such a test then runs alone, in the namespace its `[env] namespace` names, with
cleanup removing whatever root-level entities appeared while it ran. A test
declaring `namespace = false` has nowhere but root to write and is exclusive
automatically — it needs no key.

```toml
[env]
remote-exclusive = true
```

**A test that needs this and does not declare it fails rather than races.**
An `ALTER SYSTEM` is caught before the run starts, in the test's source and in
its imports, and refuses to schedule the run at all — the setting it changes
applies to every request the server is serving, so a test that restores it still
imposes it on whatever ran beside it, and a check made afterwards would find
nothing to report.

Everything else is caught after cleanup: a concurrent test's root-level state is
compared against a reading taken before the run began, and anything new fails the
test by name:

```
> Test failed, it created root-level state but is not marked `[env] remote-exclusive`:
  - NAMESPACE `test_namespace`
  - USER `root_secret` ON ROOT
```

The endpoint is asked rather than the source read, so this holds however the
state got there — the test's own body, one of its `imports`, or a function it
calls. What it cannot see is the second and third cases above, which are
ordinary expectation failures.

The comparison also runs the other way. A test is as free to *remove* root state
the endpoint already had as to add some, and that cannot be undone — a snapshot
holds names, not definitions, and `INFO FOR ROOT` redacts a user's hash, so
recreating one would invent an account rather than restore it. It is therefore
reported rather than repaired. An exclusive test that removes a pre-existing root
user, access or namespace fails by name, and the end-of-run sweep reports
anything else that went missing and fails the run:

```
 ws://127.0.0.1:18283 was not left as this run found it; removed by this run and
 not restorable: ACCESS `planted_ac` ON ROOT, USER `planted` ON ROOT
```

The per-test check for a concurrent test stays one-way on purpose: it puts the
baseline back after reporting, so that one offender does not go on to fail every
test after it, and a removal is the one thing it cannot put back. The sweep
reports those once, for the run.

Keep the declaration to tests that need it. Each one is a point where the run
stops and waits for every job to drain, so it is the one part of the suite that
does not get faster with `--jobs`.

## Markdown tests.

The language test suite is able to extract tests from markdown files when compiled
with the `docs` feature. When this feature is enabled the language test suite will
also search files with the extension `.md` and `.mdx`, looking for code blocks 
marked with `surql` as it's language. The suite will run all tests in these files
resulting in possibly multiple test per files. Codeblocks can be excluded from 
running as a test by adding `notest` after the `surql` code block header.
