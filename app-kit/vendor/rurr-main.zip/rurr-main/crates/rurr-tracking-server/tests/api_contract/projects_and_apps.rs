use super::*;

async fn assert_truncated_trailing_log_line_ignored(kind: TrackingEndpointKind) {
    let (_tempdir, app) = truncated_log_tempdir_app();
    let response = tracking_endpoint_request(&app, kind, "proj1", "app1", "pk").await;

    assert_eq!(
        response.status(),
        StatusCode::OK,
        "truncated trailing log lines should not cause 500"
    );
    let payload = response_json(response).await;
    match kind {
        TrackingEndpointKind::Apps => {
            assert_eq!(payload.get("total"), Some(&json!(1)));
            assert_eq!(payload.get("has_another_page"), Some(&json!(false)));
            assert_eq!(payload["applications"][0]["app_id"], json!("app1"));
            assert_eq!(payload["applications"][0]["num_steps"], json!(1));
            assert!(payload["applications"][0].get("last_action").is_none());
            assert!(payload.get("items").is_none());
        }
        TrackingEndpointKind::AppDetail => {
            assert_eq!(payload["application"]["entrypoint"], json!("noop"));
            assert_eq!(
                payload["steps"].as_array().map(Vec::len),
                Some(1),
                "only complete begin/end log entries should form one Burr step"
            );
            assert!(payload.get("log").is_none());
        }
        TrackingEndpointKind::Projects => unreachable!("projects endpoint is not used here"),
    }
}

#[tokio::test]
async fn projects_apps_and_app_detail_endpoints_read_local_fixture() {
    let (_tempdir, app) = fixture_tempdir_app();

    let projects = projects_request(&app).await;
    assert_eq!(projects.status(), StatusCode::OK);
    let projects_json = response_json(projects).await;
    assert_eq!(projects_json[0]["name"], json!("proj1"));
    assert_eq!(projects_json[0]["id"], json!("proj1"));
    assert_eq!(projects_json[0]["num_apps"], json!(2));
    assert_eq!(projects_json[0]["uri"], Value::Null);
    assert!(projects_json[0]["created"].is_string());
    assert!(projects_json[0]["last_written"].is_string());

    let apps = apps_request(&app, "proj1", "pk", 10, 0).await;
    assert_eq!(apps.status(), StatusCode::OK);
    let apps_json = response_json(apps).await;
    assert_eq!(apps_json.get("total"), Some(&json!(1)));
    assert_eq!(apps_json.get("has_another_page"), Some(&json!(false)));
    assert_eq!(apps_json["applications"][0]["app_id"], json!("app1"));
    assert_eq!(apps_json["applications"][0]["partition_key"], json!("pk"));
    assert_eq!(apps_json["applications"][0]["num_steps"], json!(1));
    assert_eq!(apps_json["applications"][0]["tags"], json!({}));
    assert!(apps_json["applications"][0]["first_written"].is_string());
    assert!(apps_json["applications"][0]["last_written"].is_string());
    assert!(apps_json.get("items").is_none());

    let app_detail = app_detail_request(&app, "proj1", "app1", "pk").await;
    assert_eq!(app_detail.status(), StatusCode::OK);
    let detail_json = response_json(app_detail).await;
    assert_eq!(detail_json["application"]["entrypoint"], json!("noop"));
    assert_eq!(detail_json["steps"].as_array().map(Vec::len), Some(1));
    assert_eq!(
        detail_json["steps"][0]["step_start_log"]["action"],
        json!("noop")
    );
    assert_eq!(
        detail_json["steps"][0]["step_end_log"]["action"],
        json!("noop")
    );
    assert!(detail_json.get("log").is_none());
}

#[tokio::test]
async fn unpartitioned_apps_routes_use_none_partition_semantics() {
    let (_tempdir, app) = single_app_tempdir_app("proj_none", "app_none", None);

    let apps = apps_request(&app, "proj_none", "__none__", 10, 0).await;
    assert_eq!(apps.status(), StatusCode::OK);
    let apps_json = response_json(apps).await;
    assert_eq!(apps_json.get("total"), Some(&json!(1)));
    assert_eq!(apps_json["applications"][0]["app_id"], json!("app_none"));
    assert_eq!(apps_json["applications"][0]["partition_key"], Value::Null);

    let app_detail = app_detail_request(&app, "proj_none", "app_none", "__none__").await;
    assert_eq!(app_detail.status(), StatusCode::OK);
    let detail_json = response_json(app_detail).await;
    assert_eq!(detail_json["parent_pointer"], Value::Null);
    assert_eq!(detail_json["spawning_parent_pointer"], Value::Null);

    let exact_partition_apps = apps_request(&app, "proj_none", "pk", 10, 0).await;
    assert_eq!(exact_partition_apps.status(), StatusCode::OK);
    let exact_partition_apps_json = response_json(exact_partition_apps).await;
    assert_eq!(exact_partition_apps_json.get("total"), Some(&json!(0)));
    assert_eq!(exact_partition_apps_json["applications"], json!([]));

    let exact_partition_detail = app_detail_request(&app, "proj_none", "app_none", "pk").await;
    assert_eq!(exact_partition_detail.status(), StatusCode::NOT_FOUND);
}

#[tokio::test]
async fn apps_endpoint_rejects_metadata_missing_type_field() {
    let (_tempdir, app) = local_backend_tempdir_app(|root| {
        build_single_app_fixture(root, "proj_invalid", "app_invalid", Some("pk"));
        write_json(
            &root
                .join("proj_invalid")
                .join("app_invalid")
                .join("metadata.json"),
            &json!({
                "partition_key": "pk",
                "parent_pointer": null,
                "spawning_parent_pointer": null
            }),
        );
    });

    let apps = apps_request(&app, "proj_invalid", "pk", 10, 0).await;
    assert_eq!(apps.status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn apps_and_detail_endpoints_reject_app_directory_without_metadata() {
    let (_tempdir, app) = local_backend_tempdir_app(|root| {
        build_single_app_fixture(
            root,
            "proj_missing_metadata",
            "app_missing_metadata",
            Some("pk"),
        );
        fs::remove_file(
            root.join("proj_missing_metadata")
                .join("app_missing_metadata")
                .join("metadata.json"),
        )
        .expect("metadata should be removed");
    });

    let apps = apps_request(&app, "proj_missing_metadata", "pk", 10, 0).await;
    assert_eq!(apps.status(), StatusCode::BAD_REQUEST);

    let detail =
        app_detail_request(&app, "proj_missing_metadata", "app_missing_metadata", "pk").await;
    assert_eq!(detail.status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn apps_and_detail_endpoints_reject_app_directory_without_log() {
    let (_tempdir, app) = local_backend_tempdir_app(|root| {
        build_single_app_fixture(root, "proj_missing_log", "app_missing_log", Some("pk"));
        fs::remove_file(
            root.join("proj_missing_log")
                .join("app_missing_log")
                .join("log.jsonl"),
        )
        .expect("log should be removed");
    });

    let apps = apps_request(&app, "proj_missing_log", "pk", 10, 0).await;
    assert_json_error_response(
        apps,
        StatusCode::NOT_FOUND,
        "missing required app log should fail app summaries",
    )
    .await;

    let detail = app_detail_request(&app, "proj_missing_log", "app_missing_log", "pk").await;
    assert_json_error_response(
        detail,
        StatusCode::NOT_FOUND,
        "missing required app log should fail app detail reads",
    )
    .await;
}

#[tokio::test]
async fn apps_and_detail_endpoints_reject_recognized_malformed_log_entries() {
    let (_tempdir, app) = local_backend_tempdir_app(|root| {
        build_single_app_fixture(root, "proj_malformed_log", "app_malformed_log", Some("pk"));
        write_jsonl(
            &root
                .join("proj_malformed_log")
                .join("app_malformed_log")
                .join("log.jsonl"),
            &[json!({
                "type": "begin_entry",
                "start_time": "2026-04-11T20:51:59.096000Z",
                "action": "counter",
                "inputs": {},
                "sequence_id": "not-a-number"
            })],
        );
    });

    let apps = apps_request(&app, "proj_malformed_log", "pk", 10, 0).await;
    assert_eq!(apps.status(), StatusCode::BAD_REQUEST);

    let detail = app_detail_request(&app, "proj_malformed_log", "app_malformed_log", "pk").await;
    assert_eq!(detail.status(), StatusCode::BAD_REQUEST);
}

#[tokio::test]
async fn unknown_api_routes_return_json_404() {
    let (_tempdir, app) = fixture_tempdir_app();

    let plain_404 = api_get(&app, "/api/v0/does/not/exist").await;
    assert_json_error_response(
        plain_404,
        StatusCode::NOT_FOUND,
        "unknown api routes should return JSON 404 payloads",
    )
    .await;

    for uri in ["/api/v1/projects", "/api"] {
        let response = api_get(&app, uri).await;
        assert_json_error_response_without_spa_rewrite(
            response,
            StatusCode::NOT_FOUND,
            "api misses outside routed endpoints should stay JSON, not SPA HTML",
        )
        .await;
    }
}

#[tokio::test]
async fn tracking_endpoints_return_json_404_when_storage_root_missing() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    let missing_storage_root = tempdir.path().join("missing-storage-root");
    let app = local_backend_app(&missing_storage_root);

    for kind in [TrackingEndpointKind::Apps, TrackingEndpointKind::AppDetail] {
        let response = tracking_endpoint_request(&app, kind, "proj1", "app1", "pk").await;
        assert_json_error_response_without_spa_rewrite(
            response,
            StatusCode::NOT_FOUND,
            "missing storage roots should still return JSON 404 responses",
        )
        .await;
    }
}

#[tokio::test]
async fn apps_and_detail_endpoints_ignore_truncated_trailing_jsonl_line() {
    for kind in [TrackingEndpointKind::Apps, TrackingEndpointKind::AppDetail] {
        assert_truncated_trailing_log_line_ignored(kind).await;
    }
}

#[tokio::test]
async fn local_backend_pins_relative_storage_root_when_cwd_changes_and_root_appears_later() {
    let construction_cwd = tempfile::tempdir().expect("construction cwd should be created");
    let request_cwd = tempfile::tempdir().expect("request cwd should be created");
    let relative_storage_root = PathBuf::from("relative-storage");
    let backend = with_locked_current_dir_async(construction_cwd.path(), || async {
        LocalBackend::new(relative_storage_root.clone())
            .expect("relative storage root should pin while current dir is available")
    })
    .await;
    let storage_root = construction_cwd.path().join(&relative_storage_root);
    build_single_app_fixture(&storage_root, "proj1", "app1", Some("pk"));

    let projects = with_locked_current_dir_async(request_cwd.path(), || async {
        backend
            .list_projects()
            .await
            .expect("relative storage root should remain pinned to the construction cwd")
    })
    .await;

    assert_eq!(projects.len(), 1);
    assert_eq!(projects[0].name, "proj1");
    assert_eq!(projects[0].num_apps, 1);
}

#[tokio::test]
async fn ready_endpoints_return_burr_compatible_payloads() {
    let (_tempdir, app) = fixture_tempdir_app();

    let ready = api_get(&app, "/ready").await;
    assert_eq!(ready.status(), StatusCode::OK);
    assert_eq!(response_json(ready).await, json!({"ready": true}));

    let api_ready = api_get(&app, "/api/v0/ready").await;
    assert_eq!(api_ready.status(), StatusCode::OK);
    assert_eq!(response_json(api_ready).await, json!(true));
}
