#[cfg(feature = "s3")]
use super::S3TrackingClient;
use super::{LocalTrackingClient, TrackingError};
use crate::application::{tracker_spec::TrackerSpec, Tracker};
use indexmap::IndexMap;
use serde_json::Value;
use std::path::PathBuf;
use std::sync::Arc;

pub(crate) struct ResolvedTrackerSpec {
    tracker: Arc<dyn Tracker>,
    register_root_application: bool,
}

impl ResolvedTrackerSpec {
    pub(crate) fn caller_provided(tracker: Arc<dyn Tracker>) -> Self {
        Self {
            tracker,
            register_root_application: false,
        }
    }

    fn managed_tracker(tracker: Arc<dyn Tracker>) -> Self {
        Self {
            tracker,
            register_root_application: true,
        }
    }

    pub(crate) fn into_parts(self) -> (Arc<dyn Tracker>, bool) {
        (self.tracker, self.register_root_application)
    }
}

pub(crate) fn resolve_tracker_spec(
    tracker_spec: Option<TrackerSpec>,
) -> Result<Option<ResolvedTrackerSpec>, TrackingError> {
    match tracker_spec {
        None => Ok(None),
        Some(TrackerSpec::Provided(tracker)) => {
            Ok(Some(ResolvedTrackerSpec::caller_provided(tracker)))
        }
        Some(TrackerSpec::Local { project, params }) => {
            let (storage_dir, serde_kwargs) = parse_local_tracker_params(params)?;
            let tracker: Arc<dyn Tracker> = Arc::new(LocalTrackingClient::with_serde_kwargs(
                project,
                storage_dir,
                serde_kwargs,
            )?);
            Ok(Some(ResolvedTrackerSpec::managed_tracker(tracker)))
        }
        #[cfg(feature = "s3")]
        Some(TrackerSpec::S3 { config }) => {
            let tracker: Arc<dyn Tracker> = Arc::new(S3TrackingClient::new(config)?);
            Ok(Some(ResolvedTrackerSpec::managed_tracker(tracker)))
        }
    }
}

fn parse_local_tracker_params(
    params: IndexMap<String, Value>,
) -> Result<(PathBuf, IndexMap<String, Value>), TrackingError> {
    let mut storage_dir = PathBuf::from(LocalTrackingClient::DEFAULT_STORAGE_DIR);
    let mut serde_kwargs = IndexMap::new();

    for (key, value) in params {
        match key.as_str() {
            "storage_dir" => {
                let Some(path) = value.as_str() else {
                    return Err(TrackingError::InvalidLocalTrackerParamType {
                        param: "storage_dir",
                        expected: "string",
                        actual: value_type_name(&value),
                    });
                };
                storage_dir = PathBuf::from(path);
            }
            "serde_kwargs" => {
                let Some(object) = value.as_object() else {
                    return Err(TrackingError::InvalidLocalTrackerParamType {
                        param: "serde_kwargs",
                        expected: "object",
                        actual: value_type_name(&value),
                    });
                };
                serde_kwargs = object
                    .into_iter()
                    .map(|(key, value)| (key.clone(), value.clone()))
                    .collect();
            }
            other => {
                return Err(TrackingError::UnsupportedLocalTrackerParam {
                    param: other.to_string(),
                });
            }
        }
    }

    Ok((storage_dir, serde_kwargs))
}

fn value_type_name(value: &Value) -> &'static str {
    match value {
        Value::Null => "null",
        Value::Bool(_) => "bool",
        Value::Number(_) => "number",
        Value::String(_) => "string",
        Value::Array(_) => "array",
        Value::Object(_) => "object",
    }
}

#[cfg(test)]
mod tests {
    use super::parse_local_tracker_params;
    use crate::tracking::{LocalTrackingClient, TrackingError};
    use indexmap::IndexMap;
    use serde_json::json;
    use std::path::PathBuf;

    #[test]
    fn parse_local_tracker_params_uses_default_storage_dir_and_empty_serde_kwargs() {
        let (storage_dir, serde_kwargs) =
            parse_local_tracker_params(IndexMap::new()).expect("default params should parse");

        assert_eq!(
            storage_dir,
            PathBuf::from(LocalTrackingClient::DEFAULT_STORAGE_DIR)
        );
        assert!(serde_kwargs.is_empty());
    }

    #[test]
    fn parse_local_tracker_params_accepts_storage_dir_and_serde_kwargs() {
        let (storage_dir, serde_kwargs) = parse_local_tracker_params(IndexMap::from([
            ("storage_dir".to_string(), json!("/tmp/rurr-tracking")),
            (
                "serde_kwargs".to_string(),
                json!({"path": "/tmp/custom-serde", "indent": 2}),
            ),
        ]))
        .expect("storage_dir and serde_kwargs should parse");

        assert_eq!(storage_dir, PathBuf::from("/tmp/rurr-tracking"));
        assert_eq!(
            serde_kwargs,
            IndexMap::from([
                ("path".to_string(), json!("/tmp/custom-serde")),
                ("indent".to_string(), json!(2)),
            ])
        );
    }

    #[test]
    fn parse_local_tracker_params_rejects_non_string_storage_dir() {
        let error = parse_local_tracker_params(IndexMap::from([(
            "storage_dir".to_string(),
            json!(["not", "a", "string"]),
        )]))
        .expect_err("non-string storage_dir should fail");

        assert!(matches!(
            error,
            TrackingError::InvalidLocalTrackerParamType {
                param: "storage_dir",
                expected: "string",
                actual: "array",
            }
        ));
    }

    #[test]
    fn parse_local_tracker_params_rejects_non_object_serde_kwargs() {
        let error = parse_local_tracker_params(IndexMap::from([(
            "serde_kwargs".to_string(),
            json!("not-an-object"),
        )]))
        .expect_err("non-object serde_kwargs should fail");

        assert!(matches!(
            error,
            TrackingError::InvalidLocalTrackerParamType {
                param: "serde_kwargs",
                expected: "object",
                actual: "string",
            }
        ));
    }

    #[test]
    fn parse_local_tracker_params_rejects_unknown_params_deterministically() {
        let error =
            parse_local_tracker_params(IndexMap::from([("unexpected".to_string(), json!(true))]))
                .expect_err("unexpected params should fail");

        assert!(matches!(
            error,
            TrackingError::UnsupportedLocalTrackerParam { param } if param == "unexpected"
        ));
    }
}
