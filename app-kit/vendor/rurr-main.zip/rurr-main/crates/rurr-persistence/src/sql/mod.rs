//! Shared SQL persistence helpers used by the workspace's SQLite and Postgres
//! backends.

mod async_core;
/// Async SQL helpers shared by multiple persistence backends.
pub mod async_ops;
mod core_plan;
mod dialect;
mod init_hint;
mod query_plan;
mod request;
mod row_models;
mod sync_core;

use crate::{
    persisted_state_from_record_parts, PersistedRecordParts, PersistedStateData, PersistenceError,
};

/// Async persistence core used by higher-level backend wrappers.
pub use async_core::AsyncSqlxPersistenceCore;
/// Shared SQL operation plans used by sync and async executors.
pub use core_plan::{SqlInitializationPlan, SqlListAppIdsPlan, SqlSavePlan};
/// Dialect markers and trait bounds for shared SQL rendering.
pub use dialect::{PostgresDialect, SqlDialect, SqliteDialect};
/// Lightweight initialization-state tracker for async backends.
pub use init_hint::InitializationHint;
/// Pre-rendered SQL query text for supported dialects.
pub use query_plan::PersistedStateQueries;
/// Request types used by the shared SQL persistence paths.
pub use request::{LoadSelector, PersistedStateSaveRequest};
/// Sync persistence core used by higher-level backend wrappers.
pub use sync_core::{SyncSqlBackend, SyncSqlPersistenceCore};

/// Tuple representation used when mapping persisted-state rows between adapters.
pub type PersistedRowTuple = (String, String, i64, String, String, Option<String>, String);

const OP_SEQUENCE_ID_OUT_OF_RANGE: &str = "sequence_id_out_of_range";
const OP_STATE_DESERIALIZATION_FAILED: &str = "state_deserialization_failed";
const OP_STATUS_DESERIALIZATION_FAILED: &str = "status_deserialization_failed";

/// Builds the standardized unsupported-operation error used for closed SQL
/// connections.
pub fn closed_connection_error(operation: &'static str) -> PersistenceError {
    PersistenceError::UnsupportedOperation { operation }
}

/// Returns `true` when a persistence error matches the provided closed
/// connection operation.
pub fn is_closed_connection_error(error: &PersistenceError, operation: &'static str) -> bool {
    matches!(
        error,
        PersistenceError::UnsupportedOperation {
            operation: actual_operation,
        } if *actual_operation == operation
    )
}

/// Converts a persisted sequence identifier into the signed representation expected by SQL rows.
pub fn sequence_id_u64_to_i64(sequence_id: u64) -> Result<i64, PersistenceError> {
    i64::try_from(sequence_id).map_err(|_| PersistenceError::UnsupportedOperation {
        operation: OP_SEQUENCE_ID_OUT_OF_RANGE,
    })
}

/// Converts a signed SQL sequence identifier back into the public unsigned representation.
pub fn sequence_id_i64_to_u64(sequence_id: i64) -> Result<u64, PersistenceError> {
    u64::try_from(sequence_id).map_err(|_| PersistenceError::UnsupportedOperation {
        operation: OP_SEQUENCE_ID_OUT_OF_RANGE,
    })
}

/// Converts a raw persisted-state row tuple into the public persistence model.
pub fn tuple_to_persisted_state(
    tuple: PersistedRowTuple,
) -> Result<PersistedStateData, PersistenceError> {
    let (partition_key, app_id, sequence_id, position, state_json, created_at, status) = tuple;
    let sequence_id = sequence_id_i64_to_u64(sequence_id)?;
    persisted_state_from_record_parts(
        PersistedRecordParts {
            partition_key,
            app_id,
            sequence_id,
            position: Some(position),
            state_json: Some(state_json.as_str()),
            created_at,
            status: &status,
        },
        OP_STATE_DESERIALIZATION_FAILED,
        OP_STATUS_DESERIALIZATION_FAILED,
    )
}

#[cfg(test)]
mod tests {
    use super::{closed_connection_error, is_closed_connection_error};
    use crate::PersistenceError;

    #[test]
    fn closed_connection_error_uses_requested_operation() {
        let error = closed_connection_error("connection_closed");
        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == "connection_closed"
        ));
    }

    #[test]
    fn is_closed_connection_error_matches_only_requested_operation() {
        let error = closed_connection_error("connection_closed");
        assert!(is_closed_connection_error(&error, "connection_closed"));
        assert!(!is_closed_connection_error(&error, "other_operation"));
    }
}
