use super::*;
use super::{actions::*, fixtures::*, graphs::*};

#[test]
fn task_level_api_e2e_sync() {
    let child_graph = runnable_graph_from_action(
        "child_task_sync",
        FunctionActionBuilder::new()
            .writes(["output_number"])
            .build_sync(|state, _ctx| {
                let input = state
                    .get("input_number")
                    .and_then(Value::as_i64)
                    .expect("input_number should be present");
                let to_add = state
                    .get("number_to_add")
                    .and_then(Value::as_i64)
                    .expect("number_to_add should be present");
                map_from_pairs([("output_number", json!(input + to_add))])
            })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec!["input_numbers_in_state".to_string()],
        vec!["output_numbers_in_state".to_string()],
        vec![],
        Arc::new(move |state: &State, _ctx: &ActionContext| {
            let numbers = state
                .get("input_numbers_in_state")
                .and_then(Value::as_array)
                .expect("input_numbers_in_state should be an array");
            Ok(numbers
                .iter()
                .enumerate()
                .map(|(index, number)| {
                    let input = number.as_i64().expect("input number should be an integer");
                    SubGraphTask::new(
                        child_graph.clone(),
                        state_from_pairs([
                            ("input_number", json!(input)),
                            ("number_to_add", json!(10)),
                        ]),
                        format!("0-{index}"),
                    )
                })
                .collect())
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            let outputs = child_states
                .iter()
                .map(|state| {
                    state
                        .get("output_number")
                        .and_then(Value::as_i64)
                        .expect("output_number should be present")
                })
                .collect::<Vec<_>>();
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([(
                    "output_numbers_in_state",
                    Value::Array(outputs.into_iter().map(Value::from).collect()),
                )]),
            ))
        }),
        false,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("input_numbers_in_state", json!([100, 200, 300]))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        step.state.get("output_numbers_in_state"),
        Some(&json!([110, 210, 310]))
    );
}

#[tokio::test]
async fn task_level_api_e2e_async() {
    let child_graph = runnable_graph_from_action(
        "child_task_async",
        FunctionActionBuilder::new()
            .writes(["output_number"])
            .build_async(|state, _ctx| async move {
                sleep(Duration::from_millis(25)).await;
                let input = state
                    .get("input_number")
                    .and_then(Value::as_i64)
                    .expect("input_number should be present");
                let to_add = state
                    .get("number_to_add")
                    .and_then(Value::as_i64)
                    .expect("number_to_add should be present");
                map_from_pairs([("output_number", json!(input + to_add))])
            })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec!["input_numbers_in_state".to_string()],
        vec!["output_numbers_in_state".to_string()],
        vec![],
        Arc::new(move |state: &State, _ctx: &ActionContext| {
            let numbers = state
                .get("input_numbers_in_state")
                .and_then(Value::as_array)
                .expect("input_numbers_in_state should be an array");
            Ok(numbers
                .iter()
                .enumerate()
                .map(|(index, number)| {
                    let input = number.as_i64().expect("input number should be an integer");
                    SubGraphTask::new(
                        child_graph.clone(),
                        state_from_pairs([
                            ("input_number", json!(input)),
                            ("number_to_add", json!(10)),
                        ]),
                        format!("0-{index}"),
                    )
                })
                .collect())
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            let outputs = child_states
                .iter()
                .map(|state| {
                    state
                        .get("output_number")
                        .and_then(Value::as_i64)
                        .expect("output_number should be present")
                })
                .collect::<Vec<_>>();
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([(
                    "output_numbers_in_state",
                    Value::Array(outputs.into_iter().map(Value::from).collect()),
                )]),
            ))
        }),
        true,
    );

    let mut app = build_single_action_app(
        state_from_pairs([("input_numbers_in_state", json!([100, 200, 300]))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .astep(None)
        .await
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        step.state.get("output_numbers_in_state"),
        Some(&json!([110, 210, 310]))
    );
}

#[test]
fn map_reduce_action_e2e_uses_runtime_inputs() {
    let child_graph = runnable_graph_from_action(
        "child_map_reduce",
        FunctionActionBuilder::new()
            .writes(["output_number"])
            .build_sync(|state, _ctx| {
                let input = state
                    .get("input_number")
                    .and_then(Value::as_i64)
                    .expect("input_number should be present");
                let to_add = state
                    .get("number_to_add")
                    .and_then(Value::as_i64)
                    .expect("number_to_add should be present");
                map_from_pairs([("output_number", json!(input + to_add))])
            })
            .expect("action should build"),
    );

    let action = map_reduce_action(
        vec![child_graph],
        Arc::new(|state: &State, ctx: &ActionContext| {
            let to_add = ctx
                .inputs
                .get("number_to_add")
                .and_then(Value::as_i64)
                .expect("runtime input number_to_add should be present");
            let numbers = state
                .get("input_numbers_in_state")
                .and_then(Value::as_array)
                .expect("input_numbers_in_state should be an array");
            Ok(numbers
                .iter()
                .map(|number| {
                    state_from_pairs([
                        (
                            "input_number",
                            json!(number.as_i64().expect("input number should be an integer")),
                        ),
                        ("number_to_add", json!(to_add)),
                    ])
                })
                .collect::<Vec<_>>())
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            let outputs = child_states
                .iter()
                .map(|state| {
                    state
                        .get("output_number")
                        .and_then(Value::as_i64)
                        .expect("output_number should be present")
                })
                .collect::<Vec<_>>();
            State::default().update(map_from_pairs([(
                "output_numbers_in_state",
                Value::Array(outputs.into_iter().map(Value::from).collect()),
            )]))
        }),
        vec!["input_numbers_in_state".to_string()],
        vec!["output_numbers_in_state".to_string()],
        vec!["number_to_add".to_string()],
    );

    let mut app = build_single_action_app(
        state_from_pairs([("input_numbers_in_state", json!([100, 200, 300]))]),
        "parallel",
        action,
        "parent-app",
        LifecycleAdapterSet::default(),
        None,
    );

    let step = app
        .step(Some(map_from_pairs([("number_to_add", json!(10))])))
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        step.state.get("output_numbers_in_state"),
        Some(&json!([110, 210, 310]))
    );
}
