use super::tracking_metadata_value;
use serde_json::Value;
use std::error::Error;
use std::fs;
use std::path::{Path, PathBuf};

/// Filename used for serialized graph artifacts.
pub const GRAPH_FILENAME: &str = "graph.json";
/// Filename used for tracking metadata artifacts.
pub const METADATA_FILENAME: &str = "metadata.json";
/// Filename used for tracking log artifacts.
pub const LOG_FILENAME: &str = "log.jsonl";
/// Filename used for child-application artifacts.
pub const CHILDREN_FILENAME: &str = "children.jsonl";
/// Filename used for annotation artifacts.
pub const ANNOTATIONS_FILENAME: &str = "annotations.jsonl";

/// Returns the fixture app directory for one project/app pair.
pub fn project_app_dir(storage_root: &Path, project: &str, app_id: &str) -> PathBuf {
    storage_root.join(project).join(app_id)
}

/// Reads and parses one JSON file.
pub fn try_read_json(path: &Path) -> Result<Value, Box<dyn Error>> {
    Ok(serde_json::from_str(&fs::read_to_string(path)?)?)
}

/// Reads and parses one JSON file, panicking on failure.
pub fn read_json(path: &Path) -> Value {
    try_read_json(path).expect("json file should parse")
}

/// Reads and parses one JSONL file.
pub fn try_read_jsonl(path: &Path) -> Result<Vec<Value>, Box<dyn Error>> {
    Ok(fs::read_to_string(path)?
        .lines()
        .filter(|line| !line.trim().is_empty())
        .map(serde_json::from_str::<Value>)
        .collect::<Result<Vec<_>, _>>()?)
}

/// Reads and parses one JSONL file, panicking on failure.
pub fn read_jsonl(path: &Path) -> Vec<Value> {
    try_read_jsonl(path).expect("jsonl file should parse")
}

/// Reads and parses one JSONL file when it exists, otherwise returns `[]`.
pub fn read_jsonl_if_exists(path: &Path) -> Vec<Value> {
    if !path.exists() {
        return Vec::new();
    }

    read_jsonl(path)
}

/// Writes one JSON file, creating parent directories as needed.
pub fn write_json(path: &Path, value: &Value) {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).expect("parent directory should exist");
    }

    fs::write(
        path,
        serde_json::to_string(value).expect("json should serialize"),
    )
    .expect("json file should be written");
}

/// Writes one JSONL file, creating parent directories as needed.
pub fn write_jsonl(path: &Path, values: &[Value]) {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).expect("parent directory should exist");
    }

    if values.is_empty() {
        fs::write(path, "").expect("empty jsonl file should be written");
        return;
    }

    let payload = values
        .iter()
        .map(|value| serde_json::to_string(value).expect("json line should serialize"))
        .collect::<Vec<_>>()
        .join("\n");
    fs::write(path, format!("{payload}\n")).expect("jsonl file should be written");
}

/// Writes standard tracking metadata for one fixture app directory.
pub fn write_tracking_metadata(app_dir: &Path, partition_key: Option<&str>) {
    write_json(
        &app_dir.join(METADATA_FILENAME),
        &tracking_metadata_value(partition_key),
    );
}

/// Writes raw tracking metadata JSON for one fixture app directory.
pub fn write_raw_tracking_metadata(app_dir: &Path, metadata_json: &str) {
    let path = app_dir.join(METADATA_FILENAME);
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).expect("parent directory should exist");
    }
    fs::write(path, metadata_json).expect("raw metadata should be writable");
}

/// Writes tracking log lines for one fixture app directory.
pub fn write_tracking_log(app_dir: &Path, values: &[Value]) {
    write_jsonl(&app_dir.join(LOG_FILENAME), values);
}

/// Writes tracking child-application rows for one fixture app directory.
pub fn write_tracking_children(app_dir: &Path, values: &[Value]) {
    write_jsonl(&app_dir.join(CHILDREN_FILENAME), values);
}
