//! SQLite-backed persistence adapters for Rurr applications.
//!
//! This crate exposes sync and async persisters that store persisted state in a
//! single SQLite table. The sync adapter opens a direct `rusqlite` connection,
//! while the async adapter uses a lazy `sqlx` pool configured to stay runtime
//! free until the first real query.
//! Both lanes share the same table layout from `rurr-persistence`.
//! Table-name validation and migration SQL are local operations; the example
//! below uses a temporary database file and never depends on external services.
//!
//! ```rust
//! use indexmap::IndexMap;
//! use rurr_persistence::{BaseStateLoader, BaseStateSaver, PersistedStateStatus};
//! use rurr_sqlite::{SqlitePersister, SqlitePersisterConfig, DEFAULT_TABLE_NAME};
//! use serde_json::json;
//!
//! let database_path =
//!     std::env::temp_dir().join(format!("rurr-sqlite-doc-{}.db", std::process::id()));
//! let _ = std::fs::remove_file(&database_path);
//!
//! let persister = SqlitePersister::new(SqlitePersisterConfig::new(
//!     &database_path,
//!     DEFAULT_TABLE_NAME,
//! ))?;
//! persister.initialize()?;
//! persister.save(
//!     None,
//!     "docs-app",
//!     1,
//!     "step-1",
//!     IndexMap::from([("count".to_string(), json!(1))]),
//!     PersistedStateStatus::Completed,
//! )?;
//!
//! let snapshot = persister
//!     .load(None, Some("docs-app"), None)?
//!     .ok_or(rurr_persistence::PersistenceError::NotInitialized)?;
//! assert_eq!(snapshot.sequence_id, 1);
//! assert_eq!(snapshot.position.as_deref(), Some("step-1"));
//!
//! persister.cleanup()?;
//! let _ = std::fs::remove_file(&database_path);
//! # Ok::<(), rurr_persistence::PersistenceError>(())
//! ```
#![deny(missing_docs)]

use rurr_persistence::InitializationHint;
use rusqlite::Connection;
use serde::{Deserialize, Serialize};
use sqlx::SqlitePool;
use std::path::Path;
use std::sync::atomic::AtomicBool;
use std::sync::{Arc, Mutex};

use rurr_persistence::{PersistedStateData, PersistedStateStatus, PersistenceError};

mod async_ops;
/// Error adapters that normalize SQLite-specific driver failures into
/// [`PersistenceError`] values.
pub mod error_map;
/// Helpers for decoding persisted-state rows returned by `rusqlite`.
pub mod row;
/// Schema and connection helpers shared by the sync and async persisters.
pub mod schema;
/// Shared query plans and connection state used by both SQLite persisters.
pub mod shared;
mod sync_ops;

use error_map::{map_rusqlite_error, map_sqlx_error};
use row::row_tuple_from_rusqlite;
use schema::default_async_pool_options;
use shared::SqliteShared;

const MIGRATION_SQL: &str = include_str!("../migrations/sqlite.sql");

const OP_CONNECTION_CLOSED: &str = "connection_closed";
const OP_CONNECTION_LOCK_POISONED: &str = "connection_lock_poisoned";
const OP_INVALID_TABLE_NAME: &str = "invalid_table_name";
const OP_SQLITE_CONNECT_FAILED: &str = "sqlite_connect_failed";
const OP_SQLITE_MIGRATION_FAILED: &str = "sqlite_migration_failed";
const OP_SQLITE_QUERY_FAILED: &str = "sqlite_query_failed";
const OP_STATE_SERIALIZATION_FAILED: &str = "state_serialization_failed";

/// Default persisted-state table name used by the SQLite backend.
pub const DEFAULT_TABLE_NAME: &str = "burr_state";
const ASYNC_POOL_MAX_CONNECTIONS: u32 = 1;
// Keep the lazy pool runtime-free at construction time; sqlx spawns
// maintenance tasks immediately when min_connections > 0.
const ASYNC_POOL_MIN_CONNECTIONS: u32 = 0;
const ASYNC_POOL_IDLE_TIMEOUT: Option<std::time::Duration> = None;
const ASYNC_POOL_MAX_LIFETIME: Option<std::time::Duration> = None;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serializable configuration for constructing SQLite persisters.
pub struct SqlitePersisterConfig {
    /// Database path or SQLite URL accepted by the backend.
    pub database: String,
    /// Table used to store persisted-state rows.
    pub table_name: String,
}

impl SqlitePersisterConfig {
    /// Builds a SQLite persister config from a database path or URL and table
    /// name.
    pub fn new(database: impl AsRef<Path>, table_name: impl Into<String>) -> Self {
        Self {
            database: database.as_ref().to_string_lossy().into_owned(),
            table_name: table_name.into(),
        }
    }
}

/// Synchronous SQLite persister backed by a single `rusqlite::Connection`.
pub struct SqlitePersister {
    config: SqlitePersisterConfig,
    connection: Mutex<Option<Connection>>,
    shared: SqliteShared,
    initialized: InitializationHint,
}

/// Asynchronous SQLite persister backed by a lazy `sqlx::SqlitePool`.
#[derive(Clone)]
pub struct AsyncSqlitePersister {
    config: SqlitePersisterConfig,
    pool: SqlitePool,
    shared: SqliteShared,
    initialized: Arc<InitializationHint>,
    closed: Arc<AtomicBool>,
}

#[cfg(test)]
mod tests {
    use super::*;
    use rusqlite::ffi::{Error as SqliteFfiError, ErrorCode};
    use sqlx::error::{DatabaseError, ErrorKind};
    use std::borrow::Cow;
    use std::error::Error as StdError;
    use std::fmt::{Display, Formatter};

    #[derive(Debug)]
    struct FakeDatabaseError {
        message: &'static str,
    }

    impl Display for FakeDatabaseError {
        fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
            f.write_str(self.message)
        }
    }

    impl StdError for FakeDatabaseError {}

    impl DatabaseError for FakeDatabaseError {
        fn message(&self) -> &str {
            self.message
        }

        fn code(&self) -> Option<Cow<'_, str>> {
            None
        }

        fn as_error(&self) -> &(dyn StdError + Send + Sync + 'static) {
            self
        }

        fn as_error_mut(&mut self) -> &mut (dyn StdError + Send + Sync + 'static) {
            self
        }

        fn into_error(self: Box<Self>) -> Box<dyn StdError + Send + Sync + 'static> {
            self
        }

        fn kind(&self) -> ErrorKind {
            ErrorKind::Other
        }
    }

    #[test]
    fn default_async_pool_options_disable_reaping_and_stay_lazy() {
        let options = default_async_pool_options();

        assert_eq!(options.get_max_connections(), ASYNC_POOL_MAX_CONNECTIONS);
        assert_eq!(options.get_min_connections(), ASYNC_POOL_MIN_CONNECTIONS);
        assert_eq!(options.get_idle_timeout(), ASYNC_POOL_IDLE_TIMEOUT);
        assert_eq!(options.get_max_lifetime(), ASYNC_POOL_MAX_LIFETIME);
    }

    #[test]
    fn map_rusqlite_error_missing_table_returns_not_initialized() {
        let error = rusqlite::Error::SqliteFailure(
            SqliteFfiError::new(ErrorCode::Unknown as i32),
            Some("no such table: burr_state".to_string()),
        );
        let mapped = map_rusqlite_error(error, OP_SQLITE_QUERY_FAILED);
        assert!(matches!(mapped, PersistenceError::NotInitialized));
    }

    #[test]
    fn map_sqlx_error_pool_closed_returns_connection_closed() {
        let mapped = map_sqlx_error(sqlx::Error::PoolClosed);
        assert!(matches!(
            mapped,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_CONNECTION_CLOSED
        ));
    }

    #[test]
    fn map_sqlx_error_missing_table_returns_not_initialized() {
        let mapped = map_sqlx_error(sqlx::Error::Database(Box::new(FakeDatabaseError {
            message: "no such table: burr_state",
        })));
        assert!(matches!(mapped, PersistenceError::NotInitialized));
    }
}
