use super::step_txn::{
    execute_action_async, execute_action_sync, execute_planned_action_async,
    execute_planned_action_sync, PanicPolicy,
};
use crate::action::api::{ActionInputs, StreamItem};
use crate::application::halt_controls::HaltControls;
use crate::application::{Application, ApplicationError, ExecutionOptions, RunOutput, StepOutput};
use crate::common::drop_finalizer::run_drop_finalizer;
use crate::graph::GraphAction;
use crate::lifecycle::ExecuteCallGuard;
use crate::state::State;
use std::sync::Arc;

#[cfg(test)]
mod tests;

fn empty_run_output(app: &Application) -> RunOutput {
    RunOutput {
        action: None,
        result: None,
        state: app.state().clone(),
    }
}

#[derive(Debug, Clone, Default)]
pub(crate) struct ExecutionSessionSettings {
    inputs: Arc<ActionInputs>,
    halt_controls: HaltControls,
}

impl ExecutionSessionSettings {
    fn new(inputs: ActionInputs, halt_controls: HaltControls) -> Self {
        Self {
            inputs: Arc::new(inputs),
            halt_controls,
        }
    }

    pub(crate) fn inputs(&self) -> &ActionInputs {
        self.inputs.as_ref()
    }

    pub(crate) fn shared_inputs(&self) -> Arc<ActionInputs> {
        Arc::clone(&self.inputs)
    }

    pub(crate) fn halts_before(&self, action_name: &str) -> bool {
        self.halt_controls.halts_before(action_name)
    }

    pub(crate) fn halts_after(&self, action_name: &str) -> bool {
        self.halt_controls.halts_after(action_name)
    }

    pub(crate) fn targets_result_action(&self, action_name: &str) -> bool {
        self.halt_controls.targets_result_action(action_name)
    }
}

pub(crate) struct TransitionResolver<'a> {
    settings: &'a ExecutionSessionSettings,
}

struct TransitionFacts {
    prior_step: Option<String>,
    next_action_name: Option<String>,
    reserved_sequence_id: u64,
    has_committed_step: bool,
    last_fast_forwarded_step: Option<FastForwardedTransition>,
}

struct FastForwardedTransition(GraphAction, StreamItem);

enum HaltDecision {
    HaltBefore(GraphAction),
    HaltAfterPrior,
    Continue(ActionExecution),
    Exhausted,
}

pub(crate) enum IterateTransition {
    Continue(ActionExecution),
    Close,
}

pub(crate) enum StreamResultTransition {
    Ready {
        returned_action: GraphAction,
        target_execution: Option<ActionExecution>,
        terminal: Option<(Option<StreamItem>, State)>,
    },
    FastForward(ActionExecution),
}

impl TransitionFacts {
    fn from_resolved(resolved: ResolvedPlanState, has_committed_step: bool) -> Self {
        Self {
            prior_step: resolved.prior_step,
            next_action_name: resolved.next_action_name,
            reserved_sequence_id: resolved.reserved_sequence_id,
            has_committed_step,
            last_fast_forwarded_step: None,
        }
    }

    fn prior_halts_after(&self, settings: &ExecutionSessionSettings) -> bool {
        self.prior_step
            .as_deref()
            .is_some_and(|prior_step| settings.halts_after(prior_step))
    }

    fn next_halts_before(&self, settings: &ExecutionSessionSettings) -> bool {
        self.next_action_name
            .as_deref()
            .is_some_and(|next_action| settings.halts_before(next_action))
    }

    fn next_action(&self, app: &Application) -> Result<Option<GraphAction>, ApplicationError> {
        Ok(self
            .next_action_name
            .as_deref()
            .map(|action| app.graph_definition().get_action(action).cloned())
            .transpose()?)
    }

    fn next_execution(
        &self,
        app: &Application,
        halted: bool,
    ) -> Result<Option<ActionExecution>, ApplicationError> {
        self.next_action_name
            .as_deref()
            .map(|action| {
                ActionExecution::resolve(
                    app,
                    action,
                    self.prior_step.clone(),
                    self.reserved_sequence_id,
                    halted,
                )
            })
            .transpose()
    }

    fn continue_or_exhaust(&self, app: &Application) -> Result<HaltDecision, ApplicationError> {
        Ok(match self.next_execution(app, false)? {
            Some(execution) => HaltDecision::Continue(execution),
            None => HaltDecision::Exhausted,
        })
    }
}

impl HaltDecision {
    fn into_iterate_transition(self) -> IterateTransition {
        match self {
            Self::Continue(execution) => IterateTransition::Continue(execution),
            Self::HaltBefore(_) | Self::HaltAfterPrior | Self::Exhausted => {
                IterateTransition::Close
            }
        }
    }
}

impl<'a> TransitionResolver<'a> {
    pub(crate) fn new(settings: &'a ExecutionSessionSettings) -> Self {
        Self { settings }
    }

    fn decide_run_after_step(
        &self,
        app: &Application,
        facts: &TransitionFacts,
    ) -> Result<HaltDecision, ApplicationError> {
        if facts.next_halts_before(self.settings) {
            if let Some(action) = facts.next_action(app)? {
                return Ok(HaltDecision::HaltBefore(action));
            }
        }

        if facts.prior_halts_after(self.settings) {
            return Ok(HaltDecision::HaltAfterPrior);
        }

        facts.continue_or_exhaust(app)
    }

    fn decide_iterate_next(
        &self,
        app: &Application,
        facts: &TransitionFacts,
    ) -> Result<HaltDecision, ApplicationError> {
        if facts.has_committed_step && facts.prior_halts_after(self.settings) {
            return Ok(HaltDecision::HaltAfterPrior);
        }

        if facts.next_action_name.is_none() {
            return Ok(HaltDecision::Exhausted);
        }

        if facts.has_committed_step && facts.next_halts_before(self.settings) {
            return Ok(HaltDecision::HaltBefore(facts.next_action(app)?.ok_or(
                {
                    ApplicationError::InternalInvariant {
                        message: "transition resolver lost next action while halting iterate",
                    }
                },
            )?));
        }

        facts.continue_or_exhaust(app)
    }

    fn resolve_run_after_step(
        &self,
        app: &Application,
        resolved: ResolvedPlanState,
    ) -> Result<HaltDecision, ApplicationError> {
        let facts = TransitionFacts::from_resolved(resolved, true);
        self.decide_run_after_step(app, &facts)
    }

    pub(crate) fn resolve_iterate_next(
        &self,
        app: &Application,
        resolved: ResolvedPlanState,
        has_committed_step: bool,
    ) -> Result<IterateTransition, ApplicationError> {
        let facts = TransitionFacts::from_resolved(resolved, has_committed_step);
        self.decide_iterate_next(app, &facts)
            .map(HaltDecision::into_iterate_transition)
    }

    pub(crate) fn resolve_stream_result_target(
        &self,
        app: &Application,
        resolved: ResolvedPlanState,
        last_fast_forwarded_step: Option<(&GraphAction, &StreamItem)>,
    ) -> Result<StreamResultTransition, ApplicationError> {
        let mut facts = TransitionFacts::from_resolved(resolved, false);
        facts.last_fast_forwarded_step = last_fast_forwarded_step
            .map(|(action, result)| FastForwardedTransition(action.clone(), result.clone()));

        if let Some(next_action_name) = facts.next_action_name.as_deref() {
            if facts.prior_step.is_some()
                && self.settings.halts_before(next_action_name)
                && !self.settings.halts_after(next_action_name)
            {
                return Ok(StreamResultTransition::Ready {
                    returned_action: facts.next_action(app)?.ok_or({
                        ApplicationError::InternalInvariant {
                            message:
                                "transition resolver lost next action while streaming halt_before",
                        }
                    })?,
                    target_execution: None,
                    terminal: Some((None, app.state().clone())),
                });
            }

            let execution = facts.next_execution(app, false)?.ok_or({
                ApplicationError::InternalInvariant {
                    message: "transition resolver lost stream target execution",
                }
            })?;
            if self.settings.targets_result_action(next_action_name) {
                return Ok(StreamResultTransition::Ready {
                    returned_action: execution.action().clone(),
                    target_execution: Some(execution),
                    terminal: None,
                });
            }
            return Ok(StreamResultTransition::FastForward(execution));
        }

        if let Some(FastForwardedTransition(action, result)) = facts.last_fast_forwarded_step {
            if self.settings.halts_before(action.name())
                && !self.settings.halts_after(action.name())
            {
                return Ok(StreamResultTransition::Ready {
                    returned_action: action,
                    target_execution: None,
                    terminal: Some((Some(result), app.state().clone())),
                });
            }
        }

        Err(ApplicationError::NoNextActionForStreaming {
            prior_step: facts.prior_step,
        })
    }
}

struct ExecutionSessionCore {
    settings: ExecutionSessionSettings,
    next_execution: Option<ActionExecution>,
    terminal_output: Option<RunOutput>,
}

impl ExecutionSessionCore {
    fn new(settings: ExecutionSessionSettings) -> Self {
        Self {
            settings,
            next_execution: None,
            terminal_output: None,
        }
    }

    fn seed_next_execution(
        &mut self,
        app: &Application,
        plan: ResolvedPlanState,
    ) -> Result<(), ApplicationError> {
        self.next_execution = plan.into_execution(app, false)?;
        Ok(())
    }

    fn take_next_execution(&mut self, app: &Application) -> Option<ActionExecution> {
        match self.next_execution.take() {
            Some(execution) => Some(execution),
            None => {
                if self.terminal_output.is_none() {
                    self.terminal_output = Some(empty_run_output(app));
                }
                None
            }
        }
    }

    fn take_terminal_output_or_default(&mut self, app: &Application) -> RunOutput {
        self.terminal_output
            .take()
            .unwrap_or_else(|| empty_run_output(app))
    }

    fn process_step_output(
        &mut self,
        app: &Application,
        mut step_output: StepOutput,
    ) -> Result<StepOutput, ApplicationError> {
        let resolved_after_step = ExecutionPlan::new(app).resolve()?;
        match TransitionResolver::new(&self.settings)
            .resolve_run_after_step(app, resolved_after_step)?
        {
            HaltDecision::HaltBefore(action) => {
                self.terminal_output = Some(RunOutput {
                    action: Some(action),
                    result: None,
                    state: app.state().clone(),
                });
                self.next_execution = None;
            }
            HaltDecision::HaltAfterPrior => {
                step_output.halted = true;
                self.terminal_output = Some(RunOutput {
                    action: Some(step_output.action.clone()),
                    result: Some(step_output.result.clone()),
                    state: app.state().clone(),
                });
                self.next_execution = None;
            }
            HaltDecision::Continue(execution) => {
                self.next_execution = Some(execution);
            }
            HaltDecision::Exhausted => {
                self.terminal_output = Some(RunOutput {
                    action: Some(step_output.action.clone()),
                    result: Some(step_output.result.clone()),
                    state: app.state().clone(),
                });
                self.next_execution = None;
            }
        }

        Ok(step_output)
    }

    fn advance(&mut self, app: &mut Application) -> Result<Option<StepOutput>, ApplicationError> {
        let Some(execution) = self.take_next_execution(app) else {
            return Ok(None);
        };

        let step_output = execute_planned_action_sync(app, execution, self.settings.inputs())?;
        self.process_step_output(app, step_output).map(Some)
    }

    async fn advance_async(
        &mut self,
        app: &mut Application,
    ) -> Result<Option<StepOutput>, ApplicationError> {
        let Some(execution) = self.take_next_execution(app) else {
            return Ok(None);
        };

        let step_output =
            execute_planned_action_async(app, execution, self.settings.inputs()).await?;
        self.process_step_output(app, step_output).map(Some)
    }
}

/// An iterator-style execution session that advances an application step by step.
///
/// A session borrows the application mutably for its lifetime, so the type
/// system prevents competing `step`, `run`, or streaming calls while the session
/// is active. Dropping an active sync session runs the sync execute-call
/// post-hook guard; async sessions finish hooks only through explicit async
/// completion APIs. When created through
/// [`Application::iterate_with_options`](crate::Application::iterate_with_options),
/// runtime inputs and resolved halt controls are owned by the session state and
/// reused for each advancement.
pub struct ExecutionSession<'a> {
    app: &'a mut Application,
    state: ExecutionSessionState,
}

enum ExecutionSessionState {
    NotStarted(Box<ExecutionStart>),
    Active(Box<ActiveExecutionSession>),
    Done,
}

struct ActiveExecutionSession {
    loop_state: ExecutionSessionCore,
    execute_guard: ExecuteCallGuard,
}

impl<'a> ExecutionSession<'a> {
    fn new(app: &'a mut Application, start: ExecutionStart) -> Self {
        Self {
            app,
            state: ExecutionSessionState::NotStarted(Box::new(start)),
        }
    }

    fn start_if_needed(&mut self) -> Result<(), ApplicationError> {
        let start = match std::mem::replace(&mut self.state, ExecutionSessionState::Done) {
            ExecutionSessionState::NotStarted(start) => start,
            state => {
                self.state = state;
                return Ok(());
            }
        };

        let started = (*start).start_sync(self.app);
        match resolve_started_loop(self.app, started) {
            Ok((loop_state, execute_guard)) => {
                self.state = ExecutionSessionState::Active(Box::new(ActiveExecutionSession {
                    loop_state,
                    execute_guard,
                }));
                Ok(())
            }
            Err(error) => {
                self.state = ExecutionSessionState::Done;
                Err(error)
            }
        }
    }

    fn finish_active_sync(
        &mut self,
        result: Result<(), ApplicationError>,
    ) -> Result<(), ApplicationError> {
        match std::mem::replace(&mut self.state, ExecutionSessionState::Done) {
            ExecutionSessionState::Active(active) => {
                finish_execute_guard_sync(active.execute_guard, result)
            }
            ExecutionSessionState::Done => Err(ApplicationError::InternalInvariant {
                message: "iterate session completed without an active execute guard",
            }),
            ExecutionSessionState::NotStarted(_) => Err(ApplicationError::InternalInvariant {
                message: "iterate session finished before startup",
            }),
        }
    }
}

impl Drop for ExecutionSession<'_> {
    fn drop(&mut self) {
        if let ExecutionSessionState::Active(active) =
            std::mem::replace(&mut self.state, ExecutionSessionState::Done)
        {
            run_drop_finalizer(|| {
                let _ = finish_execute_guard_sync(active.execute_guard, Ok(()));
            });
        }
    }
}

impl Iterator for ExecutionSession<'_> {
    type Item = Result<StepOutput, ApplicationError>;

    fn next(&mut self) -> Option<Self::Item> {
        if matches!(self.state, ExecutionSessionState::Done) {
            return None;
        }

        if let Err(error) = self.start_if_needed() {
            return Some(Err(error));
        }

        let advance_result = {
            match &mut self.state {
                ExecutionSessionState::Active(active) => active.loop_state.advance(self.app),
                ExecutionSessionState::Done => return None,
                ExecutionSessionState::NotStarted(_) => Err(ApplicationError::InternalInvariant {
                    message: "iterate session remained unstarted after startup",
                }),
            }
        };

        let drive_result = match advance_result {
            Ok(Some(output)) => Ok(Some(output)),
            Ok(None) => self.finish_active_sync(Ok(())).map(|()| None),
            Err(error) => self.finish_active_sync(Err(error)).map(|()| None),
        };

        match drive_result {
            Ok(Some(output)) => Some(Ok(output)),
            Ok(None) => None,
            Err(error) => Some(Err(error)),
        }
    }
}

pub(crate) fn iterate<'a>(
    app: &'a mut Application,
    options: ExecutionOptions,
) -> ExecutionSession<'a> {
    ExecutionSession::new(
        app,
        ExecutionStart::new(app, ExecutionLane::Sync(SyncLane::Run), options),
    )
}

pub(crate) fn run(
    app: &mut Application,
    options: ExecutionOptions,
) -> Result<RunOutput, ApplicationError> {
    let started =
        ExecutionStart::new(app, ExecutionLane::Sync(SyncLane::Run), options).start_sync(app);
    let (mut loop_state, execute_guard) = resolve_started_loop(app, started)?;
    let method_result = (|| -> Result<RunOutput, ApplicationError> {
        while loop_state.advance(app)?.is_some() {}
        Ok(loop_state.take_terminal_output_or_default(app))
    })();
    finish_execute_guard_sync(execute_guard, method_result)
}

pub(crate) async fn arun(
    app: &mut Application,
    options: ExecutionOptions,
) -> Result<RunOutput, ApplicationError> {
    let started = ExecutionStart::new(app, ExecutionLane::Async, options)
        .start_async(app)
        .await;
    let (mut loop_state, execute_guard) = resolve_started_loop_async(app, started).await?;

    let method_result = async {
        while loop_state.advance_async(app).await?.is_some() {}
        Ok(loop_state.take_terminal_output_or_default(app))
    }
    .await;

    finish_execute_guard_async(execute_guard, method_result).await
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum SyncLane {
    Step,
    Run,
    Stream,
}

impl SyncLane {
    fn async_error(self) -> ApplicationError {
        match self {
            Self::Step => ApplicationError::AsyncApplicationUsedSyncStep,
            Self::Run => ApplicationError::AsyncApplicationUsedSyncRun,
            Self::Stream => ApplicationError::AsyncApplicationUsedSyncStream,
        }
    }
}

pub(crate) fn sync_entry_error(app: &Application, lane: SyncLane) -> Option<ApplicationError> {
    app.is_async_app().then(|| lane.async_error())
}

pub(crate) fn ensure_sync_lane(app: &Application, lane: SyncLane) -> Result<(), ApplicationError> {
    match sync_entry_error(app, lane) {
        Some(error) => Err(error),
        None => Ok(()),
    }
}

#[derive(Debug)]
pub(crate) struct ExecutionStart {
    inputs: ActionInputs,
    halt_before: Vec<String>,
    halt_after: Vec<String>,
    startup_error: Option<ApplicationError>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum ExecutionLane {
    Sync(SyncLane),
    Async,
}

pub(crate) enum StartedExecution {
    Ready {
        settings: ExecutionSessionSettings,
        execute_guard: Box<ExecuteCallGuard>,
        pending_plan: Box<ExecutionPlan>,
    },
    StartupError {
        error: ApplicationError,
    },
}

enum StartedLoopState {
    Ready {
        loop_state: Box<ExecutionSessionCore>,
        execute_guard: Box<ExecuteCallGuard>,
    },
    StartupError {
        error: ApplicationError,
    },
    GuardedResolutionError {
        execute_guard: Box<ExecuteCallGuard>,
        error: ApplicationError,
    },
}

impl ExecutionStart {
    pub(crate) fn new(app: &Application, lane: ExecutionLane, options: ExecutionOptions) -> Self {
        let (inputs, halt_before, halt_after) = options.into_parts();
        let startup_error = match lane {
            ExecutionLane::Sync(lane) => sync_entry_error(app, lane),
            ExecutionLane::Async => None,
        }
        .or_else(|| validate_user_runtime_inputs(&inputs).err());
        Self {
            inputs,
            halt_before,
            halt_after,
            startup_error,
        }
    }

    fn into_session(
        self,
        app: &Application,
    ) -> Result<(ExecutionSessionSettings, ExecutionPlan), ApplicationError> {
        let Self {
            inputs,
            halt_before,
            halt_after,
            startup_error,
        } = self;
        if let Some(startup_error) = startup_error {
            return Err(startup_error);
        }

        let halt_controls = HaltControls::resolve(app.graph_definition(), halt_before, halt_after)?;
        Ok((
            ExecutionSessionSettings::new(inputs, halt_controls),
            ExecutionPlan::new(app),
        ))
    }

    pub(crate) fn start_sync(self, app: &Application) -> StartedExecution {
        let (settings, pending_plan) = match self.into_session(app) {
            Ok(started_plan) => started_plan,
            Err(error) => return StartedExecution::StartupError { error },
        };

        match pending_plan.start_sync(app) {
            Ok(execute_guard) => StartedExecution::Ready {
                settings,
                execute_guard: Box::new(execute_guard),
                pending_plan: Box::new(pending_plan),
            },
            Err(error) => StartedExecution::StartupError { error },
        }
    }

    pub(crate) async fn start_async(self, app: &Application) -> StartedExecution {
        let (settings, pending_plan) = match self.into_session(app) {
            Ok(started_plan) => started_plan,
            Err(error) => return StartedExecution::StartupError { error },
        };

        match pending_plan.start_async(app).await {
            Ok(execute_guard) => StartedExecution::Ready {
                settings,
                execute_guard: Box::new(execute_guard),
                pending_plan: Box::new(pending_plan),
            },
            Err(error) => StartedExecution::StartupError { error },
        }
    }
}

pub(crate) fn validate_user_runtime_inputs(inputs: &ActionInputs) -> Result<(), ApplicationError> {
    let invalid_keys: Vec<String> = inputs
        .keys()
        .filter(|key| crate::action::api::is_reserved_runtime_input(key))
        .cloned()
        .collect();
    if invalid_keys.is_empty() {
        return Ok(());
    }
    Err(ApplicationError::ReservedRuntimeInputKeys { keys: invalid_keys })
}

pub(crate) fn prepare_run_inputs(
    inputs: Option<ActionInputs>,
) -> Result<ActionInputs, ApplicationError> {
    let inputs = inputs.unwrap_or_default();
    validate_user_runtime_inputs(&inputs)?;
    Ok(inputs)
}

#[derive(Debug)]
pub(crate) struct ExecutionPlan {
    execute_context: crate::lifecycle::ExecuteCallContext,
    resolution: Result<ResolvedPlanState, ApplicationError>,
}

#[derive(Debug)]
pub(crate) struct ResolvedPlanState {
    pub(crate) prior_step: Option<String>,
    pub(crate) next_action_name: Option<String>,
    pub(crate) reserved_sequence_id: u64,
}

#[derive(Debug, Clone)]
pub(crate) struct ActionExecution {
    action: GraphAction,
    prior_step: Option<String>,
    reserved_sequence_id: u64,
    halted: bool,
}

impl ExecutionPlan {
    pub(crate) fn new(app: &Application) -> Self {
        let metadata = app.state_meta();
        let resolution = (|| {
            Ok(ResolvedPlanState {
                prior_step: metadata
                    .strict_prior_step()
                    .map(|prior| prior.map(str::to_string))?,
                next_action_name: metadata.strict_next_action_name(app.graph_definition())?,
                reserved_sequence_id: metadata.strict_reserved_sequence_id()?,
            })
        })();
        let preview_action = resolution
            .as_ref()
            .ok()
            .and_then(|resolved| resolved.next_action_name.as_deref())
            .unwrap_or(app.entrypoint())
            .to_string();

        Self {
            execute_context: crate::lifecycle::ExecuteCallContext::new(
                app.uid().to_string(),
                app.partition_key().unwrap_or_default().to_string(),
                preview_action,
                metadata.preview_execute_sequence_id(),
            ),
            resolution,
        }
    }

    pub(crate) fn start_sync(
        &self,
        app: &Application,
    ) -> Result<ExecuteCallGuard, ApplicationError> {
        Ok(ExecuteCallGuard::start_sync(
            app.hooks(),
            self.execute_context.clone(),
        )?)
    }

    pub(crate) async fn start_async(
        &self,
        app: &Application,
    ) -> Result<ExecuteCallGuard, ApplicationError> {
        Ok(ExecuteCallGuard::start_async(app.hooks(), self.execute_context.clone()).await?)
    }

    pub(crate) fn resolve(self) -> Result<ResolvedPlanState, ApplicationError> {
        self.resolution
    }
}

impl ResolvedPlanState {
    pub(crate) fn into_execution(
        self,
        app: &Application,
        halted: bool,
    ) -> Result<Option<ActionExecution>, ApplicationError> {
        match self.next_action_name {
            Some(action_name) => Ok(Some(ActionExecution::resolve(
                app,
                action_name,
                self.prior_step,
                self.reserved_sequence_id,
                halted,
            )?)),
            None => Ok(None),
        }
    }
}

impl ActionExecution {
    pub(crate) fn resolve(
        app: &Application,
        action_name: impl AsRef<str>,
        prior_step: Option<String>,
        reserved_sequence_id: u64,
        halted: bool,
    ) -> Result<Self, ApplicationError> {
        Ok(Self {
            action: app
                .graph_definition()
                .get_action(action_name.as_ref())?
                .clone(),
            prior_step,
            reserved_sequence_id,
            halted,
        })
    }

    pub(crate) fn action(&self) -> &GraphAction {
        &self.action
    }

    pub(crate) fn sequence_id(&self) -> u64 {
        self.reserved_sequence_id
    }

    pub(crate) fn into_parts(self) -> (GraphAction, Option<String>, u64, bool) {
        (
            self.action,
            self.prior_step,
            self.reserved_sequence_id,
            self.halted,
        )
    }
}

pub(crate) fn finish_execute_guard_sync<T>(
    execute_guard: ExecuteCallGuard,
    result: Result<T, ApplicationError>,
) -> Result<T, ApplicationError> {
    match execute_guard.finish_sync() {
        Ok(()) => result,
        Err(finish_error) => Err(finish_error.into()),
    }
}

pub(crate) async fn finish_execute_guard_async<T>(
    execute_guard: ExecuteCallGuard,
    result: Result<T, ApplicationError>,
) -> Result<T, ApplicationError> {
    match execute_guard.finish_async().await {
        Ok(()) => result,
        Err(finish_error) => Err(finish_error.into()),
    }
}

pub(crate) fn step(
    app: &mut Application,
    inputs: Option<ActionInputs>,
) -> Result<Option<StepOutput>, ApplicationError> {
    ensure_sync_lane(app, SyncLane::Step)?;
    let action_inputs = prepare_run_inputs(inputs)?;
    let plan = ExecutionPlan::new(app);
    let execute_guard = plan.start_sync(app)?;
    let method_result = match resolve_guarded_step_execution(plan, app) {
        Ok(Some(execution)) => {
            execute_action_sync(app, execution, &action_inputs, PanicPolicy::Capture).map(Some)
        }
        Ok(None) => Ok(None),
        Err(error) => Err(error),
    };

    finish_execute_guard_sync(execute_guard, method_result)
}

pub(crate) async fn astep(
    app: &mut Application,
    inputs: Option<ActionInputs>,
) -> Result<Option<StepOutput>, ApplicationError> {
    let action_inputs = prepare_run_inputs(inputs)?;
    let plan = ExecutionPlan::new(app);
    let execute_guard = plan.start_async(app).await?;
    let method_result = match resolve_guarded_step_execution(plan, app) {
        Ok(Some(execution)) => {
            execute_action_async(app, execution, &action_inputs, PanicPolicy::Capture)
                .await
                .map(Some)
        }
        Ok(None) => Ok(None),
        Err(error) => Err(error),
    };

    finish_execute_guard_async(execute_guard, method_result).await
}

fn resolve_guarded_step_execution(
    plan: ExecutionPlan,
    app: &Application,
) -> Result<Option<ActionExecution>, ApplicationError> {
    plan.resolve()
        .and_then(|resolved_plan| resolve_step_execution(resolved_plan, app))
}

fn resolve_step_execution(
    plan: ResolvedPlanState,
    app: &Application,
) -> Result<Option<ActionExecution>, ApplicationError> {
    plan.into_execution(app, false)
}

fn resolve_started_loop(
    app: &Application,
    started: StartedExecution,
) -> Result<(ExecutionSessionCore, ExecuteCallGuard), ApplicationError> {
    match resolve_started_loop_state(app, started)? {
        StartedLoopState::Ready {
            loop_state,
            execute_guard,
        } => Ok((*loop_state, *execute_guard)),
        StartedLoopState::StartupError { error } => Err(error),
        StartedLoopState::GuardedResolutionError {
            execute_guard,
            error,
        } => Err(finish_execute_guard_sync_error(*execute_guard, error)),
    }
}

async fn resolve_started_loop_async(
    app: &Application,
    started: StartedExecution,
) -> Result<(ExecutionSessionCore, ExecuteCallGuard), ApplicationError> {
    match resolve_started_loop_state(app, started)? {
        StartedLoopState::Ready {
            loop_state,
            execute_guard,
        } => Ok((*loop_state, *execute_guard)),
        StartedLoopState::StartupError { error } => Err(error),
        StartedLoopState::GuardedResolutionError {
            execute_guard,
            error,
        } => Err(finish_execute_guard_async_error(*execute_guard, error).await),
    }
}

fn resolve_started_loop_state(
    app: &Application,
    started: StartedExecution,
) -> Result<StartedLoopState, ApplicationError> {
    match started {
        StartedExecution::StartupError { error } => Ok(StartedLoopState::StartupError { error }),
        StartedExecution::Ready {
            settings,
            execute_guard,
            pending_plan,
        } => {
            let execute_guard = *execute_guard;
            let pending_plan = *pending_plan;
            let mut loop_state = ExecutionSessionCore::new(settings);
            let plan = match pending_plan.resolve() {
                Ok(plan) => plan,
                Err(error) => {
                    return Ok(StartedLoopState::GuardedResolutionError {
                        execute_guard: Box::new(execute_guard),
                        error,
                    });
                }
            };

            if let Err(error) = loop_state.seed_next_execution(app, plan) {
                return Ok(StartedLoopState::GuardedResolutionError {
                    execute_guard: Box::new(execute_guard),
                    error,
                });
            }

            Ok(StartedLoopState::Ready {
                loop_state: Box::new(loop_state),
                execute_guard: Box::new(execute_guard),
            })
        }
    }
}

fn unexpected_execute_guard_success() -> ApplicationError {
    ApplicationError::InternalInvariant {
        message: "execute guard finish unexpectedly converted an error result into success",
    }
}

fn finish_execute_guard_error(result: Result<(), ApplicationError>) -> ApplicationError {
    match result {
        Ok(()) => unexpected_execute_guard_success(),
        Err(error) => error,
    }
}

fn finish_execute_guard_sync_error(
    execute_guard: ExecuteCallGuard,
    error: ApplicationError,
) -> ApplicationError {
    finish_execute_guard_error(finish_execute_guard_sync(
        execute_guard,
        Err::<(), _>(error),
    ))
}

async fn finish_execute_guard_async_error(
    execute_guard: ExecuteCallGuard,
    error: ApplicationError,
) -> ApplicationError {
    finish_execute_guard_error(finish_execute_guard_async(execute_guard, Err::<(), _>(error)).await)
}
