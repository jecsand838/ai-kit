use rurr_testkit::command_fixture::{assert_failure, assert_success, rurr_command_in};

#[test]
fn ui_build_exports_embedded_bundle_from_arbitrary_workdir() {
    let work_dir = tempfile::tempdir().expect("work tempdir should be created");
    let out_dir = work_dir.path().join("exported-ui");

    let output = rurr_command_in(work_dir.path())
        .arg("ui")
        .arg("build")
        .arg("--out-dir")
        .arg(&out_dir)
        .output()
        .expect("ui build should run");
    assert_success(&output, "ui build should succeed");

    let index_path = out_dir.join("index.html");
    let app_js_path = out_dir.join("assets").join("app.js");
    assert!(index_path.exists(), "index.html should be exported");
    assert!(app_js_path.exists(), "assets/app.js should be exported");

    let index = std::fs::read_to_string(&index_path).expect("index.html should be readable");
    assert!(
        !index.to_ascii_lowercase().contains("placeholder"),
        "exported index must not contain placeholder copy"
    );
    assert!(
        index.contains("data-view=\"projects\"") && index.contains("data-view=\"detail\""),
        "exported index should contain the tracking UI shell"
    );

    let app_js = std::fs::read_to_string(&app_js_path).expect("app.js should be readable");
    assert!(
        !app_js.contains("Rurr UI bundle booted"),
        "exported asset must not contain the old placeholder boot marker"
    );
    assert!(
        app_js.contains("/api/v0/projects") && app_js.contains("loadAppDetail"),
        "exported asset should drive the real tracking UI"
    );
}

#[cfg(unix)]
#[test]
fn ui_build_rejects_symlinked_output_root() {
    use std::os::unix::fs::symlink;

    let work_dir = tempfile::tempdir().expect("work tempdir should be created");
    let outside_root = tempfile::tempdir().expect("outside tempdir should be created");
    let requested_out = work_dir.path().join("exported-ui");
    symlink(outside_root.path(), &requested_out).expect("output-root symlink should be created");

    let output = rurr_command_in(work_dir.path())
        .arg("ui")
        .arg("build")
        .arg("--out-dir")
        .arg(&requested_out)
        .output()
        .expect("ui build should run");
    assert_failure(
        &output,
        "ui build must fail closed on symlinked output roots",
    );
    assert!(
        !outside_root.path().join("index.html").exists(),
        "ui build must not write through a symlinked output root"
    );
    assert!(
        !outside_root.path().join("assets").join("app.js").exists(),
        "ui build must not write assets through a symlinked output root"
    );
}

#[cfg(windows)]
#[test]
fn ui_build_rejects_symlinked_output_root() {
    use std::os::windows::fs::symlink_dir;

    let work_dir = tempfile::tempdir().expect("work tempdir should be created");
    let outside_root = tempfile::tempdir().expect("outside tempdir should be created");
    let requested_out = work_dir.path().join("exported-ui");
    symlink_dir(outside_root.path(), &requested_out)
        .expect("output-root symlink should be created");

    let output = rurr_command_in(work_dir.path())
        .arg("ui")
        .arg("build")
        .arg("--out-dir")
        .arg(&requested_out)
        .output()
        .expect("ui build should run");
    assert_failure(
        &output,
        "ui build must fail closed on symlinked output roots",
    );
    assert!(
        !outside_root.path().join("index.html").exists(),
        "ui build must not write through a symlinked output root"
    );
    assert!(
        !outside_root.path().join("assets").join("app.js").exists(),
        "ui build must not write assets through a symlinked output root"
    );
}

#[cfg(unix)]
#[test]
fn ui_build_rejects_aliased_output_ancestor() {
    use std::os::unix::fs::symlink;

    let work_dir = tempfile::tempdir().expect("work tempdir should be created");
    let outside_root = tempfile::tempdir().expect("outside tempdir should be created");
    let alias_path = work_dir.path().join("alias");
    let requested_out = alias_path.join("exported-ui");
    symlink(outside_root.path(), &alias_path).expect("output ancestor alias should be created");

    let output = rurr_command_in(work_dir.path())
        .arg("ui")
        .arg("build")
        .arg("--out-dir")
        .arg(&requested_out)
        .output()
        .expect("ui build should run");
    assert_failure(
        &output,
        "ui build must fail closed on aliased output ancestors",
    );
    assert!(
        !outside_root
            .path()
            .join("exported-ui")
            .join("index.html")
            .exists(),
        "ui build must not write through an aliased output ancestor"
    );
    assert!(
        !outside_root
            .path()
            .join("exported-ui")
            .join("assets")
            .join("app.js")
            .exists(),
        "ui build must not write assets through an aliased output ancestor"
    );
}

#[cfg(windows)]
#[test]
fn ui_build_rejects_aliased_output_ancestor() {
    use std::os::windows::fs::symlink_dir;

    let work_dir = tempfile::tempdir().expect("work tempdir should be created");
    let outside_root = tempfile::tempdir().expect("outside tempdir should be created");
    let alias_path = work_dir.path().join("alias");
    let requested_out = alias_path.join("exported-ui");
    symlink_dir(outside_root.path(), &alias_path).expect("output ancestor alias should be created");

    let output = rurr_command_in(work_dir.path())
        .arg("ui")
        .arg("build")
        .arg("--out-dir")
        .arg(&requested_out)
        .output()
        .expect("ui build should run");
    assert_failure(
        &output,
        "ui build must fail closed on aliased output ancestors",
    );
    assert!(
        !outside_root
            .path()
            .join("exported-ui")
            .join("index.html")
            .exists(),
        "ui build must not write through an aliased output ancestor"
    );
    assert!(
        !outside_root
            .path()
            .join("exported-ui")
            .join("assets")
            .join("app.js")
            .exists(),
        "ui build must not write assets through an aliased output ancestor"
    );
}
