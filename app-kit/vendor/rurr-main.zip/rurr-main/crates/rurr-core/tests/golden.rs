mod golden {
    mod graphviz_dot_golden;
}
