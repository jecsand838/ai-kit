use super::{stream_invariant, AStreamNextResult, AStreamResultCore};
use futures::future::{AbortHandle, Abortable, Aborted};
use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll};

pub(super) struct AStreamPendingNext<'a> {
    pub(super) abort_handle: Option<AbortHandle>,
    pub(super) future:
        Pin<Box<dyn Future<Output = (AStreamResultCore<'a>, AStreamNextResult)> + 'a>>,
}

pub(super) fn take_and_abort_pending<'a>(
    pending_next: &mut Option<AStreamPendingNext<'a>>,
) -> Option<AStreamPendingNext<'a>> {
    let mut pending = pending_next.take()?;
    if let Some(abort_handle) = pending.abort_handle.take() {
        abort_handle.abort();
    }
    Some(pending)
}

pub(super) fn poll_next_item<'a>(
    core: &mut Option<AStreamResultCore<'a>>,
    pending_next: &mut Option<AStreamPendingNext<'a>>,
    cx: &mut Context<'_>,
) -> Poll<AStreamNextResult> {
    if pending_next.is_none() {
        let Some(core) = core.take() else {
            return Poll::Ready(Err(stream_invariant(
                "astream_result core missing before scheduling poll",
            )));
        };
        let (abort_handle, abort_registration) = AbortHandle::new_pair();
        *pending_next = Some(AStreamPendingNext {
            abort_handle: Some(abort_handle),
            future: Box::pin(async move {
                let mut core = core;
                let result = match Abortable::new(core.next_item(), abort_registration).await {
                    Ok(result) => result,
                    Err(Aborted) => Ok(None),
                };
                (core, result)
            }),
        });
    }

    let poll_result = {
        let Some(pending) = pending_next.as_mut() else {
            return Poll::Ready(Err(stream_invariant(
                "astream_result pending future missing during poll",
            )));
        };
        pending.future.as_mut().poll(cx)
    };

    match poll_result {
        Poll::Pending => Poll::Pending,
        Poll::Ready((restored_core, result)) => {
            *pending_next = None;
            *core = Some(restored_core);
            Poll::Ready(result)
        }
    }
}

pub(super) async fn cancel_pending_and_restore_core<'a>(
    core: &mut Option<AStreamResultCore<'a>>,
    pending_next: &mut Option<AStreamPendingNext<'a>>,
) {
    if let Some(pending) = take_and_abort_pending(pending_next) {
        let (restored_core, _result) = pending.future.await;
        *core = Some(restored_core);
    }
}
