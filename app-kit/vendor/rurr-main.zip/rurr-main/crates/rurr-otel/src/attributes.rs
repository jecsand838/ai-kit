use opentelemetry::{Array as OtelArray, StringValue, Value as OtelValue};
use serde_json::Value;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum ArrayElementKind {
    Bool,
    String,
    I64,
    F64,
}

/// Converts a JSON value into an OpenTelemetry attribute when a reasonable mapping exists.
///
/// Null values return `None`; unsupported OTEL-native shapes are stringified.
pub fn convert_to_otel_attribute(value: &Value) -> Option<OtelValue> {
    match value {
        Value::Null => None,
        Value::Bool(b) => Some(OtelValue::Bool(*b)),
        Value::Number(n) => convert_number_to_otel(n),
        Value::String(s) => Some(OtelValue::String(s.clone().into())),
        Value::Array(values) => convert_array_to_otel(values),
        Value::Object(_) => Some(OtelValue::String(burr_json_string(value).into())),
    }
}

fn convert_array_to_otel(values: &[Value]) -> Option<OtelValue> {
    if values.is_empty() {
        return Some(OtelValue::String("[]".into()));
    }

    let Some(kind) = array_element_kind(&values[0]) else {
        return Some(OtelValue::String(
            burr_json_string(&Value::Array(values.to_vec())).into(),
        ));
    };
    if values
        .iter()
        .skip(1)
        .any(|value| array_element_kind(value) != Some(kind))
    {
        return Some(OtelValue::String(
            burr_json_string(&Value::Array(values.to_vec())).into(),
        ));
    }

    match kind {
        ArrayElementKind::Bool => {
            let result: Vec<bool> = values.iter().filter_map(Value::as_bool).collect();
            Some(OtelValue::Array(OtelArray::Bool(result)))
        }
        ArrayElementKind::String => {
            let result: Vec<StringValue> = values
                .iter()
                .filter_map(|value| value.as_str().map(|value| value.to_string().into()))
                .collect();
            Some(OtelValue::Array(OtelArray::String(result)))
        }
        ArrayElementKind::I64 => {
            let result: Vec<i64> = values.iter().filter_map(Value::as_i64).collect();
            Some(OtelValue::Array(OtelArray::I64(result)))
        }
        ArrayElementKind::F64 => {
            let result: Vec<f64> = values.iter().filter_map(Value::as_f64).collect();
            Some(OtelValue::Array(OtelArray::F64(result)))
        }
    }
}

fn array_element_kind(value: &Value) -> Option<ArrayElementKind> {
    match value {
        Value::Bool(_) => Some(ArrayElementKind::Bool),
        Value::String(_) => Some(ArrayElementKind::String),
        Value::Number(number) => {
            if number.is_i64() {
                Some(ArrayElementKind::I64)
            } else if number.is_f64() {
                Some(ArrayElementKind::F64)
            } else {
                None
            }
        }
        Value::Null | Value::Array(_) | Value::Object(_) => None,
    }
}

fn convert_number_to_otel(number: &serde_json::Number) -> Option<OtelValue> {
    if number.is_i64() {
        number.as_i64().map(OtelValue::I64)
    } else if number.is_f64() {
        number.as_f64().map(OtelValue::F64)
    } else {
        Some(OtelValue::String(number.to_string().into()))
    }
}

fn burr_json_string(value: &Value) -> String {
    match value {
        Value::Array(values) => {
            let elements = values
                .iter()
                .map(burr_json_string)
                .collect::<Vec<_>>()
                .join(", ");
            format!("[{elements}]")
        }
        Value::Object(map) => {
            let entries = map
                .iter()
                .map(|(key, value)| {
                    let key_json = Value::String(key.clone()).to_string();
                    format!("{key_json}: {}", burr_json_string(value))
                })
                .collect::<Vec<_>>()
                .join(", ");
            format!("{{{entries}}}")
        }
        _ => value.to_string(),
    }
}
