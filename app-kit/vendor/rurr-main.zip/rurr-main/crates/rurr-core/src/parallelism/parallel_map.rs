use super::map_common::{
    build_task, reducer_from_cascade, ParallelActionMeta, ParallelTaskActionCore, Reducer,
    TaskBuilder,
};
use super::{
    task_action::TaskBasedParallelAction, types::SubGraphTask, CascadeMode, RunnableGraph,
};
use crate::{
    action::{
        macro_support, ActionContext, ActionError, ActionResult, LocalAction,
        LocalAsyncStreamOutput,
    },
    application::ApplicationError,
    state::State,
};
use std::sync::Arc;

/// Maps a parent state into the state passed to each graph in a fan-out run.
pub type ParallelStateMapper =
    dyn Fn(&State, &ActionContext) -> Result<State, ApplicationError> + Send + Sync;
/// Splits a parent state into one state per child task.
pub type ParallelStateSplitter =
    dyn Fn(&State, &ActionContext) -> Result<Vec<State>, ApplicationError> + Send + Sync;
/// Builds explicit `(graph, state)` task pairs from the parent state.
pub type ParallelPairBuilder = dyn Fn(&State, &ActionContext) -> Result<Vec<(RunnableGraph, State)>, ApplicationError>
    + Send
    + Sync;

#[derive(Clone)]
/// Source configuration describing how a [`ParallelMap`] constructs its child tasks.
pub struct ParallelTaskSource(ParallelTaskSourceKind);

#[derive(Clone)]
enum ParallelTaskSourceKind {
    /// Reuses a fixed graph list while deriving one state for every graph.
    Graphs {
        /// Graphs to execute in parallel.
        graphs: Vec<RunnableGraph>,
        /// Mapper used to derive each child state from the parent state.
        state_mapper: Arc<ParallelStateMapper>,
    },
    /// Reuses one graph while deriving multiple child states.
    States {
        /// Graph to execute for each derived state.
        graph: RunnableGraph,
        /// Splitter used to derive child states from the parent state.
        state_splitter: Arc<ParallelStateSplitter>,
    },
    /// Builds full `(graph, state)` pairs dynamically.
    Pairs {
        /// Builder used to derive task pairs from the parent state.
        pair_builder: Arc<ParallelPairBuilder>,
    },
    Explicit {
        /// Internal task builder used by reduced helper adapters.
        task_builder: Arc<TaskBuilder>,
    },
}

#[derive(Clone)]
/// Task-based parallel action that runs child graphs and reduces their output states.
pub struct ParallelMap {
    source: ParallelTaskSource,
    core: ParallelTaskActionCore,
}

impl ParallelMap {
    /// Creates a parallel action from a task source and reduction metadata.
    pub fn new(
        source: ParallelTaskSource,
        reads: Vec<String>,
        writes: Vec<String>,
        inputs: Vec<String>,
        cascade_mode: CascadeMode,
    ) -> Self {
        let task_builder = source.task_builder();
        Self {
            source,
            core: ParallelTaskActionCore::new(
                ParallelActionMeta::new(reads, writes, cascade_mode.clone()).with_inputs(inputs),
                task_builder,
                reducer_from_cascade(&cascade_mode),
            ),
        }
    }

    pub(crate) fn with_reducer(
        source: ParallelTaskSource,
        reads: Vec<String>,
        writes: Vec<String>,
        inputs: Vec<String>,
        cascade_mode: CascadeMode,
        reducer: Arc<Reducer>,
    ) -> Self {
        let task_builder = source.task_builder();
        Self {
            source,
            core: ParallelTaskActionCore::new(
                ParallelActionMeta::new(reads, writes, cascade_mode).with_inputs(inputs),
                task_builder,
                reducer,
            ),
        }
    }

    /// Stores source text shown by [`crate::action::Action::source_code`].
    pub fn with_source_code(mut self, source_code: impl Into<String>) -> Self {
        self.core.meta_mut().set_source_code(source_code.into());
        self
    }

    /// Returns the task source used by this action.
    pub fn source(&self) -> &ParallelTaskSource {
        &self.source
    }
}

impl ParallelTaskSource {
    /// Reuses a fixed graph list while deriving one state for every graph.
    pub fn graphs(graphs: Vec<RunnableGraph>, state_mapper: Arc<ParallelStateMapper>) -> Self {
        Self(ParallelTaskSourceKind::Graphs {
            graphs,
            state_mapper,
        })
    }

    /// Reuses one graph while deriving multiple child states.
    pub fn states(graph: RunnableGraph, state_splitter: Arc<ParallelStateSplitter>) -> Self {
        Self(ParallelTaskSourceKind::States {
            graph,
            state_splitter,
        })
    }

    /// Builds full `(graph, state)` pairs dynamically.
    pub fn pairs(pair_builder: Arc<ParallelPairBuilder>) -> Self {
        Self(ParallelTaskSourceKind::Pairs { pair_builder })
    }

    pub(crate) fn explicit(task_builder: Arc<TaskBuilder>) -> Self {
        Self(ParallelTaskSourceKind::Explicit { task_builder })
    }

    fn task_builder(&self) -> Arc<TaskBuilder> {
        match &self.0 {
            ParallelTaskSourceKind::Graphs {
                graphs,
                state_mapper,
            } => {
                let task_graphs = graphs.clone();
                let state_mapper = state_mapper.clone();
                Arc::new(move |state: &State, ctx: &ActionContext| {
                    let mapped_state = (state_mapper)(state, ctx)?;
                    Ok(task_graphs
                        .iter()
                        .cloned()
                        .enumerate()
                        .map(|(index, graph)| build_task(graph, mapped_state.clone(), index, 0))
                        .collect())
                })
            }
            ParallelTaskSourceKind::States {
                graph,
                state_splitter,
            } => {
                let task_graph = graph.clone();
                let state_splitter = state_splitter.clone();
                Arc::new(move |state: &State, ctx: &ActionContext| {
                    let states = (state_splitter)(state, ctx)?;
                    Ok(states
                        .into_iter()
                        .enumerate()
                        .map(|(index, task_state)| {
                            build_task(task_graph.clone(), task_state, 0, index)
                        })
                        .collect())
                })
            }
            ParallelTaskSourceKind::Pairs { pair_builder } => {
                let pair_builder = pair_builder.clone();
                Arc::new(move |state: &State, ctx: &ActionContext| {
                    let pairs = (pair_builder)(state, ctx)?;
                    Ok(pairs
                        .into_iter()
                        .enumerate()
                        .map(|(index, (graph, task_state))| build_task(graph, task_state, index, 0))
                        .collect())
                })
            }
            ParallelTaskSourceKind::Explicit { task_builder } => task_builder.clone(),
        }
    }
}

impl LocalAction for ParallelMap {
    fn name(&self) -> Option<&str> {
        self.core.name()
    }

    fn source_code(&self) -> Option<String> {
        self.core.source_code()
    }

    fn reads(&self) -> &[String] {
        self.core.reads()
    }

    fn writes(&self) -> &[String] {
        self.core.writes()
    }

    fn inputs(&self) -> &[String] {
        self.core.inputs()
    }

    fn optional_inputs(&self) -> &[String] {
        self.core.optional_inputs()
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        macro_support::with_name_once(self, self.core.name(), name, |copied, next_name| {
            copied.core.meta_mut().set_name(next_name);
        })
    }

    fn run(&self, state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        self.core.run_sync(self, state, ctx)
    }

    async fn run_async(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        self.core.run_async(self, state, ctx).await
    }

    fn stream_run_async(&self, state: State, ctx: ActionContext) -> LocalAsyncStreamOutput {
        macro_support::one_shot_stream_from_run_async(self.clone(), state, ctx)
    }
}

impl TaskBasedParallelAction for ParallelMap {
    fn tasks(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<Vec<SubGraphTask>, ApplicationError> {
        self.core.build_tasks(state, ctx)
    }

    fn reduce(
        &self,
        parent_state: &State,
        child_states: Vec<State>,
    ) -> Result<ActionResult, ApplicationError> {
        self.core.reduce(parent_state, child_states)
    }

    fn pipeline_mode(&self) -> bool {
        self.core.meta().is_pipeline()
    }
}

#[cfg(test)]
mod tests {
    use super::{CascadeMode, ParallelMap, ParallelTaskSource, RunnableGraph};
    use crate::action::{ActionContext, ActionTracer};
    use crate::parallelism::TaskBasedParallelAction;
    use crate::state::State;
    use indexmap::IndexMap;
    use std::sync::Arc;

    fn empty_graph() -> RunnableGraph {
        RunnableGraph::new(Vec::new(), Vec::new(), None)
    }

    fn empty_context() -> ActionContext {
        ActionContext::new(IndexMap::new(), ActionTracer::default(), None)
    }

    #[test]
    fn graphs_source_builds_one_task_per_graph() {
        let map = ParallelMap::new(
            ParallelTaskSource::graphs(
                vec![empty_graph(), empty_graph()],
                Arc::new(|state, _ctx| Ok(state.clone())),
            ),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            CascadeMode::None,
        );
        let tasks = map
            .tasks(&State::new(IndexMap::new()), &empty_context())
            .expect("tasks should build");
        assert_eq!(tasks.len(), 2);
        assert_eq!(tasks[0].task_key, "0-0");
        assert_eq!(tasks[1].task_key, "1-0");
    }

    #[test]
    fn states_source_builds_one_task_per_state() {
        let map = ParallelMap::new(
            ParallelTaskSource::states(
                empty_graph(),
                Arc::new(|_state, _ctx| {
                    Ok(vec![
                        State::new(IndexMap::new()),
                        State::new(IndexMap::new()),
                    ])
                }),
            ),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            CascadeMode::None,
        );
        let tasks = map
            .tasks(&State::new(IndexMap::new()), &empty_context())
            .expect("tasks should build");
        assert_eq!(tasks.len(), 2);
        assert_eq!(tasks[0].task_key, "0-0");
        assert_eq!(tasks[1].task_key, "0-1");
    }

    #[test]
    fn pairs_source_builds_one_task_per_pair() {
        let pairs = vec![(empty_graph(), State::new(IndexMap::new()))];
        let map = ParallelMap::new(
            ParallelTaskSource::pairs(Arc::new(move |_state, _ctx| Ok(pairs.clone()))),
            Vec::new(),
            Vec::new(),
            Vec::new(),
            CascadeMode::None,
        );
        let tasks = map
            .tasks(&State::new(IndexMap::new()), &empty_context())
            .expect("tasks should build");
        assert_eq!(tasks.len(), 1);
        assert_eq!(tasks[0].task_key, "0-0");
    }
}
