use super::{PersistenceError, OP_CONNECTION_CLOSED, OP_SQLITE_QUERY_FAILED};

/// Maps a `rusqlite` error into the closest persistence-layer error variant.
pub fn map_rusqlite_error(
    error: rusqlite::Error,
    fallback_operation: &'static str,
) -> PersistenceError {
    if is_missing_table_message(rusqlite_error_message(&error)) {
        return PersistenceError::NotInitialized;
    }

    PersistenceError::UnsupportedOperation {
        operation: fallback_operation,
    }
}

/// Maps a `sqlx` SQLite error into the closest persistence-layer error variant.
pub fn map_sqlx_error(error: sqlx::Error) -> PersistenceError {
    match error {
        sqlx::Error::PoolClosed => PersistenceError::UnsupportedOperation {
            operation: OP_CONNECTION_CLOSED,
        },
        sqlx::Error::Database(db_error) if is_missing_table_message(Some(db_error.message())) => {
            PersistenceError::NotInitialized
        }
        _ => PersistenceError::UnsupportedOperation {
            operation: OP_SQLITE_QUERY_FAILED,
        },
    }
}

fn rusqlite_error_message(error: &rusqlite::Error) -> Option<&str> {
    match error {
        rusqlite::Error::SqliteFailure(_, message) => message.as_deref(),
        _ => None,
    }
}

fn is_missing_table_message(message: Option<&str>) -> bool {
    message.is_some_and(|value| value.contains("no such table"))
}
