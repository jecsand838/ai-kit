use super::StateError;
use serde_json::Value;

pub(super) fn parse_integer(value: &Value, key: &str) -> Result<i128, StateError> {
    if let Some(value) = value.as_i64() {
        return Ok(i128::from(value));
    }
    if let Some(value) = value.as_u64() {
        return Ok(i128::from(value));
    }
    Err(StateError::NonInteger {
        key: key.to_string(),
    })
}

pub(super) fn checked_increment(current: i128, delta: i64, key: &str) -> Result<Value, StateError> {
    let sum =
        current
            .checked_add(i128::from(delta))
            .ok_or_else(|| StateError::IntegerOverflow {
                key: key.to_string(),
            })?;

    if sum < i128::from(i64::MIN) || sum > i128::from(u64::MAX) {
        return Err(StateError::IntegerOverflow {
            key: key.to_string(),
        });
    }

    if sum > i128::from(i64::MAX) {
        return Ok(Value::from(sum as u64));
    }
    Ok(Value::from(sum as i64))
}

pub(super) fn value_kind(value: &Value) -> &'static str {
    match value {
        Value::Null => "null",
        Value::Bool(_) => "bool",
        Value::Number(number) => {
            if number.is_i64() {
                "i64"
            } else if number.is_u64() {
                "u64"
            } else {
                "f64"
            }
        }
        Value::String(_) => "string",
        Value::Array(_) => "array",
        Value::Object(_) => "object",
    }
}
