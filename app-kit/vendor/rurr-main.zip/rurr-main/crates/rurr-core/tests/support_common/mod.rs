pub(crate) mod field_serde;
pub(crate) mod persistence;
pub(crate) mod registry;
pub(crate) mod subprocess;
pub(crate) mod tracing;
pub(crate) mod typing;

fn keep_support_symbols_reachable() {
    let _ = (
        field_serde::register_prefixed_string_field_serde,
        persistence::with_sync_persister_spec,
        persistence::with_async_persister_spec,
        registry::registry_test_guard,
        registry::unique_registry_name,
        subprocess::subprocess_fixture_enabled,
        subprocess::run_subprocess_fixture,
        tracing::RecordedSpanEvent::phase,
        tracing::RecordedSpanEvent::span_name,
        tracing::RecordedSpanEvent::span_id,
        tracing::RecordedSpanEvent::app_id,
        tracing::RecordingHooks::events,
        tracing::RecordingHooks::attributes,
        tracing::tracer_with_recording_hooks,
        typing::NonNegativeCountTypingSystem::requiring_existing_count_before_increment,
        typing::RequireKeyTypingSystem::new,
        typing::StringListTypingSystem::new,
        typing::NoRoundTripSpyTypingSystem::reset_counts,
        typing::NoRoundTripSpyTypingSystem::roundtrip_calls,
        typing::NoRoundTripSpyTypingSystem::construct_data_calls,
        typing::NoRoundTripSpyTypingSystem::construct_state_calls,
    );
    let _ = (
        <tracing::RecordingHooks as rurr_core::lifecycle::SyncLifecycleAdapter>::pre_start_span,
        <tracing::RecordingHooks as rurr_core::lifecycle::SyncLifecycleAdapter>::post_end_span,
        <tracing::RecordingHooks as rurr_core::lifecycle::SyncLifecycleAdapter>::log_attributes,
        <tracing::RecordingHooks as rurr_core::lifecycle::AsyncLifecycleAdapter>::pre_start_span,
        <tracing::RecordingHooks as rurr_core::lifecycle::AsyncLifecycleAdapter>::post_end_span,
        <tracing::RecordingHooks as rurr_core::lifecycle::AsyncLifecycleAdapter>::log_attributes,
        <tracing::FailOnceHook as rurr_core::lifecycle::SyncLifecycleAdapter>::pre_start_span,
        <tracing::FailOnceHook as rurr_core::lifecycle::AsyncLifecycleAdapter>::pre_start_span,
    );
    let _ = persistence::with_sync_initializer_spec
        as fn(
            rurr_core::application::ApplicationBuilder,
            std::sync::Arc<dyn rurr_persistence::BaseStateLoader>,
            bool,
            indexmap::IndexMap<String, serde_json::Value>,
            String,
            Option<indexmap::IndexMap<String, serde_json::Value>>,
            Option<rurr_persistence::PersistenceLoadTarget>,
        ) -> Result<
            rurr_core::application::ApplicationBuilder,
            rurr_core::application::ApplicationError,
        >;
    let _ = persistence::with_async_initializer_spec
        as fn(
            rurr_core::application::ApplicationBuilder,
            std::sync::Arc<dyn rurr_persistence::AsyncBaseStateLoader>,
            bool,
            indexmap::IndexMap<String, serde_json::Value>,
            String,
            Option<indexmap::IndexMap<String, serde_json::Value>>,
            Option<rurr_persistence::PersistenceLoadTarget>,
        ) -> Result<
            rurr_core::application::ApplicationBuilder,
            rurr_core::application::ApplicationError,
        >;
    let _ = [
        std::mem::size_of::<typing::PassthroughTypingSystem>(),
        std::mem::size_of::<typing::NonNegativeCountTypingSystem>(),
        std::mem::size_of::<typing::DeleteOnlyPostActionTypingSystem>(),
        std::mem::size_of::<typing::RequireKeyTypingSystem>(),
        std::mem::size_of::<typing::StringListTypingSystem>(),
        std::mem::size_of::<typing::ResumeStateTypingSystem>(),
        std::mem::size_of::<typing::RoundTripCountTypingSystem>(),
        std::mem::size_of::<typing::DeleteOnlyRoundTripCountTypingSystem>(),
        std::mem::size_of::<typing::ResumeRoundTripTypingSystem>(),
        std::mem::size_of::<typing::NoRoundTripSpyTypingSystem>(),
        std::mem::size_of::<tracing::RecordedSpanEvent>(),
        std::mem::size_of::<tracing::RecordingHooks>(),
        std::mem::size_of::<tracing::FailOnceHook>(),
    ];
}

const _: fn() = keep_support_symbols_reachable;
