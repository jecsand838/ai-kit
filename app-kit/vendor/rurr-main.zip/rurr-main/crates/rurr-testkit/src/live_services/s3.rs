use super::{unique_live_suffix, LiveServiceError};
use aws_sdk_s3::primitives::ByteStream;
use rurr_core::tracking::{S3AddressingStyle, S3TrackingConfig};
use serde_json::Value;
use std::collections::HashMap;
use std::io::{BufReader, Cursor};

const S3_LIVE_SERVICE: &str = "minio-s3";
const DEFAULT_S3_ENDPOINT_URL: &str = "http://127.0.0.1:9000";
const DEFAULT_S3_REGION: &str = "us-east-1";
const DEFAULT_S3_ACCESS_KEY_ID: &str = "minioadmin";
const DEFAULT_S3_SECRET_ACCESS_KEY: &str = "minioadmin";

fn s3_live_endpoint() -> String {
    std::env::var("RURR_S3_ENDPOINT_URL").unwrap_or_else(|_| DEFAULT_S3_ENDPOINT_URL.to_string())
}

fn s3_live_invalid(endpoint: &str, message: impl Into<String>) -> LiveServiceError {
    LiveServiceError::InvalidConfiguration {
        service: S3_LIVE_SERVICE,
        endpoint: endpoint.to_string(),
        message: message.into(),
    }
}

fn s3_live_unavailable(endpoint: &str, message: impl Into<String>) -> LiveServiceError {
    LiveServiceError::Unavailable {
        service: S3_LIVE_SERVICE,
        endpoint: endpoint.to_string(),
        message: message.into(),
    }
}

/// One live S3 bucket plus raw-harness helpers for strict provider tests.
pub struct S3LiveBucketScenario {
    harness: S3LiveHarness,
    bucket: String,
}

impl S3LiveBucketScenario {
    /// Creates a unique live bucket for one test scenario.
    pub async fn new(caller: &'static str, bucket_prefix: &str) -> Result<Self, LiveServiceError> {
        let harness = S3LiveHarness::new(caller).await?;
        let bucket = harness.unique_bucket(bucket_prefix);
        harness.create_bucket(&bucket).await?;
        Ok(Self { harness, bucket })
    }

    /// Returns the scenario bucket name.
    pub fn bucket(&self) -> &str {
        &self.bucket
    }

    /// Returns the raw S3 live harness.
    pub fn harness(&self) -> &S3LiveHarness {
        &self.harness
    }

    /// Builds a path-style tracking config for this bucket.
    pub fn tracking_config(
        &self,
        project: &str,
        tracker_id: &str,
    ) -> Result<S3TrackingConfig, LiveServiceError> {
        self.harness
            .tracking_config(project, &self.bucket, tracker_id)
    }

    /// Builds a tracking config and panics on invalid test setup.
    pub fn expect_tracking_config(&self, project: &str, tracker_id: &str) -> S3TrackingConfig {
        self.tracking_config(project, tracker_id)
            .expect("s3 config should build")
    }

    /// Builds a path-style tracking config without static credentials.
    pub fn tracking_config_without_static_credentials(
        &self,
        project: &str,
        tracker_id: &str,
    ) -> Result<S3TrackingConfig, LiveServiceError> {
        let mut config = S3TrackingConfig::new(project, &self.bucket, DEFAULT_S3_REGION)
            .map_err(|error| s3_live_invalid(self.harness.endpoint(), error.to_string()))?
            .with_tracker_id(tracker_id)
            .map_err(|error| s3_live_invalid(self.harness.endpoint(), error.to_string()))?;
        config.transport = config
            .transport
            .with_endpoint_url(self.harness.endpoint().to_string())
            .map_err(|error| s3_live_invalid(self.harness.endpoint(), error.to_string()))?
            .with_addressing_style(S3AddressingStyle::PathStyle);
        Ok(config)
    }

    /// Builds a no-static-credentials config and panics on invalid test setup.
    pub fn expect_tracking_config_without_static_credentials(
        &self,
        project: &str,
        tracker_id: &str,
    ) -> S3TrackingConfig {
        self.tracking_config_without_static_credentials(project, tracker_id)
            .expect("s3 config should build")
    }

    /// Uploads one raw object without reshaping provider metadata.
    pub async fn put_object(
        &self,
        key: &str,
        body: ByteStream,
        metadata: &[(&str, &str)],
    ) -> Result<(), LiveServiceError> {
        let mut request = self
            .harness
            .client()
            .put_object()
            .bucket(&self.bucket)
            .key(key)
            .body(body);
        for (name, value) in metadata {
            request = request.metadata(*name, *value);
        }
        request
            .send()
            .await
            .map_err(|error| s3_live_unavailable(self.harness.endpoint(), error.to_string()))?;
        Ok(())
    }

    /// Creates a raw provider artifact probe for this bucket and prefix.
    pub fn artifact_probe(&self, prefix: impl Into<String>) -> S3ArtifactProbe<'_> {
        S3ArtifactProbe {
            scenario: self,
            prefix: prefix.into(),
        }
    }
}

/// Raw S3 provider probe for strict live artifact assertions.
pub struct S3ArtifactProbe<'a> {
    scenario: &'a S3LiveBucketScenario,
    prefix: String,
}

impl S3ArtifactProbe<'_> {
    /// Lists provider keys for the probe prefix and verifies provider order.
    pub async fn objects(&self) -> Result<Vec<String>, LiveServiceError> {
        let keys = self
            .scenario
            .harness
            .list_keys_raw(&self.scenario.bucket, &self.prefix)
            .await?;
        if !keys.windows(2).all(|pair| pair[0] <= pair[1]) {
            return Err(s3_live_unavailable(
                self.scenario.harness.endpoint(),
                format!(
                    "S3 provider should return ListObjectsV2 keys in lexicographic order: {keys:?}"
                ),
            ));
        }
        Ok(keys)
    }

    /// Reads required user metadata for one object through raw HEAD.
    pub async fn head_required(
        &self,
        key: &str,
    ) -> Result<HashMap<String, String>, LiveServiceError> {
        self.scenario
            .harness
            .head_metadata_raw(&self.scenario.bucket, key)
            .await?
            .ok_or_else(|| {
                s3_live_unavailable(
                    self.scenario.harness.endpoint(),
                    format!("S3 object '{key}' HEAD response did not include user metadata"),
                )
            })
    }

    /// Reads raw object bytes through GET.
    pub async fn object_bytes(&self, key: &str) -> Result<Vec<u8>, LiveServiceError> {
        self.scenario
            .harness
            .get_object_bytes_raw(&self.scenario.bucket, key)
            .await
    }

    /// Reads a complete JSONL object body as raw JSON values.
    pub async fn jsonl_values(&self, key: &str) -> Result<Vec<Value>, LiveServiceError> {
        let body = self.object_bytes(key).await?;
        S3LiveHarness::parse_jsonl(&body).map_err(|error| {
            s3_live_unavailable(
                self.scenario.harness.endpoint(),
                format!("S3 object '{key}' did not contain complete JSONL: {error}"),
            )
        })
    }

    /// Requires that the raw object body ends with a JSONL newline.
    pub async fn assert_body_has_trailing_newline(
        &self,
        key: &str,
    ) -> Result<Vec<u8>, LiveServiceError> {
        let body = self.object_bytes(key).await?;
        if !body.ends_with(b"\n") {
            return Err(s3_live_unavailable(
                self.scenario.harness.endpoint(),
                format!("S3 object '{key}' did not end with a newline"),
            ));
        }
        Ok(body)
    }
}

/// Raw MinIO/S3 live-test harness used by strict provider lanes.
///
/// The harness constructs one path-style AWS SDK client for the workspace's
/// local MinIO service and exposes raw provider operations. It intentionally
/// does not sort keys or reshape metadata; callers own any assertion-specific
/// ordering or projection.
pub struct S3LiveHarness {
    client: aws_sdk_s3::Client,
    endpoint: String,
}

impl S3LiveHarness {
    /// Builds a path-style AWS SDK client for the local MinIO service.
    pub async fn new(caller: &'static str) -> Result<Self, LiveServiceError> {
        let endpoint = s3_live_endpoint();
        let shared = aws_config::defaults(aws_config::BehaviorVersion::latest())
            .region(aws_types::region::Region::new(DEFAULT_S3_REGION))
            .endpoint_url(endpoint.clone())
            .http_client(aws_smithy_http_client::Builder::new().build_http())
            .credentials_provider(aws_credential_types::Credentials::new(
                DEFAULT_S3_ACCESS_KEY_ID,
                DEFAULT_S3_SECRET_ACCESS_KEY,
                None,
                None,
                caller,
            ))
            .load()
            .await;
        let config = aws_sdk_s3::config::Builder::from(&shared)
            .force_path_style(true)
            .build();
        Ok(Self {
            client: aws_sdk_s3::Client::from_conf(config),
            endpoint,
        })
    }

    /// Returns the raw AWS SDK client.
    pub fn client(&self) -> &aws_sdk_s3::Client {
        &self.client
    }

    /// Returns the configured S3 endpoint URL.
    pub fn endpoint(&self) -> &str {
        &self.endpoint
    }

    /// Builds a unique lower-case bucket name for one live test.
    pub fn unique_bucket(&self, prefix: &str) -> String {
        format!("{prefix}-{}", unique_live_suffix("s3"))
    }

    /// Creates a bucket through the raw provider API.
    pub async fn create_bucket(&self, bucket: &str) -> Result<(), LiveServiceError> {
        self.client
            .create_bucket()
            .bucket(bucket)
            .send()
            .await
            .map_err(|error| s3_live_unavailable(&self.endpoint, error.to_string()))?;
        Ok(())
    }

    /// Builds the core S3 tracking configuration for this live service.
    pub fn tracking_config(
        &self,
        project: &str,
        bucket: &str,
        tracker_id: &str,
    ) -> Result<S3TrackingConfig, LiveServiceError> {
        let mut config = S3TrackingConfig::new(project, bucket, DEFAULT_S3_REGION)
            .map_err(|error| s3_live_invalid(&self.endpoint, error.to_string()))?
            .with_tracker_id(tracker_id)
            .map_err(|error| s3_live_invalid(&self.endpoint, error.to_string()))?;
        config.transport = config
            .transport
            .with_endpoint_url(self.endpoint.clone())
            .map_err(|error| s3_live_invalid(&self.endpoint, error.to_string()))?
            .with_addressing_style(S3AddressingStyle::PathStyle)
            .with_credentials(DEFAULT_S3_ACCESS_KEY_ID, DEFAULT_S3_SECRET_ACCESS_KEY, None)
            .map_err(|error| s3_live_invalid(&self.endpoint, error.to_string()))?;
        Ok(config)
    }

    /// Reads raw user metadata for an object through HEAD.
    pub async fn head_metadata_raw(
        &self,
        bucket: &str,
        key: &str,
    ) -> Result<Option<HashMap<String, String>>, LiveServiceError> {
        self.client
            .head_object()
            .bucket(bucket)
            .key(key)
            .send()
            .await
            .map_err(|error| s3_live_unavailable(&self.endpoint, error.to_string()))
            .map(|output| output.metadata().cloned())
    }

    /// Reads raw object bytes through GET.
    pub async fn get_object_bytes_raw(
        &self,
        bucket: &str,
        key: &str,
    ) -> Result<Vec<u8>, LiveServiceError> {
        let output = self
            .client
            .get_object()
            .bucket(bucket)
            .key(key)
            .send()
            .await
            .map_err(|error| s3_live_unavailable(&self.endpoint, error.to_string()))?;
        output
            .body
            .collect()
            .await
            .map(|body| body.into_bytes().to_vec())
            .map_err(|error| s3_live_unavailable(&self.endpoint, error.to_string()))
    }

    /// Lists raw provider keys for a prefix without sorting or normalization.
    pub async fn list_keys_raw(
        &self,
        bucket: &str,
        prefix: &str,
    ) -> Result<Vec<String>, LiveServiceError> {
        let mut keys = Vec::new();
        let mut continuation_token = None;
        loop {
            let mut request = self.client.list_objects_v2().bucket(bucket).prefix(prefix);
            if let Some(token) = continuation_token.as_deref() {
                request = request.continuation_token(token);
            }
            let listed = request
                .send()
                .await
                .map_err(|error| s3_live_unavailable(&self.endpoint, error.to_string()))?;
            for (index, object) in listed.contents().iter().enumerate() {
                let key = object.key().ok_or_else(|| {
                    s3_live_unavailable(
                        &self.endpoint,
                        format!("S3 object at index {index} is missing Key"),
                    )
                })?;
                keys.push(key.to_string());
            }

            let is_truncated = listed.is_truncated().ok_or_else(|| {
                s3_live_unavailable(
                    &self.endpoint,
                    "S3 ListObjectsV2 response is missing IsTruncated",
                )
            })?;
            if !is_truncated {
                break;
            }
            continuation_token = listed.next_continuation_token().map(str::to_string);
            if continuation_token.is_none() {
                return Err(s3_live_unavailable(
                    &self.endpoint,
                    "truncated S3 listing did not include a continuation token",
                ));
            }
        }
        Ok(keys)
    }

    /// Parses JSONL bytes with the workspace tracking-store JSONL semantics.
    pub fn parse_jsonl(body: &[u8]) -> Result<Vec<Value>, LiveServiceError> {
        let mut values = Vec::new();
        rurr_tracking_store::jsonl::visit_complete_jsonl_values::<
            _,
            Value,
            Box<dyn std::error::Error + Send + Sync>,
            _,
        >(BufReader::new(Cursor::new(body)), |value| {
            values.push(value);
            Ok(())
        })
        .map_err(|error| s3_live_invalid("jsonl", error.to_string()))?;
        Ok(values)
    }
}
