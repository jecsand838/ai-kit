use super::dir_file_ops::ExactChildFileOpenOptions;
use super::AnchoredDir;
use std::fs;
use std::io::{self, Read};
#[cfg(windows)]
use std::path::Path;
use tempfile::tempdir;

#[cfg(unix)]
use serde_json::json;
#[cfg(unix)]
use std::io::Write;
#[cfg(unix)]
use std::os::unix::fs as unix_fs;
#[cfg(windows)]
use std::os::windows::fs as windows_fs;

#[cfg(windows)]
#[test]
fn platform_backend_exposes_complete_directory_anchor_contract() {
    let _open_root: fn(&Path) -> io::Result<super::kernel::AnchoredDirectory> =
        super::kernel::open_root_directory;
    let _revalidate_root: fn(&super::kernel::AnchoredDirectory, &Path) -> io::Result<()> =
        super::kernel::revalidate_root_directory;
    let _open_child: fn(
        &super::kernel::AnchoredDirectory,
        &std::ffi::OsStr,
        super::kernel::DirectChildDirectoryMissingBehavior,
    ) -> io::Result<Option<super::kernel::AnchoredDirectory>> =
        super::kernel::open_direct_child_directory;
    let _revalidate_child: fn(
        &super::kernel::AnchoredDirectory,
        &super::kernel::AnchoredDirectory,
        &std::ffi::OsStr,
    ) -> io::Result<()> = super::kernel::revalidate_direct_child_directory;
    let _open_file: fn(
        &super::kernel::AnchoredDirectory,
        &std::ffi::OsStr,
        super::dir_file_ops::ExactChildFileOpenOptions,
    ) -> io::Result<Option<std::fs::File>> = super::kernel::open_direct_child_file;
    let _list_children: fn(
        &super::kernel::AnchoredDirectory,
    ) -> io::Result<Vec<std::ffi::OsString>> = super::kernel::list_direct_child_directory_names;
}

#[test]
fn exact_existing_child_opens_successfully() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let anchor = AnchoredDir::open(&canonical_dir)?;
    let path = canonical_dir.join("annotations.jsonl");
    fs::write(&path, "seed\n")?;

    let mut contents = String::new();
    let opened = anchor.with_locked_child_file::<_, io::Error, _>(
        "project directory",
        "annotation file",
        "annotations.jsonl",
        ExactChildFileOpenOptions::shared_read_existing(),
        |file| {
            file.read_to_string(&mut contents)?;
            Ok(())
        },
    )?;

    assert_eq!(opened, Some(()));
    assert_eq!(contents, "seed\n");
    Ok(())
}

#[test]
fn exact_existing_child_directory_opens_successfully() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let child_dir = canonical_dir.join("assets");
    let nested_child_dir = child_dir.join("js");
    fs::create_dir(&child_dir)?;
    fs::create_dir(&nested_child_dir)?;
    fs::write(nested_child_dir.join("app.js"), "console.log('ok');")?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    let mut entries = anchor.list_child_dirs()?;
    entries.sort();

    assert_eq!(entries.len(), 1);
    assert_eq!(entries[0], "assets");
    anchor
        .open_child_dir("anchored directory", "directory", &entries[0])?
        .revalidate()?;
    Ok(())
}

#[test]
fn list_child_dirs_skips_non_utf8_and_yields_anchored_dirs() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    fs::create_dir(canonical_dir.join("project_a"))?;
    fs::create_dir(canonical_dir.join("project_b"))?;
    fs::write(canonical_dir.join("metadata.json"), "{}")?;
    #[cfg(unix)]
    {
        use std::os::unix::ffi::OsStringExt;

        let non_utf8_dir = canonical_dir.join(std::ffi::OsString::from_vec(vec![0xff, 0xfe]));
        if let Err(error) = fs::create_dir(&non_utf8_dir) {
            let unsupported_non_utf8_name = error.kind() == io::ErrorKind::InvalidInput
                || matches!(error.raw_os_error(), Some(92));
            assert!(
                unsupported_non_utf8_name,
                "unexpected error creating non-utf8 test directory '{}': {error}",
                non_utf8_dir.display()
            );
        }
    }

    let anchor = AnchoredDir::open(&canonical_dir)?;
    let mut entries = anchor.list_child_dirs()?;
    entries.sort();

    assert_eq!(
        entries,
        vec!["project_a".to_string(), "project_b".to_string()]
    );
    for entry in entries {
        let child_anchor = anchor.open_child_dir("anchored directory", "directory", &entry)?;
        child_anchor.revalidate()?;
        assert_eq!(
            child_anchor.display_path(),
            canonical_dir.join(entry).as_path()
        );
    }
    Ok(())
}

#[test]
fn list_child_dirs_rejects_root_directory_swap_at_same_path() -> io::Result<()> {
    let root = tempdir()?;
    let requested_dir = root.path().join("project");
    let moved_dir = root.path().join("project-real");
    fs::create_dir(&requested_dir)?;
    fs::create_dir(requested_dir.join("assets"))?;
    let canonical_dir = fs::canonicalize(&requested_dir)?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    fs::rename(&requested_dir, &moved_dir)?;
    fs::create_dir(&requested_dir)?;

    let error = anchor
        .list_child_dirs()
        .expect_err("root directory swaps must fail closed during anchored enumeration");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[test]
fn list_child_dirs_rejects_child_directory_swap_at_same_path() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let child_dir = canonical_dir.join("assets");
    let moved_dir = canonical_dir.join("assets-real");
    fs::create_dir(&child_dir)?;
    fs::create_dir(child_dir.join("js"))?;
    let anchor = AnchoredDir::open(&canonical_dir)?;
    let child_anchor = anchor.open_child_dir("project directory", "asset root", "assets")?;

    fs::rename(&child_dir, &moved_dir)?;
    fs::create_dir(&child_dir)?;

    let error = child_anchor
        .list_child_dirs()
        .expect_err("child directory swaps must fail closed during anchored enumeration");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(unix)]
#[test]
fn list_child_dirs_rejects_same_root_directory_aliases() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let real_dir = canonical_dir.join("real_project");
    let alias_dir = canonical_dir.join("alias_project");
    fs::create_dir(&real_dir)?;
    unix_fs::symlink(&real_dir, &alias_dir)?;

    let anchor = AnchoredDir::open(&canonical_dir)?;
    let error = anchor
        .list_child_dirs()
        .expect_err("same-root aliases must fail closed during anchored enumeration");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(windows)]
#[test]
fn list_child_dirs_rejects_same_root_directory_aliases() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let real_dir = canonical_dir.join("real_project");
    let alias_dir = canonical_dir.join("alias_project");
    fs::create_dir(&real_dir)?;
    if !create_windows_directory_alias(&real_dir, &alias_dir)? {
        return Ok(());
    }

    let anchor = AnchoredDir::open(&canonical_dir)?;
    let error = anchor
        .list_child_dirs()
        .expect_err("same-root aliases must fail closed during anchored enumeration");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[test]
fn read_required_descendant_bytes_reads_nested_leaf() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let asset_path = canonical_dir.join("assets").join("js").join("app.js");
    fs::create_dir(canonical_dir.join("assets"))?;
    fs::create_dir(canonical_dir.join("assets").join("js"))?;
    fs::write(&asset_path, "console.log('anchored');")?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    let bytes =
        anchor.read_required_descendant_bytes("ui directory", "asset path", "assets/js/app.js")?;

    assert_eq!(bytes, b"console.log('anchored');");
    Ok(())
}

#[test]
fn required_reads_report_missing_file_without_internal_panic() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    let child_error = anchor
        .read_required_child_to_string("project directory", "metadata file", "metadata.json")
        .expect_err("missing required child file must return an io error");
    assert_eq!(child_error.kind(), io::ErrorKind::NotFound);
    assert!(
        child_error.to_string().contains("metadata file"),
        "error should preserve the configured file kind: {child_error}"
    );

    let descendant_error = anchor
        .read_required_descendant_bytes("ui directory", "asset path", "assets/js/app.js")
        .expect_err("missing required descendant file must return an io error");
    assert_eq!(descendant_error.kind(), io::ErrorKind::NotFound);
    assert!(
        descendant_error.to_string().contains("asset path"),
        "error should preserve the configured file kind: {descendant_error}"
    );

    Ok(())
}

#[cfg(unix)]
#[test]
fn read_required_descendant_bytes_rejects_assets_root_swap_before_open() -> io::Result<()> {
    let root = tempdir()?;
    let outside = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let assets_dir = canonical_dir.join("assets");
    let moved_assets_dir = canonical_dir.join("assets-real");
    fs::create_dir(&assets_dir)?;
    fs::create_dir(assets_dir.join("js"))?;
    fs::write(assets_dir.join("js").join("app.js"), "inside")?;
    fs::create_dir(outside.path().join("js"))?;
    fs::write(outside.path().join("js").join("app.js"), "outside")?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    fs::rename(&assets_dir, &moved_assets_dir)?;
    unix_fs::symlink(outside.path(), &assets_dir)?;

    let error = anchor
        .read_required_descendant_bytes("ui directory", "asset path", "assets/js/app.js")
        .expect_err("assets-root swaps must fail closed");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(unix)]
#[test]
fn read_required_descendant_bytes_rejects_parent_directory_swap_before_open() -> io::Result<()> {
    let root = tempdir()?;
    let outside = tempdir()?;
    let requested_dir = root.path().join("ui");
    let moved_dir = root.path().join("ui-real");
    fs::create_dir(&requested_dir)?;
    fs::create_dir(requested_dir.join("assets"))?;
    fs::create_dir(requested_dir.join("assets").join("js"))?;
    fs::write(
        requested_dir.join("assets").join("js").join("app.js"),
        "inside",
    )?;
    fs::create_dir(outside.path().join("assets"))?;
    fs::create_dir(outside.path().join("assets").join("js"))?;
    fs::write(
        outside.path().join("assets").join("js").join("app.js"),
        "outside",
    )?;
    let canonical_dir = fs::canonicalize(&requested_dir)?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    fs::rename(&requested_dir, &moved_dir)?;
    unix_fs::symlink(outside.path(), &requested_dir)?;

    let error = anchor
        .read_required_descendant_bytes("ui directory", "asset path", "assets/js/app.js")
        .expect_err("parent directory swaps must fail closed");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[test]
fn ensure_child_dir_creates_missing_directory() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    let child_anchor = anchor.ensure_child_dir("project directory", "app directory", "app_a")?;

    child_anchor.revalidate()?;
    assert_eq!(
        child_anchor.display_path(),
        canonical_dir.join("app_a").as_path()
    );
    assert!(canonical_dir.join("app_a").is_dir());
    Ok(())
}

#[test]
fn root_directory_anchor_rejects_directory_swap_at_same_path() -> io::Result<()> {
    let root = tempdir()?;
    let requested_dir = root.path().join("project");
    let moved_dir = root.path().join("project-real");
    fs::create_dir(&requested_dir)?;
    let canonical_dir = fs::canonicalize(&requested_dir)?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    fs::rename(&canonical_dir, &moved_dir)?;
    fs::create_dir(&canonical_dir)?;

    let error = anchor
        .revalidate()
        .expect_err("root anchor must fail closed after a directory swap");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(unix)]
#[test]
fn root_directory_anchor_accepts_symlinked_root_and_pins_canonical_display_path() -> io::Result<()>
{
    let root = tempdir()?;
    let requested_dir = root.path().join("requested-root");
    let real_dir = root.path().join("real-root");
    fs::create_dir(&real_dir)?;
    fs::create_dir(real_dir.join("assets"))?;
    unix_fs::symlink(&real_dir, &requested_dir)?;
    let canonical_dir = fs::canonicalize(&real_dir)?;

    let anchor = AnchoredDir::open(&requested_dir)?;
    let mut entries = anchor.list_child_dirs()?;
    entries.sort();

    assert_eq!(anchor.display_path(), canonical_dir.as_path());
    assert_eq!(entries, vec!["assets".to_string()]);
    Ok(())
}

#[cfg(unix)]
#[test]
fn symlinked_root_anchor_stays_pinned_after_requested_path_retarget() -> io::Result<()> {
    let root = tempdir()?;
    let requested_dir = root.path().join("requested-root");
    let real_dir = root.path().join("real-root");
    let outside_dir = root.path().join("outside-root");
    fs::create_dir(&real_dir)?;
    fs::create_dir(real_dir.join("assets"))?;
    fs::create_dir(real_dir.join("assets").join("js"))?;
    fs::write(
        real_dir.join("assets").join("js").join("app.js"),
        "console.log('pinned');",
    )?;
    fs::create_dir(&outside_dir)?;
    fs::create_dir(outside_dir.join("assets"))?;
    fs::create_dir(outside_dir.join("assets").join("js"))?;
    fs::write(
        outside_dir.join("assets").join("js").join("app.js"),
        "console.log('outside');",
    )?;
    unix_fs::symlink(&real_dir, &requested_dir)?;

    let anchor = AnchoredDir::open(&requested_dir)?;

    fs::remove_file(&requested_dir)?;
    unix_fs::symlink(&outside_dir, &requested_dir)?;

    let bytes =
        anchor.read_required_descendant_bytes("ui directory", "asset path", "assets/js/app.js")?;

    assert_eq!(bytes, b"console.log('pinned');");
    Ok(())
}

#[test]
fn child_directory_anchor_rejects_directory_swap_at_same_path() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let child_dir = canonical_dir.join("assets");
    let moved_dir = canonical_dir.join("assets-real");
    fs::create_dir(&child_dir)?;
    let anchor = AnchoredDir::open(&canonical_dir)?;
    let child_anchor = anchor.open_child_dir("project directory", "asset root", "assets")?;

    fs::rename(&child_dir, &moved_dir)?;
    fs::create_dir(&child_dir)?;

    let error = child_anchor
        .revalidate()
        .expect_err("child anchor must fail closed after a directory swap");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(windows)]
#[test]
fn same_root_directory_alias_fails_closed() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let sibling_dir = canonical_dir.join("sibling");
    let alias_dir = canonical_dir.join("assets");
    fs::create_dir(&sibling_dir)?;
    if !create_windows_directory_alias(&sibling_dir, &alias_dir)? {
        return Ok(());
    }

    let anchor = AnchoredDir::open(&canonical_dir)?;
    let error = anchor
        .open_child_dir("project directory", "asset root", "assets")
        .expect_err("same-root aliases must fail closed");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(windows)]
fn create_windows_directory_alias(target: &Path, alias: &Path) -> io::Result<bool> {
    match windows_fs::symlink_dir(target, alias) {
        Ok(()) => Ok(true),
        Err(error)
            if matches!(
                error.kind(),
                io::ErrorKind::PermissionDenied | io::ErrorKind::Unsupported
            ) =>
        {
            Ok(false)
        }
        Err(error) => Err(error),
    }
}

#[cfg(unix)]
#[test]
fn broken_symlink_fails_closed() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let anchor = AnchoredDir::open(&canonical_dir)?;
    unix_fs::symlink(
        canonical_dir.join("missing.jsonl"),
        canonical_dir.join("annotations.jsonl"),
    )?;

    let error = anchor
        .with_locked_child_file::<_, io::Error, _>(
            "project directory",
            "annotation file",
            "annotations.jsonl",
            ExactChildFileOpenOptions::shared_read_existing(),
            |_file| Ok(()),
        )
        .expect_err("broken symlinks must fail closed");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(unix)]
#[test]
fn outside_root_symlink_fails_closed() -> io::Result<()> {
    let root = tempdir()?;
    let outside = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let anchor = AnchoredDir::open(&canonical_dir)?;
    let secret = outside.path().join("annotations.jsonl");
    fs::write(&secret, "outside\n")?;
    unix_fs::symlink(&secret, canonical_dir.join("annotations.jsonl"))?;

    let error = anchor
        .with_locked_child_file::<_, io::Error, _>(
            "project directory",
            "annotation file",
            "annotations.jsonl",
            ExactChildFileOpenOptions::shared_read_existing(),
            |_file| Ok(()),
        )
        .expect_err("outside-root symlinks must fail closed");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(unix)]
#[test]
fn same_root_alias_fails_closed() -> io::Result<()> {
    let root = tempdir()?;
    let canonical_dir = root.path().join("project");
    let sibling_dir = root.path().join("sibling");
    fs::create_dir_all(&canonical_dir)?;
    fs::create_dir_all(&sibling_dir)?;
    let sibling = sibling_dir.join("annotations.jsonl");
    fs::write(&sibling, "sibling\n")?;
    unix_fs::symlink(&sibling, canonical_dir.join("annotations.jsonl"))?;

    let canonical_dir = fs::canonicalize(&canonical_dir)?;
    let anchor = AnchoredDir::open(&canonical_dir)?;
    let error = anchor
        .with_locked_child_file::<_, io::Error, _>(
            "project directory",
            "annotation file",
            "annotations.jsonl",
            ExactChildFileOpenOptions::shared_read_existing(),
            |_file| Ok(()),
        )
        .expect_err("same-root aliases must fail closed");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    Ok(())
}

#[cfg(unix)]
#[test]
fn shared_read_rejects_parent_directory_swap_before_open() -> io::Result<()> {
    let root = tempdir()?;
    let outside = tempdir()?;
    let requested_dir = root.path().join("project");
    let moved_dir = root.path().join("project-real");
    fs::create_dir_all(&requested_dir)?;
    fs::write(requested_dir.join("annotations.jsonl"), "inside\n")?;
    fs::write(outside.path().join("annotations.jsonl"), "outside\n")?;
    let canonical_dir = fs::canonicalize(&requested_dir)?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    fs::rename(&requested_dir, &moved_dir)?;
    unix_fs::symlink(outside.path(), &requested_dir)?;

    let mut contents = String::new();
    let error = anchor
        .with_locked_child_file::<_, io::Error, _>(
            "project directory",
            "annotation file",
            "annotations.jsonl",
            ExactChildFileOpenOptions::shared_read_existing(),
            |file| {
                file.read_to_string(&mut contents)?;
                Ok(())
            },
        )
        .expect_err("swapped parent directories must fail closed");

    assert_eq!(error.kind(), io::ErrorKind::InvalidInput);
    assert!(
        !contents.contains("outside"),
        "outside content must not be exposed after a parent swap"
    );
    Ok(())
}

#[cfg(unix)]
#[test]
fn create_if_missing_rejects_parent_directory_swap_before_open() -> io::Result<()> {
    let root = tempdir()?;
    let outside = tempdir()?;
    let requested_dir = root.path().join("project");
    let moved_dir = root.path().join("project-real");
    fs::create_dir_all(&requested_dir)?;
    let canonical_dir = fs::canonicalize(&requested_dir)?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    fs::rename(&requested_dir, &moved_dir)?;
    unix_fs::symlink(outside.path(), &requested_dir)?;

    let result = anchor.with_locked_child_file::<_, io::Error, _>(
        "project directory",
        "annotation file",
        "annotations.jsonl",
        ExactChildFileOpenOptions::exclusive_read_write_create_if_missing(),
        |file| {
            file.write_all(b"mutated\n")?;
            Ok(())
        },
    );

    assert!(
        result.is_err(),
        "swapped parent directories must fail closed"
    );
    assert!(
        !outside.path().join("annotations.jsonl").exists(),
        "create-if-missing must not create through the swapped parent path"
    );
    Ok(())
}

#[cfg(unix)]
#[test]
fn json_helpers_do_not_write_through_parent_directory_swap() -> io::Result<()> {
    let root = tempdir()?;
    let outside = tempdir()?;
    let requested_dir = root.path().join("project");
    let moved_dir = root.path().join("project-real");
    fs::create_dir_all(&requested_dir)?;
    fs::write(outside.path().join("metadata.json"), "{\"outside\":true}")?;
    let canonical_dir = fs::canonicalize(&requested_dir)?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    fs::rename(&requested_dir, &moved_dir)?;
    unix_fs::symlink(outside.path(), &requested_dir)?;

    let created = anchor.write_json_if_missing_child(
        "project directory",
        "tracking artifact",
        "metadata.json",
        &json!({"inside": true}),
    );
    assert!(
        created.is_err(),
        "json helper must fail closed after a parent swap"
    );
    assert_eq!(
        fs::read_to_string(outside.path().join("metadata.json"))?,
        "{\"outside\":true}"
    );
    Ok(())
}

#[cfg(unix)]
#[test]
fn child_file_rejects_leaf_symlink_swap_before_open_even_if_path_is_restored() -> io::Result<()> {
    let root = tempdir()?;
    let outside = tempdir()?;
    let canonical_dir = fs::canonicalize(root.path())?;
    let child_path = canonical_dir.join("annotations.jsonl");
    let outside_file = outside.path().join("annotations.jsonl");
    fs::write(&child_path, "inside\n")?;
    fs::write(&outside_file, "outside\n")?;
    let anchor = AnchoredDir::open(&canonical_dir)?;

    let open_child = child_path.clone();
    let open_outside = outside_file.clone();
    let _open_guard = super::open_probe::set_before_child_file_open(move |path| {
        if path == open_child {
            fs::remove_file(path)?;
            unix_fs::symlink(&open_outside, path)?;
        }
        Ok(())
    });

    let validate_child = child_path.clone();
    let _validate_guard = super::open_probe::set_before_child_file_validate(move |path| {
        if path == validate_child {
            fs::remove_file(path)?;
            fs::write(path, "inside-restored\n")?;
        }
        Ok(())
    });

    let result = anchor.with_locked_child_file::<_, io::Error, _>(
        "project directory",
        "annotation file",
        "annotations.jsonl",
        ExactChildFileOpenOptions::exclusive_read_write_existing(),
        |file| {
            file.write_all(b"mutated\n")?;
            Ok(())
        },
    );

    assert!(
        result.is_err(),
        "leaf symlink swaps must fail before a writable handle escapes"
    );
    assert_eq!(
        fs::read_to_string(outside_file)?,
        "outside\n",
        "callback must not write through the swapped symlink target"
    );
    Ok(())
}
