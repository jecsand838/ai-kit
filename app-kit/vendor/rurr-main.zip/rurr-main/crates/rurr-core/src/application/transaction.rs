use super::builder::ApplicationError;
use super::state_meta::value_type_name;
use crate::state::State;
use indexmap::IndexMap;
use serde_json::Value;

/// A normalized representation of the values returned by a single-step action.
#[derive(Debug, Clone, PartialEq)]
pub enum SingleStepOutput {
    /// The action returned only an updated [`State`].
    StateOnly(State),
    /// The action returned both a result payload and an updated [`State`].
    ResultAndState(IndexMap<String, Value>, State),
    /// The action returned an unsupported shape that needs to be surfaced as an error.
    Invalid {
        /// Human-readable explanation of why the return shape was rejected.
        message: String,
    },
}

/// An intermediate conversion target for supported single-step action outputs.
#[derive(Debug, Clone, PartialEq)]
pub enum SingleStepOutputCandidate {
    /// A bare [`State`] return value.
    State(State),
    /// A result payload paired with an updated [`State`].
    ResultAndState(Value, State),
    /// An unsupported top-level value.
    InvalidTopLevel(Value),
}

impl From<State> for SingleStepOutputCandidate {
    fn from(value: State) -> Self {
        Self::State(value)
    }
}

impl From<(IndexMap<String, Value>, State)> for SingleStepOutputCandidate {
    fn from(value: (IndexMap<String, Value>, State)) -> Self {
        let (result_map, state) = value;
        let object: serde_json::Map<String, Value> = result_map.into_iter().collect();
        Self::ResultAndState(Value::Object(object), state)
    }
}

impl From<(Value, State)> for SingleStepOutputCandidate {
    fn from(value: (Value, State)) -> Self {
        let (result_value, state) = value;
        Self::ResultAndState(result_value, state)
    }
}

impl From<Value> for SingleStepOutputCandidate {
    fn from(value: Value) -> Self {
        Self::InvalidTopLevel(value)
    }
}

/// Normalizes a user action return value into the single-step runtime representation.
pub fn adjust_single_step_output<T>(output: T, action_name: &str) -> SingleStepOutput
where
    T: Into<SingleStepOutputCandidate>,
{
    match output.into() {
        SingleStepOutputCandidate::State(state) => SingleStepOutput::StateOnly(state),
        SingleStepOutputCandidate::ResultAndState(result_value, state) => match result_value {
            Value::Object(object) => {
                let result = object.into_iter().collect();
                SingleStepOutput::ResultAndState(result, state)
            }
            other => SingleStepOutput::Invalid {
                message: format!(
                    "Action {action_name} returned a non-dict result: {other}. All results must be dictionaries."
                ),
            },
        },
        SingleStepOutputCandidate::InvalidTopLevel(value) => SingleStepOutput::Invalid {
            message: format!(
                "Single step action: {action_name} must return either *just* the newly updated State or a tuple of (result: dict, state: State). Got: {value} of type {} instead, which is not valid.",
                value_type_name(&value)
            ),
        },
    }
}

/// Converts a normalized single-step output into the `(result, state)` pair expected by execution.
pub fn normalize_single_step_output(
    output: SingleStepOutput,
    action_name: &str,
) -> Result<(IndexMap<String, Value>, State), ApplicationError> {
    match output {
        SingleStepOutput::StateOnly(state) => Ok((IndexMap::new(), state)),
        SingleStepOutput::ResultAndState(result, state) => Ok((result, state)),
        SingleStepOutput::Invalid { message } => Err(ApplicationError::InvalidSingleStepOutput {
            action_name: action_name.to_string(),
            message,
        }),
    }
}
