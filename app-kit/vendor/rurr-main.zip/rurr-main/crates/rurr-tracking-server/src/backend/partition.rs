/// Sentinel path segment used for unpartitioned application routes.
pub const NONE_PARTITION_KEY: &str = "__none__";

/// Partition filter requested by a tracking-server API call.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PartitionSelector {
    /// Match partitioned and unpartitioned applications.
    Any,
    /// Match only unpartitioned applications.
    Unpartitioned,
    /// Match one exact partition key.
    Exact(String),
}

impl PartitionSelector {
    pub(crate) fn from_path_segment(raw: &str) -> Self {
        if raw == NONE_PARTITION_KEY {
            Self::Unpartitioned
        } else {
            Self::Exact(raw.to_string())
        }
    }

    pub(crate) fn from_optional_query(raw: Option<&str>) -> Self {
        match raw {
            None => Self::Any,
            Some(raw) => Self::from_path_segment(raw),
        }
    }

    pub(crate) fn as_specific_partition(&self) -> Option<&str> {
        match self {
            Self::Any | Self::Unpartitioned => None,
            Self::Exact(partition_key) => Some(partition_key.as_str()),
        }
    }

    pub(crate) fn matches(&self, partition_key: Option<&str>) -> bool {
        match self {
            Self::Any => true,
            Self::Unpartitioned => partition_key.is_none(),
            Self::Exact(expected) => partition_key == Some(expected.as_str()),
        }
    }
}
