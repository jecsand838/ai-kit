---
name: audit-workspace-for-shims
description: "Use when performing a read-only Rurr workspace or subsystem audit for production hacks, shims, deterministic or synthetic fallbacks, fake non-live tests that lack strict live proof, or strict-live test-output tampering before planning or implementation. Emit `::code-comment` findings plus a ranked deletion summary. Do not use for implementation, ordinary coverage-gap audits, or one-off bug-fix triage."
---

# Audit Workspace for Shims

Use this skill when the user wants a read-only audit of where Rurr still carries invented production behavior, unproven non-live assertions, or strict-live tests that are massaged into a passing shape.

## Quick start

Load, in order:

- `README.md`
- `docs/00_overview.md`
- `docs/03_test_plan.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- the relevant gate scripts, production code, and tests
- the matching Burr source under `tools/burr_oracle/vendor/apache-burr/` when the audited behavior is parity-sensitive

Load these companion skills:

- `$use-rust-best-practices-testing`
- `$rurr-burr-source-parity-walk`

## When to use

Use it when the task:

- asks for a workspace-wide or subsystem-wide audit of hacks, shims, synthetic paths, or deterministic fallbacks
- asks whether a non-live test is fake because it lacks a strict live provider proof
- asks whether a strict live provider test output is being reshaped to satisfy a test
- needs a ranked finding list before planning or implementation starts

## Workflow

1. Inventory the affected production behaviors, gates, and tests by subsystem and proof layer.
2. Identify production hacks, shims, deterministic outputs, synthetic paths, or undocumented fallbacks that survive in the current code.
3. Map each non-live test expectation to a corresponding strict live provider or contract proof and flag every unproven assumption.
4. Inspect strict live provider tests for output tampering, shape-forcing, or hidden normalization that makes invented expectations pass.
5. Separate proven behavior from unproven or synthetic behavior using cited source, tests, gates, docs, and Burr evidence when needed.
6. Emit one `::code-comment` finding per issue with a deletion-oriented explanation and a ranked summary of what should be removed next.

## Output contract

Return:

- the affected behavior or subsystem
- the evidence inspected
- the finding type
- the proof gap, fallback, or tampering shape
- the deletion target
- a ranked priority or severity signal
- a summarized findings list

If no findings remain, state that explicitly and call out any residual uncertainty or missing live proof surfaces.

## Default rules

- Stay read-only and do not present implementation as already complete.
- Prefer cited source, test, gate, and Burr evidence over vague architectural memory.
- Treat non-live tests without strict live proof as fake unless the workspace already contains a hard proving lane.
- Treat strict live output rewriting as a finding even when the underlying provider behavior is otherwise covered.
- Emit `::code-comment` findings only for issues that should be slated for deletion.
- Call out uncertainty explicitly when Rurr and Burr evidence do not line up cleanly.

## Do not use this skill alone when

- the user wants ordinary coverage-gap auditing rather than shim hunting: also use `$audit-workspace-test-coverage`
- the user wants a workspace-level reduction ranking before focusing on shims: also use `$rurr-burr-parity-reduction-audit`
- the user wants the audit findings turned into a concrete delete-first plan or implementation pass: also use `$remove-workspace-shims`
- the user only needs closeout or gate selection after code changes already exist: also use `$rurr-gate-closeout`
