use crate::layout::{STATUS_COMPLETED, STATUS_FAILED};
use crate::{PersistedStateStatus, PersistenceError};
use indexmap::IndexMap;
use serde_json::Value;
use std::time::{SystemTime, SystemTimeError, UNIX_EPOCH};
use time::OffsetDateTime;

/// Normalizes an optional partition key into the stored string representation.
pub fn normalize_partition_key(partition_key: Option<&str>) -> String {
    partition_key.unwrap_or_default().to_string()
}

/// Returns a stable timestamp string used by lightweight in-memory persistence helpers.
pub fn now_timestamp() -> Result<String, PersistenceError> {
    unix_duration(SystemTime::now(), "now_timestamp").map(|since_epoch| {
        format!(
            "{}.{:09}",
            since_epoch.as_secs(),
            since_epoch.subsec_nanos()
        )
    })
}

/// Formats a UTC timestamp as a fixed-width RFC3339 string that sorts lexically.
pub fn sortable_rfc3339_utc_string(timestamp: SystemTime) -> Result<String, PersistenceError> {
    unix_duration(timestamp, "sortable_rfc3339_utc_string")?;
    let datetime = OffsetDateTime::from(timestamp);

    Ok(format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:09}Z",
        datetime.year(),
        u8::from(datetime.month()),
        datetime.day(),
        datetime.hour(),
        datetime.minute(),
        datetime.second(),
        datetime.nanosecond()
    ))
}

fn unix_duration(
    timestamp: SystemTime,
    operation: &'static str,
) -> Result<std::time::Duration, PersistenceError> {
    timestamp
        .duration_since(UNIX_EPOCH)
        .map_err(|error| timestamp_error(operation, error))
}

fn timestamp_error(operation: &'static str, error: SystemTimeError) -> PersistenceError {
    PersistenceError::InvalidTimestamp {
        operation,
        message: format!("timestamp is before UNIX_EPOCH by {:?}", error.duration()),
    }
}

/// Converts a persisted status enum into its stored string representation.
pub fn persisted_status_as_str(status: PersistedStateStatus) -> &'static str {
    match status {
        PersistedStateStatus::Completed => STATUS_COMPLETED,
        PersistedStateStatus::Failed => STATUS_FAILED,
    }
}

/// Parses a stored status string into a [`PersistedStateStatus`].
pub fn persisted_status_from_str(
    status: &str,
    operation: &'static str,
) -> Result<PersistedStateStatus, PersistenceError> {
    match status {
        STATUS_COMPLETED => Ok(PersistedStateStatus::Completed),
        STATUS_FAILED => Ok(PersistedStateStatus::Failed),
        _ => Err(PersistenceError::UnsupportedOperation { operation }),
    }
}

/// Serializes an application state payload into JSON.
pub fn serialize_state_json(
    state: &IndexMap<String, Value>,
    operation: &'static str,
) -> Result<String, PersistenceError> {
    serde_json::to_string(state).map_err(|_| PersistenceError::UnsupportedOperation { operation })
}

/// Deserializes an application state payload from JSON.
pub fn deserialize_state_json(
    state_json: &str,
    operation: &'static str,
) -> Result<IndexMap<String, Value>, PersistenceError> {
    serde_json::from_str(state_json)
        .map_err(|_| PersistenceError::UnsupportedOperation { operation })
}

#[cfg(test)]
mod tests {
    use super::sortable_rfc3339_utc_string;
    use crate::PersistenceError;
    use std::time::{Duration, UNIX_EPOCH};

    #[test]
    fn sortable_rfc3339_utc_string_uses_fixed_width_nanoseconds() {
        let timestamp = UNIX_EPOCH + Duration::new(0, 123_456_789);

        assert_eq!(
            sortable_rfc3339_utc_string(timestamp).expect("valid timestamp should format"),
            "1970-01-01T00:00:00.123456789Z"
        );
    }

    #[test]
    fn sortable_rfc3339_utc_string_orders_lexically_within_the_same_millisecond() {
        let earlier = UNIX_EPOCH + Duration::new(1, 123_456_700);
        let later = UNIX_EPOCH + Duration::new(1, 123_456_900);

        assert!(
            sortable_rfc3339_utc_string(earlier).expect("earlier timestamp should format")
                < sortable_rfc3339_utc_string(later).expect("later timestamp should format"),
            "fixed-width RFC3339 strings must preserve chronological ordering even below 1 ms"
        );
    }

    #[test]
    fn sortable_rfc3339_utc_string_rejects_pre_epoch_timestamp() {
        let timestamp = UNIX_EPOCH - Duration::from_nanos(1);

        let error =
            sortable_rfc3339_utc_string(timestamp).expect_err("pre-epoch timestamp should fail");

        assert!(
            matches!(
                error,
                PersistenceError::InvalidTimestamp {
                    operation: "sortable_rfc3339_utc_string",
                    ..
                }
            ),
            "pre-epoch timestamps must fail explicitly instead of being clamped, got {error:?}"
        );
    }
}
