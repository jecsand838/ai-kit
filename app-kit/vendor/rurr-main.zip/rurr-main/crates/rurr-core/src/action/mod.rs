//! Action traits, builders, built-in actions, and streaming result containers.
//!
//! Most end users start with [`FunctionActionBuilder`] for closure-backed
//! actions, then compose them with [`Condition`], [`InputAction`], or
//! [`ResultAction`]. User actions implement [`LocalAction`], while graphs and
//! sessions dispatch through the object-safe [`ErasedAction`] runtime layer.

pub(crate) mod api;
mod builtin;
pub(crate) mod condition;
mod function;
#[doc(hidden)]
pub mod macro_support;
mod streaming;

pub use api::{
    boxed_local_async_stream, boxed_send_async_stream, is_reserved_runtime_input, Action,
    ActionContext, ActionError, ActionInputs, ActionKind, ActionResult, ActionTracer, ErasedAction,
    LocalAction, LocalAsyncStreamOutput, RurrError, SendAsyncStreamOutput, StreamItem,
    StreamOutput,
};
pub use builtin::{InputAction, ResultAction};
pub use condition::{Condition, ConditionError, ConditionOperator, ConditionRule};
pub use function::{
    FunctionAction, FunctionActionBuilder, FunctionActionUpdateFn, FunctionActionUpdatePolicy,
};
pub use streaming::{AsyncStreamingResultContainer, StreamingResultContainer};
