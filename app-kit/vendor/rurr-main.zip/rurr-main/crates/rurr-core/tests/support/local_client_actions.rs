use futures::stream;
use rurr_core::action::{
    ActionError, ActionKind, ActionResult, FunctionAction, RurrError, StreamOutput,
};
use rurr_core::state::State;
use rurr_testkit::action_fixture::{scripted_action, ScriptedActionSpec};
use rurr_testkit::action_metadata::NamedActionMetadata;
use serde_json::json;

fn count_action_metadata() -> NamedActionMetadata {
    NamedActionMetadata::from_slices(&[], &["count"], &[])
}

fn unsupported_sync_streaming_run() -> Result<ActionResult, ActionError> {
    Err(ActionError::UnsupportedOperation {
        message: "sync run is not used for this action".to_string(),
    })
}

fn count_update(value: i64) -> indexmap::IndexMap<String, serde_json::Value> {
    rurr_testkit::application_fixture::map_from_pairs([("count", json!(value))])
}

fn scripted_stream_outputs(state: State, script: &StreamingScript) -> Vec<StreamOutput> {
    match script {
        StreamingScript::TwoStepCommit => {
            let first = count_update(1);
            let second = count_update(2);
            let final_state = state
                .update(count_update(2))
                .expect("stream terminal state update should succeed");
            vec![Ok((first, None)), Ok((second, Some(final_state)))]
        }
        StreamingScript::TerminalOnly { terminal_count } => {
            let terminal = count_update(*terminal_count);
            let final_state = state
                .update(count_update(*terminal_count))
                .expect("stream terminal state update should succeed");
            vec![Ok((terminal, Some(final_state)))]
        }
        StreamingScript::ErrorAfterIntermediate { error_message } => {
            let first = count_update(1);
            vec![
                Ok((first, None)),
                Err(RurrError::Message((*error_message).to_string())),
            ]
        }
    }
}

pub(crate) fn broken_action() -> FunctionAction {
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|_state, _ctx| {
            Err(ActionError::Internal {
                message: "Broken".to_string(),
            })
        })
        .with_source_code(
            "fn broken_action(_state, _ctx) { Err(ActionError::Internal { message: \"Broken\".to_string() }) }",
        ),
    )
}

#[derive(Debug, Clone)]
pub(crate) enum StreamingScript {
    TwoStepCommit,
    TerminalOnly { terminal_count: i64 },
    ErrorAfterIntermediate { error_message: &'static str },
}

#[derive(Debug, Clone, Copy)]
pub(crate) enum StreamingLane {
    Sync,
    Async,
}

pub(crate) fn streaming_action(script: StreamingScript, lane: StreamingLane) -> FunctionAction {
    let source = match lane {
        StreamingLane::Sync => {
            "fn sync_streaming_action_fixture(state) { scripted_stream_outputs(state, &script) }"
        }
        StreamingLane::Async => {
            "async fn async_streaming_action_fixture(state) { scripted_stream_outputs(state, &script) }"
        }
    };
    let kind = match lane {
        StreamingLane::Sync => ActionKind::Sync,
        StreamingLane::Async => ActionKind::Async,
    };
    scripted_action(
        count_action_metadata(),
        ScriptedActionSpec::from_run(|_state, _ctx| unsupported_sync_streaming_run())
            .with_kind(kind)
            .with_source_code(source)
            .with_streams(
                {
                    let script = script.clone();
                    move |state, _ctx| Box::new(scripted_stream_outputs(state, &script).into_iter())
                },
                move |state, _ctx| Box::pin(stream::iter(scripted_stream_outputs(state, &script))),
            ),
    )
}
