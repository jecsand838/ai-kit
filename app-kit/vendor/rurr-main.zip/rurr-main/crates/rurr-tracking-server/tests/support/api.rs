use axum::Router;
use rurr_core::tracking::LocalTrackingClient;
use rurr_core::{
    ApplicationBuilder, FunctionActionBuilder, State, Tracker, TrackerSpec, Transition,
};
use rurr_testkit::application_fixture::map_from_pairs;
use rurr_testkit::tracking_fixture::append_truncated_app_log_line;
use rurr_testkit::tracking_fixture::artifacts::write_jsonl;
use rurr_tracking_server::backend::local::LocalBackend;
use rurr_tracking_server::router::AppState;
use std::fs;
use std::path::Path;
use std::sync::Arc;
use tempfile::TempDir;

#[cfg(unix)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum AnnotationFilesystemMutation {
    SymlinkEscape,
    CrossProjectAlias,
    ParentProjectSwap,
}

pub(crate) fn build_single_app_fixture(
    root: &Path,
    project_id: &str,
    app_id: &str,
    partition_key: Option<&str>,
) {
    run_tracked_noop_app(root, project_id, app_id, partition_key);
}

pub(crate) fn build_fixture(root: &Path) {
    run_tracked_noop_app(root, "proj1", "app1", Some("pk"));
    register_noop_app(root, "proj1", "app2", Some("other"));
}

pub(crate) fn build_fixture_with_truncated_trailing_log_line(root: &Path) {
    build_fixture(root);
    append_truncated_app_log_line(
        root,
        "proj1",
        "app1",
        br#"{"type":"end_entry","action":"broken""#,
    );
}

pub(crate) fn local_backend_app(root: &Path) -> Router {
    rurr_tracking_server::app_with_state(AppState::with_embedded_ui(Arc::new(
        LocalBackend::new(root).expect("local backend should build"),
    )))
}

pub(crate) fn local_backend_tempdir_app(setup: impl FnOnce(&Path)) -> (TempDir, Router) {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    setup(tempdir.path());
    let app = local_backend_app(tempdir.path());
    (tempdir, app)
}

pub(crate) fn fixture_app(root: &Path) -> Router {
    build_fixture(root);
    local_backend_app(root)
}

pub(crate) fn fixture_tempdir_app() -> (TempDir, Router) {
    local_backend_tempdir_app(build_fixture)
}

pub(crate) fn single_app_fixture_app(
    root: &Path,
    project_id: &str,
    app_id: &str,
    partition_key: Option<&str>,
) -> Router {
    build_single_app_fixture(root, project_id, app_id, partition_key);
    local_backend_app(root)
}

pub(crate) fn single_app_tempdir_app(
    project_id: &str,
    app_id: &str,
    partition_key: Option<&str>,
) -> (TempDir, Router) {
    local_backend_tempdir_app(|root| {
        build_single_app_fixture(root, project_id, app_id, partition_key)
    })
}

pub(crate) fn truncated_log_tempdir_app() -> (TempDir, Router) {
    local_backend_tempdir_app(build_fixture_with_truncated_trailing_log_line)
}

#[cfg(unix)]
#[allow(clippy::await_holding_lock)]
pub(crate) async fn assert_annotation_filesystem_mutation_rejected(
    kind: crate::support::api_helpers::AnnotationRequestKind,
    mutation: AnnotationFilesystemMutation,
) {
    use crate::support::api_helpers::{
        annotation_out_json, assert_rejected_annotation_request, default_annotation_path,
        default_annotation_request, DEFAULT_ANNOTATION_ID, DEFAULT_APP_ID, DEFAULT_PARTITION_KEY,
        DEFAULT_PROJECT_ID, DEFAULT_STEP_SEQUENCE_ID,
    };
    use std::os::unix::fs as unix_fs;

    match mutation {
        AnnotationFilesystemMutation::SymlinkEscape => {
            let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            build_single_app_fixture(
                storage_dir.path(),
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );

            let outside_annotations_path = outside_dir.path().join("annotations.jsonl");
            write_jsonl(
                &outside_annotations_path,
                &[annotation_out_json(
                    DEFAULT_ANNOTATION_ID,
                    DEFAULT_PROJECT_ID,
                    DEFAULT_APP_ID,
                    Some(DEFAULT_PARTITION_KEY),
                    DEFAULT_STEP_SEQUENCE_ID,
                    "outside",
                )],
            );
            unix_fs::symlink(
                &outside_annotations_path,
                default_annotation_path(storage_dir.path()),
            )
            .expect("annotation symlink should be created");
            let app = local_backend_app(storage_dir.path());
            let response = default_annotation_request(&app, kind).await;
            assert_rejected_annotation_request(
                kind,
                response,
                Some(&outside_annotations_path),
                "outside",
            )
            .await;
        }
        AnnotationFilesystemMutation::CrossProjectAlias => {
            let storage_dir = tempfile::tempdir().expect("storage tempdir should be created");
            build_single_app_fixture(
                storage_dir.path(),
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );
            build_single_app_fixture(
                storage_dir.path(),
                "proj_b",
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );

            let shared_annotations_path =
                storage_dir.path().join("proj_b").join("annotations.jsonl");
            write_jsonl(
                &shared_annotations_path,
                &[annotation_out_json(
                    DEFAULT_ANNOTATION_ID,
                    "proj_b",
                    DEFAULT_APP_ID,
                    Some(DEFAULT_PARTITION_KEY),
                    DEFAULT_STEP_SEQUENCE_ID,
                    "seed",
                )],
            );
            unix_fs::symlink(
                &shared_annotations_path,
                default_annotation_path(storage_dir.path()),
            )
            .expect("annotation alias should be created");
            let app = local_backend_app(storage_dir.path());
            let response = default_annotation_request(&app, kind).await;
            assert_rejected_annotation_request(
                kind,
                response,
                Some(&shared_annotations_path),
                "seed",
            )
            .await;
        }
        AnnotationFilesystemMutation::ParentProjectSwap => {
            let (storage_dir, app) = single_app_tempdir_app(
                DEFAULT_PROJECT_ID,
                DEFAULT_APP_ID,
                Some(DEFAULT_PARTITION_KEY),
            );
            let outside_dir = tempfile::tempdir().expect("outside tempdir should be created");
            let moved_project_dir = storage_dir
                .path()
                .join(format!("{DEFAULT_PROJECT_ID}-real"));
            let outside_annotations_path = outside_dir.path().join("annotations.jsonl");
            let outside_marker = "outside-parent-swap";
            write_jsonl(
                &outside_annotations_path,
                &[annotation_out_json(
                    DEFAULT_ANNOTATION_ID,
                    DEFAULT_PROJECT_ID,
                    DEFAULT_APP_ID,
                    Some(DEFAULT_PARTITION_KEY),
                    DEFAULT_STEP_SEQUENCE_ID,
                    outside_marker,
                )],
            );

            fs::rename(
                storage_dir.path().join(DEFAULT_PROJECT_ID),
                &moved_project_dir,
            )
            .expect("project dir should move out of the original path");
            unix_fs::symlink(
                outside_dir.path(),
                storage_dir.path().join(DEFAULT_PROJECT_ID),
            )
            .expect("project symlink replacement should be created");
            let response = default_annotation_request(&app, kind).await;
            assert_rejected_annotation_request(
                kind,
                response,
                Some(&outside_annotations_path),
                outside_marker,
            )
            .await;
        }
    }
}

const _: () = {
    #[cfg(unix)]
    let _ = AnnotationFilesystemMutation::SymlinkEscape;
    #[cfg(unix)]
    let _ = AnnotationFilesystemMutation::CrossProjectAlias;
    #[cfg(unix)]
    let _ = AnnotationFilesystemMutation::ParentProjectSwap;
    #[cfg(unix)]
    let _ = assert_annotation_filesystem_mutation_rejected;
};

fn noop_action() -> rurr_core::FunctionAction {
    FunctionActionBuilder::new()
        .writes(["count"])
        .with_source_code("fn noop(state, _ctx) -> count { state[\"count\"] + 1 }")
        .build_sync(|state, _ctx| {
            let next = state
                .get("count")
                .and_then(serde_json::Value::as_i64)
                .unwrap_or(0)
                + 1;
            map_from_pairs([("count", serde_json::json!(next))])
        })
        .expect("noop tracking action should build")
}

fn build_noop_app(
    app_id: &str,
    partition_key: Option<&str>,
    tracker: Option<Arc<dyn Tracker>>,
) -> rurr_core::Application {
    let mut builder = ApplicationBuilder::new()
        .with_state(State::default())
        .expect("state should configure")
        .with_actions(vec![("noop", noop_action())])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("noop")
        .expect("entrypoint should configure")
        .with_identifiers(app_id, partition_key.map(str::to_string), None)
        .expect("identifiers should configure");
    if let Some(tracker) = tracker {
        builder = builder
            .with_tracker(TrackerSpec::provided(tracker))
            .expect("tracker should configure");
    }
    builder.build().expect("application should build")
}

fn register_noop_app(root: &Path, project_id: &str, app_id: &str, partition_key: Option<&str>) {
    let tracker =
        LocalTrackingClient::new(project_id, root).expect("tracking client should initialize");
    let app = build_noop_app(app_id, partition_key, None);
    tracker
        .register_application(app_id, partition_key, app.graph(), None, None)
        .expect("registration should succeed");
}

fn run_tracked_noop_app(root: &Path, project_id: &str, app_id: &str, partition_key: Option<&str>) {
    let tracker = Arc::new(
        LocalTrackingClient::new(project_id, root).expect("tracking client should initialize"),
    );
    let tracker_trait: Arc<dyn Tracker> = tracker.clone();
    let mut app = build_noop_app(app_id, partition_key, Some(tracker_trait));
    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("registration should succeed");
    app.step(None).expect("step should succeed");
}
