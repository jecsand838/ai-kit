use super::app_error_to_action_error;
use crate::action::api::{ActionError, LocalAction};
use crate::action::FunctionActionBuilder;
use crate::application::builder::ApplicationError;
use crate::application::resources::RuntimeResources;
use crate::graph::{GraphAction, Transition};
use crate::lifecycle::LifecycleAdapterSet;
use crate::parallelism::{
    executor::{execute_tasks_async, execute_tasks_sync, ParallelRuntimeContext},
    runtime::child_instance_app_id,
    types::SubGraphTask,
    RunnableGraph,
};
use crate::state::{State, StateError};
use indexmap::IndexMap;
use serde_json::{json, Value};

fn runnable_graph_with_sync_app_id_capture(name: &str) -> RunnableGraph {
    let action = FunctionActionBuilder::new()
        .writes(["seen_app_id"])
        .build_sync(|_state, ctx| {
            let app_id = ctx
                .app_context
                .as_ref()
                .map(|context| context.app_id.clone())
                .expect("application context should be present in child");
            IndexMap::from([("seen_app_id".to_string(), json!(app_id))])
        })
        .expect("action should build")
        .with_name(name)
        .expect("action naming should succeed");
    let graph_action = GraphAction::new(action).expect("graph action should build");
    RunnableGraph::new(
        vec![graph_action],
        Vec::<Transition>::new(),
        Some(name.to_string()),
    )
}

fn runnable_graph_with_async_app_id_capture(name: &str) -> RunnableGraph {
    let action = FunctionActionBuilder::new()
        .writes(["seen_app_id"])
        .build_async(|_state, ctx| async move {
            let app_id = ctx
                .app_context
                .as_ref()
                .map(|context| context.app_id.clone())
                .expect("application context should be present in child");
            IndexMap::from([("seen_app_id".to_string(), json!(app_id))])
        })
        .expect("action should build")
        .with_name(name)
        .expect("action naming should succeed");
    let graph_action = GraphAction::new(action).expect("graph action should build");
    RunnableGraph::new(
        vec![graph_action],
        Vec::<Transition>::new(),
        Some(name.to_string()),
    )
}

fn seen_app_ids(states: &[State]) -> Vec<String> {
    states
        .iter()
        .map(|state| {
            state
                .get("seen_app_id")
                .and_then(Value::as_str)
                .expect("seen_app_id should exist")
                .to_string()
        })
        .collect()
}

#[test]
fn run_parallel_sync_preserves_task_order() {
    let task_graph = runnable_graph_with_sync_app_id_capture("capture");
    let tasks = vec![
        SubGraphTask::new(task_graph.clone(), State::default(), "alpha"),
        SubGraphTask::new(task_graph, State::default(), "beta"),
    ];

    let states = execute_tasks_sync(
        tasks,
        &ParallelRuntimeContext::new(
            "parent-app".to_string(),
            Some("pk".to_string()),
            17,
            RuntimeResources::new(LifecycleAdapterSet::default()),
        ),
        false,
    )
    .expect("parallel sync should succeed");

    assert_eq!(
        seen_app_ids(&states),
        vec![
            child_instance_app_id("parent-app", "alpha"),
            child_instance_app_id("parent-app", "beta"),
        ]
    );
}

#[tokio::test]
async fn run_parallel_async_preserves_task_order() {
    let task_graph = runnable_graph_with_async_app_id_capture("capture_async");
    let tasks = vec![
        SubGraphTask::new(task_graph.clone(), State::default(), "alpha"),
        SubGraphTask::new(task_graph, State::default(), "beta"),
    ];

    let states = execute_tasks_async(
        tasks,
        &ParallelRuntimeContext::new(
            "parent-app".to_string(),
            Some("pk".to_string()),
            17,
            RuntimeResources::new(LifecycleAdapterSet::default()),
        ),
        false,
    )
    .await
    .expect("parallel async should succeed");

    assert_eq!(
        seen_app_ids(&states),
        vec![
            child_instance_app_id("parent-app", "alpha"),
            child_instance_app_id("parent-app", "beta"),
        ]
    );
}

#[test]
fn app_error_to_action_error_preserves_action_variant() {
    let source = ActionError::RuntimeContextUnavailable {
        message: "missing context".to_string(),
    };

    let mapped = app_error_to_action_error(ApplicationError::Action(source.clone()));

    assert_eq!(mapped, source);
}

#[test]
fn app_error_to_action_error_preserves_state_variant() {
    let mapped = app_error_to_action_error(ApplicationError::State(StateError::TypingSystem {
        phase: "validate_post_action",
        message: "typed failure".to_string(),
    }));

    assert!(matches!(
        mapped,
        ActionError::State(StateError::TypingSystem { phase, message })
        if phase == "validate_post_action" && message == "typed failure"
    ));
}

#[test]
fn app_error_to_action_error_wraps_non_action_errors_as_internal() {
    let mapped = app_error_to_action_error(ApplicationError::InternalInvariant {
        message: "parallel mismatch",
    });

    assert!(matches!(
        mapped,
        ActionError::Internal { message }
        if message == "invalid internal state: parallel mismatch"
    ));
}
