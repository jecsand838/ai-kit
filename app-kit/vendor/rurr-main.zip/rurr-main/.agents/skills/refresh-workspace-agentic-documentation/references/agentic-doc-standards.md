# Agentic Documentation Standards

Use these standards to keep document roles distinct and easy to route.

## Audience split

- `README.md`: explain what the project is, why it exists, how to get started, and where deeper docs live.
- `AGENTS.md` and `AGENTS.override.md`: explain agent and operator workflow, precedence, guardrails, commands, and restart requirements after instruction changes.
- `ARCHITECTURE.md`: explain the current system layout, boundaries, execution flow, integrations, and terminology.
- historical Markdown: preserve historical context, but mark archive status clearly and point readers back to the living docs.

## Current-state writing rules

- Prefer present-tense descriptions only for active behavior that still exists on the current branch.
- Remove or rewrite references to deleted concepts, obsolete file paths, or superseded workflow names.
- Link outward instead of duplicating full procedures across multiple living docs.
- Keep operator-only details out of human-facing overviews unless they are required for setup.

## AGENTS-specific rules

- State instruction hierarchy clearly: root guidance first, then nearer overrides, then repo-local config.
- Mention restart requirements whenever `AGENTS*.md` changes alter the instruction chain.
- Keep workflow and verification commands concrete and current.
- Use subtree overrides only for stricter local guidance, not for duplicate root content.

## ARCHITECTURE-specific rules

- Describe the current execution stack and public mental model, not the historical scaffolding.
- Explain how subsystems connect, where data flows, and which docs define guardrails or compatibility contracts.
- Keep historical remediation material out of the main architecture narrative unless it explains a still-relevant constraint.

## README-specific rules

- Stay concise and human-oriented.
- Link to architecture, compatibility, operator, and deeper implementation docs instead of absorbing them.
- Keep quick-start commands accurate for the current branch.
