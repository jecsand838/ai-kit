use super::*;
use super::{actions::*, builders::*, cases::*, hooks::*};
use std::future::poll_fn;
use std::task::Poll;

sync_stream_cases! {
    stream_iterate_error_boundary_surfaces_sync_post_execute_call_failure =>
        assert_iterate_error_boundary_surfaces_post_execute_call_failure(StreamMode::Sync),
    stream_iterate_next_item_error_closes_session_immediately =>
        assert_iterate_next_item_error_closes_session_immediately(StreamMode::Sync),
    stream_iterate_get_error_closes_session_immediately =>
        assert_iterate_get_error_closes_session_immediately(StreamMode::Sync)
}
async_stream_cases! {
    astream_iterate_error_boundary_surfaces_async_post_execute_call_failure =>
        assert_iterate_error_boundary_surfaces_post_execute_call_failure(StreamMode::Async),
    astream_iterate_next_item_error_closes_session_immediately =>
        assert_iterate_next_item_error_closes_session_immediately(StreamMode::Async),
    astream_iterate_get_error_closes_session_immediately =>
        assert_iterate_get_error_closes_session_immediately(StreamMode::Async),
    astream_iterate_non_streaming_run_async_error_runs_async_post_step_once =>
        assert_astream_iterate_non_streaming_failure_runs_post_step_once(AsyncNonStreamingFailureKind::Run)
}

#[tokio::test]
async fn astream_result_parallel_map_states_executes_async_path() {
    let mut app = build_map_states_async_child_app().expect("app should build");

    let (_action, mut stream_result) = app
        .astream_result_with_options(
            rurr_core::ExecutionOptions::new().halt_after(["parallel".to_string()]),
        )
        .await
        .expect("astream_result should create");

    assert!(stream_result
        .next_item()
        .await
        .expect("next_item should succeed")
        .is_none());

    let (terminal, state) = stream_result.get().await.expect("get should succeed");
    assert_eq!(terminal, Some(IndexMap::new()));
    assert_eq!(state.get("count").cloned(), Some(json!(0)));
}

async_stream_case!(
    astream_iterate_non_streaming_update_error_runs_async_post_step_once =>
        assert_astream_iterate_non_streaming_failure_runs_post_step_once(AsyncNonStreamingFailureKind::Update)
);

sync_stream_cases! {
    stream_iterate_commit_failure_records_post_step_exception_and_rolls_back =>
        assert_iterate_commit_failure_records_post_step_exception_and_rolls_back(StreamMode::Sync),
    stream_iterate_abort_closes_session_immediately =>
        assert_iterate_abort_closes_session_immediately(StreamMode::Sync)
}
async_stream_cases! {
    astream_iterate_commit_failure_records_post_step_exception_and_rolls_back =>
        assert_iterate_commit_failure_records_post_step_exception_and_rolls_back(StreamMode::Async),
    astream_iterate_abort_closes_session_and_runs_async_post_execute_call_once =>
        assert_iterate_abort_closes_session_immediately(StreamMode::Async)
}

#[tokio::test]
async fn astream_iterate_abort_is_idempotent() {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(stream_calls, 3, None);
    let mut app =
        build_streaming_app_with_hooks(action, counting_hooks(&counts)).expect("app should build");

    let mut iterate = app.astream_iterate().await;
    iterate
        .abort()
        .await
        .expect("first abort should close session");
    iterate
        .abort()
        .await
        .expect("second abort should be idempotent");

    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 1);
    assert!(iterate
        .next_step()
        .await
        .expect("aborted async stream iterate session should be terminal")
        .is_none());
}

async_stream_cases! {
    astream_iterate_drop_without_abort_runs_sync_post_execute_call_only =>
        assert_astream_drop_without_abort_runs_sync_post_execute_call_only(AsyncDropWithoutAbortTarget::Iterate),
    astream_result_drop_without_abort_runs_sync_post_execute_call_only =>
        assert_astream_drop_without_abort_runs_sync_post_execute_call_only(AsyncDropWithoutAbortTarget::Result)
}

#[test]
fn stream_iterate_drop_during_unwind_panicking_post_execute_hook_does_not_abort_process() {
    run_subprocess_fixture(
        "contract::application_streaming_contract::error_and_abort_paths::stream_iterate_drop_during_unwind_panicking_post_execute_hook_fixture",
    );
}

#[test]
fn stream_result_drop_during_unwind_panicking_post_execute_hook_does_not_abort_process() {
    run_subprocess_fixture(
        "contract::application_streaming_contract::error_and_abort_paths::stream_result_drop_during_unwind_panicking_post_execute_hook_fixture",
    );
}

#[test]
fn stream_step_handle_drop_during_unwind_panicking_post_step_or_stream_hook_does_not_abort_process()
{
    run_subprocess_fixture(
        "contract::application_streaming_contract::error_and_abort_paths::stream_step_handle_drop_during_unwind_panicking_post_step_or_stream_hook_fixture",
    );
}

#[test]
fn stream_iterate_drop_during_unwind_panicking_post_execute_hook_fixture() {
    if !subprocess_fixture_enabled() {
        return;
    }

    let hook_state = Arc::new(PanickingPostExecuteState::default());
    let hooks = LifecycleAdapterSet::new(
        vec![Arc::new(PanickingPostExecuteCallHook::new(Arc::clone(
            &hook_state,
        )))],
        Vec::new(),
    );
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(stream_calls, 3, None);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");

    let panic_result = std::panic::catch_unwind(AssertUnwindSafe(|| {
        let _iterate = app.stream_iterate();
        panic!("intentional outer panic while stream_iterate session is alive");
    }));

    assert!(panic_result.is_err(), "outer panic should be catchable");
    assert_eq!(hook_state.post_execute_call.load(Ordering::SeqCst), 1);
}

#[test]
fn stream_result_drop_during_unwind_panicking_post_execute_hook_fixture() {
    if !subprocess_fixture_enabled() {
        return;
    }

    let hook_state = Arc::new(PanickingPostExecuteState::default());
    let hooks = LifecycleAdapterSet::new(
        vec![Arc::new(PanickingPostExecuteCallHook::new(Arc::clone(
            &hook_state,
        )))],
        Vec::new(),
    );
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(stream_calls, 3, None);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");
    let halt_after = vec!["stream".to_string()];

    let panic_result = std::panic::catch_unwind(AssertUnwindSafe(|| {
        let (_action, _stream_result) = app
            .stream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
            .expect("stream_result should create");
        panic!("intentional outer panic while stream_result session is alive");
    }));

    assert!(panic_result.is_err(), "outer panic should be catchable");
    assert_eq!(hook_state.post_execute_call.load(Ordering::SeqCst), 1);
}

#[test]
fn stream_step_handle_drop_during_unwind_panicking_post_step_or_stream_hook_fixture() {
    if !subprocess_fixture_enabled() {
        return;
    }

    let hook_state = Arc::new(PanickingPostStepState::default());
    let hooks = LifecycleAdapterSet::new(
        vec![Arc::new(PanickingPostStepHook::new(Arc::clone(
            &hook_state,
        )))],
        Vec::new(),
    );
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(stream_calls, 3, None);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");

    let panic_result = std::panic::catch_unwind(AssertUnwindSafe(|| {
        let mut iterate = app.stream_iterate();
        let (_action, mut handle) = iterate
            .next_step()
            .expect("next_step should succeed")
            .expect("step should exist");
        let _first = handle
            .next_item()
            .expect("first next_item should succeed")
            .expect("first stream item should exist");
        panic!("intentional outer panic while stream step handle is alive");
    }));

    assert!(panic_result.is_err(), "outer panic should be catchable");
    assert_eq!(hook_state.post_run_step.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn astream_step_handle_drop_mid_stream_runs_sync_post_step_and_stream_only() {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let action = streaming_count_action(stream_calls, 3, None);
    let mut app =
        build_streaming_app_with_hooks(action, counting_hooks(&counts)).expect("app should build");

    let mut iterate = app.astream_iterate().await;
    let (_action, mut handle) = iterate
        .next_step()
        .await
        .expect("next_step should succeed")
        .expect("step should exist");
    let first = handle
        .next_item()
        .await
        .expect("first next_item should succeed")
        .expect("first stream item should exist");
    assert_eq!(first.get("count"), Some(&json!(1)));

    drop(handle);

    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_end_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_run_step.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_end_stream.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 0);

    iterate.abort().await.expect("abort should close session");
    drop(iterate);

    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

sync_stream_case!(
    stream_result_accepts_non_send_sync_stream_sources =>
        assert_result_accepts_non_send_stream_sources(StreamMode::Sync)
);
async_stream_case!(
    astream_result_accepts_non_send_async_stream_sources =>
        assert_result_accepts_non_send_stream_sources(StreamMode::Async)
);

#[tokio::test]
async fn astream_result_abort_cancels_inflight_pending_poll_without_hanging() {
    let pending_polls = Arc::new(AtomicUsize::new(0));
    let action = never_ready_async_stream_action(Arc::clone(&pending_polls));
    let mut app = build_streaming_app(action).expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = app
        .astream_result_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("astream_result should create");

    {
        let next_future = stream_result.next();
        tokio::pin!(next_future);
        poll_fn(
            |cx| match std::future::Future::poll(next_future.as_mut(), cx) {
                Poll::Pending => Poll::Ready(()),
                Poll::Ready(output) => {
                    panic!("never-ready stream unexpectedly produced output: {output:?}")
                }
            },
        )
        .await;
    }

    assert!(
        pending_polls.load(Ordering::SeqCst) > 0,
        "pending path should have been polled at least once"
    );

    tokio::time::timeout(Duration::from_millis(100), stream_result.abort())
        .await
        .expect("abort should not block on unresolved pending stream poll")
        .expect("abort should succeed");
    drop(stream_result);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

async_stream_case!(
    astream_result_abort_after_cancelled_poll_runs_async_post_hooks_once =>
        assert_astream_result_cleanup_after_pending_poll_runs_expected_hooks(AsyncPendingPollCleanup::Abort)
);
async_stream_case!(
    astream_result_drop_after_pending_poll_runs_sync_post_execute_only =>
        assert_astream_result_cleanup_after_pending_poll_runs_expected_hooks(AsyncPendingPollCleanup::Drop)
);
