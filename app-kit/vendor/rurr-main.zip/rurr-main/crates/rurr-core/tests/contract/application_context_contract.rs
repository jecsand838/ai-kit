use super::support::application::{
    fixed_sync_initializer as sync_initializer_with, initialize_from_spec,
    persisted_state_fixture_with as persisted_state, ApplicationScenario,
};
use indexmap::IndexMap;
use rurr_core::action::{
    ActionContext, ActionInputs, ActionTracer, FunctionAction, FunctionActionBuilder,
};
use rurr_core::application::{ApplicationBuilder, ApplicationContext as Ctx, ParentPointer};
use rurr_core::graph::Transition;
use rurr_core::state::State;
use rurr_persistence::{BaseStateLoader, PersistedStateStatus};
use serde_json::json;
use std::sync::Arc;

fn sample_context(app_id: &str) -> Ctx {
    Ctx {
        app_id: app_id.to_string(),
        partition_key: Some("tenant-7".to_string()),
        sequence_id: Some(22),
        prior_step: Some("prepare".to_string()),
        parent_pointer: Some(ParentPointer {
            app_id: "parent-app".to_string(),
            partition_key: Some("parent-partition".to_string()),
            sequence_id: Some(3),
        }),
        spawning_parent_pointer: Some(ParentPointer {
            app_id: "spawn-app".to_string(),
            partition_key: Some("spawn-partition".to_string()),
            sequence_id: Some(8),
        }),
    }
}

fn build_single_step_app(action_name: &str, action: FunctionAction) -> rurr_core::Application {
    ApplicationScenario::single_action(State::default(), action_name, action)
        .expect("fixture should build")
        .into_fixture()
        .with_identifiers("app-context-test", Some("pk".to_string()), None)
        .expect("identifiers should configure")
        .build()
        .expect("application should build")
}

fn has_app_context_action() -> FunctionAction {
    FunctionActionBuilder::new()
        .build_sync(|_state, ctx| {
            IndexMap::from([(
                "has_app_context".to_string(),
                json!(ctx.app_context.is_some()),
            )])
        })
        .expect("function action should build")
}

fn runtime_app_context_action(
    builder: FunctionActionBuilder,
    build: impl Fn(&ActionContext, &Ctx) -> IndexMap<String, serde_json::Value> + Send + Sync + 'static,
) -> FunctionAction {
    builder
        .build_sync(move |_state, ctx| {
            let app_context = ctx
                .app_context
                .as_ref()
                .expect("runtime should provide app context");
            build(ctx, app_context)
        })
        .expect("function action should build")
}

#[test]
fn manual_action_run_uses_caller_provided_context() {
    let expected_context = sample_context("manual-app");
    let action = FunctionActionBuilder::new()
        .build_sync(|_state, ctx| {
            let app_id = ctx
                .app_context
                .as_ref()
                .expect("manual context should be set")
                .app_id
                .clone();
            IndexMap::from([("seen_app_id".to_string(), json!(app_id))])
        })
        .expect("function action should build");

    let result = rurr_core::action::LocalAction::run(
        &action,
        &State::default(),
        &ActionContext::new(
            ActionInputs::new(),
            ActionTracer::default(),
            Some(expected_context.clone()),
        ),
    )
    .expect("manual action should run");

    assert_eq!(
        result.result().get("seen_app_id"),
        Some(&json!(expected_context.app_id))
    );
}

#[test]
fn manual_action_run_defaults_to_no_app_context() {
    let action = has_app_context_action();

    let result =
        rurr_core::action::LocalAction::run(&action, &State::default(), &ActionContext::default())
            .expect("action run should succeed");

    assert_eq!(result.result().get("has_app_context"), Some(&json!(false)));
}

#[test]
fn application_step_populates_action_context_inputs_and_app_context() {
    let action = runtime_app_context_action(
        FunctionActionBuilder::new().inputs(["payload"]),
        |ctx, app_context| {
            IndexMap::from([
                (
                    "payload".to_string(),
                    ctx.inputs
                        .get("payload")
                        .cloned()
                        .expect("payload should pass through"),
                ),
                ("app_id".to_string(), json!(app_context.app_id.clone())),
                (
                    "partition_key".to_string(),
                    json!(app_context.partition_key.clone()),
                ),
                (
                    "sequence_id".to_string(),
                    json!(app_context.sequence_id.expect("sequence id should be set")),
                ),
            ])
        },
    );
    let mut app = build_single_step_app("check_ctx", action);

    let output = app
        .step(Some(IndexMap::from([("payload".to_string(), json!(41))])))
        .expect("step should succeed")
        .expect("step should execute action");

    assert_eq!(
        output.result,
        IndexMap::from([
            ("payload".to_string(), json!(41)),
            ("app_id".to_string(), json!("app-context-test")),
            ("partition_key".to_string(), json!("pk")),
            ("sequence_id".to_string(), json!(0)),
        ])
    );
}

#[test]
fn application_step_uses_seeded_sequence_id_from_identifiers() {
    let action = runtime_app_context_action(FunctionActionBuilder::new(), |_ctx, app_context| {
        IndexMap::from([(
            "sequence_id".to_string(),
            json!(app_context
                .sequence_id
                .expect("sequence id should be present")),
        )])
    });
    let mut app = ApplicationScenario::single_action(State::default(), "seeded", action)
        .expect("fixture should build")
        .into_fixture()
        .with_identifiers("seeded-app", Some("seeded-pk".to_string()), Some(41))
        .expect("identifiers should configure")
        .build()
        .expect("application should build");

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute action");

    assert_eq!(output.result.get("sequence_id"), Some(&json!(42)));
}

#[test]
fn application_step_propagates_spawning_parent_pointer_from_builder() {
    let action = runtime_app_context_action(FunctionActionBuilder::new(), |_ctx, app_context| {
        let spawning_parent = app_context
            .spawning_parent_pointer
            .as_ref()
            .expect("spawning parent pointer should be set");
        IndexMap::from([
            (
                "parent_app_id".to_string(),
                json!(spawning_parent.app_id.clone()),
            ),
            (
                "parent_partition_key".to_string(),
                json!(spawning_parent.partition_key.clone()),
            ),
            (
                "parent_sequence_id".to_string(),
                json!(spawning_parent
                    .sequence_id
                    .expect("sequence id should be set")),
            ),
        ])
    });
    let mut app = ApplicationScenario::single_action(State::default(), "spawned", action)
        .expect("fixture should build")
        .into_fixture()
        .into_builder()
        .with_spawning_parent("parent-app", Some("parent-pk".to_string()), 8)
        .expect("spawning parent should configure")
        .build()
        .expect("application should build");

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute action");

    assert_eq!(
        output.result,
        IndexMap::from([
            ("parent_app_id".to_string(), json!("parent-app")),
            ("parent_partition_key".to_string(), json!("parent-pk")),
            ("parent_sequence_id".to_string(), json!(8)),
        ])
    );
}

#[test]
fn application_step_propagates_fork_parent_pointer_from_initialize_from() {
    let action = runtime_app_context_action(FunctionActionBuilder::new(), |_ctx, app_context| {
        let parent = app_context
            .parent_pointer
            .as_ref()
            .expect("fork parent pointer should be set");
        IndexMap::from([
            ("parent_app_id".to_string(), json!(parent.app_id.clone())),
            (
                "parent_partition_key".to_string(),
                json!(parent.partition_key.clone()),
            ),
            (
                "parent_sequence_id".to_string(),
                json!(parent.sequence_id.expect("sequence id should be set")),
            ),
            (
                "current_sequence_id".to_string(),
                json!(app_context.sequence_id.expect("sequence id should be set")),
            ),
        ])
    });
    let initializer: Arc<dyn BaseStateLoader> = sync_initializer_with(Some(persisted_state(
        Some("tenant-source"),
        "source-app",
        7,
        Some(IndexMap::new()),
        Some("forked"),
        PersistedStateStatus::Completed,
        Some("2026-03-19T00:00:00Z"),
    )));
    let mut app = ApplicationBuilder::new()
        .with_actions(vec![("forked", action)])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_identifiers("target-app", Some("target-pk".to_string()), None)
        .expect("identifiers should configure")
        .initialize_from(
            initializer,
            initialize_from_spec(false, IndexMap::new(), "forked").with_fork_target(
                rurr_persistence::PersistenceLoadTarget::new(
                    "source-app",
                    Some("tenant-source".to_string()),
                    Some(7),
                ),
            ),
        )
        .expect("initializer wrapper should configure")
        .build()
        .expect("application should build");

    let output = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute action");

    assert_eq!(
        output.result,
        IndexMap::from([
            ("parent_app_id".to_string(), json!("source-app")),
            ("parent_partition_key".to_string(), json!("tenant-source")),
            ("parent_sequence_id".to_string(), json!(7)),
            ("current_sequence_id".to_string(), json!(8)),
        ])
    );
}

#[test]
fn forged_runtime_reserved_inputs_are_rejected_by_application_step() {
    let action = FunctionActionBuilder::new()
        .inputs(["payload"])
        .build_sync(|_state, ctx| {
            IndexMap::from([(
                "payload".to_string(),
                ctx.inputs
                    .get("payload")
                    .cloned()
                    .expect("payload should pass through"),
            )])
        })
        .expect("function action should build");
    let mut app = build_single_step_app("check_reserved", action);

    let runtime_inputs = IndexMap::from([
        ("payload".to_string(), json!(41)),
        ("__context".to_string(), json!({"forged": true})),
        ("__tracer".to_string(), json!("forged-tracer")),
    ]);

    let error = app
        .step(Some(runtime_inputs))
        .expect_err("reserved runtime inputs should be rejected");
    let message = error.to_string();
    assert!(message.contains("reserved"));
    assert!(message.contains("__context"));
    assert!(message.contains("__tracer"));
}

#[test]
fn bind_time_reserved_inputs_are_rejected_by_builder() {
    let error = FunctionActionBuilder::new()
        .inputs(["safe"])
        .bind([
            ("safe", json!(10)),
            ("__context", json!({"forged": "bind"})),
            ("__tracer", json!("forged-bind-tracer")),
        ])
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect_err("builder should reject reserved bind-time inputs");
    let message = error.to_string();
    assert!(
        message.contains("__context") || message.contains("__tracer"),
        "expected reserved key in error message, got: {message}"
    );
}

#[test]
fn manual_action_context_defaults_to_none_without_explicit_context() {
    let action = has_app_context_action();

    let seen =
        rurr_core::action::LocalAction::run(&action, &State::default(), &ActionContext::default())
            .expect("action run should succeed")
            .result()
            .get("has_app_context")
            .cloned()
            .expect("has_app_context should be present");

    assert_eq!(seen, json!(false));
}

#[test]
fn application_context_accessor_reflects_stored_metadata() {
    let action = FunctionActionBuilder::new()
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("function action should build");
    let mut app = ApplicationScenario::single_action(State::default(), "inspect", action)
        .expect("fixture should build")
        .into_fixture()
        .into_builder()
        .with_identifiers("ctx-app", Some("ctx-pk".to_string()), Some(5))
        .expect("identifiers should configure")
        .with_spawning_parent("spawn-parent", Some("spawn-pk".to_string()), 8)
        .expect("spawning parent should configure")
        .build()
        .expect("application should build");

    let initial = app.context().expect("context should resolve");
    assert_eq!(initial.app_id, "ctx-app");
    assert_eq!(initial.partition_key.as_deref(), Some("ctx-pk"));
    assert_eq!(initial.sequence_id, Some(5));
    assert_eq!(
        initial
            .spawning_parent_pointer
            .as_ref()
            .map(|pointer| pointer.app_id.as_str()),
        Some("spawn-parent")
    );

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    let committed = app.context().expect("context should resolve after step");
    assert_eq!(committed.sequence_id, Some(6));
    assert_eq!(committed.prior_step.as_deref(), Some("inspect"));
}
