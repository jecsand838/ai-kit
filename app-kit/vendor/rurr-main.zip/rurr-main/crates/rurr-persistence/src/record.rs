use crate::{wire as persistence_wire, PersistedStateData, PersistenceError};

/// Backend-decoded scalar fields used to assemble a persisted-state record.
pub struct PersistedRecordParts<'a> {
    /// Normalized stored partition key.
    pub partition_key: String,
    /// Stored application id.
    pub app_id: String,
    /// Public sequence id value.
    pub sequence_id: u64,
    /// Optional stored workflow position.
    pub position: Option<String>,
    /// Optional stored JSON payload.
    pub state_json: Option<&'a str>,
    /// Optional created-at timestamp.
    pub created_at: Option<String>,
    /// Stored status string.
    pub status: &'a str,
}

/// Builds the public persisted-state model from backend-decoded scalar fields.
pub fn persisted_state_from_record_parts(
    parts: PersistedRecordParts<'_>,
    state_deserialization_operation: &'static str,
    status_deserialization_operation: &'static str,
) -> Result<PersistedStateData, PersistenceError> {
    Ok(PersistedStateData {
        partition_key: Some(parts.partition_key),
        app_id: parts.app_id,
        sequence_id: parts.sequence_id,
        position: parts.position,
        state: parts
            .state_json
            .map(|state_json| {
                persistence_wire::deserialize_state_json(
                    state_json,
                    state_deserialization_operation,
                )
            })
            .transpose()?,
        created_at: parts.created_at,
        status: persistence_wire::persisted_status_from_str(
            parts.status,
            status_deserialization_operation,
        )?,
    })
}

#[cfg(test)]
mod tests {
    use super::{persisted_state_from_record_parts, PersistedRecordParts};
    use crate::PersistedStateStatus;
    use indexmap::IndexMap;
    use serde_json::json;

    #[test]
    fn persisted_state_from_record_parts_preserves_optional_fields() {
        let state_json = serde_json::to_string(&IndexMap::from([("count".to_string(), json!(1))]))
            .expect("state json should serialize");

        let record = persisted_state_from_record_parts(
            PersistedRecordParts {
                partition_key: "partition".to_string(),
                app_id: "app".to_string(),
                sequence_id: 7,
                position: Some("step".to_string()),
                state_json: Some(state_json.as_str()),
                created_at: Some("2026-04-14T00:00:00.000000000Z".to_string()),
                status: "completed",
            },
            "state_failed",
            "status_failed",
        )
        .expect("record parts should deserialize");

        assert_eq!(record.sequence_id, 7);
        assert_eq!(record.position.as_deref(), Some("step"));
        assert_eq!(record.status, PersistedStateStatus::Completed);
    }
}
