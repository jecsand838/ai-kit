use rurr_persistence::PersistenceError;
use std::fmt::{Display, Formatter};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant as StdInstant, SystemTime, UNIX_EPOCH};
use tokio::time::{sleep, Instant};

/// Environment variable that activates docker-backed live/provider test lanes.
pub const CHECK_LIVE_ENV: &str = "RURR_RUN_CHECK_LIVE";
/// Environment variable that activates the private OpenAI live test lane.
pub const OPENAI_LIVE_ENV: &str = "RURR_RUN_OPENAI_LIVE";

pub(crate) const SERVICE_PROBE_ATTEMPT_TIMEOUT: Duration = Duration::from_secs(2);
const SERVICE_PROBE_TOTAL_TIMEOUT: Duration = Duration::from_secs(10);
const SERVICE_PROBE_RETRY_DELAY: Duration = Duration::from_millis(250);

fn env_flag_enabled(name: &str) -> bool {
    matches!(std::env::var(name).as_deref(), Ok("1"))
}

/// Returns whether docker-backed live/provider tests are explicitly enabled.
///
/// Test bodies should return early when this is `false`; starting containers is
/// handled by the workspace live scripts, not by unit tests.
pub fn check_live_tests_enabled() -> bool {
    env_flag_enabled(CHECK_LIVE_ENV)
}

/// Returns whether the private OpenAI live test lane is explicitly enabled.
pub fn openai_live_tests_enabled() -> bool {
    env_flag_enabled(OPENAI_LIVE_ENV)
}

/// Returns a compact time-derived suffix for live-test resource names.
pub fn unique_live_suffix(prefix: &'static str) -> String {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| format!("{:x}", duration.as_nanos()))
        .unwrap_or_else(|_| prefix.to_string())
}

pub(crate) fn unique_name_suffix(counter: &AtomicU64) -> String {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_nanos() as u64)
        .unwrap_or_default();
    let counter = counter.fetch_add(1, Ordering::Relaxed);
    format!("{:08x}", (nanos ^ counter) as u32)
}

#[derive(Clone, Copy)]
pub(crate) struct ProbeSchedule {
    pub(crate) attempt_timeout: Duration,
    pub(crate) total_timeout: Duration,
    pub(crate) retry_delay: Duration,
}

impl ProbeSchedule {
    pub(crate) const fn live_defaults() -> Self {
        Self {
            attempt_timeout: SERVICE_PROBE_ATTEMPT_TIMEOUT,
            total_timeout: SERVICE_PROBE_TOTAL_TIMEOUT,
            retry_delay: SERVICE_PROBE_RETRY_DELAY,
        }
    }

    #[cfg(test)]
    pub(crate) const fn new(
        attempt_timeout: Duration,
        total_timeout: Duration,
        retry_delay: Duration,
    ) -> Self {
        Self {
            attempt_timeout,
            total_timeout,
            retry_delay,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Error returned when a live-service test helper cannot validate or reach a service.
pub enum LiveServiceError {
    /// The configured endpoint is malformed or unsupported for the helper.
    InvalidConfiguration {
        /// Service being validated.
        service: &'static str,
        /// Endpoint or URI that was rejected.
        endpoint: String,
        /// Human-readable validation failure.
        message: String,
    },
    /// The configured endpoint is valid but the service did not become reachable in time.
    Unavailable {
        /// Service being probed.
        service: &'static str,
        /// Endpoint or URI that remained unavailable.
        endpoint: String,
        /// Human-readable probe failure.
        message: String,
    },
    /// A strict OTLP collector JSONL envelope was malformed.
    MalformedOtelJsonEnvelope {
        /// Signal being projected.
        signal: &'static str,
        /// JSON pointer path where validation failed.
        path: String,
        /// Human-readable validation failure.
        message: String,
    },
}

impl Display for LiveServiceError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::InvalidConfiguration {
                service,
                endpoint,
                message,
            } => write!(
                f,
                "{service} live test configuration is invalid for {endpoint}: {message}"
            ),
            Self::Unavailable {
                service,
                endpoint,
                message,
            } => write!(
                f,
                "{service} live service is unavailable at {endpoint}: {message}"
            ),
            Self::MalformedOtelJsonEnvelope {
                signal,
                path,
                message,
            } => write!(
                f,
                "malformed OTLP {signal} JSON envelope at {path}: {message}"
            ),
        }
    }
}

impl std::error::Error for LiveServiceError {}

/// Converts a live-service helper failure into a persistence error without
/// discarding provider detail.
pub fn live_service_error_to_persistence(
    operation: &'static str,
    error: LiveServiceError,
) -> PersistenceError {
    PersistenceError::BackendOperationFailed {
        operation,
        message: error.to_string(),
    }
}

#[derive(Clone, Copy)]
pub(crate) struct ServiceProbe<'a> {
    service: &'static str,
    endpoint: &'a str,
    schedule: ProbeSchedule,
}

impl<'a> ServiceProbe<'a> {
    pub(crate) fn new(service: &'static str, endpoint: &'a str, schedule: ProbeSchedule) -> Self {
        Self {
            service,
            endpoint,
            schedule,
        }
    }

    pub(crate) fn invalid(self, message: impl Into<String>) -> LiveServiceError {
        LiveServiceError::InvalidConfiguration {
            service: self.service,
            endpoint: self.endpoint.to_string(),
            message: message.into(),
        }
    }

    pub(crate) fn unavailable(self, message: impl Into<String>) -> LiveServiceError {
        LiveServiceError::Unavailable {
            service: self.service,
            endpoint: self.endpoint.to_string(),
            message: message.into(),
        }
    }

    pub(crate) async fn retry_async<F, Fut>(self, mut probe: F) -> Result<(), LiveServiceError>
    where
        F: FnMut() -> Fut,
        Fut: std::future::Future<Output = Result<(), String>>,
    {
        let deadline = Instant::now() + self.schedule.total_timeout;

        loop {
            match probe().await {
                Ok(()) => return Ok(()),
                Err(message) if Instant::now() >= deadline => {
                    return Err(self.unavailable(format!(
                        "probe failed after {}s: {message}",
                        self.schedule.total_timeout.as_secs()
                    )));
                }
                Err(_) => sleep(self.schedule.retry_delay).await,
            }
        }
    }

    pub(crate) fn retry_sync<F>(self, mut probe: F) -> Result<(), LiveServiceError>
    where
        F: FnMut() -> Result<(), String>,
    {
        let deadline = StdInstant::now() + self.schedule.total_timeout;

        loop {
            match probe() {
                Ok(()) => return Ok(()),
                Err(message) if StdInstant::now() >= deadline => {
                    return Err(self.unavailable(format!(
                        "probe failed after {}s: {message}",
                        self.schedule.total_timeout.as_secs()
                    )));
                }
                Err(_) => std::thread::sleep(self.schedule.retry_delay),
            }
        }
    }
}

#[cfg(test)]
pub(crate) mod tests {
    use std::net::{SocketAddr, TcpListener};

    pub(crate) struct StallServer {
        _listener: TcpListener,
        address: SocketAddr,
    }

    impl StallServer {
        pub(crate) fn start() -> Self {
            let listener = TcpListener::bind(("127.0.0.1", 0)).expect("listener should bind");
            let address = listener
                .local_addr()
                .expect("listener should expose its address");
            Self {
                _listener: listener,
                address,
            }
        }

        pub(crate) fn address(&self) -> SocketAddr {
            self.address
        }
    }
}
