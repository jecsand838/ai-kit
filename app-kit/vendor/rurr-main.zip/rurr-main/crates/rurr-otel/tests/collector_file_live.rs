use opentelemetry::logs::{LogRecord as _, Logger as _, LoggerProvider as _, Severity};
use opentelemetry::trace::{Span as _, Tracer as _, TracerProvider as _};
use opentelemetry::KeyValue;
use opentelemetry_otlp::Protocol;
use rurr_otel::{
    build_otlp_logger_provider, build_otlp_tracer_provider, convert_to_otel_attribute, OtlpConfig,
};
use rurr_testkit::live_services::{
    otel_array_any_values as array_any_values, otel_bool_any_value as bool_any_value,
    otel_double_any_value as double_any_value, otel_int_any_value as int_any_value,
    otel_log_attribute as log_attribute, otel_resource_attribute_value as resource_attribute_value,
    otel_span_attribute as span_attribute, otel_string_any_value as string_any_value,
    reset_otel_file_exports, unique_live_suffix, wait_for_raw_otel_exports, RawOtelLogRecord,
    RawOtelTraceSpan,
};
use serde_json::json;
use serde_json::Value;
use std::time::Duration;

const LIVE_EVENT_NAME: &str = "rurr.otel.live";
const LIVE_ATTRIBUTE_EVENT_NAME: &str = "rurr.otel.attribute.live";
const LIVE_GRPC_EVENT_NAME: &str = "rurr.otel.grpc.live";
const LIVE_HTTP_JSON_EVENT_NAME: &str = "rurr.otel.http_json.live";
const LIVE_NULL_ATTRIBUTE_EVENT_NAME: &str = "rurr.otel.null_attribute.live";

fn wait_for_matching_records(
    service_name: &str,
    span_name: &str,
    case_id: &str,
) -> (RawOtelTraceSpan, RawOtelLogRecord) {
    wait_for_raw_otel_exports(
        Duration::from_secs(15),
        "collector file exporter did not record the expected OTEL span/log within 15s",
        |spans, logs| {
            let span = spans.into_iter().find(|export| {
                export.span.get("name").and_then(Value::as_str) == Some(span_name)
                    && resource_attribute_value(&export.resource_attributes, "service.name")
                        .and_then(string_any_value)
                        == Some(service_name)
                    && span_attribute(&export.span, "rurr.test.case").and_then(string_any_value)
                        == Some(case_id)
            });
            let log = logs.into_iter().find(|export| {
                export.record.get("eventName").and_then(Value::as_str) == Some(span_name)
                    && resource_attribute_value(&export.resource_attributes, "service.name")
                        .and_then(string_any_value)
                        == Some(service_name)
                    && log_attribute(&export.record, "rurr.test.case").and_then(string_any_value)
                        == Some(case_id)
            });
            span.zip(log)
        },
    )
    .expect("collector file exporter should return the expected OTEL span/log")
}

fn export_correlated_trace_and_log(
    config: &OtlpConfig,
    instrumentation_name: &'static str,
    span_name: &'static str,
    body: &'static str,
    case_id: &str,
) -> (RawOtelTraceSpan, RawOtelLogRecord) {
    let tracer_provider = build_otlp_tracer_provider(config).expect("trace provider should build");
    let logger_provider = build_otlp_logger_provider(config).expect("log provider should build");

    let tracer = tracer_provider.tracer(instrumentation_name);
    let logger = logger_provider.logger(instrumentation_name);
    let mut span = tracer.start(span_name.to_string());
    span.set_attribute(KeyValue::new("rurr.test.case", case_id.to_string()));

    let span_context = span.span_context().clone();
    let mut record = logger.create_log_record();
    record.set_event_name(span_name);
    record.set_target(instrumentation_name);
    record.set_severity_number(Severity::Info);
    record.set_severity_text(Severity::Info.name());
    record.set_body(body.into());
    record.set_trace_context(
        span_context.trace_id(),
        span_context.span_id(),
        Some(span_context.trace_flags()),
    );
    record.add_attribute("rurr.test.case", case_id.to_string());
    logger.emit(record);
    span.end();

    logger_provider
        .force_flush()
        .expect("log provider force flush should succeed");
    tracer_provider
        .force_flush()
        .expect("trace provider force flush should succeed");
    logger_provider
        .shutdown()
        .expect("log provider shutdown should succeed");
    tracer_provider
        .shutdown()
        .expect("trace provider shutdown should succeed");

    wait_for_matching_records(&config.service_name, span_name, case_id)
}

#[tokio::test(flavor = "multi_thread")]
async fn collector_file_export_contains_correlated_trace_and_log() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let suffix = unique_live_suffix("otel-live");
    let service_name = format!("rurr-otel-live-{suffix}");
    let mut config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_logs_collector_endpoint("http://127.0.0.1:4318");
    config.service_name = service_name.clone();

    let (exported_span, exported_log) = export_correlated_trace_and_log(
        &config,
        "rurr-otel-live",
        LIVE_EVENT_NAME,
        "rurr otel live proof",
        &suffix,
    );
    assert_eq!(
        exported_log.record.get("traceId").and_then(Value::as_str),
        exported_span.span.get("traceId").and_then(Value::as_str)
    );
    assert_eq!(
        exported_log.record.get("spanId").and_then(Value::as_str),
        exported_span.span.get("spanId").and_then(Value::as_str)
    );
    assert_eq!(
        resource_attribute_value(&exported_span.resource_attributes, "service.name")
            .and_then(string_any_value),
        Some(service_name.as_str())
    );
    assert_eq!(
        resource_attribute_value(&exported_log.resource_attributes, "service.name")
            .and_then(string_any_value),
        Some(service_name.as_str())
    );
    assert_eq!(
        span_attribute(&exported_span.span, "rurr.test.case").and_then(string_any_value),
        Some(suffix.as_str())
    );
    assert_eq!(
        log_attribute(&exported_log.record, "rurr.test.case").and_then(string_any_value),
        Some(suffix.as_str())
    );
    assert_eq!(
        exported_log.record.get("eventName").and_then(Value::as_str),
        Some(LIVE_EVENT_NAME)
    );
    assert_eq!(
        exported_log
            .record
            .get("severityText")
            .and_then(Value::as_str),
        Some("INFO")
    );
    assert_eq!(
        exported_log.record.get("body").and_then(string_any_value),
        Some("rurr otel live proof")
    );
}

#[tokio::test(flavor = "multi_thread")]
async fn collector_file_export_projection_validates_real_otlp_envelopes() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let suffix = unique_live_suffix("otel-envelope-live");
    let service_name = format!("rurr-otel-envelope-live-{suffix}");
    let mut config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_logs_collector_endpoint("http://127.0.0.1:4318");
    config.service_name = service_name.clone();

    let (exported_span, exported_log) = export_correlated_trace_and_log(
        &config,
        "rurr-otel-envelope-live",
        "rurr.otel.envelope.live",
        "rurr otel envelope live proof",
        &suffix,
    );

    assert!(
        exported_span.resource_attributes.is_some(),
        "strict live trace projection should preserve the resource envelope"
    );
    assert!(
        exported_log.resource_attributes.is_some(),
        "strict live log projection should preserve the resource envelope"
    );
    assert_eq!(
        resource_attribute_value(&exported_span.resource_attributes, "service.name")
            .and_then(string_any_value),
        Some(service_name.as_str())
    );
    assert_eq!(
        resource_attribute_value(&exported_log.resource_attributes, "service.name")
            .and_then(string_any_value),
        Some(service_name.as_str())
    );
}

#[tokio::test(flavor = "multi_thread")]
async fn collector_file_export_contains_grpc_trace_and_log() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let suffix = unique_live_suffix("otel-grpc-live");
    let service_name = format!("rurr-otel-grpc-live-{suffix}");
    let mut config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4317")
        .with_logs_collector_endpoint("http://127.0.0.1:4317")
        .with_protocol(Protocol::Grpc);
    config.service_name = service_name.clone();

    let (exported_span, exported_log) = export_correlated_trace_and_log(
        &config,
        "rurr-otel-grpc-live",
        LIVE_GRPC_EVENT_NAME,
        "rurr otel grpc live proof",
        &suffix,
    );
    assert_eq!(
        exported_log.record.get("traceId").and_then(Value::as_str),
        exported_span.span.get("traceId").and_then(Value::as_str)
    );
    assert_eq!(
        exported_log.record.get("spanId").and_then(Value::as_str),
        exported_span.span.get("spanId").and_then(Value::as_str)
    );
    assert_eq!(
        resource_attribute_value(&exported_span.resource_attributes, "service.name")
            .and_then(string_any_value),
        Some(service_name.as_str())
    );
    assert_eq!(
        exported_log.record.get("body").and_then(string_any_value),
        Some("rurr otel grpc live proof")
    );
}

#[tokio::test(flavor = "multi_thread")]
async fn collector_file_export_contains_http_json_trace_and_log() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let suffix = unique_live_suffix("otel-http-json-live");
    let service_name = format!("rurr-otel-http-json-live-{suffix}");
    let mut config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_logs_collector_endpoint("http://127.0.0.1:4318")
        .with_protocol(Protocol::HttpJson);
    config.service_name = service_name.clone();

    let (exported_span, exported_log) = export_correlated_trace_and_log(
        &config,
        "rurr-otel-http-json-live",
        LIVE_HTTP_JSON_EVENT_NAME,
        "rurr otel http json live proof",
        &suffix,
    );
    assert_eq!(
        exported_log.record.get("traceId").and_then(Value::as_str),
        exported_span.span.get("traceId").and_then(Value::as_str)
    );
    assert_eq!(
        exported_log.record.get("spanId").and_then(Value::as_str),
        exported_span.span.get("spanId").and_then(Value::as_str)
    );
    assert_eq!(
        resource_attribute_value(&exported_span.resource_attributes, "service.name")
            .and_then(string_any_value),
        Some(service_name.as_str())
    );
    assert_eq!(
        exported_log.record.get("body").and_then(string_any_value),
        Some("rurr otel http json live proof")
    );
}

#[tokio::test(flavor = "multi_thread")]
async fn collector_file_export_proves_complex_attribute_string_values() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let suffix = unique_live_suffix("otel-base-live");
    let service_name = format!("rurr-otel-attribute-live-{suffix}");
    let mut config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_logs_collector_endpoint("http://127.0.0.1:4318");
    config.service_name = service_name.clone();

    let tracer_provider = build_otlp_tracer_provider(&config).expect("trace provider should build");
    let logger_provider = build_otlp_logger_provider(&config).expect("log provider should build");

    let tracer = tracer_provider.tracer("rurr-otel-live");
    let logger = logger_provider.logger("rurr-otel-live");
    let mut span = tracer.start(LIVE_ATTRIBUTE_EVENT_NAME);
    span.set_attribute(KeyValue::new("rurr.test.case", suffix.clone()));

    let expected_attributes = [
        (
            "rurr.test.object",
            json!({"foo": 1, "bar": true}),
            r#"{"foo": 1, "bar": true}"#,
        ),
        ("rurr.test.mixed_array", json!([1, "x"]), r#"[1, "x"]"#),
        ("rurr.test.mixed_numeric_array", json!([1, 1.5]), "[1, 1.5]"),
        (
            "rurr.test.large_u64",
            json!(9_223_372_036_854_775_808_u64),
            "9223372036854775808",
        ),
        (
            "rurr.test.large_u64_array",
            json!([9_223_372_036_854_775_808_u64, 9_223_372_036_854_775_809_u64]),
            "[9223372036854775808, 9223372036854775809]",
        ),
        ("rurr.test.empty_array", json!([]), "[]"),
    ];

    for (key, value, _expected) in expected_attributes.iter() {
        let otel_value = convert_to_otel_attribute(value)
            .unwrap_or_else(|| panic!("{key} should convert into a live-proven string attribute"));
        span.set_attribute(KeyValue::new(*key, otel_value));
    }

    let span_context = span.span_context().clone();
    let mut record = logger.create_log_record();
    record.set_event_name(LIVE_ATTRIBUTE_EVENT_NAME);
    record.set_target("rurr-otel-live");
    record.set_severity_number(Severity::Info);
    record.set_severity_text(Severity::Info.name());
    record.set_body("rurr otel attribute live proof".into());
    record.set_trace_context(
        span_context.trace_id(),
        span_context.span_id(),
        Some(span_context.trace_flags()),
    );
    record.add_attribute("rurr.test.case", suffix.clone());
    logger.emit(record);
    span.end();

    logger_provider
        .force_flush()
        .expect("log provider force flush should succeed");
    tracer_provider
        .force_flush()
        .expect("trace provider force flush should succeed");
    logger_provider
        .shutdown()
        .expect("log provider shutdown should succeed");
    tracer_provider
        .shutdown()
        .expect("trace provider shutdown should succeed");

    let (exported_span, _exported_log) =
        wait_for_matching_records(&service_name, LIVE_ATTRIBUTE_EVENT_NAME, &suffix);
    for (key, _value, expected) in expected_attributes {
        assert_eq!(
            span_attribute(&exported_span.span, key).and_then(string_any_value),
            Some(expected),
            "collector raw AnyValue stringValue mismatch for {key}"
        );
    }
}

#[tokio::test(flavor = "multi_thread")]
async fn collector_file_export_proves_primitive_and_homogeneous_array_any_values() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let suffix = unique_live_suffix("otel-attr-live");
    let service_name = format!("rurr-otel-anyvalue-live-{suffix}");
    let mut config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_logs_collector_endpoint("http://127.0.0.1:4318");
    config.service_name = service_name.clone();

    let tracer_provider = build_otlp_tracer_provider(&config).expect("trace provider should build");
    let logger_provider = build_otlp_logger_provider(&config).expect("log provider should build");

    let tracer = tracer_provider.tracer("rurr-otel-live");
    let logger = logger_provider.logger("rurr-otel-live");
    let mut span = tracer.start(LIVE_ATTRIBUTE_EVENT_NAME);
    span.set_attribute(KeyValue::new("rurr.test.case", suffix.clone()));

    let expected_attributes = [
        ("rurr.test.bool", json!(true)),
        ("rurr.test.i64", json!(42_i64)),
        ("rurr.test.f64", json!(4.25_f64)),
        ("rurr.test.string", json!("otel-string")),
        ("rurr.test.bool_array", json!([true, false, true])),
        ("rurr.test.i64_array", json!([1_i64, 2_i64, 3_i64])),
        ("rurr.test.f64_array", json!([1.25_f64, 2.5_f64, 3.75_f64])),
        ("rurr.test.string_array", json!(["alpha", "beta", "gamma"])),
    ];

    for (key, value) in expected_attributes {
        let otel_value = convert_to_otel_attribute(&value)
            .unwrap_or_else(|| panic!("{key} should convert into a live-proven AnyValue"));
        span.set_attribute(KeyValue::new(key, otel_value));
    }

    let span_context = span.span_context().clone();
    let mut record = logger.create_log_record();
    record.set_event_name(LIVE_ATTRIBUTE_EVENT_NAME);
    record.set_target("rurr-otel-live");
    record.set_severity_number(Severity::Info);
    record.set_severity_text(Severity::Info.name());
    record.set_body("rurr otel anyvalue live proof".into());
    record.set_trace_context(
        span_context.trace_id(),
        span_context.span_id(),
        Some(span_context.trace_flags()),
    );
    record.add_attribute("rurr.test.case", suffix.clone());
    logger.emit(record);
    span.end();

    logger_provider
        .force_flush()
        .expect("log provider force flush should succeed");
    tracer_provider
        .force_flush()
        .expect("trace provider force flush should succeed");
    logger_provider
        .shutdown()
        .expect("log provider shutdown should succeed");
    tracer_provider
        .shutdown()
        .expect("trace provider shutdown should succeed");

    let (exported_span, _exported_log) =
        wait_for_matching_records(&service_name, LIVE_ATTRIBUTE_EVENT_NAME, &suffix);
    assert_eq!(
        span_attribute(&exported_span.span, "rurr.test.bool").and_then(bool_any_value),
        Some(true)
    );
    assert_eq!(
        span_attribute(&exported_span.span, "rurr.test.i64").and_then(int_any_value),
        Some("42")
    );
    assert_eq!(
        span_attribute(&exported_span.span, "rurr.test.f64").and_then(double_any_value),
        Some(4.25)
    );
    assert_eq!(
        span_attribute(&exported_span.span, "rurr.test.string").and_then(string_any_value),
        Some("otel-string")
    );

    let bool_values = span_attribute(&exported_span.span, "rurr.test.bool_array")
        .and_then(array_any_values)
        .expect("bool array should be exported as raw AnyValue.arrayValue.values");
    assert_eq!(
        bool_values
            .iter()
            .map(bool_any_value)
            .collect::<Option<Vec<_>>>(),
        Some(vec![true, false, true])
    );

    let i64_values = span_attribute(&exported_span.span, "rurr.test.i64_array")
        .and_then(array_any_values)
        .expect("i64 array should be exported as raw AnyValue.arrayValue.values");
    assert_eq!(
        i64_values
            .iter()
            .map(int_any_value)
            .collect::<Option<Vec<_>>>(),
        Some(vec!["1", "2", "3"])
    );

    let f64_values = span_attribute(&exported_span.span, "rurr.test.f64_array")
        .and_then(array_any_values)
        .expect("f64 array should be exported as raw AnyValue.arrayValue.values");
    assert_eq!(
        f64_values
            .iter()
            .map(double_any_value)
            .collect::<Option<Vec<_>>>(),
        Some(vec![1.25, 2.5, 3.75])
    );

    let string_values = span_attribute(&exported_span.span, "rurr.test.string_array")
        .and_then(array_any_values)
        .expect("string array should be exported as raw AnyValue.arrayValue.values");
    assert_eq!(
        string_values
            .iter()
            .map(string_any_value)
            .collect::<Option<Vec<_>>>(),
        Some(vec!["alpha", "beta", "gamma"])
    );
}

#[tokio::test(flavor = "multi_thread")]
async fn collector_file_export_proves_json_null_attributes_are_omitted() {
    rurr_testkit::require_check_live_tests!();

    reset_otel_file_exports().expect("collector file exports should reset");

    let suffix = unique_live_suffix("otel-null-live");
    let service_name = format!("rurr-otel-null-live-{suffix}");
    let mut config = OtlpConfig::default()
        .with_traces_collector_endpoint("http://127.0.0.1:4318")
        .with_logs_collector_endpoint("http://127.0.0.1:4318");
    config.service_name = service_name.clone();

    let tracer_provider = build_otlp_tracer_provider(&config).expect("trace provider should build");
    let logger_provider = build_otlp_logger_provider(&config).expect("log provider should build");

    let tracer = tracer_provider.tracer("rurr-otel-live");
    let logger = logger_provider.logger("rurr-otel-live");
    let mut span = tracer.start(LIVE_NULL_ATTRIBUTE_EVENT_NAME);
    span.set_attribute(KeyValue::new("rurr.test.case", suffix.clone()));

    let null_value = json!(null);
    if let Some(otel_value) = convert_to_otel_attribute(&null_value) {
        span.set_attribute(KeyValue::new("rurr.test.null", otel_value));
    }

    let span_context = span.span_context().clone();
    let mut record = logger.create_log_record();
    record.set_event_name(LIVE_NULL_ATTRIBUTE_EVENT_NAME);
    record.set_target("rurr-otel-live");
    record.set_severity_number(Severity::Info);
    record.set_severity_text(Severity::Info.name());
    record.set_body("rurr otel null attribute live proof".into());
    record.set_trace_context(
        span_context.trace_id(),
        span_context.span_id(),
        Some(span_context.trace_flags()),
    );
    record.add_attribute("rurr.test.case", suffix.clone());
    logger.emit(record);
    span.end();

    logger_provider
        .force_flush()
        .expect("log provider force flush should succeed");
    tracer_provider
        .force_flush()
        .expect("trace provider force flush should succeed");
    logger_provider
        .shutdown()
        .expect("log provider shutdown should succeed");
    tracer_provider
        .shutdown()
        .expect("trace provider shutdown should succeed");

    let (exported_span, _exported_log) =
        wait_for_matching_records(&service_name, LIVE_NULL_ATTRIBUTE_EVENT_NAME, &suffix);
    assert_eq!(
        span_attribute(&exported_span.span, "rurr.test.case").and_then(string_any_value),
        Some(suffix.as_str())
    );
    assert!(
        span_attribute(&exported_span.span, "rurr.test.null").is_none(),
        "JSON null conversion must not create a raw OTEL span attribute"
    );
}
