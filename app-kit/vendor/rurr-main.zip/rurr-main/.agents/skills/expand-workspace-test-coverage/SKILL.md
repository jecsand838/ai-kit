---
name: expand-workspace-test-coverage
description: "Use when turning approved, workspace-scoped Rurr test-coverage findings into a red-test-first plan and implementation pass that adds unit, integration, and live coverage, fixes real bugs exposed by new tests, and runs completion gates without shims, warning suppression, dead test-only logic, or new crates. Do not use for one-off failing test triage, `/review` bug-fix resolution, or delete-first cleanup refactors."
---

# Expand Workspace Test Coverage

Use this skill when the user wants approved Rurr coverage findings turned into a concrete red-test-first plan and an implementation pass that closes those gaps without adding test hacks or unrelated refactors.

## Quick start

Load, in order:

- the prior coverage audit, approved findings, or approved plan first
- `README.md`
- `docs/00_overview.md`
- `docs/03_test_plan.md`
- `docs/RURR_TEST_MATRIX.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- the relevant existing tests, live gates, and Burr source for the touched behavior

Load these companion skills:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-dependencies-platforms`
- `$rurr-burr-source-parity-walk`
- `$rurr-gate-closeout`

Add the relevant Rurr guardrail skills when the touched behavior needs them:

- `$rurr-streaming-transaction-safety`
- `$rurr-anchored-filesystem-hardening`
- `$rurr-persistence-adapter-parity`
- `$rurr-proc-macro-ui-contract`

## When to use

Use it when the task:

- asks to resolve previously identified workspace test coverage gaps end to end
- asks to plan and then implement approved coverage findings
- needs red-test-first slice order, minimal production fixes, and final gates
- needs real bugs fixed only when new tests expose them

Do not use it for one-off failing test triage, `/review` bug-fix resolution, delete-first cleanup work, or unrelated refactors.

## Planning phase

1. Translate each approved finding into the affected behavior, current evidence, required proof, likely files, and gate risk.
2. Group the work by subsystem or behavior, not by file list or audit ordering.
3. Specify the red tests first, the intended proving layer, and the smallest production fix surface that should be touched.
4. When a finding touches provider/backend behavior or production fallback semantics, require the named strict live/backend/provider proof lane first or alongside local tests.
5. Name the relevant Rurr guardrail skills and Rust companion skills for each finding group.
6. Define the narrow gates for each group plus the required final completion gates.
7. Reject shims, warning suppression, dead test-only logic, golden leaks, hacked live tests, and new crates.
8. Emit a decision-complete `<proposed_plan>` with `Summary`, `Findings Covered`, `Key Changes`, `Tests/Gates`, and `Assumptions/Blockers`.

## Implementation phase

1. Load the approved plan and the touched guardrails before editing.
2. Add or enable the red test first when feasible.
3. Implement one finding group at a time and keep the fix surface minimal.
4. Reuse existing Rurr models, facades, and helpers before adding new abstractions.
5. If the honest result is "unsupported", "not yet implemented", or explicit configuration failure, encode that directly instead of inventing a fallback to satisfy the new test.
6. If a new test exposes a production bug, fix the real defect and remove any adjacent dead path touched by that fix.
7. Run narrow tests after each group before broadening to the next one.
8. Use `$rurr-gate-closeout` for manifest handling, final gate selection, and truthful closeout reporting.
9. Report every approved finding as resolved or blocked, with the exact tests and gates that prove the status.

## Plan output contract

When producing a plan, wrap the final answer in `<proposed_plan>` and include exactly these sections:

- `Summary`
- `Findings Covered`
- `Key Changes`
- `Tests/Gates`
- `Assumptions/Blockers`

`Findings Covered` must account for every approved gap or explicitly mark duplicates and deliberate deferrals. `Tests/Gates` must name the red tests, narrow gates, manifest handling, and final completion gates.

## Default rules

- This skill is designed for Plan mode use, but the plan/implementation split is encoded in the body rather than metadata.
- Prefer the narrowest test layer that can prove the behavior truthfully.
- Keep unit tests local, integration tests on public APIs, and live tests on real dependencies you do not own.
- For external/provider/backend behavior, do not stop at local tests when the workspace expects a
  named strict proof lane.
- Do not introduce new crates or test-only production hooks.
- Do not weaken gates or suppress warnings to make the pass go green.
- Preserve documented Rurr guardrails and Burr parity for any touched behavior.
- Prefer explicit `Unsupported`, `NotYetImplemented`, or typed configuration/startup errors over
  synthetic production fallbacks when missing behavior is exposed.

## Do not use this skill alone when

- the user still needs the coverage audit itself: also use `$audit-workspace-test-coverage`
- the user still needs a disputed Burr comparison resolved before the implementation plan: also use `$rurr-burr-source-parity-walk`
- the task is only final verification after code changes already exist: also use `$rurr-gate-closeout`
- the task is really Codex `/review` bug-fix resolution: use `$rurr-resolve-review-findings` instead
- the task is really a delete-first cleanup or branch-diff reduction pass: use `$rurr-delete-first-refactor-plan` instead
