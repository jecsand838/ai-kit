use super::common::{
    unique_name_suffix, LiveServiceError, ProbeSchedule, ServiceProbe,
    SERVICE_PROBE_ATTEMPT_TIMEOUT,
};
use mongodb::bson::{doc, Document};
use mongodb::sync::Client as MongoClient;
use std::sync::atomic::AtomicU64;
use std::time::Duration;

const DEFAULT_MONGODB_URI: &str = "mongodb://127.0.0.1:27017";

static MONGODB_COLLECTION_COUNTER: AtomicU64 = AtomicU64::new(0);

/// Returns a validated MongoDB URI from `MONGODB_URI` or the local default.
pub fn mongodb_uri_from_env() -> Result<String, LiveServiceError> {
    let mongodb_uri =
        std::env::var("MONGODB_URI").unwrap_or_else(|_| DEFAULT_MONGODB_URI.to_string());
    validate_mongodb_uri(&mongodb_uri)?;
    Ok(mongodb_uri)
}

/// Returns a validated MongoDB URI after confirming the server is reachable synchronously.
pub fn ready_mongodb_uri_sync() -> Result<String, LiveServiceError> {
    let mongodb_uri = mongodb_uri_from_env()?;
    wait_for_mongodb_ready_sync(&mongodb_uri)?;
    Ok(mongodb_uri)
}

/// Drops a MongoDB collection used by a live test if it exists.
pub fn drop_mongodb_collection_sync(
    mongodb_uri: &str,
    db_name: &str,
    collection_name: &str,
) -> Result<(), LiveServiceError> {
    let client = mongodb_probe_client(mongodb_uri, SERVICE_PROBE_ATTEMPT_TIMEOUT)?;
    let probe = ServiceProbe::new("mongodb", mongodb_uri, ProbeSchedule::live_defaults());
    let database = client.database(db_name);
    let collections = database
        .list_collection_names()
        .run()
        .map_err(|error| probe.unavailable(format!("collection listing failed: {error}")))?;

    if !collections.iter().any(|name| name == collection_name) {
        return Ok(());
    }

    database
        .collection::<Document>(collection_name)
        .drop()
        .run()
        .map_err(|error| probe.unavailable(format!("collection drop failed: {error}")))?;
    Ok(())
}

/// Builds a unique MongoDB collection name for a test run.
pub fn unique_mongodb_collection_name(prefix: &str) -> String {
    let suffix = unique_name_suffix(&MONGODB_COLLECTION_COUNTER);
    format!("rurr_mongo_{prefix}_{suffix}")
}

fn wait_for_mongodb_ready_sync_with_schedule(
    mongodb_uri: &str,
    schedule: ProbeSchedule,
) -> Result<(), LiveServiceError> {
    let client = mongodb_probe_client(mongodb_uri, schedule.attempt_timeout)?;
    let probe = ServiceProbe::new("mongodb", mongodb_uri, schedule);
    probe.retry_sync(|| probe_mongodb_sync(&client))
}

/// Waits synchronously for a MongoDB server to accept commands at `mongodb_uri`.
pub fn wait_for_mongodb_ready_sync(mongodb_uri: &str) -> Result<(), LiveServiceError> {
    wait_for_mongodb_ready_sync_with_schedule(mongodb_uri, ProbeSchedule::live_defaults())
}

fn validate_mongodb_uri(mongodb_uri: &str) -> Result<(), LiveServiceError> {
    let probe = ServiceProbe::new("mongodb", mongodb_uri, ProbeSchedule::live_defaults());
    MongoClient::with_uri_str(mongodb_uri).map_err(|error| probe.invalid(error.to_string()))?;
    Ok(())
}

fn mongodb_probe_client(
    mongodb_uri: &str,
    attempt_timeout: Duration,
) -> Result<MongoClient, LiveServiceError> {
    let probe_uri = mongodb_uri_with_probe_timeouts(mongodb_uri, attempt_timeout);
    let probe = ServiceProbe::new("mongodb", mongodb_uri, ProbeSchedule::live_defaults());
    MongoClient::with_uri_str(&probe_uri).map_err(|error| probe.invalid(error.to_string()))
}

fn mongodb_uri_with_probe_timeouts(mongodb_uri: &str, attempt_timeout: Duration) -> String {
    let timeout_ms = attempt_timeout.as_millis().max(1);
    let mut parameters = Vec::new();

    if !mongodb_uri.contains("serverSelectionTimeoutMS=") {
        parameters.push(format!("serverSelectionTimeoutMS={timeout_ms}"));
    }
    if !mongodb_uri.contains("connectTimeoutMS=") {
        parameters.push(format!("connectTimeoutMS={timeout_ms}"));
    }
    if parameters.is_empty() {
        return mongodb_uri.to_string();
    }

    let separator = if mongodb_uri.contains('?') { '&' } else { '?' };
    format!("{mongodb_uri}{separator}{}", parameters.join("&"))
}

fn probe_mongodb_sync(client: &MongoClient) -> Result<(), String> {
    client
        .database("admin")
        .run_command(doc! { "ping": 1 })
        .run()
        .map(|_| ())
        .map_err(|error| format!("ping failed: {error}"))
}
