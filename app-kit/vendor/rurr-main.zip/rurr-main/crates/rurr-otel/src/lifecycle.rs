use crate::convert_to_otel_attribute;
use crate::opentelemetry::global::{self, BoxedTracer};
use crate::opentelemetry::trace::{
    Span as _, SpanContext as OtelSpanContext, Status, TraceContextExt, Tracer as _,
};
use crate::opentelemetry::{Context, ContextGuard, KeyValue, Value as OtelValue};
use indexmap::IndexMap;
use rurr_core::lifecycle::{
    AsyncLifecycleContextPropagator, AsyncLifecyclePollContext, AsyncLifecyclePollGuard,
    ExecuteCallContext, LifecycleAdapterSet, LifecycleError, LifecycleExecutionMode,
    PostStepContext, PreStepContext, SpanContext, SyncLifecycleAdapter, VisibilityRootContext,
};
use rurr_core::{application::Tracker, visibility::ActionSpan};
use serde_json::Value;
use std::cell::{Cell, RefCell};
use std::fmt;
use std::sync::Arc;

mod keys;
mod registry;
mod span_slot;
mod state;

use keys::{ActionRootKey, ActiveSpanKey, OtelContextGuardKey, StepKey};
pub use registry::{OtelTrackingRegistry, RurrTrackingSpanProcessor};
use span_slot::{SpanKind, SpanSlot};
use state::{ExecuteMetadata, OtelLifecycleState, RejectedSpanSlot};

const RURR_OTEL_LIFECYCLE_TRACER: &str = "rurr-otel.lifecycle";

thread_local! {
    static RURR_OWNED_SPAN_START_DEPTH: Cell<usize> = const { Cell::new(0) };
    static ACTIVE_OTEL_CONTEXT_GUARDS: RefCell<Vec<(OtelContextGuardKey, ContextGuard)>> =
        const { RefCell::new(Vec::new()) };
}

struct RurrOwnedSpanStartGuard;

impl RurrOwnedSpanStartGuard {
    fn enter() -> Self {
        RURR_OWNED_SPAN_START_DEPTH.with(|depth| depth.set(depth.get() + 1));
        Self
    }
}

impl Drop for RurrOwnedSpanStartGuard {
    fn drop(&mut self) {
        RURR_OWNED_SPAN_START_DEPTH.with(|depth| {
            let current = depth.get();
            depth.set(current.saturating_sub(1));
        });
    }
}

fn rurr_owned_span_start_active() -> bool {
    RURR_OWNED_SPAN_START_DEPTH.with(|depth| depth.get() > 0)
}

fn attach_otel_context(key: OtelContextGuardKey, context: Context) {
    let guard = context.attach();
    ACTIVE_OTEL_CONTEXT_GUARDS.with(|guards| guards.borrow_mut().push((key, guard)));
}

fn detach_otel_context(key: &OtelContextGuardKey) -> bool {
    ACTIVE_OTEL_CONTEXT_GUARDS.with(|guards| {
        let mut guards = guards.borrow_mut();
        match guards.iter().rposition(|(active_key, _)| active_key == key) {
            Some(index) => {
                guards.remove(index);
                true
            }
            None => false,
        }
    })
}

#[cfg(test)]
thread_local! {
    static BEFORE_OTEL_ATTRIBUTE_SET: RefCell<Option<Box<dyn FnMut()>>> =
        const { RefCell::new(None) };
}

#[cfg(test)]
struct OtelAttributeSetProbeGuard;

#[cfg(test)]
impl Drop for OtelAttributeSetProbeGuard {
    fn drop(&mut self) {
        BEFORE_OTEL_ATTRIBUTE_SET.with(|probe| {
            probe.borrow_mut().take();
        });
    }
}

#[cfg(test)]
fn set_before_otel_attribute_set(callback: impl FnMut() + 'static) -> OtelAttributeSetProbeGuard {
    BEFORE_OTEL_ATTRIBUTE_SET.with(|probe| {
        let previous = probe.borrow_mut().replace(Box::new(callback));
        assert!(previous.is_none(), "OTEL attribute probe already installed");
    });
    OtelAttributeSetProbeGuard
}

#[cfg(test)]
fn before_otel_attribute_set() {
    BEFORE_OTEL_ATTRIBUTE_SET.with(|probe| {
        if let Some(callback) = probe.borrow_mut().as_mut() {
            callback();
        }
    });
}

#[cfg(test)]
fn has_active_otel_context_guard() -> bool {
    ACTIVE_OTEL_CONTEXT_GUARDS.with(|guards| !guards.borrow().is_empty())
}

#[cfg(test)]
fn active_otel_context_guard_count() -> usize {
    ACTIVE_OTEL_CONTEXT_GUARDS.with(|guards| guards.borrow().len())
}

#[derive(Clone)]
struct OtelAsyncLifecycleContextPropagator {
    adapter: Arc<OtelLifecycleAdapter>,
}

impl OtelAsyncLifecycleContextPropagator {
    fn new(adapter: Arc<OtelLifecycleAdapter>) -> Self {
        Self { adapter }
    }
}

struct OtelPollContext {
    context: Context,
}

impl AsyncLifecyclePollContext for OtelPollContext {
    fn enter(&self) -> Box<dyn AsyncLifecyclePollGuard + '_> {
        Box::new(self.context.clone().attach())
    }
}

impl OtelAsyncLifecycleContextPropagator {
    fn poll_context(context: Context) -> Arc<dyn AsyncLifecyclePollContext> {
        Arc::new(OtelPollContext { context })
    }
}

impl AsyncLifecycleContextPropagator for OtelAsyncLifecycleContextPropagator {
    fn step_poll_context(
        &self,
        context: &PreStepContext,
    ) -> Option<Arc<dyn AsyncLifecyclePollContext>> {
        self.adapter
            .step_context_for_pre(context)
            .map(Self::poll_context)
    }

    fn span_poll_context(
        &self,
        context: &SpanContext,
    ) -> Option<Arc<dyn AsyncLifecyclePollContext>> {
        self.adapter
            .span_context_for(context)
            .map(Self::poll_context)
    }
}

/// Errors observed by the OTEL tracking bridge while mirroring spans.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OtelTrackingError {
    /// A started SDK span did not expose exportable span data to the processor.
    MissingSpanData,
    /// A tracking lifecycle hook failed while mirroring an OTEL span.
    TrackerHookFailed {
        /// Lifecycle phase that failed.
        phase: &'static str,
        /// Span id that was being mirrored.
        span_id: String,
        /// Hook failure message.
        message: String,
    },
    /// An OTEL span attribute value used an SDK shape Rurr does not yet support for tracking.
    UnsupportedAttributeValue {
        /// Span id that owned the unsupported attribute.
        span_id: String,
        /// Attribute key whose value could not be mirrored.
        key: String,
    },
    /// A lifecycle span could not detach its current-context guard.
    MissingContextGuard {
        /// Guard key that could not be detached.
        key: String,
    },
}

impl fmt::Display for OtelTrackingError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::MissingSpanData => write!(f, "otel span did not expose exportable span data"),
            Self::TrackerHookFailed {
                phase,
                span_id,
                message,
            } => write!(
                f,
                "otel tracking hook {phase} failed for mirrored span {span_id}: {message}"
            ),
            Self::UnsupportedAttributeValue { span_id, key } => write!(
                f,
                "otel tracking bridge does not support attribute {key} on span {span_id}"
            ),
            Self::MissingContextGuard { key } => {
                write!(f, "otel context guard was not active for {key}")
            }
        }
    }
}

impl std::error::Error for OtelTrackingError {}

/// Owner object that wires OTEL lifecycle export and tracking mirroring together.
///
/// Use one bridge to create the lifecycle hooks installed on an application and
/// the span processor installed on the OTEL tracer provider. The hook set also
/// carries the async lifecycle context propagator that keeps child spans
/// attached to the current Rurr step or visibility span after `.await`.
///
/// # Examples
///
/// ```
/// use rurr_core::tracking::LocalTrackingClient;
/// use rurr_core::Tracker;
/// use rurr_otel::OtelTrackingBridge;
/// use std::sync::Arc;
/// use std::time::{SystemTime, UNIX_EPOCH};
///
/// let suffix = SystemTime::now().duration_since(UNIX_EPOCH)?.as_nanos();
/// let storage_dir = std::env::temp_dir().join(format!("rurr-otel-doc-{suffix}"));
/// let tracker: Arc<dyn Tracker> =
///     Arc::new(LocalTrackingClient::new("docs-project", &storage_dir)?);
///
/// let bridge = OtelTrackingBridge::new(tracker);
/// let hooks = bridge.lifecycle_hooks();
/// assert_eq!(hooks.sync_adapters().len(), 1);
/// assert!(hooks.async_adapters().is_empty());
/// assert!(bridge.take_errors().is_empty());
///
/// let _ = std::fs::remove_dir_all(storage_dir);
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
#[derive(Clone)]
pub struct OtelTrackingBridge {
    registry: Arc<OtelTrackingRegistry>,
}

impl OtelTrackingBridge {
    /// Creates a bridge that mirrors external OTEL child spans into `tracker`.
    pub fn new(tracker: Arc<dyn Tracker>) -> Self {
        Self {
            registry: Arc::new(OtelTrackingRegistry::new(tracker)),
        }
    }

    /// Creates the lifecycle hook set needed for OTEL span and context propagation.
    ///
    /// The returned set contains the sync lifecycle adapter plus a provider-
    /// neutral async lifecycle context propagator. Install this set with
    /// `ApplicationBuilder::with_hooks`.
    pub fn lifecycle_hooks(&self) -> LifecycleAdapterSet {
        let adapter = Arc::new(OtelLifecycleAdapter::from_parts(
            None,
            Some(Arc::clone(&self.registry)),
        ));
        let sync_adapter: Arc<dyn SyncLifecycleAdapter> = adapter.clone();
        LifecycleAdapterSet::new(vec![sync_adapter], Vec::new())
            .with_async_lifecycle_context_propagator(Arc::new(
                OtelAsyncLifecycleContextPropagator::new(adapter),
            ))
    }

    /// Creates a tracking span processor connected to this bridge.
    pub fn span_processor(&self) -> RurrTrackingSpanProcessor {
        RurrTrackingSpanProcessor::new(Arc::clone(&self.registry))
    }

    /// Returns and clears bridge errors observed since the previous call.
    pub fn take_errors(&self) -> Vec<OtelTrackingError> {
        self.registry.take_errors()
    }
}

/// Lifecycle adapter that emits Rurr execution and step activity through OpenTelemetry.
///
/// The adapter records execution, step, custom span, and stream activity on the
/// sync lifecycle lane. It does not own exporter setup; install a provider with
/// the helpers in this crate before running the application. The adapter keeps
/// lock scopes short and never awaits while holding internal state.
pub struct OtelLifecycleAdapter {
    tracer_override: Option<BoxedTracer>,
    tracking_registry: Option<Arc<OtelTrackingRegistry>>,
    state: OtelLifecycleState,
}

struct VisibilityTrackingSeed {
    action_span: ActionSpan,
    app_id: String,
    partition_key: Option<String>,
}

impl Default for OtelLifecycleAdapter {
    fn default() -> Self {
        Self::new()
    }
}

impl OtelLifecycleAdapter {
    /// Creates an adapter that uses the current global tracer provider.
    pub fn new() -> Self {
        Self::from_parts(None, None)
    }

    fn from_parts(
        tracer_override: Option<BoxedTracer>,
        tracking_registry: Option<Arc<OtelTrackingRegistry>>,
    ) -> Self {
        Self {
            tracer_override,
            tracking_registry,
            state: OtelLifecycleState::new(),
        }
    }

    fn sequence_id_to_attr(sequence_id: u64) -> OtelValue {
        match i64::try_from(sequence_id) {
            Ok(value) => OtelValue::I64(value),
            Err(_) => OtelValue::String(sequence_id.to_string().into()),
        }
    }

    fn start_slot(
        &self,
        kind: SpanKind,
        span_name: String,
        parent: Option<OtelSpanContext>,
        attributes: Vec<KeyValue>,
        execution_mode: LifecycleExecutionMode,
    ) -> SpanSlot {
        let _owned_span_guard = RurrOwnedSpanStartGuard::enter();
        let mut span = if let Some(parent_context) = parent {
            let parent_cx = Context::new().with_remote_span_context(parent_context);
            match self.tracer_override.as_ref() {
                Some(tracer) => tracer.start_with_context(span_name, &parent_cx),
                None => global::tracer(RURR_OTEL_LIFECYCLE_TRACER)
                    .start_with_context(span_name, &parent_cx),
            }
        } else {
            match self.tracer_override.as_ref() {
                Some(tracer) => tracer.start(span_name),
                None => global::tracer(RURR_OTEL_LIFECYCLE_TRACER).start(span_name),
            }
        };
        for attribute in attributes {
            span.set_attribute(attribute);
        }
        let span_context = span.span_context().clone();
        let context = Context::current_with_span(span);
        let mut slot = SpanSlot::new(kind, context, span_context);
        if execution_mode == LifecycleExecutionMode::Sync {
            slot.attach_sync_guard();
        }
        slot
    }

    fn required_attributes(
        app_id: &str,
        partition_key: &str,
        sequence_id: u64,
        action: &str,
    ) -> Vec<KeyValue> {
        vec![
            KeyValue::new("rurr.app_id", app_id.to_string()),
            KeyValue::new("rurr.partition_key", partition_key.to_string()),
            KeyValue::new("rurr.sequence_id", Self::sequence_id_to_attr(sequence_id)),
            KeyValue::new("rurr.action", action.to_string()),
        ]
    }

    fn partition_key_for_tracking(partition_key: &str) -> Option<String> {
        (!partition_key.is_empty()).then(|| partition_key.to_string())
    }

    fn record_missing_context_guard(&self, key: OtelContextGuardKey) {
        if let Some(registry) = &self.tracking_registry {
            registry.record_error(OtelTrackingError::MissingContextGuard {
                key: format!("{key:?}"),
            });
        }
    }

    fn finish_slot(&self, slot: SpanSlot) {
        slot.finish(self.tracking_registry.as_deref(), |guard_key| {
            self.record_missing_context_guard(guard_key);
        });
    }

    fn finish_rejected_slot(&self, rejected: Box<RejectedSpanSlot>) -> LifecycleError {
        let (slot, error) = (*rejected).into_parts();
        self.finish_slot(slot);
        error
    }

    fn step_context_for_pre(&self, context: &PreStepContext) -> Option<Context> {
        self.state.step_context_for_pre(context)
    }

    fn span_context_for(&self, context: &SpanContext) -> Option<Context> {
        self.state.span_context_for(context)
    }

    fn visibility_root_span_parent_core(
        &self,
        context: &VisibilityRootContext,
    ) -> Option<ActionSpan> {
        self.tracking_registry.as_ref().map(|registry| {
            registry.ensure_action_root(
                ActionRootKey::new(context.app_id(), context.sequence_id()),
                context.action_name().to_string(),
                format!("step:{}", context.action_name()),
                context.sequence_id(),
                context.app_id().to_string(),
                context.partition_key().map(str::to_string),
            )
        })
    }

    fn seed_step_tracking_span(
        &self,
        metadata: &ExecuteMetadata,
        context: &PreStepContext,
        span_context: &OtelSpanContext,
    ) {
        if let Some(registry) = &self.tracking_registry {
            let root = registry.ensure_action_root(
                ActionRootKey::new(metadata.app_id.clone(), context.sequence_id()),
                metadata.action.clone(),
                format!("step:{}", context.action_name()),
                context.sequence_id(),
                metadata.app_id.clone(),
                Self::partition_key_for_tracking(&metadata.partition_key),
            );
            registry.seed_span(
                span_context,
                root,
                metadata.app_id.clone(),
                Self::partition_key_for_tracking(&metadata.partition_key),
            );
        }
    }

    fn prepare_visibility_tracking_seed(
        &self,
        metadata: &ExecuteMetadata,
        context: &SpanContext,
    ) -> Result<Option<VisibilityTrackingSeed>, LifecycleError> {
        if self.tracking_registry.is_none() {
            return Ok(None);
        }

        let action_span = context.action_span().cloned().ok_or_else(|| {
            LifecycleError::hook_failed(
                "pre_start_span",
                format!(
                    "missing ActionSpan handle for tracked visibility span {}",
                    context.span_id()
                ),
            )
        })?;

        Ok(Some(VisibilityTrackingSeed {
            action_span,
            app_id: metadata.app_id.clone(),
            partition_key: Self::partition_key_for_tracking(&metadata.partition_key),
        }))
    }

    fn seed_visibility_tracking_span(
        &self,
        seed: Option<VisibilityTrackingSeed>,
        span_context: &OtelSpanContext,
    ) {
        let (Some(registry), Some(seed)) = (&self.tracking_registry, seed) else {
            return;
        };
        registry.seed_span(
            span_context,
            seed.action_span,
            seed.app_id,
            seed.partition_key,
        );
    }

    fn pre_execute_call_core(&self, context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.state.begin_execute(context);
        Ok(())
    }

    fn post_execute_call_core(&self, context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        let root_key = self.state.finish_execute(context);
        if let Some(registry) = &self.tracking_registry {
            registry.forget_action_root(&root_key);
        }
        Ok(())
    }

    fn pre_start_span_core(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        let metadata = self.state.metadata_for_span(context)?;
        let mut attributes = Self::required_attributes(
            &metadata.app_id,
            &metadata.partition_key,
            context.sequence_id(),
            &metadata.action,
        );
        attributes.push(KeyValue::new("rurr.span_id", context.span_id().to_string()));

        let span_key = ActiveSpanKey::from_context(context);
        self.state
            .ensure_visibility_span_vacant(&span_key, "pre_start_span")?;
        let tracking_seed = self.prepare_visibility_tracking_seed(&metadata, context)?;
        let parent_context = context
            .parent_span_id()
            .and_then(|parent_span_id| self.state.parent_span_context(context, parent_span_id));
        let slot = self.start_slot(
            SpanKind::Visibility(span_key.clone()),
            context.span_name().unwrap_or(context.span_id()).to_string(),
            parent_context,
            attributes,
            context.execution_mode(),
        );
        let span_context = slot.span_context().clone();
        self.state
            .insert_visibility_span(span_key, slot, "pre_start_span")
            .map_err(|rejected| self.finish_rejected_slot(rejected))?;
        self.seed_visibility_tracking_span(tracking_seed, &span_context);
        Ok(())
    }

    fn post_end_span_core(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        let span_key = ActiveSpanKey::from_context(context);
        let span = self
            .state
            .take_visibility_span(&span_key, "post_end_span")?;
        self.finish_slot(span);
        Ok(())
    }

    fn log_attributes_core(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        let span_key = ActiveSpanKey::from_context(context);
        let span_context = self
            .state
            .visibility_span_context(&span_key, "log_attributes")?;
        for (key, value) in attributes {
            if let Some(otel_value) = convert_to_otel_attribute(value) {
                #[cfg(test)]
                before_otel_attribute_set();
                span_context
                    .span()
                    .set_attribute(KeyValue::new(key.clone(), otel_value));
            }
        }
        Ok(())
    }

    fn pre_run_step_core(&self, context: &PreStepContext) -> Result<(), LifecycleError> {
        let step_key = StepKey::from_pre(context).ok_or_else(|| {
            LifecycleError::hook_failed(
                "pre_run_step",
                format!(
                    "missing step app id for sequence {} action {}",
                    context.sequence_id(),
                    context.action_name()
                ),
            )
        })?;
        let metadata = self.state.metadata_for_execution(
            context.app_id(),
            context.sequence_id(),
            context.action_name(),
        )?;
        self.state
            .ensure_step_span_vacant(&step_key, "pre_run_step")?;
        let attributes = Self::required_attributes(
            &metadata.app_id,
            &metadata.partition_key,
            context.sequence_id(),
            &metadata.action,
        );
        let slot = self.start_slot(
            SpanKind::Step(step_key.clone()),
            format!("step:{}", context.action_name()),
            None,
            attributes,
            context.execution_mode(),
        );
        let span_context = slot.span_context().clone();
        self.state
            .insert_step_span(step_key, slot, "pre_run_step")
            .map_err(|rejected| self.finish_rejected_slot(rejected))?;
        self.seed_step_tracking_span(&metadata, context, &span_context);
        Ok(())
    }

    fn post_run_step_core(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        let step_key = StepKey::from_post(context).ok_or_else(|| {
            LifecycleError::hook_failed(
                "post_run_step",
                format!(
                    "missing step app id for sequence {} action {}",
                    context.sequence_id(),
                    context.action_name()
                ),
            )
        })?;
        let root_key = ActionRootKey::new(step_key.app_id.clone(), step_key.sequence_id);
        let step_span = self.state.take_step_span(&step_key, "post_run_step")?;

        if let Some(result) = context.result() {
            step_span.context().span().set_attribute(KeyValue::new(
                "rurr.result",
                serialize_step_payload_json("rurr.result", result)?,
            ));
        }
        let is_critical_abort = context.result().is_none()
            && context.state().is_none()
            && context.exception().is_none();
        if let Some(exception) = context.exception() {
            step_span
                .context()
                .span()
                .set_attribute(KeyValue::new("rurr.exception", exception.to_string()));
            step_span
                .context()
                .span()
                .set_status(Status::error(exception.to_string()));
        } else if is_critical_abort {
            step_span
                .context()
                .span()
                .set_status(Status::error("critical_abort"));
        } else {
            step_span.context().span().set_status(Status::Ok);
        }
        if let Some(state) = context.state() {
            step_span.context().span().set_attribute(KeyValue::new(
                "rurr.state",
                serialize_step_payload_json("rurr.state", &state.get_all())?,
            ));
        }

        self.finish_slot(step_span);
        if let Some(registry) = &self.tracking_registry {
            registry.forget_action_root(&root_key);
        }
        Ok(())
    }
}

impl SyncLifecycleAdapter for OtelLifecycleAdapter {
    fn visibility_root_span_parent(&self, context: &VisibilityRootContext) -> Option<ActionSpan> {
        self.visibility_root_span_parent_core(context)
    }

    fn pre_execute_call(&self, context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.pre_execute_call_core(context)
    }

    fn post_execute_call(&self, context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.post_execute_call_core(context)
    }

    fn pre_start_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.pre_start_span_core(context)
    }

    fn post_end_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.post_end_span_core(context)
    }

    fn log_attributes(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        self.log_attributes_core(context, attributes)
    }

    fn pre_run_step(&self, context: &PreStepContext) -> Result<(), LifecycleError> {
        self.pre_run_step_core(context)
    }

    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.post_run_step_core(context)
    }
}

fn serialize_step_payload_json(
    field_name: &'static str,
    value: &IndexMap<String, Value>,
) -> Result<String, LifecycleError> {
    serde_json::to_string(value).map_err(|error| {
        LifecycleError::hook_failed(
            "post_run_step",
            format!("serialize {field_name} attribute: {error}"),
        )
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::opentelemetry::trace::{SpanId, TracerProvider as _};
    use crate::opentelemetry_sdk::trace::SdkTracerProvider;
    use rurr_core::application::Tracker;
    use rurr_core::lifecycle::ExecuteCallContext;
    use rurr_core::lifecycle::{
        AsyncLifecycleAdapter, AsyncLifecycleContextPropagator, LifecycleExecutionMode,
        SyncLifecycleAdapter, VisibilityRootContext,
    };
    use rurr_core::visibility::{trace_async, TraceOptions, TraceSpanHandle};
    use rurr_core::ActionTracer;
    use std::sync::{Arc, Mutex};
    use std::time::SystemTime;

    struct NoopTracker;

    impl SyncLifecycleAdapter for NoopTracker {}
    impl AsyncLifecycleAdapter for NoopTracker {}
    impl Tracker for NoopTracker {
        fn sync_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn SyncLifecycleAdapter>> {
            Some(self)
        }

        fn async_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn AsyncLifecycleAdapter>> {
            Some(self)
        }
    }

    #[test]
    fn registry_reuses_one_action_root_for_step_and_visibility_tracking() {
        const LIVE_PROOF: &str =
            "facade_otel_tracking_bridge_unifies_step_visibility_and_external_span_ids";
        let tracker: Arc<dyn Tracker> = Arc::new(NoopTracker);
        let registry = Arc::new(OtelTrackingRegistry::new(tracker));
        let adapter = OtelLifecycleAdapter::from_parts(None, Some(registry));
        let visibility_root = VisibilityRootContext::new("rurr-test-app", "count", 7)
            .with_partition_key("partition-a");

        let step_root = adapter
            .visibility_root_span_parent_core(&visibility_root)
            .expect("OTEL tracking bridge should allocate one canonical step root");
        let visibility_parent = adapter
            .visibility_root_span_parent_core(&visibility_root)
            .expect("OTEL tracking bridge should reuse the canonical step root");
        let visibility_span = visibility_parent.spawn("visibility-root");
        let direct_external_span = step_root.spawn("external-child");

        assert_eq!(
            step_root.uid(),
            "7:0",
            "non-live registry contract is proven by {LIVE_PROOF}"
        );
        assert_eq!(
            visibility_span.parent().map(|parent| parent.uid()).as_deref(),
            Some("7:0"),
            "root visibility spans must spawn from the canonical step root; strict live proof: {LIVE_PROOF}"
        );
        assert_eq!(
            visibility_span.uid(),
            "7:0.0",
            "visibility child allocation should share the step-root child counter; strict live proof: {LIVE_PROOF}"
        );
        assert_eq!(
            direct_external_span.uid(),
            "7:0.1",
            "direct external children should continue after visibility allocation from the same root; strict live proof: {LIVE_PROOF}"
        );
    }

    #[test]
    fn bridge_lifecycle_hooks_do_not_double_register_otel_step_adapters() {
        let tracker: Arc<dyn Tracker> = Arc::new(NoopTracker);
        let bridge = OtelTrackingBridge::new(tracker);
        let hooks = bridge.lifecycle_hooks();

        assert_eq!(hooks.sync_adapters().len(), 1);
        assert_eq!(hooks.async_adapters().len(), 0);
    }

    #[test]
    fn post_run_step_fails_closed_when_step_span_is_missing() {
        let adapter = OtelLifecycleAdapter::new();
        let context =
            PostStepContext::new("count", 42, 7, SystemTime::UNIX_EPOCH).with_app_id("app");

        let error = adapter
            .post_run_step_core(&context)
            .expect_err("post-step without pre-step should fail closed");

        assert_eq!(error.phase(), "post_run_step");
        assert!(
            error.message().contains("missing OTEL step span"),
            "missing step error should be explicit: {error}"
        );
    }

    #[test]
    fn visibility_span_hooks_fail_closed_when_span_is_missing() {
        let adapter = OtelLifecycleAdapter::new();
        let context = SpanContext::new("count", 42, "missing-span").with_app_id("app");
        let attributes = IndexMap::from([("key".to_string(), Value::from("value"))]);

        let attribute_error = adapter
            .log_attributes_core(&context, &attributes)
            .expect_err("attributes without pre_start_span should fail closed");
        assert_eq!(attribute_error.phase(), "log_attributes");
        assert!(
            attribute_error
                .message()
                .contains("missing OTEL visibility span"),
            "missing visibility span error should be explicit: {attribute_error}"
        );

        let end_error = adapter
            .post_end_span_core(&context)
            .expect_err("post_end_span without pre_start_span should fail closed");
        assert_eq!(end_error.phase(), "post_end_span");
        assert!(
            end_error.message().contains("missing OTEL visibility span"),
            "missing visibility span error should be explicit: {end_error}"
        );
    }

    #[test]
    fn log_attributes_keeps_visibility_span_registered_during_attribute_write() {
        let adapter = Arc::new(OtelLifecycleAdapter::new());
        let context = SpanContext::new("count", 42, "active-span")
            .with_app_id("app")
            .with_execution_mode(LifecycleExecutionMode::Async);
        adapter
            .pre_start_span_core(&context)
            .expect("pre-start should register visibility span");

        let probe_adapter = Arc::clone(&adapter);
        let probe_context = context.clone();
        let _probe = set_before_otel_attribute_set(move || {
            assert!(
                probe_adapter.span_context_for(&probe_context).is_some(),
                "attribute logging must not unregister an active visibility span"
            );
        });

        let attributes = IndexMap::from([("key".to_string(), Value::from("value"))]);
        adapter
            .log_attributes_core(&context, &attributes)
            .expect("attribute logging should preserve active span state");
        adapter
            .post_end_span_core(&context)
            .expect("span should still close after attribute logging");
    }

    #[test]
    fn duplicate_pre_run_step_does_not_replace_active_step_span() {
        let provider = SdkTracerProvider::builder().build();
        let adapter = OtelLifecycleAdapter::from_parts(
            Some(BoxedTracer::new(Box::new(
                provider.tracer("rurr-otel-duplicate-step-unit"),
            ))),
            None,
        );
        let execute_context = ExecuteCallContext::new("app", "", "count", 42);
        adapter
            .pre_execute_call_core(&execute_context)
            .expect("execute metadata should seed");
        let pre_context = PreStepContext::new("count", 42, 7, SystemTime::UNIX_EPOCH)
            .with_app_id("app")
            .with_execution_mode(LifecycleExecutionMode::Async);

        adapter
            .pre_run_step_core(&pre_context)
            .expect("first pre-step should start the active span");
        let first_span_id = adapter
            .state
            .step_context_for_pre(&pre_context)
            .expect("first pre-step should register a span")
            .span()
            .span_context()
            .span_id();

        let error = adapter
            .pre_run_step_core(&pre_context)
            .expect_err("duplicate pre-step should fail closed");

        assert_eq!(error.phase(), "pre_run_step");
        assert!(
            error.message().contains("duplicate OTEL step span"),
            "duplicate step error should be explicit: {error}"
        );
        assert_eq!(
            adapter
                .state
                .step_context_for_pre(&pre_context)
                .expect("duplicate pre-step must leave the original span registered")
                .span()
                .span_context()
                .span_id(),
            first_span_id,
            "duplicate pre-step must not replace the active span slot"
        );

        let post_context =
            PostStepContext::new("count", 42, 7, SystemTime::UNIX_EPOCH).with_app_id("app");
        adapter
            .post_run_step_core(&post_context)
            .expect("post-step should still close the original span");
        provider
            .shutdown()
            .expect("test tracer provider should shut down");
    }

    #[test]
    fn duplicate_pre_start_span_does_not_replace_active_visibility_span_or_leak_guard() {
        assert_eq!(
            active_otel_context_guard_count(),
            0,
            "test should start without an active OTEL context guard"
        );
        let provider = SdkTracerProvider::builder().build();
        let adapter = OtelLifecycleAdapter::from_parts(
            Some(BoxedTracer::new(Box::new(
                provider.tracer("rurr-otel-duplicate-visibility-unit"),
            ))),
            None,
        );
        let context = SpanContext::new("count", 42, "visibility-span")
            .with_app_id("app")
            .with_execution_mode(LifecycleExecutionMode::Sync);

        adapter
            .pre_start_span_core(&context)
            .expect("first visibility pre-hook should start the active span");
        let first_span_id = adapter
            .span_context_for(&context)
            .expect("first visibility pre-hook should register a span")
            .span()
            .span_context()
            .span_id();
        assert_eq!(
            active_otel_context_guard_count(),
            1,
            "sync visibility pre-hook should attach one active context guard"
        );

        let error = adapter
            .pre_start_span_core(&context)
            .expect_err("duplicate visibility pre-hook should fail closed");

        assert_eq!(error.phase(), "pre_start_span");
        assert!(
            error.message().contains("duplicate OTEL visibility span"),
            "duplicate visibility error should be explicit: {error}"
        );
        assert_eq!(
            adapter
                .span_context_for(&context)
                .expect("duplicate visibility pre-hook must leave the original span registered")
                .span()
                .span_context()
                .span_id(),
            first_span_id,
            "duplicate visibility pre-hook must not replace the active span slot"
        );
        assert_eq!(
            active_otel_context_guard_count(),
            1,
            "rejected duplicate visibility span must not leak a second context guard"
        );

        adapter
            .post_end_span_core(&context)
            .expect("post-span should still close the original span");
        assert_eq!(
            active_otel_context_guard_count(),
            0,
            "closing the original visibility span should detach its context guard"
        );
        provider
            .shutdown()
            .expect("test tracer provider should shut down");
    }

    #[tokio::test]
    async fn async_lifecycle_poll_context_uses_stored_step_context_without_thread_local_guard() {
        let tracker: Arc<dyn Tracker> = Arc::new(NoopTracker);
        let registry = Arc::new(OtelTrackingRegistry::new(tracker));
        let provider = SdkTracerProvider::builder().build();
        let adapter = Arc::new(OtelLifecycleAdapter::from_parts(
            Some(BoxedTracer::new(Box::new(
                provider.tracer("rurr-otel-step-unit"),
            ))),
            Some(Arc::clone(&registry)),
        ));
        let execute_context = ExecuteCallContext::new("app", "", "count", 42);
        adapter
            .pre_execute_call_core(&execute_context)
            .expect("execute metadata should seed");
        let pre_context = PreStepContext::new("count", 42, 42, SystemTime::UNIX_EPOCH)
            .with_app_id("app")
            .with_execution_mode(LifecycleExecutionMode::Async);

        adapter
            .pre_run_step_core(&pre_context)
            .expect("async pre-step should start step span");
        assert!(
            !has_active_otel_context_guard(),
            "async step pre-hooks must not rely on a thread-local ContextGuard"
        );
        let expected_span_id = adapter
            .state
            .step_context_for_pre(&pre_context)
            .expect("pre-step should store the active step span")
            .span()
            .span_context()
            .span_id();
        assert_ne!(
            expected_span_id,
            SpanId::INVALID,
            "test tracer provider should create a real step span id"
        );

        let observed_span_id = Arc::new(Mutex::new(SpanId::INVALID));

        let propagator = OtelAsyncLifecycleContextPropagator::new(Arc::clone(&adapter));
        let poll_context = propagator
            .step_poll_context(&pre_context)
            .expect("async pre-step should provide an OTEL poll context");
        {
            let _guard = poll_context.enter();
            *observed_span_id
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()) =
                Context::current().span().span_context().span_id();
        }

        assert_eq!(
            *observed_span_id
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()),
            expected_span_id,
            "async future polling should see the stored step OTEL context"
        );
        let post_context =
            PostStepContext::new("count", 42, 42, SystemTime::UNIX_EPOCH).with_app_id("app");
        adapter
            .post_run_step_core(&post_context)
            .expect("post-step should end the async step span");
        assert_eq!(
            registry.take_errors(),
            Vec::new(),
            "async steps must not try to detach a thread-local guard"
        );
        provider
            .shutdown()
            .expect("test tracer provider should shut down");
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn async_visibility_context_uses_poll_context_without_thread_local_guard() {
        let provider = SdkTracerProvider::builder().build();
        let adapter = Arc::new(OtelLifecycleAdapter::from_parts(
            Some(BoxedTracer::new(Box::new(
                provider.tracer("rurr-otel-visibility-unit"),
            ))),
            None,
        ));
        let execute_context =
            ExecuteCallContext::new("async-visibility-app", "partition-a", "count", 42);
        adapter
            .pre_execute_call_core(&execute_context)
            .expect("execute metadata should seed");
        let hooks = LifecycleAdapterSet::new(
            vec![adapter.clone() as Arc<dyn SyncLifecycleAdapter>],
            Vec::new(),
        )
        .with_async_lifecycle_context_propagator(Arc::new(
            OtelAsyncLifecycleContextPropagator::new(Arc::clone(&adapter)),
        ));
        let tracer = ActionTracer::new(
            "count",
            42,
            hooks,
            "async-visibility-app",
            Some("partition-a".to_string()),
        );
        let observed_span_id = Arc::new(Mutex::new(SpanId::INVALID));
        let observed_span_id_after_yield = Arc::clone(&observed_span_id);

        trace_async(
            &tracer,
            "async_visibility",
            &IndexMap::new(),
            &TraceOptions::new()
                .with_capture_inputs(false)
                .with_capture_outputs(false)
                .with_capture_auto_attributes(false),
            move |_span: TraceSpanHandle| {
                let observed_span_id = Arc::clone(&observed_span_id_after_yield);
                async move {
                    assert!(
                        !has_active_otel_context_guard(),
                        "async visibility spans must not rely on thread-local OTEL guards"
                    );
                    tokio::task::yield_now().await;
                    *observed_span_id
                        .lock()
                        .unwrap_or_else(|poisoned| poisoned.into_inner()) =
                        Context::current().span().span_context().span_id();
                    7_i32
                }
            },
        )
        .await
        .expect("async visibility trace should succeed");

        assert_ne!(
            *observed_span_id
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner()),
            SpanId::INVALID,
            "async visibility future polling should see the stored OTEL span context"
        );
        adapter
            .post_execute_call_core(&execute_context)
            .expect("execute metadata should clear");
        provider
            .shutdown()
            .expect("test tracer provider should shut down");
    }
}
