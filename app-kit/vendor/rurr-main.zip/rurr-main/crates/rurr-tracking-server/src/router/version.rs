use super::AppState;
use crate::schema::{burr_compat_version, VersionResponse};
use axum::routing::get;
use axum::{Json, Router};

/// Builds the version route mounted under `/api/v0`.
pub fn routes() -> Router<AppState> {
    Router::new().route("/version", get(version))
}

async fn version() -> Json<VersionResponse> {
    Json(VersionResponse {
        version: burr_compat_version().to_string(),
    })
}
