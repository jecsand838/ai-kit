use super::common::{prompt_from_state, response_item};
use super::outputs::{async_stream_outputs_from_source, materialize_async_response};
use super::sources::AsyncChunkSource;
use rurr_core::action::LocalAsyncStreamOutput;
use rurr_core::{ActionContext, ActionError, ActionKind, ActionResult, LocalAction, State};

#[derive(Clone)]
struct StreamingActionMeta<S> {
    name: Option<String>,
    source: S,
    reads: Vec<String>,
    writes: Vec<String>,
}

impl<S> StreamingActionMeta<S> {
    fn new(source: S) -> Self {
        Self {
            name: None,
            source,
            reads: vec!["prompt".to_string()],
            writes: vec!["response".to_string()],
        }
    }
}

impl<S: Clone> StreamingActionMeta<S> {
    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }

        let mut cloned = self.clone();
        cloned.name = Some(next_name);
        Ok(cloned)
    }
}

#[derive(Clone)]
pub(super) struct AsyncClassStreamingAction<S> {
    meta: StreamingActionMeta<S>,
}

impl<S: AsyncChunkSource> AsyncClassStreamingAction<S> {
    pub(super) fn new(source: S) -> Self {
        Self {
            meta: StreamingActionMeta::new(source),
        }
    }
}

impl<S: AsyncChunkSource> LocalAction for AsyncClassStreamingAction<S> {
    fn name(&self) -> Option<&str> {
        self.meta.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &self.meta.reads
    }

    fn writes(&self) -> &[String] {
        &self.meta.writes
    }

    fn kind(&self) -> ActionKind {
        ActionKind::Async
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        Ok(Self {
            meta: self.meta.with_name(name)?,
        })
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Err(ActionError::AsyncActionRequiresRunAsync)
    }

    async fn run_async(
        &self,
        state: &State,
        _ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        let response =
            materialize_async_response(&self.meta.source, &prompt_from_state(state)).await?;
        Ok(ActionResult::new(
            response_item(&response),
            response_item(&response),
        ))
    }

    fn stream_run_async(&self, state: State, _ctx: ActionContext) -> LocalAsyncStreamOutput {
        let prompt = prompt_from_state(&state);
        Box::pin(async_stream_outputs_from_source(
            self.meta.source.clone(),
            state,
            prompt,
        ))
    }
}
