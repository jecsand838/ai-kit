use super::dir::AnchoredDir;
use super::dir_errors::{
    child_alias_error, child_already_exists_error, child_directory_missing_error,
    child_non_file_error, child_open_error,
};
use super::kernel::{self, DirectChildPathType};
use super::path::{validate_descendant_segments, validate_path_segment};
use fs2::FileExt;
use serde::{de::DeserializeOwned, Serialize};
use std::ffi::{OsStr, OsString};
use std::io::{self, Read, Write};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FileLockMode {
    Shared,
    Exclusive,
}

impl FileLockMode {
    pub(crate) fn lock(self, file: &std::fs::File) -> io::Result<()> {
        match self {
            Self::Shared => file.lock_shared(),
            Self::Exclusive => file.lock_exclusive(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExactChildFileAccessMode {
    ReadOnly,
    ReadWrite,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExactChildFileMissingBehavior {
    OptionalMissing,
    MustExist,
    CreateIfMissing,
    CreateNew,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ExactChildFileOpenOptions {
    pub access_mode: ExactChildFileAccessMode,
    pub lock_mode: FileLockMode,
    pub missing_behavior: ExactChildFileMissingBehavior,
}

impl ExactChildFileOpenOptions {
    pub const fn shared_read_optional() -> Self {
        Self {
            access_mode: ExactChildFileAccessMode::ReadOnly,
            lock_mode: FileLockMode::Shared,
            missing_behavior: ExactChildFileMissingBehavior::OptionalMissing,
        }
    }

    pub const fn shared_read_existing() -> Self {
        Self {
            access_mode: ExactChildFileAccessMode::ReadOnly,
            lock_mode: FileLockMode::Shared,
            missing_behavior: ExactChildFileMissingBehavior::MustExist,
        }
    }

    pub const fn exclusive_read_write_existing() -> Self {
        Self {
            access_mode: ExactChildFileAccessMode::ReadWrite,
            lock_mode: FileLockMode::Exclusive,
            missing_behavior: ExactChildFileMissingBehavior::MustExist,
        }
    }

    pub const fn exclusive_read_write_create_if_missing() -> Self {
        Self {
            access_mode: ExactChildFileAccessMode::ReadWrite,
            lock_mode: FileLockMode::Exclusive,
            missing_behavior: ExactChildFileMissingBehavior::CreateIfMissing,
        }
    }

    pub const fn exclusive_read_write_create_new() -> Self {
        Self {
            access_mode: ExactChildFileAccessMode::ReadWrite,
            lock_mode: FileLockMode::Exclusive,
            missing_behavior: ExactChildFileMissingBehavior::CreateNew,
        }
    }

    fn validate(self, scope_name: &'static str, kind: &str, raw: &str) -> io::Result<()> {
        match (self.access_mode, self.lock_mode, self.missing_behavior) {
            (
                ExactChildFileAccessMode::ReadOnly,
                _,
                ExactChildFileMissingBehavior::CreateIfMissing
                | ExactChildFileMissingBehavior::CreateNew,
            ) => Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!(
                    "{kind} '{raw}' cannot create a missing file while opening read-only within the configured {scope_name}"
                ),
            )),
            (ExactChildFileAccessMode::ReadWrite, FileLockMode::Shared, _) => Err(io::Error::new(
                io::ErrorKind::InvalidInput,
                format!(
                    "{kind} '{raw}' cannot open read-write with a shared lock within the configured {scope_name}"
                ),
            )),
            _ => Ok(()),
        }
    }
}

impl AnchoredDir {
    pub fn with_locked_child_file<R, E, F>(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
        options: ExactChildFileOpenOptions,
        f: F,
    ) -> Result<Option<R>, E>
    where
        E: From<io::Error>,
        F: FnOnce(&mut std::fs::File) -> Result<R, E>,
    {
        options.validate(scope_name, kind, raw).map_err(E::from)?;
        validate_path_segment(kind, raw).map_err(E::from)?;
        self.revalidate().map_err(E::from)?;
        with_locked_exact_file(
            options,
            || open_child_file(self, scope_name, kind, raw, options),
            f,
        )
    }

    pub fn with_locked_descendant_file<R, E, F>(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
        options: ExactChildFileOpenOptions,
        f: F,
    ) -> Result<Option<R>, E>
    where
        E: From<io::Error>,
        F: FnOnce(&mut std::fs::File) -> Result<R, E>,
    {
        let segments = validate_descendant_segments(kind, raw).map_err(E::from)?;
        options.validate(scope_name, kind, raw).map_err(E::from)?;
        self.revalidate().map_err(E::from)?;
        with_locked_exact_file(
            options,
            || open_descendant_file(self, scope_name, kind, raw, &segments, options),
            f,
        )
    }

    pub fn child_file_exists(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<bool> {
        self.with_locked_child_file::<_, io::Error, _>(
            scope_name,
            kind,
            raw,
            ExactChildFileOpenOptions::shared_read_optional(),
            |_file| Ok(()),
        )
        .map(|result| result.is_some())
    }

    pub fn read_optional_child_to_string(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<Option<String>> {
        self.with_locked_child_file::<_, io::Error, _>(
            scope_name,
            kind,
            raw,
            ExactChildFileOpenOptions::shared_read_optional(),
            |file| {
                let mut body = String::new();
                file.read_to_string(&mut body)?;
                Ok(body)
            },
        )
    }

    pub fn read_required_child_to_string(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<String> {
        self.with_locked_child_file::<_, io::Error, _>(
            scope_name,
            kind,
            raw,
            ExactChildFileOpenOptions::shared_read_existing(),
            |file| {
                let mut body = String::new();
                file.read_to_string(&mut body)?;
                Ok(body)
            },
        )
        .and_then(|result| result.ok_or_else(|| missing_required_file_error(scope_name, kind, raw)))
    }

    pub fn read_optional_json_child<T: DeserializeOwned>(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<Option<T>> {
        let Some(body) = self.read_optional_child_to_string(scope_name, kind, raw)? else {
            return Ok(None);
        };
        let value = serde_json::from_str(&body).map_err(|error| {
            io::Error::new(
                io::ErrorKind::InvalidData,
                format!("deserialize json: {error}"),
            )
        })?;
        Ok(Some(value))
    }

    pub fn read_required_json_child<T: DeserializeOwned>(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<T> {
        let body = self.read_required_child_to_string(scope_name, kind, raw)?;
        serde_json::from_str(&body).map_err(|error| {
            io::Error::new(
                io::ErrorKind::InvalidData,
                format!("deserialize json: {error}"),
            )
        })
    }

    pub fn read_required_descendant_bytes(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<Vec<u8>> {
        self.with_locked_descendant_file::<_, io::Error, _>(
            scope_name,
            kind,
            raw,
            ExactChildFileOpenOptions::shared_read_existing(),
            |file| {
                let mut bytes = Vec::new();
                file.read_to_end(&mut bytes)?;
                Ok(bytes)
            },
        )
        .and_then(|result| result.ok_or_else(|| missing_required_file_error(scope_name, kind, raw)))
    }

    pub fn write_json_if_missing_child<T: Serialize>(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
        value: &T,
    ) -> io::Result<bool> {
        let payload = serde_json::to_vec(value).map_err(|error| {
            io::Error::new(
                io::ErrorKind::InvalidData,
                format!("serialize json: {error}"),
            )
        })?;

        match self.with_locked_child_file::<_, io::Error, _>(
            scope_name,
            kind,
            raw,
            ExactChildFileOpenOptions::exclusive_read_write_create_new(),
            |file| {
                file.write_all(&payload)?;
                file.flush()?;
                Ok(())
            },
        ) {
            Ok(_) => Ok(true),
            Err(error) if error.kind() == io::ErrorKind::AlreadyExists => Ok(false),
            Err(error) => Err(error),
        }
    }
}

fn missing_required_file_error(scope_name: &'static str, kind: &str, raw: &str) -> io::Error {
    io::Error::new(
        io::ErrorKind::NotFound,
        format!("missing required {kind} '{raw}' within the configured {scope_name}"),
    )
}

fn with_locked_exact_file<R, E, F>(
    options: ExactChildFileOpenOptions,
    open_file: impl FnOnce() -> io::Result<Option<std::fs::File>>,
    f: F,
) -> Result<Option<R>, E>
where
    E: From<io::Error>,
    F: FnOnce(&mut std::fs::File) -> Result<R, E>,
{
    let mut file = match open_file() {
        Ok(Some(file)) => file,
        Ok(None) => return Ok(None),
        Err(error) => return Err(E::from(error)),
    };
    options.lock_mode.lock(&file).map_err(E::from)?;

    let result = f(&mut file);
    let unlock_result = file.unlock().map_err(E::from);
    match (result, unlock_result) {
        (Err(error), _) => Err(error),
        (Ok(_), Err(error)) => Err(error),
        (Ok(value), Ok(())) => Ok(Some(value)),
    }
}

fn open_child_file(
    parent: &AnchoredDir,
    scope_name: &'static str,
    kind: &str,
    raw: &str,
    options: ExactChildFileOpenOptions,
) -> io::Result<Option<std::fs::File>> {
    #[cfg(test)]
    super::open_probe::before_child_file_open(&parent.display_path().join(raw))?;
    let opened = kernel::open_direct_child_file(parent.handle(), OsStr::new(raw), options)
        .map_err(|error| {
            map_child_file_error(
                parent.handle(),
                parent.display_path(),
                scope_name,
                kind,
                raw,
                OsStr::new(raw),
                error,
            )
        })?;
    #[cfg(test)]
    super::open_probe::before_child_file_validate(&parent.display_path().join(raw))?;
    Ok(opened)
}

fn open_descendant_file(
    parent: &AnchoredDir,
    scope_name: &'static str,
    kind: &str,
    raw: &str,
    segments: &[&str],
    options: ExactChildFileOpenOptions,
) -> io::Result<Option<std::fs::File>> {
    let components: Vec<OsString> = segments.iter().map(OsString::from).collect();
    kernel::open_descendant_file(parent.handle(), &components, options).map_err(|error| {
        map_descendant_file_error(parent.display_path(), scope_name, kind, raw, error)
    })
}

fn map_child_file_error(
    parent: &kernel::AnchoredDirectory,
    parent_display_path: &std::path::Path,
    scope_name: &'static str,
    kind: &str,
    raw: &str,
    leaf_name: &OsStr,
    error: io::Error,
) -> io::Error {
    map_exact_file_open_error(
        parent_display_path,
        scope_name,
        kind,
        raw,
        error,
        child_invalid_input_error(parent, scope_name, kind, raw, leaf_name),
    )
}

fn map_descendant_file_error(
    parent_display_path: &std::path::Path,
    scope_name: &'static str,
    kind: &str,
    raw: &str,
    error: io::Error,
) -> io::Error {
    map_exact_file_open_error(
        parent_display_path,
        scope_name,
        kind,
        raw,
        error,
        Some(child_alias_error(scope_name, kind, raw)),
    )
}

fn map_exact_file_open_error(
    parent_display_path: &std::path::Path,
    scope_name: &'static str,
    kind: &str,
    raw: &str,
    error: io::Error,
    invalid_input_error: Option<io::Error>,
) -> io::Error {
    match error.kind() {
        io::ErrorKind::AlreadyExists => child_already_exists_error(scope_name, kind, raw),
        io::ErrorKind::NotFound => child_directory_missing_error(scope_name, kind, raw),
        io::ErrorKind::InvalidInput => invalid_input_error
            .unwrap_or_else(|| child_open_error(parent_display_path, kind, raw, error)),
        _ => child_open_error(parent_display_path, kind, raw, error),
    }
}

fn child_invalid_input_error(
    parent: &kernel::AnchoredDirectory,
    scope_name: &'static str,
    kind: &str,
    raw: &str,
    leaf_name: &OsStr,
) -> Option<io::Error> {
    match kernel::inspect_direct_child(parent, leaf_name) {
        Ok(Some(DirectChildPathType::Symlink)) => Some(child_alias_error(scope_name, kind, raw)),
        Ok(Some(DirectChildPathType::Directory | DirectChildPathType::Other)) => {
            Some(child_non_file_error(scope_name, kind, raw))
        }
        _ => None,
    }
}
