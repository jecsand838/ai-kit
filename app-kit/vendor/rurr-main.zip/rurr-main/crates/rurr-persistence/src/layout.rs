use indexmap::IndexMap;
use serde::{Deserialize, Serialize};
use serde_json::Value;

/// Current persisted-state storage layout version.
pub const STORAGE_LAYOUT_VERSION: &str = "v1";

/// Field name for the normalized partition key.
pub const FIELD_PARTITION_KEY: &str = "partition_key";
/// Field name for the application identifier.
pub const FIELD_APP_ID: &str = "app_id";
/// Field name for the persisted sequence identifier.
pub const FIELD_SEQUENCE_ID: &str = "sequence_id";
/// Field name for the persisted workflow position.
pub const FIELD_POSITION: &str = "position";
/// Field name for the serialized state payload.
pub const FIELD_STATE: &str = "state";
/// Field name for the record creation timestamp.
pub const FIELD_CREATED_AT: &str = "created_at";
/// Field name for the persisted status string.
pub const FIELD_STATUS: &str = "status";

/// Status string for completed executions.
pub const STATUS_COMPLETED: &str = "completed";
/// Status string for failed executions.
pub const STATUS_FAILED: &str = "failed";

/// Canonical field ordering for persisted-state records.
pub const PERSISTED_STATE_FIELD_ORDER: [&str; 7] = [
    FIELD_PARTITION_KEY,
    FIELD_APP_ID,
    FIELD_SEQUENCE_ID,
    FIELD_POSITION,
    FIELD_STATE,
    FIELD_CREATED_AT,
    FIELD_STATUS,
];

/// Returns the current persisted-state storage layout version.
pub fn storage_layout_version() -> &'static str {
    STORAGE_LAYOUT_VERSION
}

/// Status stored alongside a persisted state snapshot.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PersistedStateStatus {
    /// The execution finished successfully.
    Completed,
    /// The execution finished with an error.
    Failed,
}

/// Persisted state snapshot loaded from or written to a backend.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct PersistedStateData {
    /// Normalized partition key, if any.
    pub partition_key: Option<String>,
    /// Application identifier.
    pub app_id: String,
    /// Sequence identifier for the saved step.
    pub sequence_id: u64,
    /// Workflow position saved with the record.
    pub position: Option<String>,
    /// Serialized application state payload.
    pub state: Option<IndexMap<String, Value>>,
    /// Backend-provided creation timestamp.
    pub created_at: Option<String>,
    /// Saved execution status.
    pub status: PersistedStateStatus,
}
