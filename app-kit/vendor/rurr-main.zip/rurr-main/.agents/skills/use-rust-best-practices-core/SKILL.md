---
name: use-rust-best-practices-core
description: "Apply this on any Rust task that creates, edits, reviews, refactors, debugs, or plans Rust code. Respect the repository's pinned toolchain, edition, and MSRV policy first; otherwise use current stable Rust conventions, thin binaries over reusable libraries, borrow-first data flow, modern Cargo/workspace hygiene, docs/lints/tests review, and escalation to the specialized Rust skills when architecture, testing, async, networking, abstractions, dependencies, or cross-platform issues appear."
---

# Rust core best practices

Use this skill for **every** Rust task.

## When to use

Use it when the task:

- adds or edits Rust code
- reviews or debugs Rust code
- plans a Rust implementation
- changes `Cargo.toml`, package layout, or lint/test expectations
- needs a baseline Rust quality checklist before specialized guidance

## Do not use this skill alone when

- the task is primarily about crate/workspace structure and test placement → also load `$use-rust-best-practices-architecture`
- the task is primarily about test design or failing tests → also load `$use-rust-best-practices-testing`
- the task is primarily about `async`, Tokio, futures, spawned tasks, or shutdown → also load `$use-rust-best-practices-async`
- the task is primarily about HTTP, gRPC, retries, clients, pools, or DB access → also load `$use-rust-best-practices-networking`
- the task is primarily about traits, generics, lifetimes, errors, panics, or refactors → also load `$use-rust-best-practices-abstractions`
- the task is primarily about dependency policy, platform support, or Cargo hygiene → also load `$use-rust-best-practices-dependencies-platforms`

## Do this first

1. Inspect the repository for `rust-toolchain*`, CI version matrices, `edition`, and `rust-version`.
2. Preserve sound repo-local conventions before applying bundle defaults.
3. Prefer **library-first design**: keep logic in `lib.rs`-backed modules or library crates, and keep `main.rs` thin.
4. Prefer **borrowing, slices, iterators, and focused refactors** before adding `clone`, `Arc`, or duplicate logic.
5. Prefer **typed errors in libraries** and ergonomic composition at executable boundaries.
6. For Rurr, never use helper macros or macro helper crates as the refactor mechanism for ordinary
   duplicated code; model repeated data and behavior with structs, enums, methods, or real trait
   boundaries.
7. Before finishing, reason through formatting, linting, test scope, dependency impact, platform impact, and unsafe boundaries.

## Default delivery checklist

- Keep public API additions minimal and intentional.
- Reuse or extend existing domain code before creating a new crate.
- Avoid hidden panics (`unwrap`, `expect`) in production paths unless the invariant is truly impossible and documented.
- Reuse long-lived clients and crate-provided pools instead of rebuilding them per request.
- Keep tests at the narrowest useful level: unit, integration, doctest, binary smoke test, or e2e.
- Prefer clear ownership boundaries at parsing, persistence, network, and task-spawn edges.

## Load these references directly when needed

- `references/core-checklist.md` — baseline manifests, commands, review checklist, and escalation rules.

## Load these templates when useful

- `assets/templates/baseline-package/Cargo.toml`
- `assets/templates/member-Cargo.toml`

## Companion skills

- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-dependencies-platforms`
