use indexmap::IndexMap;
use rurr_core::action::{ActionContext, ActionError, ActionResult, Condition, LocalAction};
use rurr_core::graph::{GraphAction, GraphBuilder};
use rurr_core::state::State;
use std::fs;
use std::path::Path;

#[derive(Debug, Clone)]
struct GoldenAction {
    name: Option<String>,
}

impl GoldenAction {
    fn unnamed() -> Self {
        Self { name: None }
    }
}

impl LocalAction for GoldenAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &[]
    }

    fn writes(&self) -> &[String] {
        &[]
    }

    fn tags(&self) -> &[String] {
        &[]
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        let next_name = name.into();
        if let Some(current_name) = &self.name {
            return Err(ActionError::NameAlreadySet {
                current_name: current_name.clone(),
                attempted_name: next_name,
            });
        }

        let mut copied = self.clone();
        copied.name = Some(next_name);
        Ok(copied)
    }

    fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
    }
}

fn graph_action(name: &str) -> GraphAction {
    let named = GoldenAction::unnamed()
        .with_name(name)
        .expect("test action naming should succeed");
    GraphAction::new(named).expect("named action should create graph action")
}

#[test]
fn graphviz_dot_golden() {
    let graph = GraphBuilder::new()
        .with_actions(vec![graph_action("counter"), graph_action("result")])
        .with_transition_when("counter", "counter", Condition::expr("count < 10"))
        .with_transition("counter", "result")
        .build()
        .expect("graph build should succeed");

    let actual = graph
        .visualize(None, false)
        .expect("visualize should render dot text");

    let expected_path =
        Path::new(env!("CARGO_MANIFEST_DIR")).join("../../goldens/graphviz/tiny_graph.dot");
    let expected =
        fs::read_to_string(&expected_path).expect("golden file should be readable from workspace");

    assert_eq!(actual, expected, "dot output should match golden snapshot");
}
