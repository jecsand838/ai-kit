use crate::lifecycle::context::{
    ExecuteCallContext, PostStepContext, PreStepContext, SpanContext, StreamContext,
    StreamItemContext, VisibilityRootContext,
};
use crate::visibility::ActionSpan;
use crate::{application::ParentPointer, graph::Graph};
use async_trait::async_trait;
use indexmap::IndexMap;
use serde_json::Value;
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use thiserror::Error;

/// Errors returned by lifecycle adapters and lifecycle hook dispatch.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum LifecycleError {
    /// A lifecycle hook returned an error during the named phase.
    #[error("lifecycle hook failed during {phase}: {message}")]
    HookFailed {
        /// The lifecycle phase that was executing when the error occurred.
        phase: &'static str,
        /// A human-readable error message from the hook implementation.
        message: String,
    },
}

impl LifecycleError {
    /// Builds a hook failure for the provided phase and message.
    pub fn hook_failed(phase: &'static str, message: impl Into<String>) -> Self {
        Self::HookFailed {
            phase,
            message: message.into(),
        }
    }

    /// Returns the lifecycle phase associated with this error.
    pub fn phase(&self) -> &'static str {
        match self {
            Self::HookFailed { phase, .. } => phase,
        }
    }

    /// Returns the human-readable hook failure message.
    pub fn message(&self) -> &str {
        match self {
            Self::HookFailed { message, .. } => message,
        }
    }
}

/// Synchronous lifecycle hooks that run around application execution.
///
/// Sync hooks are the drop-safe lifecycle lane. Runtime guards use them to
/// report post-step, post-stream, and execute-call cleanup during normal
/// completion, early drop, and panic unwind.
pub trait SyncLifecycleAdapter: Send + Sync {
    /// Returns an optional parent for root visibility spans in one action execution.
    fn visibility_root_span_parent(&self, _context: &VisibilityRootContext) -> Option<ActionSpan> {
        None
    }

    /// Records a root application registration event.
    fn register_application(
        &self,
        _app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Records a child application registration event.
    fn register_child_application(
        &self,
        _child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Records the child application's own registration data.
    ///
    /// This lane is used when a child app has a tracker distinct from the
    /// parent app's tracker. The parent tracker owns parent-child relationship
    /// indexes; the child tracker owns the child application's graph,
    /// metadata, and lifecycle log.
    fn register_child_application_artifacts(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_child_application(
            child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
        )
    }

    /// Records parent-owned relationship indexes for a child application.
    ///
    /// This lane is used when a child app has a tracker distinct from the
    /// parent app's tracker. The parent tracker owns this relationship record
    /// without becoming the owner of the child application's graph, metadata,
    /// or lifecycle log.
    fn register_child_application_relationship(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_child_application(
            child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
        )
    }

    /// Runs immediately before an action step executes.
    fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after an action step finishes or fails.
    fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs before a visibility span begins.
    fn pre_start_span(&self, _context: &SpanContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after a visibility span has ended.
    fn post_end_span(&self, _context: &SpanContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Records one or more span attributes.
    fn log_attributes(
        &self,
        _context: &SpanContext,
        _attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs before a stream begins producing items.
    fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after an individual stream item has been emitted.
    fn post_stream_item(&self, _context: &StreamItemContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after a stream has completed.
    fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs before an execute-style call starts advancing the application.
    fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after an execute-style call has finished.
    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        Ok(())
    }
}

#[async_trait]
/// Asynchronous lifecycle hooks that run around application execution.
///
/// Async hooks run only from async execution APIs. They are never awaited from
/// `Drop`; callers that stop async streaming early must use the explicit abort
/// methods on async stream handles when these hooks must observe cleanup.
pub trait AsyncLifecycleAdapter: Send + Sync {
    /// Returns an optional parent for root visibility spans in one action execution.
    fn visibility_root_span_parent(&self, _context: &VisibilityRootContext) -> Option<ActionSpan> {
        None
    }

    /// Records a root application registration event.
    async fn register_application(
        &self,
        _app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Records a child application registration event.
    async fn register_child_application(
        &self,
        _child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Records the child application's own registration data.
    ///
    /// This lane is used when a child app has a tracker distinct from the
    /// parent app's tracker. The parent tracker owns parent-child relationship
    /// indexes; the child tracker owns the child application's graph,
    /// metadata, and lifecycle log.
    async fn register_child_application_artifacts(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_child_application(
            child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
        )
        .await
    }

    /// Records parent-owned relationship indexes for a child application.
    ///
    /// This lane is used when a child app has a tracker distinct from the
    /// parent app's tracker. The parent tracker owns this relationship record
    /// without becoming the owner of the child application's graph, metadata,
    /// or lifecycle log.
    async fn register_child_application_relationship(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_child_application(
            child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
        )
        .await
    }

    /// Runs immediately before an action step executes.
    async fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after an action step finishes or fails.
    async fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs before a visibility span begins.
    async fn pre_start_span(&self, _context: &SpanContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after a visibility span has ended.
    async fn post_end_span(&self, _context: &SpanContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Records one or more span attributes.
    async fn log_attributes(
        &self,
        _context: &SpanContext,
        _attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs before a stream begins producing items.
    async fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after an individual stream item has been emitted.
    async fn post_stream_item(&self, _context: &StreamItemContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after a stream has completed.
    async fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs before an execute-style call starts advancing the application.
    async fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        Ok(())
    }

    /// Runs after an execute-style call has finished.
    async fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        Ok(())
    }
}

/// Provider-neutral guard entered while an async lifecycle-owned future is polled.
///
/// Implementations usually restore provider context when dropped. Core treats
/// the guard opaquely so integrations such as OTEL can propagate context
/// without adding provider dependencies to `rurr-core`.
pub trait AsyncLifecyclePollGuard {}

impl<T> AsyncLifecyclePollGuard for T {}

/// Provider-neutral context that can enter a poll-scoped lifecycle context.
///
/// The context is entered for each poll of the relevant future, not held across
/// an entire async operation. That keeps propagation correct for future-scoped
/// provider APIs and avoids thread-local guard leaks across `.await`.
pub trait AsyncLifecyclePollContext: Send + Sync {
    /// Enters this context for the current poll and returns its guard.
    fn enter(&self) -> Box<dyn AsyncLifecyclePollGuard + '_>;
}

struct AsyncLifecyclePollGuardStack<'a> {
    guards: Vec<Box<dyn AsyncLifecyclePollGuard + 'a>>,
}

impl<'a> AsyncLifecyclePollGuardStack<'a> {
    fn enter(contexts: &'a [Arc<dyn AsyncLifecyclePollContext>]) -> Self {
        Self {
            guards: contexts.iter().map(|context| context.enter()).collect(),
        }
    }
}

impl Drop for AsyncLifecyclePollGuardStack<'_> {
    fn drop(&mut self) {
        while let Some(guard) = self.guards.pop() {
            drop(guard);
        }
    }
}

/// Optional provider-neutral context propagation for async lifecycle work.
///
/// Core stores these contexts without depending on a concrete provider. The
/// runtime enters each returned context only while polling the relevant future,
/// which matches provider APIs such as OpenTelemetry's future-scoped context
/// propagation without relying on thread-local guards across `.await`.
/// Propagators are additive; they do not change hook ordering or the sync/async
/// lifecycle split.
pub trait AsyncLifecycleContextPropagator: Send + Sync {
    /// Returns a poll context for an async step action future, when available.
    fn step_poll_context(
        &self,
        _context: &PreStepContext,
    ) -> Option<Arc<dyn AsyncLifecyclePollContext>> {
        None
    }

    /// Returns a poll context for an async visibility span future, when available.
    fn span_poll_context(
        &self,
        _context: &SpanContext,
    ) -> Option<Arc<dyn AsyncLifecyclePollContext>> {
        None
    }
}

pub(crate) async fn poll_with_lifecycle_contexts<Fut>(
    future: Fut,
    contexts: Vec<Arc<dyn AsyncLifecyclePollContext>>,
) -> Fut::Output
where
    Fut: Future,
{
    if contexts.is_empty() {
        return future.await;
    }

    let mut future = Box::pin(future);
    std::future::poll_fn(move |cx| {
        let _guards = AsyncLifecyclePollGuardStack::enter(&contexts);
        Pin::as_mut(&mut future).poll(cx)
    })
    .await
}

#[derive(Clone, Default)]
/// A collection of synchronous and asynchronous lifecycle adapters.
///
/// The set keeps sync hooks, async hooks, and async lifecycle context propagators in
/// separate lanes so runtime execution can preserve sync cleanup guarantees and
/// only poll async hooks from async APIs.
///
/// Use [`with_async_lifecycle_context_propagator`](Self::with_async_lifecycle_context_propagator)
/// when an integration needs to carry provider context through awaited async
/// step or visibility futures. The hook composition APIs preserve those
/// propagators when tracker hooks are added or removed.
///
/// # Examples
///
/// ```
/// use rurr_core::LifecycleAdapterSet;
///
/// let hooks = LifecycleAdapterSet::new(Vec::new(), Vec::new());
/// assert!(hooks.sync_adapters().is_empty());
/// assert!(hooks.async_adapters().is_empty());
/// ```
pub struct LifecycleAdapterSet {
    sync_adapters: Vec<Arc<dyn SyncLifecycleAdapter>>,
    async_adapters: Vec<Arc<dyn AsyncLifecycleAdapter>>,
    async_lifecycle_context_propagators: Vec<Arc<dyn AsyncLifecycleContextPropagator>>,
}

#[derive(Clone, Copy)]
enum LifecycleHook<'a> {
    RegisterApplication {
        app_id: &'a str,
        partition_key: Option<&'a str>,
        graph: &'a Graph,
        parent_pointer: Option<&'a ParentPointer>,
        spawning_parent_pointer: Option<&'a ParentPointer>,
    },
    RegisterChildApplication {
        child_app_id: &'a str,
        partition_key: Option<&'a str>,
        graph: &'a Graph,
        parent_pointer: Option<&'a ParentPointer>,
        spawning_parent_pointer: Option<&'a ParentPointer>,
    },
    PreRunStep(&'a PreStepContext),
    PostRunStep(&'a PostStepContext),
    PreStartSpan(&'a SpanContext),
    PostEndSpan(&'a SpanContext),
    LogAttributes {
        context: &'a SpanContext,
        attributes: &'a IndexMap<String, Value>,
    },
    PreStartStream(&'a StreamContext),
    PostStreamItem(&'a StreamItemContext),
    PostEndStream(&'a StreamContext),
    PreExecuteCall(&'a ExecuteCallContext),
    PostExecuteCall(&'a ExecuteCallContext),
}

impl LifecycleHook<'_> {
    fn call_sync(&self, adapter: &dyn SyncLifecycleAdapter) -> Result<(), LifecycleError> {
        match self {
            Self::RegisterApplication {
                app_id,
                partition_key,
                graph,
                parent_pointer,
                spawning_parent_pointer,
            } => adapter.register_application(
                app_id,
                *partition_key,
                graph,
                *parent_pointer,
                *spawning_parent_pointer,
            ),
            Self::RegisterChildApplication {
                child_app_id,
                partition_key,
                graph,
                parent_pointer,
                spawning_parent_pointer,
            } => adapter.register_child_application(
                child_app_id,
                *partition_key,
                graph,
                *parent_pointer,
                *spawning_parent_pointer,
            ),
            Self::PreRunStep(context) => adapter.pre_run_step(context),
            Self::PostRunStep(context) => adapter.post_run_step(context),
            Self::PreStartSpan(context) => adapter.pre_start_span(context),
            Self::PostEndSpan(context) => adapter.post_end_span(context),
            Self::LogAttributes {
                context,
                attributes,
            } => adapter.log_attributes(context, attributes),
            Self::PreStartStream(context) => adapter.pre_start_stream(context),
            Self::PostStreamItem(context) => adapter.post_stream_item(context),
            Self::PostEndStream(context) => adapter.post_end_stream(context),
            Self::PreExecuteCall(context) => adapter.pre_execute_call(context),
            Self::PostExecuteCall(context) => adapter.post_execute_call(context),
        }
    }

    async fn call_async(&self, adapter: &dyn AsyncLifecycleAdapter) -> Result<(), LifecycleError> {
        match self {
            Self::RegisterApplication {
                app_id,
                partition_key,
                graph,
                parent_pointer,
                spawning_parent_pointer,
            } => {
                adapter
                    .register_application(
                        app_id,
                        *partition_key,
                        graph,
                        *parent_pointer,
                        *spawning_parent_pointer,
                    )
                    .await
            }
            Self::RegisterChildApplication {
                child_app_id,
                partition_key,
                graph,
                parent_pointer,
                spawning_parent_pointer,
            } => {
                adapter
                    .register_child_application(
                        child_app_id,
                        *partition_key,
                        graph,
                        *parent_pointer,
                        *spawning_parent_pointer,
                    )
                    .await
            }
            Self::PreRunStep(context) => adapter.pre_run_step(context).await,
            Self::PostRunStep(context) => adapter.post_run_step(context).await,
            Self::PreStartSpan(context) => adapter.pre_start_span(context).await,
            Self::PostEndSpan(context) => adapter.post_end_span(context).await,
            Self::LogAttributes {
                context,
                attributes,
            } => adapter.log_attributes(context, attributes).await,
            Self::PreStartStream(context) => adapter.pre_start_stream(context).await,
            Self::PostStreamItem(context) => adapter.post_stream_item(context).await,
            Self::PostEndStream(context) => adapter.post_end_stream(context).await,
            Self::PreExecuteCall(context) => adapter.pre_execute_call(context).await,
            Self::PostExecuteCall(context) => adapter.post_execute_call(context).await,
        }
    }
}

impl LifecycleAdapterSet {
    /// Creates a lifecycle adapter set from the provided adapter lists.
    pub fn new(
        sync_adapters: Vec<Arc<dyn SyncLifecycleAdapter>>,
        async_adapters: Vec<Arc<dyn AsyncLifecycleAdapter>>,
    ) -> Self {
        Self {
            sync_adapters,
            async_adapters,
            async_lifecycle_context_propagators: Vec::new(),
        }
    }

    pub(crate) fn with_adapters(
        self,
        sync_adapters: Vec<Arc<dyn SyncLifecycleAdapter>>,
        async_adapters: Vec<Arc<dyn AsyncLifecycleAdapter>>,
    ) -> Self {
        Self {
            sync_adapters,
            async_adapters,
            async_lifecycle_context_propagators: self.async_lifecycle_context_propagators,
        }
    }

    /// Returns the registered synchronous lifecycle adapters.
    pub fn sync_adapters(&self) -> &[Arc<dyn SyncLifecycleAdapter>] {
        &self.sync_adapters
    }

    /// Returns the registered asynchronous lifecycle adapters.
    pub fn async_adapters(&self) -> &[Arc<dyn AsyncLifecycleAdapter>] {
        &self.async_adapters
    }

    /// Adds an async lifecycle context propagator to this adapter set.
    pub fn with_async_lifecycle_context_propagator(
        mut self,
        propagator: Arc<dyn AsyncLifecycleContextPropagator>,
    ) -> Self {
        self.async_lifecycle_context_propagators.push(propagator);
        self
    }

    pub(crate) fn async_step_poll_contexts(
        &self,
        context: &PreStepContext,
    ) -> Vec<Arc<dyn AsyncLifecyclePollContext>> {
        self.async_lifecycle_context_propagators
            .iter()
            .filter_map(|propagator| propagator.step_poll_context(context))
            .collect()
    }

    pub(crate) fn async_span_poll_contexts(
        &self,
        context: &SpanContext,
    ) -> Vec<Arc<dyn AsyncLifecyclePollContext>> {
        self.async_lifecycle_context_propagators
            .iter()
            .filter_map(|propagator| propagator.span_poll_context(context))
            .collect()
    }

    pub(crate) fn visibility_root_span_parent(
        &self,
        context: &VisibilityRootContext,
    ) -> Option<ActionSpan> {
        self.sync_adapters
            .iter()
            .find_map(|adapter| adapter.visibility_root_span_parent(context))
            .or_else(|| {
                self.async_adapters
                    .iter()
                    .find_map(|adapter| adapter.visibility_root_span_parent(context))
            })
    }

    fn run_sync_hook(&self, hook: LifecycleHook<'_>) -> Result<(), LifecycleError> {
        for adapter in &self.sync_adapters {
            hook.call_sync(adapter.as_ref())?;
        }
        Ok(())
    }

    async fn run_async_hook(&self, hook: LifecycleHook<'_>) -> Result<(), LifecycleError> {
        for adapter in &self.async_adapters {
            hook.call_async(adapter.as_ref()).await?;
        }
        Ok(())
    }

    async fn run_sync_then_async_hook(
        &self,
        hook: LifecycleHook<'_>,
    ) -> Result<(), LifecycleError> {
        self.run_sync_hook(hook)?;
        self.run_async_hook(hook).await
    }

    /// Runs the synchronous `register_application` hook across sync adapters.
    pub fn register_application_sync(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::RegisterApplication {
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
        })
    }

    /// Runs `register_application` across sync adapters, then async adapters.
    pub async fn register_application_async(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::RegisterApplication {
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
        })
        .await
    }

    /// Runs the synchronous `register_child_application` hook across sync adapters.
    pub fn register_child_application_sync(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::RegisterChildApplication {
            child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
        })
    }

    /// Runs `register_child_application` across sync adapters, then async adapters.
    pub async fn register_child_application_async(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::RegisterChildApplication {
            child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
        })
        .await
    }

    /// Runs the synchronous `pre_run_step` hook across sync adapters.
    pub fn pre_run_step_sync(&self, context: &PreStepContext) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PreRunStep(context))
    }

    /// Runs `pre_run_step` across sync adapters, then async adapters.
    pub async fn pre_run_step_async(&self, context: &PreStepContext) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PreRunStep(context))
            .await
    }

    /// Runs the synchronous `post_run_step` hook across sync adapters.
    pub fn post_run_step_sync(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PostRunStep(context))
    }

    /// Runs `post_run_step` across sync adapters, then async adapters.
    pub async fn post_run_step_async(
        &self,
        context: &PostStepContext,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PostRunStep(context))
            .await
    }

    /// Runs only the asynchronous `post_run_step` hook across async adapters.
    pub async fn post_run_step_async_only(
        &self,
        context: &PostStepContext,
    ) -> Result<(), LifecycleError> {
        self.run_async_hook(LifecycleHook::PostRunStep(context))
            .await
    }

    /// Runs the synchronous `pre_start_span` hook across sync adapters.
    pub fn pre_start_span_sync(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PreStartSpan(context))
    }

    /// Runs `pre_start_span` across sync adapters, then async adapters.
    pub async fn pre_start_span_async(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PreStartSpan(context))
            .await
    }

    /// Runs the synchronous `post_end_span` hook across sync adapters.
    pub fn post_end_span_sync(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PostEndSpan(context))
    }

    /// Runs `post_end_span` across sync adapters, then async adapters.
    pub async fn post_end_span_async(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PostEndSpan(context))
            .await
    }

    /// Runs only the asynchronous `post_end_span` hook across async adapters.
    pub async fn post_end_span_async_only(
        &self,
        context: &SpanContext,
    ) -> Result<(), LifecycleError> {
        self.run_async_hook(LifecycleHook::PostEndSpan(context))
            .await
    }

    /// Runs the synchronous `log_attributes` hook across sync adapters.
    pub fn log_attributes_sync(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::LogAttributes {
            context,
            attributes,
        })
    }

    /// Runs `log_attributes` across sync adapters, then async adapters.
    pub async fn log_attributes_async(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::LogAttributes {
            context,
            attributes,
        })
        .await
    }

    /// Runs the synchronous `pre_start_stream` hook across sync adapters.
    pub fn pre_start_stream_sync(&self, context: &StreamContext) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PreStartStream(context))
    }

    /// Runs `pre_start_stream` across sync adapters, then async adapters.
    pub async fn pre_start_stream_async(
        &self,
        context: &StreamContext,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PreStartStream(context))
            .await
    }

    /// Runs the synchronous `post_stream_item` hook across sync adapters.
    pub fn post_stream_item_sync(&self, context: &StreamItemContext) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PostStreamItem(context))
    }

    /// Runs `post_stream_item` across sync adapters, then async adapters.
    pub async fn post_stream_item_async(
        &self,
        context: &StreamItemContext,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PostStreamItem(context))
            .await
    }

    /// Runs the synchronous `post_end_stream` hook across sync adapters.
    pub fn post_end_stream_sync(&self, context: &StreamContext) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PostEndStream(context))
    }

    /// Runs `post_end_stream` across sync adapters, then async adapters.
    pub async fn post_end_stream_async(
        &self,
        context: &StreamContext,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PostEndStream(context))
            .await
    }

    /// Runs only the asynchronous `post_end_stream` hook across async adapters.
    pub async fn post_end_stream_async_only(
        &self,
        context: &StreamContext,
    ) -> Result<(), LifecycleError> {
        self.run_async_hook(LifecycleHook::PostEndStream(context))
            .await
    }

    /// Runs the synchronous `pre_execute_call` hook across sync adapters.
    pub fn pre_execute_call_sync(
        &self,
        context: &ExecuteCallContext,
    ) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PreExecuteCall(context))
    }

    /// Runs `pre_execute_call` across sync adapters, then async adapters.
    pub async fn pre_execute_call_async(
        &self,
        context: &ExecuteCallContext,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PreExecuteCall(context))
            .await
    }

    /// Runs the synchronous `post_execute_call` hook across sync adapters.
    pub fn post_execute_call_sync(
        &self,
        context: &ExecuteCallContext,
    ) -> Result<(), LifecycleError> {
        self.run_sync_hook(LifecycleHook::PostExecuteCall(context))
    }

    /// Runs `post_execute_call` across sync adapters, then async adapters.
    pub async fn post_execute_call_async(
        &self,
        context: &ExecuteCallContext,
    ) -> Result<(), LifecycleError> {
        self.run_sync_then_async_hook(LifecycleHook::PostExecuteCall(context))
            .await
    }

    /// Runs only the asynchronous `post_execute_call` hook across async adapters.
    pub async fn post_execute_call_async_only(
        &self,
        context: &ExecuteCallContext,
    ) -> Result<(), LifecycleError> {
        self.run_async_hook(LifecycleHook::PostExecuteCall(context))
            .await
    }
}

#[cfg(test)]
mod tests {
    use super::{poll_with_lifecycle_contexts, AsyncLifecyclePollContext, AsyncLifecyclePollGuard};
    use std::sync::{Arc, Mutex};

    struct RecordingPollContext {
        label: &'static str,
        events: Arc<Mutex<Vec<String>>>,
    }

    impl RecordingPollContext {
        fn new(label: &'static str, events: Arc<Mutex<Vec<String>>>) -> Self {
            Self { label, events }
        }
    }

    impl AsyncLifecyclePollContext for RecordingPollContext {
        fn enter(&self) -> Box<dyn AsyncLifecyclePollGuard + '_> {
            self.events
                .lock()
                .expect("recording poll context mutex poisoned")
                .push(format!("enter:{}", self.label));
            Box::new(RecordingPollGuard {
                label: self.label,
                events: Arc::clone(&self.events),
            })
        }
    }

    struct RecordingPollGuard {
        label: &'static str,
        events: Arc<Mutex<Vec<String>>>,
    }

    impl Drop for RecordingPollGuard {
        fn drop(&mut self) {
            self.events
                .lock()
                .expect("recording poll guard mutex poisoned")
                .push(format!("drop:{}", self.label));
        }
    }

    #[tokio::test]
    async fn poll_lifecycle_context_guards_unwind_in_reverse_order() {
        let events = Arc::new(Mutex::new(Vec::new()));
        let contexts: Vec<Arc<dyn AsyncLifecyclePollContext>> = vec![
            Arc::new(RecordingPollContext::new("a", Arc::clone(&events))),
            Arc::new(RecordingPollContext::new("b", Arc::clone(&events))),
        ];

        poll_with_lifecycle_contexts(
            {
                let events = Arc::clone(&events);
                async move {
                    events
                        .lock()
                        .expect("recording future mutex poisoned")
                        .push("body".to_string());
                }
            },
            contexts,
        )
        .await;

        let events = events
            .lock()
            .expect("recorded event mutex poisoned")
            .clone();
        assert_eq!(events, ["enter:a", "enter:b", "body", "drop:b", "drop:a"]);
    }
}
