# crates/rurr-macros/AGENTS.override.md — Proc-macro + UI contract rules

This file applies only to `crates/rurr-macros/` and adds proc-macro-specific rules on top of
repo-root `AGENTS.md` and `crates/AGENTS.override.md`.

## Scope and precedence
- Apply repo-root `AGENTS.md` first, then `crates/AGENTS.override.md`, then this file.
- Use `crates/rurr-macros/ARCHITECTURE.md` for the living parse/model/validate/expand map.
- `.codex/config.toml` may change Codex defaults, but it does not relax the trybuild or diagnostic
  requirements in this subtree.
- If any `AGENTS*.md` file changes, restart Codex before continuing here.

## Commands
- `cargo test -q -p rurr-macros`
- `cargo test -q -p rurr-macros --test trybuild`
- ONLY when intentionally updating expected UI outputs:
    - `TRYBUILD=overwrite cargo test -q -p rurr-macros --test trybuild`

## Non-negotiables
- trybuild UI tests are the spec: do not loosen them.
- Never `panic!` during macro expansion; return a spanned `syn::Error`.
- Generated code must be deterministic and compile on stable Rust.
- Ask before adding new dependencies beyond the standard proc-macro stack (`syn`, `quote`, `proc-macro2`).
- Keep the current internal split across `src/parse.rs`, `src/model.rs`, `src/validate.rs`, and `src/expand.rs`; public macro behavior should not change just because internals are reorganized.
- Do not add macro helper crates or extra macro layers to simplify the macro implementation itself;
  use parse/model/validate/expand structs and methods unless the public proc-macro contract
  explicitly requires code generation.

## Boundaries
### ✅ Always do
- Keep error messages actionable and attach spans to the most relevant tokens.
- Update/commit `tests/ui/*.stderr` only via `TRYBUILD=overwrite` when changes are intentional.

## Remediation reopening execution
- During explicitly reopened remediation work, load `TASKS_PROGRESS.md` and `docs/refactors/burr-parity-remediation/README.md` before touching `rurr-macros`.
- Treat trybuild diagnostics and the generated public API as frozen unless the reopened remediation phase explicitly permits a pinned diagnostic update.
- Record reopened remediation progress, gates, and any residual trybuild risk in `TASKS_PROGRESS.md` before handing work back.

### 🚫 Never do
- Add runtime dependencies to the proc-macro crate.
- Require `unsafe` in downstream crates as a side effect of codegen.
- Change `rurr-core` APIs just to simplify macros unless the task explicitly permits it.
- Treat the existence of `rurr-macros` as permission to use macros for unrelated workspace
  cleanup. The crate is only for the user-facing proc-macro action surface.
