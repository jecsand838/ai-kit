---
name: rurr-anchored-filesystem-hardening
description: "Use when editing Rurr anchored filesystem, output preparation, path validation, pinning, or tracking artifact path handling to preserve symlink rejection, descendant validation, deterministic IO errors, and a narrow public filesystem facade."
---

# Rurr Anchored Filesystem Hardening

Use this skill when path safety, artifact layout, or public anchored-filesystem surface area is part of a Rurr change.

## Quick start

Load, in order:

- `AGENTS.md`
- `README.md`
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- current anchored filesystem code and tests found with `rg "anchored_fs|AnchoredDir|PreparedOutput|PathSegment"`

Load these companion skills:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-dependencies-platforms`

## Workflow

1. Classify the change as validation, child opening, descendant opening, output preparation, pinning, or public facade cleanup.
2. Add or request tests for symlink rejection, non-file/non-dir rejection, missing required reads, descendant validation, and overwrite/create behavior.
3. Consolidate repeated checked-target logic behind private concrete helpers.
4. Keep only facade types public when workspace users need them.
5. Replace required-read `expect` paths with deterministic `io::Error` values.
6. Check platform-specific behavior without adding new dependencies or broad cfg forks.
7. Update downstream imports to use the facade instead of hidden internals.

## Output contract

Return:

- the anchored-filesystem behavior under review
- the path-safety tests required
- the public facade that should remain
- the internals that should be private or deleted
- the narrow gate and any manifest-sensitive fallout

## Default rules

- Reject symlink escapes and non-descendant paths deterministically.
- Preserve raw tracking artifact layout and Burr-visible path behavior.
- Prefer a single private checked-target kernel over parallel helper families.
- Do not expose low-level modules such as `ops`, `platform`, `resolve`, `target`, or `validation` unless a real public use requires them.
- Do not hand edit generated manifests.

## Do not use this skill alone when

- the path behavior must be compared to Burr source first: also use `$rurr-burr-source-parity-walk`
- the filesystem work is one phase of a larger cleanup: also use `$rurr-delete-first-refactor-plan`
- implementation is requested for an approved delete-first refactor: also use `$rurr-delete-first-refactor-plan` in implementation mode
- final handoff requires gate selection: also use `$rurr-gate-closeout`
