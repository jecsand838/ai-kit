//! PostgreSQL-backed persistence adapters for Rurr applications.
//!
//! The sync and async persisters in this crate share the same table layout and
//! query plan. Constructors validate configuration eagerly, but they do not
//! open network connections until the first real operation, which keeps local
//! configuration examples fast and deterministic.
//! Both lanes use the shared persisted-state layout from `rurr-persistence`.
//! Runtime I/O is provider-backed and should be proven through the live
//! PostgreSQL lane; doctests here stay limited to constructor and validation
//! behavior.
//!
//! ```rust
//! use rurr_postgres::{
//!     schema::validate_table_name, AsyncPostgresPersister, PostgresPersister,
//!     DEFAULT_TABLE_NAME,
//! };
//!
//! validate_table_name(DEFAULT_TABLE_NAME)?;
//!
//! let sync = PostgresPersister::new(rurr_postgres::PostgresPersisterConfig::new(
//!     "postgres://postgres:postgres@localhost/rurr_docs",
//!     DEFAULT_TABLE_NAME,
//! ))?;
//! assert_eq!(sync.config().table_name, DEFAULT_TABLE_NAME);
//!
//! let async_persister =
//!     AsyncPostgresPersister::new(rurr_postgres::PostgresPersisterConfig::new(
//!         "postgres://postgres:postgres@localhost/rurr_docs",
//!         DEFAULT_TABLE_NAME,
//!     ))?;
//! assert_eq!(async_persister.config().database_url, "postgres://postgres:postgres@localhost/rurr_docs");
//! # Ok::<(), rurr_persistence::PersistenceError>(())
//! ```
#![deny(missing_docs)]

use serde::{Deserialize, Serialize};
use sqlx::PgPool;
use std::sync::atomic::AtomicBool;
use std::sync::Mutex;
use std::time::Duration;

use rurr_persistence::{PersistedStateData, PersistedStateStatus, PersistenceError};

mod async_ops;
/// Error adapters that normalize PostgreSQL driver failures into
/// [`PersistenceError`] values.
pub mod error_map;
/// Schema validation and migration rendering helpers for PostgreSQL tables.
pub mod schema;
/// Shared query plans, connection helpers, and state for PostgreSQL persisters.
pub mod shared;
mod sync_ops;

#[cfg(test)]
use error_map::map_sqlstate_error;
use error_map::map_sqlx_error;
use shared::{PostgresShared, SyncClientState};

const MIGRATION_SQL: &str = include_str!("../migrations/postgres.sql");

const OP_CONNECTION_CLOSED: &str = "connection_closed";
const OP_CONNECTION_LOCK_POISONED: &str = "connection_lock_poisoned";
const OP_INVALID_TABLE_NAME: &str = "invalid_table_name";
const OP_POSTGRES_CONNECT_FAILED: &str = "postgres_connect_failed";
const OP_POSTGRES_MIGRATION_FAILED: &str = "postgres_migration_failed";
const OP_POSTGRES_QUERY_FAILED: &str = "postgres_query_failed";
const OP_STATE_SERIALIZATION_FAILED: &str = "state_serialization_failed";

/// Default persisted-state table name used by the PostgreSQL backend.
pub const DEFAULT_TABLE_NAME: &str = "burr_state";
const POSTGRES_IDENTIFIER_MAX_LEN: usize = 63;
const CREATED_AT_INDEX_SUFFIX: &str = "_created_at_index";
const POSTGRES_INDEX_SAFE_TABLE_NAME_MAX_LEN: usize =
    POSTGRES_IDENTIFIER_MAX_LEN - CREATED_AT_INDEX_SUFFIX.len();
const ASYNC_POOL_MAX_CONNECTIONS: u32 = 1;
// Keep the pool runtime-free at construction time; sqlx spawns maintenance
// tasks immediately when min_connections > 0, which panics without Tokio.
const ASYNC_POOL_MIN_CONNECTIONS: u32 = 0;
const ASYNC_POOL_IDLE_TIMEOUT: Option<Duration> = None;
const ASYNC_POOL_MAX_LIFETIME: Option<Duration> = None;

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serializable configuration for constructing PostgreSQL persisters.
pub struct PostgresPersisterConfig {
    /// Connection string for the target PostgreSQL database.
    pub database_url: String,
    /// Table used to store persisted-state rows.
    pub table_name: String,
}

impl PostgresPersisterConfig {
    /// Builds a PostgreSQL persister config from a database URL and table name.
    pub fn new(database_url: impl Into<String>, table_name: impl Into<String>) -> Self {
        Self {
            database_url: database_url.into(),
            table_name: table_name.into(),
        }
    }
}

/// Synchronous PostgreSQL persister backed by a lazily opened `postgres::Client`.
pub struct PostgresPersister {
    client_state: Mutex<SyncClientState>,
    shared: PostgresShared,
}

/// Asynchronous PostgreSQL persister backed by a lazy `sqlx::PgPool`.
pub struct AsyncPostgresPersister {
    pool: PgPool,
    shared: PostgresShared,
    closed: AtomicBool,
}

#[cfg(test)]
mod tests {
    use super::{
        map_sqlstate_error, map_sqlx_error, PersistenceError, OP_CONNECTION_CLOSED,
        OP_POSTGRES_QUERY_FAILED,
    };
    use rurr_persistence::{sequence_id_i64_to_u64, sequence_id_u64_to_i64};
    use sqlx::error::{DatabaseError, ErrorKind};
    use std::borrow::Cow;
    use std::error::Error as StdError;
    use std::fmt::{Display, Formatter};

    const OP_SEQUENCE_ID_OUT_OF_RANGE: &str = "sequence_id_out_of_range";

    #[derive(Debug)]
    struct FakeDatabaseError {
        code: Option<&'static str>,
        message: &'static str,
    }

    impl Display for FakeDatabaseError {
        fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
            f.write_str(self.message)
        }
    }

    impl StdError for FakeDatabaseError {}

    impl DatabaseError for FakeDatabaseError {
        fn message(&self) -> &str {
            self.message
        }

        fn code(&self) -> Option<Cow<'_, str>> {
            self.code.map(Cow::Borrowed)
        }

        fn as_error(&self) -> &(dyn StdError + Send + Sync + 'static) {
            self
        }

        fn as_error_mut(&mut self) -> &mut (dyn StdError + Send + Sync + 'static) {
            self
        }

        fn into_error(self: Box<Self>) -> Box<dyn StdError + Send + Sync + 'static> {
            self
        }

        fn kind(&self) -> ErrorKind {
            ErrorKind::Other
        }
    }

    #[test]
    fn sequence_id_u64_to_i64_accepts_value_above_i32_max() {
        let sequence_id = i32::MAX as u64 + 1;
        let converted = sequence_id_u64_to_i64(sequence_id).expect("conversion should succeed");
        assert_eq!(converted, sequence_id as i64);
    }

    #[test]
    fn sequence_id_u64_to_i64_accepts_i64_max() {
        let sequence_id = i64::MAX as u64;
        let converted = sequence_id_u64_to_i64(sequence_id).expect("conversion should succeed");
        assert_eq!(converted, i64::MAX);
    }

    #[test]
    fn sequence_id_u64_to_i64_rejects_value_above_i64_max() {
        let error =
            sequence_id_u64_to_i64(i64::MAX as u64 + 1).expect_err("conversion should fail");
        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_SEQUENCE_ID_OUT_OF_RANGE
        ));
    }

    #[test]
    fn sequence_id_i64_to_u64_rejects_negative_value() {
        let error = sequence_id_i64_to_u64(-1).expect_err("conversion should fail");
        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_SEQUENCE_ID_OUT_OF_RANGE
        ));
    }

    #[test]
    fn map_sqlx_error_pool_closed_returns_connection_closed() {
        let mapped = map_sqlx_error(sqlx::Error::PoolClosed, OP_POSTGRES_QUERY_FAILED);
        assert!(matches!(
            mapped,
            PersistenceError::UnsupportedOperation { operation }
                if operation == OP_CONNECTION_CLOSED
        ));
    }

    #[test]
    fn map_sqlstate_error_relation_missing_returns_not_initialized() {
        let mapped = map_sqlstate_error(Some("42P01"), OP_POSTGRES_QUERY_FAILED);
        assert!(matches!(mapped, PersistenceError::NotInitialized));
    }

    #[test]
    fn map_sqlx_error_relation_missing_sqlstate_returns_not_initialized() {
        let mapped = map_sqlx_error(
            sqlx::Error::Database(Box::new(FakeDatabaseError {
                code: Some("42P01"),
                message: "relation does not exist",
            })),
            OP_POSTGRES_QUERY_FAILED,
        );
        assert!(matches!(mapped, PersistenceError::NotInitialized));
    }
}
