use super::config::S3BackendConfig;
use super::{invalid_layout, map_metadata_error, provider};
use crate::backend::BackendError;
use aws_sdk_s3::operation::list_objects_v2::ListObjectsV2Output;
use aws_sdk_s3::primitives::DateTime;
use aws_sdk_s3::types::{CommonPrefix, Object};
use rurr_core::tracking::S3TrackingObjectKey;
use std::collections::HashMap;

#[derive(Debug)]
pub(super) struct S3ListedObject {
    key: S3TrackingObjectKey,
    last_modified: String,
}

impl S3ListedObject {
    pub(super) fn last_modified(&self) -> &str {
        &self.last_modified
    }

    pub(super) fn into_key(self) -> S3TrackingObjectKey {
        self.key
    }
}

pub(super) struct S3ObjectScanner<'a> {
    client: &'a aws_sdk_s3::Client,
    config: &'a S3BackendConfig,
}

impl<'a> S3ObjectScanner<'a> {
    pub(super) fn new(client: &'a aws_sdk_s3::Client, config: &'a S3BackendConfig) -> Self {
        Self { client, config }
    }

    pub(super) fn max_concurrency(&self) -> usize {
        self.config.indexing.aws_max_concurrency
    }

    pub(super) fn tracking_object_key(
        &self,
        key: &str,
    ) -> Result<S3TrackingObjectKey, BackendError> {
        S3TrackingObjectKey::parse(&self.config.data_prefix, key).map_err(invalid_layout)
    }

    pub(super) async fn list_projects(&self) -> Result<Vec<String>, BackendError> {
        let prefix = format!("{}/", self.config.data_prefix);
        self.collect_listing(
            "list_projects",
            prefix.clone(),
            ListingTarget::CommonPrefixes,
            None,
            None,
        )
        .await?
        .into_iter()
        .map(|entry| {
            let common_prefix = entry.into_common_prefix("list_projects")?;
            project_from_common_prefix("list_projects", &prefix, &common_prefix)
        })
        .collect()
    }

    pub(super) async fn list_tracking_objects(
        &self,
        project: &str,
        high_watermark: Option<&str>,
    ) -> Result<Vec<S3ListedObject>, BackendError> {
        let entries = self
            .collect_listing(
                "list_project_files",
                format!("{}/{project}/", self.config.data_prefix),
                ListingTarget::Objects,
                high_watermark,
                Some(self.config.indexing.max_paths_per_project),
            )
            .await?;

        entries
            .into_iter()
            .map(|entry| {
                let ListedObjectEntry { key, last_modified } =
                    entry.into_object("list_project_files")?;
                Ok(S3ListedObject {
                    key: self.tracking_object_key(&key)?,
                    last_modified,
                })
            })
            .collect()
    }

    pub(super) async fn list_snapshot_candidate_keys(&self) -> Result<Vec<String>, BackendError> {
        self.collect_listing(
            "list_snapshots",
            format!("{}/", self.config.indexing.snapshot_prefix),
            ListingTarget::Objects,
            None,
            None,
        )
        .await
        .map(|entries| {
            entries
                .into_iter()
                .filter_map(ListingEntry::object_key)
                .filter(|key| key.ends_with("/snapshot.db"))
                .collect()
        })
    }

    pub(super) async fn head_metadata(
        &self,
        key: &str,
        operation: &'static str,
    ) -> Result<HashMap<String, String>, BackendError> {
        self.client
            .head_object()
            .bucket(self.config.transport.bucket())
            .key(key)
            .send()
            .await
            .map_err(provider(operation))?
            .metadata()
            .cloned()
            .ok_or_else(|| {
                map_metadata_error(rurr_core::tracking::s3_metadata::missing_metadata_map(key))
            })
    }

    pub(super) async fn get_object_bytes(
        &self,
        key: &str,
        get_operation: &'static str,
        read_operation: &'static str,
    ) -> Result<Vec<u8>, BackendError> {
        let output = self
            .client
            .get_object()
            .bucket(self.config.transport.bucket())
            .key(key)
            .send()
            .await
            .map_err(provider(get_operation))?;
        let collected = output
            .body
            .collect()
            .await
            .map_err(|error| BackendError::Provider {
                operation: read_operation,
                message: error.to_string(),
            })?;
        Ok(collected.into_bytes().to_vec())
    }

    pub(super) async fn delete_object(
        &self,
        key: &str,
        operation: &'static str,
    ) -> Result<(), BackendError> {
        self.client
            .delete_object()
            .bucket(self.config.transport.bucket())
            .key(key)
            .send()
            .await
            .map_err(provider(operation))?;
        Ok(())
    }
}

struct ListedObjectEntry {
    key: String,
    last_modified: String,
}

#[derive(Clone, Copy)]
enum ListingTarget {
    Objects,
    CommonPrefixes,
}

impl ListingTarget {
    fn delimiter(self) -> Option<&'static str> {
        match self {
            Self::Objects => None,
            Self::CommonPrefixes => Some("/"),
        }
    }
}

enum ListingEntry {
    Object(ListedObjectEntry),
    CommonPrefix(String),
}

impl ListingEntry {
    fn order_key(&self) -> &str {
        match self {
            Self::Object(entry) => &entry.key,
            Self::CommonPrefix(prefix) => prefix,
        }
    }

    fn object_key(self) -> Option<String> {
        match self {
            Self::Object(entry) => Some(entry.key),
            Self::CommonPrefix(_) => None,
        }
    }

    fn into_object(self, operation: &'static str) -> Result<ListedObjectEntry, BackendError> {
        match self {
            Self::Object(entry) => Ok(entry),
            Self::CommonPrefix(prefix) => Err(BackendError::Provider {
                operation,
                message: format!(
                    "S3 listing returned common prefix '{prefix}' while reading objects"
                ),
            }),
        }
    }

    fn into_common_prefix(self, operation: &'static str) -> Result<String, BackendError> {
        match self {
            Self::CommonPrefix(prefix) => Ok(prefix),
            Self::Object(entry) => Err(BackendError::Provider {
                operation,
                message: format!(
                    "S3 listing returned object '{}' while reading prefixes",
                    entry.key
                ),
            }),
        }
    }
}

impl S3ObjectScanner<'_> {
    async fn collect_listing(
        &self,
        operation: &'static str,
        prefix: String,
        target: ListingTarget,
        start_after: Option<&str>,
        limit: Option<usize>,
    ) -> Result<Vec<ListingEntry>, BackendError> {
        let start_after = start_after
            .filter(|value| !value.is_empty())
            .map(str::to_string);
        let mut continuation = None;
        let mut last_seen = start_after.clone();
        let mut entries = Vec::new();

        while limit.is_none_or(|limit| entries.len() < limit) {
            let mut request = self
                .client
                .list_objects_v2()
                .bucket(self.config.transport.bucket())
                .prefix(&prefix);
            if let Some(delimiter) = target.delimiter() {
                request = request.delimiter(delimiter);
            }
            if let Some(page_size) = self.config.indexing.list_page_size {
                request = request.max_keys(page_size);
            }
            if let Some(token) = continuation.take() {
                request = request.continuation_token(token);
            } else if let Some(start_after) = start_after.as_deref() {
                request = request.start_after(start_after);
            }

            let output = request.send().await.map_err(provider(operation))?;
            let truncated = required_is_truncated(operation, &output)?;
            continuation = next_continuation_token(operation, &output, truncated)?;
            let reached_limit = collect_page_entries(
                operation,
                target,
                &output,
                &mut last_seen,
                &mut entries,
                limit,
            )?;
            if reached_limit || continuation.is_none() {
                break;
            }
        }

        Ok(entries)
    }
}

fn collect_page_entries(
    operation: &'static str,
    target: ListingTarget,
    output: &ListObjectsV2Output,
    last_seen: &mut Option<String>,
    entries: &mut Vec<ListingEntry>,
    limit: Option<usize>,
) -> Result<bool, BackendError> {
    match target {
        ListingTarget::Objects => {
            for (index, object) in output.contents().iter().enumerate() {
                let key = required_object_key(operation, index, object)?;
                let last_modified = required_last_modified(operation, key, object)?;
                let entry = ListingEntry::Object(ListedObjectEntry {
                    key: key.to_string(),
                    last_modified: last_modified.to_string(),
                });
                if push_listing_entry(operation, entries, last_seen, entry, limit)? {
                    return Ok(true);
                }
            }
        }
        ListingTarget::CommonPrefixes => {
            for (index, common_prefix) in output.common_prefixes().iter().enumerate() {
                let entry = ListingEntry::CommonPrefix(
                    required_common_prefix(operation, index, common_prefix)?.to_string(),
                );
                if push_listing_entry(operation, entries, last_seen, entry, limit)? {
                    return Ok(true);
                }
            }
        }
    }
    Ok(false)
}

fn push_listing_entry(
    operation: &'static str,
    entries: &mut Vec<ListingEntry>,
    last_seen: &mut Option<String>,
    entry: ListingEntry,
    limit: Option<usize>,
) -> Result<bool, BackendError> {
    ensure_provider_order(operation, last_seen, entry.order_key())?;
    entries.push(entry);
    Ok(limit.is_some_and(|limit| entries.len() >= limit))
}

fn required_common_prefix<'a>(
    operation: &'static str,
    index: usize,
    common_prefix: &'a CommonPrefix,
) -> Result<&'a str, BackendError> {
    common_prefix
        .prefix()
        .ok_or_else(|| BackendError::Provider {
            operation,
            message: format!("S3 CommonPrefix at index {index} is missing Prefix"),
        })
}

fn project_from_common_prefix(
    operation: &'static str,
    listing_prefix: &str,
    common_prefix: &str,
) -> Result<String, BackendError> {
    common_prefix
        .trim_end_matches('/')
        .strip_prefix(listing_prefix)
        .map(str::to_string)
        .ok_or_else(|| BackendError::Provider {
            operation,
            message: format!(
                "S3 CommonPrefix '{common_prefix}' does not start with requested prefix '{listing_prefix}'"
            ),
        })
}

fn required_object_key<'a>(
    operation: &'static str,
    index: usize,
    object: &'a Object,
) -> Result<&'a str, BackendError> {
    object.key().ok_or_else(|| BackendError::Provider {
        operation,
        message: format!("S3 object at index {index} is missing Key"),
    })
}

fn required_last_modified<'a>(
    operation: &'static str,
    key: &str,
    object: &'a Object,
) -> Result<&'a DateTime, BackendError> {
    object
        .last_modified()
        .ok_or_else(|| BackendError::Provider {
            operation,
            message: format!("S3 object '{key}' is missing LastModified"),
        })
}

fn required_is_truncated(
    operation: &'static str,
    output: &ListObjectsV2Output,
) -> Result<bool, BackendError> {
    output.is_truncated().ok_or_else(|| BackendError::Provider {
        operation,
        message: "S3 ListObjectsV2 response is missing IsTruncated".to_string(),
    })
}

fn next_continuation_token(
    operation: &'static str,
    output: &ListObjectsV2Output,
    truncated: bool,
) -> Result<Option<String>, BackendError> {
    if truncated {
        output
            .next_continuation_token()
            .map(str::to_string)
            .map(Some)
            .ok_or_else(|| BackendError::Provider {
                operation,
                message: "truncated S3 listing did not include NextContinuationToken".to_string(),
            })
    } else {
        Ok(None)
    }
}

fn ensure_provider_order(
    operation: &'static str,
    last_seen: &mut Option<String>,
    key: &str,
) -> Result<(), BackendError> {
    if let Some(previous) = last_seen.as_deref() {
        if key < previous {
            return Err(BackendError::Provider {
                operation,
                message: format!(
                    "S3 provider returned key '{key}' after later key '{previous}'; this backend requires lexicographic ListObjectsV2 order"
                ),
            });
        }
    }
    *last_seen = Some(key.to_string());
    Ok(())
}
