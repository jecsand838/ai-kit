use rurr_core::application::ApplicationBuilder;
use rurr_persistence::{
    ApplicationPersistenceSpec, AsyncBaseStateLoader, AsyncBaseStateSaver, BaseStateLoader,
    BaseStateSaver, PersistedStateStatus, PersistenceError, StateInitializerSpec,
};
use rurr_sqlite::{AsyncSqlitePersister, SqlitePersister};
use rurr_testkit::persistence_cases::{self, map_from_pairs};
use rurr_testkit::test_dir_for_test;
use serde_json::json;
use std::sync::Arc;

mod support;

use support::{assert_resumed_state, noop_action, SqliteAsyncLane};

macro_rules! async_case_tests {
    ($(($name:ident, $db:literal, $table:literal, $case:path, $message:literal)),+ $(,)?) => {
        $(
            #[tokio::test]
            async fn $name() {
                let lane = SqliteAsyncLane::new($db, $table);
                $case(&lane).await.expect($message);
            }
        )+
    };
}

#[tokio::test]
async fn async_initialize_save_load_list_and_is_initialized() {
    let persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        "sqlite::memory:",
        "async_roundtrip",
    ))
    .expect("persister should create");
    assert!(!persister
        .is_initialized()
        .await
        .expect("is_initialized should work"));

    persister
        .initialize()
        .await
        .expect("initialize should succeed");
    assert!(persister
        .is_initialized()
        .await
        .expect("is_initialized should work"));

    persister
        .save(
            Some("partition"),
            "app_id",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("save should succeed");

    let loaded = persister
        .load(Some("partition"), Some("app_id"), None)
        .await
        .expect("load should succeed")
        .expect("state should exist");
    let app_ids = persister
        .list_app_ids(Some("partition"))
        .await
        .expect("list_app_ids should succeed");

    assert_eq!(loaded.partition_key.as_deref(), Some("partition"));
    assert_eq!(loaded.app_id, "app_id");
    assert_eq!(loaded.sequence_id, 1);
    assert_eq!(loaded.position.as_deref(), Some("position"));
    assert_eq!(
        loaded.state,
        Some(map_from_pairs([("key", json!("value"))]))
    );
    assert_eq!(loaded.status, PersistedStateStatus::Completed);
    assert_eq!(app_ids, vec!["app_id".to_string()]);

    persister.close().await.expect("close should succeed");
}

#[tokio::test]
async fn async_methods_before_initialize_return_not_initialized() {
    let lane = SqliteAsyncLane::new("async-not-initialized.db", "async_not_initialized");
    persistence_cases::not_initialized_for_load_save_and_list(&lane).await;
}

#[tokio::test]
async fn same_instance_reprobes_after_external_initialize_and_recreate_async() {
    let lane = SqliteAsyncLane::new("async-reprobe.db", "async_reprobe");
    persistence_cases::same_instance_reprobes_after_external_initialize_and_recreate(&lane)
        .await
        .expect("reprobe assertions should succeed");
}

#[tokio::test]
async fn from_values_supports_path_and_url_inputs() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let db_path = temp_dir.join("path-or-url.db");
    let db_path_str = db_path
        .to_str()
        .expect("temp db path should be valid UTF-8")
        .to_string();

    let path_persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path_str,
        "async_path_url",
    ))
    .expect("persister should create from path");
    path_persister
        .initialize()
        .await
        .expect("initialize should succeed");
    path_persister.close().await.expect("close should succeed");

    let database_url = format!("sqlite://{db_path_str}");
    let url_persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &database_url,
        "async_path_url",
    ))
    .expect("persister should create from URL");
    assert!(url_persister
        .is_initialized()
        .await
        .expect("is_initialized should succeed"));
    url_persister.close().await.expect("close should succeed");
}

#[tokio::test]
async fn from_values_rejects_digit_prefixed_table_name_async() {
    let error = match AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        "sqlite::memory:",
        "1invalid_table",
    )) {
        Ok(_) => panic!("digit-prefixed table name should be rejected"),
        Err(error) => error,
    };

    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation { operation } if operation == "invalid_table_name"
    ));
}

async_case_tests!(
    (
        list_app_ids_orders_by_latest_created_at_not_sequence_id_async,
        "async-created-at-order.db",
        "async_created_order",
        persistence_cases::list_app_ids_order,
        "list_app_ids ordering assertions should succeed"
    ),
    (
        load_without_app_id_orders_by_latest_created_at_not_sequence_id_async,
        "async-load-created-at-order.db",
        "async_load_created_order",
        persistence_cases::latest_partition_prefers_newest_created_at,
        "latest partition ordering assertions should succeed"
    ),
    (
        load_exact_sequence_orders_by_created_at_then_position_async,
        "async-load-sequence-order.db",
        "async_load_sequence_order",
        persistence_cases::exact_sequence_prefers_latest_created_at_then_position,
        "exact-sequence ordering assertions should succeed"
    ),
    (
        load_with_sequence_id_and_no_app_id_returns_none_async,
        "async-load-seq-without-app-id.db",
        "async_load_seq_without_app",
        persistence_cases::load_with_sequence_id_and_no_app_id_returns_none,
        "missing-app-id assertions should succeed"
    )
);

#[tokio::test]
async fn save_accepts_same_sequence_with_different_position_and_rejects_exact_duplicate_async() {
    let lane = SqliteAsyncLane::new("async-duplicate-identity.db", "async_duplicate_identity");
    persistence_cases::duplicate_identity_behavior(&lane, "sqlite_query_failed")
        .await
        .expect("duplicate identity assertions should succeed");
}

#[tokio::test]
async fn close_is_idempotent_and_methods_fail_after_close() {
    let persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        "sqlite::memory:",
        "async_close",
    ))
    .expect("persister should create");
    persister
        .initialize()
        .await
        .expect("initialize should succeed");
    persister.close().await.expect("first close should succeed");
    persister
        .close()
        .await
        .expect("second close should succeed");

    let list_error = persister
        .list_app_ids(Some("partition"))
        .await
        .expect_err("operations should fail after close");
    assert!(matches!(
        list_error,
        PersistenceError::UnsupportedOperation { operation } if operation == "connection_closed"
    ));
}

#[tokio::test]
async fn drop_then_reopen_persister_retains_file_backed_state() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let db_path = temp_dir.join("drop-reopen.db");
    let db_path_str = db_path
        .to_str()
        .expect("temp db path should be valid UTF-8")
        .to_string();

    {
        let persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
            &db_path_str,
            "async_reopen",
        ))
        .expect("persister should create");
        persister
            .initialize()
            .await
            .expect("initialize should succeed");
        persister
            .save(
                Some("partition"),
                "app_id",
                1,
                "position",
                map_from_pairs([("key", json!("value"))]),
                PersistedStateStatus::Completed,
            )
            .await
            .expect("save should succeed");
    }

    let reopened = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path_str,
        "async_reopen",
    ))
    .expect("persister should create");
    assert!(reopened
        .is_initialized()
        .await
        .expect("is_initialized should succeed"));
    let loaded = reopened
        .load(Some("partition"), Some("app_id"), None)
        .await
        .expect("load should succeed")
        .expect("state should exist");
    assert_eq!(
        loaded.state,
        Some(map_from_pairs([("key", json!("value"))]))
    );
    reopened.close().await.expect("close should succeed");
}

#[tokio::test]
async fn cloned_persister_shares_underlying_state() {
    let persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        "sqlite::memory:",
        "async_copy",
    ))
    .expect("persister should create");
    persister
        .initialize()
        .await
        .expect("initialize should succeed");
    persister
        .save(
            Some("partition"),
            "app_id",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("save should succeed");

    let copied = persister.clone();
    let loaded = copied
        .load(Some("partition"), Some("app_id"), None)
        .await
        .expect("load should succeed")
        .expect("state should exist");
    assert_eq!(
        loaded.state,
        Some(map_from_pairs([("key", json!("value"))]))
    );

    persister.close().await.expect("close should succeed");
}

#[tokio::test]
async fn cloned_persister_close_is_shared_and_returns_connection_closed() {
    let persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        "sqlite::memory:",
        "async_copy_closed",
    ))
    .expect("persister should create");
    persister
        .initialize()
        .await
        .expect("initialize should succeed");

    let copied = persister.clone();
    persister.close().await.expect("close should succeed");

    let error = copied
        .list_app_ids(Some("partition"))
        .await
        .expect_err("copied persister should observe closed connection");
    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation { operation } if operation == "connection_closed"
    ));
}

#[tokio::test]
async fn async_to_sync_initializer_spec_resume_interoperability() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let db_path = temp_dir.join("async-to-sync-resume.db");
    let db_path_str = db_path
        .to_str()
        .expect("temp db path should be valid UTF-8")
        .to_string();

    let async_persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path_str,
        "async_sync_resume",
    ))
    .expect("persister should create");
    async_persister
        .initialize()
        .await
        .expect("initialize should succeed");
    async_persister
        .save(
            Some("sqlite"),
            "test_1",
            5,
            "noop",
            map_from_pairs([("chat_history", json!([1, 2]))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("save should succeed");
    async_persister.close().await.expect("close should succeed");

    let sync_persister = SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path,
        "async_sync_resume",
    ))
    .expect("persister should create");
    assert!(sync_persister
        .is_initialized()
        .expect("is_initialized should work"));

    let initializer: Arc<dyn BaseStateLoader> = Arc::new(sync_persister);
    let app = ApplicationBuilder::new()
        .with_actions(vec![("noop", noop_action())])
        .expect("actions should configure")
        .with_identifiers("test_1", Some("sqlite".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(ApplicationPersistenceSpec::new().with_initializer(
            StateInitializerSpec::sync(
                initializer,
                true,
                map_from_pairs([("chat_history", json!([]))]),
                "noop",
                None,
            ),
        ))
        .expect("initializer spec should configure")
        .build()
        .expect("build should succeed");

    assert_resumed_state(&app, 5);
}

#[tokio::test]
async fn sync_async_load_parity_for_state_and_status() {
    let temp_dir = test_dir_for_test().expect("temp dir should be created");
    let db_path = temp_dir.join("sync-async-parity.db");
    let db_path_str = db_path
        .to_str()
        .expect("temp db path should be valid UTF-8")
        .to_string();

    let async_persister = AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path_str,
        "sync_async_parity",
    ))
    .expect("async persister should create");
    async_persister
        .initialize()
        .await
        .expect("async initialize should succeed");
    async_persister
        .save(
            Some("partition"),
            "app_id",
            42,
            "position_sync",
            map_from_pairs([("k", json!("v"))]),
            PersistedStateStatus::Failed,
        )
        .await
        .expect("async save should succeed");
    async_persister
        .close()
        .await
        .expect("async close should succeed");

    let sync = SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
        &db_path,
        "sync_async_parity",
    ))
    .expect("sync persister should create");
    assert!(sync
        .is_initialized()
        .expect("sync is_initialized should succeed"));
    let loaded = sync
        .load(Some("partition"), Some("app_id"), Some(42))
        .expect("sync load should succeed")
        .expect("record should exist");

    assert_eq!(loaded.sequence_id, 42);
    assert_eq!(loaded.position.as_deref(), Some("position_sync"));
    assert_eq!(loaded.state, Some(map_from_pairs([("k", json!("v"))])));
    assert_eq!(loaded.status, PersistedStateStatus::Failed);
}
