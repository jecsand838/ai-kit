mod decoder;
mod fixture_io;
mod template;

use crate::TestCaseCreateArgs;
use decoder::TrackedStateDecoder;
use fixture_io::emit_fixture;
use rurr_tracking_store::tracking_repository::{
    extract_local_test_case, LocalTestCaseExtraction, LocalTestCaseStatus,
};
use std::error::Error;

pub(crate) fn create(args: TestCaseCreateArgs) -> Result<(), Box<dyn Error>> {
    let decoder = TrackedStateDecoder::from_args(&args);
    let Some(extraction) = extract_local_test_case(
        &args.storage_dir,
        &args.project_name,
        args.partition_key.as_deref(),
        &args.app_id,
        args.sequence_id,
        args.action_name.as_deref(),
        |values| decoder.decode(values),
    )?
    else {
        println!(
            "No state found for {}, {}, {}, {}.",
            args.project_name,
            args.partition_key.as_deref().unwrap_or(""),
            args.app_id,
            args.sequence_id
        );
        return Ok(());
    };

    print_extraction_status(&extraction);
    emit_fixture(args.target_file_name.as_deref(), &extraction.fixture)?;

    println!("\nAdd the following to your test file:\n");
    println!(
        "{}",
        template::helper_template(args.target_file_name.as_deref(), &extraction)
    );
    Ok(())
}

fn print_extraction_status(extraction: &LocalTestCaseExtraction) {
    if extraction.status == LocalTestCaseStatus::Completed {
        println!("Action was successful so loading initial and expected state into test fixture.");
    }
}

#[cfg(test)]
mod tests;
