use super::adapter::LifecycleError;
use crate::action::api::ActionInputs;
use crate::state::State;
use crate::visibility::ActionSpan;
use indexmap::IndexMap;
use serde_json::Value;
use std::time::SystemTime;

/// Context passed to execute-call lifecycle hooks.
///
/// This context describes the execute-style API call that is about to advance
/// the application. Inputs are optional because some calls advance with stored
/// state only.
///
/// # Examples
///
/// ```
/// use rurr_core::ExecuteCallContext;
///
/// let context = ExecuteCallContext::new("app", "", "count", 1);
/// assert_eq!(context.app_id(), "app");
/// assert_eq!(context.partition_key(), "");
/// assert_eq!(context.action_name(), "count");
/// ```
#[derive(Debug, Clone)]
pub struct ExecuteCallContext {
    app_id: String,
    partition_key: String,
    action_name: String,
    sequence_id: u64,
    inputs: Option<ActionInputs>,
}

impl PartialEq for ExecuteCallContext {
    fn eq(&self, other: &Self) -> bool {
        self.app_id == other.app_id
            && self.partition_key == other.partition_key
            && self.action_name == other.action_name
            && self.sequence_id == other.sequence_id
    }
}

impl Eq for ExecuteCallContext {}

impl ExecuteCallContext {
    /// Creates a new execute-call context.
    pub fn new(
        app_id: impl Into<String>,
        partition_key: impl Into<String>,
        action_name: impl Into<String>,
        sequence_id: u64,
    ) -> Self {
        Self {
            app_id: app_id.into(),
            partition_key: partition_key.into(),
            action_name: action_name.into(),
            sequence_id,
            inputs: None,
        }
    }

    /// Returns the application id.
    pub fn app_id(&self) -> &str {
        &self.app_id
    }

    /// Returns the partition key string, using the empty string for the
    /// unpartitioned lane.
    pub fn partition_key(&self) -> &str {
        &self.partition_key
    }

    /// Returns the action name about to be executed.
    pub fn action_name(&self) -> &str {
        &self.action_name
    }

    /// Returns the sequence id reserved for the action.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }

    /// Attaches runtime inputs to the context.
    pub fn with_inputs(mut self, inputs: ActionInputs) -> Self {
        self.inputs = Some(inputs);
        self
    }

    /// Returns the runtime inputs, when they were attached.
    pub fn inputs(&self) -> Option<&ActionInputs> {
        self.inputs.as_ref()
    }
}

/// Identifies whether a lifecycle hook is executing through the sync or async runtime lane.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LifecycleExecutionMode {
    /// The hook is executing through synchronous application APIs.
    Sync,
    /// The hook is executing through asynchronous application APIs.
    Async,
}

/// Context passed to pre-step lifecycle hooks.
///
/// Pre-step hooks see the reserved sequence id, step-local id, and runtime inputs
/// before the action body runs.
#[derive(Debug, Clone)]
pub struct PreStepContext {
    app_id: Option<String>,
    action_name: String,
    sequence_id: u64,
    step_id: u64,
    started_at: SystemTime,
    inputs: Option<ActionInputs>,
    execution_mode: LifecycleExecutionMode,
}

impl PartialEq for PreStepContext {
    fn eq(&self, other: &Self) -> bool {
        self.app_id == other.app_id
            && self.action_name == other.action_name
            && self.sequence_id == other.sequence_id
            && self.step_id == other.step_id
    }
}

impl Eq for PreStepContext {}

impl PreStepContext {
    /// Creates a new pre-step context.
    pub fn new(
        action_name: impl Into<String>,
        sequence_id: u64,
        step_id: u64,
        started_at: SystemTime,
    ) -> Self {
        Self {
            app_id: None,
            action_name: action_name.into(),
            sequence_id,
            step_id,
            started_at,
            inputs: None,
            execution_mode: LifecycleExecutionMode::Sync,
        }
    }

    /// Returns the action name being executed.
    pub fn action_name(&self) -> &str {
        &self.action_name
    }

    /// Attaches the application id.
    pub fn with_app_id(mut self, app_id: impl Into<String>) -> Self {
        self.app_id = Some(app_id.into());
        self
    }

    /// Returns the application id, when present.
    pub fn app_id(&self) -> Option<&str> {
        self.app_id.as_deref()
    }

    /// Returns the reserved sequence id for the step.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }

    /// Returns the step-local id used by lifecycle reporting.
    pub fn step_id(&self) -> u64 {
        self.step_id
    }

    /// Returns when the step started.
    pub fn started_at(&self) -> SystemTime {
        self.started_at
    }

    /// Attaches runtime inputs to the context.
    pub fn with_inputs(mut self, inputs: ActionInputs) -> Self {
        self.inputs = Some(inputs);
        self
    }

    /// Returns the runtime inputs, when they were attached.
    pub fn inputs(&self) -> Option<&ActionInputs> {
        self.inputs.as_ref()
    }

    /// Marks whether this step will be executed through sync or async APIs.
    pub fn with_execution_mode(mut self, execution_mode: LifecycleExecutionMode) -> Self {
        self.execution_mode = execution_mode;
        self
    }

    /// Returns the runtime lane executing this step.
    pub fn execution_mode(&self) -> LifecycleExecutionMode {
        self.execution_mode
    }
}

/// Context passed to post-step lifecycle hooks.
#[derive(Debug, Clone)]
pub struct PostStepContext {
    app_id: Option<String>,
    action_name: String,
    sequence_id: u64,
    step_id: u64,
    started_at: SystemTime,
    result: Option<IndexMap<String, Value>>,
    state: Option<State>,
    exception: Option<String>,
    execution_mode: LifecycleExecutionMode,
}

impl PartialEq for PostStepContext {
    fn eq(&self, other: &Self) -> bool {
        self.app_id == other.app_id
            && self.action_name == other.action_name
            && self.sequence_id == other.sequence_id
            && self.step_id == other.step_id
    }
}

impl Eq for PostStepContext {}

impl PostStepContext {
    /// Creates a new post-step context.
    pub fn new(
        action_name: impl Into<String>,
        sequence_id: u64,
        step_id: u64,
        started_at: SystemTime,
    ) -> Self {
        Self {
            app_id: None,
            action_name: action_name.into(),
            sequence_id,
            step_id,
            started_at,
            result: None,
            state: None,
            exception: None,
            execution_mode: LifecycleExecutionMode::Sync,
        }
    }

    /// Returns the action name that just ran.
    pub fn action_name(&self) -> &str {
        &self.action_name
    }

    /// Attaches the application id.
    pub fn with_app_id(mut self, app_id: impl Into<String>) -> Self {
        self.app_id = Some(app_id.into());
        self
    }

    /// Returns the application id, when present.
    pub fn app_id(&self) -> Option<&str> {
        self.app_id.as_deref()
    }

    /// Returns the reserved sequence id for the step.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }

    /// Returns the step-local id used by lifecycle reporting.
    pub fn step_id(&self) -> u64 {
        self.step_id
    }

    /// Returns when the step started.
    pub fn started_at(&self) -> SystemTime {
        self.started_at
    }

    /// Attaches the action result payload.
    pub fn with_result(mut self, result: IndexMap<String, Value>) -> Self {
        self.result = Some(result);
        self
    }

    /// Returns the action result payload, when present.
    pub fn result(&self) -> Option<&IndexMap<String, Value>> {
        self.result.as_ref()
    }

    /// Attaches the committed state snapshot.
    pub fn with_state(mut self, state: State) -> Self {
        self.state = Some(state);
        self
    }

    /// Returns the committed state snapshot, when present.
    pub fn state(&self) -> Option<&State> {
        self.state.as_ref()
    }

    /// Returns the committed state snapshot or fails the lifecycle hook.
    ///
    /// Tracking and logging hooks call this when they require the state that
    /// was actually committed by the completed step. A missing state is a
    /// lifecycle error; consumers must not serialize an invented empty state
    /// snapshot.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::time::SystemTime;
    ///
    /// use rurr_core::{PostStepContext, State};
    ///
    /// let context = PostStepContext::new("count", 1, 1, SystemTime::now())
    ///     .with_state(State::default());
    /// assert!(context.require_state_for("post_run_step", "docs").is_ok());
    ///
    /// let missing = PostStepContext::new("count", 1, 2, SystemTime::now());
    /// assert!(missing.require_state_for("post_run_step", "docs").is_err());
    /// ```
    pub fn require_state_for(
        &self,
        operation: &'static str,
        consumer: &'static str,
    ) -> Result<&State, LifecycleError> {
        self.state.as_ref().ok_or_else(|| {
            LifecycleError::hook_failed(
                operation,
                format!("{consumer} requires committed post-step state"),
            )
        })
    }

    /// Attaches an exception string recorded for the step.
    pub fn with_exception(mut self, exception: impl Into<String>) -> Self {
        self.exception = Some(exception.into());
        self
    }

    /// Returns the exception string, when one was recorded.
    pub fn exception(&self) -> Option<&str> {
        self.exception.as_deref()
    }

    /// Marks whether this step was executed through sync or async APIs.
    pub fn with_execution_mode(mut self, execution_mode: LifecycleExecutionMode) -> Self {
        self.execution_mode = execution_mode;
        self
    }

    /// Returns the runtime lane that executed this step.
    pub fn execution_mode(&self) -> LifecycleExecutionMode {
        self.execution_mode
    }
}

/// Context passed to stream lifecycle hooks.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StreamContext {
    app_id: Option<String>,
    action_name: String,
    sequence_id: u64,
    stream_id: u64,
}

impl StreamContext {
    /// Creates a new stream context.
    pub fn new(action_name: impl Into<String>, sequence_id: u64, stream_id: u64) -> Self {
        Self {
            app_id: None,
            action_name: action_name.into(),
            sequence_id,
            stream_id,
        }
    }

    /// Returns the action name that owns the stream.
    pub fn action_name(&self) -> &str {
        &self.action_name
    }

    /// Attaches the application id.
    pub fn with_app_id(mut self, app_id: impl Into<String>) -> Self {
        self.app_id = Some(app_id.into());
        self
    }

    /// Returns the application id, when present.
    pub fn app_id(&self) -> Option<&str> {
        self.app_id.as_deref()
    }

    /// Returns the action sequence id.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }

    /// Returns the stream-local id.
    pub fn stream_id(&self) -> u64 {
        self.stream_id
    }
}

/// Context passed to per-stream-item lifecycle hooks.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StreamItemContext {
    app_id: Option<String>,
    action_name: String,
    sequence_id: u64,
    stream_id: u64,
    item_index: usize,
}

impl StreamItemContext {
    /// Creates a new stream-item context.
    pub fn new(
        action_name: impl Into<String>,
        sequence_id: u64,
        stream_id: u64,
        item_index: usize,
    ) -> Self {
        Self {
            app_id: None,
            action_name: action_name.into(),
            sequence_id,
            stream_id,
            item_index,
        }
    }

    /// Returns the action name that owns the stream.
    pub fn action_name(&self) -> &str {
        &self.action_name
    }

    /// Attaches the application id.
    pub fn with_app_id(mut self, app_id: impl Into<String>) -> Self {
        self.app_id = Some(app_id.into());
        self
    }

    /// Returns the application id, when present.
    pub fn app_id(&self) -> Option<&str> {
        self.app_id.as_deref()
    }

    /// Returns the action sequence id.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }

    /// Returns the stream-local id.
    pub fn stream_id(&self) -> u64 {
        self.stream_id
    }

    /// Returns the zero-based item index inside the stream.
    pub fn item_index(&self) -> usize {
        self.item_index
    }
}

/// Context used when lifecycle adapters may provide a parent for root visibility spans.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct VisibilityRootContext {
    app_id: String,
    partition_key: Option<String>,
    action_name: String,
    sequence_id: u64,
}

impl VisibilityRootContext {
    /// Creates a new visibility root context for one action execution.
    pub fn new(
        app_id: impl Into<String>,
        action_name: impl Into<String>,
        sequence_id: u64,
    ) -> Self {
        Self {
            app_id: app_id.into(),
            partition_key: None,
            action_name: action_name.into(),
            sequence_id,
        }
    }

    /// Attaches the partition key when the action is associated with a partitioned app.
    pub fn with_partition_key(mut self, partition_key: impl Into<String>) -> Self {
        self.partition_key = Some(partition_key.into());
        self
    }

    /// Returns the application id.
    pub fn app_id(&self) -> &str {
        &self.app_id
    }

    /// Returns the partition key, when present.
    pub fn partition_key(&self) -> Option<&str> {
        self.partition_key.as_deref()
    }

    /// Returns the action name.
    pub fn action_name(&self) -> &str {
        &self.action_name
    }

    /// Returns the action sequence id.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }
}

/// Context passed to span lifecycle hooks.
#[derive(Debug, Clone)]
pub struct SpanContext {
    app_id: Option<String>,
    partition_key: Option<String>,
    action_name: String,
    sequence_id: u64,
    span_id: String,
    span_name: Option<String>,
    parent_span_id: Option<String>,
    span_dependencies: Vec<String>,
    action_span: Option<ActionSpan>,
    execution_mode: LifecycleExecutionMode,
}

impl PartialEq for SpanContext {
    fn eq(&self, other: &Self) -> bool {
        self.app_id == other.app_id
            && self.partition_key == other.partition_key
            && self.action_name == other.action_name
            && self.sequence_id == other.sequence_id
            && self.span_id == other.span_id
            && self.span_name == other.span_name
            && self.parent_span_id == other.parent_span_id
            && self.span_dependencies == other.span_dependencies
    }
}

impl Eq for SpanContext {}

impl SpanContext {
    /// Creates a new span context.
    pub fn new(
        action_name: impl Into<String>,
        sequence_id: u64,
        span_id: impl Into<String>,
    ) -> Self {
        Self {
            app_id: None,
            partition_key: None,
            action_name: action_name.into(),
            sequence_id,
            span_id: span_id.into(),
            span_name: None,
            parent_span_id: None,
            span_dependencies: Vec::new(),
            action_span: None,
            execution_mode: LifecycleExecutionMode::Sync,
        }
    }

    /// Returns the action name that owns the span.
    pub fn action_name(&self) -> &str {
        &self.action_name
    }

    /// Attaches the application id.
    pub fn with_app_id(mut self, app_id: impl Into<String>) -> Self {
        self.app_id = Some(app_id.into());
        self
    }

    /// Returns the application id, when present.
    pub fn app_id(&self) -> Option<&str> {
        self.app_id.as_deref()
    }

    /// Attaches the partition key when the span is associated with a partitioned app.
    ///
    /// Spans for unpartitioned apps should omit this field and leave it as `None`.
    pub fn with_partition_key(mut self, partition_key: impl Into<String>) -> Self {
        self.partition_key = Some(partition_key.into());
        self
    }

    /// Returns the partition key, when present.
    ///
    /// `None` indicates the unpartitioned app lane.
    pub fn partition_key(&self) -> Option<&str> {
        self.partition_key.as_deref()
    }

    /// Returns the action sequence id.
    pub fn sequence_id(&self) -> u64 {
        self.sequence_id
    }

    /// Returns the span id.
    pub fn span_id(&self) -> &str {
        &self.span_id
    }

    /// Attaches the human-readable span name.
    pub fn with_span_name(mut self, span_name: impl Into<String>) -> Self {
        self.span_name = Some(span_name.into());
        self
    }

    /// Returns the human-readable span name, when present.
    pub fn span_name(&self) -> Option<&str> {
        self.span_name.as_deref()
    }

    /// Attaches the parent span id.
    pub fn with_parent_span_id(mut self, parent_span_id: impl Into<String>) -> Self {
        self.parent_span_id = Some(parent_span_id.into());
        self
    }

    /// Returns the parent span id, when present.
    pub fn parent_span_id(&self) -> Option<&str> {
        self.parent_span_id.as_deref()
    }

    /// Replaces the explicit span dependency list.
    pub fn with_span_dependencies(mut self, span_dependencies: Vec<String>) -> Self {
        self.span_dependencies = span_dependencies;
        self
    }

    /// Returns the span dependency ids.
    pub fn span_dependencies(&self) -> &[String] {
        &self.span_dependencies
    }

    pub(crate) fn with_action_span(mut self, action_span: ActionSpan) -> Self {
        self.action_span = Some(action_span);
        self
    }

    /// Returns the runtime action span associated with this lifecycle span.
    pub fn action_span(&self) -> Option<&ActionSpan> {
        self.action_span.as_ref()
    }

    /// Marks whether this span is executing through sync or async APIs.
    pub fn with_execution_mode(mut self, execution_mode: LifecycleExecutionMode) -> Self {
        self.execution_mode = execution_mode;
        self
    }

    /// Returns the runtime lane executing this span.
    pub fn execution_mode(&self) -> LifecycleExecutionMode {
        self.execution_mode
    }
}
