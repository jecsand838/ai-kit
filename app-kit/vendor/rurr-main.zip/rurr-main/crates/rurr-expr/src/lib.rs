//! Expression parsing and evaluation helpers for the bounded Burr-compatible
//! condition language that Rurr exposes publicly.
//!
//! The main entrypoints are [`parse`] for syntax validation and
//! [`evaluate_bool`] for executing a validated expression against a lightweight
//! state view. Unsupported Python AST nodes fail at parse/validation time
//! rather than falling back to host-language evaluation.
//! Python-style identity comparisons (`is` and `is not`) are supported for
//! JSON null and boolean singleton checks.
//!
//! ```rust
//! use rurr_expr::{evaluate_bool, parse, StateView};
//! use serde_json::{json, Value};
//! use std::collections::HashMap;
//!
//! struct ExampleState {
//!     values: HashMap<String, Value>,
//! }
//!
//! impl StateView for ExampleState {
//!     fn get_value(&self, key: &str) -> Option<&Value> {
//!         self.values.get(key)
//!     }
//! }
//!
//! let ast = parse("count >= 2 and flag is True")?;
//! let state = ExampleState {
//!     values: HashMap::from([
//!         ("count".to_string(), json!(3)),
//!         ("flag".to_string(), json!(true)),
//!     ]),
//! };
//!
//! assert!(evaluate_bool(&ast, &state)?);
//! # Ok::<(), rurr_expr::ExprError>(())
//! ```
#![deny(missing_docs)]

use rustpython_parser::ast;
use serde_json::Value;
use thiserror::Error;

mod eval;
mod parse;
/// Validation helpers for the bounded expression AST accepted by Rurr.
pub mod validate;
/// Internal runtime value conversions used while evaluating parsed expressions.
pub mod value;

/// Evaluates a validated expression as a boolean against a [`StateView`].
pub use eval::{
    compare_eval_values, compare_json_values, condition_rule_name, evaluate_bool, python_repr,
    python_repr_with_mode, ComparisonOperator, PythonReprMode,
};
/// Parses a source expression into a validated [`ExprAst`].
pub use parse::{parse, referenced_names};

/// Parsed and validated expression tree for Rurr's condition language.
#[derive(Debug, Clone)]
pub struct ExprAst {
    expr: ast::Expr,
}

/// Lightweight read-only access to values referenced by an expression.
pub trait StateView {
    /// Returns the JSON value bound to `key`, if present.
    fn get_value(&self, key: &str) -> Option<&Value>;
}

/// Errors produced while parsing, validating, or evaluating expressions.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum ExprError {
    /// Parsing failed before validation or evaluation could start.
    #[error("failed to parse expression: {message}")]
    Parse {
        /// Human-readable parse failure details.
        message: String,
    },
    /// The expression contained an AST node outside Rurr's supported subset.
    #[error("unsupported expression node: {node}")]
    UnsupportedNode {
        /// Stable diagnostic name for the unsupported AST node.
        node: String,
    },
    /// The expression contained an operator outside Rurr's supported subset.
    #[error("unsupported expression operator: {operator}")]
    UnsupportedOperator {
        /// Human-readable operator name or debug representation.
        operator: String,
    },
    /// The expression contained a constant shape outside Rurr's supported subset.
    #[error("unsupported expression constant: {constant}")]
    UnsupportedConstant {
        /// Human-readable constant description.
        constant: String,
    },
    /// The expression used an unsupported function-call form.
    #[error("invalid function call: {message}")]
    InvalidCall {
        /// Details about the invalid call expression.
        message: String,
    },
    /// Evaluation referenced a name that the supplied state view could not resolve.
    #[error("unknown name '{name}'")]
    UnknownName {
        /// Name that was missing from the supplied state view.
        name: String,
    },
    /// Evaluation encountered a value of the wrong type for the requested operation.
    #[error("type error: {message}")]
    TypeError {
        /// Human-readable type-mismatch details.
        message: String,
    },
    /// Evaluation encountered an invalid `in` or `not in` operation.
    #[error("invalid membership test: {message}")]
    InvalidMembership {
        /// Human-readable membership failure details.
        message: String,
    },
    /// Evaluation encountered an invalid attribute or subscript lookup.
    #[error("invalid subscript: {message}")]
    InvalidSubscript {
        /// Human-readable attribute or subscript failure details.
        message: String,
    },
    /// Evaluation overflowed while converting or manipulating an integer.
    #[error("integer overflow")]
    IntegerOverflow,
    /// Evaluation attempted to divide by zero.
    #[error("division by zero")]
    DivisionByZero,
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;
    use std::collections::HashMap;

    struct TestState {
        values: HashMap<String, Value>,
    }

    impl TestState {
        fn from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> Self {
            Self {
                values: pairs
                    .into_iter()
                    .map(|(key, value)| (key.to_string(), value))
                    .collect(),
            }
        }
    }

    impl StateView for TestState {
        fn get_value(&self, key: &str) -> Option<&Value> {
            self.values.get(key)
        }
    }

    #[test]
    fn mixed_int_float_comparison_is_exact_near_2_pow_53() {
        let ast = parse("n > 9007199254740992.0").expect("parse should succeed");
        let state = TestState::from_pairs([("n", json!(9007199254740993_i64))]);
        assert!(
            evaluate_bool(&ast, &state).expect("evaluation should succeed"),
            "comparison should remain exact near 2^53"
        );
    }

    #[test]
    fn python_modulo_sign_matches_divisor() {
        let ast = parse("n % -2 == -1").expect("parse should succeed");
        let state = TestState::from_pairs([("n", json!(1))]);
        assert!(evaluate_bool(&ast, &state).expect("evaluation should succeed"));
    }

    #[test]
    fn python_repr_uses_python_singletons_and_collection_spelling() {
        assert_eq!(python_repr(&json!(null)), "None");
        assert_eq!(python_repr(&json!(true)), "True");
        assert_eq!(python_repr(&json!("can\\'t")), "'can\\\\\\'t'");
        assert_eq!(python_repr(&json!(["x", false])), "['x', False]");
        assert_eq!(
            python_repr(&json!({"enabled": true, "items": [1, null]})),
            "{'enabled': True, 'items': [1, None]}"
        );
    }

    #[test]
    fn condition_rule_name_uses_burr_equality_spelling_and_python_repr_elsewhere() {
        assert_eq!(
            condition_rule_name("status", ComparisonOperator::Eq, &json!("ready")),
            "status=ready"
        );
        assert_eq!(
            condition_rule_name("status", ComparisonOperator::NotEq, &json!("ready")),
            "status!='ready'"
        );
        assert_eq!(
            condition_rule_name("items", ComparisonOperator::Contains, &json!("needle")),
            "items contains 'needle'"
        );
    }
}
