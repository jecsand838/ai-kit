//! Helpers for executing one oracle scenario inside an isolated storage root.
//!
//! The runner prepares scenario-local storage, wires a real
//! [`LocalTrackingClient`](rurr_core::tracking::LocalTrackingClient), executes
//! the scenario implementation, and returns the resulting application directory
//! plus any persistence payloads emitted along the way.

use crate::cases::run_case;
use crate::manifest::BurrOracleScenario;
use rurr_core::lifecycle::{LifecycleAdapterSet, SyncLifecycleAdapter};
use rurr_core::tracking::LocalTrackingClient;
use serde_json::Value;
use std::error::Error;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::Arc;

/// Outputs collected while executing an oracle scenario locally.
#[derive(Debug)]
pub struct ScenarioRunResult {
    /// Application directory produced by the run.
    pub app_dir: PathBuf,
    /// Persisted-state payloads emitted by scenarios that exercise persistence.
    pub persisted_state_payloads: Vec<Value>,
}

fn prepare_scenario_storage(
    temp_storage_root: &Path,
    scenario_id: &str,
) -> Result<PathBuf, Box<dyn Error>> {
    let scenario_storage = temp_storage_root.join(scenario_id);
    if scenario_storage.exists() {
        fs::remove_dir_all(&scenario_storage)?;
    }
    fs::create_dir_all(&scenario_storage)?;
    Ok(scenario_storage)
}

fn scenario_app_dir(definition: &BurrOracleScenario, scenario_storage: &Path) -> PathBuf {
    scenario_storage
        .join(&definition.project)
        .join(&definition.app_id)
}

fn validate_scenario_app_dir(
    definition: &BurrOracleScenario,
    app_dir: PathBuf,
) -> Result<PathBuf, Box<dyn Error>> {
    if !app_dir.exists() {
        return Err(format!("scenario {} produced no app dir", definition.id).into());
    }
    Ok(app_dir)
}

/// Runs `definition` inside a fresh scenario-specific storage root.
pub fn run_oracle_scenario(
    definition: &BurrOracleScenario,
    temp_storage_root: &Path,
) -> Result<ScenarioRunResult, Box<dyn Error>> {
    let scenario_storage = prepare_scenario_storage(temp_storage_root, definition.id.as_str())?;

    let tracker = Arc::new(LocalTrackingClient::new(
        &definition.project,
        &scenario_storage,
    )?);
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], Vec::new());
    let persisted_state_payloads = run_case(definition, &tracker, &hooks, &scenario_storage)?;

    let app_dir =
        validate_scenario_app_dir(definition, scenario_app_dir(definition, &scenario_storage))?;

    Ok(ScenarioRunResult {
        app_dir,
        persisted_state_payloads,
    })
}

#[cfg(test)]
mod tests {
    use super::{
        prepare_scenario_storage, run_oracle_scenario, scenario_app_dir, validate_scenario_app_dir,
    };
    use crate::manifest::{BurrOracleScenario, BurrOracleScenarioId};
    use std::fs;
    use std::path::PathBuf;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_root(label: &str) -> PathBuf {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .expect("system time should be after epoch")
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "rurr_oracle_runner_{label}_{}_{}",
            std::process::id(),
            unique
        ));
        fs::create_dir_all(&path).expect("temp root should be created");
        path
    }

    fn create_only_scenario() -> BurrOracleScenario {
        BurrOracleScenario {
            id: BurrOracleScenarioId::CreateOnly,
            description: "Minimal application creation flow.".to_string(),
            project: "runner_test_project".to_string(),
            app_id: "runner-test-app".to_string(),
            partition_key: "runner-test-pk".to_string(),
            expects_children_file: false,
        }
    }

    #[test]
    fn prepare_scenario_storage_clears_stale_contents() {
        let root = temp_root("stale_cleanup");
        let stale_dir = root.join("00_create_only");
        fs::create_dir_all(&stale_dir).expect("stale dir should be created");
        fs::write(stale_dir.join("stale.txt"), "stale").expect("stale file should be written");

        let prepared = prepare_scenario_storage(&root, "00_create_only")
            .expect("scenario storage should be prepared");

        assert_eq!(prepared, stale_dir);
        assert!(prepared.exists(), "prepared scenario dir should exist");
        assert!(
            !prepared.join("stale.txt").exists(),
            "stale contents should be removed"
        );

        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn validate_scenario_app_dir_reports_missing_output() {
        let definition = create_only_scenario();
        let root = temp_root("missing_app_dir");
        let app_dir = scenario_app_dir(&definition, &root);

        let error = validate_scenario_app_dir(&definition, app_dir)
            .expect_err("missing app dir should fail");
        assert_eq!(
            error.to_string(),
            "scenario 00_create_only produced no app dir"
        );

        let _ = fs::remove_dir_all(root);
    }

    #[test]
    fn run_oracle_scenario_executes_lightweight_happy_path() {
        let definition = create_only_scenario();
        let root = temp_root("happy_path");

        let result =
            run_oracle_scenario(&definition, &root).expect("create-only scenario should run");

        assert_eq!(
            result.app_dir,
            scenario_app_dir(&definition, &root.join("00_create_only"))
        );
        assert!(result.app_dir.exists(), "scenario should create an app dir");
        assert!(
            result.persisted_state_payloads.is_empty(),
            "create-only scenario should not emit persistence payloads"
        );

        let _ = fs::remove_dir_all(root);
    }
}
