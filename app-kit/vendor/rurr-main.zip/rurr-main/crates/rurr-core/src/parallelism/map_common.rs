use super::CascadeMode;
use crate::{
    action::api::{ActionContext, ActionError, ActionResult},
    application::builder::ApplicationError,
    state::State,
};
use std::sync::Arc;

use super::{task_action::collapse_child_states, types::SubGraphTask, RunnableGraph};

pub(super) type TaskBuilder =
    dyn Fn(&State, &ActionContext) -> Result<Vec<SubGraphTask>, ApplicationError> + Send + Sync;
pub(super) type Reducer =
    dyn Fn(&State, Vec<State>) -> Result<ActionResult, ApplicationError> + Send + Sync;

#[derive(Clone)]
pub(super) struct ParallelTaskActionCore {
    meta: ParallelActionMeta,
    task_builder: Arc<TaskBuilder>,
    reducer: Arc<Reducer>,
}

impl ParallelTaskActionCore {
    pub(super) fn new(
        meta: ParallelActionMeta,
        task_builder: Arc<TaskBuilder>,
        reducer: Arc<Reducer>,
    ) -> Self {
        Self {
            meta,
            task_builder,
            reducer,
        }
    }

    pub(super) fn meta(&self) -> &ParallelActionMeta {
        &self.meta
    }

    pub(super) fn meta_mut(&mut self) -> &mut ParallelActionMeta {
        &mut self.meta
    }

    pub(super) fn name(&self) -> Option<&str> {
        self.meta.name()
    }

    pub(super) fn source_code(&self) -> Option<String> {
        self.meta.source_code().map(str::to_owned)
    }

    pub(super) fn reads(&self) -> &[String] {
        self.meta.reads()
    }

    pub(super) fn writes(&self) -> &[String] {
        self.meta.writes()
    }

    pub(super) fn inputs(&self) -> &[String] {
        self.meta.inputs()
    }

    pub(super) fn optional_inputs(&self) -> &[String] {
        self.meta.optional_inputs()
    }

    pub(super) fn build_tasks(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<Vec<SubGraphTask>, ApplicationError> {
        (self.task_builder)(state, ctx)
    }

    pub(super) fn reduce(
        &self,
        parent_state: &State,
        child_states: Vec<State>,
    ) -> Result<ActionResult, ApplicationError> {
        (self.reducer)(parent_state, child_states)
    }

    pub(super) fn run_sync<A>(
        &self,
        owner: &A,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError>
    where
        A: super::task_action::TaskBasedParallelAction,
    {
        super::task_action::execute_task_based_action_sync(owner, state, ctx)
    }

    pub(super) async fn run_async<A>(
        &self,
        owner: &A,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError>
    where
        A: super::task_action::TaskBasedParallelAction,
    {
        super::task_action::execute_task_based_action_async(owner, state, ctx).await
    }
}

#[derive(Clone)]
pub(super) struct ParallelActionMeta {
    name: Option<String>,
    source_code: Option<String>,
    reads: Vec<String>,
    writes: Vec<String>,
    inputs: Vec<String>,
    optional_inputs: Vec<String>,
    cascade_mode: CascadeMode,
}

impl ParallelActionMeta {
    pub(super) fn new(reads: Vec<String>, writes: Vec<String>, cascade_mode: CascadeMode) -> Self {
        Self {
            name: None,
            source_code: None,
            reads,
            writes,
            inputs: Vec::new(),
            optional_inputs: Vec::new(),
            cascade_mode,
        }
    }

    pub(super) fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    pub(super) fn reads(&self) -> &[String] {
        &self.reads
    }

    pub(super) fn source_code(&self) -> Option<&str> {
        self.source_code.as_deref()
    }

    pub(super) fn writes(&self) -> &[String] {
        &self.writes
    }

    pub(super) fn inputs(&self) -> &[String] {
        &self.inputs
    }

    pub(super) fn optional_inputs(&self) -> &[String] {
        &self.optional_inputs
    }

    pub(super) fn is_pipeline(&self) -> bool {
        matches!(self.cascade_mode, CascadeMode::Pipeline)
    }

    pub(super) fn with_inputs(mut self, inputs: Vec<String>) -> Self {
        self.inputs = inputs;
        self
    }

    pub(super) fn set_name(&mut self, name: String) {
        self.name = Some(name);
    }

    pub(super) fn set_source_code(&mut self, source_code: String) {
        self.source_code = Some(source_code);
    }
}

pub(super) fn task_key(graph_index: usize, state_index: usize) -> String {
    format!("{graph_index}-{state_index}")
}

pub(super) fn build_task(
    graph: RunnableGraph,
    state: State,
    graph_index: usize,
    state_index: usize,
) -> SubGraphTask {
    SubGraphTask::new(graph, state, task_key(graph_index, state_index))
}

pub(super) fn reducer_from_cascade(cascade_mode: &CascadeMode) -> Arc<Reducer> {
    let cascade_mode = cascade_mode.clone();
    Arc::new(move |parent_state: &State, child_states: Vec<State>| {
        collapse_child_states(parent_state, &cascade_mode, child_states)
    })
}
