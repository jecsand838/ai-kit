use indexmap::IndexMap;
use rurr_core::tracking::LocalTrackingClient;
use rurr_core::{
    ApplicationBuilder, Condition, FunctionActionBuilder, State, Tracker, TrackerSpec, Transition,
};
use rurr_testkit::command_fixture::{run_command, rurr_command};
use serde_json::Value;
use std::ffi::OsStr;
use std::path::Path;
use std::process::{Command, Output};
use std::sync::Arc;

pub(crate) fn write_tracking_fixture(
    storage_root: &Path,
    project_name: &str,
    app_id: &str,
    action_name: &str,
    states: &[Value],
) {
    assert!(
        !states.is_empty(),
        "fixture helper requires at least one runtime state snapshot"
    );
    let scripted_states = states
        .iter()
        .map(|state| {
            let object = state
                .as_object()
                .expect("fixture runtime state should be a JSON object");
            State::new(
                object
                    .iter()
                    .map(|(key, value)| (key.clone(), value.clone()))
                    .collect::<IndexMap<String, Value>>(),
            )
        })
        .collect::<Vec<_>>();
    let writes = scripted_states
        .iter()
        .flat_map(|state| state.keys())
        .collect::<std::collections::BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();

    let tracker = Arc::new(
        LocalTrackingClient::new(project_name, storage_root)
            .expect("tracking client should initialize"),
    );
    let tracker_trait: Arc<dyn Tracker> = tracker.clone();
    let scripted_states_for_action = scripted_states.clone();
    let action = FunctionActionBuilder::new()
        .writes(writes)
        .with_source_code("fn counter(state, _ctx) -> scripted_state { scripted_state }")
        .build_sync(move |state, _ctx| {
            let next_index = state
                .get("__SEQUENCE_ID")
                .and_then(Value::as_u64)
                .map(|sequence_id| sequence_id as usize)
                .unwrap_or(0);
            scripted_states_for_action
                .get(next_index)
                .map(|state| state.get_all())
                .expect("fixture action should only be stepped for scripted states")
        })
        .expect("fixture action should build");
    let mut app = ApplicationBuilder::new()
        .with_state(State::default())
        .expect("state should configure")
        .with_actions(vec![(action_name, action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            action_name,
            action_name,
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_entrypoint(action_name)
        .expect("entrypoint should configure")
        .with_identifiers(app_id, None, None)
        .expect("identifiers should configure")
        .with_tracker(TrackerSpec::provided(tracker_trait))
        .expect("tracker should configure")
        .build()
        .expect("application should build");
    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("registration should succeed");
    for _ in 0..scripted_states.len() {
        app.step(None).expect("step should succeed");
    }
}

pub(crate) fn test_case_create_command() -> Command {
    let mut command = rurr_command();
    command.arg("test-case").arg("create");
    command
}

pub(crate) fn run_test_case_create(args: &[&OsStr]) -> Output {
    let mut command = test_case_create_command();
    command.args(args);
    run_command(&mut command, "test-case create should run")
}
