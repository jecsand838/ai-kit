use super::*;

pub(crate) fn sync_resume_persistence_spec<P>(
    persister: Arc<P>,
    load_target: Option<PersistenceLoadTarget>,
    default_state: indexmap::IndexMap<String, Value>,
    default_entrypoint: &str,
) -> ApplicationPersistenceSpec
where
    P: BaseStatePersister + 'static,
{
    ApplicationPersistenceSpec::sync_resume(
        persister,
        true,
        default_state,
        default_entrypoint,
        None,
        load_target,
    )
}

pub(crate) fn async_resume_persistence_spec<P>(
    persister: Arc<P>,
    load_target: Option<PersistenceLoadTarget>,
    default_state: indexmap::IndexMap<String, Value>,
    default_entrypoint: &str,
) -> ApplicationPersistenceSpec
where
    P: AsyncBaseStatePersister + 'static,
{
    let initializer: Arc<dyn AsyncBaseStateLoader> = persister.clone();
    let initializer = match load_target {
        Some(load_target) => StateInitializerSpec::async_initializer(
            Arc::clone(&initializer),
            true,
            default_state,
            default_entrypoint,
            None,
        )
        .with_load_target(load_target),
        None => StateInitializerSpec::async_initializer(
            Arc::clone(&initializer),
            true,
            default_state,
            default_entrypoint,
            None,
        ),
    };

    ApplicationPersistenceSpec::new()
        .with_initializer(initializer)
        .with_persister(StatePersisterSpec::async_persister(persister))
}

#[derive(Debug, Default)]
struct RecordingPersistenceState {
    initialized: AtomicBool,
    save_counter: AtomicU64,
    saved_keys: Mutex<Vec<(String, u64)>>,
    records: Mutex<Vec<PersistedStateData>>,
}

impl RecordingPersistenceState {
    fn ensure_initialized(&self) -> Result<(), PersistenceError> {
        if self.initialized.load(Ordering::SeqCst) {
            Ok(())
        } else {
            Err(PersistenceError::NotInitialized)
        }
    }

    fn set_initialized(&self, initialized: bool) {
        self.initialized.store(initialized, Ordering::SeqCst);
    }

    fn is_initialized(&self) -> bool {
        self.initialized.load(Ordering::SeqCst)
    }

    fn saved_keys(&self) -> Vec<(String, u64)> {
        self.saved_keys
            .lock()
            .expect("saved_keys lock should not be poisoned")
            .clone()
    }

    fn load_record(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.ensure_initialized()?;
        if app_id.is_none() && sequence_id.is_some() {
            return Ok(None);
        }

        let partition_key = partition_key.map(str::to_string);
        let records = self
            .records
            .lock()
            .expect("records lock should not be poisoned");
        let loaded = records
            .iter()
            .rev()
            .find(|record| {
                record.partition_key == partition_key
                    && app_id
                        .map(|candidate| record.app_id == candidate)
                        .unwrap_or(true)
                    && sequence_id
                        .map(|candidate| record.sequence_id == candidate)
                        .unwrap_or(true)
            })
            .cloned();
        Ok(loaded)
    }

    fn list_record_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        self.ensure_initialized()?;
        let partition_key = partition_key.map(str::to_string);
        let records = self
            .records
            .lock()
            .expect("records lock should not be poisoned");
        let app_ids: std::collections::BTreeSet<String> = records
            .iter()
            .filter(|record| record.partition_key == partition_key)
            .map(|record| record.app_id.clone())
            .collect();
        Ok(app_ids.into_iter().collect())
    }

    fn save_record(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: indexmap::IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.ensure_initialized()?;
        self.saved_keys
            .lock()
            .expect("saved_keys lock should not be poisoned")
            .push((app_id.to_string(), sequence_id));
        self.records
            .lock()
            .expect("records lock should not be poisoned")
            .push(PersistedStateData {
                partition_key: partition_key.map(str::to_string),
                app_id: app_id.to_string(),
                sequence_id,
                position: Some(position.to_string()),
                state: Some(state),
                created_at: Some(self.save_counter.fetch_add(1, Ordering::SeqCst).to_string()),
                status,
            });
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct RecordingSyncPersister {
    state: RecordingPersistenceState,
}

impl RecordingSyncPersister {
    pub(crate) fn initialize_for_test(&self) {
        self.initialize().expect("initialize should succeed");
    }

    pub(crate) fn saved_keys(&self) -> Vec<(String, u64)> {
        self.state.saved_keys()
    }
}

impl BaseStateLoader for RecordingSyncPersister {
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.state.load_record(partition_key, app_id, sequence_id)
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        self.state.list_record_app_ids(partition_key)
    }
}

impl BaseStateSaver for RecordingSyncPersister {
    fn initialize(&self) -> Result<(), PersistenceError> {
        self.state.set_initialized(true);
        Ok(())
    }

    fn is_initialized(&self) -> Result<bool, PersistenceError> {
        Ok(self.state.is_initialized())
    }

    fn cleanup(&self) -> Result<(), PersistenceError> {
        self.state.set_initialized(false);
        Ok(())
    }

    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: indexmap::IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.state
            .save_record(partition_key, app_id, sequence_id, position, state, status)
    }
}

#[derive(Debug, Default)]
pub(crate) struct RecordingAsyncPersister {
    state: RecordingPersistenceState,
}

impl RecordingAsyncPersister {
    pub(crate) async fn initialize_for_test(&self) {
        self.initialize().await.expect("initialize should succeed");
    }

    pub(crate) fn saved_keys(&self) -> Vec<(String, u64)> {
        self.state.saved_keys()
    }
}

#[async_trait]
impl AsyncBaseStateLoader for RecordingAsyncPersister {
    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.state.load_record(partition_key, app_id, sequence_id)
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        self.state.list_record_app_ids(partition_key)
    }
}

#[async_trait]
impl AsyncBaseStateSaver for RecordingAsyncPersister {
    async fn initialize(&self) -> Result<(), PersistenceError> {
        self.state.set_initialized(true);
        Ok(())
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        Ok(self.state.is_initialized())
    }

    async fn cleanup(&self) -> Result<(), PersistenceError> {
        self.state.set_initialized(false);
        Ok(())
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: indexmap::IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.state
            .save_record(partition_key, app_id, sequence_id, position, state, status)
    }
}

#[derive(Clone, Debug)]
enum RecordingPersistenceHarness {
    Sync(Arc<RecordingSyncPersister>),
    Async(Arc<RecordingAsyncPersister>),
}

impl RecordingPersistenceHarness {
    fn resume_spec(
        &self,
        load_target: Option<PersistenceLoadTarget>,
        default_state: indexmap::IndexMap<String, Value>,
        default_entrypoint: &str,
    ) -> ApplicationPersistenceSpec {
        match self {
            Self::Sync(persister) => sync_resume_persistence_spec(
                persister.clone(),
                load_target,
                default_state,
                default_entrypoint,
            ),
            Self::Async(persister) => async_resume_persistence_spec(
                persister.clone(),
                load_target,
                default_state,
                default_entrypoint,
            ),
        }
    }

    async fn initialize_for_test(&self) {
        match self {
            Self::Sync(persister) => persister.initialize_for_test(),
            Self::Async(persister) => persister.initialize_for_test().await,
        }
    }

    fn saved_keys(&self) -> Vec<(String, u64)> {
        match self {
            Self::Sync(persister) => persister.saved_keys(),
            Self::Async(persister) => persister.saved_keys(),
        }
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: indexmap::IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) {
        match self {
            Self::Sync(persister) => persister
                .save(partition_key, app_id, sequence_id, position, state, status)
                .expect("seed save should succeed"),
            Self::Async(persister) => persister
                .save(partition_key, app_id, sequence_id, position, state, status)
                .await
                .expect("seed save should succeed"),
        }
    }

    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> PersistedStateData {
        match self {
            Self::Sync(persister) => persister
                .load(partition_key, app_id, sequence_id)
                .expect("load should succeed")
                .expect("record should exist"),
            Self::Async(persister) => persister
                .load(partition_key, app_id, sequence_id)
                .await
                .expect("load should succeed")
                .expect("record should exist"),
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum PersistenceMode {
    Sync,
    Async,
}

impl PersistenceMode {
    fn recording_harness(self) -> RecordingPersistenceHarness {
        match self {
            Self::Sync => {
                RecordingPersistenceHarness::Sync(Arc::new(RecordingSyncPersister::default()))
            }
            Self::Async => {
                RecordingPersistenceHarness::Async(Arc::new(RecordingAsyncPersister::default()))
            }
        }
    }

    async fn build(self, builder: ApplicationBuilder) -> Result<Application, ApplicationError> {
        match self {
            Self::Sync => builder.build(),
            Self::Async => builder.abuild().await,
        }
    }

    async fn step(self, app: &mut Application) -> StepOutput {
        match self {
            Self::Sync => app
                .step(None)
                .expect("step should succeed")
                .expect("step should execute"),
            Self::Async => app
                .astep(None)
                .await
                .expect("async step should succeed")
                .expect("async step should execute"),
        }
    }
}

pub(crate) async fn assert_persistence_spec_with_uninitialized_recording_persister_surfaces_persistence_error(
    mode: PersistenceMode,
) {
    let harness = mode.recording_harness();

    let error = mode
        .build(
            start_finish_counter_builder()
                .with_identifiers("run-app", Some("tenant".to_string()), None)
                .expect("identifiers should configure")
                .with_persistence_spec(harness.resume_spec(
                    None,
                    map_from_pairs([("count", json!(0))]),
                    "start",
                ))
                .expect("persistence spec should configure"),
        )
        .await
        .err()
        .expect("build should surface load-time persistence errors");

    assert!(matches!(
        error,
        ApplicationError::Persistence(PersistenceError::NotInitialized)
    ));
}

pub(crate) async fn assert_persistence_spec_resume_path_loads_state_and_resumes_next_action(
    mode: PersistenceMode,
) {
    let harness = mode.recording_harness();
    harness.initialize_for_test().await;

    let mut first_app = mode
        .build(
            start_finish_counter_builder()
                .with_identifiers("resume-app", Some("tenant".to_string()), None)
                .expect("identifiers should configure")
                .with_persistence_spec(harness.resume_spec(
                    None,
                    map_from_pairs([("count", json!(0))]),
                    "start",
                ))
                .expect("persistence spec should configure"),
        )
        .await
        .expect("initial build should use default state");

    let first_step = mode.step(&mut first_app).await;
    assert_eq!(first_step.action.name(), "start");
    assert_eq!(first_step.state.get("count"), Some(&json!(1)));

    let mut resumed_app = mode
        .build(
            start_finish_counter_builder()
                .with_identifiers("resume-app", Some("tenant".to_string()), None)
                .expect("identifiers should configure")
                .with_persistence_spec(harness.resume_spec(
                    None,
                    map_from_pairs([("count", json!(0))]),
                    "start",
                ))
                .expect("persistence spec should configure"),
        )
        .await
        .expect("second build should load persisted state");

    assert_eq!(resumed_app.state().get("count"), Some(&json!(1)));
    assert_eq!(resumed_app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
    assert_eq!(
        resumed_app.state().get("__PRIOR_STEP"),
        Some(&json!("start"))
    );

    let resumed_step = mode.step(&mut resumed_app).await;
    assert_eq!(resumed_step.action.name(), "finish");
    assert_eq!(
        harness.saved_keys(),
        vec![("resume-app".to_string(), 0), ("resume-app".to_string(), 1)]
    );
}

pub(crate) async fn assert_persistence_spec_same_app_exact_sequence_miss_starts_fresh_at_zero(
    mode: PersistenceMode,
) {
    let harness = mode.recording_harness();
    harness.initialize_for_test().await;

    let mut app = mode
        .build(
            start_finish_counter_builder()
                .with_identifiers("resume-app", Some("tenant".to_string()), Some(41))
                .expect("identifiers should configure")
                .with_persistence_spec(harness.resume_spec(
                    None,
                    map_from_pairs([("count", json!(0))]),
                    "start",
                ))
                .expect("persistence spec should configure"),
        )
        .await
        .expect("build should succeed");

    assert_eq!(app.state().get("count"), Some(&json!(0)));
    assert_eq!(app.state().get("__SEQUENCE_ID"), None);

    let step = mode.step(&mut app).await;
    assert_eq!(step.action.name(), "start");
    assert_eq!(step.state.get("__SEQUENCE_ID"), Some(&json!(0)));
    assert_eq!(
        harness.saved_keys(),
        vec![("resume-app".to_string(), 0)],
        "exact-sequence miss should save as a fresh run"
    );
}

pub(crate) async fn assert_persistence_spec_fork_from_exact_sequence_preserves_target_ids_and_parent_pointer(
    mode: PersistenceMode,
) {
    let harness = mode.recording_harness();
    harness.initialize_for_test().await;
    harness
        .save(
            Some("tenant"),
            "source-app",
            0,
            "start",
            map_from_pairs([("count", json!(1))]),
            PersistedStateStatus::Completed,
        )
        .await;
    harness
        .save(
            Some("tenant"),
            "source-app",
            1,
            "finish",
            map_from_pairs([("count", json!(2))]),
            PersistedStateStatus::Completed,
        )
        .await;

    let mut forked_app = mode
        .build(
            start_finish_counter_builder()
                .with_identifiers("fork-app", Some("tenant".to_string()), None)
                .expect("identifiers should configure")
                .with_persistence_spec(harness.resume_spec(
                    Some(PersistenceLoadTarget::new(
                        "source-app",
                        Some("tenant".to_string()),
                        Some(0),
                    )),
                    map_from_pairs([("count", json!(0))]),
                    "start",
                ))
                .expect("persistence spec should configure"),
        )
        .await
        .expect("fork build should succeed");

    assert_eq!(
        forked_app.parent_pointer(),
        Some(&ParentPointer {
            app_id: "source-app".to_string(),
            partition_key: Some("tenant".to_string()),
            sequence_id: Some(0),
        })
    );
    assert_eq!(forked_app.uid(), "fork-app");
    assert_eq!(forked_app.partition_key(), Some("tenant"));
    assert_eq!(forked_app.state().get("count"), Some(&json!(1)));
    assert_eq!(forked_app.state().get("__SEQUENCE_ID"), Some(&json!(0)));
    assert_eq!(
        forked_app.state().get("__PRIOR_STEP"),
        Some(&json!("start"))
    );

    let forked_step = mode.step(&mut forked_app).await;
    assert_eq!(forked_step.action.name(), "finish");

    let target_record = harness
        .load(Some("tenant"), Some("fork-app"), Some(1))
        .await;
    let source_record = harness
        .load(Some("tenant"), Some("source-app"), Some(1))
        .await;

    assert_eq!(target_record.app_id, "fork-app");
    assert_eq!(target_record.sequence_id, 1);
    assert_eq!(
        target_record
            .state
            .as_ref()
            .and_then(|state| state.get("count")),
        Some(&json!(2))
    );
    assert_eq!(source_record.app_id, "source-app");
    assert_eq!(
        harness.saved_keys(),
        vec![
            ("source-app".to_string(), 0),
            ("source-app".to_string(), 1),
            ("fork-app".to_string(), 1),
        ]
    );
}

pub(crate) async fn assert_persistence_spec_rejects_same_app_load_target(mode: PersistenceMode) {
    let harness = mode.recording_harness();
    harness.initialize_for_test().await;

    let error = mode
        .build(
            start_finish_counter_builder()
                .with_identifiers("source-app", Some("tenant".to_string()), None)
                .expect("identifiers should configure")
                .with_persistence_spec(harness.resume_spec(
                    Some(PersistenceLoadTarget::new(
                        "source-app",
                        Some("tenant".to_string()),
                        Some(0),
                    )),
                    map_from_pairs([("count", json!(0))]),
                    "start",
                ))
                .expect("persistence spec should configure"),
        )
        .await
        .err()
        .expect("same-app load target should be rejected");

    assert!(matches!(
        error,
        ApplicationError::PersistenceLoadTargetMatchesTargetAppId
    ));
}

#[derive(Debug, Default)]
pub(crate) struct FixedSyncInitializer {
    pub(crate) result: Option<PersistedStateData>,
}

impl BaseStateLoader for FixedSyncInitializer {
    fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(self.result.clone())
    }

    fn list_app_ids(&self, _partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

#[derive(Debug, Default)]
pub(crate) struct FixedAsyncInitializer {
    pub(crate) result: Option<PersistedStateData>,
}

#[async_trait]
impl AsyncBaseStateLoader for FixedAsyncInitializer {
    async fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(self.result.clone())
    }

    async fn list_app_ids(
        &self,
        _partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

#[derive(Debug, Default)]
pub(crate) struct FixedSyncPersister;

impl BaseStateLoader for FixedSyncPersister {
    fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(None)
    }

    fn list_app_ids(&self, _partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

impl BaseStateSaver for FixedSyncPersister {
    fn save(
        &self,
        _partition_key: Option<&str>,
        _app_id: &str,
        _sequence_id: u64,
        _position: &str,
        _state: indexmap::IndexMap<String, Value>,
        _status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct FixedAsyncPersister;

#[async_trait]
impl AsyncBaseStateLoader for FixedAsyncPersister {
    async fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        Ok(None)
    }

    async fn list_app_ids(
        &self,
        _partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

#[async_trait]
impl AsyncBaseStateSaver for FixedAsyncPersister {
    async fn save(
        &self,
        _partition_key: Option<&str>,
        _app_id: &str,
        _sequence_id: u64,
        _position: &str,
        _state: indexmap::IndexMap<String, Value>,
        _status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        Ok(())
    }
}

pub(crate) fn fixed_sync_initializer(
    result: Option<PersistedStateData>,
) -> Arc<dyn BaseStateLoader> {
    Arc::new(FixedSyncInitializer { result })
}

pub(crate) fn fixed_async_initializer(
    result: Option<PersistedStateData>,
) -> Arc<dyn AsyncBaseStateLoader> {
    Arc::new(FixedAsyncInitializer { result })
}

pub(crate) fn fixed_sync_persister() -> Arc<dyn BaseStatePersister> {
    Arc::new(FixedSyncPersister)
}

pub(crate) fn fixed_async_persister() -> Arc<dyn AsyncBaseStatePersister> {
    Arc::new(FixedAsyncPersister)
}

pub(crate) fn persisted_state_fixture_with(
    partition_key: Option<&str>,
    app_id: &str,
    sequence_id: u64,
    state: Option<indexmap::IndexMap<String, Value>>,
    position: Option<&str>,
    status: PersistedStateStatus,
    created_at: Option<&str>,
) -> PersistedStateData {
    PersistedStateData {
        partition_key: partition_key.map(str::to_string),
        app_id: app_id.to_string(),
        sequence_id,
        position: position.map(str::to_string),
        state,
        created_at: created_at.map(str::to_string),
        status,
    }
}

pub(crate) fn persisted_state_fixture(
    state: Option<indexmap::IndexMap<String, Value>>,
    position: Option<&str>,
    status: PersistedStateStatus,
) -> PersistedStateData {
    persisted_state_fixture_with(
        Some("tenant-1"),
        "saved-app",
        7,
        state,
        position,
        status,
        Some("2026-02-21T00:00:00Z"),
    )
}
