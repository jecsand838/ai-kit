//! Immutable application state plus typed mutation helpers.
//!
//! [`State`] stores insertion-ordered JSON values and validates transitions
//! through a pluggable [`TypingSystem`]. Use [`StateOperation`] for primitive
//! mutations, or the higher-level convenience methods on [`State`] when you
//! want the runtime to preserve typing and round-trip validation rules.

use crate::serde::{self as core_serde, SerdeError};
use indexmap::IndexMap;
use serde_json::Value;
use std::collections::HashSet;
use std::sync::Arc;
use thiserror::Error;

mod inner;
mod operations;
/// Registry helpers for field-specific state serialization hooks.
pub mod serde_registry;
mod typing;
mod value_ops;

use inner::make_mut_values;
use serde_registry::snapshot_field_serde_registry;
use typing::{validate_full_state, validate_transition};
use value_ops::value_kind;

pub use operations::StateOperation;
pub use serde_registry::register_field_serde;
pub use typing::{DefaultTypingSystem, TypingSystem};

/// Error returned while validating or mutating state.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum StateError {
    /// A required key was not present in the state map.
    #[error("missing key '{key}' in state. available keys: {available_keys:?}")]
    MissingKey {
        /// Missing state key.
        key: String,
        /// Keys currently present in the state.
        available_keys: Vec<String>,
    },
    /// An append operation targeted a non-appendable value.
    #[error("cannot append to non-appendable value at key '{key}'")]
    NonAppendable {
        /// Key whose value was not appendable.
        key: String,
    },
    /// An extend operation targeted a non-extendable value.
    #[error("cannot extend non-extendable value at key '{key}'")]
    NonExtendable {
        /// Key whose value was not extendable.
        key: String,
    },
    /// An increment operation targeted a non-integer value.
    #[error("cannot increment non-integer value at key '{key}'")]
    NonInteger {
        /// Key whose value was not an integer.
        key: String,
    },
    /// An increment operation overflowed `i64`.
    #[error("integer overflow at key '{key}'")]
    IntegerOverflow {
        /// Key whose increment overflowed.
        key: String,
    },
    /// `wipe` was called with both `delete` and `keep`.
    #[error("wipe cannot accept both delete={delete:?} and keep={keep:?}")]
    WipeDeleteAndKeepConflict {
        /// Explicit delete list.
        delete: Vec<String>,
        /// Explicit keep list.
        keep: Vec<String>,
    },
    /// A custom field serializer returned a non-object JSON value.
    #[error("field serializer for '{field}' must return an object/map, got {actual}")]
    FieldSerializerMustReturnObject {
        /// Field whose serializer returned the invalid value.
        field: String,
        /// Human-readable description of the returned JSON kind.
        actual: String,
    },
    /// The field serde registry lock was poisoned.
    #[error("field serde registry lock was poisoned")]
    FieldSerdeRegistryPoisoned,
    /// A field serializer or deserializer returned an error.
    #[error("field {direction} handler for '{field}' failed: {message}")]
    FieldSerdeHandlerFailed {
        /// Field whose serde handler failed.
        field: String,
        /// Either `"serialize"` or `"deserialize"`.
        direction: &'static str,
        /// Human-readable failure message.
        message: String,
    },
    /// The configured typing system rejected the state transition.
    #[error("typing system error during {phase}: {message}")]
    TypingSystem {
        /// Validation phase that failed.
        phase: &'static str,
        /// Human-readable validation failure.
        message: String,
    },
    /// Generic serde dispatch failure.
    #[error(transparent)]
    Serde(#[from] SerdeError),
}

/// Immutable application state plus a typing system used to validate changes.
#[derive(Debug, Clone)]
pub struct State {
    values: Arc<IndexMap<String, Value>>,
    typing_system: Arc<dyn TypingSystem>,
}

impl Default for State {
    fn default() -> Self {
        Self::new(IndexMap::new())
    }
}

impl PartialEq for State {
    fn eq(&self, other: &Self) -> bool {
        self.values.as_ref() == other.values.as_ref()
    }
}

impl State {
    /// Creates a state value with the default typing system.
    pub fn new(values: IndexMap<String, Value>) -> Self {
        Self {
            values: Arc::new(values),
            typing_system: Arc::new(DefaultTypingSystem),
        }
    }

    pub(crate) fn new_with_typing_system(
        values: IndexMap<String, Value>,
        typing_system: Arc<dyn TypingSystem>,
    ) -> Result<Self, StateError> {
        validate_full_state(typing_system.as_ref(), &values)?;
        Ok(Self {
            values: Arc::new(values),
            typing_system,
        })
    }

    /// Rebinds the state to a different typing system after validating the
    /// current values.
    pub fn with_typing_system(
        &self,
        typing_system: Arc<dyn TypingSystem>,
    ) -> Result<Self, StateError> {
        validate_full_state(typing_system.as_ref(), self.values.as_ref())?;
        Ok(Self {
            values: Arc::clone(&self.values),
            typing_system,
        })
    }

    /// Returns the typing system used by this state.
    pub fn typing_system(&self) -> &Arc<dyn TypingSystem> {
        &self.typing_system
    }

    /// Returns one state value by key.
    pub fn get(&self, key: &str) -> Option<&Value> {
        self.values.get(key)
    }

    /// Returns one state value by key or a typed missing-key error.
    pub fn require(&self, key: &str) -> Result<&Value, StateError> {
        self.values.get(key).ok_or_else(|| StateError::MissingKey {
            key: key.to_string(),
            available_keys: self.keys(),
        })
    }

    /// Returns one state value or the provided default reference.
    pub fn get_or<'a>(&'a self, key: &str, default: &'a Value) -> &'a Value {
        self.values.get(key).unwrap_or(default)
    }

    /// Returns one state value or `Value::Null`.
    pub fn get_or_default(&self, key: &str) -> Value {
        self.values.get(key).cloned().unwrap_or(Value::Null)
    }

    /// Returns an owned copy of the full state map.
    pub fn get_all(&self) -> IndexMap<String, Value> {
        self.values.as_ref().clone()
    }

    pub(crate) fn entries(&self) -> indexmap::map::Iter<'_, String, Value> {
        self.values.iter()
    }

    /// Returns whether the state contains `key`.
    pub fn contains_key(&self, key: &str) -> bool {
        self.values.contains_key(key)
    }

    /// Returns all state keys in insertion order.
    pub fn keys(&self) -> Vec<String> {
        self.values.keys().cloned().collect()
    }

    /// Applies a typed [`StateOperation`] and returns the validated next state.
    pub fn apply_operation(&self, operation: StateOperation) -> Result<Self, StateError> {
        self.typing_system
            .validate_pre_action(self.values.as_ref(), &operation)?;

        let mut next = self.clone();
        operation.apply(make_mut_values(&mut next))?;

        validate_transition(
            self.typing_system.as_ref(),
            self.values.as_ref(),
            next.values.as_ref(),
            &operation,
        )?;
        Ok(next)
    }

    fn validated_with_values(&self, values: IndexMap<String, Value>) -> Result<Self, StateError> {
        Self::new_with_typing_system(values, Arc::clone(&self.typing_system))
    }

    /// Applies a key/value update operation.
    pub fn update(&self, updates: IndexMap<String, Value>) -> Result<Self, StateError> {
        self.apply_operation(StateOperation::Update(updates))
    }

    /// Appends one or more values to appendable fields.
    pub fn append(&self, payload: Vec<(String, Value)>) -> Result<Self, StateError> {
        self.append_many(payload)
    }

    /// Appends one or more values to appendable fields.
    pub fn append_many(&self, payload: Vec<(String, Value)>) -> Result<Self, StateError> {
        self.apply_operation(StateOperation::Append(payload))
    }

    /// Extends one or more collection fields.
    pub fn extend(&self, payload: Vec<(String, Vec<Value>)>) -> Result<Self, StateError> {
        self.extend_many(payload)
    }

    /// Extends one or more collection fields.
    pub fn extend_many(&self, payload: Vec<(String, Vec<Value>)>) -> Result<Self, StateError> {
        self.apply_operation(StateOperation::Extend(payload))
    }

    /// Increments one or more integer fields.
    pub fn increment(&self, payload: Vec<(String, i64)>) -> Result<Self, StateError> {
        self.increment_many(payload)
    }

    /// Increments one or more integer fields.
    pub fn increment_many(&self, payload: Vec<(String, i64)>) -> Result<Self, StateError> {
        self.apply_operation(StateOperation::Increment(payload))
    }

    /// Deletes fields either by explicit delete list or by keeping only a named
    /// subset.
    pub fn wipe(
        &self,
        delete: Option<Vec<String>>,
        keep: Option<Vec<String>>,
    ) -> Result<Self, StateError> {
        match (delete, keep) {
            (Some(delete), Some(keep)) => {
                Err(StateError::WipeDeleteAndKeepConflict { delete, keep })
            }
            (Some(delete), None) => self.delete_owned_keys(delete),
            (None, Some(keep)) => {
                let keep: HashSet<String> = keep.into_iter().collect();
                let delete_keys = self
                    .values
                    .keys()
                    .filter(|key| !keep.contains(key.as_str()))
                    .cloned()
                    .collect();
                self.delete_owned_keys(delete_keys)
            }
            (None, None) => self.delete_owned_keys(self.values.keys().cloned().collect()),
        }
    }

    /// Merges another state into this one, preferring values from `other`.
    pub fn merge(&self, other: &Self) -> Result<Self, StateError> {
        let mut values = self.get_all();
        for (key, value) in other.values.iter() {
            values.insert(key.clone(), value.clone());
        }
        self.validated_with_values(values)
    }

    /// Returns a validated subset containing only the requested keys that
    /// exist.
    pub fn subset<I, S>(&self, keys: I) -> Result<Self, StateError>
    where
        I: IntoIterator<Item = S>,
        S: AsRef<str>,
    {
        let mut subset = IndexMap::new();
        for key in keys {
            let key_ref = key.as_ref();
            if let Some(value) = self.values.get(key_ref) {
                subset.insert(key_ref.to_string(), value.clone());
            }
        }
        self.validated_with_values(subset)
    }

    /// Serializes the state into Burr-compatible JSON values.
    pub fn serialize(&self) -> Result<IndexMap<String, Value>, StateError> {
        let registry = snapshot_field_serde_registry()?;
        let mut serialized = IndexMap::new();

        for (key, value) in self.values.iter() {
            let serialized_value = match registry.serializer_for(key) {
                Some(serializer) => {
                    let candidate = serializer(value)?;
                    if !candidate.is_object() {
                        return Err(StateError::FieldSerializerMustReturnObject {
                            field: key.clone(),
                            actual: value_kind(&candidate).to_string(),
                        });
                    }
                    candidate
                }
                None => core_serde::serialize(value),
            };
            serialized.insert(key.clone(), serialized_value);
        }

        Ok(serialized)
    }

    /// Deserializes a serialized state snapshot with the provided typing
    /// system.
    pub fn deserialize(
        values: IndexMap<String, Value>,
        typing_system: Arc<dyn TypingSystem>,
    ) -> Result<Self, StateError> {
        let deserialized = Self::decode_serialized_values(values)?;
        Self::new_with_typing_system(deserialized, typing_system)
    }

    /// Decode a serialized state snapshot back into runtime-facing values without
    /// constructing a typed `State`.
    pub fn decode_serialized_values(
        values: IndexMap<String, Value>,
    ) -> Result<IndexMap<String, Value>, StateError> {
        let registry = snapshot_field_serde_registry()?;
        let dispatch = core_serde::snapshot_registered_deserializers()?;
        let mut deserialized = IndexMap::new();
        for (key, value) in values {
            let deserialized_value = match registry.deserializer_for(&key) {
                Some(deserializer) => deserializer(&value)?,
                None => core_serde::deserialize(&value, dispatch.as_ref())?,
            };
            deserialized.insert(key, deserialized_value);
        }
        Ok(deserialized)
    }

    pub(crate) fn delete_owned_keys(&self, keys: Vec<String>) -> Result<Self, StateError> {
        self.apply_operation(StateOperation::Delete(keys))
    }
}

impl rurr_expr::StateView for State {
    fn get_value(&self, key: &str) -> Option<&Value> {
        self.get(key)
    }
}
