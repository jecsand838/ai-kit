//! S3 tracking backend implementation.
//!
//! The backend indexes Burr-compatible S3 tracking objects into a local SQLite
//! database, serves the normal tracking-server API from that index, and can
//! upload/load SQLite snapshots through S3. Provider listing and object fetches
//! stay outside SQLite transactions; index mutation is transactional inside the
//! store.
//!
//! The backend preserves Burr-visible object layout and metadata semantics. A
//! snapshot upload reads from a SQLite-created copy of the index rather than the
//! live database file. Index updates retain provider key ordering after
//! pagination and before transactional writes, which keeps lifecycle logs in the
//! same order proven by strict S3 live tests.
//!
//! Annotation routes are intentionally unsupported for this backend today. The
//! capability flag stays `false`, so the router returns typed unsupported
//! errors for annotation reads and writes instead of synthesizing empty
//! annotation responses.

mod config;
mod index_store;
mod scanner;
mod snapshot;

use super::{step_projection_error, BackendCapabilities, BackendError, TrackingBackend};
use crate::schema::{
    steps_from_projection, ApplicationLogs, ApplicationPage, IndexingJob, Project,
};
use async_trait::async_trait;
use aws_sdk_s3::primitives::ByteStream;
pub use config::{S3BackendConfig, S3BackendConfigOverrides, S3IndexingPolicy};
use futures::{stream, StreamExt, TryStreamExt};
use index_store::{IndexedArtifact, IndexingJobRun, S3IndexStore};
use rurr_core::tracking::{
    partition_segment,
    s3_artifact::{S3ArtifactDescriptor, S3LogBundle, S3TrackingArtifactError},
    ApplicationMetadataModel, ApplicationModel, ChildApplicationModel, S3LayoutError,
    S3TrackingObjectKey, S3TrackingObjectKind,
};
use rurr_tracking_store::tracked_log::{TrackingLogProjector, TrackingLogScanOptions};
use scanner::{S3ListedObject, S3ObjectScanner};
use snapshot::{enforce_snapshot_retention, load_snapshot_to_path, snapshot_key};
use std::collections::HashMap;
use std::future::Future;
use std::path::{Path, PathBuf};
use time::OffsetDateTime;
use uuid::Uuid;

/// S3-backed tracking server backend with a local SQLite index and S3 snapshots.
///
/// Creating the backend validates config, optionally restores the latest
/// snapshot when the local index is absent, and constructs one AWS SDK client
/// for later indexing/snapshot operations. Index refreshes page S3 keys by
/// project high-watermark and apply each project's updates transactionally.
#[derive(Clone)]
pub struct S3Backend {
    config: S3BackendConfig,
    client: aws_sdk_s3::Client,
    store: S3IndexStore,
    backend_id: String,
}

impl S3Backend {
    /// Creates an S3 backend, optionally restoring a snapshot before opening the SQLite index.
    ///
    /// # Errors
    ///
    /// Returns configuration errors before contacting S3 when required fields or
    /// local limits are invalid. Provider, snapshot, and SQLite errors are
    /// surfaced without falling back to an empty index.
    pub async fn new(config: S3BackendConfig) -> Result<Self, BackendError> {
        config.validate()?;
        let client = config.sdk_client().await?;
        if config.indexing.load_snapshot_on_start && !config.indexing.db_path.exists() {
            load_snapshot_to_path(&client, &config).await?;
        }
        let store = S3IndexStore::open(&config.indexing.db_path).await?;
        Ok(Self {
            config,
            client,
            store,
            backend_id: Uuid::new_v4().to_string(),
        })
    }

    /// Returns the local SQLite index path.
    pub fn db_path(&self) -> &Path {
        &self.config.indexing.db_path
    }

    /// Returns the backend configuration.
    pub fn config(&self) -> &S3BackendConfig {
        &self.config
    }

    async fn update_index_inner(&self) -> Result<u64, BackendError> {
        let scanner = self.scanner();
        let projects = scanner.list_projects().await?;
        let mut records = 0u64;
        for project in projects {
            let high_watermark = self.store.high_watermark(&project).await?;
            let files = scanner
                .list_tracking_objects(&project, high_watermark.as_deref())
                .await?;
            let mut max_key = high_watermark.unwrap_or_default();
            let updates = index_file_updates(files, &scanner).await?;
            for update in &updates {
                max_key = max_key.max(update.key().to_string());
            }
            records += self
                .store
                .apply_project_updates(&project, &updates, &max_key)
                .await?;
        }
        Ok(records)
    }

    fn scanner(&self) -> S3ObjectScanner<'_> {
        S3ObjectScanner::new(&self.client, &self.config)
    }
}

struct S3ObjectReader<'a> {
    scanner: &'a S3ObjectScanner<'a>,
}

impl<'a> S3ObjectReader<'a> {
    fn new(scanner: &'a S3ObjectScanner<'a>) -> Self {
        Self { scanner }
    }

    async fn index_update(&self, listed: S3ListedObject) -> Result<IndexedArtifact, BackendError> {
        let last_modified = listed.last_modified().to_string();
        self.index_update_for(listed.into_key(), last_modified)
            .await
    }

    async fn read_graph_model(&self, key: &str) -> Result<ApplicationModel, BackendError> {
        let (file, metadata, body) = self.fetch_artifact_parts(key).await?;
        S3ArtifactDescriptor::Graph
            .decode_graph(file, &metadata, body)
            .map_err(artifact_error)
    }

    async fn read_metadata_model(
        &self,
        key: &str,
    ) -> Result<ApplicationMetadataModel, BackendError> {
        let (file, metadata, body) = self.fetch_artifact_parts(key).await?;
        S3ArtifactDescriptor::Metadata
            .decode_metadata(file, &metadata, body)
            .map(|artifact| artifact.model)
            .map_err(artifact_error)
    }

    async fn read_log_bundle(&self, key: &str) -> Result<S3LogBundle, BackendError> {
        let (file, metadata, body) = self.fetch_artifact_parts(key).await?;
        S3ArtifactDescriptor::Log
            .decode_log(file, &metadata, body)
            .map_err(artifact_error)
    }

    async fn read_children(&self, key: &str) -> Result<Vec<ChildApplicationModel>, BackendError> {
        let (file, metadata, body) = self.fetch_artifact_parts(key).await?;
        S3ArtifactDescriptor::Children
            .decode_children(file, &metadata, body)
            .map(|artifact| artifact.children)
            .map_err(artifact_error)
    }

    async fn index_update_for(
        &self,
        file: S3TrackingObjectKey,
        last_modified: String,
    ) -> Result<IndexedArtifact, BackendError> {
        let descriptor = S3ArtifactDescriptor::for_key(&file);
        let metadata = self.head_required(&file).await?;
        let body = if descriptor.requires_body_for_index() {
            Some(self.body(&file).await?)
        } else {
            None
        };
        let payload = descriptor
            .index_payload(&file, &metadata, body)
            .map_err(artifact_error)?;
        Ok(IndexedArtifact::new(file, last_modified, payload))
    }

    async fn fetch_artifact_parts(
        &self,
        key: &str,
    ) -> Result<(S3TrackingObjectKey, HashMap<String, String>, Vec<u8>), BackendError> {
        let file = self.tracking_object_key(key)?;
        let metadata = self.head_required(&file).await?;
        let body = self.body(&file).await?;
        Ok((file, metadata, body))
    }

    fn tracking_object_key(&self, key: &str) -> Result<S3TrackingObjectKey, BackendError> {
        self.scanner.tracking_object_key(key)
    }

    async fn head_required(
        &self,
        file: &S3TrackingObjectKey,
    ) -> Result<HashMap<String, String>, BackendError> {
        self.scanner
            .head_metadata(file.key(), head_operation(file.kind()))
            .await
    }

    async fn body(&self, file: &S3TrackingObjectKey) -> Result<Vec<u8>, BackendError> {
        self.scanner
            .get_object_bytes(file.key(), "get_object", body_operation(file.kind()))
            .await
    }
}

fn head_operation(kind: S3TrackingObjectKind) -> &'static str {
    match kind {
        S3TrackingObjectKind::Graph => "head_graph_object",
        S3TrackingObjectKind::Metadata => "head_metadata_object",
        S3TrackingObjectKind::Log => "head_log_object",
        S3TrackingObjectKind::Children => "head_children_object",
    }
}

fn body_operation(kind: S3TrackingObjectKind) -> &'static str {
    match kind {
        S3TrackingObjectKind::Children => "read_child_object_body",
        _ => "read_object_body",
    }
}

async fn index_file_updates(
    files: Vec<S3ListedObject>,
    scanner: &S3ObjectScanner<'_>,
) -> Result<Vec<IndexedArtifact>, BackendError> {
    let reader = S3ObjectReader::new(scanner);
    load_chunks_in_provider_order(files, scanner.max_concurrency(), |listed| {
        let reader = &reader;
        async move { reader.index_update(listed).await }
    })
    .await
}

async fn load_chunks_in_provider_order<T, U, F, Fut>(
    items: Vec<T>,
    max_concurrency: usize,
    load: F,
) -> Result<Vec<U>, BackendError>
where
    F: Fn(T) -> Fut,
    Fut: Future<Output = Result<U, BackendError>>,
{
    stream::iter(items)
        .map(load)
        .buffered(max_concurrency)
        .try_collect::<Vec<_>>()
        .await
}

#[async_trait]
impl TrackingBackend for S3Backend {
    fn backend_name(&self) -> &'static str {
        "s3"
    }

    fn backend_capabilities(&self) -> BackendCapabilities {
        BackendCapabilities {
            indexing: true,
            snapshotting: true,
            supports_demos: false,
            supports_annotations: false,
        }
    }

    async fn list_projects(&self) -> Result<Vec<Project>, BackendError> {
        self.store.list_projects().await
    }

    async fn list_apps(
        &self,
        project_id: &str,
        partition_key: Option<&str>,
        limit: usize,
        offset: usize,
    ) -> Result<ApplicationPage, BackendError> {
        self.store
            .list_apps(project_id, partition_key, limit, offset)
            .await
    }

    async fn read_app(
        &self,
        project_id: &str,
        app_id: &str,
        partition_key: Option<&str>,
    ) -> Result<ApplicationLogs, BackendError> {
        let partition_norm = partition_segment(partition_key);
        let scanner = self.scanner();
        let (graph_key, metadata_key) = self
            .store
            .app_object_keys(project_id, app_id, &partition_norm)
            .await?;
        let reader = S3ObjectReader::new(&scanner);
        let (graph, metadata, log_keys, child_keys) = tokio::try_join!(
            reader.read_graph_model(&graph_key),
            reader.read_metadata_model(&metadata_key),
            self.store
                .ordered_app_log_keys(project_id, app_id, &partition_norm),
            self.store
                .ordered_app_child_keys(project_id, app_id, &partition_norm),
        )?;

        let log_chunks = load_chunks_in_provider_order(
            log_keys,
            self.config.indexing.aws_max_concurrency,
            |key| {
                let reader = &reader;
                async move {
                    let bundle = reader.read_log_bundle(&key).await?;
                    let mut projector =
                        TrackingLogProjector::new(TrackingLogScanOptions::full_projection());
                    bundle
                        .project_into(&mut projector)
                        .map_err(artifact_error)?;
                    Ok(projector)
                }
            },
        )
        .await?;
        let mut projection = TrackingLogProjector::new(TrackingLogScanOptions::full_projection());
        for chunk in log_chunks {
            projection
                .merge_in_provider_order(chunk)
                .map_err(step_projection_error)?;
        }
        let projection = projection.finish();
        let steps = steps_from_projection(projection.steps).map_err(step_projection_error)?;
        let child_chunks = load_chunks_in_provider_order(
            child_keys,
            self.config.indexing.aws_max_concurrency,
            |key| {
                let reader = &reader;
                async move { reader.read_children(&key).await }
            },
        )
        .await?;
        let children = child_chunks.into_iter().flatten().collect();
        Ok(ApplicationLogs {
            application: graph,
            children,
            steps,
            parent_pointer: metadata.parent_pointer,
            spawning_parent_pointer: metadata.spawning_parent_pointer,
        })
    }

    async fn indexing_jobs(
        &self,
        offset: usize,
        limit: usize,
        filter_empty: bool,
    ) -> Result<Vec<IndexingJob>, BackendError> {
        self.store.indexing_jobs(offset, limit, filter_empty).await
    }

    async fn load_snapshot(&self) -> Result<(), BackendError> {
        if self.config.indexing.db_path.exists() {
            return Ok(());
        }
        load_snapshot_to_path(&self.client, &self.config).await
    }

    async fn update_index(&self) -> Result<(), BackendError> {
        let bucket = self.config.transport.bucket();
        let job = IndexingJobRun::start(&self.store, bucket).await?;
        job.finish(self.update_index_inner().await).await
    }

    async fn snapshot(&self) -> Result<(), BackendError> {
        let bytes = self.snapshot_index_bytes().await?;
        let key = snapshot_key(
            &self.config.indexing.snapshot_prefix,
            &self.backend_id,
            OffsetDateTime::now_utc(),
        );
        self.client
            .put_object()
            .bucket(self.config.transport.bucket())
            .key(&key)
            .body(ByteStream::from(bytes))
            .send()
            .await
            .map_err(provider("put_snapshot"))?;
        enforce_snapshot_retention(&self.client, &self.config).await
    }
}

impl S3Backend {
    async fn snapshot_index_bytes(&self) -> Result<Vec<u8>, BackendError> {
        read_sqlite_snapshot_bytes(self.store.pool(), &self.config.indexing.db_path).await
    }
}

async fn read_sqlite_snapshot_bytes(
    pool: &sqlx::SqlitePool,
    db_path: &Path,
) -> Result<Vec<u8>, BackendError> {
    let snapshot_path = temporary_snapshot_copy_path(db_path);
    let snapshot_path_text = snapshot_path.to_string_lossy().into_owned();
    let vacuum_result = sqlx::query("VACUUM main INTO ?1")
        .bind(&snapshot_path_text)
        .execute(pool)
        .await;
    if let Err(error) = vacuum_result {
        let _ = tokio::fs::remove_file(&snapshot_path).await;
        return Err(error.into());
    }
    let read_result = tokio::fs::read(&snapshot_path).await;
    let _ = tokio::fs::remove_file(&snapshot_path).await;
    Ok(read_result?)
}

fn temporary_snapshot_copy_path(db_path: &Path) -> PathBuf {
    let parent = db_path.parent().unwrap_or_else(|| Path::new("."));
    parent.join(format!("rurr-s3-snapshot-{}.db", Uuid::new_v4()))
}

fn invalid_layout(error: S3LayoutError) -> BackendError {
    BackendError::InvalidRequest {
        message: error.to_string(),
    }
}

fn artifact_error(error: S3TrackingArtifactError) -> BackendError {
    let message = error.to_string();
    match error {
        S3TrackingArtifactError::InvalidAppId(app_id) => BackendError::InvalidRequest {
            message: format!("invalid S3 tracking app id: {app_id}"),
        },
        S3TrackingArtifactError::Layout(error) => invalid_layout(error),
        S3TrackingArtifactError::Metadata(error) => map_metadata_error(error),
        S3TrackingArtifactError::Json(error) => BackendError::from(error),
        S3TrackingArtifactError::Io(error) => BackendError::from(error),
        S3TrackingArtifactError::GraphModel(_)
        | S3TrackingArtifactError::UnexpectedKind(..)
        | S3TrackingArtifactError::MissingBody { .. }
        | S3TrackingArtifactError::MissingSequenceId => BackendError::InvalidRequest { message },
        S3TrackingArtifactError::Timestamp { operation, message } => {
            BackendError::Timestamp { operation, message }
        }
    }
}

fn map_metadata_error(error: rurr_core::tracking::s3_metadata::S3MetadataError) -> BackendError {
    match error {
        rurr_core::tracking::s3_metadata::S3MetadataError::MissingMetadataMap(object_key) => {
            BackendError::Provider {
                operation: "head_object_metadata",
                message: format!("S3 object '{object_key}' is missing user metadata"),
            }
        }
        rurr_core::tracking::s3_metadata::S3MetadataError::MissingField(object_key, field) => {
            BackendError::InvalidRequest {
                message: format!("S3 object '{object_key}' is missing required metadata '{field}'"),
            }
        }
        rurr_core::tracking::s3_metadata::S3MetadataError::MalformedField(
            object_key,
            field,
            message,
        ) => BackendError::MalformedMetadata {
            key: object_key,
            field,
            message,
        },
        rurr_core::tracking::s3_metadata::S3MetadataError::SerializePointer(error) => {
            BackendError::from(error)
        }
    }
}

fn provider<E>(operation: &'static str) -> impl FnOnce(E) -> BackendError
where
    E: std::fmt::Display,
{
    move |error| BackendError::Provider {
        operation,
        message: error.to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use rurr_testkit::env::EnvVarGuard;
    use std::time::Duration;

    #[test]
    fn pointer_metadata_rejects_malformed_json() {
        let metadata = std::collections::HashMap::from([
            ("parent_pointer".to_string(), "not-json".to_string()),
            ("spawning_parent_pointer".to_string(), "None".to_string()),
        ]);

        let error = rurr_core::tracking::s3_metadata::parse_pointer_metadata(
            &metadata,
            "parent_pointer",
            "data/key/metadata.json",
        )
        .map_err(map_metadata_error)
        .expect_err("malformed pointer should fail");

        assert!(
            error.to_string().contains("parent_pointer"),
            "unexpected error: {error}"
        );
    }

    #[tokio::test]
    async fn sqlite_snapshot_bytes_use_vacuum_copy() {
        let dir = tempfile::tempdir().expect("tempdir should create");
        let db_path = dir.path().join("index.sqlite3");
        let store = S3IndexStore::open(&db_path)
            .await
            .expect("store should open");
        sqlx::query(
            "INSERT INTO projects (project_id, created_at, last_written)
             VALUES ('demo', '2026-03-20T00:00:00Z', '2026-03-20T00:00:00Z')",
        )
        .execute(store.pool())
        .await
        .expect("project should insert");

        let bytes = read_sqlite_snapshot_bytes(store.pool(), &db_path)
            .await
            .expect("snapshot copy should read");
        assert!(bytes.starts_with(b"SQLite format 3"));

        let restored_path = dir.path().join("restored.sqlite3");
        tokio::fs::write(&restored_path, bytes)
            .await
            .expect("snapshot bytes should write");
        let restored = S3IndexStore::open(&restored_path)
            .await
            .expect("restored store should open");
        let projects = restored
            .list_projects()
            .await
            .expect("projects should list");
        assert_eq!(projects.len(), 1);
        assert_eq!(projects[0].name, "demo");
        let leftover_temp_files = std::fs::read_dir(dir.path())
            .expect("temp dir should list")
            .filter_map(Result::ok)
            .filter(|entry| {
                entry
                    .file_name()
                    .to_string_lossy()
                    .starts_with("rurr-s3-snapshot-")
            })
            .count();
        assert_eq!(leftover_temp_files, 0);
    }

    #[test]
    fn config_overrides_take_precedence_over_env() {
        let _env = EnvVarGuard::set([
            ("RURR_S3_BUCKET", Some("env-bucket")),
            ("RURR_S3_REGION", Some("env-region")),
            ("RURR_S3_ACCESS_KEY_ID", Some("env-access")),
            ("RURR_S3_SECRET_ACCESS_KEY", Some("env-secret")),
            ("RURR_S3_SESSION_TOKEN", None),
            ("RURR_S3_LIST_PAGE_SIZE", Some("0")),
        ]);

        let config = S3BackendConfig::from_env_and_overrides(
            "index.sqlite3",
            S3BackendConfigOverrides {
                bucket: Some("cli-bucket".to_string()),
                region: Some("cli-region".to_string()),
                access_key_id: Some("cli-access".to_string()),
                secret_access_key: Some("cli-secret".to_string()),
                list_page_size: Some(Some(2)),
                update_interval: Some(Duration::from_millis(1)),
                snapshot_interval: Some(Duration::from_millis(2)),
                ..S3BackendConfigOverrides::default()
            },
        )
        .expect("override config should parse");

        assert_eq!(config.transport.bucket(), "cli-bucket");
        assert_eq!(config.transport.region(), "cli-region");
        let credentials = config
            .transport
            .credentials("test")
            .expect("override credentials should parse");
        assert_eq!(credentials.access_key_id(), "cli-access");
        assert_eq!(credentials.secret_access_key(), "cli-secret");
        assert_eq!(config.indexing.list_page_size, Some(2));
        assert_eq!(config.indexing.update_interval, Duration::from_millis(1));
        assert_eq!(config.indexing.snapshot_interval, Duration::from_millis(2));
    }

    #[test]
    fn config_accepts_burr_s3_setting_env_aliases() {
        let _env = EnvVarGuard::set([
            ("RURR_S3_BUCKET", None),
            ("RURR_S3_REGION", None),
            ("RURR_S3_UPDATE_INTERVAL_MS", None),
            ("RURR_S3_SNAPSHOT_INTERVAL_MS", None),
            ("RURR_S3_AWS_MAX_CONCURRENCY", None),
            ("RURR_S3_PRIOR_SNAPSHOTS_TO_KEEP", None),
            ("RURR_S3_LOAD_SNAPSHOT_ON_START", None),
            ("RURR_S3_ACCESS_KEY_ID", None),
            ("RURR_S3_SECRET_ACCESS_KEY", None),
            ("RURR_S3_SESSION_TOKEN", None),
            ("BURR_S3_BUCKET", Some("burr-bucket")),
            ("AWS_REGION", Some("us-east-1")),
            ("AWS_ACCESS_KEY_ID", Some("aws-access")),
            ("AWS_SECRET_ACCESS_KEY", Some("aws-secret")),
            ("AWS_SESSION_TOKEN", None),
            ("BURR_UPDATE_INTERVAL_MILLISECONDS", Some("11")),
            ("BURR_SNAPSHOT_INTERVAL_MILLISECONDS", Some("22")),
            ("BURR_AWS_MAX_CONCURRENCY", Some("3")),
            ("BURR_PRIOR_SNAPSHOTS_TO_KEEP", Some("4")),
            ("BURR_LOAD_SNAPSHOT_ON_START", Some("false")),
        ]);

        let config = S3BackendConfig::from_env_and_overrides(
            "index.sqlite3",
            S3BackendConfigOverrides::default(),
        )
        .expect("Burr env aliases should parse");

        assert_eq!(config.transport.bucket(), "burr-bucket");
        let credentials = config
            .transport
            .credentials("test")
            .expect("AWS env credentials should parse");
        assert_eq!(credentials.access_key_id(), "aws-access");
        assert_eq!(credentials.secret_access_key(), "aws-secret");
        assert_eq!(config.indexing.update_interval, Duration::from_millis(11));
        assert_eq!(config.indexing.snapshot_interval, Duration::from_millis(22));
        assert_eq!(config.indexing.aws_max_concurrency, 3);
        assert_eq!(config.indexing.prior_snapshots_to_keep, 4);
        assert!(!config.indexing.load_snapshot_on_start);
    }

    #[test]
    fn config_rejects_missing_static_credentials() {
        let _env = EnvVarGuard::set([
            ("RURR_S3_ACCESS_KEY_ID", None),
            ("RURR_S3_SECRET_ACCESS_KEY", None),
            ("RURR_S3_SESSION_TOKEN", None),
            ("AWS_ACCESS_KEY_ID", None),
            ("AWS_SECRET_ACCESS_KEY", None),
            ("AWS_SESSION_TOKEN", None),
        ]);

        let error = S3BackendConfig::from_env_and_overrides(
            "index.sqlite3",
            S3BackendConfigOverrides {
                bucket: Some("bucket".to_string()),
                region: Some("us-east-1".to_string()),
                ..S3BackendConfigOverrides::default()
            },
        )
        .expect_err("missing static credentials should fail closed");

        assert!(
            error
                .to_string()
                .contains("missing access_key_id for S3 backend"),
            "unexpected error: {error}"
        );
    }

    #[test]
    fn config_rejects_invalid_limits_and_intervals() {
        let _env = EnvVarGuard::set([]);
        let error = S3BackendConfig::from_env_and_overrides(
            "index.sqlite3",
            S3BackendConfigOverrides {
                bucket: Some("bucket".to_string()),
                region: Some("us-east-1".to_string()),
                list_page_size: Some(Some(1001)),
                ..S3BackendConfigOverrides::default()
            },
        )
        .expect_err("oversized list page should fail");
        assert!(error.to_string().contains("list_page_size"));

        let error = S3BackendConfig::from_env_and_overrides(
            "index.sqlite3",
            S3BackendConfigOverrides {
                bucket: Some("bucket".to_string()),
                region: Some("us-east-1".to_string()),
                update_interval: Some(Duration::ZERO),
                ..S3BackendConfigOverrides::default()
            },
        )
        .expect_err("zero interval should fail");
        assert!(error.to_string().contains("update_interval"));
    }

    #[cfg(unix)]
    #[test]
    fn config_rejects_non_utf8_environment_values() {
        use std::ffi::OsString;
        use std::os::unix::ffi::OsStringExt;

        struct OsEnvGuard {
            name: &'static str,
            previous: Option<OsString>,
        }

        impl OsEnvGuard {
            fn set(name: &'static str, value: OsString) -> Self {
                let previous = std::env::var_os(name);
                std::env::set_var(name, value);
                Self { name, previous }
            }
        }

        impl Drop for OsEnvGuard {
            fn drop(&mut self) {
                match self.previous.as_ref() {
                    Some(value) => std::env::set_var(self.name, value),
                    None => std::env::remove_var(self.name),
                }
            }
        }

        let _env = EnvVarGuard::set([
            ("BURR_S3_BUCKET", None),
            ("RURR_S3_REGION", Some("us-east-1")),
        ]);
        let _invalid_bucket = OsEnvGuard::set("RURR_S3_BUCKET", OsString::from_vec(vec![0xff]));

        let error = S3BackendConfig::from_env_and_overrides(
            "index.sqlite3",
            S3BackendConfigOverrides::default(),
        )
        .expect_err("non-UTF-8 env should fail closed");

        assert!(
            error.to_string().contains("RURR_S3_BUCKET")
                && error.to_string().contains("valid UTF-8"),
            "unexpected error: {error}"
        );
    }
}
