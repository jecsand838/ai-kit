use rurr_core::action::{ActionContext, ActionTracer};
use rurr_core::application::{ApplicationContext, ParentPointer};
use serde_json::json;

fn sample_context() -> ApplicationContext {
    ApplicationContext {
        app_id: "ctx-app".to_string(),
        partition_key: Some("tenant-a".to_string()),
        sequence_id: Some(17),
        prior_step: Some("prepare".to_string()),
        parent_pointer: Some(ParentPointer {
            app_id: "parent-app".to_string(),
            partition_key: Some("parent-pk".to_string()),
            sequence_id: Some(3),
        }),
        spawning_parent_pointer: Some(ParentPointer {
            app_id: "spawn-parent".to_string(),
            partition_key: None,
            sequence_id: Some(9),
        }),
    }
}

#[test]
fn application_context_serializes_with_nulls_for_absent_fields() {
    let context = ApplicationContext {
        app_id: "ctx-app".to_string(),
        partition_key: None,
        sequence_id: None,
        prior_step: None,
        parent_pointer: None,
        spawning_parent_pointer: None,
    };

    assert_eq!(
        serde_json::to_value(&context).expect("context should serialize"),
        json!({
            "app_id": "ctx-app",
            "partition_key": null,
            "sequence_id": null,
            "prior_step": null,
            "parent_pointer": null,
            "spawning_parent_pointer": null,
        })
    );
}

#[test]
fn application_context_serializes_nested_parent_pointers() {
    assert_eq!(
        serde_json::to_value(sample_context()).expect("context should serialize"),
        json!({
            "app_id": "ctx-app",
            "partition_key": "tenant-a",
            "sequence_id": 17,
            "prior_step": "prepare",
            "parent_pointer": {
                "app_id": "parent-app",
                "partition_key": "parent-pk",
                "sequence_id": 3,
            },
            "spawning_parent_pointer": {
                "app_id": "spawn-parent",
                "partition_key": null,
                "sequence_id": 9,
            },
        })
    );
}

#[test]
fn default_action_context_is_explicitly_empty() {
    let context = ActionContext::default();

    assert!(context.inputs.is_empty());
    assert!(context.app_context.is_none());
    assert_eq!(context.tracer, ActionTracer::default());
}
