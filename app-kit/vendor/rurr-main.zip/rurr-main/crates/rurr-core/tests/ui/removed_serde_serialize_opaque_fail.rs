fn main() {
    let _ = rurr_core::serde::serialize_opaque("opaque");
}
