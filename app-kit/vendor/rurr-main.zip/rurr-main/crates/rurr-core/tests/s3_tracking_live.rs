use indexmap::IndexMap;
use rurr_core::action::ActionError;
use rurr_core::application::ApplicationError;
use rurr_core::graph::{Graph, GraphAction};
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, PostStepContext, PreStepContext, SpanContext, StreamContext,
    StreamItemContext, SyncLifecycleAdapter,
};
use rurr_core::tracking::{
    ApplicationMetadataModel, ApplicationModel, LocalTrackingClient, S3TrackingClient,
    S3TrackingConfig, TrackingError,
};
use rurr_core::LocalAction;
use rurr_core::{
    ApplicationBuilder, CascadeMode, FunctionActionBuilder, ParallelMap, ParallelTaskSource,
    RunnableGraph, State, TrackerSpec,
};
use rurr_testkit::action_fixture::{scripted_action, ScriptedActionSpec};
use rurr_testkit::action_metadata::NamedActionMetadata;
use rurr_testkit::env::EnvVarGuard;
use rurr_testkit::live_services::S3LiveBucketScenario;
use rurr_testkit::S3LiveHarness;
use serde_json::{json, Value};
use std::collections::BTreeSet;
use std::sync::Arc;
use std::time::{Duration, SystemTime};

fn live_enabled() -> bool {
    rurr_testkit::check_live_tests_enabled()
}

fn parse_jsonl(body: &[u8]) -> Vec<Value> {
    S3LiveHarness::parse_jsonl(body).expect("log body should parse")
}

async fn listed_s3_keys(scenario: &S3LiveBucketScenario, prefix: impl Into<String>) -> Vec<String> {
    let probe = scenario.artifact_probe(prefix);
    probe.objects().await.expect("objects should list")
}

async fn s3_head_metadata(
    scenario: &S3LiveBucketScenario,
    key: &str,
) -> std::collections::HashMap<String, String> {
    scenario
        .artifact_probe("")
        .head_required(key)
        .await
        .expect("object head should succeed")
}

async fn s3_object_bytes(scenario: &S3LiveBucketScenario, key: &str) -> Vec<u8> {
    scenario
        .artifact_probe("")
        .object_bytes(key)
        .await
        .expect("object body should collect")
}

fn graph() -> Graph {
    let action = FunctionActionBuilder::new()
        .with_source_code("fn noop(_state, _ctx) -> IndexMap<String, Value> { IndexMap::new() }")
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("action should build")
        .with_name("noop")
        .expect("action should be named");
    Graph::new(
        vec![GraphAction::new(action).expect("graph action should build")],
        Vec::new(),
        "noop",
    )
    .expect("graph should build")
}

fn app_builder(
    app_id: &str,
    partition_key: Option<&str>,
    config: S3TrackingConfig,
) -> ApplicationBuilder {
    ApplicationBuilder::new()
        .with_graph(graph())
        .expect("graph should attach")
        .with_identifiers(app_id, partition_key.map(str::to_string), None)
        .expect("identifiers should attach")
        .with_tracker(TrackerSpec::s3(config))
        .expect("tracker should attach")
}

fn broken_graph() -> Graph {
    let action = scripted_action(
        NamedActionMetadata::from_slices(&[], &[], &[]),
        ScriptedActionSpec::from_run(|_state, _ctx| {
            Err(ActionError::Internal {
                message: "Broken".to_string(),
            })
        })
        .with_source_code(
            "fn broken_action(_state, _ctx) { Err(ActionError::Internal { message: \"Broken\".to_string() }) }",
        ),
    )
    .with_name("broken")
    .expect("broken action should be named");
    Graph::new(
        vec![GraphAction::new(action).expect("graph action should build")],
        Vec::new(),
        "broken",
    )
    .expect("broken graph should build")
}

fn broken_app_builder(
    app_id: &str,
    partition_key: Option<&str>,
    config: S3TrackingConfig,
) -> ApplicationBuilder {
    ApplicationBuilder::new()
        .with_graph(broken_graph())
        .expect("broken graph should attach")
        .with_identifiers(app_id, partition_key.map(str::to_string), None)
        .expect("identifiers should attach")
        .with_tracker(TrackerSpec::s3(config))
        .expect("tracker should attach")
}

fn parallel_graph() -> Graph {
    let child_action = FunctionActionBuilder::new()
        .writes(["value"])
        .with_source_code("fn child(_state, _ctx) -> value { value: 1 }")
        .build_sync(|_state, _ctx| IndexMap::from([("value".to_string(), json!(1))]))
        .expect("child action should build")
        .with_name("child")
        .expect("child action should be named");
    let child_graph = RunnableGraph::new(
        vec![GraphAction::new(child_action).expect("child graph action should build")],
        Vec::new(),
        Some("child".to_string()),
    );
    let parallel_action = ParallelMap::new(
        ParallelTaskSource::graphs(vec![child_graph], Arc::new(|state, _ctx| Ok(state.clone()))),
        Vec::new(),
        Vec::new(),
        Vec::new(),
        CascadeMode::None,
    )
    .with_source_code(
        "fn parallel(state, _ctx) -> child_states { ParallelTaskSource::graphs([child], state.clone()) }",
    )
    .with_name("parallel")
    .expect("parallel action should be named");

    Graph::new(
        vec![GraphAction::new(parallel_action).expect("parallel graph action should build")],
        Vec::new(),
        "parallel",
    )
    .expect("parallel graph should build")
}

struct LifecycleEquivalenceScenario {
    pre_step: PreStepContext,
    post_step: PostStepContext,
    span: SpanContext,
    attributes: IndexMap<String, Value>,
    stream: StreamContext,
    first_item: StreamItemContext,
    second_item: StreamItemContext,
}

impl LifecycleEquivalenceScenario {
    fn new(app_id: &str, partition_key: &str) -> Self {
        let started_at = SystemTime::UNIX_EPOCH + Duration::from_secs(1_700_000_000);
        let inputs = IndexMap::from([
            ("prompt".to_string(), json!("prove lifecycle body parity")),
            ("attempt".to_string(), json!(1)),
        ]);
        let result = IndexMap::from([("count".to_string(), json!(2))]);
        let state = State::new(IndexMap::from([
            ("count".to_string(), json!(2)),
            ("__SEQUENCE_ID".to_string(), json!(11)),
            ("__PRIOR_STEP".to_string(), json!("noop")),
        ]));

        Self {
            pre_step: PreStepContext::new("noop", 11, 22, started_at)
                .with_app_id(app_id)
                .with_inputs(inputs),
            post_step: PostStepContext::new("noop", 11, 22, started_at)
                .with_app_id(app_id)
                .with_result(result)
                .with_state(state),
            span: SpanContext::new("noop", 11, "span-equivalence")
                .with_app_id(app_id)
                .with_partition_key(partition_key)
                .with_span_name("equivalence-span")
                .with_parent_span_id("parent-span")
                .with_span_dependencies(vec!["dep-a".to_string(), "dep-b".to_string()]),
            attributes: IndexMap::from([(
                "lifecycle_equivalence".to_string(),
                json!({"sink": "shared-builder", "strict": true}),
            )]),
            stream: StreamContext::new("noop", 11, 33).with_app_id(app_id),
            first_item: StreamItemContext::new("noop", 11, 33, 0).with_app_id(app_id),
            second_item: StreamItemContext::new("noop", 11, 33, 1).with_app_id(app_id),
        }
    }
}

fn run_sync_lifecycle_sequence(
    adapter: &impl SyncLifecycleAdapter,
    scenario: &LifecycleEquivalenceScenario,
) {
    adapter
        .pre_run_step(&scenario.pre_step)
        .expect("sync pre_run_step should log");
    adapter
        .post_run_step(&scenario.post_step)
        .expect("sync post_run_step should log");
    adapter
        .pre_start_span(&scenario.span)
        .expect("sync pre_start_span should log");
    adapter
        .log_attributes(&scenario.span, &scenario.attributes)
        .expect("sync log_attributes should log");
    adapter
        .post_end_span(&scenario.span)
        .expect("sync post_end_span should log");
    adapter
        .pre_start_stream(&scenario.stream)
        .expect("sync pre_start_stream should log");
    adapter
        .post_stream_item(&scenario.first_item)
        .expect("sync first stream item should log");
    adapter
        .post_stream_item(&scenario.second_item)
        .expect("sync second stream item should update count");
    adapter
        .post_end_stream(&scenario.stream)
        .expect("sync post_end_stream should log");
}

async fn run_async_lifecycle_sequence(
    adapter: &impl AsyncLifecycleAdapter,
    scenario: &LifecycleEquivalenceScenario,
) {
    adapter
        .pre_run_step(&scenario.pre_step)
        .await
        .expect("async pre_run_step should log");
    adapter
        .post_run_step(&scenario.post_step)
        .await
        .expect("async post_run_step should log");
    adapter
        .pre_start_span(&scenario.span)
        .await
        .expect("async pre_start_span should log");
    adapter
        .log_attributes(&scenario.span, &scenario.attributes)
        .await
        .expect("async log_attributes should log");
    adapter
        .post_end_span(&scenario.span)
        .await
        .expect("async post_end_span should log");
    adapter
        .pre_start_stream(&scenario.stream)
        .await
        .expect("async pre_start_stream should log");
    adapter
        .post_stream_item(&scenario.first_item)
        .await
        .expect("async first stream item should log");
    adapter
        .post_stream_item(&scenario.second_item)
        .await
        .expect("async second stream item should update count");
    adapter
        .post_end_stream(&scenario.stream)
        .await
        .expect("async post_end_stream should log");
}

fn read_local_lifecycle_log(client: &LocalTrackingClient, app_id: &str) -> Vec<Value> {
    let log_path = client
        .storage_dir()
        .join(app_id)
        .join(LocalTrackingClient::LOG_FILENAME);
    parse_jsonl(&std::fs::read(log_path).expect("local lifecycle log should read"))
}

async fn s3_lifecycle_log_keys(
    scenario: &S3LiveBucketScenario,
    project: &str,
    partition_key: &str,
    app_id: &str,
) -> Vec<String> {
    let app_path = format!("/{partition_key}/{app_id}/");
    listed_s3_keys(scenario, format!("data/{project}/"))
        .await
        .into_iter()
        .filter(|key| key.contains(&app_path) && key.ends_with("__log.jsonl"))
        .collect()
}

async fn read_s3_lifecycle_events(
    scenario: &S3LiveBucketScenario,
    project: &str,
    partition_key: &str,
    app_id: &str,
) -> Vec<Value> {
    let log_keys = s3_lifecycle_log_keys(scenario, project, partition_key, app_id).await;
    assert!(!log_keys.is_empty(), "S3 lifecycle log keys should exist");

    let mut events = Vec::new();
    for key in log_keys {
        let body = s3_object_bytes(scenario, &key).await;
        assert!(
            body.ends_with(b"\n"),
            "S3 lifecycle log object should be a newline-terminated JSONL body: {key}"
        );
        let object_events = parse_jsonl(&body);
        assert_eq!(
            object_events.len(),
            1,
            "S3 lifecycle log object should contain exactly one raw event: {key}"
        );
        events.extend(object_events);
    }
    events
}

fn assert_missing_stream_state_error(error: rurr_core::lifecycle::LifecycleError, phase: &str) {
    assert_eq!(error.phase(), phase);
    assert!(
        error.message().contains("missing stream state"),
        "missing stream state error should be explicit: {error}"
    );
    assert!(
        error.message().contains("pre_start_stream"),
        "missing stream state error should identify the required pre_start_stream hook: {error}"
    );
}

fn assert_missing_post_step_state_error(error: rurr_core::lifecycle::LifecycleError) {
    assert_eq!(error.phase(), "post_run_step");
    assert!(
        error
            .message()
            .contains("tracking end_entry requires committed post-step state"),
        "missing post-step state error should be explicit: {error}"
    );
}

async fn assert_no_s3_lifecycle_logs(
    scenario: &S3LiveBucketScenario,
    project: &str,
    partition_key: &str,
    app_id: &str,
) {
    let log_keys = s3_lifecycle_log_keys(scenario, project, partition_key, app_id).await;
    assert!(
        log_keys.is_empty(),
        "failed lifecycle hook must not write log objects: {log_keys:?}"
    );
}

fn event_type(event: &Value) -> &str {
    event
        .get("type")
        .and_then(Value::as_str)
        .unwrap_or("<missing-type>")
}

fn assert_local_lifecycle_event_order(events: &[Value]) {
    let types = events.iter().map(event_type).collect::<Vec<_>>();
    assert_eq!(
        types,
        [
            "begin_entry",
            "end_entry",
            "begin_span",
            "attribute",
            "end_span",
            "begin_stream",
            "first_item_stream",
            "end_stream",
        ]
    );
}

fn expected_lifecycle_stable_events() -> Vec<Value> {
    vec![
        json!({
            "type": "begin_entry",
            "action": "noop",
            "inputs": {
                "prompt": "prove lifecycle body parity",
                "attempt": 1,
            },
            "sequence_id": 11,
        }),
        json!({
            "type": "end_entry",
            "action": "noop",
            "result": {
                "count": 2,
            },
            "exception": null,
            "state": {
                "count": 2,
                "__SEQUENCE_ID": 11,
                "__PRIOR_STEP": "noop",
            },
            "sequence_id": 11,
        }),
        json!({
            "type": "begin_span",
            "action_sequence_id": 11,
            "span_id": "span-equivalence",
            "span_name": "equivalence-span",
            "parent_span_id": "parent-span",
            "span_dependencies": ["dep-a", "dep-b"],
        }),
        json!({
            "type": "attribute",
            "key": "lifecycle_equivalence",
            "action_sequence_id": 11,
            "span_id": "span-equivalence",
            "value": {
                "sink": "shared-builder",
                "strict": true,
            },
            "tags": {},
        }),
        json!({
            "type": "end_span",
            "action_sequence_id": 11,
            "span_id": "span-equivalence",
        }),
        json!({
            "type": "begin_stream",
            "action_sequence_id": 11,
            "span_id": null,
        }),
        json!({
            "type": "first_item_stream",
            "action_sequence_id": 11,
            "span_id": null,
        }),
        json!({
            "type": "end_stream",
            "action_sequence_id": 11,
            "span_id": null,
            "items_streamed": 2,
        }),
    ]
}

fn timestamp_fields(event_type: &str) -> &'static [&'static str] {
    match event_type {
        "begin_entry" | "begin_span" => &["start_time"],
        "end_entry" | "end_span" | "end_stream" => &["end_time"],
        "attribute" => &["time_logged"],
        "begin_stream" => &["stream_init_time"],
        "first_item_stream" => &["first_item_time"],
        other => panic!("unexpected lifecycle event type: {other}"),
    }
}

fn assert_rurr_timestamp(value: &Value, field: &str) {
    let timestamp = value
        .get(field)
        .and_then(Value::as_str)
        .unwrap_or_else(|| panic!("{field} should be a timestamp string in {value}"));
    assert_eq!(
        timestamp.len(),
        30,
        "{field} should use fixed-width nanosecond RFC3339 UTC format"
    );
    for (index, expected) in [
        (4, '-'),
        (7, '-'),
        (10, 'T'),
        (13, ':'),
        (16, ':'),
        (19, '.'),
        (29, 'Z'),
    ] {
        assert_eq!(
            timestamp.as_bytes()[index] as char,
            expected,
            "{field} has invalid timestamp separator: {timestamp}"
        );
    }
    for (index, byte) in timestamp.bytes().enumerate() {
        if matches!(index, 4 | 7 | 10 | 13 | 16 | 19 | 29) {
            continue;
        }
        assert!(
            byte.is_ascii_digit(),
            "{field} has a non-digit timestamp component: {timestamp}"
        );
    }
}

fn assert_event_matches_stable_fields(actual: &Value, expected: &Value) {
    let event_type = expected
        .get("type")
        .and_then(Value::as_str)
        .expect("expected stable event should include type");
    let actual_object = actual
        .as_object()
        .unwrap_or_else(|| panic!("actual event should be an object: {actual}"));
    let expected_object = expected
        .as_object()
        .expect("expected stable event should be an object");

    let mut expected_keys = expected_object.keys().cloned().collect::<BTreeSet<_>>();
    for field in timestamp_fields(event_type) {
        assert_rurr_timestamp(actual, field);
        expected_keys.insert((*field).to_string());
    }
    let actual_keys = actual_object.keys().cloned().collect::<BTreeSet<_>>();
    assert_eq!(
        actual_keys, expected_keys,
        "event fields should match the lifecycle schema for {event_type}"
    );

    for (key, expected_value) in expected_object {
        assert_eq!(
            actual_object.get(key),
            Some(expected_value),
            "stable lifecycle field {key} differed for {event_type}"
        );
    }
}

fn assert_lifecycle_events_match_expected_ordered(events: &[Value]) {
    let expected = expected_lifecycle_stable_events();
    assert_eq!(events.len(), expected.len());
    for (actual, expected) in events.iter().zip(expected.iter()) {
        assert_event_matches_stable_fields(actual, expected);
    }
}

#[tokio::test]
async fn s3_tracking_client_writes_provider_backed_child_events_to_minio() {
    if !live_enabled() {
        return;
    }

    let scenario = S3LiveBucketScenario::new("rurr-core-s3-child-live-test", "rurr-core-s3-child")
        .await
        .expect("S3 live scenario should build");
    let mut app = ApplicationBuilder::new()
        .with_graph(parallel_graph())
        .expect("parallel graph should attach")
        .with_identifiers("parent-app", Some("pk".to_string()), None)
        .expect("identifiers should attach")
        .with_tracker(TrackerSpec::s3(
            scenario.expect_tracking_config("project-child", "tracker-child"),
        ))
        .expect("tracker should attach")
        .build()
        .expect("parent app should build");

    app.run().expect("parallel parent should run");

    let probe = scenario.artifact_probe("data/project-child/");
    let objects = probe.objects().await.expect("objects should list");
    let child_keys = objects
        .iter()
        .filter(|key| key.contains("/pk/parent-app/") && key.ends_with("__children.jsonl"))
        .collect::<Vec<_>>();
    assert_eq!(
        child_keys.len(),
        1,
        "one provider-backed child event object should be written"
    );
    let child_key = child_keys[0].as_str();

    let metadata = probe
        .head_required(child_key)
        .await
        .expect("child object metadata should read");
    assert_eq!(
        metadata.get("tracker_id"),
        Some(&"tracker-child".to_string())
    );

    probe
        .assert_body_has_trailing_newline(child_key)
        .await
        .expect("child event object should be complete newline-terminated JSONL");
    let entries = probe
        .jsonl_values(child_key)
        .await
        .expect("child JSONL should parse");
    assert_eq!(entries.len(), 1);
    let child = &entries[0];
    assert_eq!(child["type"], json!("child_application_data"));
    assert_eq!(child["event_type"], json!("spawn_start"));
    assert_eq!(child["sequence_id"], json!(0));
    assert_eq!(child["child"]["type"], json!("pointer_data"));
    assert!(child["child"]["app_id"].as_str().is_some_and(
        |app_id| app_id.len() == 64 && app_id.chars().all(|ch| ch.is_ascii_hexdigit())
    ));
    assert_eq!(child["child"]["partition_key"], json!("pk"));
}

#[tokio::test]
async fn s3_tracking_client_writes_burr_layout_and_metadata_to_minio() {
    if !live_enabled() {
        return;
    }

    let scenario = S3LiveBucketScenario::new("rurr-core-s3-live-test", "rurr-core-s3")
        .await
        .expect("S3 live scenario should build");

    let mut sync_app = app_builder(
        "app-sync",
        Some("pk"),
        scenario.expect_tracking_config("project-sync", "tracker-sync"),
    )
    .with_spawning_parent("parent", Some("parent-pk".to_string()), 7)
    .expect("spawning parent should attach")
    .build()
    .expect("sync app should build");
    sync_app
        .step(None)
        .expect("sync step should run")
        .expect("sync step should execute");

    let mut async_app = app_builder(
        "app-async",
        None,
        scenario.expect_tracking_config("project-async", "tracker-async"),
    )
    .abuild()
    .await
    .expect("async app should build");
    async_app
        .astep(None)
        .await
        .expect("async step should run")
        .expect("async step should execute");

    let keys = listed_s3_keys(&scenario, "data/").await;
    assert!(keys
        .iter()
        .any(|key| key.ends_with("/pk/app-sync/graph.json")));
    assert!(keys
        .iter()
        .any(|key| key.ends_with("/pk/app-sync/metadata.json")));
    assert!(keys
        .iter()
        .any(|key| key.contains("/pk/app-sync/") && key.ends_with("__log.jsonl")));
    assert!(keys
        .iter()
        .any(|key| key.ends_with("/__none__/app-async/metadata.json")));

    let sync_graph_key = keys
        .iter()
        .find(|key| key.ends_with("/pk/app-sync/graph.json"))
        .expect("sync graph key should exist");
    let async_graph_key = keys
        .iter()
        .find(|key| key.ends_with("/__none__/app-async/graph.json"))
        .expect("async graph key should exist");
    let metadata_key = keys
        .iter()
        .find(|key| key.ends_with("/pk/app-sync/metadata.json"))
        .expect("metadata key should exist");
    let async_metadata_key = keys
        .iter()
        .find(|key| key.ends_with("/__none__/app-async/metadata.json"))
        .expect("async metadata key should exist");

    let metadata = s3_head_metadata(&scenario, metadata_key).await;
    assert_eq!(
        metadata.get("tracker_id"),
        Some(&"tracker-sync".to_string())
    );
    assert!(metadata
        .get("spawning_parent_pointer")
        .expect("spawning parent pointer metadata should exist")
        .contains("\"app_id\":\"parent\""));
    assert_eq!(
        scenario
            .artifact_probe("")
            .head_required(sync_graph_key)
            .await
            .expect("sync graph head should succeed")
            .get("tracker_id"),
        Some(&"tracker-sync".to_string())
    );
    assert_eq!(
        scenario
            .artifact_probe("")
            .head_required(async_graph_key)
            .await
            .expect("async graph head should succeed")
            .get("tracker_id"),
        Some(&"tracker-async".to_string())
    );
    assert_eq!(
        scenario
            .artifact_probe("")
            .head_required(async_metadata_key)
            .await
            .expect("async metadata head should succeed")
            .get("tracker_id"),
        Some(&"tracker-async".to_string())
    );

    let graph_body = s3_object_bytes(&scenario, sync_graph_key).await;
    let graph_model: ApplicationModel =
        serde_json::from_slice(&graph_body).expect("graph body should parse");
    assert_eq!(graph_model.r#type, "application");
    assert_eq!(graph_model.entrypoint, "noop");
    assert_eq!(graph_model.actions.len(), 1);
    assert!(graph_model.actions[0].optional_inputs.is_empty());

    let metadata_body = s3_object_bytes(&scenario, metadata_key).await;
    let metadata_model: ApplicationMetadataModel =
        serde_json::from_slice(&metadata_body).expect("metadata body should parse");
    assert_eq!(metadata_model.r#type, "application_metadata");
    assert_eq!(metadata_model.partition_key.as_deref(), Some("pk"));
    assert_eq!(
        metadata_model
            .spawning_parent_pointer
            .expect("spawning pointer should exist")
            .app_id,
        "parent"
    );

    let log_keys = keys
        .iter()
        .filter(|key| key.contains("/pk/app-sync/") && key.ends_with("__log.jsonl"))
        .cloned()
        .collect::<Vec<_>>();
    assert!(!log_keys.is_empty(), "sync log keys should exist");
    let async_log_keys = keys
        .iter()
        .filter(|key| key.contains("/__none__/app-async/") && key.ends_with("__log.jsonl"))
        .cloned()
        .collect::<Vec<_>>();
    assert!(!async_log_keys.is_empty(), "async log keys should exist");
    for log_key in &log_keys {
        let log_metadata = s3_head_metadata(&scenario, log_key).await;
        assert_eq!(
            log_metadata.get("tracker_id"),
            Some(&"tracker-sync".to_string())
        );
        assert_eq!(log_metadata.get("min_sequence_id"), Some(&"0".to_string()));
        assert_eq!(log_metadata.get("max_sequence_id"), Some(&"0".to_string()));
    }

    let mut sync_log = Vec::new();
    for log_key in &log_keys {
        sync_log.extend(parse_jsonl(&s3_object_bytes(&scenario, log_key).await));
    }
    assert!(sync_log
        .iter()
        .any(|value| value["type"] == json!("begin_entry")));
    assert!(sync_log
        .iter()
        .any(|value| value["type"] == json!("end_entry")));
    assert!(sync_log
        .iter()
        .all(|value| value.get("sequence_id").and_then(Value::as_u64) == Some(0)));

    for async_log_key in &async_log_keys {
        let async_log_metadata = s3_head_metadata(&scenario, async_log_key).await;
        assert_eq!(
            async_log_metadata.get("tracker_id"),
            Some(&"tracker-async".to_string())
        );
    }
    let mut async_log = Vec::new();
    for async_log_key in &async_log_keys {
        async_log.extend(parse_jsonl(
            &s3_object_bytes(&scenario, async_log_key).await,
        ));
    }
    assert!(async_log
        .iter()
        .any(|value| value["type"] == json!("begin_entry")));
    assert!(async_log
        .iter()
        .any(|value| value["type"] == json!("end_entry")));
}

#[tokio::test]
async fn s3_tracking_client_rejects_missing_static_credentials_before_provider_io() {
    if !live_enabled() {
        return;
    }

    let _env = EnvVarGuard::set([
        ("AWS_ACCESS_KEY_ID", None),
        ("AWS_SECRET_ACCESS_KEY", None),
        ("AWS_SESSION_TOKEN", None),
    ]);
    let scenario =
        S3LiveBucketScenario::new("rurr-core-s3-live-test", "rurr-core-s3-missing-creds")
            .await
            .expect("S3 live scenario should build");

    let client = S3TrackingClient::new(scenario.expect_tracking_config_without_static_credentials(
        "project-missing-creds",
        "tracker-missing-creds",
    ))
    .expect("client construction should stay local");
    let error = client
        .register_application_async("app-missing-creds", None, &graph(), None, None)
        .await
        .expect_err("missing static credentials should fail before provider write");

    match error {
        TrackingError::MissingS3TrackerConfig { field } => assert_eq!(field, "access_key_id"),
        other => panic!("expected missing S3 credentials, got {other:?}"),
    }
    assert!(
        scenario
            .artifact_probe("data/")
            .objects()
            .await
            .expect("objects should list")
            .is_empty(),
        "missing credentials must not produce S3 objects"
    );
}

#[tokio::test]
async fn s3_parallel_tracking_does_not_emit_or_advertise_reserved_context_inputs() {
    if !live_enabled() {
        return;
    }

    let scenario = S3LiveBucketScenario::new("rurr-core-s3-live-test", "rurr-core-s3-parallel")
        .await
        .expect("S3 live scenario should build");

    let project = "project-s3-parallel-no-reserved";
    let app_id = "app-parallel-no-reserved";
    let partition_key = "pk-parallel";
    let mut app = ApplicationBuilder::new()
        .with_graph(parallel_graph())
        .expect("parallel graph should attach")
        .with_identifiers(app_id, Some(partition_key.to_string()), None)
        .expect("identifiers should attach")
        .with_tracker(TrackerSpec::s3(
            scenario.expect_tracking_config(project, "tracker-parallel-no-reserved"),
        ))
        .expect("tracker should attach")
        .build()
        .expect("parallel app should build");

    app.step(None)
        .expect("parallel step should run")
        .expect("parallel step should execute");

    let keys = listed_s3_keys(&scenario, "data/").await;
    let graph_key = keys
        .iter()
        .find(|key| key.ends_with(&format!("/{partition_key}/{app_id}/graph.json")))
        .expect("parent graph key should exist");
    let graph_body = s3_object_bytes(&scenario, graph_key).await;
    let graph_model: ApplicationModel =
        serde_json::from_slice(&graph_body).expect("graph body should parse");
    let parallel_action = graph_model
        .actions
        .iter()
        .find(|action| action.name == "parallel")
        .expect("parallel action metadata should exist");
    assert!(parallel_action.optional_inputs.is_empty());
    assert!(!parallel_action
        .optional_inputs
        .iter()
        .any(|key| key == "__context" || key == "__tracer"));

    let parent_events = read_s3_lifecycle_events(&scenario, project, partition_key, app_id).await;
    let begin_inputs = parent_events
        .iter()
        .find(|event| event["type"] == "begin_entry")
        .and_then(|event| event["inputs"].as_object())
        .expect("parent begin_entry should include an input object");
    assert!(!begin_inputs.contains_key("__context"));
    assert!(!begin_inputs.contains_key("__tracer"));
}

#[tokio::test]
async fn s3_tracking_failed_step_records_exact_rurr_exception_text() {
    if !live_enabled() {
        return;
    }

    let scenario = S3LiveBucketScenario::new("rurr-core-s3-live-test", "rurr-core-s3-failed-step")
        .await
        .expect("S3 live scenario should build");

    let project = "project-s3-failed-step-exception";
    let app_id = "app-s3-failed-step-exception";
    let partition_key = "pk-failed-step";
    let mut app = broken_app_builder(
        app_id,
        Some(partition_key),
        scenario.expect_tracking_config(project, "tracker-failed-step-exception"),
    )
    .build()
    .expect("broken app should build");

    let error = app.run().expect_err("broken action should fail");
    assert!(matches!(
        &error,
        ApplicationError::Action(ActionError::Internal { message }) if message == "Broken"
    ));

    let events = read_s3_lifecycle_events(&scenario, project, partition_key, app_id).await;
    let end_entry = events
        .iter()
        .find(|event| event["type"] == "end_entry")
        .expect("failed step should emit end_entry");
    let exception = end_entry["exception"]
        .as_str()
        .expect("failed S3 end_entry should include exception text");
    assert_eq!(exception, error.to_string());
    assert!(
        !exception.contains("Traceback"),
        "Rurr S3 failure logging must not invent Python traceback text: {exception}"
    );
}

#[tokio::test]
async fn s3_tracking_post_run_step_rejects_missing_state_without_logs() {
    if !live_enabled() {
        return;
    }

    let scenario =
        S3LiveBucketScenario::new("rurr-core-s3-live-test", "rurr-core-s3-missing-post-state")
            .await
            .expect("S3 live scenario should build");

    let project = "project-s3-missing-post-state";
    let partition_key = "pk-missing-post-state";
    let app_graph = graph();

    let sync_client = S3TrackingClient::new(
        scenario.expect_tracking_config(project, "tracker-sync-missing-post-state"),
    )
    .expect("sync S3 tracking client should build");
    let sync_app = "app-sync-missing-post-state";
    SyncLifecycleAdapter::register_application(
        &sync_client,
        sync_app,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .expect("sync app should register");
    let sync_error = SyncLifecycleAdapter::post_run_step(
        &sync_client,
        &PostStepContext::new("noop", 7, 99, SystemTime::UNIX_EPOCH).with_app_id(sync_app),
    )
    .expect_err("sync missing post-step state should fail");
    assert_missing_post_step_state_error(sync_error);
    assert_no_s3_lifecycle_logs(&scenario, project, partition_key, sync_app).await;

    let async_client = S3TrackingClient::new(
        scenario.expect_tracking_config(project, "tracker-async-missing-post-state"),
    )
    .expect("async S3 tracking client should build");
    let async_app = "app-async-missing-post-state";
    AsyncLifecycleAdapter::register_application(
        &async_client,
        async_app,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .await
    .expect("async app should register");
    let async_error = AsyncLifecycleAdapter::post_run_step(
        &async_client,
        &PostStepContext::new("noop", 8, 100, SystemTime::UNIX_EPOCH).with_app_id(async_app),
    )
    .await
    .expect_err("async missing post-step state should fail");
    assert_missing_post_step_state_error(async_error);
    assert_no_s3_lifecycle_logs(&scenario, project, partition_key, async_app).await;
}

#[tokio::test]
async fn s3_tracking_unknown_app_id_fails_without_synthetic_none_partition_log() {
    if !live_enabled() {
        return;
    }

    let scenario = S3LiveBucketScenario::new("rurr-core-s3-live-test", "rurr-core-s3-unknown-app")
        .await
        .expect("S3 live scenario should build");

    let project = "project-s3-unknown-app";
    let client =
        S3TrackingClient::new(scenario.expect_tracking_config(project, "tracker-unknown-app"))
            .expect("S3 tracking client should build");

    let unknown_app = "app-never-registered";
    let error = SyncLifecycleAdapter::pre_run_step(
        &client,
        &PreStepContext::new("noop", 0, 0, SystemTime::UNIX_EPOCH).with_app_id(unknown_app),
    )
    .expect_err("unknown app id must fail before S3 key construction");
    assert!(
        error
            .to_string()
            .contains("S3 lifecycle event for unregistered app id"),
        "unknown app error should be explicit: {error}"
    );
    assert_no_s3_lifecycle_logs(&scenario, project, "__none__", unknown_app).await;

    let unpartitioned_app = "app-registered-unpartitioned";
    SyncLifecycleAdapter::register_application(
        &client,
        unpartitioned_app,
        None,
        &graph(),
        None,
        None,
    )
    .expect("unpartitioned app should register");
    SyncLifecycleAdapter::pre_run_step(
        &client,
        &PreStepContext::new("noop", 1, 1, SystemTime::UNIX_EPOCH).with_app_id(unpartitioned_app),
    )
    .expect("registered unpartitioned app should write under Burr __none__ lane");
    let log_keys = s3_lifecycle_log_keys(&scenario, project, "__none__", unpartitioned_app).await;
    assert_eq!(
        log_keys.len(),
        1,
        "registered partitionless apps should keep the intentional __none__ path"
    );
}

#[tokio::test]
async fn s3_tracking_stream_hooks_reject_missing_pre_start_stream_without_synthetic_logs() {
    if !live_enabled() {
        return;
    }

    let scenario =
        S3LiveBucketScenario::new("rurr-core-s3-live-test", "rurr-core-s3-missing-stream")
            .await
            .expect("S3 live scenario should build");

    let project = "project-s3-missing-stream-state";
    let partition_key = "pk-missing-stream";
    let app_graph = graph();

    let sync_client = S3TrackingClient::new(
        scenario.expect_tracking_config(project, "tracker-sync-missing-stream-state"),
    )
    .expect("sync S3 tracking client should build");
    let sync_item_app = "app-sync-missing-stream-item";
    SyncLifecycleAdapter::register_application(
        &sync_client,
        sync_item_app,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .expect("sync item app should register");
    let sync_item_error = SyncLifecycleAdapter::post_stream_item(
        &sync_client,
        &StreamItemContext::new("noop", 7, 99, 0).with_app_id(sync_item_app),
    )
    .expect_err("missing sync pre_start_stream should reject stream item");
    assert_missing_stream_state_error(sync_item_error, "post_stream_item");
    assert_no_s3_lifecycle_logs(&scenario, project, partition_key, sync_item_app).await;

    let sync_end_app = "app-sync-missing-stream-end";
    SyncLifecycleAdapter::register_application(
        &sync_client,
        sync_end_app,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .expect("sync end app should register");
    let sync_end_error = SyncLifecycleAdapter::post_end_stream(
        &sync_client,
        &StreamContext::new("noop", 7, 100).with_app_id(sync_end_app),
    )
    .expect_err("missing sync pre_start_stream should reject stream end");
    assert_missing_stream_state_error(sync_end_error, "post_end_stream");
    assert_no_s3_lifecycle_logs(&scenario, project, partition_key, sync_end_app).await;

    let async_client = S3TrackingClient::new(
        scenario.expect_tracking_config(project, "tracker-async-missing-stream-state"),
    )
    .expect("async S3 tracking client should build");
    let async_item_app = "app-async-missing-stream-item";
    AsyncLifecycleAdapter::register_application(
        &async_client,
        async_item_app,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .await
    .expect("async item app should register");
    let async_item_error = AsyncLifecycleAdapter::post_stream_item(
        &async_client,
        &StreamItemContext::new("noop", 7, 101, 0).with_app_id(async_item_app),
    )
    .await
    .expect_err("missing async pre_start_stream should reject stream item");
    assert_missing_stream_state_error(async_item_error, "post_stream_item");
    assert_no_s3_lifecycle_logs(&scenario, project, partition_key, async_item_app).await;

    let async_end_app = "app-async-missing-stream-end";
    AsyncLifecycleAdapter::register_application(
        &async_client,
        async_end_app,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .await
    .expect("async end app should register");
    let async_end_error = AsyncLifecycleAdapter::post_end_stream(
        &async_client,
        &StreamContext::new("noop", 7, 102).with_app_id(async_end_app),
    )
    .await
    .expect_err("missing async pre_start_stream should reject stream end");
    assert_missing_stream_state_error(async_end_error, "post_end_stream");
    assert_no_s3_lifecycle_logs(&scenario, project, partition_key, async_end_app).await;
}

#[tokio::test]
async fn local_sync_s3_sync_and_s3_async_lifecycle_bodies_match() {
    if !live_enabled() {
        return;
    }

    let s3_scenario =
        S3LiveBucketScenario::new("rurr-core-s3-live-test", "rurr-core-s3-equivalence")
            .await
            .expect("S3 live scenario should build");

    let app_id = "app-lifecycle-equivalence";
    let partition_key = "pk-equivalence";
    let app_graph = graph();
    let scenario = LifecycleEquivalenceScenario::new(app_id, partition_key);

    let local_root = tempfile::tempdir().expect("local tracking tempdir should build");
    let local_client = LocalTrackingClient::new("project-local-equivalence", local_root.path())
        .expect("local tracking client should build");
    SyncLifecycleAdapter::register_application(
        &local_client,
        app_id,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .expect("local app should register");
    run_sync_lifecycle_sequence(&local_client, &scenario);

    let s3_sync_project = "project-s3-sync-equivalence";
    let s3_sync_client = S3TrackingClient::new(
        s3_scenario.expect_tracking_config(s3_sync_project, "tracker-sync-equivalence"),
    )
    .expect("sync S3 tracking client should build");
    SyncLifecycleAdapter::register_application(
        &s3_sync_client,
        app_id,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .expect("sync S3 app should register");
    run_sync_lifecycle_sequence(&s3_sync_client, &scenario);

    let s3_async_project = "project-s3-async-equivalence";
    let s3_async_client = S3TrackingClient::new(
        s3_scenario.expect_tracking_config(s3_async_project, "tracker-async-equivalence"),
    )
    .expect("async S3 tracking client should build");
    AsyncLifecycleAdapter::register_application(
        &s3_async_client,
        app_id,
        Some(partition_key),
        &app_graph,
        None,
        None,
    )
    .await
    .expect("async S3 app should register");
    run_async_lifecycle_sequence(&s3_async_client, &scenario).await;

    let local_events = read_local_lifecycle_log(&local_client, app_id);
    let s3_sync_events =
        read_s3_lifecycle_events(&s3_scenario, s3_sync_project, partition_key, app_id).await;
    let s3_async_events =
        read_s3_lifecycle_events(&s3_scenario, s3_async_project, partition_key, app_id).await;

    assert_local_lifecycle_event_order(&local_events);
    assert_lifecycle_events_match_expected_ordered(&local_events);
    assert_lifecycle_events_match_expected_ordered(&s3_sync_events);
    assert_lifecycle_events_match_expected_ordered(&s3_async_events);
}
