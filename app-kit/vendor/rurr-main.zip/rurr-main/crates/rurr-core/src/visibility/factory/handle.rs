use super::session::TraceSession;
use super::VisibilityError;
use crate::common::panic::panic_payload_to_string;
use crate::lifecycle::{poll_with_lifecycle_contexts, AsyncLifecyclePollContext};
use crate::visibility::span::ActionSpan;
use crate::visibility::span_scope;
use futures::FutureExt;
use indexmap::IndexMap;
use serde_json::Value;
use std::future::Future;
use std::panic::{self, AssertUnwindSafe};
use std::sync::{Arc, Condvar, Mutex};
use tokio::sync::Notify;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum TraceSpanLifecyclePhase {
    Active,
    Closing,
    Closed,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum TraceHandleMode {
    SyncOnly,
    AsyncCapable,
}

#[derive(Debug)]
struct TraceSpanLifecycle {
    phase: TraceSpanLifecyclePhase,
    in_flight_ops: usize,
}

type TraceFinishTarget = (Arc<TraceSession>, ActionSpan);

enum AsyncCloseState {
    Done,
    Wait,
    Finish(TraceFinishTarget),
}

impl Default for TraceSpanLifecycle {
    fn default() -> Self {
        Self {
            phase: TraceSpanLifecyclePhase::Active,
            in_flight_ops: 0,
        }
    }
}

struct TraceSpanHandleState {
    session: Arc<TraceSession>,
    span: ActionSpan,
    mode: TraceHandleMode,
    poll_contexts: Vec<Arc<dyn AsyncLifecyclePollContext>>,
    lifecycle: Mutex<TraceSpanLifecycle>,
    drained: Condvar,
    drained_async: Notify,
}

impl TraceSpanHandleState {
    fn new(
        session: Arc<TraceSession>,
        span: ActionSpan,
        mode: TraceHandleMode,
        poll_contexts: Vec<Arc<dyn AsyncLifecyclePollContext>>,
    ) -> Self {
        Self {
            session,
            span,
            mode,
            poll_contexts,
            lifecycle: Mutex::new(TraceSpanLifecycle::default()),
            drained: Condvar::new(),
            drained_async: Notify::new(),
        }
    }

    fn begin_sync_operation(self: &Arc<Self>) -> Option<TraceSpanOperation> {
        let mut lifecycle = self
            .lifecycle
            .lock()
            .expect("trace span lifecycle lock should not be poisoned");
        if lifecycle.phase != TraceSpanLifecyclePhase::Active {
            return None;
        }
        lifecycle.in_flight_ops += 1;
        drop(lifecycle);

        Some(TraceSpanOperation {
            state: Arc::clone(self),
            session: Arc::clone(&self.session),
            span: self.span.clone(),
        })
    }

    fn begin_async_operation(
        self: &Arc<Self>,
        operation: &'static str,
    ) -> Result<Option<TraceSpanOperation>, VisibilityError> {
        if self.mode == TraceHandleMode::SyncOnly && self.is_active() {
            return Err(VisibilityError::AsyncOperationRequiresAsyncTrace { operation });
        }
        Ok(self.begin_sync_operation())
    }

    fn is_active(&self) -> bool {
        self.lifecycle
            .lock()
            .expect("trace span lifecycle lock should not be poisoned")
            .phase
            == TraceSpanLifecyclePhase::Active
    }

    fn finish_target(&self) -> TraceFinishTarget {
        (Arc::clone(&self.session), self.span.clone())
    }

    fn try_close_locked(&self, lifecycle: &mut TraceSpanLifecycle) -> Option<TraceFinishTarget> {
        if lifecycle.in_flight_ops == 0 {
            lifecycle.phase = TraceSpanLifecyclePhase::Closed;
            Some(self.finish_target())
        } else {
            None
        }
    }

    fn try_close(&self) -> Option<TraceFinishTarget> {
        let mut lifecycle = self
            .lifecycle
            .lock()
            .expect("trace span lifecycle lock should not be poisoned");
        self.try_close_locked(&mut lifecycle)
    }

    fn begin_async_close(&self, owns_close: &mut bool) -> AsyncCloseState {
        let mut lifecycle = self
            .lifecycle
            .lock()
            .expect("trace span lifecycle lock should not be poisoned");
        match lifecycle.phase {
            TraceSpanLifecyclePhase::Active => {
                lifecycle.phase = TraceSpanLifecyclePhase::Closing;
                *owns_close = true;
            }
            TraceSpanLifecyclePhase::Closing if !*owns_close => return AsyncCloseState::Done,
            TraceSpanLifecyclePhase::Closing => {}
            TraceSpanLifecyclePhase::Closed => return AsyncCloseState::Done,
        }

        match self.try_close_locked(&mut lifecycle) {
            Some(target) => AsyncCloseState::Finish(target),
            None => AsyncCloseState::Wait,
        }
    }

    fn finish_sync(&self) -> Result<(), VisibilityError> {
        let (session, span) = {
            let mut lifecycle = self
                .lifecycle
                .lock()
                .expect("trace span lifecycle lock should not be poisoned");
            if lifecycle.phase != TraceSpanLifecyclePhase::Active {
                return Ok(());
            }
            lifecycle.phase = TraceSpanLifecyclePhase::Closing;
            loop {
                if let Some(target) = self.try_close_locked(&mut lifecycle) {
                    break target;
                }
                lifecycle = self
                    .drained
                    .wait(lifecycle)
                    .expect("trace span lifecycle lock should not be poisoned");
            }
        };

        session.finish_span_sync(&span)
    }

    async fn finish_async(&self) -> Result<(), VisibilityError> {
        let mut owns_close = false;
        loop {
            let notified = self.drained_async.notified();
            match self.begin_async_close(&mut owns_close) {
                AsyncCloseState::Done => return Ok(()),
                AsyncCloseState::Finish((session, span)) => {
                    return session.finish_span_async(&span).await;
                }
                AsyncCloseState::Wait => {}
            }

            notified.await;
            if let Some((session, span)) = self.try_close() {
                return session.finish_span_async(&span).await;
            }
        }
    }
}

struct TraceSpanOperation {
    state: Arc<TraceSpanHandleState>,
    session: Arc<TraceSession>,
    span: ActionSpan,
}

impl Drop for TraceSpanOperation {
    fn drop(&mut self) {
        let mut lifecycle = self
            .state
            .lifecycle
            .lock()
            .expect("trace span lifecycle lock should not be poisoned");
        if lifecycle.in_flight_ops > 0 {
            lifecycle.in_flight_ops -= 1;
        }
        if lifecycle.in_flight_ops == 0 {
            self.state.drained.notify_all();
            self.state.drained_async.notify_waiters();
        }
    }
}

#[derive(Clone, Default)]
/// A handle to the currently active visibility span.
pub struct TraceSpanHandle {
    state: Option<Arc<TraceSpanHandleState>>,
}

impl TraceSpanHandle {
    pub(super) fn active(
        session: Arc<TraceSession>,
        span: ActionSpan,
        mode: TraceHandleMode,
        poll_contexts: Vec<Arc<dyn AsyncLifecyclePollContext>>,
    ) -> Self {
        Self {
            state: Some(Arc::new(TraceSpanHandleState::new(
                session,
                span,
                mode,
                poll_contexts,
            ))),
        }
    }

    /// Returns the active span metadata while the handle is still open.
    pub fn span(&self) -> Option<&ActionSpan> {
        let state = self.state.as_deref()?;
        if state.is_active() {
            Some(&state.span)
        } else {
            None
        }
    }

    /// Logs a single attribute on the active span.
    pub fn log_attribute(
        &self,
        key: impl Into<String>,
        value: Value,
    ) -> Result<(), VisibilityError> {
        self.with_sync_operation(|operation| {
            operation
                .session
                .log_attribute_sync(&operation.span, key, value)
        })
        .map(|_| ())
    }

    /// Logs multiple attributes on the active span.
    pub fn log_attributes(
        &self,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), VisibilityError> {
        self.with_sync_operation(|operation| {
            operation
                .session
                .log_attributes_sync(&operation.span, attributes)
        })
        .map(|_| ())
    }

    /// Logs a single attribute on the active span from async code.
    pub async fn log_attribute_async(
        &self,
        key: impl Into<String>,
        value: Value,
    ) -> Result<(), VisibilityError> {
        self.with_async_operation("log_attribute_async", |operation| async move {
            operation
                .session
                .log_attribute_async(&operation.span, key, value)
                .await
        })
        .await
        .map(|_| ())
    }

    /// Logs multiple attributes on the active span from async code.
    pub async fn log_attributes_async(
        &self,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), VisibilityError> {
        self.with_async_operation("log_attributes_async", |operation| async move {
            operation
                .session
                .log_attributes_async(&operation.span, attributes)
                .await
        })
        .await
        .map(|_| ())
    }

    /// Starts a child span, runs the provided function, and closes the child span on return.
    pub fn trace_child<F, R>(
        &self,
        span_name: impl Into<String>,
        function: F,
    ) -> Result<R, VisibilityError>
    where
        F: FnOnce(TraceSpanHandle) -> R,
    {
        self.trace_child_with_dependencies(span_name, Vec::new(), function)
    }

    /// Starts a child span with explicit dependencies, runs the function, and closes the span.
    pub fn trace_child_with_dependencies<F, R>(
        &self,
        span_name: impl Into<String>,
        span_dependencies: Vec<String>,
        function: F,
    ) -> Result<R, VisibilityError>
    where
        F: FnOnce(TraceSpanHandle) -> R,
    {
        let Some(child) = self.start_child_handle_sync(span_name, span_dependencies)? else {
            return run_sync_scope(Self::default(), "trace_child", function);
        };
        run_sync_scope(child, "trace_child", function)
    }

    /// Starts an async child span, runs the future, and closes the span on completion.
    pub async fn trace_child_async<F, Fut, R>(
        &self,
        span_name: impl Into<String>,
        function: F,
    ) -> Result<R, VisibilityError>
    where
        F: FnOnce(TraceSpanHandle) -> Fut,
        Fut: Future<Output = R>,
    {
        self.trace_child_with_dependencies_async(span_name, Vec::new(), function)
            .await
    }

    /// Starts an async child span with explicit dependencies and runs the provided future.
    pub async fn trace_child_with_dependencies_async<F, Fut, R>(
        &self,
        span_name: impl Into<String>,
        span_dependencies: Vec<String>,
        function: F,
    ) -> Result<R, VisibilityError>
    where
        F: FnOnce(TraceSpanHandle) -> Fut,
        Fut: Future<Output = R>,
    {
        let Some(child) = self
            .start_child_handle_async(span_name, span_dependencies)
            .await?
        else {
            return run_async_scope(Self::default(), "trace_child_async", function).await;
        };
        run_async_scope(child, "trace_child_async", function).await
    }

    pub(crate) fn finish_sync(&self) -> Result<(), VisibilityError> {
        let Some(state) = self.state.as_deref() else {
            return Ok(());
        };
        state.finish_sync()
    }

    pub(crate) async fn finish_async(&self) -> Result<(), VisibilityError> {
        let Some(state) = self.state.as_deref() else {
            return Ok(());
        };
        state.finish_async().await
    }

    fn begin_operation(
        &self,
        async_operation: Option<&'static str>,
    ) -> Result<Option<TraceSpanOperation>, VisibilityError> {
        match self.state.as_ref() {
            Some(state) => match async_operation {
                Some(operation) => state.begin_async_operation(operation),
                None => Ok(state.begin_sync_operation()),
            },
            None => Ok(None),
        }
    }

    fn with_sync_operation<T>(
        &self,
        operation: impl FnOnce(TraceSpanOperation) -> Result<T, VisibilityError>,
    ) -> Result<Option<T>, VisibilityError> {
        self.begin_operation(None)?.map(operation).transpose()
    }

    async fn with_async_operation<T, Fut>(
        &self,
        operation_name: &'static str,
        operation: impl FnOnce(TraceSpanOperation) -> Fut,
    ) -> Result<Option<T>, VisibilityError>
    where
        Fut: Future<Output = Result<T, VisibilityError>>,
    {
        match self.begin_operation(Some(operation_name))? {
            Some(operation_state) => operation(operation_state).await.map(Some),
            None => Ok(None),
        }
    }

    fn start_child_handle_sync(
        &self,
        span_name: impl Into<String>,
        span_dependencies: Vec<String>,
    ) -> Result<Option<TraceSpanHandle>, VisibilityError> {
        self.with_sync_operation(|operation| {
            operation.session.start_handle_sync(
                operation
                    .span
                    .spawn_with_dependencies(span_name, span_dependencies),
            )
        })
    }

    async fn start_child_handle_async(
        &self,
        span_name: impl Into<String>,
        span_dependencies: Vec<String>,
    ) -> Result<Option<TraceSpanHandle>, VisibilityError> {
        self.with_async_operation("trace_child_async", |operation| async move {
            operation
                .session
                .start_handle_async(
                    operation
                        .span
                        .spawn_with_dependencies(span_name, span_dependencies),
                )
                .await
        })
        .await
    }

    pub(in crate::visibility) fn run_in_current_scope<F, R>(&self, function: F) -> R
    where
        F: FnOnce() -> R,
    {
        match self.state.as_ref() {
            Some(state) if state.is_active() => {
                span_scope::scope_sync(state.session.session_id(), state.span.clone(), function)
            }
            _ => function(),
        }
    }

    pub(in crate::visibility) async fn run_in_current_scope_async<Fut>(
        &self,
        future: Fut,
    ) -> Fut::Output
    where
        Fut: Future,
    {
        match self.state.as_ref() {
            Some(state) if state.is_active() => {
                poll_with_lifecycle_contexts(
                    span_scope::scope_async(state.session.session_id(), state.span.clone(), future),
                    state.poll_contexts.clone(),
                )
                .await
            }
            _ => future.await,
        }
    }
}

fn run_sync_scope<F, R>(
    handle: TraceSpanHandle,
    operation: &'static str,
    function: F,
) -> Result<R, VisibilityError>
where
    F: FnOnce(TraceSpanHandle) -> R,
{
    let finish_handle = handle.clone();
    let body_handle = handle.clone();
    match panic::catch_unwind(AssertUnwindSafe(|| {
        handle.run_in_current_scope(|| function(body_handle))
    })) {
        Ok(output) => {
            finish_handle.finish_sync()?;
            Ok(output)
        }
        Err(payload) => {
            let panic_error = VisibilityError::CapturedPanic {
                operation,
                message: panic_payload_to_string(payload),
            };
            match finish_handle.finish_sync() {
                Ok(()) => Err(panic_error),
                Err(end_error) => Err(end_error),
            }
        }
    }
}

async fn run_async_scope<F, Fut, R>(
    handle: TraceSpanHandle,
    operation: &'static str,
    function: F,
) -> Result<R, VisibilityError>
where
    F: FnOnce(TraceSpanHandle) -> Fut,
    Fut: Future<Output = R>,
{
    let finish_handle = handle.clone();
    let scope_handle = handle.clone();
    let output_result = AssertUnwindSafe(async move {
        scope_handle
            .run_in_current_scope_async(async move { function(handle).await })
            .await
    })
    .catch_unwind()
    .await;
    match output_result {
        Ok(output) => {
            finish_handle.finish_async().await?;
            Ok(output)
        }
        Err(payload) => {
            let panic_error = VisibilityError::CapturedPanic {
                operation,
                message: panic_payload_to_string(payload),
            };
            match finish_handle.finish_async().await {
                Ok(()) => Err(panic_error),
                Err(end_error) => Err(end_error),
            }
        }
    }
}
