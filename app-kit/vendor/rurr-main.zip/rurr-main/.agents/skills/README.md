# Rurr Skills

This index lists the active repo-local skills for this workspace, including both the
Rurr workflow skills and the Rust best-practice companion skills they depend on.

Current workspace references:

- `README.md` and `docs/00_overview.md` for the living documentation map
- `ARCHITECTURE.md` plus subsystem `ARCHITECTURE.md` files for current system layout
- `.codex/config.toml` for repo-local Codex configuration that can affect model/profile behavior
- `AGENTS.md` and any nearer `AGENTS.override.md` files for instruction precedence

Proof-policy note:

- When a task changes how Rurr treats live proof, shims, or unsupported behavior, update
  `docs/ARCHITECTURE_GUARDRAILS.md`, `docs/03_test_plan.md`, the `AGENTS*.md` chain, and the
  relevant repo-local skills together.

Refactor-abstraction note:

- Rurr cleanup and reduction work must not use macros as the abstraction mechanism for ordinary
  production or test code. Prefer structs, enums, methods, and real trait boundaries. The
  `rurr-macros` crate is reserved for the public proc-macro action surface, not for hiding
  duplicated runtime, tracking, persistence, server, CLI, or test logic.

Use these in workflow order:

- [`$rurr-branch-diff-reduction-audit`](rurr-branch-diff-reduction-audit/SKILL.md): Use for current-branch versus base-branch delete-first cleanup audits. Distinction: this reviews the diff that exists now before a concrete refactor plan exists.
- [`$rurr-burr-parity-reduction-audit`](rurr-burr-parity-reduction-audit/SKILL.md): Use for workspace-wide or subsystem-level delete-first reduction audits. Distinction: this finds the biggest cleanup opportunities before a concrete refactor plan exists.
- [`$rurr-burr-source-parity-walk`](rurr-burr-source-parity-walk/SKILL.md): Use for source-backed comparison between a Rurr subsystem and vendored Burr. Distinction: this proves what behavior must remain fixed before a risky cleanup or parity-sensitive change.
- [`$audit-workspace-test-coverage`](audit-workspace-test-coverage/SKILL.md): Use for workspace-wide or subsystem-wide test coverage audits across unit, integration, live, negative-path, facade, and parity-sensitive behavior. Distinction: this produces a ranked coverage-gap report and proof targets before planning implementation; proof gaps for external behavior without a strict live lane should escalate to `$audit-workspace-for-shims`.
- [`$audit-workspace-for-shims`](audit-workspace-for-shims/SKILL.md): Use for read-only audits of production shims, synthetic fallbacks, fake non-live proof, and live-test output tampering. Distinction: this emits deletion-oriented shim findings, not ordinary coverage gaps or broad reduction rankings.
- [`$rurr-resolve-review-findings`](rurr-resolve-review-findings/SKILL.md): Use for resolving concrete implementation bugs found by Codex `/review` or built-in code review. Distinction: this plans or directly implements TDD fixes for review findings, not audit-driven delete-first optimization.
- [`$rurr-delete-first-refactor-plan`](rurr-delete-first-refactor-plan/SKILL.md): Use for turning an audit or cleanup brief into a decision-complete delete-first plan, then implementing approved delete-first refactors. Distinction: this specifies and executes what to delete, what to keep, how to write red tests, and how to verify the work; use `$rurr-resolve-review-findings` for concrete `/review` bug fixes.
- [`$remove-workspace-shims`](remove-workspace-shims/SKILL.md): Use for turning an approved shim audit into a delete-first plan and implementation pass. Distinction: this only works from approved shim findings and focuses on removing invented behavior, not general refactors or `/review` bug fixes.
- [`$expand-workspace-test-coverage`](expand-workspace-test-coverage/SKILL.md): Use for turning approved test-gap findings into a red-test-first plan and implementation pass. Distinction: this adds missing coverage and fixes only the real bugs exposed by those tests, rather than serving as a general refactor workflow; external behavior still needs the relevant strict proof lane instead of fake local proof.
- [`$rurr-follow-up-reduction-pass`](rurr-follow-up-reduction-pass/SKILL.md): Use after a partial cleanup lands and more structural deletion still remains. Distinction: this plans only the residual pass instead of re-planning the full refactor.
- [`$rurr-streaming-transaction-safety`](rurr-streaming-transaction-safety/SKILL.md): Use for streaming, session, lifecycle, and transaction rollback guardrails. Distinction: this protects lazy Burr-compatible runtime behavior while structure changes.
- [`$rurr-anchored-filesystem-hardening`](rurr-anchored-filesystem-hardening/SKILL.md): Use for anchored filesystem, output preparation, path validation, and tracking artifact path changes. Distinction: this protects path safety and facade boundaries.
- [`$rurr-persistence-adapter-parity`](rurr-persistence-adapter-parity/SKILL.md): Use for persistence contracts and adapter cleanup. Distinction: this protects sync/async boundaries, ordering, layout, and scan semantics.
- [`$rurr-proc-macro-ui-contract`](rurr-proc-macro-ui-contract/SKILL.md): Use for `rurr-macros` proc macro diagnostics and generated API contracts. Distinction: this protects compile-fail coverage and reserved runtime identifiers.
- [`$rurr-structural-completion-audit`](rurr-structural-completion-audit/SKILL.md): Use after implementation and before final gates. Distinction: this verifies negative structural requirements such as removed wrappers, private internals, and forbidden patterns.
- [`$rurr-gate-closeout`](rurr-gate-closeout/SKILL.md): Use for choosing gates, handling manifest fallout, and writing the final verification summary. Distinction: this is the closeout and verification workflow after code changes already exist.
- [`$refresh-workspace-agentic-documentation`](refresh-workspace-agentic-documentation/SKILL.md): Use for workspace-wide Markdown refreshes that must plan and execute against the current branch state. Distinction: this is for full-workspace doc refreshes, including synchronized proof-policy updates across living docs, `AGENTS*.md`, and repo-local skills, not one-off README or archive-pointer tweaks.
- [`$refresh-workspace-rustdocs`](refresh-workspace-rustdocs/SKILL.md): Use for workspace-wide Rustdoc refreshes that must plan and execute public API doc coverage and doctest validation. Distinction: this is for full-workspace coverage passes, not one-off item docs or single-crate doctest cleanup.
- [`$rurr-skill-catalog-maintenance`](rurr-skill-catalog-maintenance/SKILL.md): Use for adding, editing, validating, or closing out repo-local Rurr skills. Distinction: this governs `.agents/skills` structure, metadata, routing tests, and manifest-sensitive install flow.

Rust companion skills stored in this repo-local catalog:

- [`$use-rust-best-practices-core`](use-rust-best-practices-core/SKILL.md)
- [`$use-rust-best-practices-architecture`](use-rust-best-practices-architecture/SKILL.md)
- [`$use-rust-best-practices-abstractions`](use-rust-best-practices-abstractions/SKILL.md)
- [`$use-rust-best-practices-async`](use-rust-best-practices-async/SKILL.md)
- [`$use-rust-best-practices-networking`](use-rust-best-practices-networking/SKILL.md)
- [`$use-rust-best-practices-testing`](use-rust-best-practices-testing/SKILL.md)
- [`$use-rust-best-practices-dependencies-platforms`](use-rust-best-practices-dependencies-platforms/SKILL.md)

Rurr override for `$use-rust-best-practices-testing`:

- fake-backed unit tests are acceptable for internal logic and owned boundaries
- provider/backend behavior and production fallback semantics still require a named strict proof
  lane or an explicit unsupported/unimplemented/configuration error

Catalog protection:

- Active repo-local skills are declared in [`catalog.toml`](catalog.toml).
- Repo-local skills under `.agents/skills/` are protected workspace assets. Do not delete,
  compress, or materially rewrite skill folders, `references/`, or `assets/` during unrelated
  cleanup, branch-diff reduction, or refactor work. Only touch them when the operator explicitly
  requests skill-catalog work.
- `./scripts/check.sh` and `./scripts/check_ci.sh preflight` fail if a listed skill
  is missing, if a skill is added without being declared, or if a retirement omits
  the explicit operator instruction record.
