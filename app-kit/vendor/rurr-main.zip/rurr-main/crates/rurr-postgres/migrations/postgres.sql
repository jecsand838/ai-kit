CREATE TABLE IF NOT EXISTS __TABLE_NAME__ (
    partition_key TEXT DEFAULT '',
    app_id TEXT NOT NULL,
    sequence_id BIGINT NOT NULL,
    position TEXT NOT NULL,
    status TEXT NOT NULL,
    state JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (partition_key, app_id, sequence_id, position)
);

CREATE INDEX IF NOT EXISTS __TABLE_NAME___created_at_index
    ON __TABLE_NAME__ (created_at);
