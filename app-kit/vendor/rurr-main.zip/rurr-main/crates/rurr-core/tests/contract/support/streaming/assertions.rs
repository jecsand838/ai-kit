use super::hooks::UpdateTraceSpanEvents;

pub(crate) const SYNC_POST_EXECUTE_FAILURE_MARKER: &str = "intentional_sync_post_execute_failure";
pub(crate) const ASYNC_POST_EXECUTE_FAILURE_MARKER: &str = "intentional_async_post_execute_failure";
pub(crate) const SYNC_POST_STREAM_ITEM_FAILURE_MARKER: &str =
    "intentional_sync_post_stream_item_failure";
pub(crate) const ASYNC_POST_STREAM_ITEM_FAILURE_MARKER: &str =
    "intentional_async_post_stream_item_failure";
pub(crate) const SYNC_POST_RUN_STEP_FAILURE_MARKER: &str = "intentional_sync_post_run_step_failure";
pub(crate) const ASYNC_POST_RUN_STEP_FAILURE_MARKER: &str =
    "intentional_async_post_run_step_failure";
pub(crate) const SYNC_POST_END_STREAM_FAILURE_MARKER: &str =
    "intentional_sync_post_end_stream_failure";
pub(crate) const ASYNC_POST_END_STREAM_FAILURE_MARKER: &str =
    "intentional_async_post_end_stream_failure";
pub(crate) const SYNC_PRE_START_STREAM_FAILURE_MARKER: &str =
    "intentional_sync_pre_start_stream_failure";
pub(crate) const ASYNC_PRE_START_STREAM_FAILURE_MARKER: &str =
    "intentional_async_pre_start_stream_failure";

pub(crate) fn assert_single_update_trace_span(events: &UpdateTraceSpanEvents) {
    let pre_start = events.pre_start_events();
    let post_end = events.post_end_events();
    assert_eq!(
        pre_start.len(),
        1,
        "trace(update) should emit exactly one pre_start_span event"
    );
    assert_eq!(
        post_end.len(),
        1,
        "trace(update) should emit exactly one post_end_span event"
    );
    assert_eq!(pre_start[0].span_name, "update_trace");
    assert_eq!(pre_start[0].span_id, post_end[0]);
}
