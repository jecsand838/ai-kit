use futures::{stream, StreamExt};
use rurr_core::common::async_utils::{asyncify_iter, asyncify_stream};

#[tokio::test]
async fn asyncify_iter_with_sync_iterable_yields_expected_items() {
    let collected: Vec<_> = asyncify_iter(0..5).collect().await;
    assert_eq!(collected, vec![0, 1, 2, 3, 4]);
}

#[tokio::test]
async fn asyncify_stream_with_async_stream_yields_expected_items() {
    let collected: Vec<_> = asyncify_stream(stream::iter(0..5)).collect().await;
    assert_eq!(collected, vec![0, 1, 2, 3, 4]);
}

#[tokio::test]
async fn asyncify_iter_with_empty_sync_iterable_collects_empty() {
    let collected: Vec<i32> = asyncify_iter(Vec::<i32>::new()).collect().await;
    assert_eq!(collected, Vec::<i32>::new());
}

#[tokio::test]
async fn asyncify_stream_with_empty_async_stream_collects_empty() {
    let collected: Vec<i32> = asyncify_stream(stream::empty::<i32>()).collect().await;
    assert_eq!(collected, Vec::<i32>::new());
}
