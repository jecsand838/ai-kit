//! Backend traits and shared types for the tracking server.
//!
//! Backends turn on-disk or service-backed tracking artifacts into the JSON
//! payloads served by the HTTP API. [`TrackingBackend`](crate::backend::TrackingBackend)
//! keeps the required read paths small while optional features such as
//! annotations and indexing remain explicit capability flags.
//!
//! Local and S3 backends share the same response schema. The S3 backend performs
//! provider LIST/HEAD/GET work outside SQLite transactions, then serves API
//! reads from its local index.
//!
//! Optional capabilities are advertised explicitly. Routes for annotations,
//! indexing, and snapshots return typed unsupported-feature errors when a
//! backend does not implement that lane. In particular, unsupported annotation
//! `GET`, `POST`, and `PUT` requests all fail closed with
//! [`BackendError::UnsupportedFeature`](crate::backend::BackendError::UnsupportedFeature)
//! rather than returning synthetic empty annotation lists.

pub(crate) mod annotations;
/// Local tracking backend implementation backed by on-disk tracking artifacts.
pub mod local;
/// Partition helpers used by request parsing and backend filters.
pub mod partition;
/// S3 tracking backend implementation backed by S3 objects, SQLite indexing, and S3 snapshots.
pub mod s3;

use crate::schema::{
    AnnotationCreate, AnnotationOut, AnnotationUpdate, AppSpecResponse, ApplicationLogs,
    ApplicationPage, IndexingJob, Project,
};
use async_trait::async_trait;
pub use partition::PartitionSelector;
use rurr_persistence::storage_layout_version;
use thiserror::Error;

/// Backend-facing error type used by the tracking server.
#[derive(Debug, Error)]
pub enum BackendError {
    /// The requested project, app, or artifact was not found.
    #[error("resource not found: {resource}")]
    NotFound {
        /// Human-readable identifier for the missing resource.
        resource: String,
    },
    /// The request shape or user input was invalid.
    #[error("invalid request: {message}")]
    InvalidRequest {
        /// Validation or parsing failure returned to the client.
        message: String,
    },
    /// The backend does not support the requested feature.
    #[error("unsupported feature: {feature}")]
    UnsupportedFeature {
        /// Feature flag or route family that is unavailable.
        feature: &'static str,
    },
    /// Startup or backend configuration was invalid.
    #[error("backend configuration error: {message}")]
    Configuration {
        /// Human-readable configuration failure.
        message: String,
    },
    /// A network/provider operation failed.
    #[error("backend provider operation failed during {operation}: {message}")]
    Provider {
        /// Operation that failed.
        operation: &'static str,
        /// Provider or transport message.
        message: String,
    },
    /// A backend timestamp could not be represented.
    #[error("backend timestamp failed during {operation}: {message}")]
    Timestamp {
        /// Operation that needed a timestamp.
        operation: &'static str,
        /// Timestamp conversion details.
        message: String,
    },
    /// Indexing failed and recording that failure also failed.
    #[error(
        "indexing job finalization failed during {operation}; primary error: {primary}; recording error: {recording}"
    )]
    IndexingJobFinalization {
        /// Operation that attempted to record the failure.
        operation: &'static str,
        /// Primary indexing error.
        primary: Box<BackendError>,
        /// Error raised while recording the failure.
        recording: Box<BackendError>,
    },
    /// S3 object metadata exists but is not valid for Burr tracking semantics.
    #[error("malformed S3 metadata on object {key} field {field}: {message}")]
    MalformedMetadata {
        /// S3 object key with malformed metadata.
        key: String,
        /// Metadata field that failed validation.
        field: &'static str,
        /// Validation or parse error.
        message: String,
    },
    /// The background annotation executor shut down before finishing an operation.
    #[error("annotation executor closed during {operation}")]
    AnnotationExecutorClosed {
        /// Operation that was waiting on the background executor.
        operation: &'static str,
    },
    /// The background annotation executor panicked while running an operation.
    #[error("annotation executor panicked during {operation}")]
    AnnotationExecutorPanic {
        /// Operation that triggered the background executor request.
        operation: &'static str,
        /// Receiver error returned after the executor task unwound.
        #[source]
        source: tokio::sync::oneshot::error::RecvError,
    },
    /// Propagates filesystem and other I/O failures.
    #[error(transparent)]
    Io(#[from] std::io::Error),
    /// Propagates JSON parse and serialization failures.
    #[error(transparent)]
    SerdeJson(#[from] serde_json::Error),
    /// Propagates SQLite index failures.
    #[error(transparent)]
    Sqlx(#[from] sqlx::Error),
}

pub(crate) fn step_projection_error(error: serde_json::Error) -> BackendError {
    BackendError::InvalidRequest {
        message: format!("failed to project tracking log into Burr steps: {error}"),
    }
}

/// Advertises optional capabilities supported by one backend implementation.
///
/// Route handlers use these flags for API metadata and to reject unsupported
/// feature routes with typed errors rather than probing backend internals.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct BackendCapabilities {
    /// Whether indexing jobs are available.
    pub indexing: bool,
    /// Whether snapshotting features are available.
    pub snapshotting: bool,
    /// Whether demo generation workflows are available.
    pub supports_demos: bool,
    /// Whether annotations are available.
    ///
    /// Route handlers check this flag before calling annotation methods. When
    /// it is `false`, annotation reads and writes all return the same typed
    /// unsupported-feature response.
    pub supports_annotations: bool,
}

/// Async trait implemented by tracking server backends.
///
/// Implementations should return raw backend/provider errors through
/// [`BackendError`] rather than normalizing missing artifacts or malformed
/// metadata into invented API data.
#[async_trait]
pub trait TrackingBackend: Send + Sync {
    /// Returns the short backend identifier used in API metadata responses.
    fn backend_name(&self) -> &'static str;

    /// Returns the optional features supported by this backend.
    fn backend_capabilities(&self) -> BackendCapabilities {
        BackendCapabilities::default()
    }

    /// Builds the static application-spec payload for this backend.
    async fn app_spec(&self) -> Result<AppSpecResponse, BackendError> {
        let capabilities = self.backend_capabilities();
        Ok(AppSpecResponse {
            backend: self.backend_name().to_string(),
            storage_layout_version: storage_layout_version().to_string(),
            indexing: capabilities.indexing,
            snapshotting: capabilities.snapshotting,
            supports_demos: capabilities.supports_demos,
            supports_annotations: capabilities.supports_annotations,
        })
    }

    /// Lists known projects.
    async fn list_projects(&self) -> Result<Vec<Project>, BackendError>;

    /// Lists app summaries for one project and optional partition.
    async fn list_apps(
        &self,
        project_id: &str,
        partition_key: Option<&str>,
        limit: usize,
        offset: usize,
    ) -> Result<ApplicationPage, BackendError>;

    /// Reads one application log payload.
    async fn read_app(
        &self,
        project_id: &str,
        app_id: &str,
        partition_key: Option<&str>,
    ) -> Result<ApplicationLogs, BackendError>;

    /// Creates one annotation when annotations are supported.
    ///
    /// Backends that leave [`BackendCapabilities::supports_annotations`] set
    /// to `false` should keep this default fail-closed implementation.
    async fn create_annotation(
        &self,
        _annotation: AnnotationCreate,
        _project_id: &str,
        _partition_key: Option<&str>,
        _app_id: &str,
        _step_sequence_id: u64,
    ) -> Result<AnnotationOut, BackendError> {
        Err(BackendError::UnsupportedFeature {
            feature: "annotations",
        })
    }

    /// Updates one annotation when annotations are supported.
    ///
    /// Backends that leave [`BackendCapabilities::supports_annotations`] set
    /// to `false` should keep this default fail-closed implementation.
    async fn update_annotation(
        &self,
        _annotation: AnnotationUpdate,
        _project_id: &str,
        _annotation_id: u64,
    ) -> Result<AnnotationOut, BackendError> {
        Err(BackendError::UnsupportedFeature {
            feature: "annotations",
        })
    }

    /// Lists annotations with backend-specific filtering.
    ///
    /// Unsupported backends return [`BackendError::UnsupportedFeature`] rather
    /// than an invented empty list. The route layer applies the same capability
    /// guard to `GET`, `POST`, and `PUT`.
    async fn get_annotations(
        &self,
        _project_id: &str,
        _partition_selector: PartitionSelector,
        _app_id: Option<&str>,
        _step_sequence_id: Option<u64>,
    ) -> Result<Vec<AnnotationOut>, BackendError> {
        Err(BackendError::UnsupportedFeature {
            feature: "annotations",
        })
    }

    /// Lists indexing jobs when the backend supports them.
    async fn indexing_jobs(
        &self,
        _offset: usize,
        _limit: usize,
        _filter_empty: bool,
    ) -> Result<Vec<IndexingJob>, BackendError> {
        Err(BackendError::UnsupportedFeature {
            feature: "indexing jobs",
        })
    }

    /// Loads a backend snapshot, when snapshotting is supported.
    async fn load_snapshot(&self) -> Result<(), BackendError> {
        Err(BackendError::UnsupportedFeature {
            feature: "snapshotting",
        })
    }

    /// Updates backend indexes, when indexing is supported.
    async fn update_index(&self) -> Result<(), BackendError> {
        Err(BackendError::UnsupportedFeature {
            feature: "indexing",
        })
    }

    /// Persists a backend snapshot, when snapshotting is supported.
    async fn snapshot(&self) -> Result<(), BackendError> {
        Err(BackendError::UnsupportedFeature {
            feature: "snapshotting",
        })
    }
}
