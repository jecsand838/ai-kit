use super::super::support::application::ApplicationScenario;
use super::*;
use super::{actions::*, assertions::*, builders::*, cases::*, hooks::*};
use rurr_core::application::ExecutionOptions;

#[derive(Clone, Copy)]
enum DeferredNextStepGuardFailure {
    InvalidPriorStep,
    UnknownPriorStep,
    ConditionError,
}

fn assert_execute_only_counts(counts: &StreamAbortHookCounts, mode: StreamMode) {
    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(
        counts.async_pre_execute_call.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(
        counts.async_post_execute_call.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );

    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_pre_start_stream.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_post_end_stream.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_pre_run_step.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_post_run_step.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_pre_start_stream.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_post_end_stream.load(Ordering::SeqCst), 0);
}

async fn assert_deferred_next_step_guard_failure(
    mode: StreamMode,
    failure: DeferredNextStepGuardFailure,
) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let hooks = counting_hooks(&counts);

    let initial_state = match failure {
        DeferredNextStepGuardFailure::InvalidPriorStep => state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!(1)),
            ("__SEQUENCE_ID", json!(7)),
        ]),
        DeferredNextStepGuardFailure::UnknownPriorStep => state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("missing")),
            ("__SEQUENCE_ID", json!(7)),
        ]),
        DeferredNextStepGuardFailure::ConditionError => state_from_pairs([
            ("count", json!(0)),
            ("__PRIOR_STEP", json!("A")),
            ("__SEQUENCE_ID", json!(11)),
        ]),
    };
    let mut app = match failure {
        DeferredNextStepGuardFailure::InvalidPriorStep
        | DeferredNextStepGuardFailure::UnknownPriorStep => {
            let action = streaming_count_action(Arc::new(AtomicUsize::new(0)), 2, None);
            ApplicationScenario::single_action(initial_state.clone(), "stream", action)
                .map(|scenario| scenario.with_optional_hooks(Some(hooks)))
                .and_then(ApplicationScenario::build)
        }
        DeferredNextStepGuardFailure::ConditionError => ApplicationScenario::two_action_transition(
            initial_state.clone(),
            "A",
            non_streaming_count_action(Arc::new(AtomicUsize::new(0))),
            "B",
            non_streaming_count_action(Arc::new(AtomicUsize::new(0))),
            vec![Transition::new(
                "A",
                "B",
                Condition::expr("missing_flag == true"),
            )],
        )
        .map(|scenario| scenario.with_hooks(hooks))
        .and_then(ApplicationScenario::build),
    }
    .expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    let error = match iterate.next_step().await {
        Ok(_) => panic!("guard failure should surface"),
        Err(error) => error,
    };
    match failure {
        DeferredNextStepGuardFailure::InvalidPriorStep => {
            assert!(matches!(
                error,
                ApplicationError::InvalidPriorStepType { .. }
            ));
        }
        DeferredNextStepGuardFailure::UnknownPriorStep => {
            assert!(matches!(
                error,
                ApplicationError::Graph(rurr_core::graph::GraphError::ActionNotFound {
                    action_name,
                    ..
                }) if action_name == "missing"
            ));
        }
        DeferredNextStepGuardFailure::ConditionError => {
            assert!(matches!(
                error,
                ApplicationError::Graph(GraphError::ConditionEvaluation { .. })
            ));
        }
    }

    if matches!(mode, StreamMode::Sync) {
        assert!(iterate
            .next_step()
            .await
            .expect("failed sync stream iterate session should be terminal")
            .is_none());
        assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
        assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    }
    drop(iterate);
    assert_execute_only_counts(&counts, mode);
    assert_eq!(app.state(), &initial_state);
}

async fn assert_next_step_pre_start_stream_failure(mode: StreamMode) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let counting_hook = Arc::new(LifecycleHookRecorder::counting(Arc::clone(&counts)));
    let sync_counting_hook: Arc<dyn SyncLifecycleAdapter> = counting_hook.clone();
    let async_counting_hook: Arc<dyn AsyncLifecycleAdapter> = counting_hook;
    let hooks = match mode {
        StreamMode::Sync => {
            let failing_pre_start_hook: Arc<dyn SyncLifecycleAdapter> =
                Arc::new(LifecycleFailureHook::sync_pre_start_stream());
            LifecycleAdapterSet::new(
                vec![sync_counting_hook, failing_pre_start_hook],
                vec![async_counting_hook],
            )
        }
        StreamMode::Async => {
            let failing_pre_start_hook: Arc<dyn AsyncLifecycleAdapter> =
                Arc::new(LifecycleFailureHook::async_pre_start_stream());
            LifecycleAdapterSet::new(
                vec![sync_counting_hook],
                vec![async_counting_hook, failing_pre_start_hook],
            )
        }
    };

    let action = streaming_count_action(Arc::new(AtomicUsize::new(0)), 2, None);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");

    let mut iterate = mode.stream_iterate(&mut app, ExecutionOptions::new()).await;
    let error = match iterate.next_step().await {
        Ok(_) => panic!("pre_start_stream hook failure should surface"),
        Err(error) => error,
    };
    assert!(matches!(
        error,
        ApplicationError::LifecycleHookFailed {
            phase: "pre_start_stream",
            message
        } if message.contains(match mode {
            StreamMode::Sync => SYNC_PRE_START_STREAM_FAILURE_MARKER,
            StreamMode::Async => ASYNC_PRE_START_STREAM_FAILURE_MARKER,
        })
    ));

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(
        counts.async_pre_execute_call.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(
        counts.async_post_execute_call.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );

    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_end_stream.load(Ordering::SeqCst), 0);
    assert_eq!(
        counts.async_pre_run_step.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(
        counts.async_post_run_step.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(
        counts.async_pre_start_stream.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(counts.async_post_end_stream.load(Ordering::SeqCst), 0);

    if matches!(mode, StreamMode::Sync) {
        assert!(iterate
            .next_step()
            .await
            .expect("failed sync stream iterate session should be terminal")
            .is_none());
    }
    drop(iterate);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

async fn assert_result_target_step_pre_start_stream_failure(mode: StreamMode) {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let counting_hook = Arc::new(LifecycleHookRecorder::counting(Arc::clone(&counts)));
    let sync_counting_hook: Arc<dyn SyncLifecycleAdapter> = counting_hook.clone();
    let async_counting_hook: Arc<dyn AsyncLifecycleAdapter> = counting_hook;
    let hooks = match mode {
        StreamMode::Sync => {
            let failing_pre_start_hook: Arc<dyn SyncLifecycleAdapter> =
                Arc::new(LifecycleFailureHook::sync_pre_start_stream());
            LifecycleAdapterSet::new(
                vec![sync_counting_hook, failing_pre_start_hook],
                vec![async_counting_hook],
            )
        }
        StreamMode::Async => {
            let failing_pre_start_hook: Arc<dyn AsyncLifecycleAdapter> =
                Arc::new(LifecycleFailureHook::async_pre_start_stream());
            LifecycleAdapterSet::new(
                vec![sync_counting_hook],
                vec![async_counting_hook, failing_pre_start_hook],
            )
        }
    };

    let action = streaming_count_action(Arc::new(AtomicUsize::new(0)), 2, None);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");
    let halt_after = vec!["stream".to_string()];
    let (_action, mut stream_result) = mode
        .stream_result(&mut app, ExecutionOptions::new().halt_after(halt_after))
        .await
        .expect("stream_result should create");

    let error = stream_result
        .next_item()
        .await
        .expect_err("pre_start_stream hook failure should surface");
    assert!(matches!(
        error,
        ApplicationError::LifecycleHookFailed {
            phase: "pre_start_stream",
            message
        } if message.contains(match mode {
            StreamMode::Sync => SYNC_PRE_START_STREAM_FAILURE_MARKER,
            StreamMode::Async => ASYNC_PRE_START_STREAM_FAILURE_MARKER,
        })
    ));

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(
        counts.async_pre_execute_call.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(
        counts.async_post_execute_call.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );

    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_end_stream.load(Ordering::SeqCst), 0);
    assert_eq!(
        counts.async_pre_run_step.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(
        counts.async_post_run_step.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(
        counts.async_pre_start_stream.load(Ordering::SeqCst),
        usize::from(matches!(mode, StreamMode::Async))
    );
    assert_eq!(counts.async_post_end_stream.load(Ordering::SeqCst), 0);

    drop(stream_result);
    if matches!(mode, StreamMode::Sync) {
        assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    }
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

sync_stream_cases! {
    stream_iterate_next_step_invalid_prior_step_runs_sync_post_execute_call_once =>
        assert_deferred_next_step_guard_failure(StreamMode::Sync, DeferredNextStepGuardFailure::InvalidPriorStep),
    stream_iterate_next_step_unknown_prior_step_runs_sync_post_execute_call_once =>
        assert_deferred_next_step_guard_failure(StreamMode::Sync, DeferredNextStepGuardFailure::UnknownPriorStep),
    stream_iterate_next_step_condition_error_runs_sync_post_execute_call_once =>
        assert_deferred_next_step_guard_failure(StreamMode::Sync, DeferredNextStepGuardFailure::ConditionError)
}

#[tokio::test]
async fn stream_iterate_next_step_inside_tokio_runtime_runs_sync_post_run_step_once() {
    let counts = Arc::new(StreamAbortHookCounts::default());
    let hook = Arc::new(LifecycleHookRecorder::counting(Arc::clone(&counts)));
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = hook.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = hook;
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook]);

    let action = streaming_count_action(Arc::new(AtomicUsize::new(0)), 2, None);
    let mut app = build_streaming_app_with_hooks(action, hooks).expect("app should build");

    let mut iterate = app.stream_iterate();
    let (_executed, mut handle) = iterate
        .next_step()
        .expect("next_step should construct handle")
        .expect("step should exist");
    let item = handle
        .next_item()
        .expect("stream source should poll successfully")
        .expect("first stream item should exist");

    assert_eq!(counts.sync_pre_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_pre_execute_call.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_post_execute_call.load(Ordering::SeqCst), 0);

    assert_eq!(counts.sync_pre_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 0);
    assert_eq!(counts.sync_pre_start_stream.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_end_stream.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_pre_run_step.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_post_run_step.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_pre_start_stream.load(Ordering::SeqCst), 0);
    assert_eq!(counts.async_post_end_stream.load(Ordering::SeqCst), 0);
    assert_eq!(item.get("count"), Some(&json!(1)));

    drop(handle);
    drop(iterate);
    assert_eq!(counts.sync_post_execute_call.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_run_step.load(Ordering::SeqCst), 1);
    assert_eq!(counts.sync_post_end_stream.load(Ordering::SeqCst), 1);
    assert_eq!(app.state().get("count").cloned(), Some(json!(0)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
}

sync_stream_cases! {
    stream_iterate_next_step_pre_start_stream_failure_runs_sync_post_run_step_once =>
        assert_next_step_pre_start_stream_failure(StreamMode::Sync),
    stream_result_target_step_pre_start_stream_failure_runs_sync_post_run_step_once =>
        assert_result_target_step_pre_start_stream_failure(StreamMode::Sync)
}
async_stream_cases! {
    astream_iterate_next_step_pre_start_stream_failure_runs_async_post_run_step_once =>
        assert_next_step_pre_start_stream_failure(StreamMode::Async),
    astream_result_target_step_pre_start_stream_failure_runs_async_post_run_step_once =>
        assert_result_target_step_pre_start_stream_failure(StreamMode::Async),
    astream_iterate_next_step_invalid_prior_step_runs_async_post_execute_call_once =>
        assert_deferred_next_step_guard_failure(StreamMode::Async, DeferredNextStepGuardFailure::InvalidPriorStep),
    astream_iterate_next_step_unknown_prior_step_runs_async_post_execute_call_once =>
        assert_deferred_next_step_guard_failure(StreamMode::Async, DeferredNextStepGuardFailure::UnknownPriorStep),
    astream_iterate_next_step_condition_error_runs_async_post_execute_call_once =>
        assert_deferred_next_step_guard_failure(StreamMode::Async, DeferredNextStepGuardFailure::ConditionError)
}
