use super::{progress::StreamPhase, progress::TerminalState, StreamProgress};
use crate::action::ResultAction;
use crate::application::{Application, ApplicationBuilder};

fn build_test_app() -> Application {
    ApplicationBuilder::new()
        .with_actions(vec![("result", ResultAction::new(["count"]))])
        .expect("action should register")
        .with_transitions(Vec::new())
        .expect("transitions should register")
        .with_entrypoint("result")
        .expect("entrypoint should register")
        .build()
        .expect("app should build")
}

#[test]
fn rollback_to_current_state_caches_current_state_and_marks_done() {
    let app = build_test_app();
    let mut progress = StreamProgress::new(None);
    progress.mark_streaming_started();

    progress.finish_from_current_state(Some(&app));

    assert!(progress.is_done());
    assert_eq!(
        progress,
        StreamProgress {
            phase: StreamPhase::Done,
            terminal: TerminalState::Ready((None, app.state().clone())),
        }
    );
}
