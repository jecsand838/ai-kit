use super::support::{
    build_counter_action, build_registered_app_from_definition, map_from_pairs, state_from_pairs,
    sync_persistence_spec,
};
use crate::manifest::BurrOracleScenario;
use rurr_core::action::Condition;
use rurr_core::application::ApplicationBuilder;
use rurr_core::graph::Transition;
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::tracking::LocalTrackingClient;
use rurr_persistence::{
    ApplicationPersistenceSpec, BaseStateLoader, BaseStatePersister, BaseStateSaver,
    StatePersisterSpec,
};
use rurr_sqlite::SqlitePersister;
use serde_json::{json, Value};
use std::error::Error;
use std::path::Path;
use std::sync::Arc;

pub(super) fn run_07_sqlite_persistence_resume(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
    scenario_storage: &Path,
) -> Result<Vec<Value>, Box<dyn Error>> {
    let counter = build_counter_action()?;
    let db_path = scenario_storage.join("oracle_state.db");
    let sqlite = Arc::new(SqlitePersister::new(
        rurr_sqlite::SqlitePersisterConfig::new(&db_path, "oracle_sqlite_resume"),
    )?);
    sqlite.initialize()?;

    let sqlite_loader: Arc<dyn BaseStateLoader> = sqlite.clone();
    let sqlite_persister: Arc<dyn BaseStatePersister> = sqlite.clone();

    let mut first = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(0))]))?
            .with_actions(vec![("counter", counter.clone())])?
            .with_transitions(vec![Transition::new(
                "counter",
                "counter",
                Condition::expr("count < 3"),
            )])?
            .with_entrypoint("counter")?
            .with_persistence_spec(
                ApplicationPersistenceSpec::new()
                    .with_persister(StatePersisterSpec::sync(sqlite_persister.clone())),
            )?,
        definition,
        tracker,
        hooks,
    )?;

    let halt_after_counter = vec!["counter".to_string()];
    first.run_with_options(
        rurr_core::ExecutionOptions::new().halt_after(halt_after_counter.clone()),
    )?;

    let mut resumed = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_actions(vec![("counter", counter)])?
            .with_transitions(vec![Transition::new(
                "counter",
                "counter",
                Condition::expr("count < 3"),
            )])?
            .with_persistence_spec(sync_persistence_spec(
                sqlite_loader,
                sqlite_persister,
                map_from_pairs([("count", json!(0))]),
                "counter",
            ))?,
        definition,
        tracker,
        hooks,
    )?;

    resumed.run_with_options(rurr_core::ExecutionOptions::new().halt_after(halt_after_counter))?;

    let loaded = sqlite.load(
        Some(&definition.partition_key),
        Some(&definition.app_id),
        None,
    )?;

    let mut payloads = Vec::new();
    if let Some(data) = loaded {
        payloads.push(serde_json::to_value(data)?);
    }

    Ok(payloads)
}
