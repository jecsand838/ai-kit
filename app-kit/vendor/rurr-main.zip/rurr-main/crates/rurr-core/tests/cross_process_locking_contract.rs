use rurr_core::tracking::jsonl::append_jsonl_locked;
use serde_json::json;
use serde_json::Value;
use std::env;
use std::fs;
use std::path::Path;
use std::path::PathBuf;
use std::process::Child;
use std::process::Command;

const CHILD_TEST: &str = "cross_process_jsonl_append_child";
const PATH_ENV: &str = "RURR_APPEND_JSONL_PATH";
const COUNT_ENV: &str = "RURR_APPEND_JSONL_COUNT";
const WRITER_ENV: &str = "RURR_APPEND_JSONL_WRITER";

fn parse_jsonl(path: &Path) -> Vec<Value> {
    fs::read_to_string(path)
        .expect("jsonl file should be readable")
        .lines()
        .filter(|line| !line.trim().is_empty())
        .map(|line| serde_json::from_str::<Value>(line).expect("jsonl line should parse"))
        .collect()
}

fn spawn_writer(log_path: &Path, line_count: usize, writer_id: &str) -> Child {
    let current_exe = env::current_exe().expect("current test executable should resolve");
    Command::new(current_exe)
        .args(["--exact", CHILD_TEST, "--ignored", "--quiet"])
        .env(PATH_ENV, log_path)
        .env(COUNT_ENV, line_count.to_string())
        .env(WRITER_ENV, writer_id)
        .spawn()
        .unwrap_or_else(|error| panic!("{writer_id} process should start: {error}"))
}

#[test]
fn cross_process_jsonl_append_is_atomic_and_complete() {
    let tempdir = tempfile::tempdir().expect("tempdir should be created");
    let log_path = tempdir.path().join("shared.jsonl");
    let line_count_per_writer = 250usize;
    let mut writer_a = spawn_writer(&log_path, line_count_per_writer, "writer_a");
    let mut writer_b = spawn_writer(&log_path, line_count_per_writer, "writer_b");

    let status_a = writer_a.wait().expect("writer A should terminate");
    let status_b = writer_b.wait().expect("writer B should terminate");
    assert!(status_a.success(), "writer A failed: {status_a:?}");
    assert!(status_b.success(), "writer B failed: {status_b:?}");

    let lines = parse_jsonl(&log_path);
    assert_eq!(
        lines.len(),
        line_count_per_writer * 2,
        "all writes from both processes should be present"
    );
    for line in lines {
        assert!(line.get("writer").and_then(Value::as_str).is_some());
        assert!(line.get("sequence").and_then(Value::as_u64).is_some());
    }
}

#[test]
#[ignore = "spawned by cross_process_jsonl_append_is_atomic_and_complete"]
fn cross_process_jsonl_append_child() {
    let path = env::var_os(PATH_ENV)
        .map(PathBuf::from)
        .expect("parent test should pass JSONL path");
    let count = env::var(COUNT_ENV)
        .expect("parent test should pass line count")
        .parse::<usize>()
        .expect("line count should parse");
    let writer = env::var(WRITER_ENV).expect("parent test should pass writer id");

    for sequence in 0..count {
        let line = json!({
            "writer": writer.as_str(),
            "sequence": sequence,
        });
        append_jsonl_locked(&path, &line).expect("child writer should append JSONL");
    }
}
