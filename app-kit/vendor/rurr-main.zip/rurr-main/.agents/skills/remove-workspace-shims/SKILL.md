---
name: remove-workspace-shims
description: "Use when turning a prior `audit-workspace-for-shims` result or equivalent approved shim-audit findings into a decision-complete delete-first Rurr cleanup plan and implementation pass that removes production shims, adds strict proof tests, aligns unit coverage to live behavior, and runs final gates without introducing new synthetic behavior. Do not use without a prior approved shim audit."
---

# Remove Workspace Shims

Use this skill when the user wants approved shim-audit findings turned into a concrete delete-first plan and an implementation pass that removes the invented behavior without replacing it with new shims.

## Quick start

Load, in order:

- the approved `audit-workspace-for-shims` output or equivalent approved shim findings first
- `README.md`
- `docs/00_overview.md`
- `docs/03_test_plan.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- the relevant live gates, production code, tests, and Burr source

Load these companion skills:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-testing`
- `$use-rust-best-practices-dependencies-platforms`
- `$rurr-burr-source-parity-walk`
- `$rurr-gate-closeout`

Add the relevant Rurr guardrail skills when the touched behavior needs them:

- `$rurr-streaming-transaction-safety`
- `$rurr-anchored-filesystem-hardening`
- `$rurr-persistence-adapter-parity`
- `$rurr-proc-macro-ui-contract`
- `$rurr-structural-completion-audit`

## When to use

Use it when the task:

- asks to plan and remove previously audited production shims end to end
- asks to delete synthetic production behavior before forward-fixing the real implementation
- asks to add strict proof tests for removed shim behavior and align unit tests to live behavior
- needs final gates after a shim-removal pass

Do not use it from a vague cleanup brief or without a prior approved shim audit.

## Planning phase

1. Translate every approved shim finding into the affected behavior, current synthetic path, required strict proof, likely files, and gate risk.
2. Group the work by subsystem or behavior, not by finding order or file inventory.
3. Specify an immediate delete-first pre-pass that removes every approved shim path before any forward fix is attempted.
4. Require an explicit failing strict proof test for every removed shim, preferring strict live or provider-backed proofs before narrower local tests.
5. Name the Rurr guardrail skills and Rust companion skills required for each finding group.
6. Define the narrow gates for each group plus the required final completion gates.
7. Reject new hacks, shims, synthetic behavior, warning suppression, dead test-only logic, and self-invented cleanup targets that were not approved by the prior audit.
8. Emit a decision-complete `<proposed_plan>` with `Summary`, `Findings Covered`, `Key Changes`, `Tests/Gates`, and `Assumptions/Blockers`.

## Implementation phase

1. Load the approved shim audit and approved plan before editing.
2. Delete the approved shim or synthetic path first in the current slice so the failing proof becomes explicit.
3. Add or enable the failing strict proof test first when feasible, starting with the strict live or provider-backed source of truth.
4. Implement only the real production behavior supported by Burr, live-provider evidence, and current Rurr guardrails.
5. Refactor conflicting unit or local contract tests so they match the strict proof instead of the removed shim.
6. Implement one finding group at a time and keep the fix surface minimal.
7. Run narrow gates after each group before broadening to the next one.
8. Use `$rurr-gate-closeout` for manifest handling, final gate selection, and truthful final reporting.
9. Run `./scripts/check.sh` and `./scripts/check_live.sh` when the touched behavior or proof lane requires them.

## Plan output contract

When producing a plan, wrap the final answer in `<proposed_plan>` and include exactly these sections:

- `Summary`
- `Findings Covered`
- `Key Changes`
- `Tests/Gates`
- `Assumptions/Blockers`

`Findings Covered` must account for every approved shim finding or explicitly mark duplicates. `Tests/Gates` must name the delete-first red tests, narrow gates, manifest handling, and final completion gates.

## Default rules

- This skill is designed for Plan mode use, but it can also drive implementation once an approved shim-audit result exists.
- Do not infer cleanup targets from a generic brief; require the prior approved shim audit.
- Delete the shim path before adding a replacement behavior so the red stage stays explicit.
- Prefer strict live or provider-backed proof over local non-live approximations when the finding concerns invented external behavior.
- `Unsupported` and `NotYetImplemented` are acceptable only when they replace invented behavior rather than mask it.
- Do not add new compatibility shims, deprecated aliases, or dual paths unless Burr parity explicitly requires them.

## Do not use this skill alone when

- the user still needs the shim audit itself: also use `$audit-workspace-for-shims`
- the user wants a more general delete-first cleanup plan that is not limited to approved shim findings: also use `$rurr-delete-first-refactor-plan`
- the task is really a concrete `/review` bug-fix workflow rather than an audit-driven shim removal: use `$rurr-resolve-review-findings` instead
- the task is only final verification after changes already exist: also use `$rurr-gate-closeout`
