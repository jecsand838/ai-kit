//! Workspace-local implementations of the published oracle scenarios.
//!
//! Each helper mirrors one manifest entry and writes tracking artifacts through
//! the same local runtime and tracking layers used by the rest of the
//! workspace. [`run_case`](crate::cases::run_case) is the dispatch point shared
//! by tests and the oracle runner.

mod basic;
mod parallelism;
mod persistence;
mod streaming;
mod support;

use crate::manifest::{BurrOracleScenario, BurrOracleScenarioId};
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::tracking::LocalTrackingClient;
use serde_json::Value;
use std::error::Error;
use std::path::Path;
use std::sync::Arc;

/// Runs the workspace-local implementation for a specific oracle scenario.
pub fn run_case(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
    scenario_storage: &Path,
) -> Result<Vec<Value>, Box<dyn Error>> {
    match definition.id {
        BurrOracleScenarioId::CreateOnly => {
            basic::run_00_create_only(definition, tracker, hooks)?;
            Ok(Vec::new())
        }
        BurrOracleScenarioId::CounterBasic => {
            basic::run_01_counter_basic(definition, tracker, hooks)?;
            Ok(Vec::new())
        }
        BurrOracleScenarioId::BranchingExpr => {
            basic::run_02_branching_expr(definition, tracker, hooks)?;
            Ok(Vec::new())
        }
        BurrOracleScenarioId::SpansAndAttributes => {
            basic::run_03_spans_and_attributes(definition, tracker, hooks)?;
            Ok(Vec::new())
        }
        BurrOracleScenarioId::StreamingAction => {
            streaming::run_04_streaming_action(definition, tracker, hooks)?;
            Ok(Vec::new())
        }
        BurrOracleScenarioId::ConditionIdentityExpr => {
            basic::run_05_condition_identity_expr(definition, tracker, hooks)?;
            Ok(Vec::new())
        }
        BurrOracleScenarioId::ForkAndSpawnChildren => {
            parallelism::run_06_fork_and_spawn_children(definition, tracker, hooks)?;
            Ok(Vec::new())
        }
        BurrOracleScenarioId::SqlitePersistenceResume => {
            persistence::run_07_sqlite_persistence_resume(
                definition,
                tracker,
                hooks,
                scenario_storage,
            )
        }
    }
}
