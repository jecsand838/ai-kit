use rurr_core::action::{FunctionActionBuilder, LocalAction};
use rurr_core::graph::{GraphAction, Transition};
use rurr_core::parallelism::RunnableGraph;
use rurr_testkit::application_fixture::map_from_pairs;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

pub(crate) fn runnable_graph_from_action<A: LocalAction + Send + Sync + 'static>(
    name: &str,
    action: A,
) -> RunnableGraph {
    let named_action = action
        .with_name(name)
        .expect("action naming should succeed");
    let graph_action = GraphAction::new(named_action).expect("graph action should build");
    RunnableGraph::new(
        vec![graph_action],
        Vec::<Transition>::new(),
        Some(name.to_string()),
    )
}

pub(crate) fn constant_output_sync_child_graph(name: &str, output: i64) -> RunnableGraph {
    runnable_graph_from_action(
        name,
        FunctionActionBuilder::new()
            .writes(["output"])
            .with_source_code(format!(
                "fn {name}(_state, _ctx) -> output {{ output: {output} }}"
            ))
            .build_sync(move |_state, _ctx| map_from_pairs([("output", json!(output))]))
            .expect("action should build"),
    )
}

pub(crate) fn constant_output_async_child_graph(name: &str, output: i64) -> RunnableGraph {
    runnable_graph_from_action(
        name,
        FunctionActionBuilder::new()
            .writes(["output"])
            .with_source_code(format!(
                "async fn {name}(_state, _ctx) -> output {{ output: {output} }}"
            ))
            .build_async(
                move |_state, _ctx| async move { map_from_pairs([("output", json!(output))]) },
            )
            .expect("action should build"),
    )
}

pub(crate) fn two_constant_output_sync_child_graphs(
    first: (&str, i64),
    second: (&str, i64),
) -> Vec<RunnableGraph> {
    vec![
        constant_output_sync_child_graph(first.0, first.1),
        constant_output_sync_child_graph(second.0, second.1),
    ]
}

pub(crate) fn three_constant_output_sync_child_graphs(
    first: (&str, i64),
    second: (&str, i64),
    third: (&str, i64),
) -> Vec<RunnableGraph> {
    vec![
        constant_output_sync_child_graph(first.0, first.1),
        constant_output_sync_child_graph(second.0, second.1),
        constant_output_sync_child_graph(third.0, third.1),
    ]
}

pub(crate) fn sync_counter_child_graph(counter: Arc<AtomicUsize>, name: &str) -> RunnableGraph {
    runnable_graph_from_action(
        name,
        FunctionActionBuilder::new()
            .writes(["child_ran"])
            .with_source_code(format!(
                "fn {name}(_state, _ctx) -> child_ran {{ counter.fetch_add(1, Ordering::SeqCst); child_ran: true }}"
            ))
            .build_sync(move |_state, _ctx| {
                counter.fetch_add(1, Ordering::SeqCst);
                map_from_pairs([("child_ran", json!(true))])
            })
            .expect("action should build"),
    )
}

pub(crate) fn async_counter_child_graph(counter: Arc<AtomicUsize>, name: &str) -> RunnableGraph {
    runnable_graph_from_action(
        name,
        FunctionActionBuilder::new()
            .writes(["child_ran"])
            .with_source_code(format!(
                "async fn {name}(_state, _ctx) -> child_ran {{ counter.fetch_add(1, Ordering::SeqCst); child_ran: true }}"
            ))
            .build_async(move |_state, _ctx| {
                let counter = counter.clone();
                async move {
                    counter.fetch_add(1, Ordering::SeqCst);
                    map_from_pairs([("child_ran", json!(true))])
                }
            })
            .expect("action should build"),
    )
}

pub(crate) fn sync_resume_probe_graph(default_name: &str, resume_name: &str) -> RunnableGraph {
    let default_action = FunctionActionBuilder::new()
        .writes(["output"])
        .with_source_code(format!(
            "fn {default_name}(_state, _ctx) -> output {{ output: -1 }}"
        ))
        .build_sync(|_state, _ctx| map_from_pairs([("output", json!(-1))]))
        .expect("default action should build")
        .with_name(default_name)
        .expect("default action naming should succeed");
    let resume_action = FunctionActionBuilder::new()
        .writes(["output"])
        .with_source_code(format!(
            "fn {resume_name}(state, _ctx) -> output {{ output: state.seed + 1 }}"
        ))
        .build_sync(|state, _ctx| {
            let seed = state
                .get("seed")
                .and_then(Value::as_i64)
                .unwrap_or_default();
            map_from_pairs([("output", json!(seed + 1))])
        })
        .expect("resume action should build")
        .with_name(resume_name)
        .expect("resume action naming should succeed");

    RunnableGraph::new(
        vec![
            GraphAction::new(default_action).expect("default graph action should build"),
            GraphAction::new(resume_action).expect("resume graph action should build"),
        ],
        Vec::<Transition>::new(),
        Some(default_name.to_string()),
    )
}

pub(crate) fn async_resume_probe_graph(default_name: &str, resume_name: &str) -> RunnableGraph {
    let default_action = FunctionActionBuilder::new()
        .writes(["output"])
        .with_source_code(format!(
            "async fn {default_name}(_state, _ctx) -> output {{ output: -1 }}"
        ))
        .build_async(|_state, _ctx| async move { map_from_pairs([("output", json!(-1))]) })
        .expect("default action should build")
        .with_name(default_name)
        .expect("default action naming should succeed");
    let resume_action = FunctionActionBuilder::new()
        .writes(["output"])
        .with_source_code(format!(
            "async fn {resume_name}(state, _ctx) -> output {{ output: state.seed + 1 }}"
        ))
        .build_async(|state, _ctx| async move {
            let seed = state
                .get("seed")
                .and_then(Value::as_i64)
                .unwrap_or_default();
            map_from_pairs([("output", json!(seed + 1))])
        })
        .expect("resume action should build")
        .with_name(resume_name)
        .expect("resume action naming should succeed");

    RunnableGraph::new(
        vec![
            GraphAction::new(default_action).expect("default graph action should build"),
            GraphAction::new(resume_action).expect("resume graph action should build"),
        ],
        Vec::<Transition>::new(),
        Some(default_name.to_string()),
    )
}

pub(crate) fn stable_child_app_id(parent_app_id: &str, task_key: &str) -> String {
    let digest = Sha256::digest(format!("{parent_app_id}:{task_key}").as_bytes());
    format!("{digest:x}")
}

pub(crate) fn namespaced_child_app_id(
    parent_app_id: &str,
    action_name: &str,
    task_key: &str,
) -> String {
    let digest = Sha256::digest(format!("{parent_app_id}:{action_name}:{task_key}").as_bytes());
    format!("{digest:x}")
}
