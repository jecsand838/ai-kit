use super::common::{LifecycleHookLane, LifecycleHookPhase};
use async_trait::async_trait;
use rurr_core::lifecycle::LifecycleError;
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, ExecuteCallContext, PostStepContext, PreStepContext, StreamContext,
    SyncLifecycleAdapter,
};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

#[derive(Debug, Default)]
pub(crate) struct PendingHookCounts {
    pub(crate) sync_pre_run_step: AtomicUsize,
    pub(crate) async_pre_run_step: AtomicUsize,
}

#[derive(Debug)]
pub(crate) struct YieldingPreRunStepHook {
    counts: Arc<PendingHookCounts>,
    yielded: AtomicBool,
}

impl YieldingPreRunStepHook {
    pub(crate) fn new(counts: Arc<PendingHookCounts>) -> Self {
        Self {
            counts,
            yielded: AtomicBool::new(false),
        }
    }
}

impl SyncLifecycleAdapter for YieldingPreRunStepHook {
    fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        self.counts.sync_pre_run_step.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for YieldingPreRunStepHook {
    async fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        self.counts
            .async_pre_run_step
            .fetch_add(1, Ordering::SeqCst);
        if !self.yielded.swap(true, Ordering::SeqCst) {
            tokio::task::yield_now().await;
        }
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct StreamAbortHookCounts {
    pub(crate) sync_pre_execute_call: AtomicUsize,
    pub(crate) sync_post_execute_call: AtomicUsize,
    pub(crate) sync_pre_run_step: AtomicUsize,
    pub(crate) sync_post_run_step: AtomicUsize,
    pub(crate) sync_pre_start_stream: AtomicUsize,
    pub(crate) sync_post_end_stream: AtomicUsize,
    pub(crate) async_pre_execute_call: AtomicUsize,
    pub(crate) async_post_execute_call: AtomicUsize,
    pub(crate) async_pre_run_step: AtomicUsize,
    pub(crate) async_post_run_step: AtomicUsize,
    pub(crate) async_pre_start_stream: AtomicUsize,
    pub(crate) async_post_end_stream: AtomicUsize,
}

#[derive(Debug, Default)]
pub(crate) struct PostStepExceptionRecorder {
    sync_exceptions: Mutex<Vec<Option<String>>>,
    async_exceptions: Mutex<Vec<Option<String>>>,
}

impl PostStepExceptionRecorder {
    pub(crate) fn sync_exceptions(&self) -> Vec<Option<String>> {
        self.sync_exceptions
            .lock()
            .expect("sync_exceptions lock should not be poisoned")
            .clone()
    }

    pub(crate) fn async_exceptions(&self) -> Vec<Option<String>> {
        self.async_exceptions
            .lock()
            .expect("async_exceptions lock should not be poisoned")
            .clone()
    }
}

#[derive(Debug)]
pub(crate) struct LifecycleHookRecorder {
    counts: Option<Arc<StreamAbortHookCounts>>,
    exceptions: Option<Arc<PostStepExceptionRecorder>>,
}

impl LifecycleHookRecorder {
    pub(crate) fn counting(counts: Arc<StreamAbortHookCounts>) -> Self {
        Self {
            counts: Some(counts),
            exceptions: None,
        }
    }

    pub(crate) fn exceptions(exceptions: Arc<PostStepExceptionRecorder>) -> Self {
        Self {
            counts: None,
            exceptions: Some(exceptions),
        }
    }

    fn record_count(&self, lane: LifecycleHookLane, phase: LifecycleHookPhase) {
        let Some(counts) = self.counts.as_ref() else {
            return;
        };

        let counter = match (lane, phase) {
            (LifecycleHookLane::Sync, LifecycleHookPhase::PostExecuteCall) => {
                &counts.sync_post_execute_call
            }
            (LifecycleHookLane::Sync, LifecycleHookPhase::PostRunStep) => {
                &counts.sync_post_run_step
            }
            (LifecycleHookLane::Sync, LifecycleHookPhase::PostEndStream) => {
                &counts.sync_post_end_stream
            }
            (LifecycleHookLane::Sync, LifecycleHookPhase::PreStartStream) => {
                &counts.sync_pre_start_stream
            }
            (LifecycleHookLane::Async, LifecycleHookPhase::PostExecuteCall) => {
                &counts.async_post_execute_call
            }
            (LifecycleHookLane::Async, LifecycleHookPhase::PostRunStep) => {
                &counts.async_post_run_step
            }
            (LifecycleHookLane::Async, LifecycleHookPhase::PostEndStream) => {
                &counts.async_post_end_stream
            }
            (LifecycleHookLane::Async, LifecycleHookPhase::PreStartStream) => {
                &counts.async_pre_start_stream
            }
            (LifecycleHookLane::Sync, LifecycleHookPhase::PostStreamItem)
            | (LifecycleHookLane::Async, LifecycleHookPhase::PostStreamItem) => return,
        };
        counter.fetch_add(1, Ordering::SeqCst);
    }

    fn record_pre_execute_call(&self, lane: LifecycleHookLane) {
        let Some(counts) = self.counts.as_ref() else {
            return;
        };

        let counter = match lane {
            LifecycleHookLane::Sync => &counts.sync_pre_execute_call,
            LifecycleHookLane::Async => &counts.async_pre_execute_call,
        };
        counter.fetch_add(1, Ordering::SeqCst);
    }

    fn record_pre_run_step(&self, lane: LifecycleHookLane) {
        let Some(counts) = self.counts.as_ref() else {
            return;
        };

        let counter = match lane {
            LifecycleHookLane::Sync => &counts.sync_pre_run_step,
            LifecycleHookLane::Async => &counts.async_pre_run_step,
        };
        counter.fetch_add(1, Ordering::SeqCst);
    }

    fn record_exception(&self, lane: LifecycleHookLane, context: &PostStepContext) {
        let Some(exceptions) = self.exceptions.as_ref() else {
            return;
        };

        let entries = match lane {
            LifecycleHookLane::Sync => &exceptions.sync_exceptions,
            LifecycleHookLane::Async => &exceptions.async_exceptions,
        };
        entries
            .lock()
            .expect("exception recorder lock should not be poisoned")
            .push(context.exception().map(str::to_string));
    }
}

impl SyncLifecycleAdapter for LifecycleHookRecorder {
    fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.record_pre_execute_call(LifecycleHookLane::Sync);
        Ok(())
    }

    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.record_count(LifecycleHookLane::Sync, LifecycleHookPhase::PostExecuteCall);
        Ok(())
    }

    fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        self.record_pre_run_step(LifecycleHookLane::Sync);
        Ok(())
    }

    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.record_count(LifecycleHookLane::Sync, LifecycleHookPhase::PostRunStep);
        self.record_exception(LifecycleHookLane::Sync, context);
        Ok(())
    }

    fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.record_count(LifecycleHookLane::Sync, LifecycleHookPhase::PreStartStream);
        Ok(())
    }

    fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.record_count(LifecycleHookLane::Sync, LifecycleHookPhase::PostEndStream);
        Ok(())
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for LifecycleHookRecorder {
    async fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.record_pre_execute_call(LifecycleHookLane::Async);
        Ok(())
    }

    async fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.record_count(
            LifecycleHookLane::Async,
            LifecycleHookPhase::PostExecuteCall,
        );
        Ok(())
    }

    async fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        self.record_pre_run_step(LifecycleHookLane::Async);
        Ok(())
    }

    async fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.record_count(LifecycleHookLane::Async, LifecycleHookPhase::PostRunStep);
        self.record_exception(LifecycleHookLane::Async, context);
        Ok(())
    }

    async fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.record_count(LifecycleHookLane::Async, LifecycleHookPhase::PreStartStream);
        Ok(())
    }

    async fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.record_count(LifecycleHookLane::Async, LifecycleHookPhase::PostEndStream);
        Ok(())
    }
}
