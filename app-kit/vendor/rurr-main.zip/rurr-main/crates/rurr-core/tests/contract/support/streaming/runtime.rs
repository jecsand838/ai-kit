use rurr_core::action::StreamItem;
use rurr_core::application::{
    AStreamIterate, AStreamResult, AStreamStepHandle, Application, ApplicationError,
    ExecutionOptions, StreamIterate, StreamResult, StreamStepHandle,
};
use rurr_core::graph::GraphAction;
use rurr_core::state::State;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum StreamMode {
    Sync,
    Async,
}

impl StreamMode {
    pub(crate) const fn iterate_event_name(self) -> &'static str {
        match self {
            Self::Sync => "stream_iterate",
            Self::Async => "astream_iterate",
        }
    }

    pub(crate) const fn next_panic_scope(self) -> &'static str {
        match self {
            Self::Sync => "streaming.sync.next",
            Self::Async => "streaming.async.next",
        }
    }

    pub(crate) async fn stream_result<'a>(
        self,
        app: &'a mut Application,
        options: ExecutionOptions,
    ) -> Result<(GraphAction, ModeStreamResult<'a>), ApplicationError> {
        match self {
            Self::Sync => app
                .stream_result_with_options(options)
                .map(|(action, handle)| (action, ModeStreamResult::Sync(handle))),
            Self::Async => app
                .astream_result_with_options(options)
                .await
                .map(|(action, handle)| (action, ModeStreamResult::Async(handle))),
        }
    }

    pub(crate) async fn stream_iterate<'a>(
        self,
        app: &'a mut Application,
        options: ExecutionOptions,
    ) -> ModeIterate<'a> {
        match self {
            Self::Sync => ModeIterate::Sync(app.stream_iterate_with_options(options)),
            Self::Async => ModeIterate::Async(app.astream_iterate_with_options(options).await),
        }
    }
}

pub(crate) enum ModeStreamResult<'a> {
    Sync(StreamResult<'a>),
    Async(AStreamResult<'a>),
}

impl ModeStreamResult<'_> {
    pub(crate) async fn next_item(&mut self) -> Result<Option<StreamItem>, ApplicationError> {
        match self {
            Self::Sync(handle) => handle.next_item(),
            Self::Async(handle) => handle.next_item().await,
        }
    }

    pub(crate) async fn get(&mut self) -> Result<(Option<StreamItem>, State), ApplicationError> {
        match self {
            Self::Sync(handle) => handle.get(),
            Self::Async(handle) => handle.get().await,
        }
    }
}

pub(crate) enum ModeIterate<'a> {
    Sync(StreamIterate<'a>),
    Async(AStreamIterate<'a>),
}

impl<'a> ModeIterate<'a> {
    pub(crate) async fn next_step<'s>(
        &'s mut self,
    ) -> Result<Option<(String, ModeStepHandle<'s, 'a>)>, ApplicationError> {
        match self {
            Self::Sync(iterate) => iterate.next_step().map(|next_step| {
                next_step.map(|(executed, handle)| {
                    (executed.name().to_string(), ModeStepHandle::Sync(handle))
                })
            }),
            Self::Async(iterate) => iterate.next_step().await.map(|next_step| {
                next_step.map(|(executed, handle)| {
                    (executed.name().to_string(), ModeStepHandle::Async(handle))
                })
            }),
        }
    }

    pub(crate) async fn abort(&mut self) -> Result<(), ApplicationError> {
        match self {
            Self::Sync(iterate) => iterate.abort(),
            Self::Async(iterate) => iterate.abort().await,
        }
    }
}

pub(crate) enum ModeStepHandle<'s, 'a> {
    Sync(StreamStepHandle<'s, 'a>),
    Async(AStreamStepHandle<'s, 'a>),
}

impl ModeStepHandle<'_, '_> {
    pub(crate) async fn next_item(&mut self) -> Result<Option<StreamItem>, ApplicationError> {
        match self {
            Self::Sync(handle) => handle.next_item(),
            Self::Async(handle) => handle.next_item().await,
        }
    }

    pub(crate) async fn get(&mut self) -> Result<(Option<StreamItem>, State), ApplicationError> {
        match self {
            Self::Sync(handle) => handle.get(),
            Self::Async(handle) => handle.get().await,
        }
    }
}
