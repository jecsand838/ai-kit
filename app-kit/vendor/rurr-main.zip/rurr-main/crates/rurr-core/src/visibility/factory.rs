use thiserror::Error;

mod handle;
mod hook_call;
mod session;
pub use handle::TraceSpanHandle;
pub(crate) use session::TraceSession;

/// Error returned while creating or using visibility spans.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum VisibilityError {
    /// A visibility hook panicked.
    #[error("visibility hook panic during {hook}: {message}")]
    HookPanic {
        /// Hook name that panicked.
        hook: &'static str,
        /// Panic payload rendered as a string.
        message: String,
    },
    /// A visibility hook returned an error.
    #[error("visibility hook failed during {hook}: {message}")]
    HookFailed {
        /// Hook name that failed.
        hook: &'static str,
        /// Human-readable failure message.
        message: String,
    },
    /// The traced return value could not be serialized truthfully.
    #[error("failed to serialize traced output during {operation}: {message}")]
    OutputSerializationFailed {
        /// Operation that failed to serialize the traced output.
        operation: &'static str,
        /// Human-readable serialization failure message.
        message: String,
    },
    /// An async-only visibility operation was attempted on a sync-only span.
    #[error("async visibility operation '{operation}' requires an async trace span")]
    AsyncOperationRequiresAsyncTrace {
        /// Operation that required an async trace.
        operation: &'static str,
    },
    /// A panic was captured while executing a visibility operation.
    #[error("captured panic during {operation}: {message}")]
    CapturedPanic {
        /// Operation that captured the panic.
        operation: &'static str,
        /// Panic payload rendered as a string.
        message: String,
    },
}
