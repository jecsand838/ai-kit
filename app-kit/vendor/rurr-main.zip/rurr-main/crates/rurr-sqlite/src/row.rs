use rurr_persistence::PersistedRowTuple;

/// Extracts a persisted-state row tuple from a `rusqlite` result row.
pub fn row_tuple_from_rusqlite(row: &rusqlite::Row<'_>) -> rusqlite::Result<PersistedRowTuple> {
    Ok((
        row.get(0)?,
        row.get(1)?,
        row.get(2)?,
        row.get(3)?,
        row.get(4)?,
        row.get(5)?,
        row.get(6)?,
    ))
}
