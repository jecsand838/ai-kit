use super::*;
use crate::tracking::lifecycle_events::ChildRelationshipMode;
use rurr_persistence::wire as persistence_wire;
use std::{io, time::SystemTime};
use store_util::tracking_repository::{artifacts::TrackingArtifact, write as repository_write};

const REQUIRED_REGISTERED_APP_ARTIFACTS: &[TrackingArtifact] = &[
    TrackingArtifact::Graph,
    TrackingArtifact::Metadata,
    TrackingArtifact::Log,
];

#[derive(Clone, Copy)]
struct ValidatedAppId<'a>(&'a str);

impl<'a> ValidatedAppId<'a> {
    fn new(app_id: &'a str) -> Result<Self, TrackingError> {
        LocalTrackingClient::validate_app_id(app_id)?;
        Ok(Self(app_id))
    }

    fn required(app_id: Option<&'a str>, op_label: &'static str) -> Result<Self, TrackingError> {
        let Some(app_id) = app_id else {
            return Err(TrackingError::MissingAppId {
                operation: op_label,
            });
        };
        Self::new(app_id)
    }

    fn as_str(self) -> &'a str {
        self.0
    }
}

pub(super) struct ResolvedTrackingApp {
    pub(super) app_id: String,
    pub(super) anchor: store_util::anchored_fs::AnchoredDir,
}

struct PreparedChildRelationshipWrite {
    parent_anchor: store_util::anchored_fs::AnchoredDir,
    child_event: ChildApplicationModel,
}

impl PreparedChildRelationshipWrite {
    fn resolve_all(
        client: &LocalTrackingClient,
        child_app_id: ValidatedAppId<'_>,
        child_partition_key: Option<&str>,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<Vec<Self>, TrackingError> {
        let mut writes = Vec::new();
        if let Some(parent) = parent_pointer {
            writes.push(Self::resolve(
                client,
                child_app_id,
                child_partition_key,
                parent,
                "fork",
            )?);
        }
        if let Some(parent) = spawning_parent_pointer {
            writes.push(Self::resolve(
                client,
                child_app_id,
                child_partition_key,
                parent,
                "spawn_start",
            )?);
        }
        Ok(writes)
    }

    fn resolve(
        client: &LocalTrackingClient,
        child_app_id: ValidatedAppId<'_>,
        child_partition_key: Option<&str>,
        parent_pointer: &ParentPointer,
        event_type: &'static str,
    ) -> Result<Self, TrackingError> {
        let parent_app =
            client.open_registered_tracking_app(ValidatedAppId::new(&parent_pointer.app_id)?)?;
        let _ = repository_write::artifact_exists(&parent_app.anchor, TrackingArtifact::Children)
            .map_err(TrackingError::from)?;

        let child_pointer = PointerModel::application(
            child_app_id.as_str(),
            child_partition_key.map(str::to_string),
            None,
        );
        let child_event = ChildApplicationModel::new(
            child_pointer,
            event_type,
            parent_pointer.sequence_id,
            persistence_wire::sortable_rfc3339_utc_string(SystemTime::now()).map_err(|error| {
                TrackingError::Timestamp {
                    operation: "register_child_application",
                    message: error.to_string(),
                }
            })?,
        );

        Ok(Self {
            parent_anchor: parent_app.anchor,
            child_event,
        })
    }
}

impl LocalTrackingClient {
    /// Registers a tracked application and writes its graph and metadata artifacts if needed.
    pub fn register_application(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &impl GraphRegistrationView,
        parent_pointer: Option<ParentPointer>,
        spawning_parent_pointer: Option<ParentPointer>,
    ) -> Result<(), TrackingError> {
        self.register_application_with_child_relationships(
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            ChildRelationshipMode::Record,
        )
    }

    pub(super) fn register_application_with_child_relationships(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &impl GraphRegistrationView,
        parent_pointer: Option<ParentPointer>,
        spawning_parent_pointer: Option<ParentPointer>,
        child_relationships: ChildRelationshipMode,
    ) -> Result<(), TrackingError> {
        let child_app_id = ValidatedAppId::new(app_id)?;
        if child_relationships == ChildRelationshipMode::RelationshipOnly {
            let prepared_child_relationships = PreparedChildRelationshipWrite::resolve_all(
                self,
                child_app_id,
                partition_key,
                parent_pointer.as_ref(),
                spawning_parent_pointer.as_ref(),
            )?;
            for child_relationship in prepared_child_relationships {
                self.append_prepared_child_event(child_relationship)?;
            }
            return Ok(());
        }

        let existing_app = self.open_tracking_app_if_present(child_app_id)?;
        let metadata_exists = match existing_app.as_ref() {
            Some(app) => repository_write::artifact_exists(&app.anchor, TrackingArtifact::Metadata)
                .map_err(TrackingError::from)?,
            None => false,
        };
        let prepared_child_relationships =
            if metadata_exists || child_relationships == ChildRelationshipMode::ApplicationOnly {
                Vec::new()
            } else {
                PreparedChildRelationshipWrite::resolve_all(
                    self,
                    child_app_id,
                    partition_key,
                    parent_pointer.as_ref(),
                    spawning_parent_pointer.as_ref(),
                )?
            };
        let app = match existing_app {
            Some(app) => app,
            None => self.ensure_tracking_app(child_app_id)?,
        };
        let graph_model = ApplicationModel::from_graph(graph)?;
        let metadata_model = ApplicationMetadataModel::new(
            partition_key.map(|pk| pk.to_string()),
            parent_pointer,
            spawning_parent_pointer,
        );

        let _ = repository_write::write_json_artifact_if_missing(
            &app.anchor,
            TrackingArtifact::Graph,
            &graph_model,
        )
        .map_err(TrackingError::from)?;
        let metadata_created = repository_write::write_json_artifact_if_missing(
            &app.anchor,
            TrackingArtifact::Metadata,
            &metadata_model,
        )
        .map_err(TrackingError::from)?;
        let _ =
            repository_write::create_jsonl_artifact_if_missing(&app.anchor, TrackingArtifact::Log)
                .map_err(TrackingError::from)?;

        if metadata_created {
            for child_relationship in prepared_child_relationships {
                self.append_prepared_child_event(child_relationship)?;
            }
        }

        Ok(())
    }

    pub(super) fn resolve_required_tracking_app(
        &self,
        app_id: Option<&str>,
        op_label: &'static str,
    ) -> Result<ResolvedTrackingApp, TrackingError> {
        self.open_registered_tracking_app(ValidatedAppId::required(app_id, op_label)?)
    }

    fn ensure_tracking_app(
        &self,
        app_id: ValidatedAppId<'_>,
    ) -> Result<ResolvedTrackingApp, TrackingError> {
        let anchor =
            store_util::tracking_repository::ensure_app_dir(self.project_anchor(), app_id.as_str())
                .map_err(TrackingError::from)?;
        Ok(ResolvedTrackingApp {
            app_id: app_id.as_str().to_string(),
            anchor,
        })
    }

    fn open_tracking_app_if_present(
        &self,
        app_id: ValidatedAppId<'_>,
    ) -> Result<Option<ResolvedTrackingApp>, TrackingError> {
        store_util::tracking_repository::open_app_dir_if_present(
            self.project_anchor(),
            app_id.as_str(),
        )
        .map(|anchor| {
            anchor.map(|anchor| ResolvedTrackingApp {
                app_id: app_id.as_str().to_string(),
                anchor,
            })
        })
        .map_err(TrackingError::from)
    }

    fn open_registered_tracking_app(
        &self,
        app_id: ValidatedAppId<'_>,
    ) -> Result<ResolvedTrackingApp, TrackingError> {
        let Some(app) = self.open_tracking_app_if_present(app_id)? else {
            return Err(TrackingError::Io(io::Error::new(
                io::ErrorKind::NotFound,
                format!("required tracking app '{}' is missing", app_id.as_str()),
            )));
        };
        repository_write::preflight_required_artifacts(
            &app.anchor,
            REQUIRED_REGISTERED_APP_ARTIFACTS,
        )
        .map_err(TrackingError::from)?;
        Ok(app)
    }

    fn append_prepared_child_event(
        &self,
        child_relationship: PreparedChildRelationshipWrite,
    ) -> Result<(), TrackingError> {
        self.with_write_lock(|| {
            repository_write::preflight_required_artifacts(
                &child_relationship.parent_anchor,
                REQUIRED_REGISTERED_APP_ARTIFACTS,
            )?;
            repository_write::append_optional_jsonl_artifact(
                &child_relationship.parent_anchor,
                TrackingArtifact::Children,
                &child_relationship.child_event,
            )
        })
    }
}
