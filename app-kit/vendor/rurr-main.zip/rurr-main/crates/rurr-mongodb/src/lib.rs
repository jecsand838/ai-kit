//! MongoDB-backed persistence adapter for Rurr applications.
//!
//! The persister keeps MongoDB-specific schema helpers in [`schema`] and uses a
//! cached collection UUID so raw commands can safely target the initialized
//! collection. Construction validates configuration locally without requiring a
//! live server connection.
//! Persistence rows are encoded to the shared `rurr-persistence` wire shape
//! before being stored as MongoDB documents.
//! Live command behavior is covered outside doctests; docs examples stay on
//! constructor/configuration paths so they do not require a running deployment.
//!
//! ```rust
//! use rurr_mongodb::{schema::UNIQUE_RECORD_INDEX_NAME, MongoPersister, MongoPersisterConfig};
//!
//! let config = MongoPersisterConfig {
//!     uri: "mongodb://localhost:27017".to_string(),
//!     db_name: "rurr_docs".to_string(),
//!     collection_name: "state".to_string(),
//! };
//! let persister = MongoPersister::new(config.clone())?;
//!
//! assert_eq!(persister.config(), config);
//! assert_eq!(UNIQUE_RECORD_INDEX_NAME, "unique_record");
//! # Ok::<(), rurr_persistence::PersistenceError>(())
//! ```
#![deny(missing_docs)]

use mongodb::bson::Binary;
use mongodb::error::Error as MongoError;
use mongodb::sync::Client;
use serde::{Deserialize, Serialize};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Mutex;

use rurr_persistence::PersistenceError;

mod mongo_impl;
/// Schema definitions, command builders, and query helpers for MongoDB-backed
/// persisted state.
pub mod schema;
mod sync_impl;
pub(crate) use mongo_impl::document::{
    document_to_persisted_state, now_sortable_rfc3339_utc_string, parse_save_reply,
};
use mongo_impl::error::{classify_mongo_server_error, mongo_error_details};
pub(crate) use mongo_impl::error::{is_namespace_exists_error, is_namespace_not_found_error};

const OP_CONNECTION_CLOSED: &str = "connection_closed";
const OP_CONNECTION_LOCK_POISONED: &str = "connection_lock_poisoned";
const OP_DOCUMENT_DESERIALIZATION_FAILED: &str = "document_deserialization_failed";
const OP_MONGODB_COMMAND_FAILED: &str = "mongodb_command_failed";
const OP_MONGODB_CONNECT_FAILED: &str = "mongodb_connect_failed";
const OP_RECORD_ALREADY_EXISTS: &str = "record_already_exists";
const OP_SEQUENCE_ID_OUT_OF_RANGE: &str = "sequence_id_out_of_range";
const OP_STATE_DESERIALIZATION_FAILED: &str = "state_deserialization_failed";
const OP_STATUS_DESERIALIZATION_FAILED: &str = "status_deserialization_failed";

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serializable configuration for constructing a MongoDB persister.
pub struct MongoPersisterConfig {
    /// MongoDB connection string for the target deployment.
    pub uri: String,
    /// Database that stores the persisted-state collection.
    pub db_name: String,
    /// Collection used to store persisted-state documents.
    pub collection_name: String,
}

impl MongoPersisterConfig {
    /// Builds a MongoDB persister config from a URI, database name, and
    /// collection name.
    pub fn new(
        uri: impl Into<String>,
        db_name: impl Into<String>,
        collection_name: impl Into<String>,
    ) -> Self {
        Self {
            uri: uri.into(),
            db_name: db_name.into(),
            collection_name: collection_name.into(),
        }
    }
}

/// Synchronous MongoDB persister built on the driver’s sync client API.
pub struct MongoPersister {
    client: Client,
    config: MongoPersisterConfig,
    cached_collection_uuid: Mutex<Option<Binary>>,
    closed: AtomicBool,
}

impl MongoPersister {
    /// Creates a MongoDB persister from a serialized config value.
    pub fn new(config: MongoPersisterConfig) -> Result<Self, PersistenceError> {
        let client = Client::with_uri_str(config.uri.as_str()).map_err(|_| {
            PersistenceError::UnsupportedOperation {
                operation: OP_MONGODB_CONNECT_FAILED,
            }
        })?;

        Ok(Self {
            client,
            config,
            cached_collection_uuid: Mutex::new(None),
            closed: AtomicBool::new(false),
        })
    }

    /// Returns the configuration originally used to construct this persister.
    pub fn config(&self) -> MongoPersisterConfig {
        self.config.clone()
    }

    /// Marks the persister as closed and drops any cached collection metadata.
    pub fn cleanup(&self) -> Result<(), PersistenceError> {
        self.shutdown()
    }

    fn shutdown(&self) -> Result<(), PersistenceError> {
        self.closed.store(true, Ordering::Release);
        self.invalidate_cached_collection_uuid();
        Ok(())
    }

    fn map_command_error(&self, error: MongoError, operation: &'static str) -> PersistenceError {
        let (code, code_name, message) = mongo_error_details(&error);
        if let Some(classified) = classify_mongo_server_error(code, code_name, message) {
            return self.track_persistence_error(classified);
        }

        self.track_persistence_error(PersistenceError::UnsupportedOperation { operation })
    }

    fn track_persistence_error(&self, error: PersistenceError) -> PersistenceError {
        if matches!(error, PersistenceError::NotInitialized) {
            self.invalidate_cached_collection_uuid();
        }
        error
    }
}

#[cfg(test)]
mod tests;
