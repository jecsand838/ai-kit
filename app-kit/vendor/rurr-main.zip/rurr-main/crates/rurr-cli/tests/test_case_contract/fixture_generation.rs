use super::*;

fn write_counter_fixture(storage_dir: &std::path::Path, states: &[Value]) {
    write_tracking_fixture(
        storage_dir,
        "demo_counter",
        "counter-app-0001",
        "counter",
        states,
    );
}

fn write_failed_chatbot_fixture(storage_dir: &tempfile::TempDir) {
    let app_dir = storage_dir
        .path()
        .join("demo_chatbot")
        .join("chat-1-giraffe");
    fs::create_dir_all(&app_dir).expect("chatbot app dir should be created");
    fs::write(
        app_dir.join("metadata.json"),
        r#"{"type":"application_metadata","partition_key":null,"parent_pointer":null,"spawning_parent_pointer":null}"#,
    )
    .expect("chatbot metadata should be written");
    fs::write(
        app_dir.join("log.jsonl"),
        serde_json::json!({
            "type": "end_entry",
            "end_time": "2026-03-20T00:00:00.000000000Z",
            "action": "prompt",
            "result": serde_json::Value::Null,
            "exception": "model unavailable",
            "state": {
                "prompt": "Tell me about giraffes",
                "__SEQUENCE_ID": 0
            },
            "sequence_id": 0,
        })
        .to_string(),
    )
    .expect("chatbot log should be written");
}

#[test]
fn test_case_create_writes_completed_fixture_and_burr_style_helper_text() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("counter-fixture.json");

    write_counter_fixture(
        storage_dir.path(),
        &[
            serde_json::json!({"count": 1}),
            serde_json::json!({"count": 2}),
        ],
    );

    let mut command = test_case_create_command();
    command
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--project-name")
        .arg("demo_counter")
        .arg("--app-id")
        .arg("counter-app-0001")
        .arg("--sequence-id")
        .arg("1")
        .arg("--target-file-name")
        .arg(&fixture_path);
    let output = run_command(&mut command, "test-case create should run");
    assert_success(&output, "test-case create should succeed");

    let stdout = stdout_utf8(&output);
    assert!(stdout.contains("Action was successful"));
    assert!(stdout.contains("Add the following to your test file:"));
    assert!(stdout.contains("counter"));

    let fixtures: Value =
        serde_json::from_str(&fs::read_to_string(&fixture_path).expect("fixture should exist"))
            .expect("fixture json should parse");
    let fixtures = fixtures
        .as_array()
        .expect("fixture file should contain an array");
    assert_eq!(fixtures.len(), 1);
    assert_eq!(fixtures[0]["action"], Value::String("counter".to_string()));
    assert_eq!(
        fixtures[0]["input_state"],
        serde_json::json!({
            "count": 1
        })
    );
    assert_eq!(
        fixtures[0]["expected_state"],
        serde_json::json!({
            "count": 2
        })
    );
}

#[test]
fn test_case_create_rejects_failed_sequence_without_provable_expected_state() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("fixtures.json");

    write_counter_fixture(
        storage_dir.path(),
        &[
            serde_json::json!({"count": 1}),
            serde_json::json!({"count": 2}),
        ],
    );
    write_failed_chatbot_fixture(&storage_dir);

    let mut first_command = test_case_create_command();
    first_command
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--project-name")
        .arg("demo_counter")
        .arg("--app-id")
        .arg("counter-app-0001")
        .arg("--sequence-id")
        .arg("1")
        .arg("--target-file-name")
        .arg(&fixture_path);
    let first = run_command(&mut first_command, "first test-case create should run");
    assert_success(&first, "first invocation should succeed");

    let mut second_command = test_case_create_command();
    second_command
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--project-name")
        .arg("demo_chatbot")
        .arg("--app-id")
        .arg("chat-1-giraffe")
        .arg("--sequence-id")
        .arg("0")
        .arg("--target-file-name")
        .arg(&fixture_path)
        .arg("--action-name")
        .arg("chat_response");
    let second = run_command(&mut second_command, "second test-case create should run");
    assert_test_case_failure_contains(
        &second,
        "failed tracked runs should not synthesize a fixture",
        "tracked artifacts do not prove an expected_state",
    );

    let fixtures: Value =
        serde_json::from_str(&fs::read_to_string(&fixture_path).expect("fixture should exist"))
            .expect("fixture json should parse");
    let fixtures = fixtures
        .as_array()
        .expect("fixture file should contain an array");
    assert_eq!(fixtures.len(), 1);
}

#[test]
fn test_case_create_accepts_existing_empty_fixture_file() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("empty-fixture.json");
    fs::write(&fixture_path, "").expect("empty fixture file should be created");

    write_counter_fixture(
        storage_dir.path(),
        &[
            serde_json::json!({"count": 1}),
            serde_json::json!({"count": 2}),
        ],
    );

    let mut command = test_case_create_command();
    command
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--project-name")
        .arg("demo_counter")
        .arg("--app-id")
        .arg("counter-app-0001")
        .arg("--sequence-id")
        .arg("1")
        .arg("--target-file-name")
        .arg(&fixture_path);
    let output = run_command(&mut command, "test-case create should run");
    assert_success(
        &output,
        "test-case create should accept an existing empty fixture file",
    );

    let fixtures: Value =
        serde_json::from_str(&fs::read_to_string(&fixture_path).expect("fixture should exist"))
            .expect("fixture json should parse");
    let fixtures = fixtures
        .as_array()
        .expect("fixture file should contain an array");
    assert_eq!(fixtures.len(), 1);
    assert_eq!(fixtures[0]["action"], Value::String("counter".to_string()));
}

#[test]
fn test_case_create_rejects_completed_sequence_when_prior_snapshot_is_missing() {
    let storage_dir = tempfile::tempdir().expect("storage dir should be created");
    let target_dir = tempfile::tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("initial-fixture.json");

    write_counter_fixture(storage_dir.path(), &[serde_json::json!({"count": 1})]);

    let mut command = test_case_create_command();
    command
        .arg("--storage-dir")
        .arg(storage_dir.path())
        .arg("--project-name")
        .arg("demo_counter")
        .arg("--app-id")
        .arg("counter-app-0001")
        .arg("--sequence-id")
        .arg("0")
        .arg("--target-file-name")
        .arg(&fixture_path);
    let output = run_command(&mut command, "test-case create should run");
    assert_test_case_failure_contains(
        &output,
        "test-case create should fail for initial completed actions without a prior snapshot",
        "cannot extract local test case fixture without a provable input_state",
    );
    assert!(
        !fixture_path.exists(),
        "fixture file should not be created when the input_state cannot be proven"
    );
}
