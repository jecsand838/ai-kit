use crate::model::{InputBinding, ParamKind, SignatureModel};
use crate::parse::MacroArgs;
use proc_macro2::TokenStream as TokenStream2;
use quote::{format_ident, quote};
use syn::{ItemFn, LitStr};

pub(crate) fn generate_action_tokens(
    function: &ItemFn,
    args: &MacroArgs,
    model: &SignatureModel,
) -> TokenStream2 {
    generate_constructor(function, args, model, GenerationKind::Action)
}

pub(crate) fn generate_streaming_tokens(
    function: &ItemFn,
    args: &MacroArgs,
    model: &SignatureModel,
) -> TokenStream2 {
    generate_constructor(function, args, model, GenerationKind::Streaming)
}

#[derive(Clone, Copy)]
enum GenerationKind {
    Action,
    Streaming,
}

fn generate_constructor(
    function: &ItemFn,
    args: &MacroArgs,
    model: &SignatureModel,
    kind: GenerationKind,
) -> TokenStream2 {
    let constructor_ident = format_ident!("{}_action", function.sig.ident);
    let visibility = &function.vis;
    let builder = builder_tokens(function, args, model);
    let handler = handler_tokens(function, model, kind, builder);

    quote! {
        #visibility fn #constructor_ident() -> ::std::result::Result<
            ::rurr_core::action::FunctionAction,
            ::rurr_core::action::ActionError,
        > {
            #handler
        }
    }
}

fn builder_tokens(function: &ItemFn, args: &MacroArgs, model: &SignatureModel) -> TokenStream2 {
    let reads = string_array_tokens(&args.reads);
    let writes = string_array_tokens(&args.writes);
    let tags = string_array_tokens(&args.tags);
    let inputs = string_array_tokens(
        &model
            .input_bindings
            .iter()
            .map(|binding| binding.ident.to_string())
            .collect::<Vec<_>>(),
    );
    let source = function.to_token_stream().to_string();

    quote! {
        ::rurr_core::action::FunctionActionBuilder::new()
            .reads(#reads)
            .writes(#writes)
            .tags(#tags)
            .inputs(#inputs)
            .with_source_code(#source)
    }
}

fn handler_tokens(
    function: &ItemFn,
    model: &SignatureModel,
    kind: GenerationKind,
    builder: TokenStream2,
) -> TokenStream2 {
    let function_ident = &function.sig.ident;
    let action_extraction = extract_action_inputs(&model.input_bindings);
    let sync_stream_extraction = extract_sync_stream_inputs(&model.input_bindings);
    let async_stream_extraction = extract_async_stream_inputs(&model.input_bindings);
    let sync_args = call_args(
        &model.ordered_params,
        quote!(state),
        quote!(ctx),
        &model.input_bindings,
    );
    let owned_args = call_args(
        &model.ordered_params,
        quote!(state_ref),
        quote!(ctx_ref),
        &model.input_bindings,
    );

    match (kind, function.sig.asyncness.is_some()) {
        (GenerationKind::Action, false) => quote! {
            ::rurr_core::action::macro_support::sync_action(#builder, |state, ctx| {
                #action_extraction
                #function_ident(#(#sync_args),*)
            })
        },
        (GenerationKind::Action, true) => quote! {
            ::rurr_core::action::macro_support::async_action(#builder, |state, ctx| async move {
                let state_ref = &state;
                let ctx_ref = &ctx;
                #action_extraction
                #function_ident(#(#owned_args),*).await
            })
        },
        (GenerationKind::Streaming, false) => quote! {
            ::rurr_core::action::macro_support::streaming_sync_action(#builder, |state, ctx| {
                let state_ref = &state;
                let ctx_ref = &ctx;
                #sync_stream_extraction
                #function_ident(#(#owned_args),*)
            })
        },
        (GenerationKind::Streaming, true) => quote! {
            ::rurr_core::action::macro_support::streaming_async_action(#builder, |state, ctx| {
                ::rurr_core::action::macro_support::flatten_local_async_stream(async move {
                    let state_ref = &state;
                    let ctx_ref = &ctx;
                    #async_stream_extraction
                    #function_ident(#(#owned_args),*).await
                })
            })
        },
    }
}

fn call_args(
    ordered_params: &[ParamKind],
    state_ident: TokenStream2,
    ctx_ident: TokenStream2,
    input_bindings: &[InputBinding],
) -> Vec<TokenStream2> {
    ordered_params
        .iter()
        .map(|param| match param {
            ParamKind::State => state_ident.clone(),
            ParamKind::Context => ctx_ident.clone(),
            ParamKind::User { binding_index } => {
                let binding_ident = &input_bindings[*binding_index].binding_ident;
                quote!(#binding_ident)
            }
        })
        .collect()
}

fn extract_action_inputs(input_bindings: &[InputBinding]) -> TokenStream2 {
    let bindings = input_bindings.iter().map(|binding| {
        let binding_ident = &binding.binding_ident;
        let ty = &binding.ty;
        let input_key = LitStr::new(&binding.ident.to_string(), binding.ident.span());
        quote! {
            let #binding_ident: #ty =
                ::rurr_core::action::macro_support::deserialize_input(&ctx.inputs, #input_key)?;
        }
    });
    quote!(#(#bindings)*)
}

fn extract_sync_stream_inputs(input_bindings: &[InputBinding]) -> TokenStream2 {
    let bindings = input_bindings.iter().map(|binding| {
        let binding_ident = &binding.binding_ident;
        let ty = &binding.ty;
        let input_key = LitStr::new(&binding.ident.to_string(), binding.ident.span());
        quote! {
            let #binding_ident: #ty = match ::rurr_core::action::macro_support::deserialize_sync_stream_input(
                &ctx.inputs,
                #input_key,
            ) {
                Ok(value) => value,
                Err(error_stream) => return error_stream,
            };
        }
    });
    quote!(#(#bindings)*)
}

fn extract_async_stream_inputs(input_bindings: &[InputBinding]) -> TokenStream2 {
    let bindings = input_bindings.iter().map(|binding| {
        let binding_ident = &binding.binding_ident;
        let ty = &binding.ty;
        let input_key = LitStr::new(&binding.ident.to_string(), binding.ident.span());
        quote! {
            let #binding_ident: #ty = match ::rurr_core::action::macro_support::deserialize_async_stream_input(
                &ctx.inputs,
                #input_key,
            ) {
                Ok(value) => value,
                Err(error_stream) => return error_stream,
            };
        }
    });
    quote!(#(#bindings)*)
}

fn string_array_tokens(values: &[String]) -> TokenStream2 {
    if values.is_empty() {
        quote!(::std::iter::empty::<&str>())
    } else {
        let values = values
            .iter()
            .map(|value| LitStr::new(value, proc_macro2::Span::call_site()))
            .collect::<Vec<_>>();
        quote!([#(#values),*])
    }
}

trait ToTokenStream {
    fn to_token_stream(&self) -> TokenStream2;
}

impl ToTokenStream for ItemFn {
    fn to_token_stream(&self) -> TokenStream2 {
        quote!(#self)
    }
}
