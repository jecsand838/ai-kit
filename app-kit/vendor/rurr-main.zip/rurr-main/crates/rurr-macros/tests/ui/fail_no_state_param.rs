use rurr_core::action::{ActionError, ActionResult};

#[rurr_macros::action(reads = ["amount"], writes = ["amount"])]
fn missing_state(amount: i64) -> Result<ActionResult, ActionError> {
    let _ = amount;
    Ok(ActionResult::new(Default::default(), Default::default()))
}

fn main() {}
