---
name: rurr-streaming-transaction-safety
description: "Use when touching Rurr streaming, sessions, lifecycle hooks, application execution, or transaction rollback behavior to preserve lazy Burr-compatible streaming, sync/async separation, typed error paths, and forbidden-runtime-pattern guardrails."
---

# Rurr Streaming Transaction Safety

Use this skill when streaming, session, lifecycle, or execution-engine changes could affect Burr-visible runtime behavior.

## Quick start

Load, in order:

- `AGENTS.md`
- `README.md`
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- relevant tests and code under the current application execution stack

Load these companion skills:

- `$rurr-burr-source-parity-walk`
- `$use-rust-best-practices-core`
- `$use-rust-best-practices-async`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-testing`

## Workflow

1. Identify whether the change touches streaming laziness, rollback, session state, lifecycle hooks, entrypoint resolution, or tracking hooks.
2. Pin the existing behavior with current tests, docs, and Burr source before changing structure.
3. Add or request red tests for laziness, abort/error rollback, panic-to-error behavior, or sync/async separation when behavior is at risk.
4. Prefer private concrete enums and helpers over new public traits or compatibility layers.
5. Keep sync and async execution surfaces separate; only share lane-neutral classification or policy logic.
6. Replace production panic paths with typed `ApplicationError` paths when runtime invariants can fail.
7. Verify forbidden runtime patterns are absent before handoff.

## Output contract

Return:

- the streaming or session invariant under review
- the Burr parity boundary that must remain fixed
- the red tests or characterization tests needed
- the reductive implementation direction
- the narrow gates and structural checks required

## Default rules

- Do not buffer fake streaming or drain iterators/streams for replay.
- Do not use internal `realize_stream`.
- Do not use `spawn_blocking`, `block_on`, `block_in_place`, temporary runtimes, async cleanup in `Drop`, or `std::thread::spawn` inside core execution.
- Do not mix sync and async lifecycle hooks on one trait surface.
- Preserve lazy transactional streaming and rollback behavior unless compatibility docs explicitly change.

## Do not use this skill alone when

- the user still needs the overall cleanup ranked: also use `$rurr-branch-diff-reduction-audit` or `$rurr-burr-parity-reduction-audit`
- the change needs a complete phased plan: also use `$rurr-delete-first-refactor-plan`
- the plan is being implemented as an approved delete-first refactor: also use `$rurr-delete-first-refactor-plan` in implementation mode
- final handoff requires negative structural checks: also use `$rurr-structural-completion-audit`
