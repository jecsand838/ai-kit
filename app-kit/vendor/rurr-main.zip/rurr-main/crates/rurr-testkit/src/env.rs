//! Scoped process-environment helpers for tests.
//!
//! The helpers serialize environment mutations behind one process-wide lock so
//! tests can temporarily set or clear variables without racing other tests in
//! the same process.

use std::ffi::OsString;
use std::sync::{Mutex, MutexGuard};

static ENV_LOCK: Mutex<()> = Mutex::new(());

/// Restores process environment variables when dropped.
///
/// Hold the guard for the full duration of the code that depends on the
/// override. Dropping the guard restores each variable to the value it had when
/// [`set`](Self::set) acquired the shared environment lock.
pub struct EnvVarGuard {
    _lock: MutexGuard<'static, ()>,
    saved: Vec<(String, Option<OsString>)>,
}

impl EnvVarGuard {
    /// Applies environment overrides while holding the workspace test env lock.
    ///
    /// A `Some(value)` entry sets a variable, while `None` removes it. The
    /// previous values are restored when the returned guard is dropped.
    ///
    /// # Examples
    ///
    /// ```
    /// use rurr_testkit::env::EnvVarGuard;
    ///
    /// let original = std::env::var_os("RURR_DOC_ENV_GUARD");
    /// {
    ///     let _guard = EnvVarGuard::set([("RURR_DOC_ENV_GUARD", Some("enabled"))]);
    ///     assert_eq!(std::env::var("RURR_DOC_ENV_GUARD").as_deref(), Ok("enabled"));
    /// }
    /// assert_eq!(std::env::var_os("RURR_DOC_ENV_GUARD"), original);
    /// ```
    pub fn set<const N: usize>(vars: [(&str, Option<&str>); N]) -> Self {
        let lock = ENV_LOCK
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        let saved = vars
            .iter()
            .map(|(key, _)| ((*key).to_string(), std::env::var_os(key)))
            .collect();
        for (key, value) in vars {
            match value {
                Some(value) => std::env::set_var(key, value),
                None => std::env::remove_var(key),
            }
        }
        Self { _lock: lock, saved }
    }
}

impl Drop for EnvVarGuard {
    fn drop(&mut self) {
        for (key, value) in self.saved.drain(..) {
            match value {
                Some(value) => std::env::set_var(key, value),
                None => std::env::remove_var(key),
            }
        }
    }
}
