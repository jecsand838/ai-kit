use rurr_testkit::workspace_fixture::{with_locked_current_dir, TestDir};
#[cfg(unix)]
use std::os::unix::fs::symlink;
#[cfg(windows)]
use std::os::windows::fs::symlink_dir;

fn assert_alias_like_error(error: &std::io::Error) {
    let message = error.to_string();
    assert!(
        message.contains("alias") || message.contains("symlink"),
        "error should explain the alias rejection: {error}"
    );
}

#[test]
fn embedded_asset_lookup_and_bundle_export_are_available() {
    let index = rurr_tracking_server::ui_assets::embedded_index_html();
    assert!(index.contains("Rurr Tracking"));
    assert!(
        !index.to_ascii_lowercase().contains("placeholder"),
        "embedded index must not ship placeholder copy"
    );

    let app_js = rurr_tracking_server::ui_assets::embedded_asset("app.js")
        .expect("embedded app.js should be available");
    assert_eq!(app_js.content_type, "application/javascript; charset=utf-8");
    let app_js = std::str::from_utf8(app_js.bytes).expect("asset should be utf-8");
    assert!(
        app_js.contains("/api/v0/projects") && app_js.contains("loadProjects"),
        "embedded asset should drive the real tracking UI"
    );
    assert!(
        !app_js.contains("Rurr UI bundle booted"),
        "embedded asset must not rely on the old placeholder marker"
    );

    let out_dir = TestDir::new("rurr-tracking-server-ui-bundle");
    rurr_tracking_server::ui_assets::write_embedded_bundle(out_dir.path())
        .expect("embedded bundle export should succeed");
    assert!(out_dir.join("index.html").exists());
    assert!(out_dir.join("assets").join("app.js").exists());
}

#[cfg(unix)]
#[test]
fn embedded_bundle_export_allows_absolute_output_when_current_dir_is_deleted() {
    let out_dir = TestDir::new("rurr-tracking-server-ui-absolute-output");
    let cwd_parent = TestDir::new("rurr-tracking-server-ui-deleted-cwd-parent");
    let deleted_cwd = cwd_parent.join("deleted-cwd");

    std::fs::create_dir(&deleted_cwd).expect("deleted cwd should be created");
    with_locked_current_dir(&deleted_cwd, || {
        std::fs::remove_dir(&deleted_cwd).expect("deleted cwd should be removed");
        assert!(
            std::env::current_dir().is_err(),
            "current dir should be unavailable after deletion"
        );

        rurr_tracking_server::ui_assets::write_embedded_bundle(out_dir.path())
            .expect("absolute output path should not depend on the current directory");
    });
    assert!(out_dir.join("index.html").exists());
    assert!(out_dir.join("assets").join("app.js").exists());
}

#[cfg(unix)]
#[test]
fn embedded_bundle_export_rejects_symlinked_output_root() {
    let requested_root = TestDir::new("rurr-tracking-server-ui-requested-root");
    let outside_root = TestDir::new("rurr-tracking-server-ui-outside-root");

    std::fs::remove_dir_all(requested_root.path()).expect("requested root should be removable");
    symlink(outside_root.path(), requested_root.path())
        .expect("output-root symlink should be created");

    let error = rurr_tracking_server::ui_assets::write_embedded_bundle(requested_root.path())
        .expect_err("symlinked output roots must fail closed");
    assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
    assert_alias_like_error(&error);
    assert!(
        !outside_root.join("index.html").exists(),
        "bundle export must not write through a symlinked output root"
    );
    assert!(
        !outside_root.join("assets").join("app.js").exists(),
        "bundle export must not write assets through a symlinked output root"
    );
}

#[cfg(windows)]
#[test]
fn embedded_bundle_export_rejects_symlinked_output_root() {
    let requested_root = TestDir::new("rurr-tracking-server-ui-requested-root");
    let outside_root = TestDir::new("rurr-tracking-server-ui-outside-root");

    std::fs::remove_dir_all(requested_root.path()).expect("requested root should be removable");
    symlink_dir(outside_root.path(), requested_root.path())
        .expect("output-root symlink should be created");

    let error = rurr_tracking_server::ui_assets::write_embedded_bundle(requested_root.path())
        .expect_err("symlinked output roots must fail closed");
    assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
    assert_alias_like_error(&error);
    assert!(
        !outside_root.join("index.html").exists(),
        "bundle export must not write through a symlinked output root"
    );
    assert!(
        !outside_root.join("assets").join("app.js").exists(),
        "bundle export must not write assets through a symlinked output root"
    );
}

#[cfg(unix)]
#[test]
fn embedded_bundle_export_rejects_aliased_assets_directory() {
    let out_dir = TestDir::new("rurr-tracking-server-ui-output-root");
    let outside_root = TestDir::new("rurr-tracking-server-ui-outside-assets");
    let aliased_assets = outside_root.join("aliased-assets");

    std::fs::create_dir_all(&aliased_assets).expect("outside assets directory should exist");
    symlink(&aliased_assets, out_dir.join("assets"))
        .expect("aliased assets symlink should be created");

    let error = rurr_tracking_server::ui_assets::write_embedded_bundle(out_dir.path())
        .expect_err("aliased assets directories must fail closed");
    assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
    assert_alias_like_error(&error);
    assert!(
        !aliased_assets.join("app.js").exists(),
        "bundle export must not write assets through an aliased assets directory"
    );
}

#[cfg(unix)]
#[test]
fn embedded_bundle_export_rejects_invalid_assets_directory_without_overwriting_index() {
    let out_dir = TestDir::new("rurr-tracking-server-ui-output-root");
    let outside_root = TestDir::new("rurr-tracking-server-ui-outside-assets");
    let aliased_assets = outside_root.join("aliased-assets");
    let original_index = "ORIGINAL_INDEX_MARKER";

    std::fs::write(out_dir.join("index.html"), original_index).expect("seed index should exist");
    std::fs::create_dir_all(&aliased_assets).expect("outside assets directory should exist");
    symlink(&aliased_assets, out_dir.join("assets"))
        .expect("aliased assets symlink should be created");

    let error = rurr_tracking_server::ui_assets::write_embedded_bundle(out_dir.path())
        .expect_err("aliased assets directories must fail closed");
    assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
    assert_alias_like_error(&error);
    assert_eq!(
        std::fs::read_to_string(out_dir.join("index.html")).expect("index should remain readable"),
        original_index,
        "bundle export must not overwrite index.html before assets validation succeeds"
    );
}

#[cfg(unix)]
#[test]
fn embedded_bundle_export_rejects_invalid_asset_leaf_without_overwriting_index() {
    let out_dir = TestDir::new("rurr-tracking-server-ui-output-root");
    let outside_root = TestDir::new("rurr-tracking-server-ui-outside-asset-leaf");
    let leaked_asset = outside_root.join("app.js");
    let original_index = "ORIGINAL_INDEX_MARKER";

    std::fs::write(out_dir.join("index.html"), original_index).expect("seed index should exist");
    std::fs::create_dir_all(out_dir.join("assets")).expect("assets dir should exist");
    std::fs::write(&leaked_asset, "console.log('outside');").expect("outside asset should exist");
    symlink(&leaked_asset, out_dir.join("assets").join("app.js"))
        .expect("aliased asset leaf should be created");

    let error = rurr_tracking_server::ui_assets::write_embedded_bundle(out_dir.path())
        .expect_err("aliased asset leaves must fail closed");
    assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
    assert_alias_like_error(&error);
    assert_eq!(
        std::fs::read_to_string(out_dir.join("index.html")).expect("index should remain readable"),
        original_index,
        "bundle export must not overwrite index.html before asset leaf validation succeeds"
    );
}

#[cfg(windows)]
#[test]
fn embedded_bundle_export_rejects_aliased_assets_directory() {
    let out_dir = TestDir::new("rurr-tracking-server-ui-output-root");
    let outside_root = TestDir::new("rurr-tracking-server-ui-outside-assets");
    let aliased_assets = outside_root.join("aliased-assets");

    std::fs::create_dir_all(&aliased_assets).expect("outside assets directory should exist");
    symlink_dir(&aliased_assets, out_dir.join("assets"))
        .expect("aliased assets symlink should be created");

    let error = rurr_tracking_server::ui_assets::write_embedded_bundle(out_dir.path())
        .expect_err("aliased assets directories must fail closed");
    assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
    assert_alias_like_error(&error);
    assert!(
        !aliased_assets.join("app.js").exists(),
        "bundle export must not write assets through an aliased assets directory"
    );
}

#[cfg(unix)]
#[test]
fn embedded_bundle_export_rejects_aliased_output_ancestor() {
    let work_dir = TestDir::new("rurr-tracking-server-ui-output-work");
    let outside_root = TestDir::new("rurr-tracking-server-ui-outside-ancestor");
    let alias_path = work_dir.join("alias");
    let requested_out = alias_path.join("exported-ui");

    symlink(&outside_root, &alias_path).expect("output ancestor alias should be created");

    let error = rurr_tracking_server::ui_assets::write_embedded_bundle(&requested_out)
        .expect_err("aliased output ancestors must fail closed");
    assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
    assert_alias_like_error(&error);
    assert!(
        !outside_root.join("exported-ui").join("index.html").exists(),
        "bundle export must not write through an aliased output ancestor"
    );
    assert!(
        !outside_root
            .join("exported-ui")
            .join("assets")
            .join("app.js")
            .exists(),
        "bundle export must not write assets through an aliased output ancestor"
    );
}

#[cfg(windows)]
#[test]
fn embedded_bundle_export_rejects_aliased_output_ancestor() {
    let work_dir = TestDir::new("rurr-tracking-server-ui-output-work");
    let outside_root = TestDir::new("rurr-tracking-server-ui-outside-ancestor");
    let alias_path = work_dir.join("alias");
    let requested_out = alias_path.join("exported-ui");

    symlink_dir(outside_root.path(), &alias_path).expect("output ancestor alias should be created");

    let error = rurr_tracking_server::ui_assets::write_embedded_bundle(&requested_out)
        .expect_err("aliased output ancestors must fail closed");
    assert_eq!(error.kind(), std::io::ErrorKind::InvalidInput);
    assert_alias_like_error(&error);
    assert!(
        !outside_root.join("exported-ui").join("index.html").exists(),
        "bundle export must not write through an aliased output ancestor"
    );
    assert!(
        !outside_root
            .join("exported-ui")
            .join("assets")
            .join("app.js")
            .exists(),
        "bundle export must not write assets through an aliased output ancestor"
    );
}
