//! Parallel child-graph execution helpers and task-construction utilities.
//!
//! This module exposes the public executor contract plus the task-shaping
//! helpers used by map-style child execution. External executors receive
//! [`ParallelRuntimeContext`] so they can delegate real child execution back to
//! the runtime instead of rebuilding tracking or persistence wiring themselves.

#[cfg(test)]
mod child_runtime;
/// Parallel child-graph execution traits and helpers.
pub mod executor;
mod map_common;
mod map_reduce;
mod parallel_map;
mod runtime;
mod task_action;
mod types;

pub use executor::{ParallelExecutor, ParallelRuntimeContext};
pub use map_reduce::map_reduce_action;
pub use parallel_map::{
    ParallelMap, ParallelPairBuilder, ParallelStateMapper, ParallelStateSplitter,
    ParallelTaskSource,
};
pub use task_action::TaskBasedParallelAction;
pub use types::{CascadeMode, RunnableGraph, SubGraphTask};
