use futures::Stream;
use std::future::Future;
use std::pin::Pin;

/// Stream type returned by asynchronous chunk sources.
pub type AsyncChunkStream = Pin<Box<dyn Stream<Item = Result<String, String>> + Send>>;
/// Future type that resolves to an asynchronous chunk stream.
pub type AsyncChunkStreamFuture =
    Pin<Box<dyn Future<Output = Result<AsyncChunkStream, String>> + Send>>;

/// Contract implemented by strict asynchronous streaming proof sources.
pub trait AsyncChunkSource: Clone + Send + Sync + 'static {
    /// Returns the prompt that this source expects to receive.
    fn prompt(&self) -> &str;
    /// Returns how many times streaming has been started.
    fn starts(&self) -> usize;
    /// Produces the asynchronous chunk stream for the provided prompt.
    fn stream_chunks_async(&self, prompt: &str) -> AsyncChunkStreamFuture;
}
