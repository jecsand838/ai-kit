use crate::wire;
use crate::{
    AsyncBaseStateLoader, AsyncBaseStateSaver, BaseStateLoader, BaseStateSaver, PersistedStateData,
    PersistedStateStatus, PersistenceError,
};
use async_trait::async_trait;
use indexmap::IndexMap;
use serde_json::Value;
use std::sync::{Mutex, MutexGuard};

type Storage = IndexMap<String, IndexMap<String, Vec<PersistedStateData>>>;

/// Synchronous in-memory persistence implementation for tests and examples.
#[derive(Debug, Default)]
pub struct InMemoryPersister {
    storage: Mutex<Storage>,
}

impl InMemoryPersister {
    /// Creates a new empty in-memory persister.
    pub fn new() -> Self {
        Self::default()
    }

    fn lock_storage(&self) -> Result<MutexGuard<'_, Storage>, PersistenceError> {
        self.storage
            .lock()
            .map_err(|_| PersistenceError::InMemoryLockPoisoned)
    }
}

impl crate::BaseStateLoader for InMemoryPersister {
    fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        let Some(app_id) = app_id else {
            return Ok(None);
        };
        let partition_key = wire::normalize_partition_key(partition_key);
        let storage = self.lock_storage()?;
        let Some(states) = storage
            .get(&partition_key)
            .and_then(|partition| partition.get(app_id))
        else {
            return Ok(None);
        };

        if let Some(sequence_id) = sequence_id {
            Ok(states
                .iter()
                .rev()
                .find(|state| state.sequence_id == sequence_id)
                .cloned())
        } else {
            Ok(states.last().cloned())
        }
    }

    fn list_app_ids(&self, partition_key: Option<&str>) -> Result<Vec<String>, PersistenceError> {
        let partition_key = wire::normalize_partition_key(partition_key);
        let storage = self.lock_storage()?;
        let Some(app_states) = storage.get(&partition_key) else {
            return Ok(Vec::new());
        };
        Ok(app_states.keys().cloned().collect())
    }
}

impl crate::BaseStateSaver for InMemoryPersister {
    fn initialize(&self) -> Result<(), PersistenceError> {
        Ok(())
    }

    fn is_initialized(&self) -> Result<bool, PersistenceError> {
        Ok(true)
    }

    fn cleanup(&self) -> Result<(), PersistenceError> {
        Ok(())
    }

    fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        let partition_key = wire::normalize_partition_key(partition_key);
        let mut storage = self.lock_storage()?;
        let partition = storage.entry(partition_key.clone()).or_default();
        let app_states = partition.entry(app_id.to_string()).or_default();
        app_states.push(PersistedStateData {
            partition_key: Some(partition_key),
            app_id: app_id.to_string(),
            sequence_id,
            position: Some(position.to_string()),
            state: Some(state),
            created_at: Some(wire::now_timestamp()?),
            status,
        });
        Ok(())
    }
}

/// Async wrapper around [`InMemoryPersister`].
#[derive(Debug, Default)]
pub struct AsyncInMemoryPersister {
    inner: InMemoryPersister,
}

impl AsyncInMemoryPersister {
    /// Creates a new empty async in-memory persister.
    pub fn new() -> Self {
        Self::default()
    }
}

#[async_trait]
impl AsyncBaseStateLoader for AsyncInMemoryPersister {
    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.inner.load(partition_key, app_id, sequence_id)
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        self.inner.list_app_ids(partition_key)
    }
}

#[async_trait]
impl AsyncBaseStateSaver for AsyncInMemoryPersister {
    async fn initialize(&self) -> Result<(), PersistenceError> {
        self.inner.initialize()
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.inner.is_initialized()
    }

    async fn cleanup(&self) -> Result<(), PersistenceError> {
        self.inner.cleanup()
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.inner
            .save(partition_key, app_id, sequence_id, position, state, status)
    }
}
