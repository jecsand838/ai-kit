//! Application construction, execution, inspection, and streaming APIs.
//!
//! This module contains the main runtime surface exposed by Rurr:
//! [`ApplicationBuilder`] assembles graphs and runtime resources, [`Application`]
//! executes them, and the streaming types expose lazy step-by-step consumption
//! without buffering terminal results up front.
//!
//! The runtime is provider-neutral by default. Persistence, tracking, lifecycle
//! hooks, and async context propagation are configured through explicit builder
//! inputs, which lets integration crates such as `rurr-otel` or the optional S3
//! tracking feature plug in without making core depend on their provider SDKs.
//! Sync and async applications are separated at build time so sync execution can
//! keep RAII cleanup guarantees while async execution can await async hooks and
//! context propagators explicitly.
//!
//! Halt-capable execution methods accept [`ExecutionOptions`] whose raw
//! selectors are resolved once during startup. Action-name selectors and
//! Burr-style `@tag:<tag>` selectors share the same halt precedence across run,
//! iterate, `stream_result`, and `stream_iterate` APIs.

mod api;
pub(crate) mod build;
pub(crate) mod builder;
pub(crate) mod context;
mod execution_options;
mod graph_view;
pub(crate) mod halt_controls;
pub(crate) mod initialize_from_spec;
pub(crate) mod resources;
pub(crate) mod session;
pub(crate) mod state_meta;
pub(crate) mod step_txn;
pub(crate) mod streaming;
pub(crate) mod tracker_spec;
pub(crate) mod transaction;
pub(crate) mod types;

pub use builder::{ApplicationBuilder, ApplicationError};
pub use context::{ApplicationContext, ParentPointer};
pub use execution_options::ExecutionOptions;
pub use graph_view::ApplicationGraph;
pub use initialize_from_spec::InitializeFromSpec;
pub(crate) use resources::RuntimeResources;
pub use session::ExecutionSession;
pub use step_txn::ExecutedAction as AsyncStepExecutedAction;
pub use streaming::{
    AStreamIterate, AStreamResult, AStreamStepHandle, ExecutedAction, StreamIterate, StreamResult,
    StreamStepHandle,
};
pub use tracker_spec::TrackerSpec;
pub use transaction::{adjust_single_step_output, normalize_single_step_output, SingleStepOutput};
pub use types::{Application, RunOutput, StepOutput, Tracker};
