use super::*;
use super::{actions::*, assertions::*, fixtures::*, graphs::*, hooks::*, persistence::*};
use rurr_core::{application::ParentPointer, graph::Graph, lifecycle::LifecycleError};
use rurr_persistence::{AsyncBaseStateLoader, PersistedStateData, PersistenceError};
use tokio::sync::{oneshot, Notify};
use tokio::time::timeout;

const INTENTIONAL_CHILD_REGISTRATION_FAILURE: &str = "intentional_child_registration_failure";

#[derive(Debug)]
struct FailingAsyncChildRegistrationHook {
    failing_app_id: String,
    child_app_ids: Mutex<Vec<String>>,
}

impl FailingAsyncChildRegistrationHook {
    fn new(failing_app_id: String) -> Self {
        Self {
            failing_app_id,
            child_app_ids: Mutex::new(Vec::new()),
        }
    }

    fn child_app_ids(&self) -> Vec<String> {
        self.child_app_ids
            .lock()
            .expect("child_app_ids lock should not be poisoned")
            .clone()
    }
}

#[async_trait::async_trait]
impl AsyncLifecycleAdapter for FailingAsyncChildRegistrationHook {
    async fn register_child_application(
        &self,
        child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.child_app_ids
            .lock()
            .expect("child_app_ids lock should not be poisoned")
            .push(child_app_id.to_string());
        if child_app_id == self.failing_app_id {
            return Err(LifecycleError::hook_failed(
                "register_child_application_async",
                INTENTIONAL_CHILD_REGISTRATION_FAILURE,
            ));
        }
        Ok(())
    }
}

#[derive(Debug)]
struct BlockingAsyncStateLoader {
    started: Arc<Notify>,
    release: Arc<Notify>,
}

impl BlockingAsyncStateLoader {
    fn new(started: Arc<Notify>, release: Arc<Notify>) -> Self {
        Self { started, release }
    }
}

#[async_trait::async_trait]
impl AsyncBaseStateLoader for BlockingAsyncStateLoader {
    async fn load(
        &self,
        _partition_key: Option<&str>,
        _app_id: Option<&str>,
        _sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.started.notify_one();
        self.release.notified().await;
        Ok(None)
    }

    async fn list_app_ids(
        &self,
        _partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        Ok(Vec::new())
    }
}

#[tokio::test]
async fn async_parallel_child_commit_failure_runs_child_async_post_step_hooks() {
    let recorder = Arc::new(StepPostRecorder::default());
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = recorder.clone();
    let async_hook: Arc<dyn AsyncLifecycleAdapter> = recorder.clone();
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![async_hook]);
    let persister: Arc<dyn AsyncBaseStatePersister> = Arc::new(AsyncFailingCommitPersister);

    let child_graph = runnable_graph_from_action(
        "child_async",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_async(|_state, _ctx| async move {
                sleep(Duration::from_millis(5)).await;
                map_from_pairs([("output", json!(1))])
            })
            .expect("action should build"),
    );
    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![
                SubGraphTask::new(child_graph.clone(), State::default(), "0-0"),
                SubGraphTask::new(child_graph.clone(), State::default(), "1-0"),
            ])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = parallel_parent_builder_with_state_and_hooks(
        state_from_pairs([("sentinel", json!(1))]),
        action,
        hooks,
    )
    .with_async_persister(persister)
    .expect("async state persister spec should configure")
    .abuild()
    .await
    .expect("application should build");

    let error = app
        .astep(None)
        .await
        .expect_err("astep should fail when child commit save fails");

    assert!(
        error
            .to_string()
            .contains(INTENTIONAL_PARALLEL_COMMIT_FAILURE),
        "error should include commit failure marker: {error}"
    );
    assert_eq!(app.state().get("sentinel"), Some(&json!(1)));
    assert!(!app.state().contains_key("__SEQUENCE_ID"));
    assert!(!app.state().contains_key("__PRIOR_STEP"));
    assert_eq!(
        recorder.sync_post_run_step.load(Ordering::SeqCst),
        3,
        "expected sync post_run_step for parent + both children"
    );
    assert_eq!(
        recorder.async_post_run_step.load(Ordering::SeqCst),
        3,
        "expected async post_run_step for parent + both children"
    );

    let async_records = recorder.async_records();
    assert_eq!(
        async_records.len(),
        3,
        "expected parent + both child async records"
    );
    assert!(
        async_records.iter().any(|(app_id, exception)| {
            app_id == "parent-app"
                && exception
                    .as_deref()
                    .is_some_and(|value| value.contains(INTENTIONAL_PARALLEL_COMMIT_FAILURE))
        }),
        "parent async post_run_step should include commit failure exception: {async_records:?}"
    );
    for expected_child_app_id in [
        stable_child_app_id("parent-app", "0-0"),
        stable_child_app_id("parent-app", "1-0"),
    ] {
        assert!(
            async_records.iter().any(|(app_id, exception)| {
                app_id == &expected_child_app_id
                    && exception
                        .as_deref()
                        .is_some_and(|value| value.contains(INTENTIONAL_PARALLEL_COMMIT_FAILURE))
            }),
            "child async post_run_step should include commit failure exception: {async_records:?}"
        );
    }
}

#[tokio::test]
async fn async_parallel_registration_failure_still_runs_already_registered_child() {
    let post_recorder = Arc::new(StepPostRecorder::default());
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = post_recorder.clone();
    let async_post_hook: Arc<dyn AsyncLifecycleAdapter> = post_recorder.clone();
    let failing_registration = Arc::new(FailingAsyncChildRegistrationHook::new(
        stable_child_app_id("parent-app", "1-0"),
    ));
    let failing_registration_hook: Arc<dyn AsyncLifecycleAdapter> = failing_registration.clone();
    let hooks = LifecycleAdapterSet::new(
        vec![sync_hook],
        vec![async_post_hook, failing_registration_hook],
    );

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![
                constant_output_async_child_graph("child_a", 1),
                constant_output_async_child_graph("child_b", 2),
            ],
            Arc::new(|state, _ctx| Ok(state.clone())),
        ),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );
    let mut app = parallel_parent_builder_with_hooks(action, hooks)
        .abuild()
        .await
        .expect("application should build");

    let error = app
        .astep(None)
        .await
        .expect_err("astep should fail when child registration fails");

    assert!(
        error
            .to_string()
            .contains(INTENTIONAL_CHILD_REGISTRATION_FAILURE),
        "error should include the registration failure marker: {error}"
    );
    assert_eq!(
        failing_registration.child_app_ids(),
        vec![
            stable_child_app_id("parent-app", "0-0"),
            stable_child_app_id("parent-app", "1-0"),
        ],
        "both child registration attempts should be observed"
    );
    assert_eq!(
        post_recorder.sync_post_run_step.load(Ordering::SeqCst),
        2,
        "expected sync post_run_step for parent + already-registered child"
    );
    assert_eq!(
        post_recorder.async_post_run_step.load(Ordering::SeqCst),
        2,
        "expected async post_run_step for parent + already-registered child"
    );

    let async_records = post_recorder.async_records();
    assert!(
        async_records.iter().any(|(app_id, exception)| {
            app_id == &stable_child_app_id("parent-app", "0-0") && exception.is_none()
        }),
        "first child should have run to completion after registering successfully: {async_records:?}"
    );
    assert!(
        async_records.iter().any(|(app_id, exception)| {
            app_id == "parent-app"
                && exception
                    .as_deref()
                    .is_some_and(|value| value.contains(INTENTIONAL_CHILD_REGISTRATION_FAILURE))
        }),
        "parent async post_run_step should include the child registration failure: {async_records:?}"
    );
    assert!(
        !async_records
            .iter()
            .any(|(app_id, _)| app_id == &stable_child_app_id("parent-app", "1-0")),
        "failing child should not emit post_run_step because it never entered execution: {async_records:?}"
    );
}

#[tokio::test]
async fn async_parallel_execution_overlaps_sibling_run_with_blocked_build() {
    let build_started = Arc::new(Notify::new());
    let release_build = Arc::new(Notify::new());
    let (fast_child_tx, fast_child_rx) = oneshot::channel();
    let fast_child_tx = Arc::new(Mutex::new(Some(fast_child_tx)));

    let blocked_loader = Arc::new(BlockingAsyncStateLoader::new(
        Arc::clone(&build_started),
        Arc::clone(&release_build),
    ));
    let blocked_graph = constant_output_async_child_graph("blocked_child", 1);
    let fast_graph = runnable_graph_from_action(
        "fast_child",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_async(move |_state, _ctx| {
                let fast_child_tx = Arc::clone(&fast_child_tx);
                async move {
                    if let Some(sender) = fast_child_tx
                        .lock()
                        .expect("fast-child sender lock should not be poisoned")
                        .take()
                    {
                        let _ = sender.send(());
                    }
                    map_from_pairs([("output", json!(2))])
                }
            })
            .expect("fast child action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![
                SubGraphTask::new(blocked_graph.clone(), State::default(), "0-0")
                    .with_state_initializer(StateLoaderRef::async_loader(blocked_loader.clone())),
                SubGraphTask::new(fast_graph.clone(), State::default(), "1-0"),
            ])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app = parallel_parent_builder_with_hooks(action, LifecycleAdapterSet::default())
        .abuild()
        .await
        .expect("application should build");

    let control = async {
        timeout(Duration::from_secs(1), build_started.notified())
            .await
            .expect("blocked child build should start");
        let fast_child_completion = timeout(Duration::from_secs(1), fast_child_rx).await;
        release_build.notify_waiters();
        fast_child_completion
    };

    let (fast_child_completion, step_result) = tokio::join!(control, app.astep(None));

    let step = step_result
        .expect("astep should succeed")
        .expect("parallel action should execute");

    assert!(
        fast_child_completion.is_ok(),
        "fast child should complete while sibling build remains blocked"
    );
    assert_eq!(child_i64_values_in_state(&step.state, "output"), vec![1, 2]);
}

#[tokio::test]
async fn async_parallel_children_inherit_async_state_persister() {
    let recording_persister = Arc::new(AsyncRecordingKeyPersister::default());
    let persister_trait: Arc<dyn AsyncBaseStatePersister> = recording_persister.clone();

    let graphs = vec![
        constant_output_async_child_graph("child_a", 1),
        constant_output_async_child_graph("child_b", 2),
    ];

    let action = ParallelMap::new(
        ParallelTaskSource::graphs(graphs, Arc::new(|state, _ctx| Ok(state.clone()))),
        vec![],
        vec![],
        vec![],
        CascadeMode::None,
    );
    let mut app = parallel_parent_builder_with_hooks(action, LifecycleAdapterSet::default())
        .with_async_persister(persister_trait)
        .expect("async state persister spec should configure")
        .abuild()
        .await
        .expect("async application should build");

    let _ = app
        .astep(None)
        .await
        .expect("step should succeed")
        .expect("parallel action should execute");

    let saved_keys = recording_persister.saved_keys().await;
    assert!(
        saved_keys.iter().any(|(app_id, _)| app_id == "parent-app"),
        "parent app save should be present: {saved_keys:?}"
    );

    let child_app_ids: BTreeSet<String> = saved_keys
        .into_iter()
        .filter(|(app_id, _)| app_id != "parent-app")
        .map(|(app_id, _)| app_id)
        .collect();
    assert_eq!(child_app_ids.len(), 2);
    assert!(
        child_app_ids.iter().all(|app_id| is_lower_hex_64(app_id)),
        "child app ids should be deterministic hashes: {child_app_ids:?}"
    );
}

#[test]
fn runnable_graph_build_application_sync_restores_public_builder() {
    let graph = runnable_graph_from_action(
        "child_sync",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(7))]))
            .expect("action should build"),
    );

    let mut app = graph
        .build_application_sync(
            State::default(),
            "child-sync-app".to_string(),
            Some("pk".to_string()),
            None,
            LifecycleAdapterSet::default(),
            None,
        )
        .expect("application should build");

    let output = app.run().expect("run should succeed");
    assert_eq!(output.state.get("output"), Some(&json!(7)));
    assert_eq!(app.entrypoint(), "child_sync");
}

#[tokio::test]
async fn runnable_graph_build_application_async_restores_public_builder() {
    let graph = runnable_graph_from_action(
        "child_async",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_async(|_state, _ctx| async move { map_from_pairs([("output", json!(9))]) })
            .expect("action should build"),
    );

    let mut app = graph
        .build_application_async(
            State::default(),
            "child-async-app".to_string(),
            Some("pk".to_string()),
            None,
            LifecycleAdapterSet::default(),
            None,
        )
        .await
        .expect("application should build");

    let output = app.arun().await.expect("run should succeed");
    assert_eq!(output.state.get("output"), Some(&json!(9)));
    assert_eq!(app.entrypoint(), "child_async");
}

#[test]
fn with_parallel_executor_is_behaviorally_used_for_sync_parallel_children() {
    let executor = Arc::new(RecordingParallelExecutor::default());
    let executor_trait: Arc<dyn ParallelExecutor> = executor.clone();

    let child_graph = runnable_graph_from_action(
        "child_sync",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_sync(|_state, _ctx| map_from_pairs([("output", json!(1))]))
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![
                SubGraphTask::new(child_graph.clone(), State::default(), "0-0"),
                SubGraphTask::new(child_graph.clone(), State::default(), "1-0"),
            ])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = parallel_parent_builder(action)
        .with_parallel_executor(executor_trait)
        .expect("parallel executor should configure")
        .build()
        .expect("application should build");

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        child_i64_values_in_state(&step.state, "output"),
        vec![99, 99]
    );
    assert_eq!(
        executor.sync_batches(),
        vec![vec!["0-0".to_string(), "1-0".to_string()]]
    );
}

#[tokio::test]
async fn with_parallel_executor_is_behaviorally_used_for_async_parallel_children() {
    let executor = Arc::new(RecordingParallelExecutor::default());
    let executor_trait: Arc<dyn ParallelExecutor> = executor.clone();

    let child_graph = runnable_graph_from_action(
        "child_async",
        FunctionActionBuilder::new()
            .writes(["output"])
            .build_async(|_state, _ctx| async move { map_from_pairs([("output", json!(1))]) })
            .expect("action should build"),
    );

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![
                SubGraphTask::new(child_graph.clone(), State::default(), "0-0"),
                SubGraphTask::new(child_graph.clone(), State::default(), "1-0"),
            ])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app = parallel_parent_builder(action)
        .with_parallel_executor(executor_trait)
        .expect("parallel executor should configure")
        .build()
        .expect("application should build");

    let step = app
        .astep(None)
        .await
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        child_i64_values_in_state(&step.state, "output"),
        vec![123, 123]
    );
    assert_eq!(
        executor.async_batches(),
        vec![vec!["0-0".to_string(), "1-0".to_string()]]
    );
}

#[test]
fn delegating_parallel_executor_preserves_child_resources_sync() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let parent_project = "parallelism_delegating_executor_parent_sync_contract";
    let child_project = "parallelism_delegating_executor_child_sync_contract";
    let parent_tracker = Arc::new(
        LocalTrackingClient::new(parent_project, &storage_root)
            .expect("parent tracking client should initialize"),
    );
    let child_tracker = Arc::new(
        LocalTrackingClient::new(child_project, &storage_root)
            .expect("child tracking client should initialize"),
    );
    let parent_tracker_trait: Arc<dyn Tracker> = parent_tracker.clone();
    let child_tracker_trait: Arc<dyn Tracker> = child_tracker.clone();
    let child_persister = Arc::new(RecordingKeyPersister::default());
    child_persister
        .save(
            Some("pk"),
            "child-delegated-sync",
            41,
            "child_delegating_executor_resume_sync",
            map_from_pairs([("seed", json!(41))]),
            PersistedStateStatus::Failed,
        )
        .expect("seed child save should succeed");

    let child_graph = sync_resume_probe_graph(
        "child_delegating_executor_default_sync",
        "child_delegating_executor_resume_sync",
    );
    let child_persister_for_task = child_persister.clone();

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                state_from_pairs([("seed", json!(5))]),
                "0-0",
            )
            .with_child_app_id("child-delegated-sync")
            .with_tracker(child_tracker_trait.clone())
            .with_state_persister(StatePersisterRef::sync(child_persister_for_task.clone()))
            .with_state_initializer(StateLoaderRef::sync(
                child_persister_for_task.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        false,
    );

    let mut app = parallel_parent_builder(action)
        .with_parallel_executor(Arc::new(DelegatingParallelExecutor))
        .expect("parallel executor should configure")
        .with_tracker(TrackerSpec::provided(parent_tracker_trait))
        .expect("tracker should configure")
        .build()
        .expect("application should build");

    parent_tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("parent app registration should succeed");

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(child_i64_values_in_state(&step.state, "output"), vec![42]);
    assert!(
        child_persister
            .saved_keys()
            .iter()
            .any(|(app_id, _)| app_id == "child-delegated-sync"),
        "delegating executor should preserve child persister wiring"
    );

    let parent_children_path = project_app_dir(&storage_root, parent_project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let parent_children = read_jsonl(&parent_children_path);
    assert_eq!(parent_children.len(), 1);
    assert_eq!(
        parent_children[0]["child"]["app_id"],
        json!("child-delegated-sync")
    );
    assert_eq!(parent_children[0]["event_type"], json!("spawn_start"));
    assert_eq!(parent_children[0]["child"]["partition_key"], json!("pk"));
    assert_child_tracker_registration_and_logs(
        &storage_root,
        child_project,
        "child-delegated-sync",
        "parent-app",
    );
}

#[tokio::test]
async fn delegating_parallel_executor_preserves_child_resources_async() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let parent_project = "parallelism_delegating_executor_parent_async_contract";
    let child_project = "parallelism_delegating_executor_child_async_contract";
    let parent_tracker = Arc::new(
        LocalTrackingClient::new(parent_project, &storage_root)
            .expect("parent tracking client should initialize"),
    );
    let child_tracker = Arc::new(
        LocalTrackingClient::new(child_project, &storage_root)
            .expect("child tracking client should initialize"),
    );
    let parent_tracker_trait: Arc<dyn Tracker> = parent_tracker.clone();
    let child_tracker_trait: Arc<dyn Tracker> = child_tracker.clone();
    let child_persister = Arc::new(AsyncRecordingKeyPersister::default());
    child_persister
        .save(
            Some("pk"),
            "child-delegated-async",
            41,
            "child_delegating_executor_resume_async",
            map_from_pairs([("seed", json!(41))]),
            PersistedStateStatus::Failed,
        )
        .await
        .expect("seed child save should succeed");

    let child_graph = async_resume_probe_graph(
        "child_delegating_executor_default_async",
        "child_delegating_executor_resume_async",
    );
    let child_persister_for_task = child_persister.clone();

    let action = ExplicitTaskAction::new(
        vec![],
        vec!["child_states".to_string()],
        vec![],
        Arc::new(move |_state: &State, _ctx: &ActionContext| {
            Ok(vec![SubGraphTask::new(
                child_graph.clone(),
                state_from_pairs([("seed", json!(5))]),
                "0-0",
            )
            .with_child_app_id("child-delegated-async")
            .with_tracker(child_tracker_trait.clone())
            .with_state_persister(StatePersisterRef::async_persister(
                child_persister_for_task.clone(),
            ))
            .with_state_initializer(StateLoaderRef::async_loader(
                child_persister_for_task.clone(),
            ))])
        }),
        Arc::new(|_parent_state: &State, child_states: Vec<State>| {
            Ok(ActionResult::new(
                IndexMap::new(),
                map_from_pairs([("child_states", child_states_value(&child_states))]),
            ))
        }),
        true,
    );

    let mut app = parallel_parent_builder(action)
        .with_parallel_executor(Arc::new(DelegatingParallelExecutor))
        .expect("parallel executor should configure")
        .with_tracker(TrackerSpec::provided(parent_tracker_trait))
        .expect("tracker should configure")
        .abuild()
        .await
        .expect("application should build");

    parent_tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("parent app registration should succeed");

    let step = app
        .astep(None)
        .await
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(child_i64_values_in_state(&step.state, "output"), vec![42]);
    assert!(
        child_persister
            .saved_keys()
            .await
            .iter()
            .any(|(app_id, _)| app_id == "child-delegated-async"),
        "delegating executor should preserve child persister wiring"
    );

    let parent_children_path = project_app_dir(&storage_root, parent_project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let parent_children = read_jsonl(&parent_children_path);
    assert_eq!(parent_children.len(), 1);
    assert_eq!(
        parent_children[0]["child"]["app_id"],
        json!("child-delegated-async")
    );
    assert_eq!(parent_children[0]["event_type"], json!("spawn_start"));
    assert_eq!(parent_children[0]["child"]["partition_key"], json!("pk"));
    assert_child_tracker_registration_and_logs(
        &storage_root,
        child_project,
        "child-delegated-async",
        "parent-app",
    );
}
