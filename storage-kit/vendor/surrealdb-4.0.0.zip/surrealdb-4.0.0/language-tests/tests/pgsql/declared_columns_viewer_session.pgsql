/**
[env]
namespace = true
database = true
imports = ["pgsql/_declared_columns_perms.surql"]
auth = { level = "viewer" }

[test]
reason = "A system user that may view the definitions of tables is told the columns a table declares: a name it does not have is an error"

[test.results]
request-error = "PostgreSQL SELECT lowering error: column \"nosuch\" does not exist"
*/

SELECT name, nosuch FROM declcol_acct;
