use super::*;
use indexmap::IndexMap;
use rurr_core::action::{ActionContext, ActionError, ActionResult, LocalAction};
use rurr_core::State;

#[derive(Clone, Copy)]
enum TracedActionMode {
    Sync,
    Async,
}

async fn assert_traced_action_writes_span_and_attribute_events_with_parent_metadata(
    storage_root: &std::path::Path,
    mode: TracedActionMode,
    project: &str,
    app_id: &str,
) {
    match mode {
        TracedActionMode::Sync => {
            let (_tracker, mut app) = registered_sync_app(
                project,
                storage_root,
                app_id,
                "counter",
                build_traced_sync_action(),
            );
            app.step(None).expect("step should succeed");
        }
        TracedActionMode::Async => {
            let (_tracker, mut app) = registered_async_app(
                project,
                storage_root,
                app_id,
                "counter",
                build_traced_async_action(),
            );
            app.astep(None).await.expect("astep should succeed");
        }
    }

    let (outer_name, inner_name, dependency, attribute_key) = match mode {
        TracedActionMode::Sync => ("increment", "inner", "counter_dep", "counter"),
        TracedActionMode::Async => (
            "increment_async",
            "inner_async",
            "counter_dep_async",
            "counter_async",
        ),
    };

    let log_lines = read_app_log(storage_root, project, app_id);
    let (begin_spans, end_spans, attributes) = span_events(&log_lines);

    assert_eq!(begin_spans.len(), 2, "expected outer + inner span");
    assert_eq!(end_spans.len(), 2, "expected outer + inner end span");
    assert_eq!(attributes.len(), 1, "expected one attribute event");

    let outer = begin_spans
        .iter()
        .find(|span| span.span_name == outer_name)
        .expect("outer span should be present");
    let inner = begin_spans
        .iter()
        .find(|span| span.span_name == inner_name)
        .expect("inner span should be present");

    assert_eq!(outer.parent_span_id, None);
    assert_eq!(outer.span_dependencies, Vec::<String>::new());
    assert_eq!(
        inner.parent_span_id.as_deref(),
        Some(outer.span_id.as_str())
    );
    assert_eq!(inner.span_dependencies, vec![dependency.to_string()]);
    let explicit_attribute = attributes
        .iter()
        .find(|attribute| attribute.key == attribute_key)
        .expect("explicit traced attribute should be present");
    assert_eq!(
        explicit_attribute.span_id.as_deref(),
        Some(inner.span_id.as_str())
    );
}

fn register_child_applications_with_parent(
    tracker: &LocalTrackingClient,
    graph: &rurr_core::ApplicationGraph,
) {
    for (app_id, parent_pointer, spawning_parent_pointer) in [
        (
            "fork-child",
            Some(ParentPointer {
                app_id: "parent-app".to_string(),
                partition_key: Some("pk".to_string()),
                sequence_id: Some(5),
            }),
            None,
        ),
        (
            "spawn-child",
            None,
            Some(ParentPointer {
                app_id: "parent-app".to_string(),
                partition_key: Some("pk".to_string()),
                sequence_id: Some(7),
            }),
        ),
    ] {
        tracker
            .register_application(
                app_id,
                Some("pk"),
                graph,
                parent_pointer.clone(),
                spawning_parent_pointer.clone(),
            )
            .expect("child registration should succeed");
        tracker
            .register_application(
                app_id,
                Some("pk"),
                graph,
                parent_pointer,
                spawning_parent_pointer,
            )
            .expect("child re-registration should succeed");
    }
}

fn assert_begin_entry_input_filtering(storage_root: &std::path::Path, include_reserved: bool) {
    let (project, app_id) = if include_reserved {
        ("test_filter_inputs", "filter-app")
    } else {
        ("test_filter_inputs_valid", "filter-app-valid")
    };
    let (_tracker, mut app) = registered_sync_app(
        project,
        storage_root,
        app_id,
        "counter",
        build_delta_sync_action(),
    );

    let action_inputs = if include_reserved {
        map_from_pairs([
            ("delta", json!(1)),
            ("__context", json!("forged")),
            ("__tracer", json!("forged")),
        ])
    } else {
        map_from_pairs([("delta", json!(1))])
    };

    if include_reserved {
        let error = app
            .step(Some(action_inputs))
            .expect_err("reserved inputs should be rejected");
        assert!(matches!(
            error,
            ApplicationError::ReservedRuntimeInputKeys { keys }
                if keys == vec!["__context".to_string(), "__tracer".to_string()]
        ));

        let log_lines = read_app_log_if_exists(storage_root, project, app_id);
        assert!(
            !log_lines.iter().any(|line| line["type"] == "begin_entry"),
            "invalid reserved runtime inputs should fail before begin_entry logging"
        );
        return;
    }

    app.step(Some(action_inputs)).expect("step should succeed");
    let begin_inputs = read_jsonl(&app_log_path(storage_root, project, app_id))
        .into_iter()
        .find(|line| line["type"] == "begin_entry")
        .and_then(|line| line["inputs"].as_object().cloned())
        .expect("begin entry inputs should exist");
    assert_eq!(begin_inputs.get("delta"), Some(&json!(1)));
    assert!(!begin_inputs.contains_key("__context"));
    assert!(!begin_inputs.contains_key("__tracer"));
}

#[test]
fn sync_run_writes_expected_tracking_files_and_entry_counts() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_application_tracks_end_to_end";
    let (_tracker, mut app) = registered_sync_app(
        project,
        &storage_root,
        "sync-app",
        "counter",
        build_single_step_sync_action(),
    );

    app.run().expect("sync run should succeed");

    let app_dir = app_dir(&storage_root, project, "sync-app");
    let graph_path = app_dir.join(LocalTrackingClient::GRAPH_FILENAME);
    let metadata_path = app_dir.join(LocalTrackingClient::METADATA_FILENAME);
    let log_path = app_dir.join(LocalTrackingClient::LOG_FILENAME);

    assert!(graph_path.exists(), "graph.json should exist");
    assert!(metadata_path.exists(), "metadata.json should exist");
    assert!(log_path.exists(), "log.jsonl should exist");

    let graph = read_json(&graph_path);
    assert_eq!(graph["type"], "application");
    assert_eq!(graph["entrypoint"], "counter");

    let log_lines = read_app_log(&storage_root, project, "sync-app");
    assert_log_event_counts(&log_lines, &[("begin_entry", 1), ("end_entry", 1)]);
    assert!(log_lines
        .iter()
        .all(|line| line.get("exception").is_none() || line["exception"].is_null()));
}

#[test]
fn register_application_creates_empty_log_for_create_only_apps() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_tracking_create_only_log";
    let (_tracker, _app) = registered_sync_app(
        project,
        &storage_root,
        "create-only-app",
        "counter",
        build_single_step_sync_action(),
    );

    let app_dir = app_dir(&storage_root, project, "create-only-app");
    let graph_path = app_dir.join(LocalTrackingClient::GRAPH_FILENAME);
    let metadata_path = app_dir.join(LocalTrackingClient::METADATA_FILENAME);
    let log_path = app_dir.join(LocalTrackingClient::LOG_FILENAME);

    assert!(graph_path.exists(), "graph.json should exist");
    assert!(metadata_path.exists(), "metadata.json should exist");
    assert!(log_path.exists(), "log.jsonl should exist");
    assert_eq!(
        fs::read_to_string(log_path).expect("log.jsonl should be readable"),
        ""
    );
}

#[test]
fn post_run_step_without_state_fails_without_end_entry() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_tracking_missing_post_step_state";
    let app_id = "missing-state-app";
    let tracker = tracker(project, &storage_root);
    let template_app = build_counter_template_app("template");
    tracker
        .register_application(app_id, Some("pk"), template_app.graph(), None, None)
        .expect("registration should create required artifacts");

    let context = PostStepContext::new("counter", 0, 0, SystemTime::UNIX_EPOCH).with_app_id(app_id);
    let error = SyncLifecycleAdapter::post_run_step(tracker.as_ref(), &context)
        .expect_err("tracking post-step without state should fail");
    assert!(
        error
            .to_string()
            .contains("tracking end_entry requires committed post-step state"),
        "error should explain the missing state requirement: {error}"
    );

    let log_lines = read_app_log_if_exists(&storage_root, project, app_id);
    assert!(
        log_lines.iter().all(|line| line["type"] != "end_entry"),
        "failed tracking post-step should not write an end_entry"
    );
}

#[test]
fn register_application_fails_closed_when_action_source_is_unavailable() {
    #[derive(Clone)]
    struct SourcelessAction;

    impl LocalAction for SourcelessAction {
        fn name(&self) -> Option<&str> {
            Some("source-less")
        }

        fn reads(&self) -> &[String] {
            &[]
        }

        fn writes(&self) -> &[String] {
            &[]
        }

        fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
            assert_eq!(name.into(), "source-less");
            Ok(self.clone())
        }

        fn run(&self, _state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
            Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
        }
    }

    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_tracking_requires_source";
    let tracker = tracker(project, &storage_root);
    let app = build_sync_app(
        "source-less-app",
        "source-less",
        SourcelessAction,
        LifecycleAdapterSet::default(),
    );

    let error = tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect_err("tracking registration should fail without provable source");
    assert!(matches!(
        error,
        TrackingError::MissingActionSource { action } if action == "source-less"
    ));
    assert!(
        !app_dir(&storage_root, project, "source-less-app")
            .join(LocalTrackingClient::GRAPH_FILENAME)
            .exists(),
        "graph.json should not be written when tracking cannot prove action source"
    );
    assert!(
        !app_dir(&storage_root, project, "source-less-app")
            .join(LocalTrackingClient::LOG_FILENAME)
            .exists(),
        "log.jsonl should not be written when tracking cannot prove action source"
    );
}

#[test]
fn traced_action_writes_span_and_attribute_events_with_parent_metadata() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    futures::executor::block_on(
        assert_traced_action_writes_span_and_attribute_events_with_parent_metadata(
            &storage_root,
            TracedActionMode::Sync,
            "test_tracking_span_events",
            "trace-app",
        ),
    );
}

#[test]
fn traced_action_with_foreign_factory_scope_still_writes_span_and_attribute_events() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_tracking_span_events_cross_factory";
    let (_tracker, mut app) = registered_sync_app(
        project,
        &storage_root,
        "trace-app-cross-factory",
        "counter",
        build_cross_factory_routed_sync_action(),
    );

    app.step(None).expect("step should succeed");

    let log_lines = read_app_log(&storage_root, project, "trace-app-cross-factory");
    let (begin_spans, end_spans, attributes) = span_events(&log_lines);

    assert_eq!(
        begin_spans.len(),
        1,
        "expected exactly one span begin event"
    );
    assert_eq!(end_spans.len(), 1, "expected exactly one span end event");
    assert_eq!(attributes.len(), 1, "expected exactly one attribute event");

    let outer = begin_spans
        .iter()
        .find(|span| span.span_name == "cross_factory_outer")
        .expect("outer span should be present");
    let end = end_spans
        .iter()
        .find(|span| span.span_id == outer.span_id)
        .expect("end span should match begin span");
    let attribute = attributes
        .iter()
        .find(|attribute| attribute.key == "counter_cross_factory")
        .expect("attribute should be present");

    assert_eq!(end.span_id, outer.span_id);
    assert_eq!(attribute.span_id.as_deref(), Some(outer.span_id.as_str()));
}

#[test]
fn failed_steps_return_real_rurr_errors_and_record_exact_exception_text() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_application_tracks_end_to_end_broken";
    let (_tracker, mut app) = registered_sync_app(
        project,
        &storage_root,
        "broken-app",
        "broken",
        broken_action(),
    );

    let error = app.run().expect_err("broken action should fail");
    assert!(matches!(
        &error,
        ApplicationError::Action(ActionError::Internal { message }) if message == "Broken"
    ));

    let log_lines = read_app_log(&storage_root, project, "broken-app");
    let end_entry = log_lines
        .iter()
        .rev()
        .find(|line| line["type"] == "end_entry")
        .expect("end_entry should be present");
    let exception = end_entry["exception"]
        .as_str()
        .expect("end_entry exception should be present");
    assert_eq!(exception, error.to_string());
    assert!(
        !exception.contains("Traceback"),
        "Rurr failure logging should not invent Python traceback text: {exception}"
    );
    let sequence_id = end_entry["state"]
        .get("__SEQUENCE_ID")
        .and_then(Value::as_i64)
        .expect("failed end_entry.state must include __SEQUENCE_ID");
    assert_eq!(sequence_id, 0);
}

#[tokio::test]
async fn async_traced_action_writes_span_and_attribute_events_with_parent_metadata() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    assert_traced_action_writes_span_and_attribute_events_with_parent_metadata(
        &storage_root,
        TracedActionMode::Async,
        "test_tracking_span_events_async",
        "trace-app-async",
    )
    .await;
}

#[test]
fn begin_entry_input_filtering_matches_valid_and_reserved_paths() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    for include_reserved in [true, false] {
        assert_begin_entry_input_filtering(&storage_root, include_reserved);
    }
}

#[test]
fn register_application_records_fork_spawn_metadata_and_children_events() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_parent_child_links";
    let tracker = tracker(project, &storage_root);

    let app = build_sync_app(
        "graph-template",
        "counter",
        build_single_step_sync_action(),
        LifecycleAdapterSet::default(),
    );
    let graph = app.graph().clone();

    tracker
        .register_application("parent-app", Some("pk"), &graph, None, None)
        .expect("parent registration should succeed");

    register_child_applications_with_parent(tracker.as_ref(), &graph);

    let fork_metadata_path = project_app_dir(&storage_root, project, "fork-child")
        .join(LocalTrackingClient::METADATA_FILENAME);
    let spawn_metadata_path = project_app_dir(&storage_root, project, "spawn-child")
        .join(LocalTrackingClient::METADATA_FILENAME);

    let fork_metadata: ApplicationMetadataModel =
        serde_json::from_str(&fs::read_to_string(fork_metadata_path).expect("metadata readable"))
            .expect("metadata should parse");
    let spawn_metadata: ApplicationMetadataModel =
        serde_json::from_str(&fs::read_to_string(spawn_metadata_path).expect("metadata readable"))
            .expect("metadata should parse");

    assert_eq!(
        fork_metadata
            .parent_pointer
            .as_ref()
            .expect("fork parent pointer should exist")
            .app_id,
        "parent-app"
    );
    assert_eq!(
        spawn_metadata
            .spawning_parent_pointer
            .as_ref()
            .expect("spawning pointer should exist")
            .app_id,
        "parent-app"
    );

    let children_path = project_app_dir(&storage_root, project, "parent-app")
        .join(LocalTrackingClient::CHILDREN_FILENAME);
    let children: Vec<ChildApplicationModel> = read_jsonl(&children_path)
        .into_iter()
        .map(|line| serde_json::from_value(line).expect("child entry should parse"))
        .collect();

    let child_ids: BTreeSet<String> = children
        .iter()
        .map(|child| child.child.app_id.clone())
        .collect();
    let event_types: BTreeSet<String> = children
        .iter()
        .map(|child| child.event_type.clone())
        .collect();

    assert_eq!(
        child_ids,
        BTreeSet::from(["fork-child".to_string(), "spawn-child".to_string()])
    );
    assert_eq!(
        event_types,
        BTreeSet::from(["fork".to_string(), "spawn_start".to_string()])
    );
    let sequence_ids: BTreeSet<Option<u64>> =
        children.iter().map(|child| child.sequence_id).collect();
    assert_eq!(sequence_ids, BTreeSet::from([Some(5), Some(7)]));
    let child_partitions: BTreeSet<Option<String>> = children
        .iter()
        .map(|child| child.child.partition_key.clone())
        .collect();
    assert_eq!(child_partitions, BTreeSet::from([Some("pk".to_string())]));

    let fork_events = children
        .iter()
        .filter(|child| child.child.app_id == "fork-child" && child.event_type == "fork")
        .count();
    let spawn_events = children
        .iter()
        .filter(|child| child.child.app_id == "spawn-child" && child.event_type == "spawn_start")
        .count();
    assert_eq!(fork_events, 1);
    assert_eq!(spawn_events, 1);
    assert_eq!(children.len(), 2);
}
