use crate::{tuple_to_persisted_state, PersistedRowTuple};
use crate::{PersistedStateData, PersistenceError};
use sqlx::{ColumnIndex, Decode, FromRow, Row, Type};

/// SQLx row model for persisted-state query results.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PersistedStateRow {
    /// Normalized partition key.
    pub partition_key: String,
    /// Application identifier.
    pub app_id: String,
    /// Persisted sequence identifier.
    pub sequence_id: i64,
    /// Persisted workflow position.
    pub position: String,
    /// Serialized state JSON.
    pub state: String,
    /// Optional creation timestamp.
    pub created_at: Option<String>,
    /// Persisted status string.
    pub status: String,
}

impl<'r, R> FromRow<'r, R> for PersistedStateRow
where
    R: Row,
    &'static str: ColumnIndex<R>,
    String: Decode<'r, R::Database> + Type<R::Database>,
    i64: Decode<'r, R::Database> + Type<R::Database>,
    Option<String>: Decode<'r, R::Database> + Type<R::Database>,
{
    fn from_row(row: &'r R) -> Result<Self, sqlx::Error> {
        Ok(Self {
            partition_key: row.try_get("partition_key")?,
            app_id: row.try_get("app_id")?,
            sequence_id: row.try_get("sequence_id")?,
            position: row.try_get("position")?,
            state: row.try_get("state")?,
            created_at: row.try_get("created_at")?,
            status: row.try_get("status")?,
        })
    }
}

impl PersistedStateRow {
    /// Converts the row model into the tuple representation shared by helper code.
    pub fn into_tuple(self) -> PersistedRowTuple {
        (
            self.partition_key,
            self.app_id,
            self.sequence_id,
            self.position,
            self.state,
            self.created_at,
            self.status,
        )
    }

    /// Converts the row model into the public persisted-state structure.
    pub fn into_persisted_state(self) -> Result<PersistedStateData, PersistenceError> {
        tuple_to_persisted_state(self.into_tuple())
    }
}

#[cfg(test)]
mod tests {
    use super::PersistedStateRow;
    use crate::{PersistedStateStatus, PersistenceError};

    #[test]
    fn persisted_state_row_converts_with_existing_tuple_logic() {
        let row = PersistedStateRow {
            partition_key: "partition".to_string(),
            app_id: "app_id".to_string(),
            sequence_id: 42,
            position: "position".to_string(),
            state: "{\"key\":\"value\"}".to_string(),
            created_at: Some("2026-03-09 00:00:00".to_string()),
            status: "failed".to_string(),
        };

        let converted = row.into_persisted_state().expect("row should convert");

        assert_eq!(converted.partition_key.as_deref(), Some("partition"));
        assert_eq!(converted.app_id, "app_id");
        assert_eq!(converted.sequence_id, 42);
        assert_eq!(
            converted
                .state
                .as_ref()
                .and_then(|state| state.get("key"))
                .and_then(|value| value.as_str()),
            Some("value")
        );
        assert_eq!(converted.status, PersistedStateStatus::Failed);
    }

    #[test]
    fn persisted_state_row_conversion_keeps_status_error_mapping() {
        let row = PersistedStateRow {
            partition_key: "partition".to_string(),
            app_id: "app_id".to_string(),
            sequence_id: 1,
            position: "position".to_string(),
            state: "{}".to_string(),
            created_at: None,
            status: "unknown".to_string(),
        };

        let error = row
            .into_persisted_state()
            .expect_err("invalid status should fail");

        assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation { operation }
                if operation == "status_deserialization_failed"
        ));
    }
}
