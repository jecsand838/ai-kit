---
name: rurr-skill-catalog-maintenance
description: "Use when adding, editing, installing, validating, or closing out Rurr repo-local skills under .agents/skills, including SKILL.md frontmatter, agents/openai.yaml metadata, trigger/forward-testing, manifest freshness, and final gates."
---

# Rurr Skill Catalog Maintenance

Use this skill when the Rurr repo-local skill catalog is created, edited, validated, or prepared for handoff.

## Quick start

Load, in order:

- `$skill-creator`
- `AGENTS.md`
- `.agents/skills/README.md`
- the touched skill `SKILL.md` files
- the touched `agents/openai.yaml` files
- `/Users/connorsanders/.codex/skills/.system/skill-creator/references/openai_yaml.md`

Use the official Codex Skills docs when changing discovery location, metadata policy, plugin packaging, or implicit invocation behavior.

## Install/update workflow

1. Keep repo skills under `.agents/skills/<skill-name>/`.
2. Use `init_skill.py` for new skills unless the folder already exists.
3. Keep each `SKILL.md` frontmatter to `name` and `description` only.
4. Put trigger conditions in `description`; put procedure in the body.
5. Include `agents/openai.yaml` with UI metadata and invocation policy.
6. Avoid `scripts/`, `references/`, and `assets/` unless repeated deterministic logic or large reusable context justifies them.
7. Update `.agents/skills/README.md` when the Rurr workflow catalog changes.
8. Refresh manifests only through `./scripts/fix_manifest_freshness.sh`.

## Metadata rules

- Folder name and frontmatter `name` must match exactly.
- `interface.default_prompt` must mention `$skill-name`.
- `policy.allow_implicit_invocation` should stay `true` for Rurr workflow skills unless forward-testing proves persistent unrelated triggering after description tightening.
- Quote string values in `agents/openai.yaml`.
- Do not add plugin packaging for repo-only Rurr skills.

## Validation checks

Run:

- `/Users/connorsanders/.codex/skills/.system/skill-creator/scripts/quick_validate.py <skill-folder>` for each new or edited skill
- a folder/frontmatter name match check
- a default-prompt `$skill-name` check
- a search for initializer placeholder markers
- a search for accidental extra sidecar docs such as readme, installation, quick-reference, or changelog files
- a routing-probe matrix for new or routing-sensitive skills: at minimum one positive prompt and one nearby negative prompt, plus an adjacent-skill positive prompt when overlap risk exists

## Acceptance checklist

Confirm before closeout:

- `SKILL.md` frontmatter contains only `name` and `description`
- `agents/openai.yaml` exists, still matches the skill, and quotes string values
- `interface.default_prompt` mentions the exact `$skill-name`
- no template placeholders or accidental sidecar docs remain
- validation ran for every touched skill
- routing probes were reviewed for any new or routing-sensitive skill
- manifests were refreshed through `./scripts/fix_manifest_freshness.sh` when tracked skill files changed

## Forward testing and routing probes

Forward-test complex or routing-sensitive changes with fresh contexts when the operator approves subagents.

Use realistic prompts, ask the tester to avoid edits, and require:

- selected skill or skills
- reason for each skill
- obvious Rurr skills intentionally not selected
- any confusing trigger language

Do not leak expected answers unless testing a specific revised behavior.

For routing-sensitive repo skills, use this decision order:

1. Start with a positive prompt that should clearly select the touched skill.
2. Add a nearby negative prompt that should stay with the closest neighboring workflow instead.
3. Add a positive prompt for the adjacent workflow when overlap is plausible.
4. Tighten `description` first if the routing is noisy or ambiguous.
5. Rerun the probes after wording changes before changing invocation policy.
6. Set `policy.allow_implicit_invocation` to `false` only when prompt probes still show persistent unrelated triggering after the wording pass.

## Manifest refresh

Stage intended `.agents/skills` changes before refreshing manifests because Rurr manifest generation is Git-index driven.

Then run:

1. `./scripts/fix_manifest_freshness.sh`
2. `git add MANIFEST.files.txt MANIFEST.sha256 FULL_CONTENT.md`
3. `./scripts/check.sh`

## Closeout

Report:

- skills added or edited
- metadata and policy changes
- validation commands and results
- forward-test prompts and outcomes
- manifest and gate results
- any remaining trigger-risk follow-up

## Default rules

- Prefer tighter descriptions over disabling implicit invocation.
- Keep each skill focused on one job.
- Prefer instructions over scripts unless deterministic tooling is repeatedly needed.
- Do not hand edit generated manifest files.
- Do not add extra skill-local docs that Codex will not need at execution time.

## Do not use this skill alone when

- the skill change also modifies Rurr runtime behavior: also use the relevant subsystem guardrail skill
- the task is final verification after skill edits: also use `$rurr-gate-closeout`
- the task is a branch-wide cleanup audit that merely mentions skills as context: also use `$rurr-branch-diff-reduction-audit`
