mod support;

use axum::body::Body;
use axum::http::{Request, StatusCode};
use rurr_tracking_server::schema::burr_compat_version;
use support::response_json::response_json;
use tower::ServiceExt;

#[tokio::test]
async fn default_app_exposes_ready_version_rich_app_spec_and_indexing_404() {
    let app = rurr_tracking_server::app().expect("default tracking server should build");

    let ready = app
        .clone()
        .oneshot(
            Request::builder()
                .uri("/ready")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("request should succeed");
    assert_eq!(ready.status(), StatusCode::OK);

    let version = app
        .clone()
        .oneshot(
            Request::builder()
                .uri("/api/v0/version")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("request should succeed");
    assert_eq!(version.status(), StatusCode::OK);
    let version_payload = response_json(version).await;
    assert_eq!(
        version_payload,
        serde_json::json!({ "version": burr_compat_version() })
    );

    let app_spec = app
        .clone()
        .oneshot(
            Request::builder()
                .uri("/api/v0/metadata/app_spec")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("request should succeed");
    assert_eq!(app_spec.status(), StatusCode::OK);
    let app_spec_payload = response_json(app_spec).await;
    assert_eq!(app_spec_payload["backend"], serde_json::json!("local"));
    assert_eq!(app_spec_payload["indexing"], serde_json::json!(false));
    assert_eq!(app_spec_payload["snapshotting"], serde_json::json!(false));
    assert_eq!(app_spec_payload["supports_demos"], serde_json::json!(false));
    assert_eq!(
        app_spec_payload["supports_annotations"],
        serde_json::json!(true)
    );

    let indexing = app
        .oneshot(
            Request::builder()
                .uri("/api/v0/indexing_jobs")
                .body(Body::empty())
                .unwrap(),
        )
        .await
        .expect("request should succeed");
    assert_eq!(indexing.status(), StatusCode::NOT_FOUND);
    let indexing_payload = response_json(indexing).await;
    assert!(
        indexing_payload["error"]
            .as_str()
            .is_some_and(|value| value.contains("indexing")),
        "unsupported indexing should return a descriptive json error"
    );
}
