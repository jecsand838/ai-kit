use super::SessionCore;
use crate::application::ApplicationError;

pub(super) fn stream_invariant(message: &'static str) -> ApplicationError {
    ApplicationError::StreamInvariantViolation { message }
}

pub(super) fn prefer_hook_error<T>(
    primary_result: Result<T, ApplicationError>,
    hook_result: Result<(), ApplicationError>,
) -> Result<T, ApplicationError> {
    match hook_result {
        Err(hook_error) => Err(hook_error),
        Ok(()) => primary_result,
    }
}

pub(super) fn prefer_hook_error_over_primary(
    primary_error: ApplicationError,
    hook_result: Result<(), ApplicationError>,
) -> ApplicationError {
    match hook_result {
        Err(hook_error) => hook_error,
        Ok(()) => primary_error,
    }
}

pub(super) fn combine_optional_primary_with_hook(
    primary_error: Option<ApplicationError>,
    hook_result: Result<(), ApplicationError>,
) -> Result<(), ApplicationError> {
    match hook_result {
        Err(hook_error) => Err(hook_error),
        Ok(()) => match primary_error {
            Some(primary_error) => Err(primary_error),
            None => Ok(()),
        },
    }
}

impl<'a> SessionCore<'a> {
    pub(super) fn close_with_deferred_abort_sync(&mut self) -> Result<(), ApplicationError> {
        if let Some(error) = self.take_deferred_abort_error() {
            return self.close_with_sync_precedence(Err(error));
        }
        self.close_with_sync_precedence(Ok(()))
    }

    pub(super) async fn close_with_deferred_abort_async(&mut self) -> Result<(), ApplicationError> {
        if let Some(error) = self.take_deferred_abort_error() {
            return self.close_with_async_precedence(Err(error)).await;
        }
        self.close_with_async_precedence(Ok(())).await
    }

    pub(super) fn close_with_sync_precedence<T>(
        &mut self,
        primary_result: Result<T, ApplicationError>,
    ) -> Result<T, ApplicationError> {
        prefer_hook_error(primary_result, self.close_session_sync())
    }

    pub(super) async fn close_with_async_precedence<T>(
        &mut self,
        primary_result: Result<T, ApplicationError>,
    ) -> Result<T, ApplicationError> {
        prefer_hook_error(primary_result, self.close_session_async().await)
    }
}
