use crate::admin_publish::{
    admin_publish_command, assert_unsafe_dist_dir_rejected, canonical_cli_target, workspace_root,
};
#[cfg(any(unix, windows))]
use crate::admin_publish::{install_dist_dir_symlink, remove_dist_dir_symlink};
#[cfg(any(unix, windows))]
use crate::workspace_snapshot::{copy_tracked_workspace, tempdir_in_workspace};
use rurr_testkit::command_fixture::run_command;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ProtectedDistDirCase {
    Root,
    Ancestor,
    CratesDir,
    GitDir,
}

impl ProtectedDistDirCase {
    fn dist_dir(self, workspace_root: &Path) -> PathBuf {
        match self {
            Self::Root => workspace_root.to_path_buf(),
            Self::Ancestor => workspace_root
                .parent()
                .expect("workspace root should have a parent directory")
                .to_path_buf(),
            Self::CratesDir => workspace_root.join("crates"),
            Self::GitDir => workspace_root.join(".git"),
        }
    }

    fn context(self) -> &'static str {
        match self {
            Self::Root => "admin publish should reject clearing the workspace root",
            Self::Ancestor => {
                "admin publish should reject clearing an ancestor of the workspace root"
            }
            Self::CratesDir => "admin publish should reject clearing workspace source directories",
            Self::GitDir => "admin publish should reject clearing git metadata directories",
        }
    }

    fn sentinel_path(self, workspace_root: &Path) -> PathBuf {
        match self {
            Self::Root | Self::Ancestor => workspace_root.join("Cargo.toml"),
            Self::CratesDir => workspace_root
                .join("crates")
                .join("rurr-cli")
                .join("Cargo.toml"),
            Self::GitDir => workspace_root.join(".git").join("HEAD"),
        }
    }
}

#[test]
fn admin_publish_rejects_protected_workspace_targets() {
    let workspace = workspace_root();
    let current_dir = workspace.join("crates").join("rurr-cli").join("src");

    for case in [
        ProtectedDistDirCase::Root,
        ProtectedDistDirCase::Ancestor,
        ProtectedDistDirCase::CratesDir,
        ProtectedDistDirCase::GitDir,
    ] {
        let sentinel = case.sentinel_path(&workspace);
        let sentinel_contents =
            fs::read_to_string(&sentinel).expect("protected sentinel should be readable");

        let mut command = admin_publish_command(
            &current_dir,
            &canonical_cli_target(&case.dist_dir(&workspace)),
        );
        let output = run_command(&mut command, "admin publish should run");

        assert_unsafe_dist_dir_rejected(&output, case.context());
        assert_eq!(
            fs::read_to_string(&sentinel).expect("sentinel should still exist"),
            sentinel_contents
        );
    }
}

#[cfg(any(unix, windows))]
#[test]
fn admin_publish_rejects_symlinked_dist_dir_target() {
    let scratch = tempfile::tempdir().expect("scratch dir should be created");
    let snapshot = tempdir_in_workspace("admin-publish-path-safety-");
    let workspace = workspace_root();
    copy_tracked_workspace(&workspace, snapshot.path());
    let current_dir = snapshot.path().join("crates").join("rurr-cli").join("src");
    let outside_dir = scratch.path().join("outside-dist");
    let outside_sentinel = outside_dir.join("keep.txt");
    let symlink_path = current_dir.join("dist-link");

    fs::create_dir_all(&outside_dir).expect("outside dir should be created");
    fs::write(&outside_sentinel, "sentinel").expect("outside sentinel should be written");
    install_dist_dir_symlink(&outside_dir, &symlink_path)
        .expect("dist-dir symlink should be created");

    let mut command = admin_publish_command(&current_dir, Path::new("dist-link"));
    let output = run_command(&mut command, "admin publish should run");

    assert_unsafe_dist_dir_rejected(
        &output,
        "admin publish should reject symlinked dist-dir targets",
    );
    assert_eq!(
        fs::read_to_string(&outside_sentinel).expect("outside sentinel should still exist"),
        "sentinel"
    );
    assert!(
        !outside_dir.join("rurr-ui").exists(),
        "ui artifacts should not be written through a symlinked dist-dir"
    );
    remove_dist_dir_symlink(&symlink_path).expect("dist-dir symlink should be removed");
    assert!(
        !symlink_path.exists(),
        "dist-dir symlink fixture should be removed before the test exits"
    );
}
