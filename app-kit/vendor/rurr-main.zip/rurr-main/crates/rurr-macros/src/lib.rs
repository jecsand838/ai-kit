//! Procedural macros for deriving Rurr action adapters from ordinary Rust
//! functions.
//!
//! The [`action`] macro generates a non-streaming `Action` implementation, and
//! [`streaming_action`] generates the owning stream-oriented variant. The macros
//! validate signatures during expansion so unsupported runtime shapes surface as
//! compile errors instead of hidden generated panics.
#![deny(missing_docs)]

mod expand;
mod model;
mod parse;
mod validate;

use crate::expand::{generate_action_tokens, generate_streaming_tokens};
use crate::model::{analyze_signature, SignatureModel};
use crate::parse::MacroArgs;
use crate::validate::{validate_action_return_type, validate_streaming_return_type};
use proc_macro::TokenStream;
use proc_macro2::TokenStream as TokenStream2;
use quote::quote;
use syn::{ItemFn, Signature};

/// Generates a non-streaming Rurr action type from a Rust function.
///
/// The macro validates the annotated function signature and emits a concrete
/// action adapter next to the original function. Generated adapters preserve
/// the declared reads, writes, inputs, optional inputs, and tags used by
/// `rurr-core` graph registration.
///
/// Typical usage:
/// `#[rurr_macros::action(reads = ["count"], writes = ["count"])]`.
#[proc_macro_attribute]
pub fn action(attr: TokenStream, item: TokenStream) -> TokenStream {
    expand_with(
        attr.into(),
        item.into(),
        validate_action_return_type,
        generate_action_tokens,
    )
    .unwrap_or_else(|error| error.to_compile_error())
    .into()
}

/// Generates a streaming Rurr action type from a Rust function.
///
/// The annotated function must return one of the supported owning stream
/// shapes accepted by Rurr. Unsupported borrowed futures or stream lifetimes
/// are rejected during macro expansion with a spanned compile error.
///
/// Typical usage:
/// `#[rurr_macros::streaming_action(reads = ["prompt"], writes = ["response"])]`.
#[proc_macro_attribute]
pub fn streaming_action(attr: TokenStream, item: TokenStream) -> TokenStream {
    expand_with(
        attr.into(),
        item.into(),
        validate_streaming_return_type,
        generate_streaming_tokens,
    )
    .unwrap_or_else(|error| error.to_compile_error())
    .into()
}

fn expand_with(
    attr: TokenStream2,
    item: TokenStream2,
    validate_return_type: fn(&Signature) -> syn::Result<()>,
    generate_tokens: fn(&ItemFn, &MacroArgs, &SignatureModel) -> TokenStream2,
) -> syn::Result<TokenStream2> {
    let args = syn::parse2::<MacroArgs>(attr)?;
    let function = syn::parse2::<ItemFn>(item)?;

    validate_return_type(&function.sig)?;
    let model = analyze_signature(&function.sig)?;
    let generated = generate_tokens(&function, &args, &model);
    Ok(quote! {
        #function
        #generated
    })
}
