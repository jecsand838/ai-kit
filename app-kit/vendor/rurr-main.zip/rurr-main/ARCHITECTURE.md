# Rurr Architecture

This is the living workspace architecture map for the current `dev` branch.
Use it for the current system shape. For compatibility guardrails and behavioral contracts, defer to:

1. `docs/ARCHITECTURE_GUARDRAILS.md`
2. `docs/compatibility/DIVERGENCES.md`
3. `docs/compatibility/SEMANTICS.md`

## 1. Project Structure

```text
rurr/
├── README.md                         # human-facing overview and quick start
├── AGENTS.md                         # root agent/operator workflow rules
├── ARCHITECTURE.md                   # this workspace map
├── TASKS_PROGRESS.md                 # completed remediation ledger
├── .codex/config.toml                # repo-scoped Codex profile/config
├── .agents/skills/                   # repo-local workflow skills
├── docs/
│   ├── 00_overview.md                # docs map and reading order
│   ├── 01_repo_layout.md             # current workspace tree
│   ├── 02_api_surface.md             # public Rust API contract
│   ├── 03_test_plan.md               # validation/spec layers
│   ├── 04_oracle_and_goldens.md      # raw Burr/Rurr oracle flow
│   ├── 05_documentation_inventory.md # markdown inventory and dispositions
│   ├── 06_integrations_plan.md       # integration implementation guidance
│   ├── 07_architecture_streaming_and_lifecycle.md
│   ├── ARCHITECTURE_GUARDRAILS.md
│   ├── compatibility/
│   └── refactors/
├── crates/
│   ├── rurr/                         # facade crate
│   ├── rurr-core/                    # runtime, builders, tracking, parallelism
│   │   └── ARCHITECTURE.md
│   ├── rurr-macros/                  # proc-macro crate
│   │   └── ARCHITECTURE.md
│   ├── rurr-persistence/             # shared persistence contracts/layout
│   ├── rurr-sqlite / postgres / redis / mongodb
│   ├── rurr-tracking-store           # anchored filesystem and tracking IO
│   ├── rurr-tracking-server          # local tracking API + embedded UI
│   ├── rurr-cli                      # `rurr` executable
│   ├── rurr-otel / rurr-telemetry
│   └── support crates
├── tools/
│   └── burr_oracle/
│       ├── README.md
│       └── ARCHITECTURE.md
├── scripts/                          # repo gates, manifest, oracle, doc helpers
├── goldens/                          # tracking artifacts + schemas
└── FULL_CONTENT.md / MANIFEST.*      # generated repo snapshots
```

## 2. High-Level System Diagram

```text
Consumer code / examples / tests
        |
        v
   rurr facade crate
        |
        v
  rurr-core application runtime
  - builder + identifiers + resume
  - step/run/session orchestration
  - live streaming handles
  - step transactions and rollback
  - tracking models and LocalTrackingClient
  - parallel child execution
        |
        +--> persistence crates (sqlite/postgres/redis/mongodb)
        +--> rurr-tracking-store (filesystem layout, anchored access, JSONL)
        +--> rurr-tracking-server + rurr-cli (local HTTP/UI/CLI workflows)
        +--> integration crates through explicit facade/features

Oracle and parity flow:
Apache Burr source + Rurr e2e outputs
        |
        v
tools/burr_oracle/*
        |
        v
raw comparator + goldens/schema + goldens/tracking
```

## 3. Core Components

### 3.1. Facade And Runtime

- `crates/rurr` is the user-facing facade and feature-gated re-export surface.
- `crates/rurr-core` owns the current execution stack:
  - application assembly in `src/application/build/`
  - execution option resolution, including graph-validated halt selectors
  - session and run-loop state in `session.rs`
  - live sync/async streaming handles in `streaming/`
  - atomic step commit/rollback in `step_txn.rs`
- Tracking helpers and models now live directly in `rurr-core` and surface through `rurr::tracking`;
  concrete S3 transport is compiled only through the `s3` feature.

### 3.2. Persistence And Backends

- `crates/rurr-persistence` owns the canonical persisted-record layout and builder wiring specs.
- Backend crates implement explicit sync/async lanes where applicable:
  - `rurr-sqlite`
  - `rurr-postgres`
  - `rurr-redis`
  - `rurr-mongodb`
- Persistence resume/fork flows are configured through `ApplicationPersistenceSpec`,
  `StateInitializerSpec`, `StatePersisterSpec`, `PersistenceLoadTarget`, and `InitializeFromSpec`.

### 3.3. Tracking, UI, And CLI

- `rurr-tracking-store` owns anchored filesystem access, JSONL append/selection, and local tracking
  repository helpers.
- `rurr-tracking-server` serves the local tracking HTTP API and an embedded UI bundle by default.
  It supports the local filesystem backend and an explicit S3 backend with SQLite indexing,
  S3-hosted snapshots, fail-closed unsupported annotation routes, and indexing-job metadata.
- `rurr-cli` exposes:
  - `rurr serve`
  - `rurr ui build`
  - `rurr test-case create`
  - `rurr admin publish`
- The removed Burr demo-data generator is not part of the current CLI surface.

### 3.4. Observability

- `rurr-otel` owns the explicit OpenTelemetry lifecycle/tracking bridge and OTLP exporter setup.
- `rurr-core` stays provider-neutral by default; anonymous telemetry is explicit through
  `rurr-telemetry` or the facade `telemetry` feature.

### 3.5. Oracle And Differential Parity

- `tools/burr_oracle` runs the raw Burr-vs-Rurr oracle workflow.
- `scripts/check_oracle.sh` and `scripts/regen_goldens.sh` share one bootstrap and comparator path.
- There is no canonicalization layer; the raw comparator is the contract.

## 4. Data Stores And Artifacts

- State/persistence records:
  - SQLite
  - Postgres
  - Redis
  - MongoDB
- Local tracking artifacts:
  - required: `graph.json`, `metadata.json`, and `log.jsonl`
  - optional: `children.jsonl` for fork/spawn scenarios
- Generated parity and repo artifacts:
  - `goldens/schema/*`
  - `goldens/tracking/*`
  - `FULL_CONTENT.md`
  - `MANIFEST.files.txt`
  - `MANIFEST.sha256`

## 5. External Integrations

- Apache Burr v0.41.0 source and vendored oracle inputs
- Docker-backed local services for:
  - Postgres
  - Redis
  - MongoDB
  - MinIO / S3 tracking
  - OTLP / Grafana LGTM
- Git-based downstream consumption of the private workspace
- Optional browser launch for local tracking UI

## 6. Deployment And Local Infrastructure

- Primary local runtime surface is library-first plus the `rurr` CLI.
- `docker-compose.dev.yml` and `./scripts/dev_up.sh` provide the local live-service stack.
- Primary validation entrypoints:
  - `./scripts/check.sh`
  - `./scripts/check_oracle.sh`
  - `./scripts/check_competition.sh`
  - `./scripts/check_live.sh`
  - `./scripts/check_openai_live.sh` for the private local streaming lane

## 7. Security And Guardrails

- Streaming must stay lazy, borrowed, exclusive, transactional, and rollback-safe.
- Core execution must not use buffered fake streaming, `realize_stream` internally,
  `spawn_blocking`, thread-spawn escapes, or runtime-dependent async cleanup in `Drop`.
- Tracking filesystem access is anchored and fail-closed against aliasing and symlink retargeting.
- Oracle comparison is raw and fail-closed: no post-read rewrites, no canonicalization sentinels,
  and no allowlist-backed audit exceptions.
- Refactor abstraction must be ordinary Rust structure: prefer structs, enums, traits at real
  boundaries, and methods over helper macros or macro crates for reducing duplicate code. The
  `rurr-macros` crate remains the only workspace surface for user-facing proc-macro behavior.

## 8. Development And Testing

- The spec is the combined contract suite, compile-fail suite, goldens, oracle differential flow,
  and compatibility docs.
- Current public API and test ownership live in:
  - `docs/02_api_surface.md`
  - `docs/03_test_plan.md`
  - `docs/04_oracle_and_goldens.md`
  - `docs/compatibility/*`

## 9. Nested Architecture Docs

- `crates/rurr-core/ARCHITECTURE.md` explains the runtime/application internals.
- `crates/rurr-macros/ARCHITECTURE.md` explains the proc-macro pipeline and UI contract.
- `tools/burr_oracle/ARCHITECTURE.md` explains the oracle bootstrap, scenario flow, and comparator.

## 10. Glossary

- `ApplicationBuilder`: public build/resume/fork entrypoint for runtime assembly.
- `InitializeFromSpec`: public builder-side resume/fork options wrapper.
- `StepTxn`: atomic step progression and rollback boundary for streaming and non-streaming execution.
- `TrackerSpec`: builder-side tracker configuration, including local tracker construction.
- `ParallelExecutor` / `SubGraphTask`: child execution handoff and override surface.
- `LocalTrackingClient`: local tracking reader/writer surface exposed from `rurr-core`.
