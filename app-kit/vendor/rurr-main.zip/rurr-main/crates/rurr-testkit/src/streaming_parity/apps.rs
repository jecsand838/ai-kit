use super::actions::AsyncClassStreamingAction;
use super::common::{
    build_capture_prompt_action, named_graph_action, prompt_from_state, ExampleResult,
    CAPTURE_PROMPT, STREAMING_RESPONSE,
};
use super::outputs::async_stream_outputs_from_source;
use super::sources::AsyncChunkSource;
use rurr_core::{Application, ApplicationBuilder, Condition, FunctionActionBuilder, Transition};

pub(super) async fn build_async_function_streaming_app<S: AsyncChunkSource>(
    source: S,
) -> ExampleResult<Application> {
    let capture_prompt = build_capture_prompt_action()?;
    let streaming_response = FunctionActionBuilder::new()
        .reads(["prompt"])
        .writes(["response"])
        .build_streaming_async(move |state, _ctx| {
            let prompt = prompt_from_state(&state);
            async_stream_outputs_from_source(source.clone(), state, prompt)
        })?;

    Ok(ApplicationBuilder::new()
        .with_state(rurr_core::State::default())?
        .with_actions(vec![
            named_graph_action(CAPTURE_PROMPT, capture_prompt)?,
            named_graph_action(STREAMING_RESPONSE, streaming_response)?,
        ])?
        .with_transitions(vec![Transition::new(
            CAPTURE_PROMPT,
            STREAMING_RESPONSE,
            Condition::default(),
        )])?
        .with_entrypoint(CAPTURE_PROMPT)?
        .abuild()
        .await?)
}

pub(super) async fn build_async_class_streaming_app<S: AsyncChunkSource>(
    source: S,
) -> ExampleResult<Application> {
    let capture_prompt = build_capture_prompt_action()?;
    let streaming_response = AsyncClassStreamingAction::new(source);

    Ok(ApplicationBuilder::new()
        .with_state(rurr_core::State::default())?
        .with_actions(vec![
            named_graph_action(CAPTURE_PROMPT, capture_prompt)?,
            named_graph_action(STREAMING_RESPONSE, streaming_response)?,
        ])?
        .with_transitions(vec![Transition::new(
            CAPTURE_PROMPT,
            STREAMING_RESPONSE,
            Condition::default(),
        )])?
        .with_entrypoint(CAPTURE_PROMPT)?
        .abuild()
        .await?)
}
