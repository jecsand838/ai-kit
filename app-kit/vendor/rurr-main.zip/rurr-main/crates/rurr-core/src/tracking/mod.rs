//! Public tracking facade for the local tracking client, tracking models, and
//! JSONL locking helpers.
//!
//! [`LocalTrackingClient`](crate::tracking::LocalTrackingClient) is the main
//! entrypoint when tests or local tools need to register applications, append
//! tracking artifacts, or reload persisted tracking state. The accompanying
//! model types mirror the JSON files and JSONL entries written under a local
//! tracking root.
//!
//! Enable the crate `s3` feature for Burr-compatible S3 tracking clients,
//! object-key parsing, user metadata helpers, and shared S3 transport
//! configuration. S3 helpers preserve raw provider ordering expectations:
//! object keys are formatted so lexicographic `ListObjectsV2` results can be
//! consumed directly by strict live tests and the tracking server.
//!
//! Tracking is fail-closed. Unknown local tracker parameters, malformed S3
//! metadata, missing stream lifecycle state, and invalid provider layout data
//! are surfaced as typed errors rather than being normalized into a passing
//! local shape.
//! For local tracking, app directories require `graph.json`, `metadata.json`,
//! and `log.jsonl`; only child relationship logs are optional.
//!
//! # Examples
//!
//! ```
//! use rurr_core::tracking::allowed_project_name;
//!
//! assert!(allowed_project_name("docs-project", cfg!(windows)));
//! # #[cfg(feature = "s3")]
//! # {
//! use rurr_core::tracking::{partition_key_from_segment, partition_segment};
//!
//! assert_eq!(partition_segment(None), "__none__");
//! assert_eq!(partition_key_from_segment("customer-a"), Some("customer-a".to_string()));
//! # }
//! ```

mod client;
/// JSONL helpers used by the local tracking client.
pub mod jsonl;
mod lifecycle_events;
mod models;
#[cfg(feature = "s3")]
mod s3;
/// Shared S3 tracking artifact preparation and decoding contracts.
#[cfg(feature = "s3")]
pub mod s3_artifact;
/// Burr-compatible S3 tracking object layout and request addressing helpers.
#[cfg(feature = "s3")]
pub mod s3_layout;
/// Canonical S3 user metadata helpers.
#[cfg(feature = "s3")]
pub mod s3_metadata;
/// Shared S3 timestamp parsers.
#[cfg(feature = "s3")]
pub mod s3_time;
/// Shared S3 client construction and request-addressing helpers.
#[cfg(feature = "s3")]
pub mod s3_transport;
mod spec;
mod stream_state;

pub use client::{allowed_project_name, LocalTrackingClient, TrackingError};
pub use models::{
    ActionModel, ApplicationMetadataModel, ApplicationModel, AttributeModel, BeginEntryModel,
    BeginSpanModel, ChildApplicationModel, EndEntryModel, EndSpanModel, EndStreamModel,
    FirstItemStreamModel, InitializeStreamModel, PointerModel, TransitionModel,
};
#[cfg(feature = "s3")]
pub use s3::{S3TrackingClient, S3TrackingConfig};
#[cfg(feature = "s3")]
pub use s3_artifact::{S3ArtifactDescriptor, S3ArtifactIndexPayload};
#[cfg(feature = "s3")]
pub use s3_layout::{
    partition_key_from_segment, partition_segment, S3AddressingStyle, S3LayoutError, S3Prefix,
    S3TrackingObjectKey, S3TrackingObjectKind, DEFAULT_DATA_PREFIX, DEFAULT_SNAPSHOT_PREFIX,
};
#[cfg(feature = "s3")]
pub use s3_transport::{S3ClientSettings, S3TransportError};
pub(crate) use spec::{resolve_tracker_spec, ResolvedTrackerSpec};
