use super::PointerModel;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
/// Serialized record describing a child application event.
///
/// Child records let tracking readers rebuild fork/spawn relationships without
/// inspecting application state snapshots.
pub struct ChildApplicationModel {
    /// Record discriminator used in tracking JSON.
    #[serde(rename = "type")]
    pub r#type: String,
    /// Pointer to the child application.
    pub child: PointerModel,
    /// RFC3339 timestamp for when the event was recorded.
    pub event_time: String,
    /// Event kind such as spawn or completion.
    pub event_type: String,
    /// Sequence id associated with the event, when available.
    pub sequence_id: Option<u64>,
}

impl ChildApplicationModel {
    /// Builds a child application event model.
    pub fn new(
        child: PointerModel,
        event_type: impl Into<String>,
        sequence_id: Option<u64>,
        event_time: impl Into<String>,
    ) -> Self {
        Self {
            r#type: "child_application_data".to_string(),
            child,
            event_time: event_time.into(),
            event_type: event_type.into(),
            sequence_id,
        }
    }
}
