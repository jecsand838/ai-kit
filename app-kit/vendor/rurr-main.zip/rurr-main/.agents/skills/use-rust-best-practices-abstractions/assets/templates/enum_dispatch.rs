pub trait Notifier {
    fn send(&self, message: &str) -> Result<(), NotifyError>;
}

#[derive(Debug, Clone)]
pub struct EmailNotifier {
    from: String,
}

impl Notifier for EmailNotifier {
    fn send(&self, message: &str) -> Result<(), NotifyError> {
        println!("email from {}: {message}", self.from);
        Ok(())
    }
}

#[derive(Debug, Clone)]
pub struct WebhookNotifier {
    endpoint: String,
}

impl Notifier for WebhookNotifier {
    fn send(&self, message: &str) -> Result<(), NotifyError> {
        println!("POST {} body={message}", self.endpoint);
        Ok(())
    }
}

pub enum NotifierKind {
    Email(EmailNotifier),
    Webhook(WebhookNotifier),
}

impl Notifier for NotifierKind {
    fn send(&self, message: &str) -> Result<(), NotifyError> {
        match self {
            NotifierKind::Email(inner) => inner.send(message),
            NotifierKind::Webhook(inner) => inner.send(message),
        }
    }
}

pub enum NotifierConfig {
    Email { from: String },
    Webhook { endpoint: String },
}

pub struct NotifierBuilder;

impl NotifierBuilder {
    pub fn build(config: NotifierConfig) -> Result<NotifierKind, BuildNotifierError> {
        match config {
            NotifierConfig::Email { from } if from.is_empty() => {
                Err(BuildNotifierError::MissingEmailFrom)
            }
            NotifierConfig::Email { from } => Ok(NotifierKind::Email(EmailNotifier { from })),
            NotifierConfig::Webhook { endpoint } if endpoint.is_empty() => {
                Err(BuildNotifierError::MissingWebhookEndpoint)
            }
            NotifierConfig::Webhook { endpoint } => {
                Ok(NotifierKind::Webhook(WebhookNotifier { endpoint }))
            }
        }
    }
}

#[derive(Debug, thiserror::Error)]
pub enum BuildNotifierError {
    #[error("missing email sender address")]
    MissingEmailFrom,
    #[error("missing webhook endpoint")]
    MissingWebhookEndpoint,
}

#[derive(Debug, thiserror::Error)]
#[error("notification failed")]
pub struct NotifyError;
