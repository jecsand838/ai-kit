//! Canonical Burr-compatible S3 user metadata helpers.
//!
//! Tracking writers and the S3 tracking server share these helpers so the
//! metadata keys and strict parsing rules stay in one place. Values are encoded
//! as S3 user metadata strings; malformed provider metadata is surfaced as a
//! typed parse error instead of silently falling back.
//!
//! # Examples
//!
//! ```
//! use rurr_core::tracking::s3_metadata::{
//!     log_metadata, required_sequence_metadata, MAX_SEQUENCE_ID, MIN_SEQUENCE_ID,
//! };
//! use std::collections::HashMap;
//!
//! let metadata: HashMap<_, _> = log_metadata("tracker-1", 10, 12).into_iter().collect();
//! assert_eq!(required_sequence_metadata(&metadata, MIN_SEQUENCE_ID, "log.jsonl")?, 10);
//! assert_eq!(required_sequence_metadata(&metadata, MAX_SEQUENCE_ID, "log.jsonl")?, 12);
//! # Ok::<(), Box<dyn std::error::Error>>(())
//! ```

use crate::application::context::ParentPointer;
use std::collections::{BTreeMap, HashMap};
use thiserror::Error;

/// S3 user metadata key written to every tracked object.
pub const TRACKER_ID: &str = "tracker_id";
/// S3 user metadata key for fork parent pointers on `metadata.json`.
pub const PARENT_POINTER: &str = "parent_pointer";
/// S3 user metadata key for spawning parent pointers on `metadata.json`.
pub const SPAWNING_PARENT_POINTER: &str = "spawning_parent_pointer";
/// S3 user metadata key for the minimum sequence id in a log object.
pub const MIN_SEQUENCE_ID: &str = "min_sequence_id";
/// S3 user metadata key for the maximum sequence id in a log object.
pub const MAX_SEQUENCE_ID: &str = "max_sequence_id";

const NONE_POINTER: &str = "None";

/// Errors raised while encoding or parsing S3 user metadata.
#[derive(Debug, Error)]
pub enum S3MetadataError {
    /// A HEAD response did not include a user metadata map.
    #[error("S3 object '{0}' is missing user metadata")]
    MissingMetadataMap(String),
    /// A required metadata value was absent.
    #[error("S3 object '{0}' is missing required metadata '{1}'")]
    MissingField(String, &'static str),
    /// A metadata value was malformed.
    #[error("S3 object '{0}' has malformed metadata '{1}': {2}")]
    MalformedField(String, &'static str, String),
    /// A parent pointer could not be serialized.
    #[error("failed to serialize S3 parent pointer metadata: {0}")]
    SerializePointer(#[from] serde_json::Error),
}

/// Builds metadata common to every tracked S3 object.
///
/// The returned map is sorted by key so callers produce stable request payloads
/// and live-test diagnostics.
pub fn object_metadata(tracker_id: &str) -> BTreeMap<String, String> {
    BTreeMap::from([(TRACKER_ID.to_string(), tracker_id.to_string())])
}

/// Builds metadata for an application `metadata.json` object.
///
/// Parent pointers are serialized as JSON strings because S3 user metadata
/// values are strings. Missing pointers use Burr's literal `None` sentinel.
///
/// # Examples
///
/// ```
/// use rurr_core::ParentPointer;
/// use rurr_core::tracking::s3_metadata::{application_metadata, PARENT_POINTER};
///
/// let parent = ParentPointer {
///     app_id: "parent-app".to_string(),
///     partition_key: Some("customer-a".to_string()),
///     sequence_id: Some(7),
/// };
/// let metadata = application_metadata("tracker-1", Some(&parent), None)?;
///
/// assert!(metadata[PARENT_POINTER].contains("parent-app"));
/// # Ok::<(), Box<dyn std::error::Error>>(())
/// ```
pub fn application_metadata(
    tracker_id: &str,
    parent_pointer: Option<&ParentPointer>,
    spawning_parent_pointer: Option<&ParentPointer>,
) -> Result<BTreeMap<String, String>, S3MetadataError> {
    let mut metadata = object_metadata(tracker_id);
    metadata.insert(PARENT_POINTER.to_string(), option_pointer(parent_pointer)?);
    metadata.insert(
        SPAWNING_PARENT_POINTER.to_string(),
        option_pointer(spawning_parent_pointer)?,
    );
    Ok(metadata)
}

/// Builds metadata for a log JSONL object.
///
/// The min/max sequence fields describe the inclusive sequence range contained
/// in the corresponding log object. Tracking-server indexing treats malformed
/// values as provider data errors instead of synthesizing a range.
pub fn log_metadata(
    tracker_id: &str,
    min_sequence_id: u64,
    max_sequence_id: u64,
) -> BTreeMap<String, String> {
    let mut metadata = object_metadata(tracker_id);
    metadata.insert(MIN_SEQUENCE_ID.to_string(), min_sequence_id.to_string());
    metadata.insert(MAX_SEQUENCE_ID.to_string(), max_sequence_id.to_string());
    metadata
}

/// Returns a typed error for a missing user metadata map.
pub fn missing_metadata_map(object_key: &str) -> S3MetadataError {
    S3MetadataError::MissingMetadataMap(object_key.to_string())
}

/// Returns a required metadata value.
///
/// # Errors
///
/// Returns [`S3MetadataError::MissingField`] when the provider metadata map does
/// not contain `field`.
pub fn required_metadata_value<'a>(
    metadata: &'a HashMap<String, String>,
    field: &'static str,
    object_key: &str,
) -> Result<&'a str, S3MetadataError> {
    required_value(metadata, field, object_key)
}

/// Parses a required unsigned sequence id metadata field.
///
/// # Errors
///
/// Returns a missing-field error for absent metadata and a malformed-field error
/// for values that are not unsigned integers.
pub fn required_sequence_metadata(
    metadata: &HashMap<String, String>,
    field: &'static str,
    object_key: &str,
) -> Result<u64, S3MetadataError> {
    let value = required_value(metadata, field, object_key)?;
    value.parse::<u64>().map_err(|error| {
        S3MetadataError::MalformedField(
            object_key.to_string(),
            field,
            format!("invalid unsigned integer '{value}': {error}"),
        )
    })
}

/// Parses an optional parent pointer metadata field into canonical JSON.
///
/// Missing fields return `Ok(None)`. Present but malformed JSON is returned as
/// a typed [`S3MetadataError`] so the tracking server can fail indexing rather
/// than silently dropping Burr parentage.
pub fn parse_pointer_metadata(
    metadata: &HashMap<String, String>,
    field: &'static str,
    object_key: &str,
) -> Result<Option<String>, S3MetadataError> {
    let value = required_value(metadata, field, object_key)?;
    if value == NONE_POINTER {
        return Ok(None);
    }
    let pointer = serde_json::from_str::<ParentPointer>(value).map_err(|error| {
        S3MetadataError::MalformedField(object_key.to_string(), field, error.to_string())
    })?;
    serde_json::to_string(&pointer)
        .map(Some)
        .map_err(S3MetadataError::from)
}

fn option_pointer(pointer: Option<&ParentPointer>) -> Result<String, S3MetadataError> {
    pointer.map_or_else(
        || Ok(NONE_POINTER.to_string()),
        |pointer| serde_json::to_string(pointer).map_err(S3MetadataError::from),
    )
}

fn required_value<'a>(
    metadata: &'a HashMap<String, String>,
    field: &'static str,
    object_key: &str,
) -> Result<&'a str, S3MetadataError> {
    metadata
        .get(field)
        .map(String::as_str)
        .ok_or_else(|| S3MetadataError::MissingField(object_key.to_string(), field))
}
