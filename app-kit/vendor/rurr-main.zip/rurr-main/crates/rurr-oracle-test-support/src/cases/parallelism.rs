use super::support::{
    build_counter_action, build_registered_app, build_registered_app_from_definition,
    initialize_from_spec, map_from_pairs, state_from_pairs,
};
use crate::manifest::BurrOracleScenario;
use rurr_core::application::{ApplicationBuilder, ParentPointer};
use rurr_core::graph::Transition;
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::tracking::LocalTrackingClient;
use rurr_persistence::BaseStateLoader;
use serde_json::json;
use std::error::Error;
use std::sync::Arc;

pub(super) fn run_06_fork_and_spawn_children(
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<(), Box<dyn Error>> {
    let counter = build_counter_action()?;

    let mut parent = build_registered_app_from_definition(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(0))]))?
            .with_actions(vec![("counter", counter.clone())])?
            .with_transitions(Vec::<Transition>::new())?
            .with_entrypoint("counter")?,
        definition,
        tracker,
        hooks,
    )?;
    parent.step(None)?;

    let parent_pointer = ParentPointer {
        app_id: definition.app_id.clone(),
        partition_key: Some(definition.partition_key.clone()),
        sequence_id: Some(0),
    };

    let fork_app_id = format!("{}_fork", definition.app_id);
    let initializer: Arc<dyn BaseStateLoader> = tracker.clone();
    let _fork = build_registered_app(
        ApplicationBuilder::new()
            .with_actions(vec![("counter", counter.clone())])?
            .with_transitions(Vec::<Transition>::new())?
            .initialize_from(
                initializer,
                initialize_from_spec(true, map_from_pairs([("count", json!(0))]), "counter")
                    .with_fork_target(rurr_persistence::PersistenceLoadTarget::new(
                        &definition.app_id,
                        Some(definition.partition_key.clone()),
                        Some(0),
                    )),
            )?,
        &fork_app_id,
        &definition.partition_key,
        tracker,
        hooks,
    )?;

    let spawn_app_id = format!("{}_spawn", definition.app_id);
    let _spawn = build_registered_app(
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(0))]))?
            .with_actions(vec![("counter", counter)])?
            .with_transitions(Vec::<Transition>::new())?
            .with_entrypoint("counter")?
            .with_spawning_parent(
                parent_pointer.app_id.clone(),
                parent_pointer.partition_key.clone(),
                parent_pointer
                    .sequence_id
                    .expect("spawn parent sequence id should be set"),
            )?,
        &spawn_app_id,
        &definition.partition_key,
        tracker,
        hooks,
    )?;

    Ok(())
}
