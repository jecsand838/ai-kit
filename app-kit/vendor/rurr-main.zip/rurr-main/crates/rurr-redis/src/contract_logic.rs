use indexmap::IndexMap;
use rurr_persistence::{
    persisted_state_from_record_parts, sequence_id_i64_to_u64, wire as persistence_wire,
    LoadSelector, PersistedRecordParts, PersistedStateData, PersistedStateStatus, PersistenceError,
};
use serde_json::Value;
use std::collections::{HashMap, HashSet};
use std::future::Future;
use std::time::SystemTime;

const STATE_KEY_PREFIX: &str = "state";
const PARTITION_INDEX_KEY_PREFIX: &str = "partition_index";
const APP_INDEX_KEY_PREFIX: &str = "app_index";
const PARTITION_APP_IDS_KEY_PREFIX: &str = "app_members";
const INDEX_MEMBER_DELIMITER: char = '|';
const SORTABLE_HEX_TERMINATOR: char = '!';
const SEQUENCE_ID_WIDTH: usize = 20;
const EXACT_SEQUENCE_RANGE_SUFFIX: char = '~';
const PARTITION_INDEX_SCAN_BATCH_SIZE: usize = 128;

/// Error code used when an app id cannot be decoded from a stored Redis hash.
pub(crate) const OP_RECORD_APP_ID_DESERIALIZATION_FAILED: &str =
    "record_app_id_deserialization_failed";
/// Error code used when a record key cannot be decoded from an index member.
pub(crate) const OP_RECORD_KEY_DESERIALIZATION_FAILED: &str = "record_key_deserialization_failed";
/// Error code used when a partition key cannot be decoded from a stored Redis
/// hash.
pub(crate) const OP_RECORD_PARTITION_KEY_DESERIALIZATION_FAILED: &str =
    "record_partition_key_deserialization_failed";
/// Error code used when a stored sequence id cannot be parsed as `u64`.
pub(crate) const OP_RECORD_SEQUENCE_ID_DESERIALIZATION_FAILED: &str =
    "record_sequence_id_deserialization_failed";
/// Error code used when the created-at prefix in an index member is invalid.
pub(crate) const OP_INDEX_MEMBER_CREATED_AT_DESERIALIZATION_FAILED: &str =
    "index_member_created_at_deserialization_failed";
/// Error code used when a Redis index member fails structural decoding.
pub(crate) const OP_INDEX_MEMBER_DESERIALIZATION_FAILED: &str =
    "index_member_deserialization_failed";
/// Error code used when a sequence id falls outside the supported range.
pub(crate) const OP_SEQUENCE_ID_OUT_OF_RANGE: &str = "sequence_id_out_of_range";
/// Error code used when a stored state payload fails JSON deserialization.
pub(crate) const OP_STATE_DESERIALIZATION_FAILED: &str = "state_deserialization_failed";
/// Error code used when a state payload fails JSON serialization.
pub(crate) const OP_STATE_SERIALIZATION_FAILED: &str = "state_serialization_failed";
/// Error code used when a stored status string cannot be decoded.
pub(crate) const OP_STATUS_DESERIALIZATION_FAILED: &str = "status_deserialization_failed";

#[derive(Debug, Clone, PartialEq, Eq)]
/// Decoded representation of a member from the partition-level sorted-set
/// index.
pub(crate) struct DecodedPartitionIndexMember {
    pub(crate) created_at: String,
    pub(crate) sequence_id: u64,
    pub(crate) app_id: String,
    pub(crate) position: String,
    pub(crate) record_key: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
/// Decoded representation of a member from the app-level sorted-set index.
pub(crate) struct DecodedAppIndexMember {
    pub(crate) sequence_id: u64,
    pub(crate) created_at: String,
    pub(crate) position: String,
    pub(crate) record_key: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) enum RecordLoadQuery {
    NoRecord,
    LatestPartition { index_key: String },
    LatestApp { index_key: String },
    ExactSequence { index_key: String, sequence_id: u64 },
}

impl RecordLoadQuery {
    pub(crate) fn from_selector(
        namespace: &str,
        selector: LoadSelector<'_>,
    ) -> Result<Self, PersistenceError> {
        Ok(match selector {
            LoadSelector::NoRecord => Self::NoRecord,
            LoadSelector::LatestPartition { partition_key } => Self::LatestPartition {
                index_key: partition_index_key(namespace, &partition_key),
            },
            LoadSelector::LatestApp {
                partition_key,
                app_id,
            } => Self::LatestApp {
                index_key: app_index_key(namespace, &partition_key, app_id),
            },
            LoadSelector::ExactSequence {
                partition_key,
                app_id,
                sequence_id,
            } => Self::ExactSequence {
                index_key: app_index_key(namespace, &partition_key, app_id),
                sequence_id: sequence_id_i64_to_u64(sequence_id)?,
            },
        })
    }

    pub(crate) fn index_key(&self) -> Option<&str> {
        match self {
            Self::NoRecord => None,
            Self::LatestPartition { index_key }
            | Self::LatestApp { index_key }
            | Self::ExactSequence { index_key, .. } => Some(index_key),
        }
    }

    pub(crate) fn record_key_from_member(
        &self,
        member: Option<String>,
    ) -> Result<Option<String>, PersistenceError> {
        match self {
            Self::NoRecord => Ok(None),
            Self::LatestPartition { .. } => member
                .map(|member| {
                    decode_partition_index_member(&member).map(|decoded| decoded.record_key)
                })
                .transpose(),
            Self::LatestApp { .. } | Self::ExactSequence { .. } => member
                .map(|member| decode_app_index_member(&member).map(|decoded| decoded.record_key))
                .transpose(),
        }
    }
}

pub(crate) struct RedisPersistencePlan;

impl RedisPersistencePlan {
    pub(crate) fn save(
        namespace: &str,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: &IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<PreparedSave, PersistenceError> {
        prepare_save(
            namespace,
            partition_key,
            app_id,
            sequence_id,
            position,
            state,
            status,
        )
    }

    pub(crate) fn load(
        namespace: &str,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<RecordLoadQuery, PersistenceError> {
        RecordLoadQuery::from_selector(
            namespace,
            LoadSelector::new(partition_key, app_id, sequence_id)?,
        )
    }

    pub(crate) fn list_app_ids(
        namespace: &str,
        partition_key: Option<&str>,
    ) -> RedisListAppIdsPlan {
        RedisListAppIdsPlan::new(namespace, partition_key)
    }
}

#[derive(Debug)]
pub(crate) struct RedisListAppIdsPlan {
    app_members_key: String,
    namespace: String,
    partition_key: String,
}

impl RedisListAppIdsPlan {
    fn new(namespace: &str, partition_key: Option<&str>) -> Self {
        let partition_key = normalize_partition_key(partition_key);
        Self {
            app_members_key: partition_app_ids_key(namespace, &partition_key),
            namespace: namespace.to_string(),
            partition_key,
        }
    }

    pub(crate) fn app_members_key(&self) -> &str {
        &self.app_members_key
    }

    pub(crate) fn scan(&self, app_ids: Vec<String>) -> PartitionAppIdScan {
        PartitionAppIdScan::new(&self.namespace, &self.partition_key, app_ids)
    }
}

#[derive(Debug)]
pub(crate) struct PartitionAppIdScan {
    partition_index_key: String,
    next_batch_start: usize,
    remaining_app_ids: HashSet<String>,
    ordered_app_ids: Vec<String>,
}

pub(crate) struct PartitionScanBatch<'a> {
    pub(crate) key: &'a str,
    pub(crate) start: usize,
    pub(crate) end: usize,
}

impl PartitionAppIdScan {
    pub(crate) fn new(namespace: &str, partition_key: &str, app_ids: Vec<String>) -> Self {
        let remaining_app_ids: HashSet<String> = app_ids.into_iter().collect();
        let ordered_app_ids = Vec::with_capacity(remaining_app_ids.len());
        Self {
            partition_index_key: partition_index_key(namespace, partition_key),
            next_batch_start: 0,
            remaining_app_ids,
            ordered_app_ids,
        }
    }

    pub(crate) fn next_batch(&self) -> Option<PartitionScanBatch<'_>> {
        if self.is_complete() {
            None
        } else {
            Some(PartitionScanBatch {
                key: self.partition_index_key.as_str(),
                start: self.next_batch_start,
                end: self.next_batch_start + partition_index_scan_batch_size() - 1,
            })
        }
    }

    pub(crate) fn absorb(&mut self, members: Vec<String>) -> Result<bool, PersistenceError> {
        if members.is_empty() {
            return Ok(false);
        }

        self.absorb_partition_members(members)?;
        self.next_batch_start += partition_index_scan_batch_size();
        Ok(!self.is_complete())
    }

    pub(crate) fn into_ordered_app_ids(self) -> Vec<String> {
        self.ordered_app_ids
    }

    fn is_complete(&self) -> bool {
        self.remaining_app_ids.is_empty()
    }

    fn absorb_partition_members(&mut self, members: Vec<String>) -> Result<(), PersistenceError> {
        for member in members {
            let member = decode_partition_index_member(&member)?;
            if self.remaining_app_ids.remove(&member.app_id) {
                self.ordered_app_ids.push(member.app_id);
                if self.is_complete() {
                    break;
                }
            }
        }
        Ok(())
    }
}

pub(crate) fn drive_partition_app_id_scan(
    mut scan: PartitionAppIdScan,
    mut fetch_batch: impl FnMut(&str, usize, usize) -> Result<Vec<String>, PersistenceError>,
) -> Result<Vec<String>, PersistenceError> {
    while let Some(batch) = scan.next_batch() {
        let partition_members = fetch_batch(batch.key, batch.start, batch.end)?;
        if !scan.absorb(partition_members)? {
            break;
        }
    }

    Ok(scan.into_ordered_app_ids())
}

pub(crate) async fn drive_partition_app_id_scan_async<F, Fut>(
    mut scan: PartitionAppIdScan,
    mut fetch_batch: F,
) -> Result<Vec<String>, PersistenceError>
where
    F: FnMut(String, usize, usize) -> Fut,
    Fut: Future<Output = Result<Vec<String>, PersistenceError>>,
{
    while let Some(batch) = scan.next_batch() {
        let key = batch.key.to_string();
        let partition_members = fetch_batch(key, batch.start, batch.end).await?;
        if !scan.absorb(partition_members)? {
            break;
        }
    }

    Ok(scan.into_ordered_app_ids())
}

pub(crate) fn finish_save_result(
    save_result: i32,
    duplicate_operation: &'static str,
) -> Result<(), PersistenceError> {
    if save_result == 1 {
        Ok(())
    } else {
        Err(PersistenceError::UnsupportedOperation {
            operation: duplicate_operation,
        })
    }
}

#[derive(Debug)]
/// Borrowed arguments passed to the Lua save script.
pub(crate) struct SaveInvocation<'a> {
    pub(crate) record_key: &'a str,
    pub(crate) partition_index_key: &'a str,
    pub(crate) partition_index_member: &'a str,
    pub(crate) app_index_key: &'a str,
    pub(crate) app_index_member: &'a str,
    pub(crate) partition_app_ids_key: &'a str,
    pub(crate) partition_key: &'a str,
    pub(crate) app_id: &'a str,
    pub(crate) sequence_id: u64,
    pub(crate) position: &'a str,
    pub(crate) state_json: &'a str,
    pub(crate) status: &'a str,
    pub(crate) created_at: &'a str,
}

#[derive(Debug)]
/// Precomputed Redis keys, members, and payload strings for a save operation.
pub(crate) struct PreparedSave {
    pub(crate) record_key: String,
    pub(crate) partition_index_key: String,
    pub(crate) partition_index_member: String,
    pub(crate) app_index_key: String,
    pub(crate) app_index_member: String,
    pub(crate) partition_app_ids_key: String,
    pub(crate) partition_key: String,
    pub(crate) app_id: String,
    pub(crate) sequence_id: u64,
    pub(crate) position: String,
    pub(crate) state_json: String,
    pub(crate) status: &'static str,
    pub(crate) created_at: String,
}

impl PreparedSave {
    pub(crate) fn invocation(&self) -> SaveInvocation<'_> {
        SaveInvocation {
            record_key: &self.record_key,
            partition_index_key: &self.partition_index_key,
            partition_index_member: &self.partition_index_member,
            app_index_key: &self.app_index_key,
            app_index_member: &self.app_index_member,
            partition_app_ids_key: &self.partition_app_ids_key,
            partition_key: &self.partition_key,
            app_id: &self.app_id,
            sequence_id: self.sequence_id,
            position: &self.position,
            state_json: &self.state_json,
            status: self.status,
            created_at: &self.created_at,
        }
    }
}

/// Normalizes an optional partition key into the Redis contract’s stored form.
fn normalize_partition_key(partition_key: Option<&str>) -> String {
    persistence_wire::normalize_partition_key(partition_key)
}

/// Prefixes a storage key with the configured namespace, if any.
pub(crate) fn namespaced_key(namespace: &str, key: &str) -> String {
    if namespace.is_empty() {
        key.to_string()
    } else {
        format!("{namespace}:{key}")
    }
}

/// Encodes a key segment using a length prefix so delimiters remain unambiguous.
pub(crate) fn encoded_segment(value: &str) -> String {
    format!("{}:{value}", value.len())
}

/// Builds the canonical Redis hash key for a persisted-state record.
pub(crate) fn state_key(
    namespace: &str,
    partition_key: &str,
    app_id: &str,
    sequence_id: u64,
    position: &str,
) -> String {
    namespaced_key(
        namespace,
        &format!(
            "{STATE_KEY_PREFIX}|{}|{}|{sequence_id}|{}",
            encoded_segment(partition_key),
            encoded_segment(app_id),
            encoded_segment(position),
        ),
    )
}

/// Builds the partition-level sorted-set key for a normalized partition key.
pub(crate) fn partition_index_key(namespace: &str, partition_key: &str) -> String {
    namespaced_key(
        namespace,
        &format!(
            "{PARTITION_INDEX_KEY_PREFIX}|{}",
            encoded_segment(partition_key)
        ),
    )
}

/// Builds the app-level sorted-set key for a normalized partition key and app
/// id.
pub(crate) fn app_index_key(namespace: &str, partition_key: &str, app_id: &str) -> String {
    namespaced_key(
        namespace,
        &format!(
            "{APP_INDEX_KEY_PREFIX}|{}|{}",
            encoded_segment(partition_key),
            encoded_segment(app_id),
        ),
    )
}

/// Builds the Redis set key that stores known app ids for a partition.
fn partition_app_ids_key(namespace: &str, partition_key: &str) -> String {
    namespaced_key(
        namespace,
        &format!(
            "{PARTITION_APP_IDS_KEY_PREFIX}|{}",
            encoded_segment(partition_key)
        ),
    )
}

/// Builds a partition-index member string ordered by creation time and
/// sequence.
pub(crate) fn partition_index_member(
    record_key: &str,
    app_id: &str,
    sequence_id: u64,
    position: &str,
    created_at: &str,
) -> String {
    format!(
        "{created_at}{INDEX_MEMBER_DELIMITER}{}{INDEX_MEMBER_DELIMITER}{}{INDEX_MEMBER_DELIMITER}{}{INDEX_MEMBER_DELIMITER}{}",
        padded_sequence_id(sequence_id),
        sortable_hex_encode(position),
        sortable_hex_encode(app_id),
        sortable_hex_encode(record_key),
    )
}

/// Builds an app-index member string ordered by sequence id.
pub(crate) fn app_index_member(
    record_key: &str,
    sequence_id: u64,
    position: &str,
    created_at: &str,
) -> String {
    format!(
        "{}{INDEX_MEMBER_DELIMITER}{created_at}{INDEX_MEMBER_DELIMITER}{}{INDEX_MEMBER_DELIMITER}{}",
        padded_sequence_id(sequence_id),
        sortable_hex_encode(position),
        sortable_hex_encode(record_key),
    )
}

/// Returns the lexicographic range bounds used to look up an exact sequence in
/// an app index.
pub(crate) fn app_index_exact_sequence_lex_range(sequence_id: u64) -> (String, String) {
    let prefix = app_index_sequence_prefix(sequence_id);
    (
        format!("[{prefix}{EXACT_SEQUENCE_RANGE_SUFFIX}"),
        format!("[{prefix}"),
    )
}

/// Precomputes all Redis keys and payloads needed to save a persisted-state
/// record.
fn prepare_save(
    namespace: &str,
    partition_key: Option<&str>,
    app_id: &str,
    sequence_id: u64,
    position: &str,
    state: &IndexMap<String, Value>,
    status: PersistedStateStatus,
) -> Result<PreparedSave, PersistenceError> {
    let partition_key = normalize_partition_key(partition_key);
    let partition_index_key = partition_index_key(namespace, &partition_key);
    let app_index_key = app_index_key(namespace, &partition_key, app_id);
    let partition_app_ids_key = partition_app_ids_key(namespace, &partition_key);
    let record_key = state_key(namespace, &partition_key, app_id, sequence_id, position);
    let state_json = persistence_wire::serialize_state_json(state, OP_STATE_SERIALIZATION_FAILED)?;
    let status = persistence_wire::persisted_status_as_str(status);
    let created_at = persistence_wire::sortable_rfc3339_utc_string(SystemTime::now())?;
    let partition_index_member =
        partition_index_member(&record_key, app_id, sequence_id, position, &created_at);
    let app_index_member = app_index_member(&record_key, sequence_id, position, &created_at);

    Ok(PreparedSave {
        record_key,
        partition_index_key,
        partition_index_member,
        app_index_key,
        app_index_member,
        partition_app_ids_key,
        partition_key,
        app_id: app_id.to_string(),
        sequence_id,
        position: position.to_string(),
        state_json,
        status,
        created_at,
    })
}

/// Parses a sequence id stored in Redis into a `u64`.
pub(crate) fn parse_sequence_id(value: &str) -> Result<u64, PersistenceError> {
    value
        .parse::<u64>()
        .map_err(|_| PersistenceError::UnsupportedOperation {
            operation: OP_SEQUENCE_ID_OUT_OF_RANGE,
        })
}

/// Converts a Redis hash payload into a fully typed persisted-state snapshot.
pub(crate) fn hash_to_persisted_state(
    fields: HashMap<String, String>,
) -> Result<PersistedStateData, PersistenceError> {
    let partition_key =
        fields
            .get("partition_key")
            .cloned()
            .ok_or(PersistenceError::UnsupportedOperation {
                operation: OP_RECORD_PARTITION_KEY_DESERIALIZATION_FAILED,
            })?;
    let app_id = fields
        .get("app_id")
        .cloned()
        .ok_or(PersistenceError::UnsupportedOperation {
            operation: OP_RECORD_APP_ID_DESERIALIZATION_FAILED,
        })?;
    let sequence_id = parse_sequence_id(fields.get("sequence_id").ok_or(
        PersistenceError::UnsupportedOperation {
            operation: OP_RECORD_SEQUENCE_ID_DESERIALIZATION_FAILED,
        },
    )?)?;
    persisted_state_from_record_parts(
        PersistedRecordParts {
            partition_key,
            app_id,
            sequence_id,
            position: fields.get("position").cloned(),
            state_json: fields.get("state").map(String::as_str),
            created_at: fields.get("created_at").cloned(),
            status: fields.get("status").map(String::as_str).ok_or(
                PersistenceError::UnsupportedOperation {
                    operation: OP_STATUS_DESERIALIZATION_FAILED,
                },
            )?,
        },
        OP_STATE_DESERIALIZATION_FAILED,
        OP_STATUS_DESERIALIZATION_FAILED,
    )
}

/// Converts a Redis hash payload into an optional persisted-state snapshot,
/// treating an empty hash as missing.
pub(crate) fn persisted_state_from_hash(
    fields: HashMap<String, String>,
) -> Result<Option<PersistedStateData>, PersistenceError> {
    if fields.is_empty() {
        return Ok(None);
    }

    hash_to_persisted_state(fields).map(Some)
}

#[cfg(test)]
pub(crate) fn record_key_from_partition_index_member(
    member: &str,
) -> Result<String, PersistenceError> {
    Ok(decode_partition_index_member(member)?.record_key)
}

#[cfg(test)]
pub(crate) fn record_key_from_app_index_member(member: &str) -> Result<String, PersistenceError> {
    Ok(decode_app_index_member(member)?.record_key)
}

#[cfg(test)]
pub(crate) fn created_at_from_partition_index_member(
    member: &str,
) -> Result<String, PersistenceError> {
    Ok(decode_partition_index_member(member)?.created_at)
}

#[cfg(test)]
pub(crate) fn app_id_from_partition_index_member(member: &str) -> Result<String, PersistenceError> {
    Ok(decode_partition_index_member(member)?.app_id)
}

/// Returns the batch size used when scanning partition index members.
pub(crate) fn partition_index_scan_batch_size() -> usize {
    PARTITION_INDEX_SCAN_BATCH_SIZE
}

fn padded_sequence_id(sequence_id: u64) -> String {
    format!("{sequence_id:0width$}", width = SEQUENCE_ID_WIDTH)
}

fn app_index_sequence_prefix(sequence_id: u64) -> String {
    format!(
        "{}{}",
        padded_sequence_id(sequence_id),
        INDEX_MEMBER_DELIMITER
    )
}

fn sortable_hex_encode(value: &str) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";

    let mut encoded = String::with_capacity(value.len() * 2 + 1);
    for byte in value.as_bytes() {
        encoded.push(HEX[(byte >> 4) as usize] as char);
        encoded.push(HEX[(byte & 0x0f) as usize] as char);
    }
    encoded.push(SORTABLE_HEX_TERMINATOR);
    encoded
}

fn sortable_hex_decode(encoded: &str, operation: &'static str) -> Result<String, PersistenceError> {
    let body = encoded
        .strip_suffix(SORTABLE_HEX_TERMINATOR)
        .ok_or(PersistenceError::UnsupportedOperation { operation })?;
    if body.len() % 2 != 0 {
        return Err(PersistenceError::UnsupportedOperation { operation });
    }

    let bytes = body
        .as_bytes()
        .chunks(2)
        .map(|chunk| {
            let high = hex_nibble(chunk[0])?;
            let low = hex_nibble(chunk[1])?;
            Ok((high << 4) | low)
        })
        .collect::<Result<Vec<_>, PersistenceError>>()?;

    String::from_utf8(bytes).map_err(|_| PersistenceError::UnsupportedOperation { operation })
}

fn hex_nibble(value: u8) -> Result<u8, PersistenceError> {
    match value {
        b'0'..=b'9' => Ok(value - b'0'),
        b'a'..=b'f' => Ok(value - b'a' + 10),
        b'A'..=b'F' => Ok(value - b'A' + 10),
        _ => Err(PersistenceError::UnsupportedOperation {
            operation: OP_INDEX_MEMBER_DESERIALIZATION_FAILED,
        }),
    }
}

fn split_app_index_member(member: &str) -> Result<(&str, &str, &str, &str), PersistenceError> {
    split_index_member(member)
}

fn split_partition_index_member(
    member: &str,
) -> Result<(&str, &str, &str, &str, &str), PersistenceError> {
    let parts = member.splitn(5, INDEX_MEMBER_DELIMITER).collect::<Vec<_>>();
    if parts.len() == 5 {
        Ok((parts[0], parts[1], parts[2], parts[3], parts[4]))
    } else {
        Err(PersistenceError::UnsupportedOperation {
            operation: OP_INDEX_MEMBER_DESERIALIZATION_FAILED,
        })
    }
}

fn split_index_member(member: &str) -> Result<(&str, &str, &str, &str), PersistenceError> {
    let parts = member.splitn(4, INDEX_MEMBER_DELIMITER).collect::<Vec<_>>();
    if parts.len() == 4 {
        Ok((parts[0], parts[1], parts[2], parts[3]))
    } else {
        Err(PersistenceError::UnsupportedOperation {
            operation: OP_INDEX_MEMBER_DESERIALIZATION_FAILED,
        })
    }
}

/// Decodes a partition-index member back into its structured representation.
pub(crate) fn decode_partition_index_member(
    member: &str,
) -> Result<DecodedPartitionIndexMember, PersistenceError> {
    let (created_at, sequence_id, position, app_id, record_key) =
        split_partition_index_member(member)?;
    if created_at.is_empty() {
        return Err(PersistenceError::UnsupportedOperation {
            operation: OP_INDEX_MEMBER_CREATED_AT_DESERIALIZATION_FAILED,
        });
    }

    Ok(DecodedPartitionIndexMember {
        created_at: created_at.to_string(),
        sequence_id: parse_sequence_id(sequence_id)?,
        app_id: sortable_hex_decode(app_id, OP_RECORD_APP_ID_DESERIALIZATION_FAILED)?,
        position: sortable_hex_decode(position, OP_INDEX_MEMBER_DESERIALIZATION_FAILED)?,
        record_key: sortable_hex_decode(record_key, OP_RECORD_KEY_DESERIALIZATION_FAILED)?,
    })
}

/// Decodes an app-index member back into its structured representation.
pub(crate) fn decode_app_index_member(
    member: &str,
) -> Result<DecodedAppIndexMember, PersistenceError> {
    let (sequence_id, created_at, position, record_key) = split_app_index_member(member)?;
    if created_at.is_empty() {
        return Err(PersistenceError::UnsupportedOperation {
            operation: OP_INDEX_MEMBER_CREATED_AT_DESERIALIZATION_FAILED,
        });
    }

    Ok(DecodedAppIndexMember {
        sequence_id: parse_sequence_id(sequence_id)?,
        created_at: created_at.to_string(),
        position: sortable_hex_decode(position, OP_INDEX_MEMBER_DESERIALIZATION_FAILED)?,
        record_key: sortable_hex_decode(record_key, OP_RECORD_KEY_DESERIALIZATION_FAILED)?,
    })
}

#[cfg(test)]
mod tests {
    use super::{
        app_id_from_partition_index_member, created_at_from_partition_index_member,
        drive_partition_app_id_scan, hash_to_persisted_state, partition_index_key,
        partition_index_member, partition_index_scan_batch_size, prepare_save,
        record_key_from_partition_index_member, state_key, PartitionAppIdScan,
    };
    use indexmap::IndexMap;
    use rurr_persistence::PersistedStateStatus;
    use serde_json::json;
    use std::collections::HashMap;

    #[test]
    fn partition_app_id_scan_preserves_partition_index_scan_order_when_timestamps_tie() {
        let first_seen = partition_index_member(
            "record::first_seen",
            "zz_app",
            7,
            "position_9",
            "2026-03-21T00:00:00.000000000Z",
        );
        let second_seen = partition_index_member(
            "record::second_seen",
            "aa_app",
            7,
            "position_1",
            "2026-03-21T00:00:00.000000000Z",
        );

        let mut scan = PartitionAppIdScan::new(
            "ns",
            "tenant",
            vec!["aa_app".to_string(), "zz_app".to_string()],
        );
        scan.absorb(vec![first_seen, second_seen])
            .expect("partition members should decode");

        assert_eq!(
            scan.into_ordered_app_ids(),
            vec!["zz_app".to_string(), "aa_app".to_string()],
            "list_app_ids must preserve canonical partition-index order when timestamps tie",
        );
    }

    #[test]
    fn partition_app_id_scan_driver_stops_on_index_exhaustion() {
        let mut batch_calls = 0;
        let expected_index_key = partition_index_key("ns", "tenant");
        let seen = partition_index_member(
            "record::seen",
            "seen_app",
            7,
            "position_1",
            "2026-03-21T00:00:00.000000000Z",
        );
        let scan = PartitionAppIdScan::new(
            "ns",
            "tenant",
            vec!["missing_app".to_string(), "seen_app".to_string()],
        );

        let app_ids = drive_partition_app_id_scan(scan, |partition_index_key, start, end| {
            batch_calls += 1;
            assert_eq!(partition_index_key, expected_index_key);
            assert_eq!(end - start + 1, partition_index_scan_batch_size());
            Ok(if batch_calls == 1 {
                vec![seen.clone()]
            } else {
                Vec::new()
            })
        })
        .expect("scan driver should surface exhausted partial order");

        assert_eq!(app_ids, vec!["seen_app".to_string()]);
        assert_eq!(batch_calls, 2);
    }

    #[test]
    fn prepare_save_matches_hermetic_key_layout_contract() {
        let state = IndexMap::from([("key".to_string(), json!("value"))]);
        let prepared = prepare_save(
            "gate1_sync",
            None,
            "app_id",
            9,
            "position_9",
            &state,
            PersistedStateStatus::Completed,
        )
        .expect("prepare_save should succeed");

        assert_eq!(prepared.partition_key, "");
        assert_eq!(
            prepared.record_key,
            "gate1_sync:state|0:|6:app_id|9|10:position_9"
        );
        assert_eq!(
            prepared.partition_index_key,
            "gate1_sync:partition_index|0:"
        );
        assert_eq!(prepared.app_index_key, "gate1_sync:app_index|0:|6:app_id");
        assert_eq!(prepared.partition_app_ids_key, "gate1_sync:app_members|0:");
        assert_eq!(prepared.status, "completed");
        assert_eq!(prepared.sequence_id, 9);
        assert!(prepared
            .partition_index_member
            .starts_with(&prepared.created_at));
        assert!(prepared
            .app_index_member
            .starts_with("00000000000000000009|"));
        assert_eq!(
            app_id_from_partition_index_member(&prepared.partition_index_member)
                .expect("partition member should decode app id"),
            "app_id"
        );
        assert_eq!(
            record_key_from_partition_index_member(&prepared.partition_index_member)
                .expect("partition member should decode record key"),
            prepared.record_key
        );
        assert_eq!(
            created_at_from_partition_index_member(&prepared.partition_index_member)
                .expect("partition member should decode created_at"),
            prepared.created_at
        );
        assert_ne!(
            state_key("gate1_sync", "a:b", "c", 1, "position"),
            state_key("gate1_sync", "a", "b:c", 1, "position"),
            "length-encoded key segments must prevent delimiter collisions",
        );
        assert_ne!(
            state_key("gate1_sync", "tenant", "app_id", 1, "left"),
            state_key("gate1_sync", "tenant", "app_id", 1, "right"),
            "position must participate in the primary record identity",
        );
    }

    #[test]
    fn hash_to_persisted_state_roundtrips_manual_hash() {
        let fields = HashMap::from([
            ("partition_key".to_string(), String::new()),
            ("app_id".to_string(), "app_id".to_string()),
            ("sequence_id".to_string(), "9".to_string()),
            ("position".to_string(), "position_9".to_string()),
            (
                "state".to_string(),
                serde_json::to_string(&IndexMap::from([("key".to_string(), json!("value"))]))
                    .expect("state serialization should succeed"),
            ),
            ("status".to_string(), "completed".to_string()),
            ("created_at".to_string(), "2026-03-18T00:00:00Z".to_string()),
        ]);

        let loaded =
            hash_to_persisted_state(fields).expect("manual persisted hash should deserialize");
        assert_eq!(loaded.partition_key.as_deref(), Some(""));
        assert_eq!(loaded.app_id, "app_id");
        assert_eq!(loaded.sequence_id, 9);
        assert_eq!(loaded.position.as_deref(), Some("position_9"));
        assert_eq!(
            loaded.state,
            Some(IndexMap::from([("key".to_string(), json!("value"))])),
        );
        assert_eq!(loaded.status, PersistedStateStatus::Completed);
    }

    #[test]
    fn partition_index_member_roundtrips_namespaced_record_key_and_pipe_heavy_app_id() {
        let record_key = state_key(
            "ns:pipey",
            "tenant|alpha",
            "app|with|pipes",
            7,
            "position|beta",
        );
        let member = partition_index_member(
            &record_key,
            "app|with|pipes",
            7,
            "position|beta",
            "2026-03-20T00:00:00.000000000Z",
        );

        assert_eq!(
            app_id_from_partition_index_member(&member)
                .expect("partition member should decode app id"),
            "app|with|pipes"
        );
        assert_eq!(
            record_key_from_partition_index_member(&member)
                .expect("partition member should decode record key"),
            record_key
        );
        assert_eq!(
            created_at_from_partition_index_member(&member)
                .expect("partition member should decode created_at"),
            "2026-03-20T00:00:00.000000000Z"
        );
    }

    #[test]
    fn prepare_save_accepts_u64_max_sequence_ids() {
        let prepared = prepare_save(
            "gate1_sync",
            None,
            "app_id",
            u64::MAX,
            "position_large",
            &IndexMap::from([("key".to_string(), json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .expect("large sequence ids should be accepted");

        assert_eq!(
            prepared.record_key,
            "gate1_sync:state|0:|6:app_id|18446744073709551615|14:position_large"
        );
    }
}
