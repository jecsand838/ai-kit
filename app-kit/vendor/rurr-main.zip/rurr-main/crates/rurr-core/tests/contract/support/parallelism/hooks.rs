use async_trait::async_trait;
use rurr_core::application::{ParentPointer, Tracker};
use rurr_core::graph::Graph;
use rurr_core::lifecycle::LifecycleError;
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, PostStepContext, PreStepContext, SyncLifecycleAdapter,
};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

#[derive(Debug)]
pub(crate) struct PreStepCounter {
    count: Arc<AtomicUsize>,
}

impl PreStepCounter {
    pub(crate) fn new(count: Arc<AtomicUsize>) -> Self {
        Self { count }
    }
}

impl SyncLifecycleAdapter for PreStepCounter {
    fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        self.count.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct StepPostRecorder {
    pub(crate) sync_post_run_step: AtomicUsize,
    pub(crate) async_post_run_step: AtomicUsize,
    async_records: Mutex<Vec<(String, Option<String>)>>,
}

impl StepPostRecorder {
    pub(crate) fn async_records(&self) -> Vec<(String, Option<String>)> {
        self.async_records
            .lock()
            .expect("async_records lock should not be poisoned")
            .clone()
    }
}

impl SyncLifecycleAdapter for StepPostRecorder {
    fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        self.sync_post_run_step.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for StepPostRecorder {
    async fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.async_post_run_step.fetch_add(1, Ordering::SeqCst);
        self.async_records
            .lock()
            .expect("async_records lock should not be poisoned")
            .push((
                context.app_id().unwrap_or("<missing>").to_string(),
                context.exception().map(str::to_string),
            ));
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct ChildRegistrationRecorder {
    child_app_ids: Mutex<Vec<String>>,
}

impl ChildRegistrationRecorder {
    pub(crate) fn child_app_ids(&self) -> Vec<String> {
        self.child_app_ids
            .lock()
            .expect("child_app_ids lock should not be poisoned")
            .clone()
    }

    fn record_child_app_id(&self, child_app_id: &str) {
        self.child_app_ids
            .lock()
            .expect("child_app_ids lock should not be poisoned")
            .push(child_app_id.to_string());
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for ChildRegistrationRecorder {
    async fn register_child_application(
        &self,
        child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.record_child_app_id(child_app_id);
        Ok(())
    }
}

impl SyncLifecycleAdapter for ChildRegistrationRecorder {
    fn register_child_application(
        &self,
        child_app_id: &str,
        _partition_key: Option<&str>,
        _graph: &Graph,
        _parent_pointer: Option<&ParentPointer>,
        _spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.record_child_app_id(child_app_id);
        Ok(())
    }
}

#[derive(Debug, Default)]
pub(crate) struct RecordingTracker {
    sync_post_run_app_ids: Mutex<Vec<String>>,
    async_post_run_app_ids: Mutex<Vec<String>>,
}

impl RecordingTracker {
    pub(crate) fn sync_post_run_app_ids(&self) -> Vec<String> {
        self.sync_post_run_app_ids
            .lock()
            .expect("sync_post_run_app_ids lock should not be poisoned")
            .clone()
    }
}

impl SyncLifecycleAdapter for RecordingTracker {
    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.sync_post_run_app_ids
            .lock()
            .expect("sync_post_run_app_ids lock should not be poisoned")
            .push(context.app_id().unwrap_or("<missing>").to_string());
        Ok(())
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for RecordingTracker {
    async fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.async_post_run_app_ids
            .lock()
            .expect("async_post_run_app_ids lock should not be poisoned")
            .push(context.app_id().unwrap_or("<missing>").to_string());
        Ok(())
    }
}

impl Tracker for RecordingTracker {
    fn sync_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn SyncLifecycleAdapter>> {
        Some(self)
    }

    fn async_lifecycle_adapter(self: Arc<Self>) -> Option<Arc<dyn AsyncLifecycleAdapter>> {
        Some(self)
    }
}
