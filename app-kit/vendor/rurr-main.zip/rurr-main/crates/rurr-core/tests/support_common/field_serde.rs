use rurr_core::state::{register_field_serde, StateError};
use serde_json::{Map, Value};

pub(crate) fn register_prefixed_string_field_serde(
    field_name: &str,
    prefix: &str,
) -> Result<(), StateError> {
    let serializer_prefix = prefix.to_string();
    let deserializer_prefix = prefix.to_string();
    register_field_serde(
        field_name,
        move |value| {
            let mut object = Map::new();
            object.insert(
                "value".to_string(),
                Value::String(format!(
                    "{serializer_prefix}{}",
                    value
                        .as_str()
                        .expect("field serializer expects a string input")
                )),
            );
            Value::Object(object)
        },
        move |value| {
            let object = value
                .as_object()
                .expect("field deserializer expects an object input");
            let serialized = object
                .get("value")
                .and_then(Value::as_str)
                .expect("field payload should contain string field 'value'");
            Value::String(
                serialized
                    .strip_prefix(&deserializer_prefix)
                    .unwrap_or(serialized)
                    .to_string(),
            )
        },
    )
}
