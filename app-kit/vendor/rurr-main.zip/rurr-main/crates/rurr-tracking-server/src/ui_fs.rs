use crate::backend::BackendError;
use crate::router::UiDirectory;
use rurr_tracking_store::anchored_fs::AnchoredDir;
use std::io::{self, ErrorKind};
use std::path::{Path, PathBuf};

const INDEX_FILENAME: &str = "index.html";
const ASSETS_DIRNAME: &str = "assets";

/// Filesystem-backed UI bundle rooted at a caller-supplied directory.
///
/// Instances are created indirectly through [`crate::router::AppState::with_ui_dir`].
#[derive(Debug, Clone)]
pub struct DirectoryUiFs {
    ui_root: AnchoredDir,
    assets_root: AssetsRootState,
}

#[derive(Debug, Clone)]
enum AssetsRootState {
    Missing,
    Available { root: AnchoredDir },
    Invalid { message: String },
}

/// Validation error returned while normalizing a UI asset path.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AssetPathError {
    /// The request path resolved to an empty asset path.
    Empty,
    /// The path contained invalid or escaping segments.
    Invalid,
}

/// Canonical relative asset path accepted by the UI filesystem helpers.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct NormalizedAssetPath {
    normalized: String,
}

impl UiDirectory {
    pub(crate) fn prepare(ui_dir: PathBuf) -> Result<Self, BackendError> {
        Ok(Self {
            fs: DirectoryUiFs::prepare(ui_dir)?,
        })
    }

    pub(crate) fn read_index_html(&self) -> Result<String, BackendError> {
        self.fs.read_index_html()
    }

    pub(crate) fn read_asset(
        &self,
        raw_path: &str,
    ) -> Result<(&'static str, Vec<u8>), BackendError> {
        self.fs.read_asset(raw_path)
    }
}

impl DirectoryUiFs {
    fn prepare(ui_dir: PathBuf) -> Result<Self, BackendError> {
        let ui_root = open_requested_directory(&ui_dir, "ui_dir")?;
        validate_required_index_target(&ui_dir, &ui_root)?;
        let assets_root =
            match ui_root.open_child_dir_if_present("ui directory", "asset root", ASSETS_DIRNAME) {
                Ok(Some(root)) => AssetsRootState::Available { root },
                Ok(None) => AssetsRootState::Missing,
                Err(error) if error.kind() == ErrorKind::NotFound => AssetsRootState::Missing,
                Err(error) if error.kind() == ErrorKind::InvalidInput => AssetsRootState::Invalid {
                    message: error.to_string(),
                },
                Err(error) => return Err(map_invalid_input_or_io(error)),
            };

        Ok(Self {
            ui_root,
            assets_root,
        })
    }

    fn read_index_html(&self) -> Result<String, BackendError> {
        self.ui_root
            .read_required_child_to_string("ui directory", "ui index", INDEX_FILENAME)
            .map_err(|error| {
                map_named_file_runtime_error(
                    format!(
                        "ui index '{}'",
                        self.ui_root.display_path().join(INDEX_FILENAME).display()
                    ),
                    error,
                )
            })
    }

    fn read_asset(&self, raw_path: &str) -> Result<(&'static str, Vec<u8>), BackendError> {
        let relative_path = validate_asset_request_path(raw_path)?;
        let assets_root = match &self.assets_root {
            AssetsRootState::Missing => {
                return Err(BackendError::NotFound {
                    resource: format!(
                        "asset root '{}'",
                        self.ui_root.display_path().join(ASSETS_DIRNAME).display()
                    ),
                });
            }
            AssetsRootState::Invalid { message } => {
                return Err(BackendError::InvalidRequest {
                    message: message.clone(),
                });
            }
            AssetsRootState::Available { root } => root,
        };

        let bytes = assets_root
            .read_required_descendant_bytes("asset root", "asset path", relative_path.as_str())
            .map_err(|error| {
                map_named_file_runtime_error(format!("asset '{}'", relative_path.as_str()), error)
            })?;
        Ok((content_type_for_asset(relative_path.as_str()), bytes))
    }
}

impl NormalizedAssetPath {
    pub(crate) fn as_str(&self) -> &str {
        &self.normalized
    }
}

/// Normalizes a user-supplied asset request path.
///
/// Leading `/` and `assets/` prefixes are removed, and the remaining path must
/// stay within the asset tree.
///
/// # Examples
///
/// ```rust
/// let path = rurr_tracking_server::ui_fs::normalize_asset_path("/assets/js/app.js")?;
/// assert_eq!(path, rurr_tracking_server::ui_fs::normalize_asset_path("js/app.js")?);
/// # Ok::<(), rurr_tracking_server::ui_fs::AssetPathError>(())
/// ```
pub fn normalize_asset_path(raw: &str) -> Result<NormalizedAssetPath, AssetPathError> {
    let trimmed = raw.trim_start_matches('/');
    let normalized = trimmed.strip_prefix("assets/").unwrap_or(trimmed);
    if normalized.is_empty() {
        return Err(AssetPathError::Empty);
    }
    let mut segments = Vec::new();
    for segment in normalized.split('/') {
        if segment.is_empty() || segment == "." || segment == ".." || segment.contains('\\') {
            return Err(AssetPathError::Invalid);
        }
        segments.push(segment.to_string());
    }

    if segments.is_empty() {
        return Err(AssetPathError::Empty);
    }

    let normalized = segments.join("/");

    Ok(NormalizedAssetPath { normalized })
}

/// Normalizes a user-supplied asset path and maps failures into
/// [`BackendError`].
///
/// # Examples
///
/// ```rust
/// let error = rurr_tracking_server::ui_fs::validate_asset_request_path("../escape.js")
///     .expect_err("parent traversal should be rejected");
/// assert!(matches!(
///     error,
///     rurr_tracking_server::backend::BackendError::InvalidRequest { .. }
/// ));
/// ```
pub fn validate_asset_request_path(raw: &str) -> Result<NormalizedAssetPath, BackendError> {
    normalize_asset_path(raw).map_err(|error| map_asset_path_error(raw, error))
}

/// Converts low-level I/O errors into request-facing backend errors.
///
/// Invalid-input errors are surfaced as client mistakes; all others remain I/O
/// failures.
///
/// # Examples
///
/// ```rust
/// let error = std::io::Error::new(std::io::ErrorKind::InvalidInput, "bad path");
/// let mapped = rurr_tracking_server::ui_fs::map_invalid_input_or_io(error);
/// assert!(matches!(
///     mapped,
///     rurr_tracking_server::backend::BackendError::InvalidRequest { .. }
/// ));
/// ```
pub fn map_invalid_input_or_io(error: io::Error) -> BackendError {
    match error.kind() {
        ErrorKind::InvalidInput => BackendError::InvalidRequest {
            message: error.to_string(),
        },
        _ => BackendError::Io(error),
    }
}

/// Converts directory-open errors into request-facing backend errors.
///
/// # Examples
///
/// ```rust
/// let missing = std::io::Error::new(std::io::ErrorKind::NotFound, "missing");
/// let mapped = rurr_tracking_server::ui_fs::map_requested_directory_error(
///     "ui_dir",
///     std::path::Path::new("/tmp/missing-ui"),
///     missing,
/// );
/// assert!(matches!(
///     mapped,
///     rurr_tracking_server::backend::BackendError::NotFound { .. }
/// ));
/// ```
pub fn map_requested_directory_error(
    label: &str,
    requested_path: &Path,
    error: io::Error,
) -> BackendError {
    match error.kind() {
        ErrorKind::NotFound => BackendError::NotFound {
            resource: format!("{label} '{}'", requested_path.display()),
        },
        ErrorKind::InvalidInput => BackendError::InvalidRequest {
            message: error.to_string(),
        },
        _ => BackendError::Io(error),
    }
}

fn map_asset_path_error(raw: &str, error: AssetPathError) -> BackendError {
    match error {
        AssetPathError::Empty => BackendError::InvalidRequest {
            message: "asset path cannot be empty".to_string(),
        },
        AssetPathError::Invalid => BackendError::InvalidRequest {
            message: format!("invalid asset path '{raw}'"),
        },
    }
}

fn open_requested_directory(
    requested_path: &Path,
    label: &str,
) -> Result<AnchoredDir, BackendError> {
    AnchoredDir::open(requested_path)
        .map_err(|error| map_requested_directory_error(label, requested_path, error))
}

fn validate_required_index_target(
    ui_dir: &Path,
    ui_root: &AnchoredDir,
) -> Result<(), BackendError> {
    ui_root
        .child_file_exists("ui directory", "ui index", INDEX_FILENAME)
        .and_then(|exists| {
            if exists {
                Ok(())
            } else {
                Err(io::Error::new(ErrorKind::NotFound, "missing"))
            }
        })
        .map_err(|error| {
            map_required_index_validation_error(
                ui_dir,
                &ui_root.display_path().join(INDEX_FILENAME),
                error,
            )
        })
}

fn map_required_index_validation_error(
    ui_dir: &Path,
    index_path: &Path,
    error: io::Error,
) -> BackendError {
    match error.kind() {
        ErrorKind::NotFound => BackendError::InvalidRequest {
            message: format!(
                "ui dir '{}' is missing required index.html at '{}'",
                ui_dir.display(),
                index_path.display()
            ),
        },
        ErrorKind::InvalidInput => BackendError::InvalidRequest {
            message: error.to_string(),
        },
        _ => BackendError::InvalidRequest {
            message: format!(
                "ui dir '{}' index.html is not readable at '{}': {error}",
                ui_dir.display(),
                index_path.display()
            ),
        },
    }
}

fn map_named_file_runtime_error(resource: String, error: io::Error) -> BackendError {
    match error.kind() {
        ErrorKind::NotFound => BackendError::NotFound { resource },
        ErrorKind::InvalidInput => BackendError::InvalidRequest {
            message: error.to_string(),
        },
        _ => BackendError::Io(error),
    }
}

fn content_type_for_asset(path: &str) -> &'static str {
    match Path::new(path)
        .extension()
        .and_then(|extension| extension.to_str())
    {
        Some("css") => "text/css; charset=utf-8",
        Some("js") => "application/javascript; charset=utf-8",
        Some("html") => "text/html; charset=utf-8",
        Some("json") => "application/json; charset=utf-8",
        Some("svg") => "image/svg+xml",
        Some("png") => "image/png",
        Some("jpg") | Some("jpeg") => "image/jpeg",
        Some("gif") => "image/gif",
        Some("ico") => "image/x-icon",
        _ => "application/octet-stream",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn normalize_asset_path_rejects_empty_inputs_without_panicking() {
        assert_eq!(normalize_asset_path("").unwrap_err(), AssetPathError::Empty);
        assert_eq!(
            normalize_asset_path("/assets/").unwrap_err(),
            AssetPathError::Empty
        );
    }

    #[test]
    fn normalize_asset_path_rejects_invalid_segments_without_panicking() {
        for raw in [
            "assets//app.js",
            "assets/./app.js",
            "assets/../app.js",
            "assets\\app.js",
        ] {
            assert_eq!(
                normalize_asset_path(raw).unwrap_err(),
                AssetPathError::Invalid,
                "path {raw:?} should be rejected"
            );
        }
    }

    #[test]
    fn normalize_asset_path_preserves_safe_relative_asset_path() {
        let rooted = normalize_asset_path("/assets/js/app.js").expect("path should normalize");
        let relative = normalize_asset_path("js/app.js").expect("path should normalize");

        assert_eq!(rooted.as_str(), "js/app.js");
        assert_eq!(relative.as_str(), "js/app.js");
    }

    #[test]
    fn validate_asset_request_path_maps_typed_errors_to_backend_errors() {
        let empty = validate_asset_request_path("/assets/")
            .expect_err("empty asset path should map to a backend error");
        let invalid = validate_asset_request_path("assets/../leak.js")
            .expect_err("invalid asset path should map to a backend error");

        match empty {
            BackendError::InvalidRequest { message } => {
                assert_eq!(message, "asset path cannot be empty");
            }
            other => panic!("unexpected empty-path error: {other:?}"),
        }

        match invalid {
            BackendError::InvalidRequest { message } => {
                assert_eq!(message, "invalid asset path 'assets/../leak.js'");
            }
            other => panic!("unexpected invalid-path error: {other:?}"),
        }
    }
}
