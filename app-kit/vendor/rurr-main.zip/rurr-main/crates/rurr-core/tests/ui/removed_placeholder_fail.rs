use rurr_core::Placeholder;

fn main() {
    let _ = core::mem::size_of::<Placeholder>();
}
