use rurr_core as crate_api;

include!("../../test_support/parallelism_public_api.inc.rs");
