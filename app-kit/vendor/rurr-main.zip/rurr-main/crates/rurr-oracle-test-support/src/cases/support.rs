use crate::manifest::BurrOracleScenario;
use indexmap::IndexMap;
use rurr_core::action::{ActionError, FunctionActionBuilder, LocalAction};
use rurr_core::application::{Application, ApplicationBuilder, InitializeFromSpec};
use rurr_core::lifecycle::LifecycleAdapterSet;
use rurr_core::state::State;
use rurr_core::tracking::LocalTrackingClient;
use rurr_persistence::{
    ApplicationPersistenceSpec, BaseStateLoader, BaseStatePersister, StateInitializerSpec,
    StatePersisterSpec,
};
use serde_json::{json, Value};
use std::error::Error;
use std::sync::Arc;

pub(super) const RURR_COUNTER_SOURCE: &str = concat!(
    "FunctionActionBuilder::new()\n",
    "    .reads([\"count\"])\n",
    "    .writes([\"count\"])\n",
    "    .build_sync(|state, _ctx| {\n",
    "        let next_count = state.get(\"count\").and_then(Value::as_i64).unwrap_or(0) + 1;\n",
    "        map_from_pairs([(\"count\", json!(next_count))])\n",
    "    })\n",
);

pub(super) fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
    pairs
        .into_iter()
        .map(|(key, value)| (key.to_string(), value))
        .collect()
}

pub(super) fn build_registered_app(
    builder: ApplicationBuilder,
    app_id: &str,
    partition_key: &str,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<Application, Box<dyn Error>> {
    let app = builder
        .with_identifiers(app_id, Some(partition_key.to_string()), None)?
        .with_hooks(hooks.clone())?
        .build()?;
    register_application(tracker.as_ref(), &app)?;
    Ok(app)
}

pub(super) fn build_registered_app_from_definition(
    builder: ApplicationBuilder,
    definition: &BurrOracleScenario,
    tracker: &Arc<LocalTrackingClient>,
    hooks: &LifecycleAdapterSet,
) -> Result<Application, Box<dyn Error>> {
    build_registered_app(
        builder,
        &definition.app_id,
        &definition.partition_key,
        tracker,
        hooks,
    )
}

pub(super) fn register_application(
    tracker: &LocalTrackingClient,
    app: &Application,
) -> Result<(), Box<dyn Error>> {
    tracker.register_application(
        app.uid(),
        app.partition_key(),
        app.graph(),
        app.parent_pointer().cloned(),
        app.spawning_parent_pointer().cloned(),
    )?;
    Ok(())
}

pub(super) fn build_counter_action() -> Result<impl LocalAction + Clone, ActionError> {
    FunctionActionBuilder::new()
        .reads(["count"])
        .writes(["count"])
        .with_source_code(RURR_COUNTER_SOURCE)
        .build_sync(|state, _ctx| {
            let next_count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
            map_from_pairs([("count", json!(next_count))])
        })
}

pub(super) fn sync_initializer_spec(
    initializer: Arc<dyn BaseStateLoader>,
    default_state: IndexMap<String, Value>,
    default_entrypoint: &str,
) -> ApplicationPersistenceSpec {
    ApplicationPersistenceSpec::new().with_initializer(StateInitializerSpec::sync(
        initializer,
        true,
        default_state,
        default_entrypoint,
        None,
    ))
}

pub(super) fn sync_persistence_spec(
    initializer: Arc<dyn BaseStateLoader>,
    persister: Arc<dyn BaseStatePersister>,
    default_state: IndexMap<String, Value>,
    default_entrypoint: &str,
) -> ApplicationPersistenceSpec {
    sync_initializer_spec(initializer, default_state, default_entrypoint)
        .with_persister(StatePersisterSpec::sync(persister))
}

pub(super) fn initialize_from_spec(
    resume_at_next_action: bool,
    default_state: IndexMap<String, Value>,
    default_entrypoint: &str,
) -> InitializeFromSpec {
    InitializeFromSpec::new(
        resume_at_next_action,
        default_state,
        default_entrypoint.to_string(),
    )
}

pub(super) fn state_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> State {
    State::new(map_from_pairs(pairs))
}
