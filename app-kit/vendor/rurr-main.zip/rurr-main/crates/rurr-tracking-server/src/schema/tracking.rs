use rurr_core::tracking::{
    ApplicationModel, AttributeModel, BeginEntryModel, BeginSpanModel, ChildApplicationModel,
    EndEntryModel, EndSpanModel, EndStreamModel, FirstItemStreamModel, InitializeStreamModel,
    PointerModel,
};
use rurr_tracking_store::tracked_log::{
    scan_values, ProjectedSpan, ProjectedStep, TrackingLogScanOptions,
};
use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;

/// Readiness response returned by `/ready`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ReadyResponse {
    /// Whether the tracking server is ready to serve requests.
    pub ready: bool,
}

/// Project row returned by `/api/v0/projects`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Project {
    /// Project display name.
    pub name: String,
    /// Project identifier.
    pub id: String,
    /// Last write time formatted as RFC3339 UTC.
    pub last_written: String,
    /// Creation time formatted as RFC3339 UTC.
    pub created: String,
    /// Number of tracked applications in this project.
    pub num_apps: usize,
    /// Project source URI when it is carried by stored tracking data.
    pub uri: Option<String>,
}

/// Summary row returned when listing applications for one project.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ApplicationSummary {
    /// Application identifier.
    pub app_id: String,
    /// Optional partition key associated with the application.
    pub partition_key: Option<String>,
    /// First observed write time formatted as RFC3339 UTC.
    pub first_written: String,
    /// Last observed write time formatted as RFC3339 UTC.
    pub last_written: String,
    /// Number of steps observed for this application.
    pub num_steps: u64,
    /// Application tags exposed by Burr's server payload.
    pub tags: BTreeMap<String, String>,
    /// Fork parent pointer, when available.
    pub parent_pointer: Option<PointerModel>,
    /// Spawning parent pointer, when available.
    pub spawning_parent_pointer: Option<PointerModel>,
}

/// Paginated application listing payload.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ApplicationPage {
    /// Application rows for the requested slice.
    pub applications: Vec<ApplicationSummary>,
    /// Total number of matching applications.
    pub total: usize,
    /// Whether another page exists after this page.
    pub has_another_page: bool,
}

/// Visibility span grouped under one application step.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct Span {
    /// Span begin log entry.
    pub begin_entry: BeginSpanModel,
    /// Span end log entry, absent for in-progress or incomplete spans.
    pub end_entry: Option<EndSpanModel>,
}

/// Streaming log entry grouped under one application step.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(untagged)]
pub enum StreamEvent {
    /// Stream initialization event.
    Initialize(InitializeStreamModel),
    /// First item event.
    FirstItem(FirstItemStreamModel),
    /// Stream completion event.
    End(EndStreamModel),
}

/// Grouped log entries for one application step.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Step {
    /// Step begin log entry.
    pub step_start_log: BeginEntryModel,
    /// Step end log entry, absent for incomplete steps.
    pub step_end_log: Option<EndEntryModel>,
    /// Visibility spans associated with the step.
    pub spans: Vec<Span>,
    /// Attributes logged during the step.
    pub attributes: Vec<AttributeModel>,
    /// Streaming lifecycle events associated with the step.
    pub streaming_events: Vec<StreamEvent>,
}

/// Full application log payload returned by the app detail route.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ApplicationLogs {
    /// Application graph model.
    pub application: ApplicationModel,
    /// Child application records associated with the application.
    pub children: Vec<ChildApplicationModel>,
    /// Grouped steps reconstructed from raw log entries.
    pub steps: Vec<Step>,
    /// Fork parent pointer, when available.
    pub parent_pointer: Option<PointerModel>,
    /// Spawning parent pointer, when available.
    pub spawning_parent_pointer: Option<PointerModel>,
}

/// Groups raw tracking log JSON values into Burr-compatible step payloads.
pub fn project_steps(log: Vec<Value>) -> Result<Vec<Step>, serde_json::Error> {
    steps_from_projection(scan_values(&log, TrackingLogScanOptions::full_projection())?.steps)
}

/// Returns Burr's visible step count from raw log values.
pub fn visible_step_count(log: &[Value]) -> Result<u64, serde_json::Error> {
    Ok(scan_values(log, TrackingLogScanOptions::summary())?.visible_count)
}

pub(crate) fn steps_from_projection(
    steps: Vec<ProjectedStep>,
) -> Result<Vec<Step>, serde_json::Error> {
    steps.into_iter().map(Step::try_from).collect()
}

impl TryFrom<ProjectedStep> for Step {
    type Error = serde_json::Error;

    fn try_from(step: ProjectedStep) -> Result<Self, Self::Error> {
        Ok(Self {
            step_start_log: serde_json::from_value(step.begin)?,
            step_end_log: step.end.map(serde_json::from_value).transpose()?,
            spans: step
                .spans
                .into_iter()
                .map(Span::try_from)
                .collect::<Result<Vec<_>, _>>()?,
            attributes: step
                .attributes
                .into_iter()
                .map(serde_json::from_value)
                .collect::<Result<Vec<AttributeModel>, _>>()?,
            streaming_events: step
                .streaming_events
                .into_iter()
                .map(stream_event_from_value)
                .collect::<Result<Vec<_>, _>>()?,
        })
    }
}

impl TryFrom<ProjectedSpan> for Span {
    type Error = serde_json::Error;

    fn try_from(span: ProjectedSpan) -> Result<Self, Self::Error> {
        Ok(Self {
            begin_entry: serde_json::from_value(span.begin)?,
            end_entry: span.end.map(serde_json::from_value).transpose()?,
        })
    }
}

fn stream_event_from_value(value: Value) -> Result<StreamEvent, serde_json::Error> {
    match value.get("type").and_then(Value::as_str) {
        Some("begin_stream") => serde_json::from_value(value).map(StreamEvent::Initialize),
        Some("first_item_stream") => serde_json::from_value(value).map(StreamEvent::FirstItem),
        Some("end_stream") => serde_json::from_value(value).map(StreamEvent::End),
        other => Err(serde::de::Error::custom(format!(
            "unexpected streaming event type: {other:?}"
        ))),
    }
}
