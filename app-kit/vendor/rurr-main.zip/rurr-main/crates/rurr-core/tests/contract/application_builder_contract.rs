use super::support::application::{
    fixed_async_initializer as async_initializer_with, fixed_async_persister as async_persister,
    fixed_sync_initializer as sync_initializer_with, fixed_sync_persister as sync_persister,
    initialize_from_spec, persisted_state_fixture as persisted_state, FixedAsyncInitializer,
    FixedAsyncPersister, FixedSyncInitializer, FixedSyncPersister, NoopParallelExecutor,
    NoopTracker,
};
use crate::test_support::{
    registry_test_guard, unique_registry_name, with_async_initializer_spec,
    with_async_persister_spec, with_sync_initializer_spec, with_sync_persister_spec,
    PassthroughTypingSystem, ResumeRoundTripTypingSystem, ResumeStateTypingSystem,
};
use indexmap::IndexMap;
use rurr_core::action::{Condition, FunctionActionBuilder, LocalAction};
use rurr_core::application::{ApplicationBuilder, ApplicationError, Tracker, TrackerSpec};
use rurr_core::graph::{Graph, GraphAction, GraphError, Transition};
use rurr_core::lifecycle::{AsyncLifecycleAdapter, LifecycleAdapterSet, SyncLifecycleAdapter};
use rurr_core::parallelism::ParallelExecutor;
use rurr_core::serde::{register_serde_deserializer, KEY};
use rurr_core::state::{State, StateError, TypingSystem};
use rurr_core::tracking::LocalTrackingClient;
use rurr_persistence::{
    ApplicationPersistenceSpec, BaseStateLoader, BaseStatePersister, PersistedStateStatus,
    PersistenceLoadTarget, StateInitializerSpec, StatePersisterSpec,
};
use rurr_testkit::{
    application_fixture::{map_from_pairs, state_from_pairs},
    test_dir,
};
use serde_json::{json, Value};
use std::sync::Arc;
use uuid::Uuid;

fn graph_action(name: &str) -> GraphAction {
    let action = FunctionActionBuilder::new()
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("function action should build")
        .with_name(name)
        .expect("naming function action should succeed");
    GraphAction::new(action).expect("graph action construction should succeed")
}

fn graph_with(actions: Vec<GraphAction>, transitions: Vec<Transition>, entrypoint: &str) -> Graph {
    Graph::new(actions, transitions, entrypoint).expect("graph construction should succeed")
}

fn alpha_omega_graph(entrypoint: &str) -> Graph {
    graph_with(
        vec![graph_action("alpha"), graph_action("omega")],
        vec![Transition::new("alpha", "omega", Condition::default())],
        entrypoint,
    )
}

fn unnamed_function_action() -> impl LocalAction {
    FunctionActionBuilder::new()
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("function action should build")
}

fn base_builder() -> ApplicationBuilder {
    ApplicationBuilder::new()
        .with_actions(vec![graph_action("noop")])
        .expect("adding noop action should succeed")
        .with_transitions(Vec::<Transition>::new())
        .expect("empty transitions should be accepted")
}

fn noop_entry_builder() -> ApplicationBuilder {
    base_builder()
        .with_entrypoint("noop")
        .expect("entrypoint should configure")
}

fn tracked_noop_entry_builder(mode: BuildMode) -> ApplicationBuilder {
    let action = match mode {
        BuildMode::Sync => FunctionActionBuilder::new()
            .with_source_code("fn noop(_state, _ctx) -> () {}")
            .build_sync(|_state, _ctx| IndexMap::new())
            .expect("tracked sync noop action should build"),
        BuildMode::Async => FunctionActionBuilder::new()
            .with_source_code("async fn noop(_state, _ctx) -> () {}")
            .build_async(|_state, _ctx| async move { IndexMap::new() })
            .expect("tracked async noop action should build"),
    };
    ApplicationBuilder::new()
        .with_actions(vec![("noop", action)])
        .expect("tracked noop action should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("empty transitions should be accepted")
        .with_entrypoint("noop")
        .expect("entrypoint should configure")
}

fn completed_noop_state(state: IndexMap<String, Value>) -> rurr_persistence::PersistedStateData {
    persisted_state(Some(state), Some("noop"), PersistedStateStatus::Completed)
}

fn completed_count_state(count: i64) -> rurr_persistence::PersistedStateData {
    completed_noop_state(map_from_pairs([("count", json!(count))]))
}

fn empty_completed_noop_state() -> rurr_persistence::PersistedStateData {
    completed_noop_state(IndexMap::new())
}

fn failed_state_without_position(
    state: IndexMap<String, Value>,
) -> rurr_persistence::PersistedStateData {
    persisted_state(Some(state), None, PersistedStateStatus::Failed)
}

fn assert_resume_initialized_app(
    app: &rurr_core::Application,
    uid: &str,
    partition_key: Option<&str>,
    count: i64,
    parent_pointer: Option<(&str, Option<&str>, Option<u64>)>,
) {
    assert_eq!(app.uid(), uid);
    assert_eq!(app.partition_key(), partition_key);

    let expected_parent_pointer = parent_pointer.map(|(app_id, partition_key, sequence_id)| {
        rurr_core::application::ParentPointer {
            app_id: app_id.to_string(),
            partition_key: partition_key.map(str::to_string),
            sequence_id,
        }
    });
    assert_eq!(app.parent_pointer(), expected_parent_pointer.as_ref());
    assert_eq!(app.state().get("count"), Some(&json!(count)));
    assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(7)));
    assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("noop")));
}

fn assert_sync_initializer_ptr(app: &rurr_core::Application, expected: &Arc<dyn BaseStateLoader>) {
    assert!(Arc::ptr_eq(
        app.state_initializer()
            .expect("state initializer should be configured")
            .as_sync()
            .expect("state initializer should be sync"),
        expected
    ));
}

fn assert_sync_persister_ptr(app: &rurr_core::Application, expected: &Arc<dyn BaseStatePersister>) {
    assert!(Arc::ptr_eq(
        app.state_persister()
            .expect("state persister should be configured")
            .as_sync()
            .expect("state persister should be sync"),
        expected
    ));
}

fn build_sync_persister_app(persister: Arc<dyn BaseStatePersister>) -> rurr_core::Application {
    with_sync_persister_spec(noop_entry_builder(), persister)
        .expect("sync persister should be accepted")
        .build()
        .expect("build should succeed with sync persister")
}

fn build_sync_initializer_app(
    initializer: Arc<dyn BaseStateLoader>,
    default_state: IndexMap<String, Value>,
) -> rurr_core::Application {
    with_sync_initializer_spec(
        base_builder(),
        initializer,
        false,
        default_state,
        "noop",
        None,
        None,
    )
    .expect("sync initializer should configure")
    .build()
    .expect("build should succeed with sync loader")
}

fn tracking_log_path(
    storage_dir: &std::path::Path,
    tracker_name: &str,
    app_id: &str,
) -> std::path::PathBuf {
    storage_dir
        .join(tracker_name)
        .join(app_id)
        .join("log.jsonl")
}

fn log_entry_count(log_contents: &str, entry_type: &str) -> usize {
    log_contents
        .lines()
        .filter(|line| !line.trim().is_empty())
        .filter_map(|line| serde_json::from_str::<Value>(line).ok())
        .filter(|line| line.get("type").and_then(Value::as_str) == Some(entry_type))
        .count()
}

fn assert_uuid_like(id: &str) {
    assert!(
        Uuid::parse_str(id).is_ok(),
        "auto-generated app_id should be UUIDv4-compatible"
    );
}

fn assert_fresh_initialize_miss(mut app: rurr_core::Application) {
    assert_eq!(app.state().get("count"), Some(&json!(0)));
    assert_eq!(app.state().get("__SEQUENCE_ID"), None);

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");
    assert_eq!(step.action.name(), "noop");
    assert_eq!(step.state.get("__SEQUENCE_ID"), Some(&json!(0)));
}

fn failed_initializer_without_position_builder(resume_at_next_action: bool) -> ApplicationBuilder {
    let loaded = failed_state_without_position(map_from_pairs([("x", json!(1))]));

    with_sync_initializer_spec(
        base_builder(),
        sync_initializer_with(Some(loaded)),
        resume_at_next_action,
        map_from_pairs([("x", json!(0))]),
        "noop",
        None,
        None,
    )
    .expect("initializer spec should configure")
}

#[derive(Clone, Copy)]
enum BuildMode {
    Sync,
    Async,
}

impl BuildMode {
    async fn build(self, builder: ApplicationBuilder) -> rurr_core::Application {
        match self {
            Self::Sync => builder.build().expect("sync build should succeed"),
            Self::Async => builder.abuild().await.expect("async build should succeed"),
        }
    }
}

fn initialize_from_count_builder(
    uid: &str,
    partition_key: &str,
    sequence_id: u64,
    loaded: Option<rurr_persistence::PersistedStateData>,
    fork_target: Option<PersistenceLoadTarget>,
) -> ApplicationBuilder {
    let spec = match fork_target {
        Some(target) => initialize_from_spec(true, map_from_pairs([("count", json!(0))]), "noop")
            .with_fork_target(target),
        None => initialize_from_spec(true, map_from_pairs([("count", json!(0))]), "noop"),
    };

    base_builder()
        .with_identifiers(uid, Some(partition_key.to_string()), Some(sequence_id))
        .expect("identifiers should configure")
        .initialize_from(sync_initializer_with(loaded), spec)
        .expect("initializer wrapper should configure")
}

async fn assert_initialize_from_default_entrypoint(mode: BuildMode) {
    let imported = alpha_omega_graph("omega");
    let app = match mode {
        BuildMode::Sync => base_builder()
            .with_graph(imported.clone())
            .expect("graph import should configure")
            .initialize_from(
                sync_initializer_with(None),
                initialize_from_spec(true, IndexMap::new(), "alpha"),
            )
            .expect("initializer wrapper should configure")
            .build()
            .expect("sync build should succeed"),
        BuildMode::Async => base_builder()
            .with_graph(imported.clone())
            .expect("graph import should configure")
            .initialize_from(
                async_initializer_with(None),
                initialize_from_spec(true, IndexMap::new(), "alpha"),
            )
            .expect("initializer wrapper should configure")
            .abuild()
            .await
            .expect("async build should succeed"),
    };
    assert_eq!(app.entrypoint(), "alpha");
    assert_eq!(app.graph().entrypoint(), "alpha");

    let reversed = match mode {
        BuildMode::Sync => base_builder()
            .initialize_from(
                sync_initializer_with(None),
                initialize_from_spec(true, IndexMap::new(), "alpha"),
            )
            .expect("initializer wrapper should configure")
            .with_graph(imported)
            .expect("graph import should configure")
            .build()
            .expect("sync build should succeed"),
        BuildMode::Async => base_builder()
            .initialize_from(
                async_initializer_with(None),
                initialize_from_spec(true, IndexMap::new(), "alpha"),
            )
            .expect("initializer wrapper should configure")
            .with_graph(imported)
            .expect("graph import should configure")
            .abuild()
            .await
            .expect("async build should succeed"),
    };
    assert_eq!(reversed.entrypoint(), "alpha");
    assert_eq!(reversed.graph().entrypoint(), "alpha");
}

async fn assert_tracker_hook_counts(
    mode: BuildMode,
    hooks: LifecycleAdapterSet,
    tracker: Arc<dyn Tracker>,
    expected_sync: usize,
    expected_async: usize,
) {
    let app = mode
        .build(
            noop_entry_builder()
                .with_hooks(hooks)
                .expect("hooks should configure")
                .with_tracker(TrackerSpec::provided(Arc::clone(&tracker)))
                .expect("tracker should configure"),
        )
        .await;
    assert_eq!(app.hooks().sync_adapters().len(), expected_sync);
    assert_eq!(app.hooks().async_adapters().len(), expected_async);
    assert!(Arc::ptr_eq(
        app.tracker().expect("tracker should be set"),
        &tracker
    ));
}

#[test]
fn provided_tracker_does_not_root_register_during_sync_build() {
    let storage_dir = test_dir().expect("temp dir should be available");
    let project = "provided_tracker_no_root_sync";
    let tracker = Arc::new(
        LocalTrackingClient::new(project, storage_dir.path())
            .expect("provided local tracker should initialize"),
    );
    let tracker_trait: Arc<dyn Tracker> = tracker;

    let app = noop_entry_builder()
        .with_identifiers("provided-no-root-sync", None, None)
        .expect("identifiers should configure")
        .with_tracker(TrackerSpec::provided(tracker_trait))
        .expect("provided tracker should configure")
        .build()
        .expect("provided tracker build should not require graph registration");

    assert!(
        !storage_dir
            .path()
            .join(project)
            .join(app.uid())
            .join(LocalTrackingClient::GRAPH_FILENAME)
            .exists(),
        "caller-provided trackers should not be root-registered automatically"
    );
}

#[tokio::test]
async fn provided_tracker_does_not_root_register_during_async_build() {
    let storage_dir = test_dir().expect("temp dir should be available");
    let project = "provided_tracker_no_root_async";
    let tracker = Arc::new(
        LocalTrackingClient::new(project, storage_dir.path())
            .expect("provided local tracker should initialize"),
    );
    let tracker_trait: Arc<dyn Tracker> = tracker;

    let app = noop_entry_builder()
        .with_identifiers("provided-no-root-async", None, None)
        .expect("identifiers should configure")
        .with_tracker(TrackerSpec::provided(tracker_trait))
        .expect("provided tracker should configure")
        .abuild()
        .await
        .expect("provided tracker build should not require graph registration");

    assert!(
        !storage_dir
            .path()
            .join(project)
            .join(app.uid())
            .join(LocalTrackingClient::GRAPH_FILENAME)
            .exists(),
        "caller-provided trackers should not be root-registered automatically"
    );
}

fn local_tracker_spec(tracker_name: &str, storage_dir: &std::path::Path) -> TrackerSpec {
    TrackerSpec::local(
        tracker_name,
        map_from_pairs([(
            "storage_dir",
            json!(storage_dir.to_string_lossy().to_string()),
        )]),
    )
}

fn read_tracking_log(storage_dir: &std::path::Path, tracker_name: &str, app_id: &str) -> String {
    let log_path = tracking_log_path(storage_dir, tracker_name, app_id);
    assert!(log_path.exists(), "log artifact should be written");
    std::fs::read_to_string(log_path).expect("tracking log file should be readable")
}

async fn assert_tracked_step_writes_log(
    mode: BuildMode,
    app_id: &str,
    tracker_name: &str,
    assert_log: impl FnOnce(&str),
) {
    let storage_dir = test_dir().expect("temp dir should be available");
    let mut app = mode
        .build(
            tracked_noop_entry_builder(mode)
                .with_identifiers(app_id, Some("pk".to_string()), None)
                .expect("identifiers should configure")
                .with_tracker(local_tracker_spec(tracker_name, storage_dir.path()))
                .expect("tracker should configure"),
        )
        .await;

    match mode {
        BuildMode::Sync => {
            let _ = app
                .step(None)
                .expect("step should succeed")
                .expect("step should execute");
        }
        BuildMode::Async => {
            let _ = app
                .astep(None)
                .await
                .expect("async step should succeed")
                .expect("async step should execute");
        }
    }

    let log_contents = read_tracking_log(storage_dir.path(), tracker_name, app_id);
    assert_log(&log_contents);
}

fn assert_tracking_log_contains_begin_and_end(log_contents: &str) {
    assert!(
        log_contents.contains("\"type\":\"begin_entry\""),
        "tracking log should include begin_entry records"
    );
    assert!(
        log_contents.contains("\"type\":\"end_entry\""),
        "tracking log should include end_entry records"
    );
}

fn assert_tracking_log_entry_counts(
    log_contents: &str,
    expected_begin: usize,
    expected_end: usize,
) {
    assert_eq!(
        log_entry_count(log_contents, "begin_entry"),
        expected_begin,
        "unexpected begin_entry count: {log_contents}"
    );
    assert_eq!(
        log_entry_count(log_contents, "end_entry"),
        expected_end,
        "unexpected end_entry count: {log_contents}"
    );
}

#[derive(Clone, Copy)]
enum SameAppForkOrder {
    IdentifiersFirst,
    InitializeFirst,
}

fn same_app_fork_target_error(order: SameAppForkOrder) -> ApplicationError {
    let builder = match order {
        SameAppForkOrder::IdentifiersFirst => base_builder()
            .with_identifiers("same-app", Some("tenant".to_string()), None)
            .expect("identifiers should configure")
            .initialize_from(
                sync_initializer_with(None),
                initialize_from_spec(true, IndexMap::new(), "noop").with_fork_target(
                    PersistenceLoadTarget::new("same-app", Some("tenant".to_string()), Some(6)),
                ),
            )
            .expect("initializer wrapper should configure"),
        SameAppForkOrder::InitializeFirst => base_builder()
            .initialize_from(
                sync_initializer_with(None),
                initialize_from_spec(true, IndexMap::new(), "noop").with_fork_target(
                    PersistenceLoadTarget::new("same-app", Some("tenant".to_string()), Some(6)),
                ),
            )
            .expect("initializer wrapper should configure")
            .with_identifiers("same-app", Some("tenant".to_string()), None)
            .expect("identifiers should configure"),
    };

    builder
        .build()
        .err()
        .expect("same-app fork target should be rejected")
}

fn assert_build_error(builder: ApplicationBuilder, assert_error: impl FnOnce(ApplicationError)) {
    let error = builder.build().err().expect("build should fail");
    assert_error(error);
}

fn assert_entrypoint_already_configured(error: ApplicationError) {
    assert!(matches!(
        error,
        ApplicationError::EntrypointAlreadyConfigured
    ));
}

fn assert_sync_build_used_async_initializer(error: ApplicationError) {
    assert!(matches!(
        error,
        ApplicationError::SyncBuildUsedAsyncInitializer
    ));
}

fn assert_sync_build_used_async_persister(error: ApplicationError) {
    assert!(matches!(
        error,
        ApplicationError::SyncBuildUsedAsyncPersister
    ));
}

fn assert_builder_call_error(
    result: Result<ApplicationBuilder, ApplicationError>,
    assert_error: impl FnOnce(ApplicationError),
) {
    let error = result.err().expect("builder call should fail");
    assert_error(error);
}

fn configured_empty_sync_initializer_builder() -> ApplicationBuilder {
    with_sync_initializer_spec(
        ApplicationBuilder::new(),
        sync_initializer_with(None),
        true,
        IndexMap::new(),
        "noop",
        None,
        None,
    )
    .expect("initializer spec should configure")
}

fn assert_initializer_spec_conflict(builder: ApplicationBuilder) {
    assert!(matches!(
        with_sync_initializer_spec(
            builder,
            sync_initializer_with(None),
            true,
            IndexMap::new(),
            "noop",
            None,
            None,
        ),
        Err(ApplicationError::PersistenceInitializerConflictsWithStateOrEntrypoint)
    ));
}

fn assert_override_state(builder: ApplicationBuilder) {
    let app = builder.build().expect("build should succeed");
    assert_eq!(
        app.state()
            .require("x")
            .expect("state should contain key 'x'"),
        &json!(100)
    );
    assert_eq!(
        app.state()
            .require("__SEQUENCE_ID")
            .expect("state should contain key '__SEQUENCE_ID'"),
        &json!(7)
    );
}

fn assert_resumed_state_validation_sync(builder: ApplicationBuilder) {
    let app = builder
        .build()
        .expect("build should succeed once the final resumed state is assembled");
    assert_eq!(app.state().get("restored"), Some(&json!(true)));
    assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(7)));
    assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("noop")));
}

async fn assert_resumed_state_validation_async(builder: ApplicationBuilder) {
    let app = builder
        .abuild()
        .await
        .expect("async build should succeed once the final resumed state is assembled");
    assert_eq!(app.state().get("restored"), Some(&json!(true)));
    assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(7)));
    assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("noop")));
}

fn assert_identifiers(
    builder: ApplicationBuilder,
    uid: &str,
    partition_key: Option<&str>,
    sequence_id: u64,
) {
    let app = builder.build().expect("build should succeed");
    assert_eq!(app.uid(), uid);
    assert_eq!(app.partition_key(), partition_key);
    assert_eq!(app.state().get("__SEQUENCE_ID"), Some(&json!(sequence_id)));
}

fn assert_initialize_from_resume(
    uid: &str,
    partition_key: &str,
    sequence_id: u64,
    loaded: Option<rurr_persistence::PersistedStateData>,
    fork_target: Option<PersistenceLoadTarget>,
    count: i64,
    parent_pointer: Option<(&str, Option<&str>, Option<u64>)>,
) {
    let app = initialize_from_count_builder(uid, partition_key, sequence_id, loaded, fork_target)
        .build()
        .expect("build should succeed");
    assert_resume_initialized_app(&app, uid, Some(partition_key), count, parent_pointer);
}

fn assert_initialize_from_miss(
    builder: ApplicationBuilder,
    assert_extra: impl FnOnce(&rurr_core::Application),
) {
    let app = builder.build().expect("build should succeed");
    assert_extra(&app);
    assert_fresh_initialize_miss(app);
}

async fn assert_abuild_error(
    builder: ApplicationBuilder,
    assert_error: impl FnOnce(ApplicationError),
) {
    let error = builder
        .abuild()
        .await
        .err()
        .expect("async build should fail");
    assert_error(error);
}

#[test]
fn application_builder_complete() {
    let app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![graph_action("counter"), graph_action("result")])
        .expect("actions should configure")
        .with_transitions(vec![
            Transition::new("counter", "counter", Condition::expr("count < 10")),
            Transition::new("counter", "result", Condition::default()),
        ])
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("application build should succeed");

    assert_eq!(app.graph().actions().len(), 2);
    assert_eq!(app.graph().transitions().len(), 2);
    assert_eq!(app.entrypoint(), "counter");
}

#[tokio::test]
async fn build_and_abuild_match_on_simple_graph_and_identifiers() {
    fn parity_builder() -> ApplicationBuilder {
        ApplicationBuilder::new()
            .with_state(state_from_pairs([("count", json!(3))]))
            .expect("state should configure")
            .with_actions(vec![graph_action("counter"), graph_action("result")])
            .expect("actions should configure")
            .with_transitions(vec![Transition::new(
                "counter",
                "result",
                Condition::default(),
            )])
            .expect("transitions should configure")
            .with_entrypoint("counter")
            .expect("entrypoint should configure")
            .with_identifiers("parity-app", Some("tenant-42".to_string()), Some(9))
            .expect("identifiers should configure")
            .with_spawning_parent("parent-app", Some("tenant-7".to_string()), 12)
            .expect("spawning parent should configure")
    }

    let sync_app = parity_builder().build().expect("sync build should succeed");
    let async_app = parity_builder()
        .abuild()
        .await
        .expect("async build should succeed");

    assert_eq!(sync_app.entrypoint(), "counter");
    assert_eq!(async_app.entrypoint(), "counter");
    assert_eq!(
        sync_app.graph().entrypoint(),
        async_app.graph().entrypoint()
    );
    assert_eq!(
        sync_app.graph().actions().len(),
        async_app.graph().actions().len()
    );
    assert_eq!(
        sync_app.graph().transitions().len(),
        async_app.graph().transitions().len()
    );
    assert_eq!(sync_app.uid(), "parity-app");
    assert_eq!(async_app.uid(), "parity-app");
    assert_eq!(sync_app.partition_key(), Some("tenant-42"));
    assert_eq!(async_app.partition_key(), Some("tenant-42"));
    assert_eq!(sync_app.parent_pointer(), None);
    assert_eq!(async_app.parent_pointer(), None);
    assert_eq!(
        sync_app.spawning_parent_pointer(),
        async_app.spawning_parent_pointer()
    );
    assert_eq!(sync_app.state().get("count"), Some(&json!(3)));
    assert_eq!(async_app.state().get("count"), Some(&json!(3)));
    assert_eq!(sync_app.state().get("__SEQUENCE_ID"), Some(&json!(9)));
    assert_eq!(async_app.state().get("__SEQUENCE_ID"), Some(&json!(9)));
}

#[test]
fn sync_initializer_spec_errors_when_loaded_record_contains_none_state() {
    let broken = persisted_state(None, Some("noop"), PersistedStateStatus::Completed);
    let error = with_sync_initializer_spec(
        base_builder(),
        sync_initializer_with(Some(broken)),
        true,
        map_from_pairs([("x", json!(0))]),
        "noop",
        None,
        None,
    )
    .expect("initializer spec should configure")
    .build()
    .err()
    .expect("build should fail when loaded state is None");

    assert!(matches!(
        error,
        ApplicationError::InitializerReturnedMissingState
    ));
}

#[test]
fn application_builder_unset_fails_build() {
    assert_build_error(ApplicationBuilder::new(), |error| {
        assert!(matches!(
            error,
            ApplicationError::Graph(GraphError::EmptyActions)
        ));
    });
}

#[test]
fn application_builder_assigns_actions_with_dual_api() {
    let app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_actions(vec![graph_action("counter")])
        .expect("graph action insertion should succeed")
        .with_actions(vec![("result".to_string(), unnamed_function_action())])
        .expect("named assignment action insertion should succeed")
        .with_transitions(Vec::<Transition>::new())
        .expect("empty transitions should be accepted")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("application build should succeed");

    let action_names: std::collections::BTreeSet<_> = app
        .graph()
        .actions()
        .iter()
        .map(|action| action.name().to_string())
        .collect();
    assert_eq!(
        action_names,
        std::collections::BTreeSet::from(["counter".to_string(), "result".to_string(),])
    );
}

#[test]
fn graph_imports_preserve_default_and_explicit_entrypoints() {
    let imported = alpha_omega_graph("omega");

    let app = ApplicationBuilder::new()
        .with_graph(imported.clone())
        .expect("graph import should configure")
        .build()
        .expect("build should succeed");

    assert_eq!(app.graph().actions().len(), imported.actions().len());
    assert_eq!(
        app.graph().transitions().len(),
        imported.transitions().len()
    );
    assert_eq!(app.entrypoint(), imported.entrypoint());
    let first = graph_with(
        vec![graph_action("left-start"), graph_action("left-finish")],
        vec![Transition::new(
            "left-start",
            "left-finish",
            Condition::default(),
        )],
        "left-finish",
    );
    let second = graph_with(
        vec![graph_action("right-start"), graph_action("right-finish")],
        vec![Transition::new(
            "right-start",
            "right-finish",
            Condition::default(),
        )],
        "right-start",
    );

    for (builder, expected_entrypoint) in [
        (
            ApplicationBuilder::new()
                .with_graphs(vec![first.clone(), second.clone()])
                .expect("graph imports should configure"),
            first.entrypoint().to_string(),
        ),
        (
            ApplicationBuilder::new()
                .with_graphs(vec![first, second])
                .expect("graph imports should configure")
                .with_entrypoint("right-start")
                .expect("explicit entrypoint should override imported graph entrypoint"),
            "right-start".to_string(),
        ),
    ] {
        let app = builder.build().expect("build should succeed");
        assert_eq!(app.entrypoint(), expected_entrypoint);
        assert_eq!(app.graph().actions().len(), 4);
        assert_eq!(app.graph().transitions().len(), 2);
    }
}

#[tokio::test]
async fn with_graph_and_initialize_from_use_initializer_default_entrypoint_when_no_state_is_loaded()
{
    assert_initialize_from_default_entrypoint(BuildMode::Sync).await;
    assert_initialize_from_default_entrypoint(BuildMode::Async).await;
}

#[test]
fn initializer_spec_cannot_be_called_after_state_or_entrypoint_is_set() {
    for builder in [
        ApplicationBuilder::new()
            .with_state(State::default())
            .expect("state should configure"),
        ApplicationBuilder::new()
            .with_entrypoint("noop")
            .expect("entrypoint should configure"),
    ] {
        assert_initializer_spec_conflict(builder);
    }
}

#[test]
fn with_state_and_with_entrypoint_are_rejected_after_initializer_spec() {
    assert_builder_call_error(
        configured_empty_sync_initializer_builder().with_state(State::default()),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::WithStateAfterPersistenceInitializer
            ))
        },
    );
    assert_builder_call_error(
        configured_empty_sync_initializer_builder().with_entrypoint("counter"),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::WithEntrypointAfterPersistenceInitializer
            ))
        },
    );
}

#[test]
fn entrypoint_and_sync_build_mode_rejections() {
    for result in [
        ApplicationBuilder::new()
            .with_entrypoint("first")
            .expect("first entrypoint should configure")
            .with_entrypoint("second"),
        ApplicationBuilder::new()
            .with_entrypoint("noop")
            .expect("first entrypoint should configure")
            .with_entrypoint("noop"),
    ] {
        assert_builder_call_error(result, assert_entrypoint_already_configured);
    }

    assert_build_error(
        with_async_initializer_spec(
            base_builder(),
            async_initializer_with(None),
            true,
            IndexMap::new(),
            "noop",
            None,
            None,
        )
        .expect("async initializer spec should configure"),
        assert_sync_build_used_async_initializer,
    );
    for (builder, assert_error) in [
        (
            base_builder()
                .initialize_from(
                    async_initializer_with(None),
                    initialize_from_spec(true, IndexMap::new(), "noop"),
                )
                .expect("async initializer wrapper should configure"),
            assert_sync_build_used_async_initializer as fn(ApplicationError),
        ),
        (
            with_async_persister_spec(noop_entry_builder(), async_persister())
                .expect("async persister spec should configure"),
            assert_sync_build_used_async_persister,
        ),
        (
            {
                let persister = Arc::new(FixedAsyncPersister);
                with_async_persister_spec(noop_entry_builder(), persister.clone())
                    .expect("concrete async persister spec should configure")
            },
            assert_sync_build_used_async_persister,
        ),
        (
            {
                let initializer = Arc::new(FixedAsyncInitializer { result: None });
                with_async_initializer_spec(
                    base_builder(),
                    initializer.clone(),
                    true,
                    IndexMap::new(),
                    "noop",
                    None,
                    None,
                )
                .expect("concrete async initializer spec should configure")
            },
            assert_sync_build_used_async_initializer,
        ),
    ] {
        assert_build_error(builder, assert_error);
    }
}

#[tokio::test]
async fn async_build_mode_rejections() {
    assert_abuild_error(
        base_builder()
            .initialize_from(
                sync_initializer_with(None),
                initialize_from_spec(true, IndexMap::new(), "noop"),
            )
            .expect("sync initializer wrapper should configure"),
        |error| {
            assert!(matches!(
                error,
                ApplicationError::AsyncBuildUsedSyncInitializer
            ))
        },
    )
    .await;
}

#[test]
fn with_persistence_spec_accepts_sync_loader_and_persister_variants() {
    let persister = sync_persister();
    let app = build_sync_persister_app(persister.clone());
    assert_sync_persister_ptr(&app, &persister);

    let concrete_persister = Arc::new(FixedSyncPersister);
    let expected: Arc<dyn BaseStatePersister> = concrete_persister.clone();
    let concrete_app = build_sync_persister_app(expected.clone());
    assert_sync_persister_ptr(&concrete_app, &expected);

    let initializer = sync_initializer_with(Some(completed_noop_state(map_from_pairs([(
        "x",
        json!(5),
    )]))));
    let app = base_builder()
        .with_identifiers("target-app", Some("tenant-2".to_string()), None)
        .expect("identifiers should configure")
        .with_persistence_spec(
            ApplicationPersistenceSpec::new()
                .with_initializer(
                    StateInitializerSpec::sync(
                        initializer.clone(),
                        true,
                        map_from_pairs([("x", json!(0))]),
                        "noop",
                        None,
                    )
                    .with_load_target(PersistenceLoadTarget::new(
                        "source-app",
                        Some("tenant-1".to_string()),
                        Some(7),
                    )),
                )
                .with_persister(StatePersisterSpec::sync(persister.clone())),
        )
        .expect("persistence spec should configure")
        .build()
        .expect("build should succeed");
    let expected_initializer: Arc<dyn BaseStateLoader> = initializer;
    assert_sync_initializer_ptr(&app, &expected_initializer);
    assert_sync_persister_ptr(&app, &persister);
    assert_eq!(app.uid(), "target-app");
    assert_eq!(app.partition_key(), Some("tenant-2"));
    assert_eq!(
        app.parent_pointer(),
        Some(&rurr_core::application::ParentPointer {
            app_id: "source-app".to_string(),
            partition_key: Some("tenant-1".to_string()),
            sequence_id: Some(7),
        })
    );
    assert_eq!(app.state().get("x"), Some(&json!(5)));

    for (initializer, default_state, expected_x) in [
        (
            {
                let initializer = Arc::new(FixedSyncInitializer {
                    result: Some(completed_noop_state(map_from_pairs([("x", json!(1))]))),
                });
                let expected: Arc<dyn BaseStateLoader> = initializer;
                expected
            },
            map_from_pairs([("x", json!(0))]),
            json!(1),
        ),
        (
            sync_persister(),
            map_from_pairs([("x", json!(9))]),
            json!(9),
        ),
    ] {
        let app = build_sync_initializer_app(initializer.clone(), default_state);
        assert_sync_initializer_ptr(&app, &initializer);
        assert_eq!(
            app.state()
                .require("x")
                .expect("state should contain key 'x'"),
            &expected_x
        );
    }
}

#[test]
fn initialize_from_resume_override_and_miss_matrix() {
    assert_initialize_from_resume(
        "resume-app",
        "tenant-1",
        3,
        Some(completed_count_state(5)),
        None,
        5,
        None,
    );
    assert_initialize_from_resume(
        "fork-app",
        "tenant-target",
        100,
        Some(completed_count_state(8)),
        Some(PersistenceLoadTarget::new(
            "source-app",
            Some("tenant-source".to_string()),
            Some(6),
        )),
        8,
        Some(("source-app", Some("tenant-source"), Some(6))),
    );

    assert_override_state({
        let loaded = completed_noop_state(map_from_pairs([("x", json!(1))]));
        base_builder()
            .initialize_from(
                sync_initializer_with(Some(loaded)),
                initialize_from_spec(false, map_from_pairs([("x", json!(0))]), "noop")
                    .with_override_state_values(map_from_pairs([("x", json!(100))])),
            )
            .expect("initializer wrapper should configure")
    });

    assert_initialize_from_miss(
        initialize_from_count_builder("resume-app", "tenant-1", 41, None, None),
        |_| {},
    );
    assert_initialize_from_miss(
        initialize_from_count_builder(
            "target-app",
            "tenant-target",
            41,
            None,
            Some(PersistenceLoadTarget::new(
                "missing-source",
                Some("tenant-source".to_string()),
                Some(7),
            )),
        ),
        |app| assert_eq!(app.parent_pointer(), None),
    );

    let ordered_error = same_app_fork_target_error(SameAppForkOrder::IdentifiersFirst);
    assert!(matches!(
        ordered_error,
        ApplicationError::PersistenceLoadTargetMatchesTargetAppId
    ));
    let reversed_error = same_app_fork_target_error(SameAppForkOrder::InitializeFirst);
    assert!(matches!(
        reversed_error,
        ApplicationError::PersistenceLoadTargetMatchesTargetAppId
    ));
}

#[test]
fn initialize_from_without_resume_at_next_action_clears_prior_step_and_uses_default_entrypoint() {
    let entry = graph_action("entry");
    let other = graph_action("other");
    let loaded = persisted_state(
        Some(map_from_pairs([
            ("count", json!(1)),
            ("__PRIOR_STEP", json!("other")),
        ])),
        Some("other"),
        PersistedStateStatus::Completed,
    );

    let mut app = ApplicationBuilder::new()
        .with_actions(vec![entry.clone(), other])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "entry",
            "other",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .initialize_from(
            sync_initializer_with(Some(loaded)),
            initialize_from_spec(false, map_from_pairs([("count", json!(0))]), "entry"),
        )
        .expect("initializer wrapper should configure")
        .build()
        .expect("build should succeed");

    assert_eq!(app.entrypoint(), "entry");
    assert_eq!(app.state().get("__PRIOR_STEP"), None);

    let step = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");
    assert_eq!(step.action.name(), "entry");
}

#[test]
fn initializer_spec_applies_override_state_values() {
    let loaded = completed_noop_state(map_from_pairs([("x", json!(1))]));
    assert_override_state(
        with_sync_initializer_spec(
            base_builder(),
            sync_initializer_with(Some(loaded)),
            false,
            map_from_pairs([("x", json!(0))]),
            "noop",
            Some(map_from_pairs([("x", json!(100))])),
            None,
        )
        .expect("initializer spec should configure"),
    );
}

#[test]
fn initializer_spec_deserializes_registered_tagged_serde_payloads() {
    let _guard = registry_test_guard();
    let dispatch_key = unique_registry_name("builder_dispatch_key");
    register_serde_deserializer(dispatch_key.clone(), |value| {
        Value::String(
            value
                .get("value")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .replace("serialized::", ""),
        )
    })
    .expect("dispatch registration should succeed");

    let loaded = completed_noop_state(map_from_pairs([(
        "payload",
        json!({KEY: dispatch_key, "value": "serialized::decoded"}),
    )]));
    let app = with_sync_initializer_spec(
        base_builder(),
        sync_initializer_with(Some(loaded)),
        false,
        IndexMap::new(),
        "noop",
        None,
        None,
    )
    .expect("initializer spec should configure")
    .build()
    .expect("build should succeed");

    assert_eq!(
        app.state()
            .require("payload")
            .expect("state should contain the deserialized payload"),
        &json!("decoded")
    );
}

#[tokio::test]
async fn initializer_spec_validates_resume_state_after_overrides_and_runtime_metadata() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(ResumeStateTypingSystem);
    let loaded = empty_completed_noop_state();

    assert_resumed_state_validation_sync(
        with_sync_initializer_spec(
            base_builder()
                .with_typing(Arc::clone(&typing_system))
                .expect("typing system should configure"),
            sync_initializer_with(Some(loaded.clone())),
            true,
            IndexMap::new(),
            "noop",
            Some(map_from_pairs([("restored", json!(true))])),
            None,
        )
        .expect("initializer spec should configure"),
    );

    assert_resumed_state_validation_async(
        with_async_initializer_spec(
            base_builder()
                .with_typing(typing_system)
                .expect("typing system should configure"),
            async_initializer_with(Some(loaded)),
            true,
            IndexMap::new(),
            "noop",
            Some(map_from_pairs([("restored", json!(true))])),
            None,
        )
        .expect("async initializer spec should configure"),
    )
    .await;
}

#[test]
fn initializer_spec_still_rejects_invalid_final_resumed_state() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(ResumeStateTypingSystem);
    let loaded = empty_completed_noop_state();

    let error = with_sync_initializer_spec(
        base_builder()
            .with_typing(typing_system)
            .expect("typing system should configure"),
        sync_initializer_with(Some(loaded)),
        true,
        IndexMap::new(),
        "noop",
        None,
        None,
    )
    .expect("initializer spec should configure")
    .build()
    .err()
    .expect("build should still validate the final resumed state");

    match error {
        ApplicationError::State(StateError::TypingSystem { phase, message }) => {
            assert_eq!(phase, "validate_state");
            assert!(message.contains("restored"));
        }
        other => panic!("expected final state typing error, got {other:?}"),
    }
}

#[test]
fn initializer_spec_rejects_roundtrip_only_invalid_final_resumed_state() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(ResumeRoundTripTypingSystem);
    let loaded = empty_completed_noop_state();

    let error = with_sync_initializer_spec(
        base_builder()
            .with_typing(typing_system)
            .expect("typing system should configure"),
        sync_initializer_with(Some(loaded)),
        true,
        IndexMap::new(),
        "noop",
        None,
        None,
    )
    .expect("initializer spec should configure")
    .build()
    .err()
    .expect("build should still validate the final resumed state");

    match error {
        ApplicationError::State(StateError::TypingSystem { phase, message }) => {
            assert_eq!(phase, "construct_data");
            assert!(message.contains("restored"));
        }
        other => panic!("expected roundtrip typing error, got {other:?}"),
    }
}

#[tokio::test]
async fn async_initializer_spec_rejects_roundtrip_only_construct_state_failures() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(ResumeRoundTripTypingSystem);
    let loaded = empty_completed_noop_state();

    let error = with_async_initializer_spec(
        base_builder()
            .with_typing(typing_system)
            .expect("typing system should configure"),
        async_initializer_with(Some(loaded)),
        true,
        IndexMap::new(),
        "noop",
        Some(map_from_pairs([
            ("restored", json!(true)),
            ("fail_construct_state", json!(true)),
        ])),
        None,
    )
    .expect("async initializer spec should configure")
    .abuild()
    .await
    .err()
    .expect("async build should validate construct_state failures");

    match error {
        ApplicationError::State(StateError::TypingSystem { phase, message }) => {
            assert_eq!(phase, "construct_state");
            assert!(message.contains("rebuilding raw state"));
        }
        other => panic!("expected construct_state typing error, got {other:?}"),
    }
}

#[test]
fn initializer_spec_does_not_overwrite_explicit_state_persister() {
    let persister = sync_persister();
    let initializer = sync_initializer_with(None);

    let app = with_sync_initializer_spec(
        with_sync_persister_spec(base_builder(), persister.clone())
            .expect("state persister should configure"),
        initializer.clone(),
        false,
        map_from_pairs([("x", json!(0))]),
        "noop",
        None,
        None,
    )
    .expect("initializer spec should configure")
    .build()
    .expect("build should succeed");

    let expected_initializer: Arc<dyn BaseStateLoader> = initializer;
    assert_sync_persister_ptr(&app, &persister);
    assert_sync_initializer_ptr(&app, &expected_initializer);
}

#[test]
fn build_preserves_explicit_state_resources_when_builder_overrides_are_unset() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(PassthroughTypingSystem);
    let explicit_state = State::new(map_from_pairs([("count", json!(0))]))
        .with_typing_system(Arc::clone(&typing_system))
        .expect("typing system should attach");

    let app = noop_entry_builder()
        .with_state(explicit_state)
        .expect("state should configure")
        .build()
        .expect("build should succeed");

    assert!(Arc::ptr_eq(app.state().typing_system(), &typing_system));
}

#[test]
fn build_stamps_configured_typing_system_onto_state() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(PassthroughTypingSystem);

    let app = noop_entry_builder()
        .with_state(state_from_pairs([("count", json!(0))]))
        .expect("state should configure")
        .with_typing(Arc::clone(&typing_system))
        .expect("typing system should configure")
        .build()
        .expect("build should succeed");

    assert!(Arc::ptr_eq(app.state().typing_system(), &typing_system));
}

#[tokio::test]
async fn tracker_hook_wiring_and_canonicalization_matrix() {
    assert_tracker_hook_counts(
        BuildMode::Sync,
        LifecycleAdapterSet::default(),
        Arc::new(NoopTracker),
        1,
        0,
    )
    .await;
    assert_tracker_hook_counts(
        BuildMode::Async,
        LifecycleAdapterSet::default(),
        Arc::new(NoopTracker),
        0,
        1,
    )
    .await;

    let tracker = Arc::new(NoopTracker);
    let tracker_sync: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let tracker_async: Arc<dyn AsyncLifecycleAdapter> = tracker.clone();

    assert_tracker_hook_counts(
        BuildMode::Sync,
        LifecycleAdapterSet::new(vec![tracker_sync.clone()], vec![tracker_async.clone()]),
        tracker.clone(),
        1,
        0,
    )
    .await;
    assert_tracker_hook_counts(
        BuildMode::Async,
        LifecycleAdapterSet::new(vec![tracker_sync], vec![tracker_async]),
        tracker,
        0,
        1,
    )
    .await;
}

#[test]
fn with_tracker_auto_wires_tracking_without_manual_hooks() {
    futures::executor::block_on(assert_tracked_step_writes_log(
        BuildMode::Sync,
        "tracked-app",
        "builder_tracker_autowire",
        assert_tracking_log_contains_begin_and_end,
    ));
}

#[tokio::test]
async fn with_tracker_emits_expected_tracking_log_entries() {
    assert_tracked_step_writes_log(
        BuildMode::Async,
        "tracked-async-app",
        "builder_tracker_async_cardinality",
        |log_contents| assert_tracking_log_entry_counts(log_contents, 1, 1),
    )
    .await;
}

#[test]
fn with_parallel_executor_rejects_duplicate_configuration_and_preserves_configured_executor() {
    let executor: Arc<dyn ParallelExecutor> = Arc::new(NoopParallelExecutor);
    let duplicate_error = base_builder()
        .with_parallel_executor(Arc::clone(&executor))
        .expect("first executor should configure")
        .with_parallel_executor(Arc::new(NoopParallelExecutor))
        .err()
        .expect("second executor should be rejected");
    assert!(matches!(
        duplicate_error,
        ApplicationError::ParallelExecutorAlreadyConfigured
    ));

    let app = noop_entry_builder()
        .with_parallel_executor(Arc::clone(&executor))
        .expect("executor should configure")
        .build()
        .expect("build should succeed");
    assert!(Arc::ptr_eq(
        app.parallel_executor()
            .expect("parallel executor should be retained"),
        &executor
    ));
}

#[test]
fn with_spawning_parent_sets_spawning_parent_pointer_on_application() {
    let app = noop_entry_builder()
        .with_spawning_parent("parent-app", Some("tenant-9".to_string()), 12)
        .expect("spawning parent should configure")
        .build()
        .expect("build should succeed");

    assert_eq!(
        app.spawning_parent_pointer(),
        Some(&rurr_core::application::ParentPointer {
            app_id: "parent-app".to_string(),
            partition_key: Some("tenant-9".to_string()),
            sequence_id: Some(12),
        })
    );
}

#[test]
fn with_identifiers_updates_only_requested_fields() {
    for (builder, uid, partition_key, sequence_id) in [
        (
            noop_entry_builder()
                .with_identifiers("app-123", Some("tenant-7".to_string()), Some(9))
                .expect("identifiers should configure"),
            "app-123",
            Some("tenant-7"),
            9,
        ),
        (
            noop_entry_builder()
                .with_state(state_from_pairs([
                    ("count", json!(0)),
                    ("__SEQUENCE_ID", json!(2)),
                ]))
                .expect("state should configure")
                .with_identifiers("app-123", Some("tenant-7".to_string()), Some(9))
                .expect("identifiers should configure"),
            "app-123",
            Some("tenant-7"),
            9,
        ),
        (
            noop_entry_builder()
                .with_identifiers("app-123", Some("tenant-7".to_string()), Some(9))
                .expect("initial identifiers should configure")
                .with_identifiers("app-456", None, None)
                .expect("app-id-only update should configure"),
            "app-456",
            Some("tenant-7"),
            9,
        ),
        (
            noop_entry_builder()
                .with_identifiers("app-123", Some("tenant-7".to_string()), Some(9))
                .expect("initial identifiers should configure")
                .with_identifiers("app-123", Some("tenant-8".to_string()), None)
                .expect("partition-key update should configure"),
            "app-123",
            Some("tenant-8"),
            9,
        ),
        (
            noop_entry_builder()
                .with_identifiers("app-123", Some("tenant-7".to_string()), Some(9))
                .expect("initial identifiers should configure")
                .with_identifiers("app-123", None, Some(11))
                .expect("sequence-id update should configure"),
            "app-123",
            Some("tenant-7"),
            11,
        ),
    ] {
        assert_identifiers(builder, uid, partition_key, sequence_id);
    }
}

#[test]
fn build_generates_distinct_uuid_app_ids_when_identifiers_unset() {
    let app1 = noop_entry_builder()
        .build()
        .expect("first build should succeed");
    let app2 = noop_entry_builder()
        .build()
        .expect("second build should succeed");

    assert_ne!(app1.uid(), app2.uid());
    assert_uuid_like(app1.uid());
    assert_uuid_like(app2.uid());
}

#[test]
fn failed_initializer_without_position_behavior_depends_on_resume_mode() {
    let error = failed_initializer_without_position_builder(true)
        .build()
        .err()
        .expect("build should fail when failed status omits position");
    assert!(matches!(
        error,
        ApplicationError::InitializerReturnedFailedStateWithoutPosition
    ));

    let app = failed_initializer_without_position_builder(false)
        .build()
        .expect("build should succeed without resume when failed status omits position");

    assert_eq!(app.entrypoint(), "noop");
    assert_eq!(
        app.state()
            .require("x")
            .expect("state should contain key 'x'"),
        &json!(1)
    );
    assert_eq!(
        app.state()
            .require("__SEQUENCE_ID")
            .expect("state should contain key '__SEQUENCE_ID'"),
        &json!(7)
    );
}
