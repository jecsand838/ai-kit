use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_core::action::ActionTracer;
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, LifecycleAdapterSet, LifecycleError, SpanContext, SyncLifecycleAdapter,
};
use serde_json::Value;
use std::sync::{Arc, Mutex};

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct RecordedSpanEvent {
    phase: &'static str,
    span_name: String,
    span_id: String,
    app_id: Option<String>,
}

impl RecordedSpanEvent {
    pub(crate) fn phase(&self) -> &'static str {
        self.phase
    }

    pub(crate) fn span_name(&self) -> &str {
        &self.span_name
    }

    pub(crate) fn span_id(&self) -> &str {
        &self.span_id
    }

    pub(crate) fn app_id(&self) -> Option<&str> {
        self.app_id.as_deref()
    }
}

#[derive(Debug, Default)]
pub(crate) struct RecordingHooks {
    events: Mutex<Vec<RecordedSpanEvent>>,
    attributes: Mutex<Vec<(String, IndexMap<String, Value>)>>,
}

impl RecordingHooks {
    pub(crate) fn events(&self) -> Vec<RecordedSpanEvent> {
        self.events.lock().unwrap().clone()
    }

    pub(crate) fn attributes(&self) -> Vec<(String, IndexMap<String, Value>)> {
        self.attributes.lock().unwrap().clone()
    }

    fn record_event(&self, phase: &'static str, context: &SpanContext) {
        self.events.lock().unwrap().push(RecordedSpanEvent {
            phase,
            span_name: context.span_name().unwrap_or("").to_string(),
            span_id: context.span_id().to_string(),
            app_id: context.app_id().map(str::to_string),
        });
    }

    fn record_attributes(&self, context: &SpanContext, attributes: &IndexMap<String, Value>) {
        self.attributes
            .lock()
            .unwrap()
            .push((context.span_id().to_string(), attributes.clone()));
    }
}

impl SyncLifecycleAdapter for RecordingHooks {
    fn pre_start_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.record_event("sync:start", context);
        Ok(())
    }

    fn post_end_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.record_event("sync:end", context);
        Ok(())
    }

    fn log_attributes(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        self.record_attributes(context, attributes);
        Ok(())
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for RecordingHooks {
    async fn pre_start_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.record_event("async:start", context);
        Ok(())
    }

    async fn post_end_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.record_event("async:end", context);
        Ok(())
    }

    async fn log_attributes(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        self.record_attributes(context, attributes);
        Ok(())
    }
}

#[derive(Debug)]
pub(crate) struct FailOnceHook {
    fail_next: Mutex<bool>,
}

impl Default for FailOnceHook {
    fn default() -> Self {
        Self {
            fail_next: Mutex::new(true),
        }
    }
}

impl FailOnceHook {
    fn maybe_fail(&self, phase: &'static str, message: &'static str) -> Result<(), LifecycleError> {
        let mut fail_next = self.fail_next.lock().unwrap();
        if *fail_next {
            *fail_next = false;
            return Err(LifecycleError::hook_failed(phase, message));
        }
        Ok(())
    }
}

impl SyncLifecycleAdapter for FailOnceHook {
    fn pre_start_span(&self, _context: &SpanContext) -> Result<(), LifecycleError> {
        self.maybe_fail("pre_start_span", "intentional sync failure")
    }
}

#[async_trait]
impl AsyncLifecycleAdapter for FailOnceHook {
    async fn pre_start_span(&self, _context: &SpanContext) -> Result<(), LifecycleError> {
        self.maybe_fail("pre_start_span_async", "intentional async failure")
    }
}

pub(crate) fn tracer_with_recording_hooks(
    sequence_id: u64,
    recorder: Arc<RecordingHooks>,
) -> ActionTracer {
    let sync_recorder: Arc<dyn SyncLifecycleAdapter> = recorder.clone();
    let async_recorder: Arc<dyn AsyncLifecycleAdapter> = recorder;
    ActionTracer::new(
        "test_action",
        sequence_id,
        LifecycleAdapterSet::new(vec![sync_recorder], vec![async_recorder]),
        "test-app",
        Some("pk".to_string()),
    )
}
