use std::io;
use std::path::Path;

pub(super) fn child_directory_missing_error(
    scope_name: &'static str,
    kind: &str,
    raw: &str,
) -> io::Error {
    io::Error::new(
        io::ErrorKind::NotFound,
        format!("{kind} '{raw}' does not exist within the configured {scope_name}"),
    )
}

pub(super) fn child_already_exists_error(
    scope_name: &'static str,
    kind: &str,
    raw: &str,
) -> io::Error {
    io::Error::new(
        io::ErrorKind::AlreadyExists,
        format!("{kind} '{raw}' already exists within the configured {scope_name}"),
    )
}

pub(super) fn child_alias_error(scope_name: &'static str, kind: &str, raw: &str) -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidInput,
        format!(
            "{kind} '{raw}' does not resolve to the exact requested direct child within the configured {scope_name}"
        ),
    )
}

pub(super) fn child_non_file_error(scope_name: &'static str, kind: &str, raw: &str) -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidInput,
        format!("{kind} '{raw}' does not resolve to a file within the configured {scope_name}"),
    )
}

pub(super) fn child_non_directory_error(
    scope_name: &'static str,
    kind: &str,
    raw: &str,
) -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidInput,
        format!(
            "{kind} '{raw}' does not resolve to a directory within the configured {scope_name}"
        ),
    )
}

pub(super) fn child_open_error(
    canonical_dir: &Path,
    kind: &str,
    raw: &str,
    error: impl std::fmt::Display,
) -> io::Error {
    io::Error::other(format!(
        "open {kind} '{}' at '{}': {error}",
        raw,
        canonical_dir.join(raw).display()
    ))
}

pub(super) fn anchored_dir_listing_alias_error(canonical_dir: &Path, raw: &Path) -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidInput,
        format!(
            "anchored directory '{}' contains aliased child '{}'",
            canonical_dir.display(),
            raw.display()
        ),
    )
}

pub(super) fn anchored_dir_open_error(path: &Path, error: impl std::fmt::Display) -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidInput,
        format!("open anchored directory '{}': {error}", path.display()),
    )
}

pub(super) fn anchored_dir_invalid_error(path: &Path) -> io::Error {
    io::Error::new(
        io::ErrorKind::InvalidInput,
        format!(
            "anchored directory '{}' no longer resolves to the originally validated directory",
            path.display()
        ),
    )
}
