use rurr_telemetry::{force_flush, shutdown};
use rurr_testkit::live_services::{
    raw_otel_log_records, raw_otel_trace_spans, read_otel_log_exports, read_otel_trace_exports,
};
use serde_json::Value;
use std::time::Duration;

pub(crate) const CLI_EVENT: &str = "os_burr_cli_command";

pub(crate) fn inherited_docker_config() -> Option<String> {
    std::env::var("DOCKER_CONFIG").ok().or_else(|| {
        std::env::var("HOME")
            .ok()
            .map(|home| format!("{home}/.docker"))
    })
}

pub(crate) fn is_telemetry_span(span: &Value) -> bool {
    span.get("name").and_then(Value::as_str) == Some(CLI_EVENT)
}

pub(crate) fn is_telemetry_log(record: &Value) -> bool {
    record.get("eventName").and_then(Value::as_str) == Some(CLI_EVENT)
}

pub(crate) async fn assert_no_cli_telemetry_exports(reason: &str) {
    force_flush();
    shutdown();
    tokio::time::sleep(Duration::from_millis(500)).await;

    let spans =
        raw_otel_trace_spans(&read_otel_trace_exports().expect("trace exports should be readable"))
            .expect("trace exports should project");
    let logs =
        raw_otel_log_records(&read_otel_log_exports().expect("log exports should be readable"))
            .expect("log exports should project");

    assert!(
        !spans.iter().any(|export| is_telemetry_span(&export.span)),
        "{reason}: expected no Rurr telemetry spans in raw collector output: {spans:?}"
    );
    assert!(
        !logs.iter().any(|export| is_telemetry_log(&export.record)),
        "{reason}: expected no Rurr telemetry logs in raw collector output: {logs:?}"
    );
}
