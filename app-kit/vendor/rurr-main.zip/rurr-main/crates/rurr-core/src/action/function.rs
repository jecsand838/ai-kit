use crate::action::api::is_reserved_runtime_input;
use crate::action::api::{
    boxed_local_async_stream, ActionContext, ActionError, ActionInputs, ActionKind, ActionResult,
    LocalAction, LocalAsyncStreamOutput, RurrError, StreamOutput,
};
use crate::action::macro_support;
use crate::state::State;
use futures::future::LocalBoxFuture;
use futures::{Stream, StreamExt};
use indexmap::{IndexMap, IndexSet};
use serde_json::Value;
use std::fmt;
use std::future::Future;
use std::sync::Arc;

type FunctionOutput = IndexMap<String, Value>;
type SyncActionResultHandler =
    dyn Fn(&State, &ActionContext) -> Result<ActionResult, ActionError> + Send + Sync;
type AsyncActionResultHandler = dyn Fn(State, ActionContext) -> LocalBoxFuture<'static, Result<ActionResult, ActionError>>
    + Send
    + Sync;
type SyncStreamingFunctionHandler =
    dyn Fn(State, ActionContext) -> Box<dyn Iterator<Item = StreamOutput>> + Send + Sync;
type SyncStreamOutput = Box<dyn Iterator<Item = StreamOutput>>;
type AsyncStreamingFunctionHandler =
    dyn Fn(State, ActionContext) -> LocalAsyncStreamOutput + Send + Sync;

#[derive(Clone, Debug)]
struct PreparedInputSpec {
    base_inputs: ActionInputs,
    bound_input_keys: IndexSet<String>,
    required_input_keys: IndexSet<String>,
}

impl PreparedInputSpec {
    fn from_builder(builder: &FunctionActionBuilder) -> Self {
        let mut base_inputs = builder.defaults.clone();
        for (key, value) in &builder.bound_inputs {
            base_inputs.insert(key.clone(), value.clone());
        }

        Self {
            base_inputs,
            bound_input_keys: builder.bound_inputs.keys().cloned().collect(),
            required_input_keys: builder.inputs.iter().cloned().collect(),
        }
    }

    fn resolve_inputs(&self, runtime_inputs: &ActionInputs) -> Result<ActionInputs, ActionError> {
        let mut resolved = self.base_inputs.clone();

        for (key, value) in runtime_inputs {
            if self.bound_input_keys.contains(key.as_str()) {
                return Err(ActionError::BoundInputOverride { key: key.clone() });
            }
            resolved.insert(key.clone(), value.clone());
        }

        if let Some(key) = self
            .required_input_keys
            .iter()
            .find(|key| !resolved.contains_key(key.as_str()))
        {
            return Err(ActionError::MissingInput { key: key.clone() });
        }

        Ok(resolved)
    }

    fn resolve_context(&self, ctx: &ActionContext) -> Result<ActionContext, ActionError> {
        Ok(ctx.clone_with_inputs(self.resolve_inputs(&ctx.inputs)?))
    }
}

#[derive(Clone)]
enum TerminalBehavior {
    Absent,
    Sync(Arc<SyncActionResultHandler>),
    Async(Arc<AsyncActionResultHandler>),
    Dual {
        sync: Arc<SyncActionResultHandler>,
        async_handler: Arc<AsyncActionResultHandler>,
        preferred: ActionKind,
    },
}

#[derive(Clone)]
enum StreamBehavior {
    Absent,
    Sync(Arc<SyncStreamingFunctionHandler>),
    Async(Arc<AsyncStreamingFunctionHandler>),
    Dual {
        sync: Arc<SyncStreamingFunctionHandler>,
        async_handler: Arc<AsyncStreamingFunctionHandler>,
        preferred: ActionKind,
    },
}

#[derive(Clone)]
struct FunctionBehavior {
    terminal: TerminalBehavior,
    stream: StreamBehavior,
}

impl FunctionBehavior {
    fn terminal(terminal: TerminalBehavior) -> Self {
        Self {
            terminal,
            stream: StreamBehavior::Absent,
        }
    }

    fn stream(stream: StreamBehavior) -> Self {
        Self {
            terminal: TerminalBehavior::Absent,
            stream,
        }
    }

    fn terminal_with_streams(terminal: TerminalBehavior, stream: StreamBehavior) -> Self {
        Self { terminal, stream }
    }

    fn kind(&self) -> ActionKind {
        match &self.terminal {
            TerminalBehavior::Sync(_) => ActionKind::Sync,
            TerminalBehavior::Async(_) => ActionKind::Async,
            TerminalBehavior::Dual { preferred, .. } => *preferred,
            TerminalBehavior::Absent => match &self.stream {
                StreamBehavior::Sync(_) => ActionKind::Sync,
                StreamBehavior::Async(_) => ActionKind::Async,
                StreamBehavior::Dual { preferred, .. } => *preferred,
                StreamBehavior::Absent => ActionKind::Sync,
            },
        }
    }

    fn is_empty(&self) -> bool {
        if let TerminalBehavior::Absent = &self.terminal {
            if let StreamBehavior::Absent = &self.stream {
                return true;
            }
        }
        false
    }

    fn requires_async_for_sync(&self) -> bool {
        if let TerminalBehavior::Async(_) = &self.terminal {
            return true;
        }
        if let TerminalBehavior::Absent = &self.terminal {
            if let StreamBehavior::Async(_) = &self.stream {
                return true;
            }
        }
        false
    }

    fn run_sync(
        &self,
        action: &FunctionAction,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        match &self.terminal {
            TerminalBehavior::Sync(handler) | TerminalBehavior::Dual { sync: handler, .. } => {
                return handler(state, ctx);
            }
            TerminalBehavior::Absent | TerminalBehavior::Async(_) => {}
        }
        match &self.stream {
            StreamBehavior::Sync(handler) | StreamBehavior::Dual { sync: handler, .. } => {
                return action.exhaust_sync_stream(handler(state.clone(), ctx.clone()));
            }
            StreamBehavior::Absent | StreamBehavior::Async(_) => {}
        }
        match (&self.terminal, &self.stream) {
            (TerminalBehavior::Async(_), _) | (_, StreamBehavior::Async(_)) => {
                Err(ActionError::AsyncActionRequiresRunAsync)
            }
            _ => Err(missing_function_handler_error()),
        }
    }

    async fn run_async(
        &self,
        action: &FunctionAction,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        match &self.terminal {
            TerminalBehavior::Async(handler)
            | TerminalBehavior::Dual {
                async_handler: handler,
                ..
            } => return handler(state.clone(), ctx.clone()).await,
            TerminalBehavior::Sync(handler) => return handler(state, ctx),
            TerminalBehavior::Absent => {}
        }
        match &self.stream {
            StreamBehavior::Async(handler)
            | StreamBehavior::Dual {
                async_handler: handler,
                ..
            } => {
                action
                    .exhaust_async_stream(handler(state.clone(), ctx.clone()))
                    .await
            }
            StreamBehavior::Sync(handler) => {
                action
                    .exhaust_async_stream(boxed_local_async_stream(futures::stream::iter(handler(
                        state.clone(),
                        ctx.clone(),
                    ))))
                    .await
            }
            StreamBehavior::Absent => Err(missing_function_handler_error()),
        }
    }

    fn into_sync_stream(
        self,
        action: &FunctionAction,
        state: State,
        ctx: ActionContext,
    ) -> SyncStreamOutput {
        match &self.stream {
            StreamBehavior::Sync(handler) | StreamBehavior::Dual { sync: handler, .. } => {
                Arc::clone(handler)(state, ctx)
            }
            StreamBehavior::Async(_) => Box::new(std::iter::once(Err(RurrError::Action(
                ActionError::AsyncActionRequiresRunAsync,
            )))),
            StreamBehavior::Absent => action.stream_run_one_shot(state, self, ctx),
        }
    }

    fn into_async_stream(
        self,
        action: FunctionAction,
        state: State,
        ctx: ActionContext,
    ) -> LocalAsyncStreamOutput {
        match &self.stream {
            StreamBehavior::Async(handler)
            | StreamBehavior::Dual {
                async_handler: handler,
                ..
            } => Arc::clone(handler)(state, ctx),
            StreamBehavior::Sync(handler) => {
                boxed_local_async_stream(futures::stream::iter(Arc::clone(handler)(state, ctx)))
            }
            StreamBehavior::Absent => action.stream_run_one_shot_async(state, self, ctx),
        }
    }
}

fn writes_from_result(writes: &[String], result: &FunctionOutput) -> IndexMap<String, Value> {
    writes
        .iter()
        .filter_map(|key| result.get(key).map(|value| (key.clone(), value.clone())))
        .collect()
}

fn finalize_result_for_writes(writes: &[String], result: FunctionOutput) -> ActionResult {
    let output_writes = writes_from_result(writes, &result);
    ActionResult::new(result, output_writes)
}

fn missing_function_handler_error() -> ActionError {
    ActionError::Internal {
        message: "function action missing call and stream handlers".to_string(),
    }
}

fn boxed_async_action_result_handler<H, Fut>(handler: H) -> Arc<AsyncActionResultHandler>
where
    H: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
    Fut: Future<Output = Result<ActionResult, ActionError>> + 'static,
{
    Arc::new(move |state: State, ctx: ActionContext| Box::pin(handler(state, ctx)))
}

/// Function-action state update callback.
pub type FunctionActionUpdateFn =
    dyn Fn(&ActionResult, &State, &ActionContext) -> Result<State, ActionError> + Send + Sync;

/// State update policy used after a [`FunctionAction`] produces an [`ActionResult`].
#[derive(Clone, Default)]
pub enum FunctionActionUpdatePolicy {
    /// Apply `ActionResult::writes()` to the current state.
    #[default]
    DefaultWrites,
    /// Run a caller-provided update callback.
    Custom(Arc<FunctionActionUpdateFn>),
}

impl fmt::Debug for FunctionActionUpdatePolicy {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::DefaultWrites => f.write_str("DefaultWrites"),
            Self::Custom(_) => f.write_str("Custom(..)"),
        }
    }
}

impl FunctionBehavior {
    fn sync_handler<H>(writes: &[String], handler: H) -> Self
    where
        H: Fn(&State, &ActionContext) -> FunctionOutput + Send + Sync + 'static,
    {
        let writes = writes.to_vec();
        let handler = move |state: &State, ctx: &ActionContext| {
            Ok(finalize_result_for_writes(&writes, handler(state, ctx)))
        };
        Self::terminal(TerminalBehavior::Sync(Arc::new(handler)))
    }

    fn async_handler<H, Fut>(writes: &[String], handler: H) -> Self
    where
        H: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = FunctionOutput> + 'static,
    {
        let writes = writes.to_vec();
        let boxed_handler =
            move |state: State,
                  ctx: ActionContext|
                  -> LocalBoxFuture<'static, Result<ActionResult, ActionError>> {
                let writes = writes.clone();
                let output = handler(state, ctx);
                Box::pin(async move { Ok(finalize_result_for_writes(&writes, output.await)) })
            };
        Self::terminal(TerminalBehavior::Async(Arc::new(boxed_handler)))
    }

    fn dual_action_result_handler<H, A, Fut>(
        sync_handler: H,
        async_handler: A,
        kind: ActionKind,
    ) -> Self
    where
        H: Fn(&State, &ActionContext) -> Result<ActionResult, ActionError> + Send + Sync + 'static,
        A: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = Result<ActionResult, ActionError>> + 'static,
    {
        Self::terminal(TerminalBehavior::Dual {
            sync: Arc::new(sync_handler),
            async_handler: boxed_async_action_result_handler(async_handler),
            preferred: kind,
        })
    }

    fn sync_stream<H, I>(handler: H) -> Self
    where
        H: Fn(State, ActionContext) -> I + Send + Sync + 'static,
        I: Iterator<Item = StreamOutput> + 'static,
    {
        let boxed_handler =
            move |state: State, ctx: ActionContext| -> Box<dyn Iterator<Item = StreamOutput>> {
                Box::new(handler(state, ctx))
            };
        Self::stream(StreamBehavior::Sync(Arc::new(boxed_handler)))
    }

    fn async_stream<H>(handler: H) -> Self
    where
        H: Fn(State, ActionContext) -> LocalAsyncStreamOutput + Send + Sync + 'static,
    {
        Self::stream(StreamBehavior::Async(Arc::new(handler)))
    }

    fn async_stream_from_stream<H, S>(handler: H) -> Self
    where
        H: Fn(State, ActionContext) -> S + Send + Sync + 'static,
        S: Stream<Item = StreamOutput> + 'static,
    {
        let boxed_handler = move |state: State, ctx: ActionContext| -> LocalAsyncStreamOutput {
            Box::pin(handler(state, ctx))
        };
        Self::async_stream(boxed_handler)
    }

    fn dual_action_result_with_streams<H, A, Fut, S, AS>(
        sync_handler: H,
        async_handler: A,
        sync_stream: S,
        async_stream: AS,
        kind: ActionKind,
    ) -> Self
    where
        H: Fn(&State, &ActionContext) -> Result<ActionResult, ActionError> + Send + Sync + 'static,
        A: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = Result<ActionResult, ActionError>> + 'static,
        S: Fn(State, ActionContext) -> Box<dyn Iterator<Item = StreamOutput>>
            + Send
            + Sync
            + 'static,
        AS: Fn(State, ActionContext) -> LocalAsyncStreamOutput + Send + Sync + 'static,
    {
        Self::terminal_with_streams(
            TerminalBehavior::Dual {
                sync: Arc::new(sync_handler),
                async_handler: boxed_async_action_result_handler(async_handler),
                preferred: kind,
            },
            StreamBehavior::Dual {
                sync: Arc::new(sync_stream),
                async_handler: Arc::new(async_stream),
                preferred: kind,
            },
        )
    }

    fn validate(&self, builder: &FunctionActionBuilder) -> Result<(), ActionError> {
        builder.validate_reserved_runtime_inputs()?;
        builder.validate_declared_reserved_inputs()?;
        builder.validate_defaults()?;
        if self.is_empty() {
            return Err(missing_function_handler_error());
        }
        Ok(())
    }
}

/// General-purpose action implementation backed by Rust closures.
#[derive(Clone)]
pub struct FunctionAction {
    name: Option<String>,
    reads: Vec<String>,
    writes: Vec<String>,
    tags: Vec<String>,
    inputs: Vec<String>,
    optional_inputs: Vec<String>,
    input_spec: PreparedInputSpec,
    source_code: Option<String>,
    behavior: FunctionBehavior,
    update_policy: FunctionActionUpdatePolicy,
}

impl FunctionAction {
    /// Returns a new builder for creating a [`FunctionAction`].
    ///
    /// # Examples
    ///
    /// ```rust
    /// use indexmap::IndexMap;
    /// use rurr_core::{LocalAction, ActionContext, FunctionAction};
    /// use serde_json::json;
    ///
    /// let action = FunctionAction::builder()
    ///     .writes(["count"])
    ///     .build_sync(|_state, _ctx| IndexMap::from([("count".to_string(), json!(1))]))?;
    /// let result = action.run(&rurr_core::State::default(), &ActionContext::default())?;
    /// assert_eq!(result.writes().get("count"), Some(&json!(1)));
    /// # Ok::<(), rurr_core::ActionError>(())
    /// ```
    pub fn builder() -> FunctionActionBuilder {
        FunctionActionBuilder::new()
    }

    fn from_builder(builder: FunctionActionBuilder, behavior: FunctionBehavior) -> Self {
        let input_spec = PreparedInputSpec::from_builder(&builder);
        Self {
            name: None,
            reads: builder.reads,
            writes: builder.writes,
            tags: builder.tags,
            inputs: builder.inputs,
            optional_inputs: builder.optional_inputs,
            input_spec,
            source_code: builder.source_code,
            behavior,
            update_policy: builder.update_policy,
        }
    }

    fn prepare_call(&self, ctx: &ActionContext) -> Result<ActionContext, ActionError> {
        self.input_spec.resolve_context(ctx)
    }

    fn prepare_sync_call(&self, ctx: &ActionContext) -> Result<ActionContext, ActionError> {
        if self.behavior.requires_async_for_sync() {
            Err(ActionError::AsyncActionRequiresRunAsync)
        } else {
            self.prepare_call(ctx)
        }
    }

    fn terminal_stream_result(
        &self,
        item: StreamOutput,
    ) -> Result<Option<ActionResult>, ActionError> {
        let (result, maybe_state) = item.map_err(Self::map_stream_error)?;
        Ok(maybe_state.map(|_| finalize_result_for_writes(&self.writes, result)))
    }

    fn map_stream_error(error: RurrError) -> ActionError {
        match error {
            RurrError::Action(error) => error,
            RurrError::Message(message) => ActionError::Internal { message },
        }
    }

    /// Returns this action with a replaced tag list.
    #[must_use]
    pub fn with_tags(mut self, tags: &[&str]) -> Self {
        self.tags = tags.iter().map(|tag| (*tag).to_string()).collect();
        self
    }

    fn apply_update_policy(
        &self,
        result: &ActionResult,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<State, ActionError> {
        match &self.update_policy {
            FunctionActionUpdatePolicy::DefaultWrites => state
                .update(result.writes().clone())
                .map_err(ActionError::from),
            FunctionActionUpdatePolicy::Custom(update) => update(result, state, ctx),
        }
    }

    fn missing_terminal_stream_error() -> ActionError {
        ActionError::Internal {
            message: "function streaming action exhausted without yielding a terminal state"
                .to_string(),
        }
    }

    fn exhaust_sync_stream(&self, stream: SyncStreamOutput) -> Result<ActionResult, ActionError> {
        for item in stream {
            if let Some(result) = self.terminal_stream_result(item)? {
                return Ok(result);
            }
        }

        Err(Self::missing_terminal_stream_error())
    }

    async fn exhaust_async_stream(
        &self,
        mut stream: LocalAsyncStreamOutput,
    ) -> Result<ActionResult, ActionError> {
        while let Some(item) = stream.next().await {
            if let Some(result) = self.terminal_stream_result(item)? {
                return Ok(result);
            }
        }

        Err(Self::missing_terminal_stream_error())
    }

    fn finalize_one_shot_stream_output(
        &self,
        result: Result<ActionResult, ActionError>,
        state: &State,
        ctx: &ActionContext,
    ) -> StreamOutput {
        result.map_err(RurrError::from).and_then(|result| {
            let next_state = self.update(&result, state, ctx).map_err(RurrError::from)?;
            Ok((result.result().clone(), Some(next_state)))
        })
    }

    fn stream_run_one_shot(
        &self,
        state: State,
        behavior: FunctionBehavior,
        ctx: ActionContext,
    ) -> SyncStreamOutput {
        let output = self.finalize_one_shot_stream_output(
            behavior.run_sync(self, &state, &ctx),
            &state,
            &ctx,
        );
        Box::new(std::iter::once(output))
    }

    fn stream_run_one_shot_async(
        self,
        state: State,
        behavior: FunctionBehavior,
        ctx: ActionContext,
    ) -> LocalAsyncStreamOutput {
        boxed_local_async_stream(futures::stream::once(async move {
            self.finalize_one_shot_stream_output(
                behavior.run_async(&self, &state, &ctx).await,
                &state,
                &ctx,
            )
        }))
    }
}

impl fmt::Debug for FunctionAction {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("FunctionAction")
            .field("name", &self.name)
            .field("reads", &self.reads)
            .field("writes", &self.writes)
            .field("tags", &self.tags)
            .field("inputs", &self.inputs)
            .field("optional_inputs", &self.optional_inputs)
            .field("input_spec", &self.input_spec)
            .field("source_code", &self.source_code)
            .field("kind", &self.kind())
            .field("update_policy", &self.update_policy)
            .finish()
    }
}

impl LocalAction for FunctionAction {
    fn name(&self) -> Option<&str> {
        self.name.as_deref()
    }

    fn reads(&self) -> &[String] {
        &self.reads
    }

    fn writes(&self) -> &[String] {
        &self.writes
    }

    fn inputs(&self) -> &[String] {
        &self.inputs
    }

    fn optional_inputs(&self) -> &[String] {
        &self.optional_inputs
    }

    fn tags(&self) -> &[String] {
        &self.tags
    }

    fn source_code(&self) -> Option<String> {
        self.source_code.clone()
    }

    fn kind(&self) -> ActionKind {
        self.behavior.kind()
    }

    fn with_name(&self, name: impl Into<String>) -> Result<Self, ActionError> {
        macro_support::with_name_once(self, self.name.as_deref(), name, |copied, next_name| {
            copied.name = Some(next_name);
        })
    }

    fn run(&self, state: &State, ctx: &ActionContext) -> Result<ActionResult, ActionError> {
        let ctx = self.prepare_sync_call(ctx)?;
        self.behavior.run_sync(self, state, &ctx)
    }

    async fn run_async(
        &self,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<ActionResult, ActionError> {
        let ctx = self.prepare_call(ctx)?;
        self.behavior.run_async(self, state, &ctx).await
    }

    fn stream_run(
        &self,
        state: State,
        ctx: ActionContext,
    ) -> Box<dyn Iterator<Item = StreamOutput>> {
        match self.prepare_sync_call(&ctx) {
            Ok(ctx) => self.behavior.clone().into_sync_stream(self, state, ctx),
            Err(error) => Box::new(std::iter::once(Err(error.into()))),
        }
    }

    fn stream_run_async(&self, state: State, ctx: ActionContext) -> LocalAsyncStreamOutput {
        match self.prepare_call(&ctx) {
            Ok(ctx) => self
                .behavior
                .clone()
                .into_async_stream(self.clone(), state, ctx),
            Err(error) => macro_support::async_action_error_stream(error),
        }
    }

    fn update(
        &self,
        result: &ActionResult,
        state: &State,
        ctx: &ActionContext,
    ) -> Result<State, ActionError> {
        self.apply_update_policy(result, state, ctx)
    }
}

/// Builder for sync, async, and streaming [`FunctionAction`] values.
///
/// The builder records action metadata before one of the `build_*` methods
/// installs executable logic. Required inputs, optional inputs, bound values,
/// and defaults are validated when the action is built: reserved `__*` runtime
/// keys are rejected, defaults must target optional inputs, and runtime inputs
/// cannot override bound values.
#[derive(Debug, Clone, Default)]
pub struct FunctionActionBuilder {
    reads: Vec<String>,
    writes: Vec<String>,
    tags: Vec<String>,
    inputs: Vec<String>,
    optional_inputs: Vec<String>,
    bound_inputs: ActionInputs,
    defaults: ActionInputs,
    source_code: Option<String>,
    reserved_runtime_inputs: Vec<String>,
    update_policy: FunctionActionUpdatePolicy,
}

impl FunctionActionBuilder {
    /// Creates an empty function-action builder.
    ///
    /// # Examples
    ///
    /// ```rust
    /// let builder = rurr_core::FunctionActionBuilder::new()
    ///     .reads(["count"])
    ///     .writes(["count"]);
    /// let _ = builder;
    /// ```
    pub fn new() -> Self {
        Self::default()
    }

    /// Replaces the action read set.
    pub fn reads<K, I>(mut self, reads: I) -> Self
    where
        K: Into<String>,
        I: IntoIterator<Item = K>,
    {
        self.reads = reads.into_iter().map(Into::into).collect();
        self
    }

    /// Replaces the action write set.
    pub fn writes<K, I>(mut self, writes: I) -> Self
    where
        K: Into<String>,
        I: IntoIterator<Item = K>,
    {
        self.writes = writes.into_iter().map(Into::into).collect();
        self
    }

    /// Replaces the action tag list.
    pub fn tags<K, I>(mut self, tags: I) -> Self
    where
        K: Into<String>,
        I: IntoIterator<Item = K>,
    {
        self.tags = tags.into_iter().map(Into::into).collect();
        self
    }

    /// Replaces the required runtime input list.
    ///
    /// Required inputs must be supplied by the caller or by [`bind`](Self::bind).
    /// Names in Rurr's reserved `__*` namespace are rejected when the action is
    /// built.
    pub fn inputs<K, I>(mut self, inputs: I) -> Self
    where
        K: Into<String>,
        I: IntoIterator<Item = K>,
    {
        self.inputs = inputs.into_iter().map(Into::into).collect();
        self
    }

    /// Replaces the optional runtime input list.
    ///
    /// Optional inputs may receive defaults through [`defaults`](Self::defaults).
    /// A default for a required or undeclared input is rejected during build.
    pub fn optional_inputs<K, I>(mut self, optional_inputs: I) -> Self
    where
        K: Into<String>,
        I: IntoIterator<Item = K>,
    {
        self.optional_inputs = optional_inputs.into_iter().map(Into::into).collect();
        self
    }

    /// Binds runtime inputs to fixed values.
    ///
    /// Bound inputs are merged before caller-provided runtime inputs. If a
    /// caller later supplies the same key, execution fails instead of silently
    /// overriding the bound value.
    pub fn bind<K, V, I>(mut self, bound_inputs: I) -> Self
    where
        K: Into<String>,
        V: Into<Value>,
        I: IntoIterator<Item = (K, V)>,
    {
        for (key, value) in bound_inputs {
            let key: String = key.into();
            if is_reserved_runtime_input(&key) {
                self.reserved_runtime_inputs.push(key);
                continue;
            }
            self.bound_inputs.insert(key, value.into());
        }
        self
    }

    /// Supplies default values for optional runtime inputs.
    ///
    /// Defaults fill missing optional inputs only. They do not make undeclared
    /// inputs valid and they cannot target the reserved runtime namespace.
    pub fn defaults<K, V, I>(mut self, defaults: I) -> Self
    where
        K: Into<String>,
        V: Into<Value>,
        I: IntoIterator<Item = (K, V)>,
    {
        for (key, value) in defaults {
            let key: String = key.into();
            if is_reserved_runtime_input(&key) {
                self.reserved_runtime_inputs.push(key);
                continue;
            }
            self.defaults.insert(key, value.into());
        }
        self
    }

    /// Stores source text shown by [`crate::action::Action::source_code`].
    pub fn with_source_code(mut self, source_code: impl Into<String>) -> Self {
        self.source_code = Some(source_code.into());
        self
    }

    /// Replaces the state update policy used after action execution.
    pub fn with_update_policy(mut self, policy: FunctionActionUpdatePolicy) -> Self {
        self.update_policy = policy;
        self
    }

    /// Replaces the state update policy with a custom callback.
    pub fn with_update(
        self,
        update: impl Fn(&ActionResult, &State, &ActionContext) -> Result<State, ActionError>
            + Send
            + Sync
            + 'static,
    ) -> Self {
        self.with_update_policy(FunctionActionUpdatePolicy::Custom(Arc::new(update)))
    }

    fn validate_reserved_runtime_inputs(&self) -> Result<(), ActionError> {
        if let Some(key) = self.reserved_runtime_inputs.first() {
            return Err(ActionError::ReservedRuntimeInputBinding { key: key.clone() });
        }
        Ok(())
    }

    fn validate_declared_reserved_inputs(&self) -> Result<(), ActionError> {
        if let Some(key) = self
            .inputs
            .iter()
            .find(|key| is_reserved_runtime_input(key))
        {
            return Err(ActionError::ReservedRuntimeInputDeclaration { key: key.clone() });
        }
        if let Some(key) = self
            .optional_inputs
            .iter()
            .find(|key| is_reserved_runtime_input(key))
        {
            return Err(ActionError::ReservedRuntimeInputDeclaration { key: key.clone() });
        }
        Ok(())
    }

    fn validate_defaults(&self) -> Result<(), ActionError> {
        if let Some(default_key) = self.defaults.keys().find(|default_key| {
            self.inputs.contains(default_key) || !self.optional_inputs.contains(default_key)
        }) {
            return Err(ActionError::DefaultInputMustBeOptional {
                key: default_key.clone(),
            });
        }

        Ok(())
    }

    fn finish(self, behavior: FunctionBehavior) -> Result<FunctionAction, ActionError> {
        behavior.validate(&self)?;
        Ok(FunctionAction::from_builder(self, behavior))
    }

    /// Builds a synchronous action from a closure returning a result map.
    pub fn build_sync<H>(self, handler: H) -> Result<FunctionAction, ActionError>
    where
        H: Fn(&State, &ActionContext) -> FunctionOutput + Send + Sync + 'static,
    {
        let behavior = FunctionBehavior::sync_handler(&self.writes, handler);
        self.finish(behavior)
    }

    /// Builds an asynchronous action from a future-returning closure.
    pub fn build_async<H, Fut>(self, handler: H) -> Result<FunctionAction, ActionError>
    where
        H: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = FunctionOutput> + 'static,
    {
        let behavior = FunctionBehavior::async_handler(&self.writes, handler);
        self.finish(behavior)
    }

    fn finish_sync_action_result<H>(self, handler: H) -> Result<FunctionAction, ActionError>
    where
        H: Fn(&State, &ActionContext) -> Result<ActionResult, ActionError> + Send + Sync + 'static,
    {
        self.finish(FunctionBehavior::terminal(TerminalBehavior::Sync(
            Arc::new(handler),
        )))
    }

    fn finish_async_action_result<H, Fut>(self, handler: H) -> Result<FunctionAction, ActionError>
    where
        H: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = Result<ActionResult, ActionError>> + 'static,
    {
        self.finish(FunctionBehavior::terminal(TerminalBehavior::Async(
            boxed_async_action_result_handler(handler),
        )))
    }

    /// Builds an action with distinct sync and async [`ActionResult`] handlers.
    pub fn build_dual_action_result<H, A, Fut>(
        self,
        sync_handler: H,
        async_handler: A,
        kind: ActionKind,
    ) -> Result<FunctionAction, ActionError>
    where
        H: Fn(&State, &ActionContext) -> Result<ActionResult, ActionError> + Send + Sync + 'static,
        A: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = Result<ActionResult, ActionError>> + 'static,
    {
        self.finish(FunctionBehavior::dual_action_result_handler(
            sync_handler,
            async_handler,
            kind,
        ))
    }

    /// Builds distinct sync/async result handlers with paired streaming lanes.
    pub fn build_dual_action_result_with_streams<H, A, Fut, S, AS>(
        self,
        sync_handler: H,
        async_handler: A,
        sync_stream: S,
        async_stream: AS,
        kind: ActionKind,
    ) -> Result<FunctionAction, ActionError>
    where
        H: Fn(&State, &ActionContext) -> Result<ActionResult, ActionError> + Send + Sync + 'static,
        A: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = Result<ActionResult, ActionError>> + 'static,
        S: Fn(State, ActionContext) -> Box<dyn Iterator<Item = StreamOutput>>
            + Send
            + Sync
            + 'static,
        AS: Fn(State, ActionContext) -> LocalAsyncStreamOutput + Send + Sync + 'static,
    {
        self.finish(FunctionBehavior::dual_action_result_with_streams(
            sync_handler,
            async_handler,
            sync_stream,
            async_stream,
            kind,
        ))
    }

    /// Builds a sync streaming action that still supports terminal `run()`.
    ///
    /// The handler returns an owning iterator. Intermediate items should carry
    /// `None` for the terminal state; the final item should carry `Some(State)`
    /// so `run()` can lazily drain to the same terminal result without changing
    /// streaming semantics.
    pub fn build_streaming_sync<H, I>(self, handler: H) -> Result<FunctionAction, ActionError>
    where
        H: Fn(State, ActionContext) -> I + Send + Sync + 'static,
        I: Iterator<Item = StreamOutput> + 'static,
    {
        self.finish(FunctionBehavior::sync_stream(handler))
    }

    /// Builds an async streaming action from a stream-returning closure.
    ///
    /// The closure returns an owning local stream. Use this for async streaming
    /// actions that stay on the caller's task and do not need a `Send` stream
    /// return type.
    pub fn build_streaming_async<H, S>(self, handler: H) -> Result<FunctionAction, ActionError>
    where
        H: Fn(State, ActionContext) -> S + Send + Sync + 'static,
        S: Stream<Item = StreamOutput> + 'static,
    {
        self.finish(FunctionBehavior::async_stream_from_stream(handler))
    }

    pub(crate) fn into_macro_sync_action<H>(self, handler: H) -> Result<FunctionAction, ActionError>
    where
        H: Fn(&State, &ActionContext) -> Result<ActionResult, ActionError> + Send + Sync + 'static,
    {
        self.finish_sync_action_result(handler)
    }

    pub(crate) fn into_macro_async_action<H, Fut>(
        self,
        handler: H,
    ) -> Result<FunctionAction, ActionError>
    where
        H: Fn(State, ActionContext) -> Fut + Send + Sync + 'static,
        Fut: Future<Output = Result<ActionResult, ActionError>> + 'static,
    {
        self.finish_async_action_result(handler)
    }

    pub(crate) fn into_macro_streaming_sync_action<H, I>(
        self,
        handler: H,
    ) -> Result<FunctionAction, ActionError>
    where
        H: Fn(State, ActionContext) -> I + Send + Sync + 'static,
        I: Iterator<Item = StreamOutput> + 'static,
    {
        self.finish(FunctionBehavior::sync_stream(handler))
    }

    pub(crate) fn into_macro_streaming_async_action<H>(
        self,
        handler: H,
    ) -> Result<FunctionAction, ActionError>
    where
        H: Fn(State, ActionContext) -> LocalAsyncStreamOutput + Send + Sync + 'static,
    {
        self.finish(FunctionBehavior::async_stream(handler))
    }
}
