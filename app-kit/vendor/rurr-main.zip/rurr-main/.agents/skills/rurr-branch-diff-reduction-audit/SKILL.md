---
name: rurr-branch-diff-reduction-audit
description: "Use when auditing the current Rurr branch against main or another base branch for delete-first optimization opportunities, duplicated logic, Rust idiom drift, public API bloat, and Apache Burr parity risks before planning or implementing a refactor."
---

# Rurr Branch Diff Reduction Audit

Use this skill when the user wants the current branch diff audited for cleanup opportunities before a concrete refactor plan exists.

## Quick start

Load, in order:

- `AGENTS.md`
- `README.md`
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- the current branch diff against the requested base branch, defaulting to `main`

Load these companion skills:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`
- `$use-rust-best-practices-testing`

Load `$rurr-burr-source-parity-walk` only when changed files touch Burr-visible runtime behavior, tracking layout, persistence semantics, macro behavior, goldens, oracle artifacts, or compatibility docs.

Add these only when changed files require them:

- `$use-rust-best-practices-async`
- `$use-rust-best-practices-networking`
- `$use-rust-best-practices-dependencies-platforms`
- `$rurr-skill-catalog-maintenance`

## Workflow

1. Identify the base branch, changed files, and broad subsystem groups from the diff.
2. Inspect the actual changed code, not only filenames or stats.
3. Compare parity-sensitive behavior against compatibility docs and Burr source before recommending structure changes.
4. Find duplication, over-layering, panic paths, stale public API, dead compatibility scaffolding, unused dependencies, and avoidable helper families.
5. Flag macro-based deduplication ideas as invalid cleanup; look for struct, enum, method, or
   trait-boundary reductions instead.
6. Rank opportunities by likely net reduction first, then by correctness or stability risk.
7. Separate behavior that must remain fixed from internal structure that can be deleted or collapsed.
8. Stop at audit findings; do not plan phases or implement changes unless the user asks for that next step.

## Output contract

If no opportunities are discovered, respond exactly:

```text
no opportunities found
```

Otherwise return a ranked list with:

- the opportunity title and affected subsystem
- specific diff evidence or file references
- why the current branch adds bloat, duplication, avoidable risk, or Rust idiom drift
- the parity boundary that must stay unchanged
- the reductive cleanup direction
- the follow-on skill or gate likely needed next

## Default rules

- Prefer deleting or consolidating internal structure over adding new helpers.
- Avoid recommending new crates, feature flags, compatibility aliases, or deprecated shims.
- Avoid recommending helper macros or macro helper crates for reduction work.
- Public API breaks are acceptable when they reduce bloat and preserve Apache Burr parity.
- Treat tests, goldens, oracle artifacts, and compatibility docs as the spec.
- Call out uncertainty when Burr source, docs, and Rurr tests do not line up cleanly.
- Use subsystem guardrail skills only for changed files that actually touch those surfaces.

## Do not use this skill alone when

- the user wants a workspace-wide reduction ranking unrelated to a branch diff: also use `$rurr-burr-parity-reduction-audit`
- the user needs a decision-complete implementation plan: also use `$rurr-delete-first-refactor-plan`
- the user wants implementation of an approved plan: also use `$rurr-delete-first-refactor-plan` in implementation mode
- the user is asking for final verification after changes already exist: also use `$rurr-structural-completion-audit` and `$rurr-gate-closeout`
