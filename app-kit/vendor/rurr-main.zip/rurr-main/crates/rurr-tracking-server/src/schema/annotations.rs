use serde::{Deserialize, Deserializer, Serialize};
use serde_json::{Map, Value};

/// Identifies the tracked payload location an annotation refers to.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AnnotationDataPointerKind {
    /// A field inside the tracked application state.
    StateField,
    /// A span attribute emitted during execution.
    Attribute,
}

/// Pointer to a concrete piece of tracked data referenced by an annotation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AnnotationDataPointer {
    /// Type of tracked data being referenced.
    #[serde(rename = "type")]
    pub kind: AnnotationDataPointerKind,
    /// Field or attribute name inside the target payload.
    pub field_name: String,
    /// Optional span identifier when the pointer targets a span-scoped attribute.
    pub span_id: Option<String>,
}

/// Single observation recorded as part of an annotation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AnnotationObservation {
    /// Arbitrary structured fields supplied by the annotator.
    pub data_fields: Map<String, Value>,
    /// Optional thumbs-up or thumbs-down signal.
    pub thumbs_up_thumbs_down: Option<bool>,
    /// Concrete data pointers that motivated the observation.
    pub data_pointers: Vec<AnnotationDataPointer>,
}

/// Request payload used to create a new annotation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AnnotationCreate {
    /// Optional span identifier associated with the annotated step.
    pub span_id: Option<String>,
    /// Step name being annotated.
    pub step_name: String,
    /// Free-form classification tags.
    pub tags: Vec<String>,
    /// Recorded observations for this annotation.
    pub observations: Vec<AnnotationObservation>,
}

/// Request payload used to update an existing annotation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AnnotationUpdate {
    /// Optional replacement span identifier.
    #[serde(default)]
    pub span_id: Option<String>,
    /// Updated step name.
    pub step_name: String,
    /// Updated free-form classification tags.
    #[serde(default, deserialize_with = "deserialize_tags_default_empty")]
    pub tags: Vec<String>,
    /// Replacement observations.
    pub observations: Vec<AnnotationObservation>,
}

/// Annotation as returned by the tracking API.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AnnotationOut {
    /// Span identifier associated with the annotation, if any.
    pub span_id: Option<String>,
    /// Step name associated with the annotation.
    pub step_name: String,
    /// Free-form classification tags.
    pub tags: Vec<String>,
    /// Recorded observations.
    pub observations: Vec<AnnotationObservation>,
    /// Stable annotation identifier.
    pub id: u64,
    /// Project that owns the annotation.
    pub project_id: String,
    /// Application identifier that owns the annotation.
    pub app_id: String,
    /// Partition key that scopes the application, if any.
    pub partition_key: Option<String>,
    /// Sequence identifier for the annotated step.
    pub step_sequence_id: u64,
    /// Creation timestamp.
    pub created: String,
    /// Last update timestamp.
    pub updated: String,
}

fn deserialize_tags_default_empty<'de, D>(deserializer: D) -> Result<Vec<String>, D::Error>
where
    D: Deserializer<'de>,
{
    Ok(Option::<Vec<String>>::deserialize(deserializer)?.unwrap_or_default())
}
