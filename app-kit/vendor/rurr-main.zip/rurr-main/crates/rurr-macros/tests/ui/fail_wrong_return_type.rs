use rurr_core::state::State;

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
fn wrong_return_type(_state: &State) -> String {
    "not an action result".to_string()
}

fn main() {}
