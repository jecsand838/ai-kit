mod annotation_executor;

use super::annotations::AnnotationStore;
use super::{
    step_projection_error, BackendCapabilities, BackendError, PartitionSelector, TrackingBackend,
};
use crate::schema::{
    project_steps, visible_step_count, AnnotationCreate, AnnotationOut, AnnotationUpdate,
    ApplicationLogs, ApplicationPage, ApplicationSummary, Project,
};
use crate::StorageRootError;
use annotation_executor::AnnotationExecutor;
use async_trait::async_trait;
use rurr_core::tracking::{
    ApplicationMetadataModel, ApplicationModel, ChildApplicationModel, PointerModel,
};
use rurr_tracking_store::tracking_repository::{
    artifacts::TrackingArtifact,
    list_sorted_app_names, list_sorted_project_names, open_project_dir_if_present,
    read::{
        self as repository_read, PartitionSemantics, PartitionedAppEntry, RepositoryMetadataHeader,
        RepositoryPointerHeader, VisitPartitionedAppsError,
    },
};
use std::cmp::Reverse;
use std::collections::BTreeMap;
use std::fs;
use std::io::{self, ErrorKind};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use time::format_description::well_known::Rfc3339;
use time::OffsetDateTime;
use tokio::sync::OnceCell;

/// Filesystem-backed tracking backend used by the local server.
#[derive(Debug, Clone)]
pub struct LocalBackend {
    storage_dir: PathBuf,
    storage_root_anchor: Arc<OnceCell<rurr_tracking_store::anchored_fs::AnchoredDir>>,
    annotation_executor: Arc<OnceCell<AnnotationExecutor>>,
}

impl LocalBackend {
    /// Creates a backend rooted at `storage_dir`.
    pub fn new(storage_dir: impl Into<PathBuf>) -> Result<Self, StorageRootError> {
        let storage_dir = pin_absolute_storage_dir(storage_dir.into())?;
        let storage_root_anchor = Arc::new(OnceCell::new());
        if let Some(anchor) = open_pinned_storage_root_anchor_if_present(&storage_dir) {
            let _ = storage_root_anchor.set(anchor);
        }
        Ok(Self {
            storage_dir,
            storage_root_anchor,
            annotation_executor: Arc::new(OnceCell::new()),
        })
    }

    /// Returns the pinned storage directory used by this backend.
    pub fn storage_dir(&self) -> &Path {
        &self.storage_dir
    }

    async fn annotation_executor(&self) -> Result<&AnnotationExecutor, BackendError> {
        self.annotation_executor
            .get_or_try_init(|| async { AnnotationExecutor::start().map_err(BackendError::Io) })
            .await
    }

    async fn storage_root_anchor(
        &self,
    ) -> Result<rurr_tracking_store::anchored_fs::AnchoredDir, BackendError> {
        let anchor = self
            .storage_root_anchor
            .get_or_try_init(|| async {
                rurr_tracking_store::anchored_fs::AnchoredDir::open(&self.storage_dir)
                    .map_err(map_scope_error)
            })
            .await?;
        Ok(anchor.clone())
    }

    async fn find_project_dir(
        &self,
        project_id: &str,
    ) -> Result<Option<rurr_tracking_store::anchored_fs::AnchoredDir>, BackendError> {
        validate_path_segment_checked("project_id", project_id)?;
        let storage_root = match self.storage_root_anchor().await {
            Ok(anchor) => anchor,
            Err(BackendError::Io(error)) if error.kind() == ErrorKind::NotFound => {
                return Ok(None);
            }
            Err(error) => return Err(error),
        };
        open_project_dir_if_present(&storage_root, project_id).map_err(map_scope_error)
    }

    async fn require_project_dir(
        &self,
        project_id: &str,
    ) -> Result<rurr_tracking_store::anchored_fs::AnchoredDir, BackendError> {
        self.find_project_dir(project_id)
            .await?
            .ok_or_else(|| BackendError::NotFound {
                resource: format!("project:{project_id}"),
            })
    }

    fn app_resource(project_id: &str, app_id: &str, partition_key: Option<&str>) -> String {
        match partition_key {
            Some(partition_key) => format!("app:{project_id}/{app_id}/{partition_key}"),
            None => format!("app:{project_id}/{app_id}"),
        }
    }

    fn map_tracking_artifact_error(error: io::Error) -> BackendError {
        match error.kind() {
            io::ErrorKind::NotFound => BackendError::NotFound {
                resource: "tracking artifact".to_string(),
            },
            io::ErrorKind::InvalidData | io::ErrorKind::InvalidInput => {
                BackendError::InvalidRequest {
                    message: error.to_string(),
                }
            }
            _ => BackendError::Io(error),
        }
    }

    fn map_partitioned_app_visit_error(
        error: VisitPartitionedAppsError<io::Error>,
    ) -> BackendError {
        match error {
            VisitPartitionedAppsError::List(error)
            | VisitPartitionedAppsError::Metadata(error)
            | VisitPartitionedAppsError::Visit(error) => Self::map_tracking_artifact_error(error),
        }
    }

    async fn require_partitioned_app_entry(
        &self,
        project_id: &str,
        app_id: &str,
        partition_key: Option<&str>,
    ) -> Result<PartitionedAppEntry<RepositoryMetadataHeader>, BackendError> {
        validate_path_segment_checked("app_id", app_id)?;
        let project_anchor = self.require_project_dir(project_id).await?;
        let Some(app_entry) = repository_read::read_partitioned_app_entry(
            &project_anchor,
            app_id,
            partition_key,
            PartitionSemantics::ExactOptional,
        )
        .map_err(Self::map_tracking_artifact_error)?
        else {
            return Err(BackendError::NotFound {
                resource: Self::app_resource(project_id, app_id, partition_key),
            });
        };

        Ok(app_entry)
    }

    async fn validate_annotation_target(
        &self,
        project_id: &str,
        app_id: &str,
        partition_key: Option<&str>,
    ) -> Result<(), BackendError> {
        let _ = self
            .require_partitioned_app_entry(project_id, app_id, partition_key)
            .await?;
        Ok(())
    }

    async fn build_annotation_store(
        &self,
        project_id: &str,
        project_anchor: rurr_tracking_store::anchored_fs::AnchoredDir,
    ) -> Result<AnnotationStore, BackendError> {
        Ok(AnnotationStore::new(project_id.to_string(), project_anchor))
    }

    async fn require_annotation_store(
        &self,
        project_id: &str,
    ) -> Result<AnnotationStore, BackendError> {
        let project_anchor = self.require_project_dir(project_id).await?;
        self.build_annotation_store(project_id, project_anchor)
            .await
    }

    async fn find_annotation_store(
        &self,
        project_id: &str,
    ) -> Result<Option<AnnotationStore>, BackendError> {
        let Some(project_anchor) = self.find_project_dir(project_id).await? else {
            return Ok(None);
        };
        self.build_annotation_store(project_id, project_anchor)
            .await
            .map(Some)
    }

    async fn with_required_annotation_store<R, F>(
        &self,
        project_id: &str,
        operation: &'static str,
        f: F,
    ) -> Result<R, BackendError>
    where
        R: Send + 'static,
        F: FnOnce(AnnotationStore) -> Result<R, BackendError> + Send + 'static,
    {
        let store = self.require_annotation_store(project_id).await?;
        self.annotation_executor()
            .await?
            .run(project_id, operation, move || f(store))
            .await
    }

    async fn with_optional_annotation_store<R, F>(
        &self,
        project_id: &str,
        operation: &'static str,
        f: F,
    ) -> Result<Option<R>, BackendError>
    where
        R: Send + 'static,
        F: FnOnce(AnnotationStore) -> Result<R, BackendError> + Send + 'static,
    {
        let Some(store) = self.find_annotation_store(project_id).await? else {
            return Ok(None);
        };
        let result = self
            .annotation_executor()
            .await?
            .run(project_id, operation, move || f(store))
            .await?;
        Ok(Some(result))
    }
}

fn pin_absolute_storage_dir(storage_dir: PathBuf) -> Result<PathBuf, StorageRootError> {
    if storage_dir.is_absolute() {
        Ok(storage_dir)
    } else {
        let cwd = std::env::current_dir().map_err(|source| {
            StorageRootError::RelativePathRequiresCurrentDir {
                path: storage_dir.clone(),
                source,
            }
        })?;
        Ok(cwd.join(&storage_dir))
    }
}

fn open_pinned_storage_root_anchor_if_present(
    storage_dir: &Path,
) -> Option<rurr_tracking_store::anchored_fs::AnchoredDir> {
    rurr_tracking_store::anchored_fs::AnchoredDir::open(storage_dir).ok()
}

fn map_scope_error(error: io::Error) -> BackendError {
    if error.kind() == ErrorKind::InvalidInput {
        BackendError::InvalidRequest {
            message: error.to_string(),
        }
    } else {
        BackendError::Io(error)
    }
}

fn validate_path_segment_checked(kind: &str, raw: &str) -> Result<(), BackendError> {
    rurr_tracking_store::anchored_fs::validate_path_segment(kind, raw).map_err(|error| {
        BackendError::InvalidRequest {
            message: error.to_string(),
        }
    })
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct FsTimestamps {
    created: String,
    modified: String,
}

fn directory_timestamps(path: &Path) -> Result<FsTimestamps, BackendError> {
    let metadata = fs::metadata(path)?;
    Ok(FsTimestamps {
        created: created_timestamp(&metadata)?,
        modified: format_system_time(metadata.modified()?)?,
    })
}

#[cfg(unix)]
fn created_timestamp(metadata: &fs::Metadata) -> Result<String, BackendError> {
    use std::os::unix::fs::MetadataExt;

    let nanos = i128::from(metadata.ctime())
        .saturating_mul(1_000_000_000)
        .saturating_add(i128::from(metadata.ctime_nsec()));
    format_offset_datetime(
        OffsetDateTime::from_unix_timestamp_nanos(nanos).map_err(|error| {
            BackendError::InvalidRequest {
                message: format!("filesystem ctime is outside supported timestamp range: {error}"),
            }
        })?,
    )
}

#[cfg(not(unix))]
fn created_timestamp(metadata: &fs::Metadata) -> Result<String, BackendError> {
    format_system_time(metadata.created()?)
}

fn format_system_time(time: std::time::SystemTime) -> Result<String, BackendError> {
    format_offset_datetime(OffsetDateTime::from(time))
}

fn format_offset_datetime(time: OffsetDateTime) -> Result<String, BackendError> {
    time.format(&Rfc3339)
        .map_err(|error| BackendError::InvalidRequest {
            message: format!("failed to format RFC3339 timestamp: {error}"),
        })
}

fn pointer_header_to_model(pointer: RepositoryPointerHeader) -> PointerModel {
    PointerModel {
        r#type: pointer.r#type,
        app_id: pointer.app_id,
        sequence_id: pointer.sequence_id,
        partition_key: pointer.partition_key,
    }
}

#[async_trait]
impl TrackingBackend for LocalBackend {
    fn backend_name(&self) -> &'static str {
        "local"
    }

    fn backend_capabilities(&self) -> BackendCapabilities {
        BackendCapabilities {
            supports_annotations: true,
            ..BackendCapabilities::default()
        }
    }

    async fn list_projects(&self) -> Result<Vec<Project>, BackendError> {
        let storage_root = match self.storage_root_anchor().await {
            Ok(anchor) => anchor,
            Err(BackendError::Io(error)) if error.kind() == ErrorKind::NotFound => {
                return Ok(Vec::new());
            }
            Err(error) => return Err(error),
        };

        list_sorted_project_names(&storage_root)
            .map_err(map_scope_error)?
            .into_iter()
            .map(|project_id| {
                let project_anchor = open_project_dir_if_present(&storage_root, &project_id)
                    .map_err(map_scope_error)?
                    .ok_or_else(|| BackendError::NotFound {
                        resource: format!("project:{project_id}"),
                    })?;
                let timestamps = directory_timestamps(project_anchor.display_path())?;
                let num_apps = list_sorted_app_names(&project_anchor)
                    .map_err(map_scope_error)?
                    .len();
                Ok(Project {
                    name: project_id.clone(),
                    id: project_id.clone(),
                    last_written: timestamps.modified,
                    created: timestamps.created,
                    num_apps,
                    uri: None,
                })
            })
            .collect()
    }

    async fn list_apps(
        &self,
        project_id: &str,
        partition_key: Option<&str>,
        limit: usize,
        offset: usize,
    ) -> Result<ApplicationPage, BackendError> {
        let project_anchor = self.require_project_dir(project_id).await?;

        let mut summaries = Vec::new();
        repository_read::visit_sorted_partitioned_apps(
            &project_anchor,
            partition_key,
            PartitionSemantics::ExactOptional,
            |app_entry| {
                let log = repository_read::read_required_jsonl_artifact::<serde_json::Value>(
                    &app_entry.anchor,
                    TrackingArtifact::Log,
                )?;
                let timestamps = directory_timestamps(app_entry.anchor.display_path())
                    .map_err(|error| io::Error::new(io::ErrorKind::InvalidData, error))?;
                summaries.push(ApplicationSummary {
                    app_id: app_entry.app_id,
                    partition_key: app_entry.metadata.partition_key,
                    first_written: timestamps.created,
                    last_written: timestamps.modified,
                    num_steps: visible_step_count(&log).map_err(|error| {
                        io::Error::new(
                            io::ErrorKind::InvalidData,
                            step_projection_error(error).to_string(),
                        )
                    })?,
                    tags: BTreeMap::new(),
                    parent_pointer: app_entry
                        .metadata
                        .parent_pointer
                        .map(pointer_header_to_model),
                    spawning_parent_pointer: app_entry
                        .metadata
                        .spawning_parent_pointer
                        .map(pointer_header_to_model),
                });
                Ok(())
            },
        )
        .map_err(Self::map_partitioned_app_visit_error)?;

        summaries.sort_by_key(|summary| {
            (
                Reverse(summary.last_written.clone()),
                summary.app_id.clone(),
            )
        });
        let total = summaries.len();
        let applications = summaries.into_iter().skip(offset).take(limit).collect();
        Ok(ApplicationPage {
            applications,
            total,
            has_another_page: total > offset.saturating_add(limit),
        })
    }

    async fn read_app(
        &self,
        project_id: &str,
        app_id: &str,
        partition_key: Option<&str>,
    ) -> Result<ApplicationLogs, BackendError> {
        let app_entry = self
            .require_partitioned_app_entry(project_id, app_id, partition_key)
            .await?;

        let metadata = repository_read::read_required_json_artifact::<ApplicationMetadataModel>(
            &app_entry.anchor,
            TrackingArtifact::Metadata,
        )
        .map_err(Self::map_tracking_artifact_error)?;
        let graph = repository_read::read_required_json_artifact::<ApplicationModel>(
            &app_entry.anchor,
            TrackingArtifact::Graph,
        )
        .map_err(Self::map_tracking_artifact_error)?;
        let log = repository_read::read_required_jsonl_artifact::<serde_json::Value>(
            &app_entry.anchor,
            TrackingArtifact::Log,
        )
        .map_err(Self::map_tracking_artifact_error)?;
        let children = repository_read::read_optional_jsonl_artifact::<ChildApplicationModel>(
            &app_entry.anchor,
            TrackingArtifact::Children,
        )
        .map_err(Self::map_tracking_artifact_error)?;
        let steps = project_steps(log).map_err(step_projection_error)?;

        Ok(ApplicationLogs {
            application: graph,
            children,
            steps,
            parent_pointer: metadata.parent_pointer,
            spawning_parent_pointer: metadata.spawning_parent_pointer,
        })
    }

    async fn create_annotation(
        &self,
        annotation: AnnotationCreate,
        project_id: &str,
        partition_key: Option<&str>,
        app_id: &str,
        step_sequence_id: u64,
    ) -> Result<AnnotationOut, BackendError> {
        self.validate_annotation_target(project_id, app_id, partition_key)
            .await?;
        let app_id = app_id.to_string();
        let partition_key = partition_key.map(str::to_string);
        self.with_required_annotation_store(project_id, "create annotation", move |store| {
            store.create(annotation, app_id, partition_key, step_sequence_id)
        })
        .await
    }

    async fn update_annotation(
        &self,
        annotation: AnnotationUpdate,
        project_id: &str,
        annotation_id: u64,
    ) -> Result<AnnotationOut, BackendError> {
        self.with_required_annotation_store(project_id, "update annotation", move |store| {
            store.update(annotation, annotation_id)
        })
        .await
    }

    async fn get_annotations(
        &self,
        project_id: &str,
        partition_selector: PartitionSelector,
        app_id: Option<&str>,
        step_sequence_id: Option<u64>,
    ) -> Result<Vec<AnnotationOut>, BackendError> {
        let app_id = app_id.map(str::to_string);
        let Some(annotations) = self
            .with_optional_annotation_store(project_id, "list annotations", move |store| {
                store.list(partition_selector, app_id, step_sequence_id)
            })
            .await?
        else {
            return Ok(Vec::new());
        };
        Ok(annotations)
    }
}
