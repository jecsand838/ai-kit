use crate::admin_publish::{
    admin_publish_command, assert_unsafe_dist_dir_rejected, canonical_cli_target, workspace_root,
    MANAGED_DIR_MARKER_FILENAME,
};
use rurr_testkit::command_fixture::{assert_success, run_command};
use std::fs;

#[test]
fn admin_publish_rejects_nonempty_external_dist_dir_by_default() {
    let scratch = tempfile::tempdir().expect("scratch dir should be created");
    let dist_dir = scratch.path().join("external-dist");
    let sentinel = dist_dir.join("keep.txt");
    let nested_cwd = workspace_root().join("crates").join("rurr-cli").join("src");

    fs::create_dir_all(&dist_dir).expect("external dist dir should be created");
    fs::write(&sentinel, "sentinel").expect("sentinel should be written");

    let mut command = admin_publish_command(&nested_cwd, &canonical_cli_target(&dist_dir));
    let output = run_command(&mut command, "admin publish should run");

    assert_unsafe_dist_dir_rejected(
        &output,
        "admin publish should reject non-empty external dist dirs by default",
    );
    assert_eq!(
        fs::read_to_string(&sentinel).expect("sentinel should still exist"),
        "sentinel"
    );
}

#[test]
fn admin_publish_allows_repeat_default_runs_into_managed_external_dist_dir() {
    let scratch = tempfile::tempdir().expect("scratch dir should be created");
    let dist_dir = scratch.path().join("external-dist");
    let nested_cwd = workspace_root().join("crates").join("rurr-cli").join("src");

    fs::create_dir_all(&dist_dir).expect("external dist dir should be created");

    let mut first_command = admin_publish_command(&nested_cwd, &canonical_cli_target(&dist_dir));
    let first = run_command(&mut first_command, "first admin publish should run");
    assert_success(&first, "first admin publish should succeed");
    assert!(
        dist_dir.join(MANAGED_DIR_MARKER_FILENAME).exists(),
        "first external publish should stamp the managed-directory marker"
    );

    let stale_file = dist_dir.join("stale").join("old.txt");
    fs::create_dir_all(
        stale_file
            .parent()
            .expect("stale file should have a parent directory"),
    )
    .expect("stale directory should be created");
    fs::write(&stale_file, "stale").expect("stale file should be written");

    let mut second_command = admin_publish_command(&nested_cwd, &canonical_cli_target(&dist_dir));
    let second = run_command(&mut second_command, "second admin publish should run");
    assert_success(&second, "second admin publish should succeed");
    assert!(
        !stale_file.exists(),
        "rerun should clear stale external dist contents"
    );
    assert!(
        dist_dir.join(MANAGED_DIR_MARKER_FILENAME).exists(),
        "rerun should preserve the managed-directory marker"
    );
    let ui_root = dist_dir.join("rurr-ui");
    assert!(
        ui_root.join("index.html").exists(),
        "admin publish should export UI on rerun"
    );
}
