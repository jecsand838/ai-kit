use super::*;

fn assert_sequence_id_not_found<T>(result: Result<T, PersistenceError>) {
    assert!(matches!(
        result,
        Err(PersistenceError::UnsupportedOperation {
            operation: "sequence_id_not_found"
        })
    ));
}

fn assert_invalid_local_tracking_state<T>(result: Result<T, PersistenceError>) {
    assert!(matches!(
        result,
        Err(PersistenceError::InvalidPersistedState {
            operation: "local_tracking_client_load",
            ..
        })
    ));
}

#[test]
fn load_roundtrip_preserves_unicode_values() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_unicode_roundtrip";
    let tracker = tracker(project, &storage_root);
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![]);

    let unicode_action = FunctionActionBuilder::new()
        .writes([
            "text", "greek", "cyrillic", "hebrew", "arabic", "hindi", "chinese", "japanese",
            "korean", "emoji",
        ])
        .with_source_code(
            "fn unicode_action(_state, _ctx) { map_from_pairs([(\"text\", json!(\"á, é, í, ó, ú, ñ, ü\")), (\"greek\", json!(\"α, β, γ, δ\")), (\"cyrillic\", json!(\"ж, ы, б, ъ\")), (\"hebrew\", json!(\"א, ב, ג, ד\")), (\"arabic\", json!(\"خ, د, ذ, ر\")), (\"hindi\", json!(\"अ, आ, इ, ई\")), (\"chinese\", json!(\"中, 国, 文\")), (\"japanese\", json!(\"日, 本, 語\")), (\"korean\", json!(\"한, 국, 어\")), (\"emoji\", json!(\"😀, 👍, 🚀, 🌍\"))]) }",
        )
        .build_sync(|_state, _ctx| {
            map_from_pairs([
                ("text", json!("á, é, í, ó, ú, ñ, ü")),
                ("greek", json!("α, β, γ, δ")),
                ("cyrillic", json!("ж, ы, б, ъ")),
                ("hebrew", json!("א, ב, ג, ד")),
                ("arabic", json!("خ, د, ذ, ر")),
                ("hindi", json!("अ, आ, इ, ई")),
                ("chinese", json!("中, 国, 文")),
                ("japanese", json!("日, 本, 語")),
                ("korean", json!("한, 국, 어")),
                ("emoji", json!("😀, 👍, 🚀, 🌍")),
            ])
        })
        .expect("unicode action should build");

    let mut app = build_sync_app("unicode-app", "unicode", unicode_action, hooks);
    register_application(tracker.as_ref(), &app);

    app.run().expect("unicode app should run successfully");

    let loaded = tracker
        .load(Some("pk"), Some("unicode-app"), None)
        .expect("load should succeed")
        .expect("load should return persisted data");

    assert_eq!(loaded.status, PersistedStateStatus::Completed);
    let loaded_state = loaded.state.expect("state should be present");
    assert_eq!(loaded_state.get("emoji"), Some(&json!("😀, 👍, 🚀, 🌍")));
    assert_eq!(loaded_state.get("greek"), Some(&json!("α, β, γ, δ")));
    assert!(loaded_state.contains_key("__SEQUENCE_ID"));
}

#[test]
fn load_returns_none_when_requested_partition_does_not_match_persisted_metadata() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_partition_mismatch_load";
    let tracker = tracker(project, &storage_root);
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![]);

    let mut app = build_sync_app(
        "partition-mismatch-app",
        "counter",
        build_single_step_sync_action(),
        hooks,
    );
    register_application(tracker.as_ref(), &app);
    app.step(None).expect("step should succeed");

    let loaded = tracker
        .load(Some("wrong_pk"), Some("partition-mismatch-app"), None)
        .expect("load should succeed");
    assert!(
        loaded.is_none(),
        "partition mismatch should return no state"
    );
}

#[test]
fn default_partition_requests_match_null_metadata_partition() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_default_partition_requests_match_null_metadata";
    let app_id = "default-partition-null-metadata-app";
    let (tracker, _app_dir) = seeded_counter_app_dir(&storage_root, project, app_id, None, 1, 1);

    let loaded_without_partition = tracker
        .load(None, Some(app_id), None)
        .expect("load should succeed")
        .expect("state should exist");
    assert_eq!(loaded_without_partition.partition_key.as_deref(), Some(""));

    let loaded_with_default_partition = tracker
        .load(Some(""), Some(app_id), None)
        .expect("load should succeed")
        .expect("default partition request should match null metadata partition");
    assert_eq!(loaded_with_default_partition.app_id, app_id);
    assert_eq!(
        loaded_with_default_partition.partition_key.as_deref(),
        Some("")
    );

    let listed = tracker
        .list_app_ids(Some(""))
        .expect("default partition list_app_ids should succeed");
    assert_eq!(listed, vec![app_id.to_string()]);
}

#[test]
fn list_app_ids_filters_by_requested_partition_key() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_list_app_ids_partition_filter";
    let tracker = tracker(project, &storage_root);
    let template_app = build_counter_template_app("template");

    tracker
        .register_application("app-pk-a-2", Some("pk_a"), template_app.graph(), None, None)
        .expect("app-pk-a-2 registration should succeed");
    tracker
        .register_application("app-pk-a-1", Some("pk_a"), template_app.graph(), None, None)
        .expect("app-pk-a-1 registration should succeed");
    tracker
        .register_application("app-pk-b-1", Some("pk_b"), template_app.graph(), None, None)
        .expect("app-pk-b-1 registration should succeed");
    tracker
        .register_application("app-default-1", None, template_app.graph(), None, None)
        .expect("app-default-1 registration should succeed");

    let pk_a = tracker
        .list_app_ids(Some("pk_a"))
        .expect("pk_a list_app_ids should succeed");
    let pk_b = tracker
        .list_app_ids(Some("pk_b"))
        .expect("pk_b list_app_ids should succeed");
    let default_partition = tracker
        .list_app_ids(None)
        .expect("default partition list_app_ids should succeed");

    assert_eq!(
        pk_a,
        vec!["app-pk-a-1".to_string(), "app-pk-a-2".to_string()]
    );
    assert_eq!(pk_b, vec!["app-pk-b-1".to_string()]);
    assert_eq!(default_partition, vec!["app-default-1".to_string()]);
}

#[test]
fn metadata_missing_type_field_is_rejected_for_load_and_list() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_metadata_missing_type_rejected";
    let app_id = "metadata-missing-type-app";
    let tracker = tracker(project, &storage_root);
    let app_dir = ensure_app_dir(&storage_root, project, app_id);
    write_raw_metadata(&app_dir, r#"{"partition_key":null}"#);
    write_app_log_entries(&app_dir, &[counter_end_entry(1, 1)]);

    assert_invalid_local_tracking_state(tracker.load(None, Some(app_id), None));
    assert_invalid_local_tracking_state(tracker.list_app_ids(None));
}

#[test]
fn load_rejects_missing_metadata_for_app_dir() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_load_none_when_metadata_missing";
    let app_id = "metadata-missing-app";
    let tracker = tracker(project, &storage_root);
    let app_dir = ensure_app_dir(&storage_root, project, app_id);
    write_app_log_entries(&app_dir, &[counter_end_entry(1, 1)]);

    assert_invalid_local_tracking_state(tracker.load(None, Some(app_id), None));
}

#[test]
fn load_rejects_missing_log_for_registered_app_dir() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_load_missing_required_log";
    let app_id = "log-missing-app";
    let (tracker, app_dir) = seeded_app_dir(&storage_root, project, app_id, Some("pk"));
    fs::remove_file(app_dir.join(LocalTrackingClient::LOG_FILENAME))
        .expect("registered log should be removable");

    assert_invalid_local_tracking_state(tracker.load(Some("pk"), Some(app_id), None));
}

#[test]
fn list_app_ids_rejects_directories_without_metadata() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_list_skips_without_metadata";
    let tracker = tracker(project, &storage_root);
    let template_app = build_counter_template_app("template");

    tracker
        .register_application("registered-app", None, template_app.graph(), None, None)
        .expect("registered app should be created");

    let raw_dir = project_app_dir(&storage_root, project, "raw-dir-no-metadata");
    fs::create_dir_all(&raw_dir).expect("raw app directory should exist");

    assert_invalid_local_tracking_state(tracker.list_app_ids(None));
}

#[test]
fn project_name_validation_matches_burr_contract() {
    let cases = [
        ("Hello-World_123", false, true),
        ("Hello:World_123", false, true),
        ("Hello:World_123", true, false),
        ("Invalid:Chars*", false, false),
        ("Just$ymbols", true, false),
        ("Normal_Text", true, true),
    ];

    for (input, on_windows, expected) in cases {
        assert_eq!(
            allowed_project_name(input, on_windows),
            expected,
            "validation mismatch for input={input:?}, on_windows={on_windows}"
        );
    }
}

#[test]
fn local_tracking_client_copy_preserves_configuration() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let serde_kwargs = map_from_pairs([("foo", json!("bar"))]);

    let client =
        LocalTrackingClient::with_serde_kwargs("copy-project", &storage_root, serde_kwargs)
            .expect("client should initialize");
    let copy = client.copy().expect("copy should preserve configuration");

    assert_eq!(copy.project_id(), client.project_id());
    assert_eq!(copy.storage_dir(), client.storage_dir());
    assert_eq!(copy.serde_kwargs(), client.serde_kwargs());
}

#[test]
fn load_returns_error_for_missing_explicit_sequence_id() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_missing_sequence_id";
    let tracker = tracker(project, &storage_root);
    let sync_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
    let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![]);

    let mut app = build_sync_app(
        "missing-seq-app",
        "counter",
        build_single_step_sync_action(),
        hooks,
    );
    register_application(tracker.as_ref(), &app);
    app.step(None).expect("step should succeed");

    assert_sequence_id_not_found(tracker.load(Some("pk"), Some("missing-seq-app"), Some(999)));
}

#[test]
fn load_ignores_truncated_trailing_jsonl_line_and_returns_latest_complete_end_entry() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_load_truncated_trailing_line";
    let app_id = "truncated-tail-app";
    let (tracker, app_dir) = seeded_app_dir(&storage_root, project, app_id, Some("pk"));
    let first = counter_end_entry(7, 7);

    let log_path = app_dir.join(LocalTrackingClient::LOG_FILENAME);
    fs::write(
        &log_path,
        format!("{first}\n{{\"type\":\"end_entry\",\"action\":\"counter\",\"sequence_id\":8"),
    )
    .expect("log should be writable");

    let loaded = tracker
        .load(Some("pk"), Some(app_id), None)
        .expect("load should succeed")
        .expect("state should exist");
    assert_eq!(loaded.sequence_id, 7);
    assert_eq!(
        loaded.state.expect("state should be present").get("count"),
        Some(&json!(7))
    );
}

#[test]
fn load_returns_sequence_id_not_found_when_only_truncated_matching_tail_exists() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_load_missing_explicit_seq_due_to_truncated_tail";
    let app_id = "truncated-explicit-seq-app";
    let (tracker, app_dir) = seeded_app_dir(&storage_root, project, app_id, Some("pk"));
    let first = counter_end_entry(7, 7);

    let log_path = app_dir.join(LocalTrackingClient::LOG_FILENAME);
    fs::write(
        &log_path,
        format!(
            "{first}\n{{\"type\":\"end_entry\",\"end_time\":\"2026-03-20T00:00:00.000000000Z\",\"action\":\"counter\",\"sequence_id\":8"
        ),
    )
    .expect("log should be writable");

    assert_sequence_id_not_found(tracker.load(Some("pk"), Some(app_id), Some(8)));
}

#[test]
fn load_fails_when_selected_end_entry_is_schema_incomplete() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_load_schema_incomplete_selected_end_entry";
    let app_id = "schema-incomplete-selected-app";
    let (tracker, app_dir) = seeded_app_dir(&storage_root, project, app_id, Some("pk"));
    let valid = counter_end_entry(7, 7);
    let malformed = json!({
        "type": "end_entry",
        "end_time": "2026-03-20T00:00:00.000000000Z",
        "action": "counter",
        "state": {"count": 8, "__SEQUENCE_ID": 8, "__PRIOR_STEP": "counter"},
        "sequence_id": 8,
        "exception": Value::Null
    });

    let log_path = app_dir.join(LocalTrackingClient::LOG_FILENAME);
    fs::write(&log_path, format!("{valid}\n{malformed}\n")).expect("log should be writable");

    assert_invalid_local_tracking_state(tracker.load(Some("pk"), Some(app_id), Some(8)));
}

#[test]
fn load_fails_when_malformed_jsonl_line_is_not_last_non_empty_line() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_load_malformed_non_terminal_line";
    let app_id = "malformed-non-terminal-app";
    let (tracker, app_dir) = seeded_app_dir(&storage_root, project, app_id, Some("pk"));
    let second = counter_end_entry(2, 2);

    let log_path = app_dir.join(LocalTrackingClient::LOG_FILENAME);
    fs::write(&log_path, format!("{{ not json\n{second}\n")).expect("log should be writable");

    assert_invalid_local_tracking_state(tracker.load(Some("pk"), Some(app_id), None));
}

#[test]
fn load_prefers_latest_matching_sequence_id_when_duplicates_exist() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_duplicate_sequence_resolution";
    let (tracker, app_dir) = seeded_app_dir(&storage_root, project, "dup-seq-app", Some("pk"));
    write_app_log_entries(
        &app_dir,
        &[
            counter_end_entry_with_exception(9, 1, json!("failed first attempt")),
            counter_end_entry(9, 2),
        ],
    );

    let loaded = tracker
        .load(Some("pk"), Some("dup-seq-app"), Some(9))
        .expect("load should succeed")
        .expect("state should exist");
    assert_eq!(loaded.status, PersistedStateStatus::Completed);
    let state = loaded.state.expect("state should be present");
    assert_eq!(state.get("count"), Some(&json!(2)));
}

#[test]
fn sync_step_logs_to_correct_app_after_registering_multiple_apps() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    futures::executor::block_on(assert_logs_to_correct_app_after_registering_multiple_apps(
        &storage_root,
        MultiAppRouteMode::SyncStep,
    ));
}

#[tokio::test]
async fn async_stream_logs_to_correct_app_after_registering_multiple_apps() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    assert_logs_to_correct_app_after_registering_multiple_apps(
        &storage_root,
        MultiAppRouteMode::AsyncStream,
    )
    .await;
}
