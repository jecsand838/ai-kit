use super::handle::{TraceHandleMode, TraceSpanHandle};
use super::hook_call::{call_async_hook, call_sync_hook};
use super::VisibilityError;
use crate::lifecycle::{LifecycleAdapterSet, LifecycleExecutionMode, SpanContext};
use crate::visibility::span::ActionSpan;
use crate::visibility::span_scope;
use indexmap::IndexMap;
use serde_json::Value;
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::Arc;

static NEXT_SESSION_ID: AtomicU64 = AtomicU64::new(1);

pub(crate) struct TraceSession {
    session_id: u64,
    action: String,
    action_sequence_id: u64,
    app_id: String,
    partition_key: Option<String>,
    hooks: LifecycleAdapterSet,
    root_span_parent: Option<ActionSpan>,
    top_level_span_count: AtomicU64,
}

impl TraceSession {
    pub(crate) fn new(
        action: impl Into<String>,
        action_sequence_id: u64,
        app_id: impl Into<String>,
        partition_key: Option<String>,
        root_span_parent: Option<ActionSpan>,
        hooks: LifecycleAdapterSet,
    ) -> Self {
        Self {
            session_id: NEXT_SESSION_ID.fetch_add(1, Ordering::Relaxed),
            action: action.into(),
            action_sequence_id,
            app_id: app_id.into(),
            partition_key,
            hooks,
            root_span_parent,
            top_level_span_count: AtomicU64::new(0),
        }
    }

    pub(crate) fn start_root_handle_sync(
        self: &Arc<Self>,
        span_name: impl Into<String>,
    ) -> Result<TraceSpanHandle, VisibilityError> {
        self.start_handle_sync(self.next_span(span_name, Vec::new()))
    }

    pub(crate) async fn start_root_handle_async(
        self: &Arc<Self>,
        span_name: impl Into<String>,
    ) -> Result<TraceSpanHandle, VisibilityError> {
        self.start_handle_async(self.next_span(span_name, Vec::new()))
            .await
    }

    fn next_span(
        &self,
        span_name: impl Into<String>,
        span_dependencies: Vec<String>,
    ) -> ActionSpan {
        let span_name = span_name.into();
        if let Some(current) = span_scope::current_span_for_session(self.session_id) {
            return current.spawn_with_dependencies(span_name, span_dependencies);
        }
        if let Some(parent) = &self.root_span_parent {
            return parent.spawn_with_dependencies(span_name, span_dependencies);
        }

        ActionSpan::create_initial_with_factory(
            self.action.clone(),
            span_name,
            self.top_level_span_count.fetch_add(1, Ordering::Relaxed),
            self.action_sequence_id,
            self.session_id,
            span_dependencies,
        )
    }

    pub(super) fn start_handle_sync(
        self: &Arc<Self>,
        span: ActionSpan,
    ) -> Result<TraceSpanHandle, VisibilityError> {
        let context = self.span_context(&span);
        call_sync_hook("pre_start_span_sync", || {
            self.hooks().pre_start_span_sync(&context)
        })?;
        Ok(TraceSpanHandle::active(
            Arc::clone(self),
            span,
            TraceHandleMode::SyncOnly,
            Vec::new(),
        ))
    }

    pub(super) async fn start_handle_async(
        self: &Arc<Self>,
        span: ActionSpan,
    ) -> Result<TraceSpanHandle, VisibilityError> {
        let context = self
            .span_context(&span)
            .with_execution_mode(LifecycleExecutionMode::Async);
        call_async_hook(
            "pre_start_span_async",
            self.hooks().pre_start_span_async(&context),
        )
        .await?;
        let poll_contexts = self.hooks().async_span_poll_contexts(&context);
        Ok(TraceSpanHandle::active(
            Arc::clone(self),
            span,
            TraceHandleMode::AsyncCapable,
            poll_contexts,
        ))
    }

    pub(super) fn finish_span_sync(&self, span: &ActionSpan) -> Result<(), VisibilityError> {
        let context = self.span_context(span);
        call_sync_hook("post_end_span_sync", || {
            self.hooks().post_end_span_sync(&context)
        })
    }

    pub(super) async fn finish_span_async(&self, span: &ActionSpan) -> Result<(), VisibilityError> {
        let context = self
            .span_context(span)
            .with_execution_mode(LifecycleExecutionMode::Async);
        call_async_hook(
            "post_end_span_async",
            self.hooks().post_end_span_async(&context),
        )
        .await
    }

    pub(super) fn log_attribute_sync(
        &self,
        span: &ActionSpan,
        key: impl Into<String>,
        value: Value,
    ) -> Result<(), VisibilityError> {
        self.log_attributes_sync(span, &IndexMap::from([(key.into(), value)]))
    }

    pub(super) fn log_attributes_sync(
        &self,
        span: &ActionSpan,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), VisibilityError> {
        let context = self.span_context(span);
        call_sync_hook("log_attributes_sync", || {
            self.hooks().log_attributes_sync(&context, attributes)
        })
    }

    pub(super) async fn log_attribute_async(
        &self,
        span: &ActionSpan,
        key: impl Into<String>,
        value: Value,
    ) -> Result<(), VisibilityError> {
        self.log_attributes_async(span, &IndexMap::from([(key.into(), value)]))
            .await
    }

    pub(super) async fn log_attributes_async(
        &self,
        span: &ActionSpan,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), VisibilityError> {
        let context = self
            .span_context(span)
            .with_execution_mode(LifecycleExecutionMode::Async);
        call_async_hook(
            "log_attributes_async",
            self.hooks().log_attributes_async(&context, attributes),
        )
        .await
    }

    pub(super) fn session_id(&self) -> u64 {
        self.session_id
    }

    fn hooks(&self) -> &LifecycleAdapterSet {
        &self.hooks
    }

    fn span_context(&self, span: &ActionSpan) -> SpanContext {
        let mut context =
            SpanContext::new(self.action.clone(), self.action_sequence_id, span.uid())
                .with_span_name(span.span_name().to_string())
                .with_span_dependencies(span.span_dependencies().to_vec())
                .with_action_span(span.clone());
        if let Some(parent) = span.parent() {
            context = context.with_parent_span_id(parent.uid());
        }
        context = context.with_app_id(self.app_id.clone());
        if let Some(partition_key) = &self.partition_key {
            context = context.with_partition_key(partition_key.clone());
        }
        context
    }
}
