use super::partition::PartitionSelector;
use super::BackendError;
use crate::schema::{AnnotationCreate, AnnotationOut, AnnotationUpdate};
use rurr_persistence::wire::sortable_rfc3339_utc_string;
use rurr_tracking_store::{
    anchored_fs::{AnchoredDir, ExactChildFileOpenOptions},
    jsonl::{parse_jsonl_line, visit_jsonl_lines, JsonlWriter},
};
use std::io::{self, BufReader, Seek, SeekFrom, Write};
use std::time::SystemTime;

const ANNOTATIONS_FILENAME: &str = "annotations.jsonl";

#[derive(Debug, Clone)]
pub(super) struct AnnotationStore {
    project_id: String,
    project_anchor: AnchoredDir,
}

enum AnnotationWrite<'a> {
    Append(&'a AnnotationOut),
    Rewrite(&'a [AnnotationOut]),
}

struct AnnotationFileSession<'a> {
    file: &'a mut std::fs::File,
}

#[derive(Debug)]
enum AnnotationFileAccessError {
    Io(io::Error),
    Backend(BackendError),
}

impl From<io::Error> for AnnotationFileAccessError {
    fn from(error: io::Error) -> Self {
        Self::Io(error)
    }
}

impl From<BackendError> for AnnotationFileAccessError {
    fn from(error: BackendError) -> Self {
        Self::Backend(error)
    }
}

impl AnnotationStore {
    pub(super) fn new(project_id: String, project_anchor: AnchoredDir) -> Self {
        Self {
            project_id,
            project_anchor,
        }
    }

    pub(super) fn create(
        &self,
        annotation: AnnotationCreate,
        app_id: String,
        partition_key: Option<String>,
        step_sequence_id: u64,
    ) -> Result<AnnotationOut, BackendError> {
        self.with_locked_access(true, |session| {
            let mut next_id = 0u64;
            session.visit_annotations(|annotation| {
                next_id = next_id.max(annotation.id.saturating_add(1));
                Ok(())
            })?;

            let now = sortable_rfc3339_utc_string(SystemTime::now()).map_err(|error| {
                BackendError::Timestamp {
                    operation: "annotation_create_timestamp",
                    message: error.to_string(),
                }
            })?;
            let annotation_out = AnnotationOut {
                span_id: annotation.span_id,
                step_name: annotation.step_name,
                tags: annotation.tags,
                observations: annotation.observations,
                id: next_id,
                project_id: self.project_id.clone(),
                app_id,
                partition_key,
                step_sequence_id,
                created: now.clone(),
                updated: now,
            };
            session.append_annotation(&annotation_out)?;
            Ok(annotation_out)
        })
    }

    pub(super) fn update(
        &self,
        annotation: AnnotationUpdate,
        annotation_id: u64,
    ) -> Result<AnnotationOut, BackendError> {
        self.with_locked_access(false, |session| {
            let mut annotations = session.read_annotations()?;
            let now = sortable_rfc3339_utc_string(SystemTime::now()).map_err(|error| {
                BackendError::Timestamp {
                    operation: "annotation_update_timestamp",
                    message: error.to_string(),
                }
            })?;
            let updated = annotations
                .iter_mut()
                .find(|item| item.id == annotation_id)
                .ok_or_else(|| BackendError::NotFound {
                    resource: format!("annotation:{}/{}", self.project_id, annotation_id),
                })?;

            updated.span_id = annotation.span_id;
            updated.step_name = annotation.step_name;
            updated.tags = annotation.tags;
            updated.observations = annotation.observations;
            updated.updated = now;

            let response = updated.clone();
            session.rewrite_annotations(&annotations)?;
            Ok(response)
        })
    }

    pub(super) fn list(
        &self,
        partition_selector: PartitionSelector,
        app_id: Option<String>,
        step_sequence_id: Option<u64>,
    ) -> Result<Vec<AnnotationOut>, BackendError> {
        self.with_optional_shared_read(|session| {
            let mut annotations = Vec::new();
            session.visit_annotations(|annotation| {
                if partition_selector.matches(annotation.partition_key.as_deref())
                    && app_id
                        .as_deref()
                        .is_none_or(|requested| annotation.app_id == requested)
                    && step_sequence_id
                        .is_none_or(|requested| annotation.step_sequence_id == requested)
                {
                    annotations.push(annotation);
                }
                Ok(())
            })?;
            Ok(annotations)
        })
        .map(|annotations| annotations.unwrap_or_default())
    }

    fn annotation_file_resource(&self) -> String {
        format!("annotation file:{}", self.project_id)
    }

    fn map_annotation_file_io_error(&self, error: io::Error) -> BackendError {
        match error.kind() {
            io::ErrorKind::NotFound => BackendError::NotFound {
                resource: self.annotation_file_resource(),
            },
            io::ErrorKind::InvalidInput => BackendError::InvalidRequest {
                message: error.to_string(),
            },
            _ => BackendError::Io(error),
        }
    }

    fn with_annotation_file<R, F>(
        &self,
        options: ExactChildFileOpenOptions,
        f: F,
    ) -> Result<Option<R>, BackendError>
    where
        F: FnOnce(&mut AnnotationFileSession<'_>) -> Result<R, BackendError>,
    {
        match self
            .project_anchor
            .with_locked_child_file::<_, AnnotationFileAccessError, _>(
                "project directory",
                "annotation file",
                ANNOTATIONS_FILENAME,
                options,
                |file| {
                    let mut session = AnnotationFileSession { file };
                    f(&mut session).map_err(AnnotationFileAccessError::from)
                },
            ) {
            Ok(result) => Ok(result),
            Err(AnnotationFileAccessError::Io(error)) => {
                Err(self.map_annotation_file_io_error(error))
            }
            Err(AnnotationFileAccessError::Backend(error)) => Err(error),
        }
    }

    fn with_optional_shared_read<R, F>(&self, f: F) -> Result<Option<R>, BackendError>
    where
        F: FnOnce(&mut AnnotationFileSession<'_>) -> Result<R, BackendError>,
    {
        self.with_annotation_file(ExactChildFileOpenOptions::shared_read_optional(), f)
    }

    fn with_locked_access<R, F>(&self, create_if_missing: bool, f: F) -> Result<R, BackendError>
    where
        F: FnOnce(&mut AnnotationFileSession<'_>) -> Result<R, BackendError>,
    {
        let options = if create_if_missing {
            ExactChildFileOpenOptions::exclusive_read_write_create_if_missing()
        } else {
            ExactChildFileOpenOptions::exclusive_read_write_existing()
        };
        self.with_annotation_file(options, f)?
            .ok_or_else(|| BackendError::NotFound {
                resource: self.annotation_file_resource(),
            })
    }
}

impl AnnotationFileSession<'_> {
    fn visit_annotations<F>(&mut self, mut on_annotation: F) -> Result<(), BackendError>
    where
        F: FnMut(AnnotationOut) -> Result<(), BackendError>,
    {
        self.file.seek(SeekFrom::Start(0))?;
        let reader = BufReader::new(self.file.try_clone()?);

        visit_jsonl_lines(reader, |line| {
            match parse_jsonl_line::<AnnotationOut>(line.line, line.is_last_non_empty_line) {
                Ok(Some(annotation)) => on_annotation(annotation),
                Ok(None) => Err(BackendError::InvalidRequest {
                    message: format!(
                        "annotation JSONL line at byte offset {} is incomplete",
                        line.start_offset
                    ),
                }),
                Err(error) => Err(BackendError::SerdeJson(error)),
            }
        })?;

        Ok(())
    }

    fn read_annotations(&mut self) -> Result<Vec<AnnotationOut>, BackendError> {
        let mut annotations = Vec::new();
        self.visit_annotations(|annotation| {
            annotations.push(annotation);
            Ok(())
        })?;
        Ok(annotations)
    }

    fn append_annotation(&mut self, annotation: &AnnotationOut) -> Result<(), BackendError> {
        self.write(AnnotationWrite::Append(annotation))
    }

    fn rewrite_annotations(&mut self, annotations: &[AnnotationOut]) -> Result<(), BackendError> {
        self.write(AnnotationWrite::Rewrite(annotations))
    }

    fn write(&mut self, write: AnnotationWrite<'_>) -> Result<(), BackendError> {
        match write {
            AnnotationWrite::Append(annotation) => {
                JsonlWriter::new(self.file)?.write_value(annotation)?;
            }
            AnnotationWrite::Rewrite(annotations) => {
                self.file.set_len(0)?;
                self.file.seek(SeekFrom::Start(0))?;
                let mut writer = JsonlWriter::new(self.file)?;
                for annotation in annotations {
                    writer.write_value(annotation)?;
                }
            }
        }
        self.file.flush()?;
        Ok(())
    }
}
