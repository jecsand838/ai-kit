use crate::support::http_request::{empty_request, json_request};
use axum::http::StatusCode;
use axum::response::Response;
use axum::Router;
use rurr_testkit::tracking_fixture::artifacts::write_jsonl;
use rurr_tracking_server::schema::AnnotationCreate;
use serde_json::{json, Value};
use std::fs;
use std::path::{Path, PathBuf};
use tower::ServiceExt;

pub(crate) const DEFAULT_PROJECT_ID: &str = "proj1";
pub(crate) const DEFAULT_APP_ID: &str = "app1";
pub(crate) const DEFAULT_PARTITION_KEY: &str = "pk";
pub(crate) const DEFAULT_STEP_SEQUENCE_ID: u64 = 0;
pub(crate) const DEFAULT_ANNOTATION_ID: u64 = 0;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum AnnotationRequestKind {
    List,
    Create,
    Update,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum TrackingEndpointKind {
    Projects,
    Apps,
    AppDetail,
}

fn annotation_request_note(kind: AnnotationRequestKind) -> Option<&'static str> {
    match kind {
        AnnotationRequestKind::List => None,
        AnnotationRequestKind::Create => Some("created"),
        AnnotationRequestKind::Update => Some("updated"),
    }
}

pub(crate) fn sample_annotation(tag: &str, note: &str) -> AnnotationCreate {
    serde_json::from_value(json!({
        "span_id": null,
        "step_name": "noop",
        "tags": [tag],
        "observations": [{
            "data_fields": {
                "note": note,
            },
            "thumbs_up_thumbs_down": true,
            "data_pointers": [{
                "type": "state_field",
                "field_name": "count",
                "span_id": null
            }]
        }]
    }))
    .expect("annotation fixture should deserialize")
}

pub(crate) fn annotation_out_json(
    id: u64,
    project_id: &str,
    app_id: &str,
    partition_key: Option<&str>,
    step_sequence_id: u64,
    note: &str,
) -> Value {
    json!({
        "span_id": null,
        "step_name": "noop",
        "tags": ["seed"],
        "observations": [{
            "data_fields": {
                "note": note,
            },
            "thumbs_up_thumbs_down": true,
            "data_pointers": [{
                "type": "state_field",
                "field_name": "count",
                "span_id": null
            }]
        }],
        "id": id,
        "project_id": project_id,
        "app_id": app_id,
        "partition_key": partition_key,
        "step_sequence_id": step_sequence_id,
        "created": "2026-03-20T00:00:00.000000000Z",
        "updated": "2026-03-20T00:00:00.000000000Z"
    })
}

pub(crate) fn annotation_body(tag: &str, note: &str) -> Value {
    json!({
        "span_id": null,
        "step_name": "noop",
        "tags": [tag],
        "observations": [{
            "data_fields": {
                "note": note,
            },
            "thumbs_up_thumbs_down": true,
            "data_pointers": [{
                "type": "state_field",
                "field_name": "count",
                "span_id": null
            }]
        }]
    })
}

pub(crate) fn pointerless_annotation_body(tag: &str, note: &str, thumbs: Option<bool>) -> Value {
    let mut body = annotation_body(tag, note);
    body["observations"][0]["data_pointers"] = json!([]);
    body["observations"][0]["thumbs_up_thumbs_down"] = match thumbs {
        Some(value) => json!(value),
        None => Value::Null,
    };
    body
}

pub(crate) fn annotations_uri(
    project_id: &str,
    app_id: Option<&str>,
    partition_key: Option<&str>,
    step_sequence_id: Option<u64>,
) -> String {
    let mut uri = format!("/api/v0/{project_id}/annotations");
    let mut params = Vec::new();
    if let Some(app_id) = app_id {
        params.push(format!("app_id={app_id}"));
    }
    if let Some(partition_key) = partition_key {
        params.push(format!("partition_key={partition_key}"));
    }
    if let Some(step_sequence_id) = step_sequence_id {
        params.push(format!("step_sequence_id={step_sequence_id}"));
    }
    if !params.is_empty() {
        uri.push('?');
        uri.push_str(&params.join("&"));
    }
    uri
}

pub(crate) fn annotation_create_uri(
    project_id: &str,
    app_id: &str,
    partition_key: &str,
    step_sequence_id: u64,
) -> String {
    format!("/api/v0/{project_id}/{app_id}/{partition_key}/{step_sequence_id}/annotations")
}

pub(crate) fn annotation_update_uri(project_id: &str, annotation_id: u64) -> String {
    format!("/api/v0/{project_id}/{annotation_id}/update_annotations")
}

pub(crate) fn default_annotation_path(root: &Path) -> PathBuf {
    root.join(DEFAULT_PROJECT_ID).join("annotations.jsonl")
}

pub(crate) fn seed_default_annotation_file(root: &Path, note: &str) -> PathBuf {
    let path = default_annotation_path(root);
    write_jsonl(
        &path,
        &[annotation_out_json(
            DEFAULT_ANNOTATION_ID,
            DEFAULT_PROJECT_ID,
            DEFAULT_APP_ID,
            Some(DEFAULT_PARTITION_KEY),
            DEFAULT_STEP_SEQUENCE_ID,
            note,
        )],
    );
    path
}

pub(crate) fn apps_uri(
    project_id: &str,
    partition_key: &str,
    limit: usize,
    offset: usize,
) -> String {
    format!("/api/v0/{project_id}/{partition_key}/apps?limit={limit}&offset={offset}")
}

pub(crate) fn app_detail_uri(project_id: &str, app_id: &str, partition_key: &str) -> String {
    format!("/api/v0/{project_id}/{app_id}/{partition_key}/apps")
}

pub(crate) async fn api_get(app: &Router, uri: &str) -> Response {
    app.clone()
        .oneshot(empty_request(uri))
        .await
        .expect("request should succeed")
}

pub(crate) async fn annotation_list_request(
    app: &Router,
    project_id: &str,
    app_id: Option<&str>,
    partition_key: Option<&str>,
    step_sequence_id: Option<u64>,
) -> Response {
    api_get(
        app,
        &annotations_uri(project_id, app_id, partition_key, step_sequence_id),
    )
    .await
}

pub(crate) async fn annotation_create_request(
    app: &Router,
    project_id: &str,
    app_id: &str,
    partition_key: &str,
    step_sequence_id: u64,
    body: &Value,
) -> Response {
    app.clone()
        .oneshot(json_request(
            "POST",
            &annotation_create_uri(project_id, app_id, partition_key, step_sequence_id),
            body,
        ))
        .await
        .expect("create annotation request should succeed")
}

pub(crate) async fn annotation_update_request(
    app: &Router,
    project_id: &str,
    annotation_id: u64,
    body: &Value,
) -> Response {
    app.clone()
        .oneshot(json_request(
            "PUT",
            &annotation_update_uri(project_id, annotation_id),
            body,
        ))
        .await
        .expect("update annotation request should succeed")
}

pub(crate) async fn annotation_request(
    app: &Router,
    kind: AnnotationRequestKind,
    project_id: &str,
    app_id: &str,
    partition_key: &str,
    step_sequence_id: u64,
    annotation_id: u64,
) -> Response {
    match kind {
        AnnotationRequestKind::List => {
            annotation_list_request(
                app,
                project_id,
                Some(app_id),
                Some(partition_key),
                Some(step_sequence_id),
            )
            .await
        }
        AnnotationRequestKind::Create => {
            annotation_create_request(
                app,
                project_id,
                app_id,
                partition_key,
                step_sequence_id,
                &pointerless_annotation_body("new", "created", Some(true)),
            )
            .await
        }
        AnnotationRequestKind::Update => {
            annotation_update_request(
                app,
                project_id,
                annotation_id,
                &pointerless_annotation_body("updated", "updated", Some(false)),
            )
            .await
        }
    }
}

pub(crate) async fn default_annotation_request(
    app: &Router,
    kind: AnnotationRequestKind,
) -> Response {
    annotation_request(
        app,
        kind,
        DEFAULT_PROJECT_ID,
        DEFAULT_APP_ID,
        DEFAULT_PARTITION_KEY,
        DEFAULT_STEP_SEQUENCE_ID,
        DEFAULT_ANNOTATION_ID,
    )
    .await
}

pub(crate) async fn projects_request(app: &Router) -> Response {
    api_get(app, "/api/v0/projects").await
}

pub(crate) async fn apps_request(
    app: &Router,
    project_id: &str,
    partition_key: &str,
    limit: usize,
    offset: usize,
) -> Response {
    api_get(app, &apps_uri(project_id, partition_key, limit, offset)).await
}

pub(crate) async fn app_detail_request(
    app: &Router,
    project_id: &str,
    app_id: &str,
    partition_key: &str,
) -> Response {
    api_get(app, &app_detail_uri(project_id, app_id, partition_key)).await
}

pub(crate) async fn tracking_endpoint_request(
    app: &Router,
    kind: TrackingEndpointKind,
    project_id: &str,
    app_id: &str,
    partition_key: &str,
) -> Response {
    match kind {
        TrackingEndpointKind::Projects => projects_request(app).await,
        TrackingEndpointKind::Apps => apps_request(app, project_id, partition_key, 10, 0).await,
        TrackingEndpointKind::AppDetail => {
            app_detail_request(app, project_id, app_id, partition_key).await
        }
    }
}

pub(crate) fn assert_json_error(payload: &Value) {
    assert!(
        payload
            .get("error")
            .and_then(Value::as_str)
            .is_some_and(|value| !value.is_empty()),
        "error responses should include a non-empty message"
    );
}

pub(crate) async fn assert_json_error_response(
    response: Response,
    expected_status: StatusCode,
    context: &str,
) -> Value {
    assert_eq!(response.status(), expected_status, "{context}");
    let payload = crate::support::response_json::response_json(response).await;
    assert_json_error(&payload);
    payload
}

pub(crate) async fn assert_json_error_response_without_spa_rewrite(
    response: Response,
    expected_status: StatusCode,
    context: &str,
) -> Value {
    assert_eq!(response.status(), expected_status, "{context}");
    let body = crate::support::response_text::response_text(response).await;
    assert!(
        !body.contains("<!doctype html"),
        "{context}: response must not be rewritten to SPA HTML: {body}"
    );
    let payload: Value = serde_json::from_str(&body).expect(context);
    assert_json_error(&payload);
    payload
}

pub(crate) async fn assert_bad_request_response(
    response: Response,
    leak_marker: Option<&str>,
    context: &str,
) {
    assert_eq!(response.status(), StatusCode::BAD_REQUEST, "{context}");
    if let Some(leak_marker) = leak_marker {
        let body = crate::support::response_text::response_text(response).await;
        assert!(
            !body.contains(leak_marker),
            "{context}: response must not expose outside data: {body}"
        );
    }
}

pub(crate) async fn assert_rejected_annotation_request(
    kind: AnnotationRequestKind,
    response: Response,
    outside_path: Option<&Path>,
    outside_marker: &str,
) {
    assert_eq!(response.status(), StatusCode::BAD_REQUEST);
    match kind {
        AnnotationRequestKind::List => {
            let body = crate::support::response_text::response_text(response).await;
            assert!(
                !body.contains(outside_marker),
                "annotation read response must not expose outside content: {body}"
            );
        }
        AnnotationRequestKind::Create | AnnotationRequestKind::Update => {
            let persisted = fs::read_to_string(
                outside_path.expect("write rejections should provide an outside file"),
            )
            .expect("outside annotation file should read");
            assert!(
                persisted.contains(outside_marker),
                "outside annotation file must stay unchanged after rejected request: {persisted}"
            );
            assert!(
                !persisted.contains(&format!(
                    r#""note":"{}""#,
                    annotation_request_note(kind)
                        .expect("write rejections should provide a mutation note"),
                )),
                "rejected request must not rewrite the outside annotation file: {persisted}"
            );
        }
    }
}
