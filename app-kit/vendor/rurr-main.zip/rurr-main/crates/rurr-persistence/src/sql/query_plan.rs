/// Pre-rendered SQL statements for a persisted-state table.
#[derive(Debug, Clone)]
pub struct PersistedStateQueries {
    insert_state: String,
    load_latest_partition: String,
    load_latest_app: String,
    load_sequence_app: String,
    list_app_ids: String,
}

impl PersistedStateQueries {
    /// Builds the async SQLite query set for `table_name`.
    pub fn sqlite_async(table_name: &str) -> Self {
        render_queries(table_name, QueryRenderPolicy::sqlite_async())
    }

    /// Builds the sync SQLite query set for `table_name`.
    pub fn sqlite_sync(table_name: &str) -> Self {
        render_queries(table_name, QueryRenderPolicy::sqlite_sync())
    }

    /// Builds the Postgres query set for `table_name`.
    pub fn postgres(table_name: &str) -> Self {
        render_queries(table_name, QueryRenderPolicy::postgres())
    }

    /// Returns the insert statement used by the save path.
    pub fn insert_state(&self) -> &str {
        &self.insert_state
    }

    /// Returns the query that loads the latest state for a partition.
    pub fn load_latest_partition(&self) -> &str {
        &self.load_latest_partition
    }

    /// Returns the query that loads the latest state for a specific app.
    pub fn load_latest_app(&self) -> &str {
        &self.load_latest_app
    }

    /// Returns the query that loads a specific app sequence.
    pub fn load_sequence_app(&self) -> &str {
        &self.load_sequence_app
    }

    /// Returns the query that lists application identifiers for a partition.
    pub fn list_app_ids(&self) -> &str {
        &self.list_app_ids
    }
}

#[derive(Debug, Clone, Copy)]
enum PlaceholderStyle {
    Anonymous,
    Indexed,
    Numbered,
}

#[derive(Debug, Clone, Copy)]
struct QueryRenderPolicy {
    placeholder_style: PlaceholderStyle,
    state_projection: &'static str,
    created_at_projection: &'static str,
    state_insert_cast: &'static str,
}

impl QueryRenderPolicy {
    const fn sqlite_async() -> Self {
        Self {
            placeholder_style: PlaceholderStyle::Anonymous,
            state_projection: "state",
            created_at_projection: "created_at",
            state_insert_cast: "",
        }
    }

    const fn sqlite_sync() -> Self {
        Self {
            placeholder_style: PlaceholderStyle::Indexed,
            state_projection: "state",
            created_at_projection: "created_at",
            state_insert_cast: "",
        }
    }

    const fn postgres() -> Self {
        Self {
            placeholder_style: PlaceholderStyle::Numbered,
            state_projection: "state::TEXT AS state",
            created_at_projection: "created_at::TEXT AS created_at",
            state_insert_cast: "::jsonb",
        }
    }
}

fn render_queries(table_name: &str, policy: QueryRenderPolicy) -> PersistedStateQueries {
    PersistedStateQueries {
        insert_state: render_insert_sql(table_name, policy),
        load_latest_partition: render_load_latest_partition_sql(table_name, policy),
        load_latest_app: render_load_latest_app_sql(table_name, policy),
        load_sequence_app: render_load_sequence_app_sql(table_name, policy),
        list_app_ids: render_list_app_ids_sql(table_name, policy),
    }
}

fn render_insert_sql(table_name: &str, policy: QueryRenderPolicy) -> String {
    format!(
        "INSERT INTO {table_name} (partition_key, app_id, sequence_id, position, state, status) \
         VALUES ({}, {}, {}, {}, {}{}, {})",
        placeholder(policy.placeholder_style, 1),
        placeholder(policy.placeholder_style, 2),
        placeholder(policy.placeholder_style, 3),
        placeholder(policy.placeholder_style, 4),
        placeholder(policy.placeholder_style, 5),
        policy.state_insert_cast,
        placeholder(policy.placeholder_style, 6),
    )
}

fn render_load_latest_partition_sql(table_name: &str, policy: QueryRenderPolicy) -> String {
    format!(
        "SELECT {} \
         FROM {table_name} \
         WHERE partition_key = {} \
         ORDER BY created_at DESC, sequence_id DESC, position DESC \
         LIMIT 1",
        select_columns(policy),
        placeholder(policy.placeholder_style, 1),
    )
}

fn render_load_latest_app_sql(table_name: &str, policy: QueryRenderPolicy) -> String {
    format!(
        "SELECT {} \
         FROM {table_name} \
         WHERE partition_key = {} AND app_id = {} \
         ORDER BY sequence_id DESC, created_at DESC, position DESC \
         LIMIT 1",
        select_columns(policy),
        placeholder(policy.placeholder_style, 1),
        placeholder(policy.placeholder_style, 2),
    )
}

fn render_load_sequence_app_sql(table_name: &str, policy: QueryRenderPolicy) -> String {
    format!(
        "SELECT {} \
         FROM {table_name} \
         WHERE partition_key = {} AND app_id = {} AND sequence_id = {} \
         ORDER BY created_at DESC, position DESC \
         LIMIT 1",
        select_columns(policy),
        placeholder(policy.placeholder_style, 1),
        placeholder(policy.placeholder_style, 2),
        placeholder(policy.placeholder_style, 3),
    )
}

fn render_list_app_ids_sql(table_name: &str, policy: QueryRenderPolicy) -> String {
    format!(
        "SELECT app_id \
         FROM {table_name} \
         WHERE partition_key = {} \
         GROUP BY app_id \
         ORDER BY MAX(created_at) DESC, app_id ASC",
        placeholder(policy.placeholder_style, 1),
    )
}

fn select_columns(policy: QueryRenderPolicy) -> String {
    format!(
        "partition_key, app_id, sequence_id, position, {}, {}, status",
        policy.state_projection, policy.created_at_projection
    )
}

fn placeholder(style: PlaceholderStyle, index: usize) -> String {
    match style {
        PlaceholderStyle::Anonymous => "?".to_string(),
        PlaceholderStyle::Indexed => format!("?{index}"),
        PlaceholderStyle::Numbered => format!("${index}"),
    }
}

#[cfg(test)]
mod tests {
    use super::PersistedStateQueries;

    #[test]
    fn sqlite_query_plan_pre_renders_async_sql() {
        let query_plan = PersistedStateQueries::sqlite_async("sqlite_state");

        assert!(query_plan
            .insert_state()
            .contains("VALUES (?, ?, ?, ?, ?, ?)"));
        assert!(query_plan.load_sequence_app().contains("sequence_id = ?"));
        assert!(query_plan
            .list_app_ids()
            .contains("ORDER BY MAX(created_at) DESC, app_id ASC"));
    }

    #[test]
    fn sqlite_sync_query_text_uses_indexed_placeholders() {
        let query_plan = PersistedStateQueries::sqlite_sync("sqlite_state");

        assert!(query_plan
            .insert_state()
            .contains("VALUES (?1, ?2, ?3, ?4, ?5, ?6)"));
        assert!(query_plan.load_sequence_app().contains("sequence_id = ?3"));
    }

    #[test]
    fn postgres_query_plan_pre_renders_async_sql() {
        let query_plan = PersistedStateQueries::postgres("postgres_state");

        assert!(query_plan.insert_state().contains("$5::jsonb"));
        assert!(query_plan
            .load_latest_partition()
            .contains("state::TEXT AS state"));
        assert!(query_plan
            .list_app_ids()
            .contains("ORDER BY MAX(created_at) DESC, app_id ASC"));
    }
}
