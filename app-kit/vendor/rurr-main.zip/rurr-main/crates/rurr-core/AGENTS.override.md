# crates/rurr-core/AGENTS.override.md — Core runtime rules (highest scrutiny)

This file applies only to `crates/rurr-core/` and adds stricter runtime rules on top of
repo-root `AGENTS.md` and `crates/AGENTS.override.md`.

## Scope and precedence
- Apply repo-root `AGENTS.md` first, then `crates/AGENTS.override.md`, then this file.
- Use `crates/rurr-core/ARCHITECTURE.md` as the living system map for this subtree.
- Treat `.codex/config.toml` as configuration only; it does not override these runtime guardrails.
- If any `AGENTS*.md` file changes, restart Codex before continuing in this subtree.

## Commands (run often)
- `cargo test -q -p rurr-core`
- `cargo test -q -p rurr-core --test contract <target>`
- Example: `cargo test -q -p rurr-core --test contract application_step_contract::`
- `cargo test -q -p rurr-core --test ui` (trybuild harness, when present)
- `cargo clippy -p rurr-core --all-targets --all-features -- -D warnings`

## Architectural invariants (do not violate)
Authoritative docs:
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- `docs/07_architecture_streaming_and_lifecycle.md` (implementation companion; defer to the docs above on conflicts)
- `docs/02_api_surface.md` (stable public surface)

Current implementation map:
- Internal execution now centers on `crates/rurr-core/src/application/build/`, `session.rs`, `streaming/`, and `step_txn.rs`.
- Supporting modules such as `parallelism/`, `tracking/`, and the typed application resources/state helpers remain part of the live runtime surface around that core.
- The old `application/app_model` layer has been flattened into `types.rs`, `resources.rs`, and `state_meta.rs`.

Hard rules:
- TRUE lazy streaming: never buffer action iterators/streams into Vec/collections for replay.
- Compile-time exclusivity: any streaming session must hold an exclusive borrow (`&mut Application`) or equivalent linear token.
- Transactional state: intermediate stream items do NOT commit `Application.state` and do NOT permanently increment `__SEQUENCE_ID`.
  Terminal completion commits atomically; early drop/error/panic rolls back with no leaked sequence ids.
- Lifecycle: split `SyncLifecycleAdapter` vs `AsyncLifecycleAdapter`. Sync post-hooks must be guaranteed via RAII guards.
  Async post-hooks only run on explicit completion/abort APIs (never in Drop).
- Drop behavior: synchronous rollback only. No tokio runtime flavor inspection, `block_on`, `block_in_place`, or temporary runtimes in Drop.
- Internal runtime paths must not use `rurr_core::common::async_utils::realize_stream`.

## Implementation constraints
- Prefer explicit lifetimes + borrowed session handles. Do not fight the borrow checker with `Rc<RefCell<_>>`.
- Avoid global state and avoid mutex-based “session locks”. The type system must enforce exclusivity.
- Do not use helper macros, proc-macro helpers, or macro helper crates as a way to reduce runtime,
  tracking, persistence, or test duplication. Refactor repeated behavior into session/config
  structs, enum-backed closed sets, methods, or real trait boundaries.
- **Never use `tokio::task::spawn_blocking` or `std::thread::spawn` in runtime execution/streaming paths.** Escaping the current thread forces `'static` bounds and destroys safe borrowing.
- Multi-step streaming may use ≤ 1 item of lookahead only (constant memory).

## Lending/Iterator pitfall (important)
Do NOT implement `Iterator<Item = StepStreamHandle<'_>>` where yielded items borrow from the iterator itself.
Instead, expose explicit step-advance APIs:
- `StreamIterate::next_step(&mut self) -> Result<Option<(ExecutedAction, StepStreamHandle<'_>)>, ...>`
- `StepStreamHandle::{next_item,get}` (and async variants)
  This keeps borrows correct and prevents unsafe designs.

## Testing rules (architecture is enforced by tests)
- Tests first; contracts must prove laziness:
    - side effects == 0 immediately after creating a stream/session
    - side effects advance exactly by 1 per `next()` / per poll
- Add drop rollback tests (drop mid-stream => state + sequence unchanged).
- Add panic rollback tests (panic mid-stream => state valid + sequence unchanged).
- Add trybuild compile-fail tests enforcing exclusivity (stream handle blocks app.step/run/etc).
- Ensure new test files are wired into the correct harness `mod.rs` (otherwise they won’t run).
- Do not let `rurr-core` local tests become the sole proof for provider/backend behavior or production fallback semantics when `docs/03_test_plan.md` names a stricter proof lane.
- If the honest runtime behavior is unsupported, unimplemented, or explicit configuration failure, encode that directly instead of inventing a fallback that local tests can satisfy.

## Remediation reopening execution
- Read `TASKS_PROGRESS.md` and `docs/refactors/burr-parity-remediation/README.md` before editing `rurr-core` for explicitly reopened remediation work.
- Only execute the reopened remediation phase. Do not mix surface-hook cleanup, fixture cleanup, oracle parity, and policy-closure work in one diff unless the reopened phase explicitly allows it.
- Update `TASKS_PROGRESS.md` as reopened loop stages complete so future sessions can resume without re-planning.
- Treat `docs/refactors/rurr-core-architecture-remediation/` as completed historical context, not as an open work queue.
- Treat the archived `docs/refactors/rurr-refactor/` phase cards as historical context only.
