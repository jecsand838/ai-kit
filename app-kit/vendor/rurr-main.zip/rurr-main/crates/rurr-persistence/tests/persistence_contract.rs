use indexmap::IndexMap;
use rurr_core::state::{register_field_serde, DefaultTypingSystem, State};
use rurr_persistence::{
    storage_layout_version, ApplicationPersistenceSpec, AsyncBaseStateLoader, AsyncBaseStateSaver,
    AsyncInMemoryPersister, BaseStateLoader, BaseStatePersister, BaseStateSaver, InMemoryPersister,
    PersistedStateStatus, PersistenceLane, StateInitializerSpec, StateLoaderRef, StatePersisterRef,
    StatePersisterSpec, STORAGE_LAYOUT_VERSION,
};
use serde_json::{json, Value};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;

static FIELD_SERDE_TEST_COUNTER: AtomicUsize = AtomicUsize::new(0);

fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
    pairs
        .into_iter()
        .map(|(key, value)| (key.to_string(), value))
        .collect()
}

fn unique_field_name() -> String {
    format!(
        "persistence_contract_field_{}",
        FIELD_SERDE_TEST_COUNTER.fetch_add(1, Ordering::Relaxed)
    )
}

#[test]
fn storage_layout_version_is_owned_by_layout_module() {
    assert_eq!(STORAGE_LAYOUT_VERSION, "v1");
    assert_eq!(storage_layout_version(), "v1");
}

#[test]
fn in_memory_latest_load_returns_newest_record_for_app() {
    let persister = InMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "first",
            map_from_pairs([("key", json!("v1"))]),
            PersistedStateStatus::Completed,
        )
        .expect("first save should succeed");
    persister
        .save(
            Some("partition_key"),
            "app_id",
            2,
            "second",
            map_from_pairs([("key", json!("v2"))]),
            PersistedStateStatus::Completed,
        )
        .expect("second save should succeed");

    let loaded = persister
        .load(Some("partition_key"), Some("app_id"), None)
        .expect("load should succeed")
        .expect("latest state should exist");

    assert_eq!(loaded.partition_key.as_deref(), Some("partition_key"));
    assert_eq!(loaded.app_id, "app_id");
    assert_eq!(loaded.sequence_id, 2);
    assert_eq!(loaded.position.as_deref(), Some("second"));
    assert_eq!(loaded.state, Some(map_from_pairs([("key", json!("v2"))])));
}

#[test]
fn in_memory_exact_sequence_load_returns_latest_matching_record() {
    let persister = InMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "first",
            map_from_pairs([("key", json!("v1"))]),
            PersistedStateStatus::Completed,
        )
        .expect("first save should succeed");
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "second",
            map_from_pairs([("key", json!("v2"))]),
            PersistedStateStatus::Completed,
        )
        .expect("second save should succeed");
    persister
        .save(
            Some("partition_key"),
            "app_id",
            2,
            "third",
            map_from_pairs([("key", json!("v3"))]),
            PersistedStateStatus::Completed,
        )
        .expect("third save should succeed");

    let loaded = persister
        .load(Some("partition_key"), Some("app_id"), Some(1))
        .expect("load should succeed")
        .expect("exact-sequence state should exist");

    assert_eq!(loaded.sequence_id, 1);
    assert_eq!(loaded.position.as_deref(), Some("second"));
    assert_eq!(loaded.state, Some(map_from_pairs([("key", json!("v2"))])));
}

#[test]
fn in_memory_list_app_ids_is_deterministic() {
    let persister = InMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id_1",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .expect("first save should succeed");
    persister
        .save(
            Some("partition_key"),
            "app_id_2",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .expect("second save should succeed");

    let app_ids = persister
        .list_app_ids(Some("partition_key"))
        .expect("list_app_ids should succeed");

    assert_eq!(
        app_ids,
        vec!["app_id_1".to_string(), "app_id_2".to_string()]
    );
}

#[test]
fn in_memory_methods_accept_none_partition_key() {
    let persister = InMemoryPersister::new();
    persister
        .save(
            None,
            "app_id",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .expect("save should succeed");

    let loaded = persister
        .load(None, Some("app_id"), None)
        .expect("load should succeed")
        .expect("state should exist");
    let app_ids = persister
        .list_app_ids(None)
        .expect("list_app_ids should succeed");

    assert_eq!(loaded.partition_key.as_deref(), Some(""));
    assert_eq!(app_ids, vec!["app_id".to_string()]);
}

#[test]
fn in_memory_initialize_and_cleanup_are_explicit_and_idempotent() {
    let persister = InMemoryPersister::new();

    assert!(persister
        .is_initialized()
        .expect("state should be readable"));
    persister
        .initialize()
        .expect("initialize should be idempotent");
    persister.cleanup().expect("cleanup should be a no-op");
    persister
        .cleanup()
        .expect("cleanup should remain idempotent");
    assert!(persister
        .is_initialized()
        .expect("state should stay readable"));
}

#[test]
fn in_memory_custom_field_serde_roundtrip_decodes_through_state_deserialize() {
    let field_name = unique_field_name();
    register_field_serde(
        field_name.clone(),
        |value| {
            let text = value.as_str().unwrap_or_default();
            json!({ "encoded": format!("serde::{text}") })
        },
        |value| {
            let encoded = value
                .get("encoded")
                .and_then(Value::as_str)
                .unwrap_or_default()
                .replace("serde::", "");
            Value::String(encoded)
        },
    )
    .expect("field serde registration should succeed");

    let mut raw_state = IndexMap::new();
    raw_state.insert(field_name.clone(), json!("payload"));
    let serialized_state = State::new(raw_state)
        .serialize()
        .expect("state serialize should succeed");

    let persister = InMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "position",
            serialized_state,
            PersistedStateStatus::Completed,
        )
        .expect("save should succeed");

    let loaded = persister
        .load(Some("partition_key"), Some("app_id"), None)
        .expect("load should succeed")
        .expect("loaded state should exist");
    let restored = State::deserialize(
        loaded.state.expect("serialized state should be present"),
        Arc::new(DefaultTypingSystem),
    )
    .expect("state deserialize should succeed");

    assert_eq!(restored.get(&field_name), Some(&json!("payload")));
}

#[test]
fn in_memory_load_with_sequence_id_and_no_app_id_returns_none() {
    let persister = InMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .expect("save should succeed");

    let loaded = persister
        .load(Some("partition_key"), None, Some(1))
        .expect("load should succeed");
    assert!(loaded.is_none());
}

#[tokio::test]
async fn async_in_memory_latest_load_returns_newest_record_for_app() {
    let persister = AsyncInMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "first",
            map_from_pairs([("key", json!("v1"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("first save should succeed");
    persister
        .save(
            Some("partition_key"),
            "app_id",
            2,
            "second",
            map_from_pairs([("key", json!("v2"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("second save should succeed");

    let loaded = persister
        .load(Some("partition_key"), Some("app_id"), None)
        .await
        .expect("load should succeed")
        .expect("latest state should exist");

    assert_eq!(loaded.sequence_id, 2);
    assert_eq!(loaded.position.as_deref(), Some("second"));
    assert_eq!(loaded.state, Some(map_from_pairs([("key", json!("v2"))])));
}

#[tokio::test]
async fn async_in_memory_exact_sequence_load_returns_latest_matching_record() {
    let persister = AsyncInMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "first",
            map_from_pairs([("key", json!("v1"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("first save should succeed");
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "second",
            map_from_pairs([("key", json!("v2"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("second save should succeed");

    let loaded = persister
        .load(Some("partition_key"), Some("app_id"), Some(1))
        .await
        .expect("load should succeed")
        .expect("exact-sequence state should exist");

    assert_eq!(loaded.sequence_id, 1);
    assert_eq!(loaded.position.as_deref(), Some("second"));
}

#[tokio::test]
async fn async_in_memory_list_app_ids_is_deterministic() {
    let persister = AsyncInMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id_1",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("first save should succeed");
    persister
        .save(
            Some("partition_key"),
            "app_id_2",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("second save should succeed");

    let app_ids = persister
        .list_app_ids(Some("partition_key"))
        .await
        .expect("list_app_ids should succeed");

    assert_eq!(
        app_ids,
        vec!["app_id_1".to_string(), "app_id_2".to_string()]
    );
}

#[tokio::test]
async fn async_in_memory_methods_accept_none_partition_key() {
    let persister = AsyncInMemoryPersister::new();
    persister
        .save(
            None,
            "app_id",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("save should succeed");

    let loaded = persister
        .load(None, Some("app_id"), None)
        .await
        .expect("load should succeed")
        .expect("state should exist");
    let app_ids = persister
        .list_app_ids(None)
        .await
        .expect("list_app_ids should succeed");

    assert_eq!(loaded.partition_key.as_deref(), Some(""));
    assert_eq!(app_ids, vec!["app_id".to_string()]);
}

#[tokio::test]
async fn async_in_memory_initialize_and_cleanup_are_explicit_and_idempotent() {
    let persister = AsyncInMemoryPersister::new();

    assert!(persister
        .is_initialized()
        .await
        .expect("state should be readable"));
    persister
        .initialize()
        .await
        .expect("initialize should be idempotent");
    persister
        .cleanup()
        .await
        .expect("cleanup should be a no-op");
    persister
        .cleanup()
        .await
        .expect("cleanup should remain idempotent");
    assert!(persister
        .is_initialized()
        .await
        .expect("state should stay readable"));
}

#[tokio::test]
async fn async_in_memory_load_with_sequence_id_and_no_app_id_returns_none() {
    let persister = AsyncInMemoryPersister::new();
    persister
        .save(
            Some("partition_key"),
            "app_id",
            1,
            "position",
            map_from_pairs([("key", json!("value"))]),
            PersistedStateStatus::Completed,
        )
        .await
        .expect("save should succeed");

    let loaded = persister
        .load(Some("partition_key"), None, Some(1))
        .await
        .expect("load should succeed");
    assert!(loaded.is_none());
}

#[test]
fn loader_wrappers_report_capability_and_lane() {
    let sync_ref = StateLoaderRef::sync(Arc::new(InMemoryPersister::new()));
    let async_ref = StateLoaderRef::async_loader(Arc::new(AsyncInMemoryPersister::new()));

    assert!(!sync_ref.is_async());
    assert_eq!(sync_ref.lane(), PersistenceLane::Sync);
    assert!(sync_ref.as_sync().is_some());
    assert!(async_ref.is_async());
    assert_eq!(async_ref.lane(), PersistenceLane::Async);
    assert!(async_ref.as_sync().is_none());
}

#[test]
fn loader_wrapper_accepts_sync_persister_trait_object_arc() {
    let persister: Arc<dyn BaseStatePersister> = Arc::new(InMemoryPersister::new());
    let loader_ref = StateLoaderRef::from(Arc::clone(&persister));
    let sync_loader = loader_ref
        .as_sync()
        .expect("sync persister should convert into sync loader ref");

    let loaded = sync_loader
        .load(Some("partition_key"), Some("app_id"), None)
        .expect("load should succeed");
    assert!(loaded.is_none());
}

#[test]
fn persister_wrappers_report_capability_and_lane() {
    let sync_ref = StatePersisterRef::sync(Arc::new(InMemoryPersister::new()));
    let async_ref = StatePersisterRef::async_persister(Arc::new(AsyncInMemoryPersister::new()));

    assert!(!sync_ref.is_async());
    assert_eq!(sync_ref.lane(), PersistenceLane::Sync);
    assert!(sync_ref.as_sync().is_some());
    assert!(async_ref.is_async());
    assert_eq!(async_ref.lane(), PersistenceLane::Async);
    assert!(async_ref.as_sync().is_none());
}

#[test]
fn application_persistence_spec_reports_lane_compatibility() {
    let sync_spec = ApplicationPersistenceSpec::new()
        .with_initializer(StateInitializerSpec::sync(
            Arc::new(InMemoryPersister::new()),
            true,
            IndexMap::new(),
            "noop",
            None,
        ))
        .with_persister(StatePersisterSpec::sync(Arc::new(InMemoryPersister::new())));
    assert!(sync_spec.supports_lane(PersistenceLane::Sync));
    assert!(!sync_spec.supports_lane(PersistenceLane::Async));

    let async_spec = ApplicationPersistenceSpec::new()
        .with_initializer(StateInitializerSpec::async_initializer(
            Arc::new(AsyncInMemoryPersister::new()),
            true,
            IndexMap::new(),
            "noop",
            None,
        ))
        .with_persister(StatePersisterSpec::async_persister(Arc::new(
            AsyncInMemoryPersister::new(),
        )));
    assert!(async_spec.supports_lane(PersistenceLane::Async));
    assert!(!async_spec.supports_lane(PersistenceLane::Sync));
}
