use crate::state::State;
use indexmap::IndexMap;
use serde_json::Value;
use std::sync::Arc;

pub(super) fn make_mut_values(state: &mut State) -> &mut IndexMap<String, Value> {
    Arc::make_mut(&mut state.values)
}
