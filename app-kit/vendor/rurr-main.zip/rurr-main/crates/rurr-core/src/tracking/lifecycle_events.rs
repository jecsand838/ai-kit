//! Shared tracking lifecycle event model builders.

use super::{
    AttributeModel, BeginEntryModel, BeginSpanModel, EndEntryModel, EndSpanModel, EndStreamModel,
    FirstItemStreamModel, InitializeStreamModel,
};
use crate::application::context::ParentPointer;
use crate::graph::Graph;
use crate::lifecycle::{
    AsyncLifecycleAdapter, LifecycleError, PostStepContext, PreStepContext, SpanContext,
    StreamContext, StreamItemContext, SyncLifecycleAdapter,
};
use crate::tracking::stream_state;
use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_persistence::wire::sortable_rfc3339_utc_string;
use serde_json::Value;
use std::fmt;
use std::future::Future;
use std::pin::Pin;
use std::sync::{Mutex, MutexGuard};
use std::time::SystemTime;

pub(crate) trait TrackingLifecycleSink {
    fn write_lifecycle_event(
        &self,
        app_id: Option<&str>,
        event: &Value,
        operation: &'static str,
    ) -> Result<String, LifecycleError>;
}

#[async_trait]
pub(crate) trait AsyncTrackingLifecycleSink {
    async fn write_lifecycle_event_async(
        &self,
        app_id: Option<&str>,
        event: &Value,
        operation: &'static str,
    ) -> Result<String, LifecycleError>;
}

pub(crate) trait TrackingLifecycleAdapter:
    TrackingLifecycleSink + AsyncTrackingLifecycleSink + Send + Sync
{
    fn tracking_log(&self) -> &TrackingLifecycleLog;

    fn register_tracking_application(
        &self,
        registration: TrackingRegistration<'_>,
    ) -> Result<(), LifecycleError>;

    fn register_tracking_application_async<'a>(
        &'a self,
        registration: TrackingRegistration<'a>,
    ) -> Pin<Box<dyn Future<Output = Result<(), LifecycleError>> + Send + 'a>> {
        Box::pin(async move { self.register_tracking_application(registration) })
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum ChildRelationshipMode {
    Record,
    ApplicationOnly,
    RelationshipOnly,
}

#[derive(Clone, Copy)]
pub(crate) struct TrackingRegistration<'a> {
    pub(crate) operation: &'static str,
    pub(crate) app_id: &'a str,
    pub(crate) partition_key: Option<&'a str>,
    pub(crate) graph: &'a Graph,
    pub(crate) parent_pointer: Option<&'a ParentPointer>,
    pub(crate) spawning_parent_pointer: Option<&'a ParentPointer>,
    pub(crate) child_relationships: ChildRelationshipMode,
}

impl<T> SyncLifecycleAdapter for T
where
    T: TrackingLifecycleAdapter + 'static,
{
    fn register_application(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_tracking_application(TrackingRegistration {
            operation: "register_application",
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships: ChildRelationshipMode::Record,
        })
    }

    fn register_child_application(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_tracking_application(TrackingRegistration {
            operation: "register_child_application",
            app_id: child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships: ChildRelationshipMode::Record,
        })
    }

    fn register_child_application_artifacts(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_tracking_application(TrackingRegistration {
            operation: "register_child_application",
            app_id: child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships: ChildRelationshipMode::ApplicationOnly,
        })
    }

    fn register_child_application_relationship(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_tracking_application(TrackingRegistration {
            operation: "register_child_application",
            app_id: child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships: ChildRelationshipMode::RelationshipOnly,
        })
    }

    fn pre_run_step(&self, context: &PreStepContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_sync_event(self, TrackingHookEvent::PreRunStep(context))
    }

    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_sync_event(self, TrackingHookEvent::PostRunStep(context))
    }

    fn pre_start_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_sync_event(self, TrackingHookEvent::PreStartSpan(context))
    }

    fn post_end_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_sync_event(self, TrackingHookEvent::PostEndSpan(context))
    }

    fn log_attributes(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        self.tracking_log().run_sync_event(
            self,
            TrackingHookEvent::LogAttributes {
                context,
                attributes,
            },
        )
    }

    fn pre_start_stream(&self, context: &StreamContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_sync_event(self, TrackingHookEvent::PreStartStream(context))
    }

    fn post_stream_item(&self, context: &StreamItemContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_sync_event(self, TrackingHookEvent::PostStreamItem(context))
    }

    fn post_end_stream(&self, context: &StreamContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_sync_event(self, TrackingHookEvent::PostEndStream(context))
    }
}

#[async_trait]
impl<T> AsyncLifecycleAdapter for T
where
    T: TrackingLifecycleAdapter + 'static,
{
    async fn register_application(
        &self,
        app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_tracking_application_async(TrackingRegistration {
            operation: "register_application",
            app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships: ChildRelationshipMode::Record,
        })
        .await
    }

    async fn register_child_application(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_tracking_application_async(TrackingRegistration {
            operation: "register_child_application",
            app_id: child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships: ChildRelationshipMode::Record,
        })
        .await
    }

    async fn register_child_application_artifacts(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_tracking_application_async(TrackingRegistration {
            operation: "register_child_application",
            app_id: child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships: ChildRelationshipMode::ApplicationOnly,
        })
        .await
    }

    async fn register_child_application_relationship(
        &self,
        child_app_id: &str,
        partition_key: Option<&str>,
        graph: &Graph,
        parent_pointer: Option<&ParentPointer>,
        spawning_parent_pointer: Option<&ParentPointer>,
    ) -> Result<(), LifecycleError> {
        self.register_tracking_application_async(TrackingRegistration {
            operation: "register_child_application",
            app_id: child_app_id,
            partition_key,
            graph,
            parent_pointer,
            spawning_parent_pointer,
            child_relationships: ChildRelationshipMode::RelationshipOnly,
        })
        .await
    }

    async fn pre_run_step(&self, context: &PreStepContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_async_event(self, TrackingHookEvent::PreRunStep(context))
            .await
    }

    async fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_async_event(self, TrackingHookEvent::PostRunStep(context))
            .await
    }

    async fn pre_start_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_async_event(self, TrackingHookEvent::PreStartSpan(context))
            .await
    }

    async fn post_end_span(&self, context: &SpanContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_async_event(self, TrackingHookEvent::PostEndSpan(context))
            .await
    }

    async fn log_attributes(
        &self,
        context: &SpanContext,
        attributes: &IndexMap<String, Value>,
    ) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_async_event(
                self,
                TrackingHookEvent::LogAttributes {
                    context,
                    attributes,
                },
            )
            .await
    }

    async fn pre_start_stream(&self, context: &StreamContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_async_event(self, TrackingHookEvent::PreStartStream(context))
            .await
    }

    async fn post_stream_item(&self, context: &StreamItemContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_async_event(self, TrackingHookEvent::PostStreamItem(context))
            .await
    }

    async fn post_end_stream(&self, context: &StreamContext) -> Result<(), LifecycleError> {
        self.tracking_log()
            .run_async_event(self, TrackingHookEvent::PostEndStream(context))
            .await
    }
}

#[derive(Debug, Default)]
pub(crate) struct TrackingLifecycleLog {
    stream_state: Mutex<IndexMap<TrackingStreamKey, usize>>,
}

#[derive(Clone, Copy)]
enum TrackingHookEvent<'a> {
    PreRunStep(&'a PreStepContext),
    PostRunStep(&'a PostStepContext),
    PreStartSpan(&'a SpanContext),
    PostEndSpan(&'a SpanContext),
    LogAttributes {
        context: &'a SpanContext,
        attributes: &'a IndexMap<String, Value>,
    },
    PreStartStream(&'a StreamContext),
    PostStreamItem(&'a StreamItemContext),
    PostEndStream(&'a StreamContext),
}

impl<'a> TrackingHookEvent<'a> {
    fn prepare(
        self,
        log: &TrackingLifecycleLog,
    ) -> Result<Vec<PreparedTrackingEvent>, LifecycleError> {
        match self {
            Self::PreRunStep(context) => prepared_events([PreparedTrackingEvent::new(
                context.app_id(),
                "pre_run_step",
                begin_entry(context)?,
            )]),
            Self::PostRunStep(context) => prepared_events([PreparedTrackingEvent::new(
                context.app_id(),
                "post_run_step",
                end_entry(context, "post_run_step")?,
            )]),
            Self::PreStartSpan(context) => prepared_events([PreparedTrackingEvent::new(
                context.app_id(),
                "pre_start_span",
                begin_span(context)?,
            )]),
            Self::PostEndSpan(context) => prepared_events([PreparedTrackingEvent::new(
                context.app_id(),
                "post_end_span",
                end_span(context)?,
            )]),
            Self::LogAttributes {
                context,
                attributes,
            } => attributes
                .iter()
                .map(|(key, value)| {
                    PreparedTrackingEvent::new(
                        context.app_id(),
                        "log_attributes",
                        attribute(context, key.clone(), value.clone())?,
                    )
                })
                .collect(),
            Self::PreStartStream(context) => prepared_events([PreparedTrackingEvent::new(
                context.app_id(),
                "pre_start_stream",
                initialize_stream(context)?,
            )]),
            Self::PostStreamItem(context) => {
                let app_id = required_app_id(context.app_id(), "post_stream_item")?;
                if log.record_stream_item(context, app_id.clone(), "post_stream_item")? {
                    prepared_events([PreparedTrackingEvent::new(
                        Some(&app_id),
                        "post_stream_item",
                        first_stream_item(context)?,
                    )])
                } else {
                    Ok(Vec::new())
                }
            }
            Self::PostEndStream(context) => {
                let app_id = required_app_id(context.app_id(), "post_end_stream")?;
                let items_streamed =
                    log.finish_stream(context, app_id.clone(), "post_end_stream")?;
                prepared_events([PreparedTrackingEvent::new(
                    Some(&app_id),
                    "post_end_stream",
                    end_stream(context, items_streamed)?,
                )])
            }
        }
    }

    fn pre_start_stream_context(self) -> Option<&'a StreamContext> {
        match self {
            Self::PreStartStream(context) => Some(context),
            _ => None,
        }
    }
}

struct PreparedTrackingEvent {
    app_id: Option<String>,
    operation: &'static str,
    value: Value,
}

impl PreparedTrackingEvent {
    fn new<T: serde::Serialize>(
        app_id: Option<&str>,
        operation: &'static str,
        model: T,
    ) -> Result<Self, LifecycleError> {
        Ok(Self {
            app_id: app_id.map(str::to_string),
            operation,
            value: serde_json::to_value(model)
                .map_err(|error| LifecycleError::hook_failed(operation, error.to_string()))?,
        })
    }

    fn write_sync<S>(&self, sink: &S) -> Result<String, LifecycleError>
    where
        S: TrackingLifecycleSink,
    {
        sink.write_lifecycle_event(self.app_id.as_deref(), &self.value, self.operation)
    }

    async fn write_async<S>(&self, sink: &S) -> Result<String, LifecycleError>
    where
        S: AsyncTrackingLifecycleSink + Sync,
    {
        sink.write_lifecycle_event_async(self.app_id.as_deref(), &self.value, self.operation)
            .await
    }
}

fn prepared_events<const N: usize>(
    events: [Result<PreparedTrackingEvent, LifecycleError>; N],
) -> Result<Vec<PreparedTrackingEvent>, LifecycleError> {
    events.into_iter().collect()
}

impl TrackingLifecycleLog {
    pub(crate) fn new() -> Self {
        Self::default()
    }

    fn run_sync_event<S>(
        &self,
        sink: &S,
        event: TrackingHookEvent<'_>,
    ) -> Result<(), LifecycleError>
    where
        S: TrackingLifecycleSink,
    {
        let stream_context = event.pre_start_stream_context();
        let mut stream_app_id = None;
        for prepared in event.prepare(self)? {
            let app_id = prepared.write_sync(sink)?;
            if stream_context.is_some() {
                stream_app_id = Some(app_id);
            }
        }
        self.finish_pre_start_stream(stream_context, stream_app_id)
    }

    async fn run_async_event<S>(
        &self,
        sink: &S,
        event: TrackingHookEvent<'_>,
    ) -> Result<(), LifecycleError>
    where
        S: AsyncTrackingLifecycleSink + Sync,
    {
        let stream_context = event.pre_start_stream_context();
        let mut stream_app_id = None;
        for prepared in event.prepare(self)? {
            let app_id = prepared.write_async(sink).await?;
            if stream_context.is_some() {
                stream_app_id = Some(app_id);
            }
        }
        self.finish_pre_start_stream(stream_context, stream_app_id)
    }

    fn finish_pre_start_stream(
        &self,
        stream_context: Option<&StreamContext>,
        stream_app_id: Option<String>,
    ) -> Result<(), LifecycleError> {
        if let Some(context) = stream_context {
            let app_id = stream_app_id.ok_or_else(|| {
                LifecycleError::hook_failed("pre_start_stream", "stream start skipped")
            })?;
            self.insert_stream(context, app_id, "pre_start_stream")?;
        }
        Ok(())
    }

    fn insert_stream(
        &self,
        context: &StreamContext,
        app_id: String,
        operation: &'static str,
    ) -> Result<(), LifecycleError> {
        self.lock_stream_state(operation)?
            .insert(TrackingStreamKey::from_stream(context, app_id), 0);
        Ok(())
    }

    fn record_stream_item(
        &self,
        context: &StreamItemContext,
        app_id: String,
        operation: &'static str,
    ) -> Result<bool, LifecycleError> {
        let key = TrackingStreamKey::from_stream_item(context, app_id);
        let mut state = self.lock_stream_state(operation)?;
        stream_state::record_stream_item(&mut state, &key, operation)
    }

    fn finish_stream(
        &self,
        context: &StreamContext,
        app_id: String,
        operation: &'static str,
    ) -> Result<usize, LifecycleError> {
        let key = TrackingStreamKey::from_stream(context, app_id);
        let mut state = self.lock_stream_state(operation)?;
        stream_state::finish_stream(&mut state, &key, operation)
    }

    fn lock_stream_state(
        &self,
        operation: &'static str,
    ) -> Result<MutexGuard<'_, IndexMap<TrackingStreamKey, usize>>, LifecycleError> {
        self.stream_state.lock().map_err(|_| {
            LifecycleError::hook_failed(operation, "tracking stream state lock poisoned")
        })
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
struct TrackingStreamKey {
    app_id: String,
    action_name: String,
    sequence_id: u64,
    stream_id: u64,
}

impl TrackingStreamKey {
    fn from_stream(context: &StreamContext, app_id: String) -> Self {
        Self {
            app_id,
            action_name: context.action_name().to_string(),
            sequence_id: context.sequence_id(),
            stream_id: context.stream_id(),
        }
    }

    fn from_stream_item(context: &StreamItemContext, app_id: String) -> Self {
        Self {
            app_id,
            action_name: context.action_name().to_string(),
            sequence_id: context.sequence_id(),
            stream_id: context.stream_id(),
        }
    }
}

impl fmt::Display for TrackingStreamKey {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "app_id={}, action={}, sequence_id={}, stream_id={}",
            self.app_id, self.action_name, self.sequence_id, self.stream_id
        )
    }
}
pub(crate) fn tracking_timestamp(
    timestamp: SystemTime,
    operation: &'static str,
) -> Result<String, LifecycleError> {
    sortable_rfc3339_utc_string(timestamp)
        .map_err(|error| LifecycleError::hook_failed(operation, error.to_string()))
}

pub(crate) fn now_tracking_timestamp(operation: &'static str) -> Result<String, LifecycleError> {
    tracking_timestamp(SystemTime::now(), operation)
}

pub(crate) fn begin_entry(context: &PreStepContext) -> Result<BeginEntryModel, LifecycleError> {
    Ok(BeginEntryModel {
        r#type: "begin_entry".to_string(),
        start_time: tracking_timestamp(context.started_at(), "pre_run_step")?,
        action: context.action_name().to_string(),
        inputs: begin_entry_inputs(context),
        sequence_id: context.sequence_id(),
    })
}

pub(crate) fn end_entry(
    context: &PostStepContext,
    operation: &'static str,
) -> Result<EndEntryModel, LifecycleError> {
    let state = context
        .require_state_for(operation, "tracking end_entry")?
        .serialize()
        .map_err(|error| LifecycleError::hook_failed(operation, error.to_string()))?;
    Ok(EndEntryModel {
        r#type: "end_entry".to_string(),
        end_time: now_tracking_timestamp(operation)?,
        action: context.action_name().to_string(),
        result: context.result().cloned(),
        exception: context.exception().map(str::to_owned),
        state,
        sequence_id: context.sequence_id(),
    })
}

pub(crate) fn begin_span(context: &SpanContext) -> Result<BeginSpanModel, LifecycleError> {
    Ok(BeginSpanModel {
        r#type: "begin_span".to_string(),
        start_time: now_tracking_timestamp("pre_start_span")?,
        action_sequence_id: context.sequence_id(),
        span_id: context.span_id().to_string(),
        span_name: context.span_name().unwrap_or(context.span_id()).to_string(),
        parent_span_id: context.parent_span_id().map(ToString::to_string),
        span_dependencies: context.span_dependencies().to_vec(),
    })
}

pub(crate) fn end_span(context: &SpanContext) -> Result<EndSpanModel, LifecycleError> {
    Ok(EndSpanModel {
        r#type: "end_span".to_string(),
        end_time: now_tracking_timestamp("post_end_span")?,
        action_sequence_id: context.sequence_id(),
        span_id: context.span_id().to_string(),
    })
}

pub(crate) fn attribute(
    context: &SpanContext,
    key: String,
    value: Value,
) -> Result<AttributeModel, LifecycleError> {
    Ok(AttributeModel {
        r#type: "attribute".to_string(),
        key,
        action_sequence_id: context.sequence_id(),
        span_id: Some(context.span_id().to_string()),
        value,
        tags: IndexMap::new(),
        time_logged: Some(now_tracking_timestamp("log_attributes")?),
    })
}

pub(crate) fn initialize_stream(
    context: &StreamContext,
) -> Result<InitializeStreamModel, LifecycleError> {
    Ok(InitializeStreamModel {
        r#type: "begin_stream".to_string(),
        action_sequence_id: context.sequence_id(),
        span_id: None,
        stream_init_time: now_tracking_timestamp("pre_start_stream")?,
    })
}

pub(crate) fn first_stream_item(
    context: &StreamItemContext,
) -> Result<FirstItemStreamModel, LifecycleError> {
    Ok(FirstItemStreamModel {
        r#type: "first_item_stream".to_string(),
        action_sequence_id: context.sequence_id(),
        span_id: None,
        first_item_time: now_tracking_timestamp("post_stream_item")?,
    })
}

pub(crate) fn end_stream(
    context: &StreamContext,
    items_streamed: usize,
) -> Result<EndStreamModel, LifecycleError> {
    Ok(EndStreamModel {
        r#type: "end_stream".to_string(),
        action_sequence_id: context.sequence_id(),
        span_id: None,
        end_time: now_tracking_timestamp("post_end_stream")?,
        items_streamed,
    })
}

fn begin_entry_inputs(context: &PreStepContext) -> IndexMap<String, Value> {
    context.inputs().cloned().unwrap_or_default()
}

fn required_app_id(
    app_id: Option<&str>,
    operation: &'static str,
) -> Result<String, LifecycleError> {
    app_id
        .map(str::to_string)
        .ok_or_else(|| LifecycleError::hook_failed(operation, "missing app id for tracking"))
}
