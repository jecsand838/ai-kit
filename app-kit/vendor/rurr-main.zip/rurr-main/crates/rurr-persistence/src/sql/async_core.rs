use super::core_plan::{
    ensure_initialized_result, list_app_ids_operation, LoadOperation, SqlInitializationPlan,
    SqlSavePlan,
};
use crate::{
    async_ops, InitializationHint, PersistedStateData, PersistedStateQueries,
    PersistedStateSaveRequest, PersistenceError, SqlDialect,
};
use sqlx::{ColumnIndex, Decode, Encode, Executor, FromRow, IntoArguments, Pool, Type};
use std::sync::atomic::{AtomicBool, Ordering};

/// Shared async backend core built directly on top of the SQLx helpers.
pub struct AsyncSqlxPersistenceCore<'a, D: SqlDialect> {
    pool: &'a Pool<D::Database>,
    queries: &'a PersistedStateQueries,
    table_name: &'a str,
    migration_sql: &'a str,
    initialization_hint: &'a InitializationHint,
    closed: &'a AtomicBool,
    connection_closed_error: fn() -> PersistenceError,
}

impl<'a, D: SqlDialect> AsyncSqlxPersistenceCore<'a, D> {
    /// Creates a new shared async persistence core.
    pub fn new(
        pool: &'a Pool<D::Database>,
        queries: &'a PersistedStateQueries,
        table_name: &'a str,
        migration_sql: &'a str,
        initialization_hint: &'a InitializationHint,
        closed: &'a AtomicBool,
        connection_closed_error: fn() -> PersistenceError,
    ) -> Self {
        Self {
            pool,
            queries,
            table_name,
            migration_sql,
            initialization_hint,
            closed,
            connection_closed_error,
        }
    }

    /// Closes the backing pool and clears the initialization hint.
    pub async fn shutdown(&self) -> Result<(), PersistenceError> {
        if self.closed.swap(true, Ordering::AcqRel) {
            return Ok(());
        }
        self.pool.close().await;
        self.initialization_hint.clear();
        Ok(())
    }

    /// Initializes the backing table if needed.
    pub async fn initialize<F>(&self, map_error: F) -> Result<(), PersistenceError>
    where
        F: Fn(sqlx::Error) -> PersistenceError + Copy,
        for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
    {
        self.ensure_open()?;
        let plan = SqlInitializationPlan::new(self.table_name, self.migration_sql);
        async_ops::execute_sqlx_statements::<D, _>(self.pool, plan.migration_sql, map_error)
            .await
            .map_err(|error| self.initialization_hint.track_error(error))?;
        self.initialization_hint.set(true);
        Ok(())
    }

    /// Checks whether the backing table exists.
    pub async fn is_initialized<F>(&self, map_error: F) -> Result<bool, PersistenceError>
    where
        F: Fn(sqlx::Error) -> PersistenceError + Copy,
        for<'r> bool: Decode<'r, D::Database> + Type<D::Database>,
        usize: ColumnIndex<<D::Database as sqlx::Database>::Row>,
        for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
        for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
        for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
    {
        self.ensure_open()?;
        let plan = SqlInitializationPlan::new(self.table_name, self.migration_sql);
        let exists = async_ops::is_initialized::<D, _>(self.pool, plan.table_name, map_error)
            .await
            .map_err(|error| self.initialization_hint.track_error(error))?;
        self.initialization_hint.set(exists);
        Ok(exists)
    }

    /// Saves a new persisted-state record.
    pub async fn save<F>(
        &self,
        request: PersistedStateSaveRequest<'_>,
        map_error: F,
        serialization_failure_operation: &'static str,
    ) -> Result<(), PersistenceError>
    where
        F: Fn(sqlx::Error) -> PersistenceError + Copy,
        for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
        for<'q> i64: Encode<'q, D::Database> + Type<D::Database>,
        for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
        for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
        for<'r> bool: Decode<'r, D::Database> + Type<D::Database>,
        usize: ColumnIndex<<D::Database as sqlx::Database>::Row>,
    {
        self.ensure_initialized(map_error).await?;
        let plan = SqlSavePlan::new(self.queries, request, serialization_failure_operation)?;
        async_ops::save::<D, _>(self.pool, &plan, map_error)
            .await
            .map_err(|error| self.initialization_hint.track_error(error))
    }

    /// Loads a persisted-state record.
    pub async fn load<F>(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
        map_error: F,
    ) -> Result<Option<PersistedStateData>, PersistenceError>
    where
        F: Fn(sqlx::Error) -> PersistenceError + Copy,
        for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
        for<'q> i64: Encode<'q, D::Database> + Type<D::Database>,
        for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
        for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
        for<'r> crate::sql::row_models::PersistedStateRow:
            FromRow<'r, <D::Database as sqlx::Database>::Row>,
        for<'r> bool: Decode<'r, D::Database> + Type<D::Database>,
        usize: ColumnIndex<<D::Database as sqlx::Database>::Row>,
    {
        self.ensure_initialized(map_error).await?;
        let operation = LoadOperation::new(self.queries, partition_key, app_id, sequence_id)?;
        async_ops::load_operation::<D, _>(self.pool, operation, map_error)
            .await
            .map_err(|error| self.initialization_hint.track_error(error))
    }

    /// Lists application identifiers for a partition.
    pub async fn list_app_ids<F>(
        &self,
        partition_key: Option<&str>,
        map_error: F,
    ) -> Result<Vec<String>, PersistenceError>
    where
        F: Fn(sqlx::Error) -> PersistenceError + Copy,
        for<'r> String: Decode<'r, D::Database> + Type<D::Database>,
        usize: ColumnIndex<<D::Database as sqlx::Database>::Row>,
        for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
        for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
        for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
        for<'r> bool: Decode<'r, D::Database> + Type<D::Database>,
    {
        self.ensure_initialized(map_error).await?;
        let plan = list_app_ids_operation(self.queries, partition_key);
        async_ops::list_app_ids_operation::<D, _>(self.pool, &plan, map_error)
            .await
            .map_err(|error| self.initialization_hint.track_error(error))
    }

    fn ensure_open(&self) -> Result<(), PersistenceError> {
        if self.closed.load(Ordering::Acquire) {
            Err((self.connection_closed_error)())
        } else {
            Ok(())
        }
    }

    async fn ensure_initialized<F>(&self, map_error: F) -> Result<(), PersistenceError>
    where
        F: Fn(sqlx::Error) -> PersistenceError + Copy,
        for<'r> bool: Decode<'r, D::Database> + Type<D::Database>,
        usize: ColumnIndex<<D::Database as sqlx::Database>::Row>,
        for<'q> &'q str: Encode<'q, D::Database> + Type<D::Database>,
        for<'q> <D::Database as sqlx::Database>::Arguments<'q>: IntoArguments<'q, D::Database>,
        for<'q> &'q Pool<D::Database>: Executor<'q, Database = D::Database>,
    {
        self.ensure_open()?;
        if self.initialization_hint.is_set() {
            return Ok(());
        }

        ensure_initialized_result(
            self.initialization_hint,
            self.is_initialized(map_error).await?,
        )
    }
}
