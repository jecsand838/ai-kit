use crate::graph::{Graph, GraphAction, GraphRegistrationView, Transition};
use std::io;
use std::path::Path;

/// Read-only application graph view exposed from [`crate::Application`].
#[derive(Debug, Clone)]
pub struct ApplicationGraph {
    graph: Graph,
}

impl ApplicationGraph {
    pub(crate) fn new(graph: Graph) -> Self {
        Self { graph }
    }

    pub(super) fn as_graph(&self) -> &Graph {
        &self.graph
    }

    /// Returns the registered graph actions.
    pub fn actions(&self) -> &[GraphAction] {
        self.graph.actions()
    }

    /// Returns the registered graph transitions.
    pub fn transitions(&self) -> &[Transition] {
        self.graph.transitions()
    }

    /// Returns the graph entrypoint action name.
    pub fn entrypoint(&self) -> &str {
        self.graph.entrypoint()
    }

    /// Renders the graph as Mermaid or DOT output.
    pub fn visualize(
        &self,
        output_file_path: Option<&Path>,
        write_dot: bool,
    ) -> io::Result<String> {
        self.graph.visualize(output_file_path, write_dot)
    }
}

impl GraphRegistrationView for ApplicationGraph {
    fn actions(&self) -> &[GraphAction] {
        self.actions()
    }

    fn transitions(&self) -> &[Transition] {
        self.transitions()
    }

    fn entrypoint(&self) -> &str {
        self.entrypoint()
    }
}
