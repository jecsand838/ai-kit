use super::StateError;
use crate::common::{cow_registry::CowRegistry, registry_result::IntoRegistryValueResult};
use indexmap::IndexMap;
use serde_json::Value;
use std::sync::Arc;

type FieldSerializer = dyn Fn(&Value) -> Result<Value, StateError> + Send + Sync + 'static;
type FieldDeserializer = dyn Fn(&Value) -> Result<Value, StateError> + Send + Sync + 'static;

#[derive(Clone)]
/// Serializer and deserializer hooks for a single state field.
pub struct FieldSerdeHandlers {
    serializer: Arc<FieldSerializer>,
    deserializer: Arc<FieldDeserializer>,
}

impl FieldSerdeHandlers {
    fn new<S, D>(serializer: S, deserializer: D) -> Self
    where
        S: Fn(&Value) -> Result<Value, StateError> + Send + Sync + 'static,
        D: Fn(&Value) -> Result<Value, StateError> + Send + Sync + 'static,
    {
        Self {
            serializer: Arc::new(serializer),
            deserializer: Arc::new(deserializer),
        }
    }
}

#[derive(Clone, Default)]
/// Registry of field-specific serde hooks for state persistence.
pub struct FieldSerdeRegistry {
    handlers: IndexMap<String, FieldSerdeHandlers>,
}

impl FieldSerdeRegistry {
    pub(crate) fn serializer_for(&self, field_name: &str) -> Option<&Arc<FieldSerializer>> {
        self.handlers
            .get(field_name)
            .map(|handlers| &handlers.serializer)
    }

    pub(crate) fn deserializer_for(&self, field_name: &str) -> Option<&Arc<FieldDeserializer>> {
        self.handlers
            .get(field_name)
            .map(|handlers| &handlers.deserializer)
    }
}

static FIELD_SERDE_REGISTRY: CowRegistry<FieldSerdeRegistry> =
    CowRegistry::new(FieldSerdeRegistry::default);

/// Registers serializer and deserializer hooks for a specific state field.
pub fn register_field_serde<S, D, SR, DR>(
    field_name: impl Into<String>,
    serializer: S,
    deserializer: D,
) -> Result<(), StateError>
where
    S: Fn(&Value) -> SR + Send + Sync + 'static,
    D: Fn(&Value) -> DR + Send + Sync + 'static,
    SR: IntoRegistryValueResult + 'static,
    DR: IntoRegistryValueResult + 'static,
{
    let field_name = field_name.into();
    let serializer_field = field_name.clone();
    let deserializer_field = field_name.clone();
    let serializer = move |value: &Value| {
        serializer(value).into_registry_value_result(|message| {
            StateError::FieldSerdeHandlerFailed {
                field: serializer_field.clone(),
                direction: "serialize",
                message,
            }
        })
    };
    let deserializer = move |value: &Value| {
        deserializer(value).into_registry_value_result(|message| {
            StateError::FieldSerdeHandlerFailed {
                field: deserializer_field.clone(),
                direction: "deserialize",
                message,
            }
        })
    };
    FIELD_SERDE_REGISTRY.update_by_cloning(
        || StateError::FieldSerdeRegistryPoisoned,
        |next| {
            next.handlers.insert(
                field_name,
                FieldSerdeHandlers::new(serializer, deserializer),
            );
        },
    )?;
    Ok(())
}

/// Returns a snapshot of the process-global field serde registry.
pub fn snapshot_field_serde_registry() -> Result<Arc<FieldSerdeRegistry>, StateError> {
    FIELD_SERDE_REGISTRY.snapshot(|| StateError::FieldSerdeRegistryPoisoned)
}
