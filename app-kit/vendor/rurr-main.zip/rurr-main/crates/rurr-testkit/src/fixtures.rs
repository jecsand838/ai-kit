use futures::{stream, Stream};
use serde_json::{Map, Value};

/// JSON object used by the lightweight fixture actions in this module.
pub type FixtureState = Map<String, Value>;

/// Builds a fixture state with just the `count` field initialized.
pub fn state_with_count(count: i64) -> FixtureState {
    let mut state = FixtureState::new();
    state.insert(String::from("count"), Value::from(count));
    state
}

/// Reads the `count` field from fixture state, defaulting to `0`.
pub fn read_count(state: &FixtureState) -> i64 {
    state.get("count").and_then(Value::as_i64).unwrap_or(0)
}

fn with_count(state: &FixtureState, count: i64) -> FixtureState {
    let mut next = state.clone();
    next.insert(String::from("count"), Value::from(count));
    next
}

/// Simple synchronous counter action fixture.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SyncCounterAction {
    /// Action name used in the fixture graph.
    pub name: &'static str,
    /// Amount added to `count` on each run.
    pub delta: i64,
}

impl SyncCounterAction {
    /// Applies the counter delta to fixture state.
    pub fn run_logic(&self, state: &FixtureState) -> FixtureState {
        with_count(state, read_count(state) + self.delta)
    }
}

/// Full synchronous counter-application fixture.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CounterSyncFixture {
    /// Entrypoint action name.
    pub start: &'static str,
    /// Counter action fixture.
    pub action: SyncCounterAction,
    /// Initial state for the fixture.
    pub initial_state: FixtureState,
}

/// Returns a one-step synchronous counter fixture.
pub fn counter_app_sync_fixture() -> CounterSyncFixture {
    CounterSyncFixture {
        start: "counter",
        action: SyncCounterAction {
            name: "counter",
            delta: 1,
        },
        initial_state: state_with_count(0),
    }
}

/// Simple asynchronous counter action fixture.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AsyncCounterAction {
    /// Action name used in the fixture graph.
    pub name: &'static str,
    /// Amount added to `count` on each run.
    pub delta: i64,
}

impl AsyncCounterAction {
    /// Applies the counter delta to fixture state asynchronously.
    pub async fn run_logic(&self, state: &FixtureState) -> FixtureState {
        with_count(state, read_count(state) + self.delta)
    }
}

/// Full asynchronous counter-application fixture.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CounterAsyncFixture {
    /// Entrypoint action name.
    pub start: &'static str,
    /// Counter action fixture.
    pub action: AsyncCounterAction,
    /// Initial state for the fixture.
    pub initial_state: FixtureState,
}

/// Returns a one-step asynchronous counter fixture.
pub fn counter_app_async_fixture() -> CounterAsyncFixture {
    CounterAsyncFixture {
        start: "counter_async",
        action: AsyncCounterAction {
            name: "counter_async",
            delta: 1,
        },
        initial_state: state_with_count(0),
    }
}

/// Simple synchronous streaming counter action fixture.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SyncStreamingCounterAction {
    /// Action name used in the fixture graph.
    pub name: &'static str,
    /// Final count value emitted by the stream.
    pub target: i64,
}

impl SyncStreamingCounterAction {
    /// Returns each intermediate state from `count + 1` through `target`.
    pub fn stream_logic(&self, state: &FixtureState) -> impl Iterator<Item = FixtureState> {
        let baseline = state.clone();
        let start = read_count(state);
        ((start + 1)..=self.target).map(move |count| with_count(&baseline, count))
    }
}

/// Simple asynchronous streaming counter action fixture.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AsyncStreamingCounterAction {
    /// Action name used in the fixture graph.
    pub name: &'static str,
    /// Final count value emitted by the stream.
    pub target: i64,
}

impl AsyncStreamingCounterAction {
    /// Returns each intermediate state from `count + 1` through `target`.
    pub fn stream_logic(&self, state: &FixtureState) -> impl Stream<Item = FixtureState> {
        let baseline = state.clone();
        let start = read_count(state);
        stream::iter(((start + 1)..=self.target).map(move |count| with_count(&baseline, count)))
    }
}

/// Fixture containing both sync and async streaming counter variants.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StreamingCounterFixture {
    /// Entrypoint action name.
    pub start: &'static str,
    /// Sync streaming action fixture.
    pub sync_action: SyncStreamingCounterAction,
    /// Async streaming action fixture.
    pub async_action: AsyncStreamingCounterAction,
    /// Initial state for the fixture.
    pub initial_state: FixtureState,
}

/// Returns a streaming counter fixture that runs until `count == 3`.
pub fn streaming_counter_app_fixture() -> StreamingCounterFixture {
    StreamingCounterFixture {
        start: "stream_counter",
        sync_action: SyncStreamingCounterAction {
            name: "stream_counter_sync",
            target: 3,
        },
        async_action: AsyncStreamingCounterAction {
            name: "stream_counter_async",
            target: 3,
        },
        initial_state: state_with_count(0),
    }
}

/// Branch condition used by the branching expression fixture.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BranchCondition {
    /// Always take the transition.
    Always,
    /// Take the transition when `count < target`.
    CountLt(i64),
    /// Take the transition when `count >= target`.
    CountGte(i64),
}

impl BranchCondition {
    /// Evaluates the branch condition against fixture state.
    pub fn eval(&self, state: &FixtureState) -> bool {
        let count = read_count(state);
        match self {
            Self::Always => true,
            Self::CountLt(target) => count < *target,
            Self::CountGte(target) => count >= *target,
        }
    }
}

/// Transition fixture connecting two named actions.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BranchTransition {
    /// Source action name.
    pub from: &'static str,
    /// Destination action name.
    pub to: &'static str,
    /// Condition that guards the transition.
    pub condition: BranchCondition,
}

/// Small branching-graph fixture driven by a `count` expression.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BranchingExprFixture {
    /// Entrypoint action name.
    pub start: &'static str,
    /// Names treated as terminal nodes in the fixture.
    pub terminal_nodes: Vec<&'static str>,
    /// Actions used by the fixture.
    pub actions: Vec<SyncCounterAction>,
    /// Transition list used by the fixture.
    pub transitions: Vec<BranchTransition>,
    /// Initial state for the fixture.
    pub initial_state: FixtureState,
}

/// Returns a small branching fixture useful for transition tests.
pub fn branching_expr_app_fixture() -> BranchingExprFixture {
    BranchingExprFixture {
        start: "start",
        terminal_nodes: vec!["done"],
        actions: vec![
            SyncCounterAction {
                name: "start",
                delta: 0,
            },
            SyncCounterAction {
                name: "lt_three",
                delta: 1,
            },
            SyncCounterAction {
                name: "gte_three",
                delta: 0,
            },
            SyncCounterAction {
                name: "done",
                delta: 0,
            },
        ],
        transitions: vec![
            BranchTransition {
                from: "start",
                to: "lt_three",
                condition: BranchCondition::CountLt(3),
            },
            BranchTransition {
                from: "start",
                to: "gte_three",
                condition: BranchCondition::CountGte(3),
            },
            BranchTransition {
                from: "lt_three",
                to: "done",
                condition: BranchCondition::Always,
            },
            BranchTransition {
                from: "gte_three",
                to: "done",
                condition: BranchCondition::Always,
            },
        ],
        initial_state: state_with_count(0),
    }
}
