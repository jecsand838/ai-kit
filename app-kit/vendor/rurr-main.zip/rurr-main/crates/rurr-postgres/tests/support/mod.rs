use async_trait::async_trait;
use futures::Future;
use indexmap::IndexMap;
use postgres::{Config as PgClientConfig, NoTls};
use rurr_core::action::{Condition, FunctionActionBuilder};
use rurr_core::application::{Application, ApplicationBuilder, StepOutput};
use rurr_core::graph::Transition;
use rurr_persistence::{
    ApplicationPersistenceSpec, AsyncBaseStateLoader, AsyncBaseStateSaver, BaseStateLoader,
    BaseStateSaver, PersistedStateData, PersistedStateStatus, PersistenceError,
    PersistenceLoadTarget,
};
use rurr_postgres::{AsyncPostgresPersister, PostgresPersister, PostgresPersisterConfig};
pub(crate) use rurr_testkit::persistence_cases::map_from_pairs;
use rurr_testkit::persistence_cases::{
    run_sync_case, PersistenceConfigLane, PersistenceLane, PersistenceOrderingLane,
    PersistenceReprobeLane,
};
pub(crate) use rurr_testkit::run_sync_on_thread;
use rurr_testkit::{
    drop_postgres_table as live_drop_postgres_table,
    drop_postgres_table_sync as live_drop_postgres_table_sync, live_service_error_to_persistence,
    postgres_url_from_env, ready_postgres_url, ready_postgres_url_sync, unique_postgres_table_name,
    LiveServiceError,
};
use serde_json::{json, Value};
use sqlx::postgres::PgPoolOptions;
use std::str::FromStr;
use std::sync::Arc;
use std::time::Duration;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum PostgresLane {
    Sync,
    Async,
}

impl PostgresLane {
    pub(crate) fn label(self) -> &'static str {
        match self {
            Self::Sync => "sync",
            Self::Async => "async",
        }
    }
}

pub(crate) enum TestPersister {
    Sync(Arc<PostgresPersister>),
    Async(Arc<AsyncPostgresPersister>),
}

impl TestPersister {
    pub(crate) fn from_values(
        lane: PostgresLane,
        database_url: impl Into<String>,
        table_name: impl Into<String>,
    ) -> Result<Self, PersistenceError> {
        let database_url = database_url.into();
        let table_name = table_name.into();

        match lane {
            PostgresLane::Sync => PostgresPersister::new(
                rurr_postgres::PostgresPersisterConfig::new(database_url, table_name),
            )
            .map(Arc::new)
            .map(Self::Sync),
            PostgresLane::Async => AsyncPostgresPersister::new(
                rurr_postgres::PostgresPersisterConfig::new(database_url, table_name),
            )
            .map(Arc::new)
            .map(Self::Async),
        }
    }

    pub(crate) fn from_config(
        lane: PostgresLane,
        config: PostgresPersisterConfig,
    ) -> Result<Self, PersistenceError> {
        match lane {
            PostgresLane::Sync => PostgresPersister::new(config).map(Arc::new).map(Self::Sync),
            PostgresLane::Async => AsyncPostgresPersister::new(config)
                .map(Arc::new)
                .map(Self::Async),
        }
    }

    pub(crate) async fn initialize(&self) -> Result<(), PersistenceError> {
        match self {
            Self::Sync(persister) => persister.initialize(),
            Self::Async(persister) => persister.initialize().await,
        }
    }

    pub(crate) async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        match self {
            Self::Sync(persister) => persister.is_initialized(),
            Self::Async(persister) => persister.is_initialized().await,
        }
    }

    pub(crate) async fn cleanup(&self) -> Result<(), PersistenceError> {
        match self {
            Self::Sync(persister) => persister.cleanup(),
            Self::Async(persister) => persister.close().await,
        }
    }

    pub(crate) async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        match self {
            Self::Sync(persister) => {
                persister.save(partition_key, app_id, sequence_id, position, state, status)
            }
            Self::Async(persister) => {
                persister
                    .save(partition_key, app_id, sequence_id, position, state, status)
                    .await
            }
        }
    }

    pub(crate) async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        match self {
            Self::Sync(persister) => persister.load(partition_key, app_id, sequence_id),
            Self::Async(persister) => persister.load(partition_key, app_id, sequence_id).await,
        }
    }

    pub(crate) async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        match self {
            Self::Sync(persister) => persister.list_app_ids(partition_key),
            Self::Async(persister) => persister.list_app_ids(partition_key).await,
        }
    }

    pub(crate) fn config(&self) -> PostgresPersisterConfig {
        match self {
            Self::Sync(persister) => persister.config(),
            Self::Async(persister) => persister.config(),
        }
    }

    pub(crate) fn persistence_spec(
        &self,
        load_target: Option<PersistenceLoadTarget>,
    ) -> ApplicationPersistenceSpec {
        match self {
            Self::Sync(persister) => sync_persistence_spec(persister.clone(), load_target),
            Self::Async(persister) => async_persistence_spec(persister.clone(), load_target),
        }
    }
}

#[derive(Clone, Copy)]
pub(crate) struct RawCompletedState<'a> {
    pub(crate) partition_key: &'a str,
    pub(crate) app_id: &'a str,
    pub(crate) sequence_id: i64,
    pub(crate) position: &'a str,
    pub(crate) marker: &'a str,
    pub(crate) created_at: &'a str,
}

pub(crate) struct LivePostgresLane {
    lane: PostgresLane,
    database_url: String,
    table_name: String,
    persister: TestPersister,
}

const OP_POSTGRES_LIVE_CLEANUP: &str = "postgres_live_cleanup";

fn postgres_live_cleanup_error(error: LiveServiceError) -> PersistenceError {
    live_service_error_to_persistence(OP_POSTGRES_LIVE_CLEANUP, error)
}

fn prefer_first_cleanup_error(
    cleanup_result: Result<(), PersistenceError>,
    finalizer_result: Result<(), PersistenceError>,
) -> Result<(), PersistenceError> {
    match cleanup_result {
        Err(error) => {
            let _ = finalizer_result;
            Err(error)
        }
        Ok(()) => finalizer_result,
    }
}

impl LivePostgresLane {
    pub(crate) async fn new(lane: PostgresLane, prefix: &str) -> Self {
        let database_url = live_database_url_for_lane(lane).await;
        let table_name = unique_table_name(prefix);
        let persister = TestPersister::from_values(lane, database_url.clone(), table_name.clone())
            .expect("persister should create");

        Self {
            lane,
            database_url,
            table_name,
            persister,
        }
    }

    pub(crate) fn persister(&self) -> &TestPersister {
        &self.persister
    }

    pub(crate) fn lane(&self) -> PostgresLane {
        self.lane
    }

    pub(crate) fn table_name(&self) -> &str {
        &self.table_name
    }

    pub(crate) fn database_url(&self) -> &str {
        &self.database_url
    }

    pub(crate) async fn insert_raw_completed_state(&self, row: RawCompletedState<'_>) {
        insert_raw_completed_state(self.lane, &self.database_url, &self.table_name, row).await;
    }

    async fn seed_completed_states(&self, rows: &[RawCompletedState<'_>]) {
        for row in rows {
            self.insert_raw_completed_state(*row).await;
        }
    }
}

fn raw_completed_state(
    partition_key: &'static str,
    app_id: &'static str,
    sequence_id: i64,
    position: &'static str,
    marker: &'static str,
    created_at: &'static str,
) -> RawCompletedState<'static> {
    RawCompletedState {
        partition_key,
        app_id,
        sequence_id,
        position,
        marker,
        created_at,
    }
}

#[async_trait(?Send)]
impl PersistenceLane for LivePostgresLane {
    async fn initialize(&self) -> Result<(), PersistenceError> {
        self.persister.initialize().await
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        self.persister.is_initialized().await
    }

    async fn cleanup(&self) -> Result<(), PersistenceError> {
        let cleanup_result = self.persister.cleanup().await;
        let drop_result = match self.lane {
            PostgresLane::Sync => drop_table_sync(&self.database_url, &self.table_name),
            PostgresLane::Async => drop_table(&self.database_url, &self.table_name).await,
        };
        prefer_first_cleanup_error(cleanup_result, drop_result)
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: IndexMap<String, Value>,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        self.persister
            .save(partition_key, app_id, sequence_id, position, state, status)
            .await
    }

    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        self.persister
            .load(partition_key, app_id, sequence_id)
            .await
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        self.persister.list_app_ids(partition_key).await
    }
}

#[async_trait(?Send)]
impl PersistenceOrderingLane for LivePostgresLane {
    async fn seed_latest_partition_order_fixture(&self) -> Result<(), PersistenceError> {
        self.seed_completed_states(&[
            raw_completed_state(
                "partition",
                "older_created_at_higher_seq",
                99,
                "step_old",
                "old",
                "2026-02-20 00:00:00",
            ),
            raw_completed_state(
                "partition",
                "newer_created_at_lower_seq",
                1,
                "step_new",
                "new",
                "2026-02-21 00:00:00",
            ),
        ])
        .await;
        Ok(())
    }

    async fn seed_exact_sequence_order_fixture(&self) -> Result<(), PersistenceError> {
        self.seed_completed_states(&[
            raw_completed_state(
                "partition",
                "app_id",
                7,
                "step_z",
                "older",
                "2026-02-20 00:00:00",
            ),
            raw_completed_state(
                "partition",
                "app_id",
                7,
                "step_a",
                "newer_low_position",
                "2026-02-21 00:00:00",
            ),
            raw_completed_state(
                "partition",
                "app_id",
                7,
                "step_b",
                "newer_high_position",
                "2026-02-21 00:00:00",
            ),
        ])
        .await;
        Ok(())
    }

    async fn seed_list_app_ids_order_fixture(&self) -> Result<Vec<String>, PersistenceError> {
        self.seed_completed_states(&[
            raw_completed_state(
                "partition",
                "app_b",
                1,
                "step_b",
                "newer_b",
                "2026-02-21 00:00:00",
            ),
            raw_completed_state(
                "partition",
                "app_a",
                1,
                "step_a",
                "newer_a",
                "2026-02-21 00:00:00",
            ),
            raw_completed_state(
                "partition",
                "app_c",
                99,
                "step_c",
                "older_c",
                "2026-02-20 00:00:00",
            ),
        ])
        .await;

        Ok(vec![
            "app_a".to_string(),
            "app_b".to_string(),
            "app_c".to_string(),
        ])
    }
}

#[async_trait(?Send)]
impl PersistenceReprobeLane for LivePostgresLane {
    async fn external_initialize(&self) -> Result<(), PersistenceError> {
        let external_initializer = TestPersister::from_values(
            self.lane,
            self.database_url.clone(),
            self.table_name.clone(),
        )
        .expect("persister should create");
        external_initializer
            .initialize()
            .await
            .expect("external initialize should succeed");
        external_initializer
            .cleanup()
            .await
            .expect("external cleanup should succeed");
        Ok(())
    }

    async fn drop_storage(&self) {
        match self.lane {
            PostgresLane::Sync => drop_table_sync(&self.database_url, &self.table_name),
            PostgresLane::Async => drop_table(&self.database_url, &self.table_name).await,
        }
        .expect("table drop should succeed");
    }
}

#[async_trait(?Send)]
impl PersistenceConfigLane for LivePostgresLane {
    async fn rebuild_from_config(&self) -> Result<Self, PersistenceError> {
        let persister = TestPersister::from_config(self.lane, self.persister.config())?;
        Ok(Self {
            lane: self.lane,
            database_url: self.database_url.clone(),
            table_name: self.table_name.clone(),
            persister,
        })
    }
}

pub(crate) fn constructor_database_url() -> String {
    postgres_url_from_env().expect("postgres URL must be valid for constructor tests")
}

pub(crate) async fn live_database_url() -> String {
    ready_postgres_url()
        .await
        .expect("postgres must be reachable for live tests")
}

pub(crate) async fn live_database_url_for_lane(lane: PostgresLane) -> String {
    match lane {
        PostgresLane::Sync => {
            ready_postgres_url_sync().expect("postgres must be reachable for live tests")
        }
        PostgresLane::Async => live_database_url().await,
    }
}

pub(crate) fn unique_table_name(prefix: &str) -> String {
    unique_postgres_table_name(prefix)
}

pub(crate) fn run_live_sync_case<F, T>(future: F) -> T
where
    F: Future<Output = T>,
{
    run_sync_case(future)
}

pub(crate) fn counter_builder() -> ApplicationBuilder {
    let start_action = counter_action();
    let finish_action = counter_action();

    ApplicationBuilder::new()
        .with_actions(vec![("start", start_action), ("finish", finish_action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "start",
            "finish",
            Condition::default(),
        )])
        .expect("transitions should configure")
}

pub(crate) type StepResult = StepOutput;

pub(crate) async fn build_counter_app(
    lane: PostgresLane,
    spec: ApplicationPersistenceSpec,
    app_id: &str,
    partition_key: Option<String>,
) -> Application {
    let builder = counter_builder()
        .with_identifiers(app_id, partition_key, None)
        .expect("identifiers should configure")
        .with_persistence_spec(spec)
        .expect("persistence spec should configure");

    match lane {
        PostgresLane::Sync => builder.build().expect("build should succeed"),
        PostgresLane::Async => builder.abuild().await.expect("build should succeed"),
    }
}

pub(crate) async fn step_counter_app(lane: PostgresLane, app: &mut Application) -> StepResult {
    match lane {
        PostgresLane::Sync => app
            .step(None)
            .expect("step should succeed")
            .expect("step should execute"),
        PostgresLane::Async => app
            .astep(None)
            .await
            .expect("step should succeed")
            .expect("step should execute"),
    }
}

pub(crate) fn sync_persistence_spec(
    persister: Arc<PostgresPersister>,
    load_target: Option<PersistenceLoadTarget>,
) -> ApplicationPersistenceSpec {
    ApplicationPersistenceSpec::sync_resume(
        persister,
        true,
        map_from_pairs([("count", json!(0))]),
        "start",
        None,
        load_target,
    )
}

pub(crate) fn async_persistence_spec(
    persister: Arc<AsyncPostgresPersister>,
    load_target: Option<PersistenceLoadTarget>,
) -> ApplicationPersistenceSpec {
    ApplicationPersistenceSpec::async_resume(
        persister,
        true,
        map_from_pairs([("count", json!(0))]),
        "start",
        None,
        load_target,
    )
}

pub(crate) fn assert_connection_closed(error: PersistenceError) {
    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation { operation } if operation == "connection_closed"
    ));
}

pub(crate) async fn insert_raw_completed_state(
    lane: PostgresLane,
    database_url: &str,
    table_name: &str,
    row: RawCompletedState<'_>,
) {
    match lane {
        PostgresLane::Sync => {
            let database_url = database_url.to_string();
            let table_name = table_name.to_string();
            let partition_key = row.partition_key.to_string();
            let app_id = row.app_id.to_string();
            let position = row.position.to_string();
            let marker = row.marker.to_string();
            let created_at = row.created_at.to_string();
            let sequence_id = row.sequence_id;

            run_sync_on_thread(move || {
                let mut client = PgClientConfig::from_str(&database_url)
                    .expect("raw insert URL should parse")
                    .connect(NoTls)
                    .expect("raw insert client should connect");
                let state_json = serde_json::to_string(&json!({ "marker": marker }))
                    .expect("json should serialize");
                let query = format!(
                    "INSERT INTO {table_name} \
                     (partition_key, app_id, sequence_id, position, status, state, created_at) \
                     VALUES ($1, $2, $3, $4, 'completed', '{state_json}'::jsonb, '{created_at}'::timestamp)"
                );

                client
                    .execute(&query, &[&partition_key, &app_id, &sequence_id, &position])
                    .expect("raw insert should succeed");
            });
        }
        PostgresLane::Async => {
            let pool = PgPoolOptions::new()
                .max_connections(1)
                .acquire_timeout(Duration::from_secs(2))
                .connect(database_url)
                .await
                .expect("raw insert pool should connect");
            let query = format!(
                "INSERT INTO {table_name} \
                 (partition_key, app_id, sequence_id, position, status, state, created_at) \
                 VALUES ($1, $2, $3, $4, 'completed', $5::jsonb, $6::timestamp)"
            );

            sqlx::query(&query)
                .bind(row.partition_key)
                .bind(row.app_id)
                .bind(row.sequence_id)
                .bind(row.position)
                .bind(format!(r#"{{"marker":"{marker}"}}"#, marker = row.marker))
                .bind(row.created_at)
                .execute(&pool)
                .await
                .expect("raw insert should succeed");

            pool.close().await;
        }
    }
}

pub(crate) async fn drop_table(
    database_url: &str,
    table_name: &str,
) -> Result<(), PersistenceError> {
    live_drop_postgres_table(database_url, table_name)
        .await
        .map_err(postgres_live_cleanup_error)
}

pub(crate) fn drop_table_sync(
    database_url: &str,
    table_name: &str,
) -> Result<(), PersistenceError> {
    live_drop_postgres_table_sync(database_url, table_name).map_err(postgres_live_cleanup_error)
}

pub(crate) fn sequence_id_column_data_type_sync(database_url: &str, table_name: &str) -> String {
    let mut client = connect_auxiliary_client(database_url);
    client
        .query_one(
            "SELECT data_type \
             FROM information_schema.columns \
             WHERE table_schema = current_schema() AND table_name = $1 AND column_name = 'sequence_id'",
            &[&table_name],
        )
        .expect("column metadata query should succeed")
        .get(0)
}

pub(crate) fn with_application_name(database_url: &str, application_name: &str) -> String {
    if database_url.contains('?') {
        format!("{database_url}&application_name={application_name}")
    } else {
        format!("{database_url}?application_name={application_name}")
    }
}

pub(crate) fn terminate_backend_by_application_name_sync(
    database_url: &str,
    application_name: &str,
) {
    let pid = backend_pid_for_application_name_sync(database_url, application_name);
    let mut client = connect_auxiliary_client(database_url);
    let terminated: bool = client
        .query_one("SELECT pg_terminate_backend($1)", &[&pid])
        .expect("backend termination query should succeed")
        .get(0);
    assert!(terminated, "backend termination should return true");
}

fn counter_action() -> rurr_core::action::FunctionAction {
    FunctionActionBuilder::new()
        .writes(vec!["count".to_string()])
        .build_sync(|state, _ctx| {
            let next = state
                .get("count")
                .and_then(Value::as_i64)
                .unwrap_or_default()
                + 1;
            IndexMap::from([(String::from("count"), Value::from(next))])
        })
        .expect("action should build")
}

fn backend_pid_for_application_name_sync(database_url: &str, application_name: &str) -> i32 {
    let mut client = connect_auxiliary_client(database_url);
    client
        .query_one(
            "SELECT pid \
             FROM pg_stat_activity \
             WHERE application_name = $1 \
             ORDER BY backend_start DESC \
             LIMIT 1",
            &[&application_name],
        )
        .expect("backend pid query should succeed")
        .get(0)
}

fn connect_auxiliary_client(database_url: &str) -> postgres::Client {
    PgClientConfig::from_str(database_url)
        .expect("auxiliary postgres URL should be valid")
        .connect(NoTls)
        .expect("auxiliary postgres connection should succeed")
}
