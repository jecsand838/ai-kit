//! Burr-style CLI telemetry for Rurr built on OTEL logs and traces.
//!
//! This crate keeps Burr-compatible enablement semantics:
//! - telemetry is enabled by default
//! - `BURR_TELEMETRY_ENABLED` overrides config file state
//! - invalid enablement values fail closed for the current process
//! - `disable_telemetry()` disables emission for the current process
//! - `~/.rurr.conf` persists the anonymous id and default enablement flag
//! - emission is best-effort and never blocks command success
//!
//! Export uses standard OTLP logs and traces through [`rurr_otel`]. When no
//! OTLP endpoint configuration is present, telemetry remains conceptually
//! enabled but export is inert.
//!
//! Rurr core application execution does not emit hidden anonymous telemetry;
//! callers explicitly emit CLI command telemetry with [`capture_cli_command`].
//! The only current telemetry event class is the Burr-compatible CLI command
//! event; application-function telemetry is intentionally not part of the Rust
//! core boundary.
//!
//! These helpers read and update process-global telemetry state. They are kept
//! separate from `rurr-core` so library users do not opt into anonymous
//! telemetry by constructing or running applications.
//!
//! # Examples
//!
//! ```no_run
//! // `capture_cli_command` is process-global and best-effort, so examples that
//! // emit real telemetry stay `no_run`.
//! rurr_telemetry::capture_cli_command("serve");
//! rurr_telemetry::force_flush();
//! ```
#![deny(missing_docs)]

mod config;
mod runtime;

pub use runtime::{
    capture_cli_command, disable_telemetry, force_flush, is_telemetry_enabled, shutdown,
};
