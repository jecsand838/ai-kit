use indexmap::IndexMap;
use rurr_core::{action::ActionInputs, state::State};
use serde_json::Value;

pub(crate) fn map_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> IndexMap<String, Value> {
    pairs
        .into_iter()
        .map(|(key, value)| (key.to_string(), value))
        .collect()
}

pub(crate) fn state_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> State {
    State::new(map_from_pairs(pairs))
}

pub(crate) fn inputs_from_pairs<const N: usize>(pairs: [(&str, Value); N]) -> ActionInputs {
    map_from_pairs(pairs)
}
