use super::{
    prefer_hook_error, stream_invariant, AsyncStepExecution, SessionCore, StreamOrigin,
    StreamTerminal, SyncStepExecution, ITERATE_ASYNC_ORIGIN, ITERATE_SYNC_ORIGIN,
    RESULT_ASYNC_ORIGIN, RESULT_SYNC_ORIGIN,
};
use crate::action::api::{ActionInputs, StreamItem};
use crate::application::session::{
    ActionExecution, ExecutionPlan, ExecutionSessionSettings, IterateTransition, StartedExecution,
    StreamResultTransition, TransitionResolver,
};
use crate::application::step_txn::{execute_planned_action_async, execute_planned_action_sync};
use crate::application::Application;
use crate::application::ApplicationError;
use crate::lifecycle::ExecuteCallGuard;

type FastForwardedStep = (crate::graph::GraphAction, StreamItem);
type StepAppResult<'a> = Result<&'a mut crate::application::Application, ApplicationError>;
type CompletedStep<'a> = (Result<StreamTerminal, ApplicationError>, StepAppResult<'a>);
type AbortedStep<'a> = (StepAppResult<'a>, Result<(), ApplicationError>);
struct OpenResultSessionDriver {
    settings: ExecutionSessionSettings,
    execute_guard: ExecuteCallGuard,
    pending_plan: ExecutionPlan,
    last_fast_forwarded_step: Option<FastForwardedStep>,
}

enum ResultSessionStep {
    Ready {
        returned_action: crate::graph::GraphAction,
        target_execution: Option<ActionExecution>,
        terminal: Option<StreamTerminal>,
    },
    FastForward(ActionExecution),
}

enum IterateStart {
    Start {
        action: crate::graph::GraphAction,
        sequence_id: u64,
        execution: ActionExecution,
    },
    Finish,
}

enum ResultSlotStart {
    Done,
    Active,
    Start(ActionExecution),
    FinishEmpty,
}

#[derive(Clone, Copy)]
struct StepAdvanceCore {
    origin: StreamOrigin,
}

enum StepSlotState<T> {
    Active(T),
    Terminal(StreamTerminal),
}

impl OpenResultSessionDriver {
    fn from_started(started: StartedExecution) -> Result<Self, ApplicationError> {
        match started {
            StartedExecution::Ready {
                settings,
                execute_guard,
                pending_plan,
            } => Ok(Self {
                settings,
                execute_guard: *execute_guard,
                pending_plan: *pending_plan,
                last_fast_forwarded_step: None,
            }),
            StartedExecution::StartupError { error } => Err(error),
        }
    }

    fn next_step(&mut self, app: &Application) -> Result<ResultSessionStep, ApplicationError> {
        let pending_plan = std::mem::replace(&mut self.pending_plan, ExecutionPlan::new(app));
        let last_fast_forwarded_step = self
            .last_fast_forwarded_step
            .as_ref()
            .map(|(action, result)| (action, result));
        match TransitionResolver::new(&self.settings).resolve_stream_result_target(
            app,
            pending_plan.resolve()?,
            last_fast_forwarded_step,
        )? {
            StreamResultTransition::Ready {
                returned_action,
                target_execution,
                terminal,
            } => Ok(ResultSessionStep::Ready {
                returned_action,
                target_execution,
                terminal,
            }),
            StreamResultTransition::FastForward(execution) => {
                Ok(ResultSessionStep::FastForward(execution))
            }
        }
    }

    fn record_fast_forward(
        &mut self,
        action: crate::graph::GraphAction,
        result: StreamItem,
        app: &Application,
    ) {
        self.last_fast_forwarded_step = Some((action, result));
        self.pending_plan = ExecutionPlan::new(app);
    }

    fn inputs(&self) -> &ActionInputs {
        self.settings.inputs()
    }

    fn finish_ready<'a>(
        self,
        app: &'a mut Application,
        terminal: Option<StreamTerminal>,
    ) -> SessionCore<'a> {
        SessionCore::new(
            app,
            self.settings,
            Some(self.execute_guard),
            terminal,
            None,
            None,
        )
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum CompletionDisposition {
    KeepHandleOpen,
    CloseSession,
}

impl CompletionDisposition {
    fn completed_resolution(self) -> StepAdvanceResolution {
        match self {
            Self::KeepHandleOpen => StepAdvanceResolution::ReturnNone,
            Self::CloseSession => StepAdvanceResolution::Close(Ok(None)),
        }
    }
}

enum ActiveStepProgress<E> {
    Item(StreamItem),
    Complete(E),
    Abort(E, ApplicationError),
}

enum StepAdvanceResolution {
    Item(StreamItem),
    ReturnNone,
    Close(Result<Option<StreamItem>, ApplicationError>),
}

enum StepSettlement<'a> {
    Item(StreamItem),
    Completed(CompletedStep<'a>),
    Aborted {
        error: ApplicationError,
        step: AbortedStep<'a>,
    },
}

impl StepAdvanceCore {
    fn new(origin: StreamOrigin) -> Self {
        Self { origin }
    }

    fn settle<E>(
        self,
        execution: &mut Option<E>,
        next_result: Result<Option<StreamItem>, ApplicationError>,
    ) -> Result<ActiveStepProgress<E>, ApplicationError> {
        match next_result {
            Ok(Some(item)) => Ok(ActiveStepProgress::Item(item)),
            Ok(None) => execution
                .take()
                .map(ActiveStepProgress::Complete)
                .ok_or_else(|| stream_invariant(self.origin.missing_completion)),
            Err(error) => execution
                .take()
                .map(|execution| ActiveStepProgress::Abort(execution, error))
                .ok_or_else(|| stream_invariant(self.origin.missing_abort)),
        }
    }

    fn close_sync_if_needed<'a>(
        self,
        lifecycle: &mut SessionCore<'a>,
        resolution: StepAdvanceResolution,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        match resolution {
            StepAdvanceResolution::Item(item) => Ok(Some(item)),
            StepAdvanceResolution::ReturnNone => Ok(None),
            StepAdvanceResolution::Close(result) => lifecycle.close_with_sync_precedence(result),
        }
    }

    async fn close_async_if_needed<'a>(
        self,
        lifecycle: &mut SessionCore<'a>,
        resolution: StepAdvanceResolution,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        match resolution {
            StepAdvanceResolution::Item(item) => Ok(Some(item)),
            StepAdvanceResolution::ReturnNone => Ok(None),
            StepAdvanceResolution::Close(result) => {
                lifecycle.close_with_async_precedence(result).await
            }
        }
    }
}

impl<'a> SessionCore<'a> {
    fn resolve_next_iterate_execution(
        &mut self,
    ) -> Result<Option<ActionExecution>, ApplicationError> {
        if self.is_done() {
            return Ok(None);
        }
        if let Some(error) = self.take_deferred_abort_error() {
            return Err(error);
        }
        if let Some(error) = self.startup_error.take() {
            return Err(error);
        }
        self.resolve_next_action()
    }

    fn resolve_next_action(&mut self) -> Result<Option<ActionExecution>, ApplicationError> {
        let app = self.app.as_deref_mut().ok_or_else(|| {
            stream_invariant("stream_iterate missing application while resolving next action")
        })?;
        let plan = self
            .pending_plan
            .take()
            .unwrap_or_else(|| ExecutionPlan::new(app));
        match TransitionResolver::new(&self.settings).resolve_iterate_next(
            app,
            plan.resolve()?,
            self.has_committed_step,
        )? {
            IterateTransition::Continue(execution) => Ok(Some(execution)),
            IterateTransition::Close => Ok(None),
        }
    }

    pub(super) fn open_result_session(
        app: &'a mut Application,
        started: StartedExecution,
    ) -> Result<(crate::graph::GraphAction, Self, Option<ActionExecution>), ApplicationError> {
        let mut driver = OpenResultSessionDriver::from_started(started)?;

        loop {
            match driver.next_step(app)? {
                ResultSessionStep::Ready {
                    returned_action,
                    target_execution,
                    terminal,
                } => {
                    let mut state = driver.finish_ready(app, terminal);
                    if state.is_done() {
                        state.close_session_sync()?;
                    }
                    return Ok((returned_action, state, target_execution));
                }
                ResultSessionStep::FastForward(execution) => {
                    match execute_planned_action_sync(app, execution, driver.inputs()) {
                        Ok(fast_forwarded) => {
                            driver.record_fast_forward(
                                fast_forwarded.action,
                                fast_forwarded.result,
                                app,
                            );
                        }
                        Err(error) => {
                            let mut state = driver.finish_ready(app, None);
                            return state.close_with_sync_precedence(Err(error));
                        }
                    }
                }
            }
        }
    }

    pub(super) async fn open_result_session_async(
        app: &'a mut Application,
        started: StartedExecution,
    ) -> Result<(crate::graph::GraphAction, Self, Option<ActionExecution>), ApplicationError> {
        let mut driver = OpenResultSessionDriver::from_started(started)?;

        loop {
            match driver.next_step(app)? {
                ResultSessionStep::Ready {
                    returned_action,
                    target_execution,
                    terminal,
                } => {
                    let mut state = driver.finish_ready(app, terminal);
                    if state.is_done() {
                        state.close_session_async().await?;
                    }
                    return Ok((returned_action, state, target_execution));
                }
                ResultSessionStep::FastForward(execution) => {
                    match execute_planned_action_async(app, execution, driver.inputs()).await {
                        Ok(fast_forwarded) => {
                            driver.record_fast_forward(
                                fast_forwarded.action,
                                fast_forwarded.result,
                                app,
                            );
                        }
                        Err(error) => {
                            let mut state = driver.finish_ready(app, None);
                            return state.close_with_async_precedence(Err(error)).await;
                        }
                    }
                }
            }
        }
    }

    pub(super) fn close_session_sync(&mut self) -> Result<(), ApplicationError> {
        self.finish_session_state();
        if let Some(guard) = self.execute_guard.take() {
            guard.finish_sync()?;
        }
        Ok(())
    }

    pub(super) async fn close_session_async(&mut self) -> Result<(), ApplicationError> {
        self.finish_session_state();
        if let Some(guard) = self.execute_guard.take() {
            guard.finish_async().await?;
        }
        Ok(())
    }

    pub(super) fn close_session_sync_only(&mut self) {
        self.finish_session_state();
        let _ = self.execute_guard.take();
    }

    pub(super) fn finish_session_state(&mut self) {
        self.progress.finish_from_current_state(self.app.as_deref());
    }

    fn classify_next_iterate_start(&mut self) -> Result<IterateStart, ApplicationError> {
        let Some(execution) = self.resolve_next_iterate_execution()? else {
            return Ok(IterateStart::Finish);
        };
        Ok(IterateStart::Start {
            action: execution.action().clone(),
            sequence_id: execution.sequence_id(),
            execution,
        })
    }

    fn classify_result_slot<T>(
        &self,
        target_execution: &mut Option<ActionExecution>,
        active_step: &Option<T>,
    ) -> ResultSlotStart {
        if self.is_done() {
            ResultSlotStart::Done
        } else if active_step.is_some() {
            ResultSlotStart::Active
        } else if let Some(execution) = target_execution.take() {
            ResultSlotStart::Start(execution)
        } else {
            ResultSlotStart::FinishEmpty
        }
    }

    fn take_step_application(
        &mut self,
        origin: StreamOrigin,
    ) -> Result<&'a mut Application, ApplicationError> {
        self.progress.clear_terminal();
        self.app
            .take()
            .ok_or_else(|| stream_invariant(origin.missing_application))
    }

    fn finish_step_start(&mut self) {
        self.progress.mark_streaming_started();
    }

    pub(super) fn result_terminal_sync(&self) -> Result<StreamTerminal, ApplicationError> {
        self.terminal(RESULT_SYNC_ORIGIN)
    }

    pub(super) fn result_terminal_async(&self) -> Result<StreamTerminal, ApplicationError> {
        self.terminal(RESULT_ASYNC_ORIGIN)
    }

    pub(super) fn start_sync_step_execution(
        &mut self,
        execution: ActionExecution,
        origin: StreamOrigin,
    ) -> Result<SyncStepExecution<'a>, ApplicationError> {
        let app = self.take_step_application(origin)?;
        match SyncStepExecution::new(app, execution, self.settings.shared_inputs()) {
            Ok(step) => {
                self.finish_step_start();
                Ok(step)
            }
            Err((error, app_back)) => {
                self.app = Some(app_back);
                Err(*error)
            }
        }
    }

    pub(super) async fn start_async_step_execution(
        &mut self,
        execution: ActionExecution,
        origin: StreamOrigin,
    ) -> Result<AsyncStepExecution<'a>, ApplicationError> {
        let app = self.take_step_application(origin)?;
        match AsyncStepExecution::new(app, execution, self.settings.shared_inputs()).await {
            Ok(step) => {
                self.finish_step_start();
                Ok(step)
            }
            Err((error, app_back)) => {
                self.app = Some(app_back);
                Err(*error)
            }
        }
    }

    pub(super) fn settle_completion(
        &mut self,
        terminal_result: Result<StreamTerminal, ApplicationError>,
        app_result: StepAppResult<'a>,
    ) -> Result<(), ApplicationError> {
        match (terminal_result, app_result) {
            (Ok(terminal), Ok(app)) => {
                self.has_committed_step |= terminal.0.is_some();
                self.app = Some(app);
                self.progress.set_terminal(terminal);
                Ok(())
            }
            (Err(error), Ok(app)) => {
                self.app = Some(app);
                Err(error)
            }
            (_, Err(error)) => Err(error),
        }
    }

    pub(super) fn settle_abort(
        &mut self,
        app_result: StepAppResult<'a>,
        abort_hook_result: Result<(), ApplicationError>,
    ) -> Result<(), ApplicationError> {
        let app_recovery_result = match app_result {
            Ok(app) => {
                self.app = Some(app);
                Ok(())
            }
            Err(error) => Err(error),
        };
        let abort_result = prefer_hook_error(app_recovery_result, abort_hook_result);
        self.progress
            .cache_current_state_if_missing(self.app.as_deref());
        abort_result
    }

    pub(super) fn settle_abort_sync_only(
        &mut self,
        app_result: StepAppResult<'a>,
    ) -> Result<(), ApplicationError> {
        self.settle_abort(app_result, Ok(()))
    }

    fn resolve_settlement(
        &mut self,
        settlement: StepSettlement<'a>,
        completion: CompletionDisposition,
    ) -> Result<StepAdvanceResolution, ApplicationError> {
        match settlement {
            StepSettlement::Item(item) => Ok(StepAdvanceResolution::Item(item)),
            StepSettlement::Completed((terminal_result, app_result)) => {
                self.settle_completion(terminal_result, app_result)?;
                Ok(completion.completed_resolution())
            }
            StepSettlement::Aborted {
                error,
                step: (app_result, abort_hook_result),
            } => Ok(StepAdvanceResolution::Close(prefer_hook_error(
                Result::<Option<StreamItem>, ApplicationError>::Err(error),
                self.settle_abort(app_result, abort_hook_result),
            ))),
        }
    }

    pub(super) fn record_deferred_abort(&mut self, result: Result<(), ApplicationError>) {
        if let Err(error) = result {
            self.set_deferred_abort_error(error);
        }
    }

    pub(super) fn begin_sync_iterate_step(
        &mut self,
    ) -> Result<Option<(crate::graph::GraphAction, u64, SyncStepExecution<'a>)>, ApplicationError>
    {
        match self.classify_next_iterate_start() {
            Ok(IterateStart::Start {
                action,
                sequence_id,
                execution,
            }) => {
                let step = self
                    .start_sync_step_execution(execution, ITERATE_SYNC_ORIGIN)
                    .or_else(|error| self.close_with_sync_precedence(Err(error)))?;
                Ok(Some((action, sequence_id, step)))
            }
            Ok(IterateStart::Finish) => {
                let _: Option<()> = self.close_with_sync_precedence(Ok(None))?;
                Ok(None)
            }
            Err(error) => self.close_with_sync_precedence(Err(error)),
        }
    }

    pub(super) async fn begin_async_iterate_step(
        &mut self,
    ) -> Result<Option<(crate::graph::GraphAction, u64, AsyncStepExecution<'a>)>, ApplicationError>
    {
        match self.classify_next_iterate_start() {
            Ok(IterateStart::Start {
                action,
                sequence_id,
                execution,
            }) => {
                let step = match self
                    .start_async_step_execution(execution, ITERATE_ASYNC_ORIGIN)
                    .await
                {
                    Ok(step) => step,
                    Err(error) => return self.close_with_async_precedence(Err(error)).await,
                };
                Ok(Some((action, sequence_id, step)))
            }
            Ok(IterateStart::Finish) => {
                let _: Option<()> = self.close_with_async_precedence(Ok(None)).await?;
                Ok(None)
            }
            Err(error) => self.close_with_async_precedence(Err(error)).await,
        }
    }

    fn advance_sync_step_execution(
        &mut self,
        execution: &mut Option<SyncStepExecution<'a>>,
        origin: StreamOrigin,
        completion: CompletionDisposition,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        let core = StepAdvanceCore::new(origin);
        let next_result = {
            let step = execution
                .as_mut()
                .ok_or_else(|| stream_invariant(origin.missing_execution))?;
            step.next_item()
        };
        let settlement = match core.settle(execution, next_result)? {
            ActiveStepProgress::Item(item) => StepSettlement::Item(item),
            ActiveStepProgress::Complete(step) => {
                StepSettlement::Completed(step.complete_and_take_app())
            }
            ActiveStepProgress::Abort(step, error) => StepSettlement::Aborted {
                error,
                step: step.abort_and_take_app_with_hook_result(),
            },
        };
        let resolution = match self.resolve_settlement(settlement, completion) {
            Ok(resolution) => resolution,
            Err(error) => return self.close_with_sync_precedence(Err(error)),
        };
        core.close_sync_if_needed(self, resolution)
    }

    async fn advance_async_step_execution(
        &mut self,
        execution: &mut Option<AsyncStepExecution<'a>>,
        origin: StreamOrigin,
        completion: CompletionDisposition,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        let core = StepAdvanceCore::new(origin);
        let next_result = {
            let step = execution
                .as_mut()
                .ok_or_else(|| stream_invariant(origin.missing_execution))?;
            step.next_item().await
        };
        let settlement = match core.settle(execution, next_result)? {
            ActiveStepProgress::Item(item) => StepSettlement::Item(item),
            ActiveStepProgress::Complete(step) => {
                StepSettlement::Completed(step.complete_and_take_app().await)
            }
            ActiveStepProgress::Abort(step, error) => StepSettlement::Aborted {
                error,
                step: step.abort_and_take_app_with_hook_result().await,
            },
        };
        let resolution = match self.resolve_settlement(settlement, completion) {
            Ok(resolution) => resolution,
            Err(error) => return self.close_with_async_precedence(Err(error)).await,
        };
        core.close_async_if_needed(self, resolution).await
    }

    pub(super) fn advance_sync_iterate_step(
        &mut self,
        execution: &mut Option<SyncStepExecution<'a>>,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        if execution.is_none() {
            return self.closed_iterate_handle_result();
        }

        self.advance_sync_step_execution(
            execution,
            ITERATE_SYNC_ORIGIN,
            CompletionDisposition::KeepHandleOpen,
        )
    }

    pub(super) async fn advance_async_iterate_step(
        &mut self,
        execution: &mut Option<AsyncStepExecution<'a>>,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        if execution.is_none() {
            return self.closed_iterate_handle_result();
        }

        self.advance_async_step_execution(
            execution,
            ITERATE_ASYNC_ORIGIN,
            CompletionDisposition::KeepHandleOpen,
        )
        .await
    }

    pub(super) fn complete_sync_iterate_step(
        &mut self,
        execution: &mut Option<SyncStepExecution<'a>>,
    ) -> Result<StreamTerminal, ApplicationError> {
        let execution = match self.take_open_iterate_step(execution, ITERATE_SYNC_ORIGIN)? {
            StepSlotState::Active(execution) => execution,
            StepSlotState::Terminal(terminal) => return Ok(terminal),
        };
        let (terminal_result, app_result) = execution.complete_and_take_app();
        self.settle_completion(terminal_result, app_result)
            .or_else(|error| self.close_with_sync_precedence(Err(error)))?;
        self.terminal(ITERATE_SYNC_ORIGIN)
    }

    pub(super) async fn complete_async_iterate_step(
        &mut self,
        execution: &mut Option<AsyncStepExecution<'a>>,
    ) -> Result<StreamTerminal, ApplicationError> {
        let execution = match self.take_open_iterate_step(execution, ITERATE_ASYNC_ORIGIN)? {
            StepSlotState::Active(execution) => execution,
            StepSlotState::Terminal(terminal) => return Ok(terminal),
        };
        let (terminal_result, app_result) = execution.complete_and_take_app().await;
        if let Err(error) = self.settle_completion(terminal_result, app_result) {
            self.close_with_async_precedence(Err(error)).await?;
        }
        self.terminal(ITERATE_ASYNC_ORIGIN)
    }

    pub(super) async fn abort_async_iterate_step(
        &mut self,
        execution: &mut Option<AsyncStepExecution<'a>>,
    ) -> Result<(), ApplicationError> {
        if let Some(step) = execution.take() {
            let (app_result, abort_hook_result) = step.abort_and_take_app_with_hook_result().await;
            self.settle_abort(app_result, abort_hook_result)?;
        }
        Ok(())
    }

    pub(super) fn advance_sync_result_stream(
        &mut self,
        target_execution: &mut Option<ActionExecution>,
        active_step: &mut Option<SyncStepExecution<'a>>,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        match self.classify_result_slot(target_execution, active_step) {
            ResultSlotStart::Done => return Ok(None),
            ResultSlotStart::FinishEmpty => {
                let _: Option<()> = self.close_with_sync_precedence(Ok(None))?;
                return Ok(None);
            }
            ResultSlotStart::Start(execution) => {
                *active_step = Some(
                    self.start_sync_step_execution(execution, RESULT_SYNC_ORIGIN)
                        .or_else(|error| self.close_with_sync_precedence(Err(error)))?,
                );
            }
            ResultSlotStart::Active => {}
        }
        if self.is_done() {
            return Ok(None);
        }
        self.advance_sync_step_execution(
            active_step,
            RESULT_SYNC_ORIGIN,
            CompletionDisposition::CloseSession,
        )
    }

    fn take_open_iterate_step<T>(
        &mut self,
        execution: &mut Option<T>,
        origin: StreamOrigin,
    ) -> Result<StepSlotState<T>, ApplicationError> {
        if execution.is_none() {
            return self
                .closed_iterate_handle_terminal(origin)
                .map(StepSlotState::Terminal);
        }
        execution
            .take()
            .map(StepSlotState::Active)
            .ok_or_else(|| stream_invariant(origin.missing_completion))
    }

    pub(super) async fn advance_async_result_stream(
        &mut self,
        target_execution: &mut Option<ActionExecution>,
        active_step: &mut Option<AsyncStepExecution<'a>>,
    ) -> Result<Option<StreamItem>, ApplicationError> {
        match self.classify_result_slot(target_execution, active_step) {
            ResultSlotStart::Done => return Ok(None),
            ResultSlotStart::FinishEmpty => {
                let _: Option<()> = self.close_with_async_precedence(Ok(None)).await?;
                return Ok(None);
            }
            ResultSlotStart::Start(execution) => {
                *active_step = Some(
                    match self
                        .start_async_step_execution(execution, RESULT_ASYNC_ORIGIN)
                        .await
                    {
                        Ok(step) => step,
                        Err(error) => return self.close_with_async_precedence(Err(error)).await,
                    },
                );
            }
            ResultSlotStart::Active => {}
        }
        if self.is_done() {
            return Ok(None);
        }

        self.advance_async_step_execution(
            active_step,
            RESULT_ASYNC_ORIGIN,
            CompletionDisposition::CloseSession,
        )
        .await
    }
}
