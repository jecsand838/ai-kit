use crate::config::{TelemetryConfigLoad, TelemetryDisabledReason, TelemetryReadyConfig};
use opentelemetry::logs::{LogRecord as _, Logger as _, LoggerProvider as _, Severity};
use opentelemetry::trace::{Span as _, Tracer as _, TracerProvider as _};
use opentelemetry::KeyValue;
use opentelemetry_sdk::logs::SdkLoggerProvider;
use opentelemetry_sdk::trace::SdkTracerProvider;
use rurr_otel::{build_otlp_logger_provider, build_otlp_tracer_provider, OtlpConfig};
use std::fmt::{Display, Formatter};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::LazyLock;
use std::time::SystemTime;

const CLI_COMMAND_EVENT: &str = "os_burr_cli_command";
const MAX_SESSION_EVENTS: usize = 10;
const TELEMETRY_VERSION: &str = "0.1.0";
const TELEMETRY_LOGGER_NAME: &str = "rurr-telemetry";

static PROGRAMMATIC_DISABLE: AtomicBool = AtomicBool::new(false);
static RUNTIME: LazyLock<TelemetryRuntime> = LazyLock::new(TelemetryRuntime::from_process);

#[derive(Debug)]
struct TelemetryRuntime {
    state: TelemetryRuntimeState,
    emitted_events: AtomicUsize,
    shutdown: AtomicBool,
}

#[derive(Debug)]
enum TelemetryRuntimeState {
    Active {
        anonymous_id: String,
        pipeline: TelemetryPipeline,
    },
    Disabled(TelemetryDisabledReason),
}

#[derive(Debug)]
struct TelemetryPipeline {
    tracer_provider: SdkTracerProvider,
    logger_provider: SdkLoggerProvider,
}

#[derive(Debug, Clone, PartialEq, Eq)]
struct TelemetryEvent {
    command: String,
    anonymous_id: String,
}

impl TelemetryRuntime {
    fn from_process() -> Self {
        let state = match TelemetryReadyConfig::load_from_process() {
            TelemetryConfigLoad::Ready(config) => match build_pipeline() {
                Ok(pipeline) => TelemetryRuntimeState::Active {
                    anonymous_id: config.anonymous_id,
                    pipeline,
                },
                Err(error) => {
                    TelemetryRuntimeState::Disabled(TelemetryDisabledReason::ProviderInit {
                        message: error.to_string(),
                    })
                }
            },
            TelemetryConfigLoad::Disabled(reason) => TelemetryRuntimeState::Disabled(reason),
        };
        Self {
            state,
            emitted_events: AtomicUsize::new(0),
            shutdown: AtomicBool::new(false),
        }
    }

    #[cfg(test)]
    fn new_for_tests(state: TelemetryRuntimeState) -> Self {
        Self {
            state,
            emitted_events: AtomicUsize::new(0),
            shutdown: AtomicBool::new(false),
        }
    }

    fn is_enabled(&self, programmatic_disabled: bool) -> bool {
        match &self.state {
            TelemetryRuntimeState::Active { .. } => {
                !programmatic_disabled
                    && !self.shutdown.load(Ordering::Relaxed)
                    && self.emitted_events.load(Ordering::Relaxed) < MAX_SESSION_EVENTS
            }
            TelemetryRuntimeState::Disabled(reason) => reason.allows_emission(),
        }
    }

    fn capture_cli_command(&self, programmatic_disabled: bool, command: &str) {
        let TelemetryRuntimeState::Active { anonymous_id, .. } = &self.state else {
            return;
        };
        self.capture_event(
            programmatic_disabled,
            TelemetryEvent {
                command: command.to_string(),
                anonymous_id: anonymous_id.clone(),
            },
        );
    }

    fn capture_event(&self, programmatic_disabled: bool, event: TelemetryEvent) {
        if !self.claim_event_slot(programmatic_disabled) {
            return;
        }
        if let TelemetryRuntimeState::Active { pipeline, .. } = &self.state {
            pipeline.emit_event(&event);
        }
    }

    fn claim_event_slot(&self, programmatic_disabled: bool) -> bool {
        if !self.is_enabled(programmatic_disabled) {
            return false;
        }
        self.emitted_events
            .fetch_update(Ordering::SeqCst, Ordering::SeqCst, |count| {
                (count < MAX_SESSION_EVENTS).then_some(count + 1)
            })
            .is_ok()
    }

    fn force_flush(&self) {
        if let TelemetryRuntimeState::Active { pipeline, .. } = &self.state {
            pipeline.force_flush();
        }
    }

    fn shutdown(&self) {
        if self.shutdown.swap(true, Ordering::SeqCst) {
            return;
        }
        if let TelemetryRuntimeState::Active { pipeline, .. } = &self.state {
            pipeline.shutdown();
        }
    }
}

impl TelemetryDisabledReason {
    fn allows_emission(&self) -> bool {
        match self {
            Self::MissingHomeDirectory
            | Self::ConfigRead { .. }
            | Self::ConfigWrite { .. }
            | Self::InvalidEnablement
            | Self::TelemetryDisabled
            | Self::ProviderInit { .. } => false,
        }
    }
}

impl TelemetryPipeline {
    fn emit_event(&self, event: &TelemetryEvent) {
        let tracer = self.tracer_provider.tracer(TELEMETRY_LOGGER_NAME);
        let logger = self.logger_provider.logger(TELEMETRY_LOGGER_NAME);
        let mut span = tracer.start(CLI_COMMAND_EVENT);
        for attribute in event.attributes() {
            span.set_attribute(attribute);
        }

        let span_context = span.span_context().clone();
        let mut record = logger.create_log_record();
        record.set_event_name(CLI_COMMAND_EVENT);
        record.set_target(TELEMETRY_LOGGER_NAME);
        record.set_timestamp(SystemTime::now());
        record.set_observed_timestamp(SystemTime::now());
        record.set_severity_number(Severity::Info);
        record.set_severity_text(Severity::Info.name());
        record.set_body(CLI_COMMAND_EVENT.into());
        record.set_trace_context(
            span_context.trace_id(),
            span_context.span_id(),
            Some(span_context.trace_flags()),
        );
        for (key, value) in event.log_attributes() {
            record.add_attribute(key, value);
        }
        logger.emit(record);
        span.end();
    }

    fn force_flush(&self) {
        let _ = self.logger_provider.force_flush();
        let _ = self.tracer_provider.force_flush();
    }

    fn shutdown(&self) {
        self.force_flush();
        let _ = self.logger_provider.shutdown();
        let _ = self.tracer_provider.shutdown();
    }

    #[cfg(test)]
    fn new_for_tests(
        tracer_provider: SdkTracerProvider,
        logger_provider: SdkLoggerProvider,
    ) -> Self {
        Self {
            tracer_provider,
            logger_provider,
        }
    }
}

impl TelemetryEvent {
    fn attributes(&self) -> Vec<KeyValue> {
        self.log_attributes()
            .into_iter()
            .map(|(key, value)| KeyValue::new(key, value))
            .collect()
    }

    fn log_attributes(&self) -> Vec<(&'static str, String)> {
        vec![
            ("command", self.command.clone()),
            ("anonymous_id", self.anonymous_id.clone()),
            ("telemetry_version", TELEMETRY_VERSION.to_string()),
            (
                "rurr_version",
                option_env!("CARGO_PKG_VERSION")
                    .unwrap_or("unknown")
                    .to_string(),
            ),
        ]
    }
}

#[derive(Debug)]
struct TelemetryInitError {
    message: String,
}

impl Display for TelemetryInitError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.message)
    }
}

impl std::error::Error for TelemetryInitError {}

fn build_pipeline() -> Result<TelemetryPipeline, TelemetryInitError> {
    let config = OtlpConfig::default();
    let tracer_provider =
        build_otlp_tracer_provider(&config).map_err(|error| TelemetryInitError {
            message: error.to_string(),
        })?;
    let logger_provider = build_otlp_logger_provider(&config).map_err(|error| {
        let _ = tracer_provider.shutdown();
        TelemetryInitError {
            message: error.to_string(),
        }
    })?;
    Ok(TelemetryPipeline {
        tracer_provider,
        logger_provider,
    })
}

/// Disables telemetry emission for the current process.
///
/// This is a process-local override and does not rewrite the user's persisted
/// configuration file.
pub fn disable_telemetry() {
    PROGRAMMATIC_DISABLE.store(true, Ordering::SeqCst);
}

/// Returns whether telemetry is currently enabled for this process.
///
/// Invalid enablement configuration fails closed, so this returns `false` when
/// the environment or config file contains an unsupported value.
pub fn is_telemetry_enabled() -> bool {
    RUNTIME.is_enabled(PROGRAMMATIC_DISABLE.load(Ordering::Relaxed))
}

/// Emits one Burr-compatible CLI command telemetry event.
///
/// This function is best-effort: disabled telemetry, invalid local config, or
/// missing OTLP endpoint configuration never make the caller fail. The emitted
/// span and log record use the `os_burr_cli_command` event class.
///
/// # Examples
///
/// ```no_run
/// // This touches process-global telemetry state and may export to the
/// // configured OTLP endpoint, so the example is compile-checked only.
/// rurr_telemetry::capture_cli_command("serve");
/// ```
pub fn capture_cli_command(command: &str) {
    RUNTIME.capture_cli_command(PROGRAMMATIC_DISABLE.load(Ordering::Relaxed), command);
}

/// Best-effort flush for any initialized OTEL telemetry providers.
///
/// Call this near process shutdown when tests or command wrappers need to give
/// the OTLP exporters a chance to send buffered CLI events.
pub fn force_flush() {
    RUNTIME.force_flush();
}

/// Best-effort shutdown for any initialized OTEL telemetry providers.
///
/// Shutdown is idempotent and intentionally best-effort so telemetry cannot
/// turn command success into failure.
pub fn shutdown() {
    RUNTIME.shutdown();
}

#[cfg(test)]
mod tests {
    use super::{
        TelemetryDisabledReason, TelemetryPipeline, TelemetryRuntime, TelemetryRuntimeState,
        CLI_COMMAND_EVENT, MAX_SESSION_EVENTS, TELEMETRY_LOGGER_NAME, TELEMETRY_VERSION,
    };
    use opentelemetry::logs::AnyValue;
    use opentelemetry_sdk::logs::{InMemoryLogExporter, SdkLoggerProvider};
    use opentelemetry_sdk::trace::{InMemorySpanExporterBuilder, SdkTracerProvider};

    fn test_runtime() -> (
        TelemetryRuntime,
        opentelemetry_sdk::trace::InMemorySpanExporter,
        InMemoryLogExporter,
    ) {
        let span_exporter = InMemorySpanExporterBuilder::new().build();
        let log_exporter = InMemoryLogExporter::default();
        let tracer_provider = SdkTracerProvider::builder()
            .with_simple_exporter(span_exporter.clone())
            .build();
        let logger_provider = SdkLoggerProvider::builder()
            .with_simple_exporter(log_exporter.clone())
            .build();
        let runtime = TelemetryRuntime::new_for_tests(TelemetryRuntimeState::Active {
            anonymous_id: "anon-test".to_string(),
            pipeline: TelemetryPipeline::new_for_tests(tracer_provider, logger_provider),
        });
        (runtime, span_exporter, log_exporter)
    }

    fn string_attr(record: &opentelemetry_sdk::logs::SdkLogRecord, key: &str) -> Option<String> {
        record.attributes_iter().find_map(|(candidate, value)| {
            (candidate.as_str() == key).then(|| match value {
                AnyValue::String(value) => value.to_string(),
                AnyValue::Int(value) => value.to_string(),
                AnyValue::Boolean(value) => value.to_string(),
                AnyValue::Double(value) => value.to_string(),
                AnyValue::Bytes(_) | AnyValue::ListAny(_) | AnyValue::Map(_) => {
                    panic!("unexpected complex log attribute for {key}")
                }
                _ => panic!("unexpected non-exhaustive log attribute for {key}"),
            })
        })
    }

    #[test]
    fn runtime_emits_one_log_and_one_span_for_cli_events() {
        let (runtime, span_exporter, log_exporter) = test_runtime();
        runtime.capture_cli_command(false, "serve");
        runtime.force_flush();

        let spans = span_exporter
            .get_finished_spans()
            .expect("spans should be readable");
        assert_eq!(spans.len(), 1);
        assert_eq!(spans[0].name.as_ref(), CLI_COMMAND_EVENT);

        let logs = log_exporter
            .get_emitted_logs()
            .expect("logs should be readable");
        assert_eq!(logs.len(), 1);
        assert_eq!(logs[0].record.event_name(), Some(CLI_COMMAND_EVENT));
        assert_eq!(
            string_attr(&logs[0].record, "command"),
            Some("serve".to_string())
        );
        assert_eq!(
            string_attr(&logs[0].record, "anonymous_id"),
            Some("anon-test".to_string())
        );
        assert_eq!(
            string_attr(&logs[0].record, "telemetry_version"),
            Some(TELEMETRY_VERSION.to_string())
        );
        assert_eq!(
            logs[0].record.target().map(ToString::to_string),
            Some(TELEMETRY_LOGGER_NAME.to_string())
        );
        let trace_context = logs[0]
            .record
            .trace_context()
            .expect("log should carry span trace context");
        assert_eq!(trace_context.trace_id, spans[0].span_context.trace_id());
        assert_eq!(trace_context.span_id, spans[0].span_context.span_id());
    }

    #[test]
    fn runtime_respects_session_cap() {
        let (runtime, span_exporter, log_exporter) = test_runtime();
        for _ in 0..(MAX_SESSION_EVENTS + 2) {
            runtime.capture_cli_command(false, "serve");
        }
        runtime.force_flush();
        assert_eq!(
            span_exporter
                .get_finished_spans()
                .expect("spans should be readable")
                .len(),
            MAX_SESSION_EVENTS
        );
        assert_eq!(
            log_exporter
                .get_emitted_logs()
                .expect("logs should be readable")
                .len(),
            MAX_SESSION_EVENTS
        );
        assert!(!runtime.is_enabled(false));
    }

    #[test]
    fn runtime_honors_programmatic_disable_and_disabled_state() {
        let (runtime, span_exporter, log_exporter) = test_runtime();
        assert!(runtime.is_enabled(false));
        runtime.capture_cli_command(true, "serve");
        assert_eq!(
            runtime
                .emitted_events
                .load(std::sync::atomic::Ordering::Relaxed),
            0
        );
        runtime.force_flush();
        assert_eq!(
            span_exporter
                .get_finished_spans()
                .expect("spans should be readable")
                .len(),
            0
        );
        assert_eq!(
            log_exporter
                .get_emitted_logs()
                .expect("logs should be readable")
                .len(),
            0
        );

        let disabled_runtime = TelemetryRuntime::new_for_tests(TelemetryRuntimeState::Disabled(
            TelemetryDisabledReason::ProviderInit {
                message: "provider failed".to_string(),
            },
        ));
        assert!(!disabled_runtime.is_enabled(false));
        disabled_runtime.capture_cli_command(false, "serve");
        assert_eq!(
            disabled_runtime
                .emitted_events
                .load(std::sync::atomic::Ordering::Relaxed),
            0
        );
        if let TelemetryRuntimeState::Disabled(reason) = &disabled_runtime.state {
            assert_eq!(
                reason,
                &TelemetryDisabledReason::ProviderInit {
                    message: "provider failed".to_string()
                }
            );
        } else {
            panic!("runtime should remain explicitly disabled");
        }
    }

    #[test]
    fn runtime_requires_active_pipeline_before_claiming_slots() {
        let disabled_runtime = TelemetryRuntime::new_for_tests(TelemetryRuntimeState::Disabled(
            TelemetryDisabledReason::TelemetryDisabled,
        ));
        disabled_runtime.capture_cli_command(false, "serve");
        assert_eq!(
            disabled_runtime
                .emitted_events
                .load(std::sync::atomic::Ordering::Relaxed),
            0
        );
    }
}
