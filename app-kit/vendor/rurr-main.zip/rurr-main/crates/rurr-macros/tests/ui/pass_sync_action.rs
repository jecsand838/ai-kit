use indexmap::IndexMap;
use rurr_core::action::{LocalAction, ActionError, ActionResult};
use rurr_core::state::State;
use serde_json::json;

#[rurr_macros::action(reads = ["count"], writes = ["count"], tags = ["math"])]
fn my_counter(state: &State) -> Result<ActionResult, ActionError> {
    let next = state
        .get("count")
        .and_then(serde_json::Value::as_i64)
        .unwrap_or(0)
        + 1;
    let result = IndexMap::from([("count".to_string(), json!(next))]);
    Ok(ActionResult::new(result.clone(), result))
}

fn assert_action_bounds<T: LocalAction + Send + Sync>(action: &T) {
    let _ = action;
}

fn main() {
    let action = my_counter_action().expect("macro-generated action should build");
    assert_action_bounds(&action);
}
