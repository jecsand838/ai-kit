---
name: rurr-follow-up-reduction-pass
description: "Use when a prior Rurr cleanup pass landed but did not fully achieve the planned deletions, and the next residual delete-first plan must be derived from what actually remains."
---

# Rurr Follow-Up Reduction Pass

Use this skill when a prior large reduction pass did not fully complete the intended cleanup and the user wants the next pass planned from the remaining residue.

## Quick start

Load, in order:

- the original plan or prior audit
- the current workspace state
- `README.md`
- `docs/00_overview.md`
- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- relevant Burr source under `tools/burr_oracle/vendor/apache-burr/`

Load these companion skills:

- `$use-rust-best-practices-core`
- `$use-rust-best-practices-architecture`
- `$use-rust-best-practices-abstractions`

Add the wider Rust skill bundle only when the remaining work spans async, networking, dependency, or testing-heavy cleanup.

Add the relevant Rurr subsystem guardrail skill when the residue touches streaming/session behavior, anchored filesystem, persistence adapters, proc macros, structural completion, or skill-catalog files.

## When to use

Use it when the task:

- says a prior pass did not fully complete the plan
- asks what reductive work is still left after a partial implementation
- needs a narrower second or third pass rather than a fresh full-workspace plan
- needs leftover structural cleanup quantified and re-scoped

## Workflow

1. Compare the original target state to what actually landed.
2. Separate completed work, partial work, and untouched reduction pools.
3. Quantify the residual structural cleanup and the remaining expected deletion.
4. Exclude macro-based cleanup proposals; residual work must collapse into structs, enums,
   methods, or real trait boundaries.
5. Produce a narrower plan that only covers the unfinished cleanup.
6. Mark the specific legacy families that must disappear for the follow-up pass to count as complete.
7. Name the subsystem guardrail skills needed for the residual pass.

## Output contract

Return:

- what was already completed
- what is only partially completed
- what remains structurally unfinished
- the expected residual deletion or reduction target
- a follow-up delete-first plan focused only on the remaining cleanup

The follow-up plan must not re-plan already completed subsystems except for minimal fallout.

## Default rules

- Prefer residual cleanup over re-explaining the whole refactor program.
- Make "still incomplete if X remains in tree" explicit.
- Treat leftover wrappers, aliases, and helper families as unfinished work even if gates are green.
- Treat newly introduced helper macros or macro helper crates as unfinished cleanup, not a valid
  reduction.
- Preserve the same guardrail and parity boundaries as the original cleanup effort.

## Do not use this skill alone when

- the user needs the initial audit before any pass exists: also use `$rurr-burr-parity-reduction-audit`
- the remaining cleanup depends on a subsystem-level Rurr versus Burr comparison: also use `$rurr-burr-source-parity-walk`
- the user wants a fresh full-batch plan instead of residual cleanup: also use `$rurr-delete-first-refactor-plan`
- the user wants implementation of the follow-up pass: also use `$rurr-delete-first-refactor-plan` in implementation mode
