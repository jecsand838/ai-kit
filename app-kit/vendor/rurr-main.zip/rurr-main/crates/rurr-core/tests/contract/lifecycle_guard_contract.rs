use crate::test_support::{run_subprocess_fixture, subprocess_fixture_enabled};
use indexmap::IndexMap;
use rurr_core::lifecycle::LifecycleError;
use rurr_core::lifecycle::{
    AsyncLifecycleAdapter, ExecuteCallContext, ExecuteCallGuard, LifecycleAdapterSet,
    PostStepContext, PreStepContext, StepGuard, StepOutcome, StreamContext, StreamGuard,
    SyncLifecycleAdapter,
};
use rurr_core::state::State;
use serde_json::{json, Value};
use std::panic::{self, AssertUnwindSafe};
use std::sync::atomic::AtomicBool;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::time::SystemTime;

#[derive(Debug, Default)]
struct ExecuteCallCounts {
    pre: AtomicUsize,
    post: AtomicUsize,
}

#[derive(Debug, Default)]
struct StepCounts {
    pre: AtomicUsize,
    post: AtomicUsize,
}

#[derive(Debug, Default)]
struct StreamCounts {
    pre: AtomicUsize,
    post: AtomicUsize,
}

#[derive(Debug)]
struct ExecuteCallCountingAdapter {
    counts: Arc<ExecuteCallCounts>,
}

impl ExecuteCallCountingAdapter {
    fn new(counts: Arc<ExecuteCallCounts>) -> Self {
        Self { counts }
    }
}

impl SyncLifecycleAdapter for ExecuteCallCountingAdapter {
    fn pre_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.counts.pre.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }

    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.counts.post.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
}

#[derive(Debug)]
struct StepCountingAdapter {
    counts: Arc<StepCounts>,
}

impl StepCountingAdapter {
    fn new(counts: Arc<StepCounts>) -> Self {
        Self { counts }
    }
}

impl SyncLifecycleAdapter for StepCountingAdapter {
    fn pre_run_step(&self, _context: &PreStepContext) -> Result<(), LifecycleError> {
        self.counts.pre.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }

    fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        self.counts.post.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
}

#[derive(Debug)]
struct StreamCountingAdapter {
    counts: Arc<StreamCounts>,
}

impl StreamCountingAdapter {
    fn new(counts: Arc<StreamCounts>) -> Self {
        Self { counts }
    }
}

impl SyncLifecycleAdapter for StreamCountingAdapter {
    fn pre_start_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.counts.pre.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }

    fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.counts.post.fetch_add(1, Ordering::SeqCst);
        Ok(())
    }
}

#[derive(Debug, Default)]
struct ExecuteCallPanicState {
    post: AtomicUsize,
    did_panic: AtomicBool,
}

#[derive(Debug)]
struct ExecuteCallPanicOnceAdapter {
    state: Arc<ExecuteCallPanicState>,
}

impl ExecuteCallPanicOnceAdapter {
    fn new(state: Arc<ExecuteCallPanicState>) -> Self {
        Self { state }
    }
}

impl SyncLifecycleAdapter for ExecuteCallPanicOnceAdapter {
    fn post_execute_call(&self, _context: &ExecuteCallContext) -> Result<(), LifecycleError> {
        self.state.post.fetch_add(1, Ordering::SeqCst);
        if !self.state.did_panic.swap(true, Ordering::SeqCst) {
            panic!("intentional panic in execute_call post hook");
        }
        Ok(())
    }
}

#[derive(Debug, Default)]
struct StepPanicState {
    post: AtomicUsize,
    did_panic: AtomicBool,
}

#[derive(Debug)]
struct StepPanicOnceAdapter {
    state: Arc<StepPanicState>,
}

impl StepPanicOnceAdapter {
    fn new(state: Arc<StepPanicState>) -> Self {
        Self { state }
    }
}

impl SyncLifecycleAdapter for StepPanicOnceAdapter {
    fn post_run_step(&self, _context: &PostStepContext) -> Result<(), LifecycleError> {
        self.state.post.fetch_add(1, Ordering::SeqCst);
        if !self.state.did_panic.swap(true, Ordering::SeqCst) {
            panic!("intentional panic in step post hook");
        }
        Ok(())
    }
}

#[derive(Debug, Default)]
struct StepPostContextRecorder {
    post_contexts: Mutex<Vec<PostStepContext>>,
}

impl StepPostContextRecorder {
    fn snapshot(&self) -> Vec<PostStepContext> {
        self.post_contexts
            .lock()
            .expect("post contexts lock should not be poisoned")
            .clone()
    }
}

impl SyncLifecycleAdapter for StepPostContextRecorder {
    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.post_contexts
            .lock()
            .expect("post contexts lock should not be poisoned")
            .push(context.clone());
        Ok(())
    }
}

#[derive(Debug, Default)]
struct StepPostContextAsyncRecorder {
    sync_post_contexts: Mutex<Vec<PostStepContext>>,
    async_post_contexts: Mutex<Vec<PostStepContext>>,
}

impl StepPostContextAsyncRecorder {
    fn sync_snapshot(&self) -> Vec<PostStepContext> {
        self.sync_post_contexts
            .lock()
            .expect("sync post contexts lock should not be poisoned")
            .clone()
    }

    fn async_snapshot(&self) -> Vec<PostStepContext> {
        self.async_post_contexts
            .lock()
            .expect("async post contexts lock should not be poisoned")
            .clone()
    }
}

impl SyncLifecycleAdapter for StepPostContextAsyncRecorder {
    fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.sync_post_contexts
            .lock()
            .expect("sync post contexts lock should not be poisoned")
            .push(context.clone());
        Ok(())
    }
}

#[async_trait::async_trait]
impl AsyncLifecycleAdapter for StepPostContextAsyncRecorder {
    async fn post_run_step(&self, context: &PostStepContext) -> Result<(), LifecycleError> {
        self.async_post_contexts
            .lock()
            .expect("async post contexts lock should not be poisoned")
            .push(context.clone());
        Ok(())
    }
}

#[derive(Debug, Default)]
struct StreamPanicState {
    post: AtomicUsize,
    did_panic: AtomicBool,
}

#[derive(Debug)]
struct StreamPanicOnceAdapter {
    state: Arc<StreamPanicState>,
}

impl StreamPanicOnceAdapter {
    fn new(state: Arc<StreamPanicState>) -> Self {
        Self { state }
    }
}

impl SyncLifecycleAdapter for StreamPanicOnceAdapter {
    fn post_end_stream(&self, _context: &StreamContext) -> Result<(), LifecycleError> {
        self.state.post.fetch_add(1, Ordering::SeqCst);
        if !self.state.did_panic.swap(true, Ordering::SeqCst) {
            panic!("intentional panic in stream post hook");
        }
        Ok(())
    }
}

fn execute_context() -> ExecuteCallContext {
    ExecuteCallContext::new("app", "partition", "action", 1)
}

fn step_context() -> PreStepContext {
    PreStepContext::new("action", 1, 2, SystemTime::UNIX_EPOCH)
}

fn stream_context() -> StreamContext {
    StreamContext::new("action", 1, 99)
}

#[test]
fn execute_call_guard_drop_during_unwind_panicking_post_hook_does_not_abort_process() {
    run_subprocess_fixture(
        "contract::lifecycle_guard_contract::execute_call_guard_drop_during_unwind_panicking_post_hook_fixture",
    );
}

#[test]
fn step_guard_drop_during_unwind_panicking_post_hook_does_not_abort_process() {
    run_subprocess_fixture(
        "contract::lifecycle_guard_contract::step_guard_drop_during_unwind_panicking_post_hook_fixture",
    );
}

#[test]
fn stream_guard_drop_during_unwind_panicking_post_hook_does_not_abort_process() {
    run_subprocess_fixture(
        "contract::lifecycle_guard_contract::stream_guard_drop_during_unwind_panicking_post_hook_fixture",
    );
}

#[test]
fn execute_call_guard_drop_during_unwind_panicking_post_hook_fixture() {
    if !subprocess_fixture_enabled() {
        return;
    }

    let state = Arc::new(ExecuteCallPanicState::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(ExecuteCallPanicOnceAdapter::new(Arc::clone(
            &state,
        )))],
        Vec::new(),
    );

    let panic_result = panic::catch_unwind(AssertUnwindSafe(|| {
        let _guard = ExecuteCallGuard::start_sync(&adapter_set, execute_context())
            .expect("execute guard should start");
        panic!("intentional outer panic while execute guard is alive");
    }));

    assert!(panic_result.is_err(), "outer panic should be catchable");
    assert_eq!(
        state.post.load(Ordering::SeqCst),
        1,
        "sync post hook should run exactly once on unwind drop path"
    );
}

#[test]
fn step_guard_drop_during_unwind_panicking_post_hook_fixture() {
    if !subprocess_fixture_enabled() {
        return;
    }

    let state = Arc::new(StepPanicState::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(StepPanicOnceAdapter::new(Arc::clone(&state)))],
        Vec::new(),
    );

    let panic_result = panic::catch_unwind(AssertUnwindSafe(|| {
        let _guard =
            StepGuard::start_sync(&adapter_set, step_context()).expect("step guard should start");
        panic!("intentional outer panic while step guard is alive");
    }));

    assert!(panic_result.is_err(), "outer panic should be catchable");
    assert_eq!(
        state.post.load(Ordering::SeqCst),
        1,
        "sync post hook should run exactly once on unwind drop path"
    );
}

#[test]
fn stream_guard_drop_during_unwind_panicking_post_hook_fixture() {
    if !subprocess_fixture_enabled() {
        return;
    }

    let state = Arc::new(StreamPanicState::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(StreamPanicOnceAdapter::new(Arc::clone(&state)))],
        Vec::new(),
    );

    let panic_result = panic::catch_unwind(AssertUnwindSafe(|| {
        let _guard = StreamGuard::start_sync(&adapter_set, stream_context())
            .expect("stream guard should start");
        panic!("intentional outer panic while stream guard is alive");
    }));

    assert!(panic_result.is_err(), "outer panic should be catchable");
    assert_eq!(
        state.post.load(Ordering::SeqCst),
        1,
        "sync post hook should run exactly once on unwind drop path"
    );
}

#[test]
fn execute_call_guard_drop_fires_post_once() {
    let counts = Arc::new(ExecuteCallCounts::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(ExecuteCallCountingAdapter::new(Arc::clone(
            &counts,
        )))],
        Vec::new(),
    );

    {
        let _guard = ExecuteCallGuard::start_sync(&adapter_set, execute_context())
            .expect("execute guard should start");
        assert_eq!(counts.pre.load(Ordering::SeqCst), 1);
        assert_eq!(counts.post.load(Ordering::SeqCst), 0);
    }

    assert_eq!(counts.post.load(Ordering::SeqCst), 1);
}

#[test]
fn execute_call_guard_drop_fires_post_once_on_panic_unwind() {
    let counts = Arc::new(ExecuteCallCounts::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(ExecuteCallCountingAdapter::new(Arc::clone(
            &counts,
        )))],
        Vec::new(),
    );

    let panic_result = panic::catch_unwind(AssertUnwindSafe(|| {
        let _guard = ExecuteCallGuard::start_sync(&adapter_set, execute_context())
            .expect("execute guard should start");
        panic!("intentional panic while execute guard is alive");
    }));

    assert!(panic_result.is_err());
    assert_eq!(counts.pre.load(Ordering::SeqCst), 1);
    assert_eq!(counts.post.load(Ordering::SeqCst), 1);
}

#[test]
fn step_guard_drop_fires_post_once() {
    let counts = Arc::new(StepCounts::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(StepCountingAdapter::new(Arc::clone(&counts)))],
        Vec::new(),
    );

    {
        let _guard =
            StepGuard::start_sync(&adapter_set, step_context()).expect("step guard should start");
        assert_eq!(counts.pre.load(Ordering::SeqCst), 1);
        assert_eq!(counts.post.load(Ordering::SeqCst), 0);
    }

    assert_eq!(counts.post.load(Ordering::SeqCst), 1);
}

#[test]
fn step_guard_drop_fires_post_once_on_panic_unwind() {
    let counts = Arc::new(StepCounts::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(StepCountingAdapter::new(Arc::clone(&counts)))],
        Vec::new(),
    );

    let panic_result = panic::catch_unwind(AssertUnwindSafe(|| {
        let _guard =
            StepGuard::start_sync(&adapter_set, step_context()).expect("step guard should start");
        panic!("intentional panic while step guard is alive");
    }));

    assert!(panic_result.is_err());
    assert_eq!(counts.pre.load(Ordering::SeqCst), 1);
    assert_eq!(counts.post.load(Ordering::SeqCst), 1);
}

#[test]
fn step_guard_success_outcome_populates_post_context_payloads() {
    let recorder = Arc::new(StepPostContextRecorder::default());
    let adapter_set = LifecycleAdapterSet::new(vec![recorder.clone()], Vec::new());
    let mut guard =
        StepGuard::start_sync(&adapter_set, step_context()).expect("step guard should start");
    let state_values: IndexMap<String, Value> =
        [("count".to_string(), json!(2))].into_iter().collect();
    let state = State::new(state_values.clone());
    let result = state_values.clone();
    guard.record_outcome(StepOutcome::Success { result, state });
    guard
        .finish_sync()
        .expect("step guard should finish successfully");

    let contexts = recorder.snapshot();
    assert_eq!(contexts.len(), 1);
    assert_eq!(contexts[0].result(), Some(&state_values));
    assert_eq!(
        contexts[0]
            .state()
            .and_then(|state| state.get("count").cloned()),
        Some(json!(2))
    );
    assert_eq!(contexts[0].exception(), None);
}

#[test]
fn step_guard_error_outcome_populates_exception_and_state() {
    let recorder = Arc::new(StepPostContextRecorder::default());
    let adapter_set = LifecycleAdapterSet::new(vec![recorder.clone()], Vec::new());
    let mut guard =
        StepGuard::start_sync(&adapter_set, step_context()).expect("step guard should start");
    let state_values: IndexMap<String, Value> =
        [("count".to_string(), json!(0))].into_iter().collect();
    let state = State::new(state_values);
    guard.record_outcome(StepOutcome::Error {
        exception: "boom".to_string(),
        state,
    });
    guard
        .finish_sync()
        .expect("step guard should finish successfully");

    let contexts = recorder.snapshot();
    assert_eq!(contexts.len(), 1);
    assert_eq!(contexts[0].result(), None);
    assert_eq!(contexts[0].exception(), Some("boom"));
    assert_eq!(
        contexts[0]
            .state()
            .and_then(|state| state.get("count").cloned()),
        Some(json!(0))
    );
}

#[test]
fn step_guard_without_outcome_leaves_post_payloads_empty() {
    let recorder = Arc::new(StepPostContextRecorder::default());
    let adapter_set = LifecycleAdapterSet::new(vec![recorder.clone()], Vec::new());
    let guard =
        StepGuard::start_sync(&adapter_set, step_context()).expect("step guard should start");
    guard
        .finish_sync()
        .expect("step guard should finish successfully");

    let contexts = recorder.snapshot();
    assert_eq!(contexts.len(), 1);
    assert_eq!(contexts[0].result(), None);
    assert_eq!(contexts[0].state(), None);
    assert_eq!(contexts[0].exception(), None);
}

#[tokio::test]
async fn step_finish_async_runs_async_post_hook_with_payloads() {
    let recorder = Arc::new(StepPostContextAsyncRecorder::default());
    let sync_adapter: Arc<dyn SyncLifecycleAdapter> = recorder.clone();
    let async_adapter: Arc<dyn AsyncLifecycleAdapter> = recorder.clone();
    let adapter_set = LifecycleAdapterSet::new(vec![sync_adapter], vec![async_adapter]);
    let mut guard =
        StepGuard::start_sync(&adapter_set, step_context()).expect("step guard should start");
    let state_values: IndexMap<String, Value> =
        [("count".to_string(), json!(3))].into_iter().collect();
    let state = State::new(state_values.clone());
    let result = state_values.clone();
    guard.record_outcome(StepOutcome::Success { result, state });
    guard
        .finish_async()
        .await
        .expect("step guard should finish successfully");

    let sync_contexts = recorder.sync_snapshot();
    let async_contexts = recorder.async_snapshot();
    assert_eq!(sync_contexts.len(), 1);
    assert_eq!(async_contexts.len(), 1);

    assert_eq!(sync_contexts[0].result(), Some(&state_values));
    assert_eq!(async_contexts[0].result(), Some(&state_values));
    assert_eq!(
        sync_contexts[0]
            .state()
            .and_then(|state| state.get("count").cloned()),
        Some(json!(3))
    );
    assert_eq!(
        async_contexts[0]
            .state()
            .and_then(|state| state.get("count").cloned()),
        Some(json!(3))
    );
    assert_eq!(sync_contexts[0].exception(), None);
    assert_eq!(async_contexts[0].exception(), None);
}

#[tokio::test]
async fn step_finish_async_without_outcome_leaves_post_payloads_empty() {
    let recorder = Arc::new(StepPostContextAsyncRecorder::default());
    let sync_adapter: Arc<dyn SyncLifecycleAdapter> = recorder.clone();
    let async_adapter: Arc<dyn AsyncLifecycleAdapter> = recorder.clone();
    let adapter_set = LifecycleAdapterSet::new(vec![sync_adapter], vec![async_adapter]);
    let guard = StepGuard::start_async(&adapter_set, step_context())
        .await
        .expect("step guard should start");

    guard
        .finish_async()
        .await
        .expect("step guard should finish successfully");

    let sync_contexts = recorder.sync_snapshot();
    let async_contexts = recorder.async_snapshot();
    assert_eq!(sync_contexts.len(), 1);
    assert_eq!(async_contexts.len(), 1);
    assert_eq!(sync_contexts[0].result(), None);
    assert_eq!(sync_contexts[0].state(), None);
    assert_eq!(sync_contexts[0].exception(), None);
    assert_eq!(async_contexts[0].result(), None);
    assert_eq!(async_contexts[0].state(), None);
    assert_eq!(async_contexts[0].exception(), None);
}

#[test]
fn stream_guard_drop_fires_post_once() {
    let counts = Arc::new(StreamCounts::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(StreamCountingAdapter::new(Arc::clone(&counts)))],
        Vec::new(),
    );

    {
        let _guard = StreamGuard::start_sync(&adapter_set, stream_context())
            .expect("stream guard should start");
        assert_eq!(counts.pre.load(Ordering::SeqCst), 1);
        assert_eq!(counts.post.load(Ordering::SeqCst), 0);
    }

    assert_eq!(counts.post.load(Ordering::SeqCst), 1);
}

#[test]
fn stream_guard_drop_fires_post_once_on_panic_unwind() {
    let counts = Arc::new(StreamCounts::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(StreamCountingAdapter::new(Arc::clone(&counts)))],
        Vec::new(),
    );

    let panic_result = panic::catch_unwind(AssertUnwindSafe(|| {
        let _guard = StreamGuard::start_sync(&adapter_set, stream_context())
            .expect("stream guard should start");
        panic!("intentional panic while stream guard is alive");
    }));

    assert!(panic_result.is_err());
    assert_eq!(counts.pre.load(Ordering::SeqCst), 1);
    assert_eq!(counts.post.load(Ordering::SeqCst), 1);
}

#[tokio::test]
async fn execute_call_finish_async_panic_does_not_reenter_sync_post_hook() {
    let state = Arc::new(ExecuteCallPanicState::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(ExecuteCallPanicOnceAdapter::new(Arc::clone(
            &state,
        )))],
        Vec::new(),
    );

    let join_result = tokio::spawn(async move {
        let guard = ExecuteCallGuard::start_sync(&adapter_set, execute_context())
            .expect("execute guard should start");
        let _ = guard.finish_async().await;
    })
    .await;

    assert!(
        join_result.is_err() && join_result.expect_err("join should fail").is_panic(),
        "finish_async should propagate panic from sync post hook"
    );
    assert_eq!(
        state.post.load(Ordering::SeqCst),
        1,
        "sync post hook should run at most once even during unwind"
    );
}

#[tokio::test]
async fn step_finish_async_panic_does_not_reenter_sync_post_hook() {
    let state = Arc::new(StepPanicState::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(StepPanicOnceAdapter::new(Arc::clone(&state)))],
        Vec::new(),
    );

    let join_result = tokio::spawn(async move {
        let guard =
            StepGuard::start_sync(&adapter_set, step_context()).expect("step guard should start");
        let _ = guard.finish_async().await;
    })
    .await;

    assert!(
        join_result.is_err() && join_result.expect_err("join should fail").is_panic(),
        "finish_async should propagate panic from sync post hook"
    );
    assert_eq!(
        state.post.load(Ordering::SeqCst),
        1,
        "sync post hook should run at most once even during unwind"
    );
}

#[tokio::test]
async fn stream_finish_async_panic_does_not_reenter_sync_post_hook() {
    let state = Arc::new(StreamPanicState::default());
    let adapter_set = LifecycleAdapterSet::new(
        vec![Arc::new(StreamPanicOnceAdapter::new(Arc::clone(&state)))],
        Vec::new(),
    );

    let join_result = tokio::spawn(async move {
        let guard = StreamGuard::start_sync(&adapter_set, stream_context())
            .expect("stream guard should start");
        let _ = guard.finish_async().await;
    })
    .await;

    assert!(
        join_result.is_err() && join_result.expect_err("join should fail").is_panic(),
        "finish_async should propagate panic from sync post hook"
    );
    assert_eq!(
        state.post.load(Ordering::SeqCst),
        1,
        "sync post hook should run at most once even during unwind"
    );
}
