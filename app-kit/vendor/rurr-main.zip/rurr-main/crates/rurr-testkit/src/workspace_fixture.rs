use std::fs;
use std::future::Future;
use std::ops::Deref;
use std::path::{Path, PathBuf};
use std::sync::LazyLock;
use tempfile::{Builder, TempDir};
use tokio::sync::Mutex as AsyncMutex;

/// Temporary workspace directory used by tests that need an isolated current
/// directory.
pub struct TestDir {
    _root: TempDir,
    path: PathBuf,
}

impl TestDir {
    /// Creates a temporary workspace directory with the provided prefix.
    pub fn new(prefix: &str) -> Self {
        let root = Builder::new()
            .prefix(prefix)
            .tempdir()
            .expect("temp directory root should be created");
        let path = root.path().join("workspace");
        fs::create_dir(&path).expect("temp directory workspace should be created");
        Self { _root: root, path }
    }

    /// Returns the isolated workspace path.
    pub fn path(&self) -> &Path {
        &self.path
    }
}

impl AsRef<Path> for TestDir {
    fn as_ref(&self) -> &Path {
        &self.path
    }
}

impl Deref for TestDir {
    type Target = Path;

    fn deref(&self) -> &Self::Target {
        &self.path
    }
}

static CURRENT_DIR_TEST_LOCK: LazyLock<AsyncMutex<()>> = LazyLock::new(|| AsyncMutex::new(()));

struct ScopedCurrentDir {
    previous: PathBuf,
}

impl ScopedCurrentDir {
    fn set_to(path: &Path) -> Self {
        let previous = std::env::current_dir().expect("current dir should resolve");
        std::env::set_current_dir(path).expect("current dir should change");
        Self { previous }
    }
}

impl Drop for ScopedCurrentDir {
    fn drop(&mut self) {
        std::env::set_current_dir(&self.previous).expect("current dir should restore");
    }
}

/// Runs `operation` while holding a global lock and temporarily changing the
/// process current directory.
pub fn with_locked_current_dir<T>(path: &Path, operation: impl FnOnce() -> T) -> T {
    let _lock = CURRENT_DIR_TEST_LOCK.blocking_lock();
    let _guard = ScopedCurrentDir::set_to(path);
    operation()
}

/// Async variant of [`with_locked_current_dir`].
pub async fn with_locked_current_dir_async<T, F, Fut>(path: &Path, operation: F) -> T
where
    F: FnOnce() -> Fut,
    Fut: Future<Output = T>,
{
    let _lock = CURRENT_DIR_TEST_LOCK.lock().await;
    let _guard = ScopedCurrentDir::set_to(path);
    operation().await
}
