use crate::action::api::ActionInputs;
use serde_json::Value;

/// Reusable configuration for halt-capable application execution methods.
///
/// `ExecutionOptions` carries runtime inputs plus optional halt selectors for
/// run, iterate, and streaming APIs. Halt selectors are raw strings until an
/// execution method starts; at startup Rurr resolves action names directly and
/// expands Burr-style `@tag:<tag>` selectors against the application graph.
/// Unknown tags or action names fail before the first action executes.
///
/// # Examples
///
/// ```
/// use indexmap::IndexMap;
/// use rurr_core::{
///     ApplicationBuilder, Condition, ExecutionOptions, FunctionActionBuilder, Transition,
/// };
/// use serde_json::{json, Value};
///
/// let capture_prompt = FunctionActionBuilder::new()
///     .inputs(["prompt"])
///     .writes(["prompt"])
///     .build_sync(|_state, ctx| {
///         let prompt = ctx.inputs.get("prompt").cloned().unwrap_or(Value::Null);
///         IndexMap::from([("prompt".to_string(), prompt)])
///     })?;
/// let answer = FunctionActionBuilder::new()
///     .reads(["prompt"])
///     .writes(["answer"])
///     .tags(["terminal"])
///     .build_sync(|state, _ctx| {
///         let prompt = state.get("prompt").and_then(Value::as_str).unwrap_or_default();
///         IndexMap::from([("answer".to_string(), json!(format!("answering {prompt}")))])
///     })?;
///
/// let mut app = ApplicationBuilder::new()
///     .with_actions(vec![("capture_prompt", capture_prompt), ("answer", answer)])?
///     .with_transitions(vec![Transition::new(
///         "capture_prompt",
///         "answer",
///         Condition::default(),
///     )])?
///     .with_entrypoint("capture_prompt")?
///     .build()?;
///
/// let output = app.run_with_options(
///     ExecutionOptions::new()
///         .with_input("prompt", json!("hello"))
///         .halt_after(["@tag:terminal"]),
/// )?;
/// assert_eq!(output.action.as_ref().map(|action| action.name()), Some("answer"));
/// assert_eq!(output.state.get("answer"), Some(&json!("answering hello")));
/// # Ok::<(), rurr_core::ApplicationError>(())
/// ```
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ExecutionOptions {
    inputs: ActionInputs,
    halt_before: Vec<String>,
    halt_after: Vec<String>,
}

impl ExecutionOptions {
    /// Creates an empty execution configuration.
    ///
    /// Empty options supply no runtime inputs and no halt selectors.
    pub fn new() -> Self {
        Self::default()
    }

    /// Replaces the current runtime inputs.
    ///
    /// Duplicate keys follow [`IndexMap`](indexmap::IndexMap) insertion
    /// semantics: the value is replaced while the original key position is
    /// retained.
    pub fn with_inputs<I, K, V>(mut self, inputs: I) -> Self
    where
        I: IntoIterator<Item = (K, V)>,
        K: Into<String>,
        V: Into<Value>,
    {
        self.inputs = inputs
            .into_iter()
            .map(|(key, value)| (key.into(), value.into()))
            .collect();
        self
    }

    /// Creates a new configuration from runtime inputs.
    ///
    /// This is equivalent to [`ExecutionOptions::new`] followed by
    /// [`with_inputs`](Self::with_inputs).
    pub fn from_inputs<I, K, V>(inputs: I) -> Self
    where
        I: IntoIterator<Item = (K, V)>,
        K: Into<String>,
        V: Into<Value>,
    {
        Self::new().with_inputs(inputs)
    }

    /// Extends the current runtime inputs, overwriting duplicate keys.
    ///
    /// Existing keys keep their original insertion position.
    pub fn extend_inputs<I, K, V>(mut self, inputs: I) -> Self
    where
        I: IntoIterator<Item = (K, V)>,
        K: Into<String>,
        V: Into<Value>,
    {
        self.inputs.extend(
            inputs
                .into_iter()
                .map(|(key, value)| (key.into(), value.into())),
        );
        self
    }

    /// Inserts or replaces a single runtime input entry.
    ///
    /// Input names beginning with `__` are reserved by the runtime and are
    /// rejected when an execution method starts.
    pub fn with_input(mut self, key: impl Into<String>, value: impl Into<Value>) -> Self {
        self.inputs.insert(key.into(), value.into());
        self
    }

    /// Replaces the `halt_before` action/tag selector list.
    ///
    /// Selectors may be action names or Burr-style `@tag:<tag>` values. Tags
    /// are expanded against the application graph when an execution method
    /// starts. If the next action matches the resolved set, execution stops
    /// before that action runs and returns the pending action with no result.
    /// Duplicate resolved actions are deduped by first occurrence.
    pub fn halt_before<I, S>(mut self, actions: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.halt_before = actions.into_iter().map(Into::into).collect();
        self
    }

    /// Replaces the `halt_after` action/tag selector list.
    ///
    /// Selectors may be action names or Burr-style `@tag:<tag>` values. Tags
    /// are expanded against the application graph when an execution method
    /// starts. If the action that just committed matches the resolved set,
    /// execution stops after that action and returns its result. Duplicate
    /// resolved actions are deduped by first occurrence.
    pub fn halt_after<I, S>(mut self, actions: I) -> Self
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.halt_after = actions.into_iter().map(Into::into).collect();
        self
    }

    /// Returns the runtime inputs carried by these options.
    pub fn inputs(&self) -> &ActionInputs {
        &self.inputs
    }

    /// Returns raw selectors that should halt execution before they run.
    ///
    /// These are the caller-provided selectors, not graph-expanded action
    /// names. Resolution happens once per execution bootstrap.
    pub fn halt_before_selectors(&self) -> &[String] {
        &self.halt_before
    }

    /// Returns raw selectors that should halt execution after they run.
    ///
    /// These are the caller-provided selectors, not graph-expanded action
    /// names. Resolution happens once per execution bootstrap.
    pub fn halt_after_selectors(&self) -> &[String] {
        &self.halt_after
    }

    pub(crate) fn into_parts(self) -> (ActionInputs, Vec<String>, Vec<String>) {
        (self.inputs, self.halt_before, self.halt_after)
    }
}

impl<K, V> std::iter::FromIterator<(K, V)> for ExecutionOptions
where
    K: Into<String>,
    V: Into<Value>,
{
    fn from_iter<I: IntoIterator<Item = (K, V)>>(iter: I) -> Self {
        Self::from_inputs(iter)
    }
}

#[cfg(test)]
mod tests {
    use super::ExecutionOptions;
    use serde_json::json;

    #[test]
    fn default_is_empty() {
        let options = ExecutionOptions::default();

        assert!(options.inputs().is_empty());
        assert!(options.halt_before_selectors().is_empty());
        assert!(options.halt_after_selectors().is_empty());
    }

    #[test]
    fn with_inputs_accepts_plain_tuple_iterators() {
        let options = ExecutionOptions::from_inputs([("first", json!(1)), ("second", json!(2))]);

        assert_eq!(options.inputs().get("first"), Some(&json!(1)));
        assert_eq!(options.inputs().get("second"), Some(&json!(2)));
    }

    #[test]
    fn extend_inputs_merges_without_manual_indexmap_construction() {
        let options = ExecutionOptions::from_inputs([("first", json!(1))])
            .extend_inputs([("second", json!(2)), ("first", json!(3))]);

        let keys: Vec<_> = options.inputs().keys().cloned().collect();
        assert_eq!(keys, vec!["first".to_string(), "second".to_string()]);
        assert_eq!(options.inputs().get("first"), Some(&json!(3)));
        assert_eq!(options.inputs().get("second"), Some(&json!(2)));
    }

    #[test]
    fn with_input_preserves_insertion_order() {
        let options = ExecutionOptions::new()
            .with_input("first", json!(1))
            .with_input("second", json!(2));

        let keys: Vec<_> = options.inputs().keys().cloned().collect();
        assert_eq!(keys, vec!["first".to_string(), "second".to_string()]);
    }

    #[test]
    fn halt_lists_collect_owned_selectors_in_order() {
        let options = ExecutionOptions::new()
            .halt_before(["prepare", "@tag:execute"])
            .halt_after(["@tag:finish"]);

        assert_eq!(
            options.halt_before_selectors(),
            vec!["prepare".to_string(), "@tag:execute".to_string()]
        );
        assert_eq!(
            options.halt_after_selectors(),
            vec!["@tag:finish".to_string()]
        );
    }
}
