use async_trait::async_trait;
use indexmap::IndexMap;
use rurr_core::action::FunctionActionBuilder;
use rurr_core::application::Application;
use rurr_persistence::{
    AsyncBaseStateLoader, AsyncBaseStateSaver, BaseStateLoader, BaseStateSaver, PersistedStateData,
    PersistedStateStatus, PersistenceError,
};
use rurr_sqlite::{AsyncSqlitePersister, SqlitePersister};
use rurr_testkit::persistence_cases::{
    self, PersistenceLane, PersistenceOrderingLane, PersistenceReprobeLane,
};
use rurr_testkit::{test_dir, TestDir};
use rusqlite::{params, Connection};
use serde_json::json;
use std::path::PathBuf;

pub(crate) fn noop_action() -> rurr_core::FunctionAction {
    FunctionActionBuilder::new()
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("noop function action should build")
}

#[derive(Clone, Copy)]
struct RawSqliteRow<'a> {
    partition_key: &'a str,
    app_id: &'a str,
    sequence_id: i64,
    position: &'a str,
    marker: &'a str,
    created_at: &'a str,
}

pub(crate) struct SqliteTestCore {
    _temp_dir: TestDir,
    pub(crate) db_path: PathBuf,
    pub(crate) table_name: String,
}

impl SqliteTestCore {
    pub(crate) fn new(db_name: &str, table_name: &str) -> Self {
        let temp_dir = test_dir().expect("temp dir should be created");
        let db_path = temp_dir.join(db_name);
        Self {
            _temp_dir: temp_dir,
            db_path,
            table_name: table_name.to_string(),
        }
    }

    pub(crate) fn seed_latest_partition_order_fixture(&self) -> Result<(), PersistenceError> {
        self.seed_completed_states(&[
            raw_sqlite_row(
                "partition",
                "older_created_at_higher_seq",
                99,
                "step_old",
                "old",
                "2026-02-20 00:00:00",
            ),
            raw_sqlite_row(
                "partition",
                "newer_created_at_lower_seq",
                1,
                "step_new",
                "new",
                "2026-02-21 00:00:00",
            ),
        ]);
        Ok(())
    }

    pub(crate) fn seed_exact_sequence_order_fixture(&self) -> Result<(), PersistenceError> {
        self.seed_completed_states(&[
            raw_sqlite_row(
                "partition",
                "app_id",
                7,
                "step_z",
                "older",
                "2026-02-20 00:00:00",
            ),
            raw_sqlite_row(
                "partition",
                "app_id",
                7,
                "step_a",
                "newer_low_position",
                "2026-02-21 00:00:00",
            ),
            raw_sqlite_row(
                "partition",
                "app_id",
                7,
                "step_b",
                "newer_high_position",
                "2026-02-21 00:00:00",
            ),
        ]);
        Ok(())
    }

    pub(crate) fn seed_list_app_ids_order_fixture(&self) -> Result<Vec<String>, PersistenceError> {
        self.seed_completed_states(&[
            raw_sqlite_row(
                "partition",
                "older_created_at_higher_seq",
                99,
                "step_1",
                "old",
                "2026-02-20 00:00:00",
            ),
            raw_sqlite_row(
                "partition",
                "newer_created_at_lower_seq",
                1,
                "step_1",
                "new",
                "2026-02-21 00:00:00",
            ),
        ]);

        Ok(vec![
            "newer_created_at_lower_seq".to_string(),
            "older_created_at_higher_seq".to_string(),
        ])
    }

    fn seed_completed_states(&self, rows: &[RawSqliteRow<'_>]) {
        for row in rows {
            self.insert_raw_completed_state(*row);
        }
    }

    fn insert_raw_completed_state(&self, row: RawSqliteRow<'_>) {
        let connection = Connection::open(&self.db_path).expect("connection should open");
        let query = format!(
            "INSERT INTO {} (partition_key, app_id, sequence_id, position, status, state, created_at) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
            self.table_name
        );
        let state_json = format!(r#"{{"marker":"{}"}}"#, row.marker);

        connection
            .execute(
                &query,
                params![
                    row.partition_key,
                    row.app_id,
                    row.sequence_id,
                    row.position,
                    "completed",
                    state_json,
                    row.created_at
                ],
            )
            .expect("raw insert should succeed");
    }
}

fn raw_sqlite_row(
    partition_key: &'static str,
    app_id: &'static str,
    sequence_id: i64,
    position: &'static str,
    marker: &'static str,
    created_at: &'static str,
) -> RawSqliteRow<'static> {
    RawSqliteRow {
        partition_key,
        app_id,
        sequence_id,
        position,
        marker,
        created_at,
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum SqliteLaneMode {
    Sync,
    Async,
}

enum SqliteTestPersister {
    Sync(SqlitePersister),
    Async(AsyncSqlitePersister),
}

impl SqliteTestPersister {
    fn new(mode: SqliteLaneMode, core: &SqliteTestCore) -> Self {
        match mode {
            SqliteLaneMode::Sync => Self::Sync(
                SqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
                    &core.db_path,
                    &core.table_name,
                ))
                .expect("persister should create"),
            ),
            SqliteLaneMode::Async => Self::Async(
                AsyncSqlitePersister::new(rurr_sqlite::SqlitePersisterConfig::new(
                    db_path_str(core),
                    &core.table_name,
                ))
                .expect("persister should create"),
            ),
        }
    }

    async fn initialize(&self) -> Result<(), PersistenceError> {
        match self {
            Self::Sync(persister) => persister.initialize(),
            Self::Async(persister) => persister.initialize().await,
        }
    }

    async fn is_initialized(&self) -> Result<bool, PersistenceError> {
        match self {
            Self::Sync(persister) => persister.is_initialized(),
            Self::Async(persister) => persister.is_initialized().await,
        }
    }

    async fn cleanup(&self) -> Result<(), PersistenceError> {
        match self {
            Self::Sync(persister) => persister.cleanup(),
            Self::Async(persister) => persister.close().await,
        }
    }

    async fn save(
        &self,
        partition_key: Option<&str>,
        app_id: &str,
        sequence_id: u64,
        position: &str,
        state: persistence_cases::PersistenceStateMap,
        status: PersistedStateStatus,
    ) -> Result<(), PersistenceError> {
        match self {
            Self::Sync(persister) => {
                persister.save(partition_key, app_id, sequence_id, position, state, status)
            }
            Self::Async(persister) => {
                persister
                    .save(partition_key, app_id, sequence_id, position, state, status)
                    .await
            }
        }
    }

    async fn load(
        &self,
        partition_key: Option<&str>,
        app_id: Option<&str>,
        sequence_id: Option<u64>,
    ) -> Result<Option<PersistedStateData>, PersistenceError> {
        match self {
            Self::Sync(persister) => persister.load(partition_key, app_id, sequence_id),
            Self::Async(persister) => persister.load(partition_key, app_id, sequence_id).await,
        }
    }

    async fn list_app_ids(
        &self,
        partition_key: Option<&str>,
    ) -> Result<Vec<String>, PersistenceError> {
        match self {
            Self::Sync(persister) => persister.list_app_ids(partition_key),
            Self::Async(persister) => persister.list_app_ids(partition_key).await,
        }
    }
}

struct SqliteLaneCore {
    core: SqliteTestCore,
    persister: SqliteTestPersister,
}

impl SqliteLaneCore {
    fn new(mode: SqliteLaneMode, db_name: &str, table_name: &str) -> Self {
        let core = SqliteTestCore::new(db_name, table_name);
        let persister = SqliteTestPersister::new(mode, &core);
        Self { core, persister }
    }
}

async fn external_initialize(
    mode: SqliteLaneMode,
    core: &SqliteTestCore,
) -> Result<(), PersistenceError> {
    let external_initializer = SqliteTestPersister::new(mode, core);
    external_initializer
        .initialize()
        .await
        .expect("external initialize should succeed");
    external_initializer
        .cleanup()
        .await
        .expect("external cleanup should succeed");
    Ok(())
}

async fn drop_storage(core: &SqliteTestCore) {
    let connection = rusqlite::Connection::open(&core.db_path).expect("connection should open");
    connection
        .execute_batch(&format!("DROP TABLE {}", core.table_name))
        .expect("table drop should succeed");
}

pub(crate) fn assert_resumed_state(app: &Application, sequence_id: u64) {
    assert_eq!(
        app.state()
            .require("chat_history")
            .expect("state should contain key 'chat_history'"),
        &json!([1, 2])
    );
    assert_eq!(
        app.state()
            .require("__SEQUENCE_ID")
            .expect("state should contain key '__SEQUENCE_ID'"),
        &json!(sequence_id)
    );
    assert_eq!(
        app.state()
            .require("__PRIOR_STEP")
            .expect("state should contain key '__PRIOR_STEP'"),
        &json!("noop")
    );
}

pub(crate) struct SqliteSyncLane(SqliteLaneCore);

impl SqliteSyncLane {
    pub(crate) fn new(db_name: &str, table_name: &str) -> Self {
        Self(SqliteLaneCore::new(
            SqliteLaneMode::Sync,
            db_name,
            table_name,
        ))
    }
}

pub(crate) struct SqliteAsyncLane(SqliteLaneCore);

impl SqliteAsyncLane {
    pub(crate) fn new(db_name: &str, table_name: &str) -> Self {
        Self(SqliteLaneCore::new(
            SqliteLaneMode::Async,
            db_name,
            table_name,
        ))
    }
}

macro_rules! impl_sqlite_lane {
    ($lane:ty, $mode:expr, $expected_none_partition_app_ids:expr) => {
        #[async_trait(?Send)]
        impl PersistenceLane for $lane {
            fn expected_none_partition_app_ids(&self) -> Vec<String> {
                $expected_none_partition_app_ids
            }

            async fn initialize(&self) -> Result<(), PersistenceError> {
                self.0.persister.initialize().await
            }

            async fn is_initialized(&self) -> Result<bool, PersistenceError> {
                self.0.persister.is_initialized().await
            }

            async fn cleanup(&self) -> Result<(), PersistenceError> {
                self.0.persister.cleanup().await
            }

            async fn save(
                &self,
                partition_key: Option<&str>,
                app_id: &str,
                sequence_id: u64,
                position: &str,
                state: persistence_cases::PersistenceStateMap,
                status: PersistedStateStatus,
            ) -> Result<(), PersistenceError> {
                self.0
                    .persister
                    .save(partition_key, app_id, sequence_id, position, state, status)
                    .await
            }

            async fn load(
                &self,
                partition_key: Option<&str>,
                app_id: Option<&str>,
                sequence_id: Option<u64>,
            ) -> Result<Option<PersistedStateData>, PersistenceError> {
                self.0
                    .persister
                    .load(partition_key, app_id, sequence_id)
                    .await
            }

            async fn list_app_ids(
                &self,
                partition_key: Option<&str>,
            ) -> Result<Vec<String>, PersistenceError> {
                self.0.persister.list_app_ids(partition_key).await
            }
        }

        #[async_trait(?Send)]
        impl PersistenceOrderingLane for $lane {
            async fn seed_latest_partition_order_fixture(&self) -> Result<(), PersistenceError> {
                self.0.core.seed_latest_partition_order_fixture()
            }

            async fn seed_exact_sequence_order_fixture(&self) -> Result<(), PersistenceError> {
                self.0.core.seed_exact_sequence_order_fixture()
            }

            async fn seed_list_app_ids_order_fixture(
                &self,
            ) -> Result<Vec<String>, PersistenceError> {
                self.0.core.seed_list_app_ids_order_fixture()
            }
        }

        #[async_trait(?Send)]
        impl PersistenceReprobeLane for $lane {
            async fn external_initialize(&self) -> Result<(), PersistenceError> {
                external_initialize($mode, &self.0.core).await
            }

            async fn drop_storage(&self) {
                drop_storage(&self.0.core).await
            }
        }
    };
}

impl_sqlite_lane!(
    SqliteSyncLane,
    SqliteLaneMode::Sync,
    vec!["app_id_none".to_string(), "app_id_none_2".to_string()]
);
impl_sqlite_lane!(SqliteAsyncLane, SqliteLaneMode::Async, Vec::new());

pub(crate) fn db_path_str(core: &SqliteTestCore) -> String {
    core.db_path
        .to_str()
        .expect("temp db path should be valid UTF-8")
        .to_string()
}

const _: () = {
    let _ = SqliteSyncLane::new;
    let _ = SqliteAsyncLane::new;
    let _ = db_path_str;
};
