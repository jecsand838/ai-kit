#![deny(missing_docs)]

//! Command-line interface for serving the tracking UI, building UI assets, and
//! running workspace test-case helpers.
//!
//! This crate backs the public `rurr` executable while also providing a stable
//! rustdoc home at `rurr_cli` for local workspace documentation builds. CLI
//! command telemetry is emitted explicitly after successful commands; core
//! application execution does not emit hidden anonymous telemetry.
//!
//! `serve` defaults to the embedded UI and local tracking backend. S3 serving is
//! selected explicitly with CLI/backend configuration and uses the tracking
//! server's S3 backend rather than changing the default local path.

mod commands;

use clap::{ArgAction, Args, Parser, Subcommand, ValueEnum};
use rurr_telemetry::capture_cli_command;
use std::path::PathBuf;

#[derive(Debug, Parser)]
#[command(name = "rurr", version, about = "Rurr CLI")]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Debug, Subcommand)]
enum Command {
    Serve(ServeArgs),
    Ui(UiCommand),
    TestCase(TestCaseCommand),
    Admin(AdminCommand),
}

type CommandResult = Result<(), Box<dyn std::error::Error>>;

impl Command {
    async fn execute(self) -> CommandResult {
        match self {
            Command::Serve(args) => commands::serve::run(args).await,
            Command::Ui(UiCommand {
                command: UiSubcommand::Build(args),
            }) => emit_on_success(commands::ui::build(args), || {
                capture_cli_command("ui.build");
            }),
            Command::TestCase(TestCaseCommand {
                command: TestCaseSubcommand::Create(args),
            }) => emit_on_success(commands::test_case::create(args), || {
                capture_cli_command("test-case.create");
            }),
            Command::Admin(AdminCommand {
                command: AdminSubcommand::Publish(args),
            }) => emit_on_success(commands::admin::publish(args), || {
                capture_cli_command("admin.publish");
            }),
        }
    }
}

fn emit_on_success<T, E>(result: Result<T, E>, on_success: impl FnOnce()) -> Result<T, E> {
    match result {
        Ok(value) => {
            on_success();
            Ok(value)
        }
        Err(error) => Err(error),
    }
}

#[derive(Debug, Clone, Args)]
struct ServeArgs {
    #[arg(long, value_enum)]
    backend: Option<ServeBackend>,
    #[arg(long, default_value = "127.0.0.1")]
    host: String,
    #[arg(long, default_value_t = 7241)]
    port: u16,
    #[arg(long)]
    storage_dir: Option<PathBuf>,
    #[arg(long)]
    ui_dir: Option<PathBuf>,
    #[arg(long)]
    s3_bucket: Option<String>,
    #[arg(long)]
    s3_region: Option<String>,
    #[arg(long)]
    s3_endpoint_url: Option<String>,
    #[arg(long, value_enum)]
    s3_addressing_style: Option<ServeS3AddressingStyle>,
    #[arg(long)]
    s3_db_path: Option<PathBuf>,
    #[arg(long)]
    s3_access_key_id: Option<String>,
    #[arg(long)]
    s3_secret_access_key: Option<String>,
    #[arg(long)]
    s3_session_token: Option<String>,
    #[arg(long)]
    s3_data_prefix: Option<String>,
    #[arg(long)]
    s3_snapshot_prefix: Option<String>,
    #[arg(long, value_parser = clap::value_parser!(bool))]
    s3_load_snapshot_on_start: Option<bool>,
    #[arg(long)]
    s3_prior_snapshots_to_keep: Option<usize>,
    #[arg(long)]
    s3_update_interval_ms: Option<u64>,
    #[arg(long)]
    s3_snapshot_interval_ms: Option<u64>,
    #[arg(long)]
    s3_max_paths_per_project: Option<usize>,
    #[arg(long)]
    s3_aws_max_concurrency: Option<usize>,
    #[arg(long)]
    s3_list_page_size: Option<i32>,
    #[arg(
        long = "open",
        default_value_t = false,
        action = ArgAction::SetTrue,
        conflicts_with = "no_open"
    )]
    open: bool,
    #[arg(
        long = "no-open",
        default_value_t = false,
        action = ArgAction::SetTrue,
        conflicts_with = "open"
    )]
    no_open: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
enum ServeBackend {
    Local,
    S3,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
enum ServeS3AddressingStyle {
    VirtualHosted,
    PathStyle,
}

#[derive(Debug, Subcommand)]
enum UiSubcommand {
    Build(UiBuildArgs),
}

#[derive(Debug, Args)]
struct UiCommand {
    #[command(subcommand)]
    command: UiSubcommand,
}

#[derive(Debug, Clone, Args)]
struct UiBuildArgs {
    #[arg(long)]
    out_dir: Option<PathBuf>,
}

#[derive(Debug, Subcommand)]
enum TestCaseSubcommand {
    Create(TestCaseCreateArgs),
}

#[derive(Debug, Args)]
struct TestCaseCommand {
    #[command(subcommand)]
    command: TestCaseSubcommand,
}

#[derive(Debug, Clone, Args)]
struct TestCaseCreateArgs {
    #[arg(long)]
    storage_dir: PathBuf,
    #[arg(long)]
    project_name: String,
    #[arg(long)]
    partition_key: Option<String>,
    #[arg(long)]
    app_id: String,
    #[arg(long)]
    sequence_id: u64,
    #[arg(long)]
    target_file_name: Option<PathBuf>,
    #[arg(long)]
    action_name: Option<String>,
    #[arg(long)]
    serde_decoder: Option<PathBuf>,
    #[arg(long, action = ArgAction::Append, num_args = 1, allow_hyphen_values = true)]
    serde_decoder_arg: Vec<String>,
}

#[derive(Debug, Subcommand)]
enum AdminSubcommand {
    Publish(AdminPublishArgs),
}

#[derive(Debug, Args)]
struct AdminCommand {
    #[command(subcommand)]
    command: AdminSubcommand,
}

#[derive(Debug, Clone, Args)]
struct AdminPublishArgs {
    #[arg(long)]
    dist_dir: Option<PathBuf>,
}

/// Parses CLI arguments and runs the selected subcommand.
///
/// This is the library entrypoint used by `src/main.rs`.
///
/// # Examples
///
/// ```no_run
/// # #[tokio::main(flavor = "current_thread")]
/// # async fn main() -> Result<(), Box<dyn std::error::Error>> {
/// // `run_cli` reads process arguments and may start a server, so Rustdoc
/// // compile-checks the shape without running it.
/// let _ = rurr_cli::run_cli().await;
/// # Ok(())
/// # }
/// ```
pub async fn run_cli() -> Result<(), Box<dyn std::error::Error>> {
    let cli = Cli::parse();
    cli.command.execute().await
}

#[cfg(test)]
mod tests {
    use super::emit_on_success;
    use std::cell::Cell;

    #[test]
    fn emit_on_success_runs_callback_for_ok_result() {
        let emitted = Cell::new(0);

        let result: Result<(), &'static str> = emit_on_success(Ok(()), || {
            emitted.set(emitted.get() + 1);
        });

        assert!(result.is_ok());
        assert_eq!(emitted.get(), 1);
    }

    #[test]
    fn emit_on_success_skips_callback_for_error_result() {
        let emitted = Cell::new(0);

        let result: Result<(), &'static str> = emit_on_success(Err("boom"), || {
            emitted.set(emitted.get() + 1);
        });

        assert_eq!(result, Err("boom"));
        assert_eq!(emitted.get(), 0);
    }
}
