use crate::support::{
    local_client_actions::{streaming_action, StreamingLane, StreamingScript},
    tracking_actions::build_single_step_sync_action,
};
use rurr_core::action::{FunctionAction, StreamItem};
use rurr_core::application::{AStreamResult, StreamResult};
use rurr_core::lifecycle::{AsyncLifecycleAdapter, LifecycleAdapterSet, SyncLifecycleAdapter};
use rurr_core::tracking::TrackingError;
use rurr_testkit::application_fixture::build_sync_app;
pub(crate) use rurr_testkit::tracking_fixture::{
    app_dir, app_log_path, assert_log_event_counts, assert_log_types, count_log_entries,
    counter_end_entry, counter_end_entry_with_exception, ensure_app_dir, log_type_sequence,
    read_app_log, read_app_log_if_exists, register_application, span_events, stream_items_streamed,
    tracker, write_app_log_entries,
};
use rurr_testkit::tracking_fixture::{registered_async_app, registered_sync_app, seeded_app_dir};
use serde_json::Value;
use std::path::Path;
use std::sync::Arc;

pub(crate) fn assert_stream_log(
    storage_root: &Path,
    project: &str,
    app_id: &str,
    expected_types: &[&str],
    items_streamed: i64,
) -> Vec<Value> {
    let log_lines = read_app_log(storage_root, project, app_id);
    assert_log_types(&log_lines, expected_types);
    assert_eq!(stream_items_streamed(&log_lines), items_streamed);
    log_lines
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum StreamFixture {
    TwoStepCommit,
    TerminalOnly { final_count: i64 },
    ErrorAfterIntermediate { message: &'static str },
}

impl StreamFixture {
    fn into_script(self) -> StreamingScript {
        match self {
            Self::TwoStepCommit => StreamingScript::TwoStepCommit,
            Self::TerminalOnly { final_count } => StreamingScript::TerminalOnly {
                terminal_count: final_count,
            },
            Self::ErrorAfterIntermediate { message } => StreamingScript::ErrorAfterIntermediate {
                error_message: message,
            },
        }
    }

    pub(crate) fn expected_types(self) -> &'static [&'static str] {
        match self {
            Self::TwoStepCommit | Self::ErrorAfterIntermediate { .. } => &[
                "begin_entry",
                "begin_stream",
                "first_item_stream",
                "end_entry",
                "end_stream",
            ],
            Self::TerminalOnly { .. } => {
                &["begin_entry", "begin_stream", "end_entry", "end_stream"]
            }
        }
    }

    pub(crate) fn expected_items_streamed(self) -> i64 {
        match self {
            Self::TerminalOnly { .. } => 0,
            Self::TwoStepCommit | Self::ErrorAfterIntermediate { .. } => 1,
        }
    }
}

pub(crate) fn assert_exception_logged(log_lines: &[Value]) {
    let end_entry = log_lines
        .iter()
        .find(|line| line["type"] == "end_entry")
        .expect("end_entry should exist");
    assert!(
        end_entry.get("exception").is_some() && !end_entry["exception"].is_null(),
        "end_entry.exception should be populated for stream failures"
    );
}

fn assert_success_end_entry(log_lines: &[Value], expected_count: i64) {
    let end_entry = log_lines
        .iter()
        .find(|line| line["type"] == "end_entry")
        .expect("end_entry should exist");
    assert_eq!(
        end_entry["result"]["count"].as_i64(),
        Some(expected_count),
        "stream success end_entry.result.count should match terminal output"
    );
    assert_eq!(
        end_entry["state"]["count"].as_i64(),
        Some(expected_count),
        "stream success end_entry.state.count should match committed terminal state"
    );
    assert_eq!(
        end_entry["state"]["__SEQUENCE_ID"].as_i64(),
        Some(0),
        "stream success end_entry.state should retain reserved sequence metadata"
    );
    assert_eq!(
        end_entry["state"]["__PRIOR_STEP"].as_str(),
        Some("stream"),
        "stream success end_entry.state should retain prior-step metadata"
    );
}

fn success_terminal_count(fixture: StreamFixture) -> Option<i64> {
    match fixture {
        StreamFixture::TwoStepCommit => Some(2),
        StreamFixture::TerminalOnly { final_count } => Some(final_count),
        StreamFixture::ErrorAfterIntermediate { .. } => None,
    }
}

fn required_count(value: Option<&Value>, context: &str) -> i64 {
    value
        .and_then(Value::as_i64)
        .unwrap_or_else(|| panic!("{context}"))
}

fn sync_stream_fixture(fixture: StreamFixture) -> FunctionAction {
    streaming_action(fixture.into_script(), StreamingLane::Sync)
}

fn async_stream_fixture(fixture: StreamFixture) -> FunctionAction {
    streaming_action(fixture.into_script(), StreamingLane::Async)
}

#[derive(Debug, PartialEq)]
struct StreamObservation {
    yielded_counts: Vec<i64>,
    final_count: Option<i64>,
    error_message: Option<String>,
}

enum TrackingStreamHandle<'a> {
    Sync(StreamResult<'a>),
    Async(AStreamResult<'a>),
}

impl TrackingStreamHandle<'_> {
    async fn next_item(
        &mut self,
    ) -> Result<Option<StreamItem>, rurr_core::application::ApplicationError> {
        match self {
            Self::Sync(handle) => handle.next_item(),
            Self::Async(handle) => handle.next_item().await,
        }
    }

    async fn get(
        &mut self,
    ) -> Result<
        (Option<StreamItem>, rurr_core::state::State),
        rurr_core::application::ApplicationError,
    > {
        match self {
            Self::Sync(handle) => handle.get(),
            Self::Async(handle) => handle.get().await,
        }
    }
}

async fn observe_stream_handle(
    fixture: StreamFixture,
    handle: &mut TrackingStreamHandle<'_>,
) -> StreamObservation {
    match fixture {
        StreamFixture::TwoStepCommit => StreamObservation {
            yielded_counts: vec![required_count(
                handle
                    .next_item()
                    .await
                    .expect("first stream item should exist")
                    .expect("first stream item should succeed")
                    .get("count"),
                "first stream item count should be i64",
            )],
            final_count: {
                assert!(
                    handle
                        .next_item()
                        .await
                        .expect("terminal stream item should not error")
                        .is_none(),
                    "terminal stream item should not be yielded"
                );
                let (_result, state) = handle.get().await.expect("get should succeed");
                Some(required_count(
                    state.get("count"),
                    "final state count should be i64",
                ))
            },
            error_message: None,
        },
        StreamFixture::TerminalOnly { .. } => StreamObservation {
            yielded_counts: {
                assert!(
                    handle
                        .next_item()
                        .await
                        .expect("terminal-only streaming action should not error")
                        .is_none(),
                    "terminal-only streaming action should not yield intermediate items"
                );
                Vec::new()
            },
            final_count: Some(required_count(
                handle
                    .get()
                    .await
                    .expect("get should succeed")
                    .1
                    .get("count"),
                "final state count should be i64",
            )),
            error_message: None,
        },
        StreamFixture::ErrorAfterIntermediate { .. } => StreamObservation {
            yielded_counts: vec![required_count(
                handle
                    .next_item()
                    .await
                    .expect("first stream item should exist")
                    .expect("first stream item should succeed")
                    .get("count"),
                "first stream item count should be i64",
            )],
            final_count: None,
            error_message: Some(
                handle
                    .next_item()
                    .await
                    .expect_err("second stream item should error")
                    .to_string(),
            ),
        },
    }
}

fn assert_stream_observation(fixture: StreamFixture, observation: &StreamObservation) {
    match fixture {
        StreamFixture::TwoStepCommit => {
            assert_eq!(observation.yielded_counts, vec![1]);
            assert_eq!(observation.final_count, Some(2));
            assert_eq!(observation.error_message, None);
        }
        StreamFixture::TerminalOnly { final_count } => {
            assert!(observation.yielded_counts.is_empty());
            assert_eq!(observation.final_count, Some(final_count));
            assert_eq!(observation.error_message, None);
        }
        StreamFixture::ErrorAfterIntermediate { message } => {
            assert_eq!(observation.yielded_counts, vec![1]);
            assert_eq!(observation.final_count, None);
            assert!(
                observation
                    .error_message
                    .as_deref()
                    .is_some_and(|error| error.contains(message)),
                "error should include stream failure detail"
            );
        }
    }
}

pub(crate) async fn assert_stream_case(
    storage_root: &Path,
    fixture: StreamFixture,
    project: &str,
    app_id: &str,
    mode: TrackingMode,
) -> Vec<Value> {
    let observation = match mode {
        TrackingMode::Sync => {
            let (_tracker, mut app) = registered_sync_app(
                project,
                storage_root,
                app_id,
                "stream",
                sync_stream_fixture(fixture),
            );

            let (_action, stream_result) =
                app.stream_result().expect("stream_result should succeed");
            let mut handle = TrackingStreamHandle::Sync(stream_result);
            observe_stream_handle(fixture, &mut handle).await
        }
        TrackingMode::Async => {
            let (_tracker, mut app) = registered_async_app(
                project,
                storage_root,
                app_id,
                "stream",
                async_stream_fixture(fixture),
            );

            let (_action, stream_result) = app
                .astream_result()
                .await
                .expect("astream_result should succeed");
            let mut handle = TrackingStreamHandle::Async(stream_result);
            observe_stream_handle(fixture, &mut handle).await
        }
    };

    assert_stream_observation(fixture, &observation);

    let log_lines = assert_stream_log(
        storage_root,
        project,
        app_id,
        fixture.expected_types(),
        fixture.expected_items_streamed(),
    );
    if let Some(expected_count) = success_terminal_count(fixture) {
        assert_success_end_entry(&log_lines, expected_count);
    } else {
        assert_exception_logged(&log_lines);
    }
    log_lines
}

pub(crate) fn count_app_log_entries(
    storage_root: &Path,
    project: &str,
    app_id: &str,
    event_types: &[&str],
) -> usize {
    read_app_log_if_exists(storage_root, project, app_id)
        .iter()
        .filter(|line| {
            line["type"]
                .as_str()
                .is_some_and(|event_type| event_types.contains(&event_type))
        })
        .count()
}

pub(crate) fn assert_invalid_input_tracking_io(error: TrackingError) {
    match error {
        TrackingError::Io(error) => {
            assert_eq!(
                error.kind(),
                std::io::ErrorKind::InvalidInput,
                "expected invalid-input IO error, got: {error}"
            );
        }
        other => panic!("expected TrackingError::Io(InvalidInput), got: {other:?}"),
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum TrackingMode {
    Sync,
    Async,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum MultiAppRouteMode {
    SyncStep,
    AsyncStream,
}

pub(crate) async fn assert_logs_to_correct_app_after_registering_multiple_apps(
    storage_root: &Path,
    mode: MultiAppRouteMode,
) {
    let (project, entry_types) = match mode {
        MultiAppRouteMode::SyncStep => (
            "test_multi_app_sync_routing",
            &["begin_entry", "end_entry"][..],
        ),
        MultiAppRouteMode::AsyncStream => (
            "test_multi_app_async_stream_routing",
            &["begin_entry", "end_entry", "begin_stream", "end_stream"][..],
        ),
    };
    let tracker = tracker(project, storage_root);

    match mode {
        MultiAppRouteMode::SyncStep => {
            let sync_hook: Arc<dyn SyncLifecycleAdapter> = tracker.clone();
            let hooks = LifecycleAdapterSet::new(vec![sync_hook], vec![]);
            let mut app_a =
                build_sync_app("app-a", "counter", build_single_step_sync_action(), hooks);
            let app_b = build_sync_app(
                "app-b",
                "counter",
                build_single_step_sync_action(),
                LifecycleAdapterSet::default(),
            );

            register_application(tracker.as_ref(), &app_a);
            register_application(tracker.as_ref(), &app_b);
            app_a.step(None).expect("step should succeed");
        }
        MultiAppRouteMode::AsyncStream => {
            let async_hook: Arc<dyn AsyncLifecycleAdapter> = tracker.clone();
            let hooks = LifecycleAdapterSet::new(vec![], vec![async_hook]);
            let mut app_a = build_sync_app(
                "app-a",
                "stream",
                streaming_action(StreamingScript::TwoStepCommit, StreamingLane::Async),
                hooks,
            );
            let app_b = build_sync_app(
                "app-b",
                "counter",
                build_single_step_sync_action(),
                LifecycleAdapterSet::default(),
            );

            register_application(tracker.as_ref(), &app_a);
            register_application(tracker.as_ref(), &app_b);

            let (_action, mut stream_result) = app_a
                .astream_result()
                .await
                .expect("astream_result should succeed");
            let _ = stream_result
                .next_item()
                .await
                .expect("stream item should succeed")
                .expect("stream item should exist");
            let _ = stream_result.get().await.expect("get should succeed");
        }
    }

    let app_a_entries = count_app_log_entries(storage_root, project, "app-a", entry_types);
    let app_b_entries = count_app_log_entries(storage_root, project, "app-b", entry_types);

    assert!(
        app_a_entries > 0,
        "app-a should contain expected tracking entries"
    );
    assert_eq!(app_b_entries, 0);
}

const _: () = {
    let _ = seeded_app_dir;
    let _ = count_app_log_entries;
    let _ = read_app_log_if_exists;
    let _ = StreamFixture::TwoStepCommit;
    let _ = StreamFixture::TerminalOnly { final_count: 0 };
    let _ = StreamFixture::ErrorAfterIntermediate { message: "" };
    let _ = MultiAppRouteMode::SyncStep;
    let _ = MultiAppRouteMode::AsyncStream;
    let _ = assert_stream_log;
    let _ = assert_stream_case;
    let _ = assert_logs_to_correct_app_after_registering_multiple_apps;
};
