use std::borrow::Cow;
use std::path::Path;
use std::path::PathBuf;
use std::process::{Command, Output};

/// Returns a [`Command`] configured to execute the `rurr` binary.
pub fn rurr_command() -> Command {
    Command::new(rurr_binary_path())
}

/// Returns a [`Command`] configured to execute the `rurr` binary in
/// `current_dir`.
pub fn rurr_command_in(current_dir: &Path) -> Command {
    let mut command = rurr_command();
    command.current_dir(current_dir);
    command
}

/// Executes the command and panics with `context` if spawning fails.
pub fn run_command(command: &mut Command, context: &str) -> Output {
    command.output().expect(context)
}

/// Asserts that a command exited successfully.
pub fn assert_success(output: &Output, context: &str) {
    assert!(
        output.status.success(),
        "{context}: stdout={} stderr={}",
        stdout_lossy(output),
        stderr_lossy(output)
    );
}

/// Asserts that a command exited unsuccessfully.
pub fn assert_failure(output: &Output, context: &str) {
    assert!(
        !output.status.success(),
        "{context}: stdout={} stderr={}",
        stdout_lossy(output),
        stderr_lossy(output)
    );
}

/// Decodes command stdout lossily as UTF-8.
pub fn stdout_lossy(output: &Output) -> Cow<'_, str> {
    String::from_utf8_lossy(&output.stdout)
}

/// Decodes command stdout as strict UTF-8.
pub fn stdout_utf8(output: &Output) -> String {
    String::from_utf8(output.stdout.clone()).expect("stdout should be utf-8")
}

/// Decodes command stderr lossily as UTF-8.
pub fn stderr_lossy(output: &Output) -> Cow<'_, str> {
    String::from_utf8_lossy(&output.stderr)
}

/// Resolves the `rurr` binary path for integration tests.
pub fn rurr_binary_path() -> PathBuf {
    if let Some(path) = std::env::var_os("CARGO_BIN_EXE_rurr") {
        return path.into();
    }

    let current_exe = std::env::current_exe().expect("current test executable should resolve");
    let profile_dir = current_exe
        .parent()
        .and_then(Path::parent)
        .expect("test executable should live under target/<profile>/deps");
    let binary_name = if cfg!(windows) { "rurr.exe" } else { "rurr" };
    let binary_path = profile_dir.join(binary_name);
    assert!(
        binary_path.exists(),
        "rurr binary should exist at {} or be provided by CARGO_BIN_EXE_rurr",
        binary_path.display()
    );
    binary_path
}
