use super::*;

#[cfg(unix)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum LoadUnsafeTarget {
    AppDir,
    MetadataFile,
    LogFile,
}

#[cfg(unix)]
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum RegisterUnsafeTarget {
    AppAlias,
    GraphAlias,
    MetadataAlias,
    BrokenGraphSymlink,
    ParentChildrenAlias,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum StepWriteFailureMode {
    #[cfg(unix)]
    LogAlias,
    AppDirReplacedByFile,
}

fn assert_tracking_step_rolled_back(app: &rurr_core::application::Application) {
    assert_eq!(
        app.state().get("count"),
        Some(&json!(0)),
        "failed hook must rollback state"
    );
    assert!(
        !app.state().contains_key("__SEQUENCE_ID"),
        "failed hook must rollback sequence reservation"
    );
}

fn assert_pre_run_step_hook_failed(error: &ApplicationError) {
    assert!(
        matches!(
            error,
            ApplicationError::LifecycleHookFailed {
                phase: "pre_run_step",
                ..
            }
        ),
        "expected lifecycle hook failure from pre_run_step write path, got: {error}"
    );
}

fn assert_graph_and_metadata_absent(app_dir: &std::path::Path, context: &str) {
    assert!(
        !app_dir.join(LocalTrackingClient::GRAPH_FILENAME).exists(),
        "graph should not be written when {context}"
    );
    assert!(
        !app_dir
            .join(LocalTrackingClient::METADATA_FILENAME)
            .exists(),
        "metadata should not be written when {context}"
    );
}

fn assert_graph_absent(app_dir: &std::path::Path, context: &str) {
    assert!(
        !app_dir.join(LocalTrackingClient::GRAPH_FILENAME).exists(),
        "graph should not be written when {context}"
    );
}

fn assert_metadata_absent(app_dir: &std::path::Path, context: &str) {
    assert!(
        !app_dir
            .join(LocalTrackingClient::METADATA_FILENAME)
            .exists(),
        "metadata should not be written when {context}"
    );
}

fn assert_not_found_tracking_io(error: &TrackingError) {
    assert!(
        matches!(error, TrackingError::Io(io) if io.kind() == std::io::ErrorKind::NotFound),
        "expected missing required tracking artifact error, got: {error}"
    );
}

fn assert_step_write_failure_rolls_back(mode: StepWriteFailureMode) {
    #[cfg(unix)]
    use std::os::unix::fs as unix_fs;

    let (project, expected_sibling_log_untouched) = match mode {
        #[cfg(unix)]
        StepWriteFailureMode::LogAlias => ("test_tracking_log_alias_failure", true),
        StepWriteFailureMode::AppDirReplacedByFile => ("test_tracking_write_failure", false),
    };
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let (_tracker, mut app) = registered_sync_app(
        project,
        &storage_root,
        "write-failure-app",
        "counter",
        build_single_step_sync_action(),
    );

    let app_dir = project_app_dir(&storage_root, project, "write-failure-app");
    let sibling_log_path = match mode {
        #[cfg(unix)]
        StepWriteFailureMode::LogAlias => {
            let sibling_app_dir = ensure_app_dir(&storage_root, project, "sibling-app");
            let sibling_log_path = sibling_app_dir.join(LocalTrackingClient::LOG_FILENAME);
            fs::write(&sibling_log_path, "").expect("sibling log should be writable");
            fs::remove_file(app_dir.join(LocalTrackingClient::LOG_FILENAME))
                .expect("requested log file should be removable before alias injection");
            unix_fs::symlink(
                &sibling_log_path,
                app_dir.join(LocalTrackingClient::LOG_FILENAME),
            )
            .expect("log alias should be created");
            Some(sibling_log_path)
        }
        StepWriteFailureMode::AppDirReplacedByFile => {
            fs::remove_dir_all(&app_dir).expect("app directory should be removable");
            fs::write(&app_dir, "not a directory").expect("file should replace app directory");
            None
        }
    };

    let error = app
        .step(None)
        .expect_err("tracking write failure must abort step with lifecycle error");
    assert_pre_run_step_hook_failed(&error);
    assert_tracking_step_rolled_back(&app);

    if expected_sibling_log_untouched {
        assert!(
            sibling_log_path.is_some_and(|path| read_jsonl_if_exists(&path).is_empty()),
            "aliased sibling log should remain untouched"
        );
    }
}

#[test]
fn missing_required_lifecycle_log_aborts_step_without_recreating_log() {
    let project = "test_tracking_missing_required_log_write";
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let (_tracker, mut app) = registered_sync_app(
        project,
        &storage_root,
        "missing-log-app",
        "counter",
        build_single_step_sync_action(),
    );
    let log_path = project_app_dir(&storage_root, project, "missing-log-app")
        .join(LocalTrackingClient::LOG_FILENAME);
    fs::remove_file(&log_path).expect("registered log file should be removable");

    let error = app
        .step(None)
        .expect_err("missing required log must abort step");
    assert_pre_run_step_hook_failed(&error);
    assert_tracking_step_rolled_back(&app);
    assert!(
        !log_path.exists(),
        "failed lifecycle write must not recreate missing log.jsonl"
    );
}

#[cfg(unix)]
fn assert_load_rejects_unsafe_target(
    storage_root: &std::path::Path,
    project: &str,
    target: LoadUnsafeTarget,
) {
    use std::os::unix::fs as unix_fs;
    let tracker = tracker(project, storage_root);

    let error = match target {
        LoadUnsafeTarget::AppDir => {
            let (_, real_app_dir) =
                seeded_counter_app_dir(storage_root, project, "real-app", Some("pk"), 1, 1);
            unix_fs::symlink(
                &real_app_dir,
                project_app_dir(storage_root, project, "alias-app"),
            )
            .expect("app alias should be created");
            tracker
                .load(Some("pk"), Some("alias-app"), None)
                .expect_err("same-root app aliases must fail closed")
        }
        LoadUnsafeTarget::MetadataFile => {
            let (_, requested_app_dir) =
                seeded_counter_app_dir(storage_root, project, "requested-app", Some("pk"), 1, 1);
            let (_, sibling_app_dir) =
                seeded_app_dir(storage_root, project, "sibling-app", Some("pk"));
            fs::remove_file(requested_app_dir.join(LocalTrackingClient::METADATA_FILENAME))
                .expect("requested metadata file should be removable before alias injection");
            unix_fs::symlink(
                sibling_app_dir.join(LocalTrackingClient::METADATA_FILENAME),
                requested_app_dir.join(LocalTrackingClient::METADATA_FILENAME),
            )
            .expect("metadata alias should be created");
            tracker
                .load(Some("pk"), Some("requested-app"), None)
                .expect_err("same-root metadata aliases must fail closed")
        }
        LoadUnsafeTarget::LogFile => {
            let (_, requested_app_dir) =
                seeded_app_dir(storage_root, project, "requested-app", Some("pk"));
            let (_, sibling_app_dir) =
                seeded_counter_app_dir(storage_root, project, "sibling-app", Some("pk"), 2, 2);
            let sibling_log_path = sibling_app_dir.join(LocalTrackingClient::LOG_FILENAME);
            fs::remove_file(requested_app_dir.join(LocalTrackingClient::LOG_FILENAME))
                .expect("requested log file should be removable before alias injection");
            unix_fs::symlink(
                &sibling_log_path,
                requested_app_dir.join(LocalTrackingClient::LOG_FILENAME),
            )
            .expect("log alias should be created");
            tracker
                .load(Some("pk"), Some("requested-app"), None)
                .expect_err("same-root log aliases must fail closed")
        }
    };

    match target {
        LoadUnsafeTarget::AppDir => assert!(matches!(
            error,
            PersistenceError::UnsupportedOperation {
                operation: "local_tracking_client_io"
            }
        )),
        LoadUnsafeTarget::MetadataFile | LoadUnsafeTarget::LogFile => assert!(matches!(
            error,
            PersistenceError::InvalidPersistedState {
                operation: "local_tracking_client_load",
                ..
            }
        )),
    }
}

#[cfg(unix)]
fn assert_register_rejects_unsafe_target(
    storage_root: &std::path::Path,
    project: &str,
    target: RegisterUnsafeTarget,
) {
    use std::os::unix::fs as unix_fs;
    let tracker = tracker(project, storage_root);
    let template_app = build_sync_app(
        "template",
        "counter",
        build_single_step_sync_action(),
        LifecycleAdapterSet::default(),
    );

    let error = match target {
        RegisterUnsafeTarget::AppAlias => {
            let real_app_dir = ensure_app_dir(storage_root, project, "real-app");
            unix_fs::symlink(
                &real_app_dir,
                project_app_dir(storage_root, project, "alias-app"),
            )
            .expect("app alias should be created");
            let error = tracker
                .register_application("alias-app", Some("pk"), template_app.graph(), None, None)
                .expect_err("same-root app aliases must fail closed on registration");
            assert_graph_and_metadata_absent(&real_app_dir, "app directory identity is unsafe");
            error
        }
        RegisterUnsafeTarget::GraphAlias => {
            let requested_app_dir = ensure_app_dir(storage_root, project, "requested-app");
            let sibling_app_dir = ensure_app_dir(storage_root, project, "sibling-app");
            fs::write(
                sibling_app_dir.join(LocalTrackingClient::GRAPH_FILENAME),
                "{}",
            )
            .expect("sibling graph should be writable");
            unix_fs::symlink(
                sibling_app_dir.join(LocalTrackingClient::GRAPH_FILENAME),
                requested_app_dir.join(LocalTrackingClient::GRAPH_FILENAME),
            )
            .expect("graph alias should be created");
            let error = tracker
                .register_application(
                    "requested-app",
                    Some("pk"),
                    template_app.graph(),
                    None,
                    None,
                )
                .expect_err("same-root graph aliases must fail closed on registration");
            assert_metadata_absent(&requested_app_dir, "graph target identity is unsafe");
            error
        }
        RegisterUnsafeTarget::MetadataAlias => {
            let requested_app_dir = ensure_app_dir(storage_root, project, "requested-app");
            let sibling_app_dir = ensure_app_dir(storage_root, project, "sibling-app");
            fs::write(
                sibling_app_dir.join(LocalTrackingClient::METADATA_FILENAME),
                "{}",
            )
            .expect("sibling metadata should be writable");
            unix_fs::symlink(
                sibling_app_dir.join(LocalTrackingClient::METADATA_FILENAME),
                requested_app_dir.join(LocalTrackingClient::METADATA_FILENAME),
            )
            .expect("metadata alias should be created");
            let error = tracker
                .register_application(
                    "requested-app",
                    Some("pk"),
                    template_app.graph(),
                    None,
                    None,
                )
                .expect_err("same-root metadata aliases must fail closed on registration");
            assert_graph_absent(&requested_app_dir, "metadata target identity is unsafe");
            error
        }
        RegisterUnsafeTarget::BrokenGraphSymlink => {
            let requested_app_dir = ensure_app_dir(storage_root, project, "requested-app");
            unix_fs::symlink(
                requested_app_dir.join("missing-graph.json"),
                requested_app_dir.join(LocalTrackingClient::GRAPH_FILENAME),
            )
            .expect("broken graph symlink should be created");
            let error = tracker
                .register_application(
                    "requested-app",
                    Some("pk"),
                    template_app.graph(),
                    None,
                    None,
                )
                .expect_err("broken graph symlinks must fail closed on registration");
            assert_metadata_absent(&requested_app_dir, "graph symlink is broken");
            error
        }
        RegisterUnsafeTarget::ParentChildrenAlias => {
            let parent_app_dir = ensure_app_dir(storage_root, project, "parent-app");
            fs::write(
                parent_app_dir.join(LocalTrackingClient::GRAPH_FILENAME),
                "{}",
            )
            .expect("parent graph proof artifact should be writable");
            fs::write(
                parent_app_dir.join(LocalTrackingClient::METADATA_FILENAME),
                "{}",
            )
            .expect("parent metadata proof artifact should be writable");
            fs::write(parent_app_dir.join(LocalTrackingClient::LOG_FILENAME), "")
                .expect("parent log proof artifact should be writable");
            let sibling_app_dir = ensure_app_dir(storage_root, project, "sibling-app");
            let sibling_children_path =
                sibling_app_dir.join(LocalTrackingClient::CHILDREN_FILENAME);
            fs::write(&sibling_children_path, "").expect("sibling children log should be writable");
            unix_fs::symlink(
                &sibling_children_path,
                parent_app_dir.join(LocalTrackingClient::CHILDREN_FILENAME),
            )
            .expect("children alias should be created");
            let error = tracker
                .register_application(
                    "child-app",
                    Some("pk"),
                    template_app.graph(),
                    Some(ParentPointer {
                        app_id: "parent-app".to_string(),
                        partition_key: Some("pk".to_string()),
                        sequence_id: Some(1),
                    }),
                    None,
                )
                .expect_err("aliased parent children logs must fail closed");
            let child_app_dir = project_app_dir(storage_root, project, "child-app");
            assert_graph_and_metadata_absent(&child_app_dir, "parent children target is unsafe");
            assert!(
                read_jsonl_if_exists(&sibling_children_path).is_empty(),
                "aliased sibling children log should remain untouched"
            );
            error
        }
    };

    assert_invalid_input_tracking_io(error);
}

#[cfg(unix)]
#[test]
fn list_app_ids_rejects_parent_project_swap_after_tracker_initialization() {
    use std::os::unix::fs as unix_fs;

    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_list_app_ids_rejects_parent_project_swap_after_tracker_initialization";
    let tracker = tracker(project, &storage_root);
    let template_app = build_sync_app(
        "template",
        "counter",
        build_single_step_sync_action(),
        LifecycleAdapterSet::default(),
    );

    tracker
        .register_application(
            "requested-app",
            Some("pk"),
            template_app.graph(),
            None,
            None,
        )
        .expect("requested app should register");

    let outside = test_dir_for_test().expect("outside temp dir should build");
    let outside_app_dir = outside.join("outside-app");
    fs::create_dir_all(&outside_app_dir).expect("outside app directory should exist");
    write_metadata(&outside_app_dir, Some("pk"));

    let moved_project_dir = storage_root.join(format!("{project}-real"));
    fs::rename(storage_root.join(project), &moved_project_dir)
        .expect("project dir should move out of the original path");
    unix_fs::symlink(&outside, storage_root.join(project))
        .expect("project symlink replacement should be created");

    let error = tracker
        .list_app_ids(None)
        .expect_err("swapped project directories must fail closed");
    assert!(matches!(
        error,
        PersistenceError::UnsupportedOperation {
            operation: "local_tracking_client_io"
        }
    ));
}

#[cfg(unix)]
#[test]
fn load_rejects_same_root_unsafe_targets() {
    for (project, target) in [
        (
            "test_load_rejects_same_root_app_alias",
            LoadUnsafeTarget::AppDir,
        ),
        (
            "test_load_rejects_same_root_metadata_file_alias",
            LoadUnsafeTarget::MetadataFile,
        ),
        (
            "test_load_rejects_same_root_log_file_alias",
            LoadUnsafeTarget::LogFile,
        ),
    ] {
        let storage_root = rurr_testkit::tempdir::test_dir().expect("temp dir should build");
        assert_load_rejects_unsafe_target(&storage_root, project, target);
    }
}

#[test]
fn register_application_rejects_invalid_parent_pointer_app_id() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_reject_invalid_parent_pointer_app_id";
    let tracker = tracker(project, &storage_root);
    let template_app = build_sync_app(
        "template",
        "counter",
        build_single_step_sync_action(),
        LifecycleAdapterSet::default(),
    );

    let error = tracker
        .register_application(
            "child-app",
            Some("pk"),
            template_app.graph(),
            Some(ParentPointer {
                app_id: "../parent".to_string(),
                partition_key: Some("pk".to_string()),
                sequence_id: Some(1),
            }),
            None,
        )
        .expect_err("invalid parent pointer app id should be rejected");
    assert!(matches!(error, TrackingError::InvalidAppId { .. }));

    let child_app_dir = project_app_dir(&storage_root, project, "child-app");
    assert_graph_and_metadata_absent(&child_app_dir, "parent pointer app id is invalid");
}

#[test]
fn register_application_rejects_missing_parent_app_without_creating_artifacts() {
    let storage_root = test_dir_for_test().expect("temp dir should build");
    let project = "test_reject_missing_parent_app";
    let tracker = tracker(project, &storage_root);
    let template_app = build_sync_app(
        "template",
        "counter",
        build_single_step_sync_action(),
        LifecycleAdapterSet::default(),
    );

    let error = tracker
        .register_application(
            "child-app",
            Some("pk"),
            template_app.graph(),
            Some(ParentPointer {
                app_id: "parent-app".to_string(),
                partition_key: Some("pk".to_string()),
                sequence_id: Some(1),
            }),
            None,
        )
        .expect_err("missing parent app should reject child registration");
    assert_not_found_tracking_io(&error);

    let parent_app_dir = project_app_dir(&storage_root, project, "parent-app");
    let child_app_dir = project_app_dir(&storage_root, project, "child-app");
    assert!(
        !parent_app_dir.exists(),
        "parent relationship preparation must not create the parent app directory"
    );
    assert!(
        !child_app_dir.exists(),
        "child artifacts must not be written when parent proof is missing"
    );
}

#[test]
fn register_application_rejects_parent_missing_required_artifact_without_creating_child_links() {
    let required_artifacts = [
        ("graph", LocalTrackingClient::GRAPH_FILENAME),
        ("metadata", LocalTrackingClient::METADATA_FILENAME),
        ("log", LocalTrackingClient::LOG_FILENAME),
    ];

    for (missing_label, missing) in required_artifacts {
        let storage_root = test_dir_for_test().expect("temp dir should build");
        let project = format!("test_reject_parent_missing_{missing_label}");
        let tracker = tracker(&project, &storage_root);
        let template_app = build_sync_app(
            "template",
            "counter",
            build_single_step_sync_action(),
            LifecycleAdapterSet::default(),
        );
        let parent_app_dir = ensure_app_dir(&storage_root, &project, "parent-app");
        for (_, artifact) in required_artifacts {
            if artifact == missing {
                continue;
            }
            let body = if artifact == LocalTrackingClient::LOG_FILENAME {
                ""
            } else {
                "{}"
            };
            fs::write(parent_app_dir.join(artifact), body)
                .expect("parent fixture artifact should be writable");
        }

        let error = tracker
            .register_application(
                "child-app",
                Some("pk"),
                template_app.graph(),
                Some(ParentPointer {
                    app_id: "parent-app".to_string(),
                    partition_key: Some("pk".to_string()),
                    sequence_id: Some(1),
                }),
                None,
            )
            .expect_err("missing parent required artifact should reject child registration");
        assert_not_found_tracking_io(&error);

        assert!(
            !parent_app_dir
                .join(LocalTrackingClient::CHILDREN_FILENAME)
                .exists(),
            "children.jsonl must not be created when parent {missing} is missing"
        );
        let child_app_dir = project_app_dir(&storage_root, &project, "child-app");
        assert!(
            !child_app_dir.exists(),
            "child artifacts must not be written when parent {missing} is missing"
        );
    }
}

#[cfg(unix)]
#[test]
fn register_application_rejects_unsafe_targets_before_writing_files() {
    for (project, target) in [
        (
            "test_register_rejects_same_root_app_alias",
            RegisterUnsafeTarget::AppAlias,
        ),
        (
            "test_register_rejects_same_root_graph_alias",
            RegisterUnsafeTarget::GraphAlias,
        ),
        (
            "test_register_rejects_same_root_metadata_alias",
            RegisterUnsafeTarget::MetadataAlias,
        ),
        (
            "test_register_rejects_broken_graph_symlink",
            RegisterUnsafeTarget::BrokenGraphSymlink,
        ),
        (
            "test_register_rejects_parent_children_alias",
            RegisterUnsafeTarget::ParentChildrenAlias,
        ),
    ] {
        let storage_root = rurr_testkit::tempdir::test_dir().expect("temp dir should build");
        assert_register_rejects_unsafe_target(&storage_root, project, target);
    }
}

#[test]
fn tracking_write_failures_abort_step_with_lifecycle_error_and_roll_back() {
    #[cfg(unix)]
    assert_step_write_failure_rolls_back(StepWriteFailureMode::LogAlias);
    assert_step_write_failure_rolls_back(StepWriteFailureMode::AppDirReplacedByFile);
}
