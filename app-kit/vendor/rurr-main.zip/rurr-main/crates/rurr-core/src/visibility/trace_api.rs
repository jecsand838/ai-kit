use super::VisibilityError;
use crate::action::api::ActionTracer;
use crate::common::panic::panic_payload_to_string;
use crate::visibility::TraceSpanHandle;
use futures::FutureExt;
use indexmap::IndexMap;
use serde::Serialize;
use serde_json::Value;
use std::future::Future;
use std::panic::{self, AssertUnwindSafe};

#[derive(Debug, Clone)]
/// Options that control how the high-level tracing helpers capture a call.
pub struct TraceOptions {
    capture_inputs: bool,
    capture_outputs: bool,
    capture_auto_attributes: bool,
    input_filterlist: Vec<String>,
    span_name: Option<String>,
}

impl Default for TraceOptions {
    fn default() -> Self {
        Self {
            capture_inputs: true,
            capture_outputs: true,
            capture_auto_attributes: true,
            input_filterlist: Vec::new(),
            span_name: None,
        }
    }
}

impl TraceOptions {
    /// Creates a tracing configuration with all capture behavior enabled.
    pub fn new() -> Self {
        Self::default()
    }

    /// Enables or disables automatic logging of function inputs.
    pub fn with_capture_inputs(mut self, capture_inputs: bool) -> Self {
        self.capture_inputs = capture_inputs;
        self
    }

    /// Enables or disables automatic logging of function outputs.
    pub fn with_capture_outputs(mut self, capture_outputs: bool) -> Self {
        self.capture_outputs = capture_outputs;
        self
    }

    /// Enables or disables built-in tracing attributes such as function metadata.
    pub fn with_capture_auto_attributes(mut self, capture_auto_attributes: bool) -> Self {
        self.capture_auto_attributes = capture_auto_attributes;
        self
    }

    /// Excludes the named input keys from automatic input capture.
    pub fn with_input_filterlist<K, I>(mut self, input_filterlist: I) -> Self
    where
        K: Into<String>,
        I: IntoIterator<Item = K>,
    {
        self.input_filterlist = input_filterlist.into_iter().map(Into::into).collect();
        self
    }

    /// Overrides the default span name derived from the wrapped function name.
    pub fn with_span_name(mut self, span_name: impl Into<String>) -> Self {
        self.span_name = Some(span_name.into());
        self
    }

    fn span_name_for(&self, function_name: &str) -> String {
        self.span_name
            .clone()
            .unwrap_or_else(|| function_name.to_string())
    }
}

fn stable_hash(value: &str) -> String {
    let mut hash = 0xcbf29ce484222325_u64;
    for byte in value.bytes() {
        hash ^= byte as u64;
        hash = hash.wrapping_mul(0x100000001b3);
    }
    format!("{hash:016x}")
}

fn filter_inputs(
    options: &TraceOptions,
    inputs: &IndexMap<String, Value>,
) -> IndexMap<String, Value> {
    inputs
        .iter()
        .filter(|(key, _)| !options.input_filterlist.contains(key))
        .map(|(key, value)| (key.clone(), value.clone()))
        .collect()
}

fn auto_attributes(function_name: &str) -> IndexMap<String, Value> {
    IndexMap::from([
        (
            "__burr_function".to_string(),
            Value::String(function_name.to_string()),
        ),
        (
            "__burr_function_hash".to_string(),
            Value::String(stable_hash(function_name)),
        ),
    ])
}

fn serialize_output(
    operation: &'static str,
    output: &impl Serialize,
) -> Result<Value, VisibilityError> {
    serde_json::to_value(output).map_err(|error| VisibilityError::OutputSerializationFailed {
        operation,
        message: error.to_string(),
    })
}

/// Wraps a synchronous function call in a traced root span.
pub fn trace<F, R>(
    tracer: &ActionTracer,
    function_name: &str,
    inputs: &IndexMap<String, Value>,
    options: &TraceOptions,
    function: F,
) -> Result<R, VisibilityError>
where
    F: FnOnce(TraceSpanHandle) -> R,
    R: Serialize,
{
    if !tracer.is_active() {
        return Ok(function(TraceSpanHandle::default()));
    }

    let root_handle = tracer.enter_root_span(options.span_name_for(function_name))?;
    let finish_handle = root_handle.clone();
    let body_handle = root_handle.clone();
    let attribute_handle = root_handle;
    let output_result = panic::catch_unwind(AssertUnwindSafe(|| -> Result<R, VisibilityError> {
        if options.capture_inputs {
            let filtered = filter_inputs(options, inputs);
            if !filtered.is_empty() {
                attribute_handle.log_attributes(&filtered)?;
            }
        }

        if options.capture_auto_attributes {
            let auto = auto_attributes(function_name);
            attribute_handle.log_attributes(&auto)?;
        }

        let scoped_handle = body_handle.clone();
        let output = body_handle.run_in_current_scope(|| function(scoped_handle));
        if options.capture_outputs {
            let output_value = serialize_output("trace", &output)?;
            attribute_handle.log_attribute("return", output_value)?;
        }
        Ok(output)
    }));
    match output_result {
        Ok(Ok(output)) => {
            finish_handle.finish_sync()?;
            Ok(output)
        }
        Ok(Err(error)) => match finish_handle.finish_sync() {
            Ok(()) => Err(error),
            Err(end_error) => Err(end_error),
        },
        Err(payload) => {
            let panic_error = VisibilityError::CapturedPanic {
                operation: "trace",
                message: panic_payload_to_string(payload),
            };
            match finish_handle.finish_sync() {
                Ok(()) => Err(panic_error),
                Err(end_error) => Err(end_error),
            }
        }
    }
}

/// Wraps an asynchronous function call in a traced root span.
pub async fn trace_async<F, Fut, R>(
    tracer: &ActionTracer,
    function_name: &str,
    inputs: &IndexMap<String, Value>,
    options: &TraceOptions,
    function: F,
) -> Result<R, VisibilityError>
where
    F: FnOnce(TraceSpanHandle) -> Fut,
    Fut: Future<Output = R>,
    R: Serialize,
{
    if !tracer.is_active() {
        return Ok(function(TraceSpanHandle::default()).await);
    }

    let root_handle = tracer
        .enter_root_span_async(options.span_name_for(function_name))
        .await?;
    let finish_handle = root_handle.clone();
    let body_handle = root_handle.clone();
    let attribute_handle = root_handle;
    let output_result = AssertUnwindSafe(async {
        if options.capture_inputs {
            let filtered = filter_inputs(options, inputs);
            if !filtered.is_empty() {
                attribute_handle.log_attributes_async(&filtered).await?;
            }
        }

        if options.capture_auto_attributes {
            let auto = auto_attributes(function_name);
            attribute_handle.log_attributes_async(&auto).await?;
        }

        let scoped_handle = body_handle.clone();
        let output = body_handle
            .run_in_current_scope_async(async move { function(scoped_handle).await })
            .await;
        if options.capture_outputs {
            let output_value = serialize_output("trace_async", &output)?;
            attribute_handle
                .log_attribute_async("return", output_value)
                .await?;
        }
        Ok::<R, VisibilityError>(output)
    })
    .catch_unwind()
    .await;
    match output_result {
        Ok(Ok(output)) => {
            finish_handle.finish_async().await?;
            Ok(output)
        }
        Ok(Err(error)) => match finish_handle.finish_async().await {
            Ok(()) => Err(error),
            Err(end_error) => Err(end_error),
        },
        Err(payload) => {
            let panic_error = VisibilityError::CapturedPanic {
                operation: "trace_async",
                message: panic_payload_to_string(payload),
            };
            match finish_handle.finish_async().await {
                Ok(()) => Err(panic_error),
                Err(end_error) => Err(end_error),
            }
        }
    }
}
