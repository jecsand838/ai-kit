use std::sync::{Arc, OnceLock, RwLock};

/// A copy-on-write registry that provides cheap snapshots for read-heavy global state.
pub struct CowRegistry<T> {
    cell: OnceLock<RwLock<Arc<T>>>,
    init: fn() -> T,
}

impl<T> CowRegistry<T> {
    pub(crate) const fn new(init: fn() -> T) -> Self {
        Self {
            cell: OnceLock::new(),
            init,
        }
    }

    fn lock(&self) -> &RwLock<Arc<T>> {
        self.cell
            .get_or_init(|| RwLock::new(Arc::new((self.init)())))
    }

    pub(crate) fn snapshot<E>(&self, on_poison: impl FnOnce() -> E) -> Result<Arc<T>, E> {
        let guard = self.lock().read().map_err(|_| on_poison())?;
        Ok((*guard).clone())
    }

    pub(crate) fn update_by_cloning<E>(
        &self,
        on_poison: impl FnOnce() -> E,
        updater: impl FnOnce(&mut T),
    ) -> Result<(), E>
    where
        T: Clone,
    {
        let mut guard = self.lock().write().map_err(|_| on_poison())?;
        let mut next = guard.as_ref().clone();
        updater(&mut next);
        *guard = Arc::new(next);
        Ok(())
    }
}
