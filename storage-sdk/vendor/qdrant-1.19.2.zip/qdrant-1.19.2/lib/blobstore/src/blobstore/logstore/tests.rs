use common::counter::hardware_counter::HardwareCounterCell;
use common::generic_consts::Random;
use common::universal_io::{MmapFile, MmapFs, Populate};
use fs_err as fs;
use tempfile::TempDir;

use crate::blobstore::reader::CONFIG_FILENAME;
use crate::config::{Compression, DEFAULT_PAGE_SIZE_BYTES, LogstoreConfig, Mode, StorageConfig};
use crate::error::BlobstoreError;
use crate::fixtures::{Payload, default_config, empty_storage_append_only, random_payload};
use crate::tracker::append_only::AppendOnlyTracker;
use crate::tracker::compacted::CompactedTracker;
use crate::tracker::{PointOffset, ValuePointer};
use crate::{Blobstore, BlobstoreReader};

/// Size in bytes of a single mapping entry in the tracker file
const TRACKER_ENTRY_SIZE: u64 = 16;

/// Create an empty append-only storage of raw byte values, for precise size assertions.
fn empty_byte_storage(compression: Compression) -> (TempDir, Blobstore<Vec<u8>>) {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression,
    });
    let storage = Blobstore::new(MmapFs, dir.path().to_path_buf(), config).unwrap();
    (dir, storage)
}

fn tracker_file_len(dir: &TempDir) -> u64 {
    fs::metadata(dir.path().join("log_tracker.dat"))
        .unwrap()
        .len()
}

#[test]
fn test_empty_storage() {
    let (dir, storage) = empty_storage_append_only();

    let hw_counter = HardwareCounterCell::new();
    assert_eq!(storage.get_value::<Random>(0, &hw_counter).unwrap(), None);
    assert_eq!(storage.max_point_offset(), 0);
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 0);

    // Only three files: tracker, page and config
    let files = storage.files();
    assert_eq!(files.len(), 3, "Expected 3 files, got {files:?}");
    assert_eq!(files[0].file_name().unwrap(), "log_tracker.dat");
    assert_eq!(files[1].file_name().unwrap(), "log_page_0.dat");
    assert_eq!(files[2].file_name().unwrap(), "config.json");
    let actual_files = fs::read_dir(dir.path()).unwrap().count();
    assert_eq!(files.len(), actual_files);

    let immutable_files = storage.immutable_files();
    assert_eq!(immutable_files.len(), 1);
    assert_eq!(immutable_files[0].file_name().unwrap(), "config.json");

    // Both files start empty, they are not preallocated
    assert_eq!(tracker_file_len(&dir), 0);
    assert_eq!(
        fs::metadata(dir.path().join("log_page_0.dat"))
            .unwrap()
            .len(),
        0,
    );
}

#[rstest::rstest]
#[case(Compression::None)]
#[case(Compression::LZ4)]
fn test_put_get_roundtrip(#[case] compression: Compression) {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression,
    });
    let mut storage = Blobstore::<Payload>::new(MmapFs, dir.path().to_path_buf(), config).unwrap();

    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();
    let payloads = (0..100)
        .map(|point_offset| (point_offset, random_payload(rng, 2)))
        .collect::<Vec<_>>();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for (point_offset, payload) in &payloads {
        let is_update = storage
            .put_value(*point_offset, payload, hw_counter_ref)
            .unwrap();
        assert!(!is_update);
    }
    assert!(hw_counter.payload_io_write_counter().get() > 0);
    assert_eq!(storage.max_point_offset(), 100);

    for (point_offset, payload) in &payloads {
        let stored = storage
            .get_value::<Random>(*point_offset, &hw_counter)
            .unwrap();
        assert_eq!(stored.as_ref(), Some(payload));
    }

    storage.flusher()().unwrap();

    // The tracker file length matches the exact number of mappings
    assert_eq!(tracker_file_len(&dir), 100 * TRACKER_ENTRY_SIZE);

    // Everything is still there after reopening, the mode is selected automatically
    drop(storage);
    let storage =
        Blobstore::<Payload>::open(MmapFs, dir.path().to_path_buf(), Populate::No).unwrap();
    storage.as_logstore();
    assert_eq!(storage.max_point_offset(), 100);
    for (point_offset, payload) in &payloads {
        let stored = storage
            .get_value::<Random>(*point_offset, &hw_counter)
            .unwrap();
        assert_eq!(stored.as_ref(), Some(payload));
    }
}

/// Puts buffer both the value data and the mapping in memory: nothing lands on disk until a
/// flush, which batches everything into a single write per file.
#[test]
fn test_put_buffers_value_and_mapping_until_flush() {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression: Compression::None,
    });
    let mut storage = Blobstore::<Vec<u8>>::new(MmapFs, dir.path().to_path_buf(), config).unwrap();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    let page_path = dir.path().join("log_page_0.dat");
    let tracker_path = dir.path().join("log_tracker.dat");

    for point_offset in 0..3 {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 100], hw_counter_ref)
            .unwrap();
    }

    // Nothing is written to disk until a flush
    assert_eq!(fs::metadata(&page_path).unwrap().len(), 0);
    assert_eq!(fs::metadata(&tracker_path).unwrap().len(), 0);

    // The buffered values are still fully readable, served from memory
    assert_eq!(storage.max_point_offset(), 3);
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 3 * 100);
    for point_offset in 0..3 {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(vec![point_offset as u8; 100]),
        );
    }

    // The flush lands all buffered values and mappings at once, in exactly their extents
    storage.flusher()().unwrap();
    assert_eq!(
        fs::metadata(&page_path).unwrap().len(),
        3 * 100,
        "the page file must hold exactly the appended values",
    );
    assert_eq!(
        fs::metadata(&tracker_path).unwrap().len(),
        3 * TRACKER_ENTRY_SIZE,
        "the tracker file must hold exactly the appended mappings",
    );

    // The values remain readable, now served from the files, and survive a reopen
    for point_offset in 0..3 {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(vec![point_offset as u8; 100]),
        );
    }
    drop(storage);
    let storage =
        Blobstore::<Vec<u8>>::open(MmapFs, dir.path().to_path_buf(), Populate::No).unwrap();
    assert_eq!(storage.max_point_offset(), 3);
    for point_offset in 0..3 {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(vec![point_offset as u8; 100]),
        );
    }
}

#[test]
fn test_put_rejects_out_of_order_point_offsets() {
    let (_dir, mut storage) = empty_byte_storage(Compression::None);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    storage.put_value(0, &vec![1; 100], hw_counter_ref).unwrap();
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 100);

    // Putting the same point offset twice is rejected
    let err = storage
        .put_value(0, &vec![2; 100], hw_counter_ref)
        .unwrap_err();
    assert!(matches!(err, BlobstoreError::UnsupportedOperation { .. }));

    storage.put_value(2, &vec![3; 100], hw_counter_ref).unwrap();

    // Putting a lower point offset is rejected, even if it was never set
    let err = storage
        .put_value(1, &vec![4; 100], hw_counter_ref)
        .unwrap_err();
    assert!(matches!(err, BlobstoreError::UnsupportedOperation { .. }));

    // Rejected puts must not append any value data
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 2 * 100);

    // The stored values are unaffected
    assert_eq!(
        storage.get_value::<Random>(0, &hw_counter).unwrap(),
        Some(vec![1; 100]),
    );
    assert_eq!(
        storage.get_value::<Random>(2, &hw_counter).unwrap(),
        Some(vec![3; 100]),
    );
}

#[test]
fn test_delete_is_rejected() {
    let (_dir, mut storage) = empty_storage_append_only();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    storage
        .put_value(0, &Payload::default(), hw_counter_ref)
        .unwrap();

    let err = storage.delete_value(0).unwrap_err();
    assert!(matches!(err, BlobstoreError::UnsupportedOperation { .. }));

    // The value is still there
    assert_eq!(
        storage.get_value::<Random>(0, &hw_counter).unwrap(),
        Some(Payload::default()),
    );
}

#[test]
fn test_skipped_point_offsets_read_as_none() {
    let (_dir, mut storage) = empty_byte_storage(Compression::None);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    for point_offset in [0, 3, 4, 10] {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 10], hw_counter_ref)
            .unwrap();
    }
    assert_eq!(storage.max_point_offset(), 11);

    for point_offset in [1, 2, 5, 6, 7, 8, 9, 11] {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            None,
        );
    }

    // Iteration skips the gaps. Values are read in batches, so the callback may be invoked in
    // any order; sort before comparing.
    let mut collected = Vec::new();
    storage
        .iter(
            |point_offset, value: Vec<u8>| {
                collected.push((point_offset, value));
                Ok::<_, BlobstoreError>(true)
            },
            hw_counter.ref_payload_io_read_counter(),
        )
        .unwrap();
    collected.sort_by_key(|(point_offset, _)| *point_offset);
    assert_eq!(
        collected,
        vec![
            (0, vec![0; 10]),
            (3, vec![3; 10]),
            (4, vec![4; 10]),
            (10, vec![10; 10]),
        ]
    );

    // Iteration can stop early
    let mut count = 0;
    storage
        .iter(
            |_, _: Vec<u8>| {
                count += 1;
                Ok::<_, BlobstoreError>(false)
            },
            hw_counter.ref_payload_io_read_counter(),
        )
        .unwrap();
    assert_eq!(count, 1);

    // Batched reads yield None for gaps and out of range point offsets. The callback may be
    // invoked in any order, so sort before comparing.
    let mut collected = Vec::new();
    storage
        .read_values::<Random, _, BlobstoreError>(
            [0, 1, 5, 10, 3, 20].iter().map(|&offset| ((), offset)),
            |_, point_offset, value| {
                collected.push((point_offset, value));
                Ok(())
            },
            hw_counter.payload_io_read_counter(),
        )
        .unwrap();
    collected.sort();
    assert_eq!(
        collected,
        vec![
            (0, Some(vec![0; 10])),
            (1, None),
            (3, Some(vec![3; 10])),
            (5, None),
            (10, Some(vec![10; 10])),
            (20, None),
        ]
    );
}

#[test]
fn test_values_are_byte_packed() {
    let (_dir, mut storage) = empty_byte_storage(Compression::None);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    // Each value starts right after the previous one, without blocks or alignment
    storage.put_value(0, &vec![1; 100], hw_counter_ref).unwrap();
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 100);
    storage.put_value(1, &vec![2; 50], hw_counter_ref).unwrap();
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 100 + 50);
    storage.put_value(2, &vec![3; 300], hw_counter_ref).unwrap();
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 100 + 50 + 300);

    let pointer = storage.get_pointer(1).unwrap();
    assert_eq!(pointer.page_id, 0);
    assert_eq!(pointer.block_offset, 100);
    assert_eq!(pointer.length, 50);
    let pointer = storage.get_pointer(2).unwrap();
    assert_eq!(pointer.block_offset, 150);

    for (point_offset, value) in [(0, vec![1; 100]), (1, vec![2; 50]), (2, vec![3; 300])] {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(value),
        );
    }
}

#[test]
fn test_empty_and_huge_values() {
    let (_dir, mut storage) = empty_byte_storage(Compression::None);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    // An empty value takes no space at all
    storage.put_value(0, &vec![], hw_counter_ref).unwrap();
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 0);
    assert_eq!(
        storage.get_value::<Random>(0, &hw_counter).unwrap(),
        Some(vec![]),
    );

    // A huge value simply grows the page file, values never span pages
    let huge = (0..2_000_000).map(|i| i as u8).collect::<Vec<u8>>();
    storage.put_value(1, &huge, hw_counter_ref).unwrap();
    assert_eq!(storage.get_storage_size_bytes().unwrap(), huge.len());
    assert_eq!(
        storage.get_value::<Random>(1, &hw_counter).unwrap(),
        Some(huge),
    );
}

#[test]
fn test_unflushed_puts_are_lost_after_reopen() {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression: Compression::None,
    });
    let mut storage = Blobstore::<Vec<u8>>::new(MmapFs, dir.path().to_path_buf(), config).unwrap();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    // Both the value data and the mappings are buffered in memory until the next flush
    for point_offset in 0..3 {
        storage
            .put_value(point_offset, &vec![7; 100], hw_counter_ref)
            .unwrap();
    }
    drop(storage);

    // Without a flush, the puts are gone after reopening, and left nothing behind on disk
    let mut storage =
        Blobstore::<Vec<u8>>::open(MmapFs, dir.path().to_path_buf(), Populate::No).unwrap();
    assert_eq!(storage.max_point_offset(), 0);
    assert_eq!(storage.get_value::<Random>(0, &hw_counter).unwrap(), None);
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 0);

    // New puts start from a clean page file
    storage.put_value(0, &vec![9; 10], hw_counter_ref).unwrap();
    storage.flusher()().unwrap();
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 10);
    assert_eq!(
        storage.get_value::<Random>(0, &hw_counter).unwrap(),
        Some(vec![9; 10]),
    );
}

#[test]
fn test_stale_flusher_is_noop() {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig::DEFAULT);
    let mut storage = Blobstore::<Payload>::new(MmapFs, dir.path().to_path_buf(), config).unwrap();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    for point_offset in 0..3 {
        storage
            .put_value(point_offset, &Payload::default(), hw_counter_ref)
            .unwrap();
    }
    let stale_flusher = storage.flusher();

    storage
        .put_value(3, &Payload::default(), hw_counter_ref)
        .unwrap();
    storage.flusher()().unwrap();
    assert_eq!(tracker_file_len(&dir), 4 * TRACKER_ENTRY_SIZE);
    let page_len = fs::metadata(dir.path().join("log_page_0.dat"))
        .unwrap()
        .len();

    // The stale flusher must not write anything again, its values and mappings are already
    // persisted
    stale_flusher().unwrap();
    assert_eq!(tracker_file_len(&dir), 4 * TRACKER_ENTRY_SIZE);
    assert_eq!(
        fs::metadata(dir.path().join("log_page_0.dat"))
            .unwrap()
            .len(),
        page_len,
    );

    drop(storage);
    let storage =
        Blobstore::<Payload>::open(MmapFs, dir.path().to_path_buf(), Populate::No).unwrap();
    assert_eq!(storage.max_point_offset(), 4);
    for point_offset in 0..4 {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(Payload::default()),
        );
    }
}

#[test]
fn test_flusher_after_clear_is_cancelled() {
    let (_dir, mut storage) = empty_storage_append_only();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    storage
        .put_value(0, &Payload::default(), hw_counter_ref)
        .unwrap();

    let flusher = storage.flusher();
    storage.clear().unwrap();

    let err = flusher().unwrap_err();
    assert!(matches!(err, BlobstoreError::FlushCancelled));
}

#[test]
fn test_clear_preserves_append_only_mode() {
    let (dir, mut storage) = empty_storage_append_only();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for point_offset in 0..3 {
        storage
            .put_value(point_offset, &Payload::default(), hw_counter_ref)
            .unwrap();
    }

    storage.clear().unwrap();
    assert_eq!(storage.max_point_offset(), 0);
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 0);

    // The storage is usable again, and putting restarts at point offset zero
    storage
        .put_value(0, &Payload::default(), hw_counter_ref)
        .unwrap();
    storage.flusher()().unwrap();

    // The recreated storage is still in append-only mode after reopening
    drop(storage);
    let storage =
        Blobstore::<Payload>::open(MmapFs, dir.path().to_path_buf(), Populate::No).unwrap();
    storage.as_logstore();
    assert_eq!(storage.max_point_offset(), 1);
}

#[test]
fn test_wipe_removes_all_files() {
    let (dir, mut storage) = empty_storage_append_only();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    storage
        .put_value(0, &Payload::default(), hw_counter_ref)
        .unwrap();

    storage.wipe().unwrap();
    assert!(!dir.path().exists());
}

#[test]
fn test_open_or_create_keeps_mode_on_disk() {
    let dir = TempDir::new().unwrap();
    let path = dir.path().join("storage");

    let config = StorageConfig::AppendOnly(LogstoreConfig::DEFAULT);
    let storage =
        Blobstore::<Payload>::open_or_create(MmapFs, path.clone(), config, Populate::No).unwrap();
    storage.as_logstore();
    drop(storage);

    // Opening again ignores the create config, the mode comes from the persisted config
    let storage = Blobstore::<Payload>::open_or_create(
        MmapFs,
        path,
        default_config(Mode::Mutable),
        Populate::No,
    )
    .unwrap();
    storage.as_logstore();
}

#[test]
fn test_reader_on_append_only_storage() {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression: Compression::None,
    });
    let mut storage = Blobstore::<Vec<u8>>::new(MmapFs, dir.path().to_path_buf(), config).unwrap();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for point_offset in [0, 1, 4] {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 10], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    // The reader selects the append-only mode automatically
    let reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 5);
    assert!(reader.is_on_disk());
    // Three values, packed back to back: point offset gaps take no page space
    assert_eq!(reader.get_storage_size_bytes(), 3 * 10);
    reader.clear_cache().unwrap();

    assert_eq!(
        reader.get_value::<Random>(0, &hw_counter).unwrap(),
        Some(vec![0; 10]),
    );
    assert_eq!(reader.get_value::<Random>(2, &hw_counter).unwrap(), None);

    // Reader files match the writer files
    let mut reader_files = reader.files();
    let mut writer_files = storage.files();
    reader_files.sort();
    writer_files.sort();
    assert_eq!(reader_files, writer_files);

    // Iteration is bounded by the given maximum id and skips gaps. Values are read in batches,
    // so the callback may be invoked in any order; sort before comparing.
    let mut collected = Vec::new();
    reader
        .iter(
            4,
            |point_offset, value: Vec<u8>| {
                collected.push((point_offset, value));
                Ok::<_, BlobstoreError>(true)
            },
            hw_counter.ref_payload_io_read_counter(),
        )
        .unwrap();
    collected.sort_by_key(|(point_offset, _)| *point_offset);
    assert_eq!(collected, vec![(0, vec![0; 10]), (1, vec![1; 10])]);

    // Batched reads through the reader and its view. The callback may be invoked in any order,
    // so sort before comparing.
    let mut collected = Vec::new();
    reader
        .read_values::<Random, _, BlobstoreError>(
            [(0, 0), (1, 3), (2, 4)].iter().copied(),
            |user_data, point_offset, value| {
                collected.push((user_data, point_offset, value.is_some()));
                Ok(())
            },
            hw_counter.payload_io_read_counter(),
        )
        .unwrap();
    collected.sort();
    assert_eq!(collected, vec![(0, 0, true), (1, 3, false), (2, 4, true)]);

    let view = reader.view();
    assert_eq!(view.max_point_offset().unwrap(), 5);
    assert_eq!(view.get_storage_size_bytes(), 3 * 10);
    assert_eq!(
        view.get_value::<Random>(4, &hw_counter).unwrap(),
        Some(vec![4; 10]),
    );
}

/// Replace the append-only tracker file in `dir` with a compacted one holding the same mappings.
fn compact_tracker(dir: &TempDir) {
    let tracker =
        AppendOnlyTracker::<MmapFile>::open_read_only(&MmapFs, dir.path(), Populate::No).unwrap();
    let compacted = CompactedTracker::from_tracker(&MmapFs, dir.path(), &tracker).unwrap();
    drop(tracker);
    compacted.flusher(PointOffset::MAX)().unwrap();
    fs::remove_file(dir.path().join("log_tracker.dat")).unwrap();
}

#[test]
fn test_reader_on_compacted_tracker() {
    let (dir, mut storage) = empty_byte_storage(Compression::None);
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let point_offsets = [0, 1, 4, 5, 9];
    for point_offset in point_offsets {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 10], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();
    drop(storage);
    compact_tracker(&dir);

    // The reader picks the compacted tracker automatically
    let mut reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 10);
    assert_eq!(reader.get_storage_size_bytes(), 5 * 10);
    for point_offset in 0..11 {
        let expected = point_offsets
            .contains(&point_offset)
            .then(|| vec![point_offset as u8; 10]);
        assert_eq!(
            reader
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            expected,
        );
    }

    let mut collected = Vec::new();
    reader
        .iter(
            PointOffset::MAX,
            |point_offset, value: Vec<u8>| {
                collected.push((point_offset, value));
                Ok::<_, BlobstoreError>(true)
            },
            hw_counter.ref_payload_io_read_counter(),
        )
        .unwrap();
    collected.sort_by_key(|(point_offset, _)| *point_offset);
    let expected = point_offsets
        .iter()
        .map(|&point_offset| (point_offset, vec![point_offset as u8; 10]))
        .collect::<Vec<_>>();
    assert_eq!(collected, expected);

    let mut files = reader.files();
    files.sort();
    assert_eq!(
        files,
        [
            dir.path().join("compacted_tracker.dat"),
            dir.path().join(CONFIG_FILENAME),
            dir.path().join("log_page_0.dat"),
        ],
    );

    reader.clear_cache().unwrap();
    reader.live_reload(&MmapFs).unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 10);
    assert_eq!(
        reader.get_value::<Random>(9, &hw_counter).unwrap(),
        Some(vec![9; 10]),
    );
}

/// A compacted storage opens writable, as every segment storage does, and keeps its tracker
/// compacted across puts and flushes.
#[test]
fn test_writable_open_on_compacted_tracker() {
    let (dir, mut storage) = empty_byte_storage(Compression::None);
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for point_offset in [0, 1, 4] {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 10], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();
    drop(storage);
    compact_tracker(&dir);

    let mut storage =
        Blobstore::<Vec<u8>>::open(MmapFs, dir.path().to_path_buf(), Populate::No).unwrap();
    assert_eq!(storage.max_point_offset(), 5);
    assert_eq!(
        storage.get_value::<Random>(4, &hw_counter).unwrap(),
        Some(vec![4; 10]),
    );
    storage.populate().unwrap();
    storage.clear_cache().unwrap();

    storage.put_value(6, &vec![6; 10], hw_counter_ref).unwrap();
    assert_eq!(storage.max_point_offset(), 7);
    assert_eq!(
        storage.get_value::<Random>(6, &hw_counter).unwrap(),
        Some(vec![6; 10]),
    );
    storage.flusher()().unwrap();
    let mut files = storage.files();
    files.sort();
    assert_eq!(
        files,
        [
            dir.path().join("compacted_tracker.dat"),
            dir.path().join(CONFIG_FILENAME),
            dir.path().join("log_page_0.dat"),
        ],
    );
    drop(storage);
    assert!(!dir.path().join("log_tracker.dat").exists());

    // The update-only writers open through `open_or_create`, same outcome
    let mut logstore = crate::Logstore::<Vec<u8>, MmapFile>::open_or_create(
        &MmapFs,
        dir.path().to_path_buf(),
        LogstoreConfig::DEFAULT,
        Populate::No,
    )
    .unwrap();
    logstore
        .put_value(&MmapFs, 7, &vec![7; 10], hw_counter_ref)
        .unwrap();
    logstore.flusher()().unwrap();
    drop(logstore);

    let reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 8);
    for point_offset in 0..9 {
        let expected = [0, 1, 4, 6, 7]
            .contains(&point_offset)
            .then(|| vec![point_offset as u8; 10]);
        assert_eq!(
            reader
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            expected,
        );
    }
}

/// Values of the given point offsets, as the tests put them, read through a fresh reader.
fn assert_reader_values(dir: &TempDir, count: PointOffset, present: &[PointOffset]) {
    let hw_counter = HardwareCounterCell::new();
    let reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), count);
    for point_offset in 0..count + 1 {
        let expected = present
            .contains(&point_offset)
            .then(|| vec![point_offset as u8; 10]);
        assert_eq!(
            reader
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            expected,
        );
    }
}

/// Making the storage immutable removes the append-only tracker file; the next flush saves the
/// compacted tracker with every put, flushed before or not.
#[test]
fn test_make_immutable_is_persisted_by_flush() {
    let (dir, mut storage) = empty_byte_storage(Compression::None);
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for point_offset in [0, 1, 4] {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 10], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();
    storage.put_value(5, &vec![5; 10], hw_counter_ref).unwrap();
    assert_eq!(storage.ram_usage_bytes(), 0);

    storage.make_immutable().unwrap();
    // Every mapping is held in RAM, not only the present ones
    assert!(storage.ram_usage_bytes() >= 6 * size_of::<Option<ValuePointer>>());
    assert!(!dir.path().join("log_tracker.dat").exists());
    assert!(!dir.path().join("compacted_tracker.dat").exists());
    assert_eq!(
        storage.get_value::<Random>(5, &hw_counter).unwrap(),
        Some(vec![5; 10]),
    );
    // Again changes nothing
    storage.make_immutable().unwrap();

    storage.flusher()().unwrap();
    assert!(dir.path().join("compacted_tracker.dat").exists());
    assert!(
        storage
            .files()
            .contains(&dir.path().join("compacted_tracker.dat"))
    );
    assert_reader_values(&dir, 6, &[0, 1, 4, 5]);

    // Still writable
    storage.put_value(7, &vec![7; 10], hw_counter_ref).unwrap();
    storage.flusher()().unwrap();
    drop(storage);
    assert_reader_values(&dir, 8, &[0, 1, 4, 5, 7]);
}

/// Until the flush after making it immutable, the storage on disk has no tracker file and does
/// not open.
#[test]
fn test_make_immutable_needs_a_flush() {
    let (dir, mut storage) = empty_byte_storage(Compression::None);
    let hw_counter = HardwareCounterCell::new();
    storage
        .put_value(0, &vec![0; 10], hw_counter.ref_payload_io_write_counter())
        .unwrap();
    storage.flusher()().unwrap();

    storage.make_immutable().unwrap();
    drop(storage);

    let err =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap_err();
    assert!(err.to_string().contains("does not exist"), "{err}");
}

#[test]
fn test_make_immutable_leaves_mutable_mode_alone() {
    let (dir, storage) = crate::fixtures::empty_storage();
    let files_before = storage.files();
    storage.make_immutable().unwrap();
    storage.flusher()().unwrap();
    assert_eq!(storage.files(), files_before);
    assert_eq!(storage.ram_usage_bytes(), 0);
    assert!(!dir.path().join("compacted_tracker.dat").exists());
}

/// Puts made after a flusher was created are not persisted by it, even though the compacted
/// tracker writes its whole file: their value data is not durable yet.
#[test]
fn test_compacted_flusher_skips_later_puts() {
    let (dir, mut storage) = empty_byte_storage(Compression::None);
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    storage.put_value(0, &vec![0; 10], hw_counter_ref).unwrap();
    storage.flusher()().unwrap();
    drop(storage);
    compact_tracker(&dir);

    let mut storage =
        Blobstore::<Vec<u8>>::open(MmapFs, dir.path().to_path_buf(), Populate::No).unwrap();
    storage.put_value(1, &vec![1; 10], hw_counter_ref).unwrap();
    let flusher = storage.flusher();
    storage.put_value(2, &vec![2; 10], hw_counter_ref).unwrap();
    flusher().unwrap();

    let reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 2);

    // The next flush persists the rest
    storage.flusher()().unwrap();
    let reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 3);
    assert_eq!(
        reader.get_value::<Random>(2, &hw_counter).unwrap(),
        Some(vec![2; 10]),
    );
}

/// Preopen schedules the compacted tracker file: once the prefetch is done, the open succeeds
/// with every file it reads through the backend deleted, see
/// `test_preopen_schedules_files_for_open`.
#[tokio::test]
async fn test_preopen_schedules_compacted_tracker() {
    use common::universal_io::{CachedFs, CachedReadFs, ReadOnly, UniversalRead, UniversalReadFs};

    let (dir, mut storage) = empty_byte_storage(Compression::None);
    let hw_counter = HardwareCounterCell::new();
    storage
        .put_value(0, &vec![7; 10], hw_counter.ref_payload_io_write_counter())
        .unwrap();
    storage.flusher()().unwrap();
    drop(storage);
    compact_tracker(&dir);

    type RoFs = <ReadOnly<MmapFile> as UniversalRead>::Fs;
    let fs = RoFs::from_context(Default::default()).unwrap();
    let mut cached_fs = CachedFs::new(fs, dir.path()).unwrap();
    cached_fs.cache_file_info().unwrap();
    BlobstoreReader::<Vec<u8>, ReadOnly<MmapFile>>::preopen(
        &cached_fs,
        dir.path().to_path_buf(),
        Populate::No,
    )
    .unwrap();
    cached_fs.wait_all().await;

    for file in ["config.json", "compacted_tracker.dat", "log_page_0.dat"] {
        fs::remove_file(dir.path().join(file)).unwrap();
    }

    let reader = BlobstoreReader::<Vec<u8>, ReadOnly<MmapFile>>::open(
        &cached_fs,
        dir.path().to_path_buf(),
        Populate::No,
    )
    .unwrap();
    assert_eq!(
        reader.get_value::<Random>(0, &hw_counter).unwrap(),
        Some(vec![7; 10]),
    );
}

/// Preopen fetches the whole compacted tracker file, not just a handle to it: once the prefetch
/// is done, opening through a disk cache no longer needs the remote tracker file.
#[tokio::test]
async fn test_preopen_fetches_compacted_tracker_through_disk_cache() {
    use std::sync::Arc;

    use common::universal_io::{
        CachedFs, CachedReadFs, DiskCache, DiskCacheConfig, DiskCacheFs, DiskCacheFsContext,
        UniversalReadFs,
    };

    let dir = TempDir::new().unwrap();
    let remote_root = dir.path().join("remote");
    let local_root = dir.path().join("local");
    let path = remote_root.join("storage");
    fs::create_dir_all(&path).unwrap();
    fs::create_dir_all(&local_root).unwrap();

    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression: Compression::None,
    });
    let mut storage = Blobstore::<Vec<u8>>::new(MmapFs, path.clone(), config).unwrap();
    let hw_counter = HardwareCounterCell::new();
    storage
        .put_value(0, &vec![7; 10], hw_counter.ref_payload_io_write_counter())
        .unwrap();
    storage.flusher()().unwrap();
    drop(storage);
    let tracker =
        AppendOnlyTracker::<MmapFile>::open_read_only(&MmapFs, &path, Populate::No).unwrap();
    let compacted = CompactedTracker::from_tracker(&MmapFs, &path, &tracker).unwrap();
    drop(tracker);
    compacted.flusher(PointOffset::MAX)().unwrap();
    fs::remove_file(path.join("log_tracker.dat")).unwrap();

    let cache_fs = DiskCacheFs::<MmapFile>::from_context(DiskCacheFsContext {
        config: Arc::new(DiskCacheConfig::new(remote_root, local_root).unwrap()),
        remote: Default::default(),
    })
    .unwrap();
    let mut cached_fs = CachedFs::new(cache_fs, &path).unwrap();
    cached_fs.cache_file_info().unwrap();
    BlobstoreReader::<Vec<u8>, DiskCache<MmapFile>>::preopen(
        &cached_fs,
        path.clone(),
        Populate::No,
    )
    .unwrap();
    cached_fs.wait_all().await;
    fs::remove_file(path.join("compacted_tracker.dat")).unwrap();

    let reader =
        BlobstoreReader::<Vec<u8>, DiskCache<MmapFile>>::open(&cached_fs, path, Populate::No)
            .unwrap();
    assert_eq!(
        reader.get_value::<Random>(0, &hw_counter).unwrap(),
        Some(vec![7; 10]),
    );
}

#[test]
fn test_reader_live_reload() {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression: Compression::None,
    });
    let mut storage = Blobstore::<Vec<u8>>::new(MmapFs, dir.path().to_path_buf(), config).unwrap();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for point_offset in 0..3 {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 10], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    let mut reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 3);

    // Without new data, a live reload changes nothing
    reader.live_reload(&MmapFs).unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 3);

    // The writer appends more values, the reader picks them up after a live reload
    for point_offset in 3..6 {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 10], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    reader.live_reload(&MmapFs).unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 6);
    assert_eq!(reader.get_storage_size_bytes(), 6 * 10);
    for point_offset in 0..6 {
        assert_eq!(
            reader
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(vec![point_offset as u8; 10]),
        );
    }

    // An unflushed put is buffered in the writer and puts nothing on disk, so a live reload
    // sees no change at all
    storage.put_value(6, &vec![6; 10], hw_counter_ref).unwrap();
    reader.live_reload(&MmapFs).unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 6);
    assert_eq!(reader.get_storage_size_bytes(), 6 * 10);
}

#[test]
fn test_reader_iter_many_values() {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression: Compression::None,
    });
    let mut storage = Blobstore::<Vec<u8>>::new(MmapFs, dir.path().to_path_buf(), config).unwrap();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    // More values than a single iteration batch (256)
    const COUNT: u32 = 1000;
    for point_offset in 0..COUNT {
        storage
            .put_value(
                point_offset,
                &point_offset.to_le_bytes().to_vec(),
                hw_counter_ref,
            )
            .unwrap();
    }
    storage.flusher()().unwrap();

    let reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();

    // Values are read in batches, so the callback may be invoked in any order. Each value
    // encodes its own point offset, so pairing is checked per callback and coverage in bulk.
    let mut seen = Vec::new();
    reader
        .iter(
            COUNT,
            |point_offset, value: Vec<u8>| {
                assert_eq!(value, point_offset.to_le_bytes().to_vec());
                seen.push(point_offset);
                Ok::<_, BlobstoreError>(true)
            },
            hw_counter.ref_payload_io_read_counter(),
        )
        .unwrap();
    seen.sort_unstable();
    assert_eq!(seen, (0..COUNT).collect::<Vec<_>>());

    // Early stop works across batches
    let mut count = 0;
    reader
        .iter(
            COUNT,
            |_, _: Vec<u8>| {
                count += 1;
                Ok::<_, BlobstoreError>(count < 300)
            },
            hw_counter.ref_payload_io_read_counter(),
        )
        .unwrap();
    assert_eq!(count, 300);
}

#[test]
fn test_open_rejects_truncated_page_file() {
    let dir = TempDir::new().unwrap();
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: DEFAULT_PAGE_SIZE_BYTES,
        compression: Compression::None,
    });
    let mut storage = Blobstore::<Vec<u8>>::new(MmapFs, dir.path().to_path_buf(), config).unwrap();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for point_offset in 0..3 {
        storage
            .put_value(point_offset, &vec![7; 100], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();
    drop(storage);

    // Truncate the page file below what the tracker references, like a partial copy would
    let page_path = dir.path().join("log_page_0.dat");
    let file = fs::OpenOptions::new().write(true).open(&page_path).unwrap();
    file.set_len(100).unwrap();
    drop(file);

    assert!(Blobstore::<Vec<u8>>::open(MmapFs, dir.path().to_path_buf(), Populate::No).is_err());

    // The reader skips the open check, the dangling mapping fails on read
    let reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert!(reader.get_value::<Random>(2, &hw_counter).is_err());
}

#[test]
fn test_read_from_pages_rejects_unknown_page() {
    let (dir, mut storage) = empty_storage_append_only();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    storage
        .put_value(0, &Payload::default(), hw_counter_ref)
        .unwrap();
    storage.flusher()().unwrap();

    let reader =
        BlobstoreReader::<Payload, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();

    // All values live in page 0, a pointer to any other page must not read anything
    let view = reader.view();
    let pointer = ValuePointer::new(1, 0, 8);
    let err = view.read_from_pages::<Random>(pointer).unwrap_err();
    assert!(matches!(err, BlobstoreError::PageNotFound { page_id: 1 },));
}

/// All writes must be pure appends: the tracker and page files only ever grow, and
/// previously written bytes are never touched.
#[test]
fn test_writes_only_append() {
    let (dir, mut storage) = empty_storage_append_only();

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let put = |storage: &mut Blobstore<Payload>, point_offset: u32, value: &str| {
        let mut payload = Payload::default();
        payload.0.insert(
            "key".to_string(),
            serde_json::Value::String(value.to_string()),
        );
        storage
            .put_value(point_offset, &payload, hw_counter_ref)
            .unwrap();
    };

    let page_path = dir.path().join("log_page_0.dat");
    let tracker_path = dir.path().join("log_tracker.dat");

    // Write, flush, and snapshot the raw file bytes
    put(&mut storage, 0, "first value");
    storage.flusher()().unwrap();
    let page_snapshot = fs::read(&page_path).unwrap();
    let tracker_snapshot = fs::read(&tracker_path).unwrap();
    assert!(!page_snapshot.is_empty(), "page must hold the first value");
    assert!(
        !tracker_snapshot.is_empty(),
        "tracker must hold the first mapping",
    );

    // Puts alone buffer in memory and leave both files byte-for-byte untouched
    put(&mut storage, 1, "second value");
    put(&mut storage, 2, "third value");
    assert_eq!(fs::read(&page_path).unwrap(), page_snapshot);
    assert_eq!(fs::read(&tracker_path).unwrap(), tracker_snapshot);

    // Flushing the puts must only extend both files
    storage.flusher()().unwrap();

    let page_grown = fs::read(&page_path).unwrap();
    assert!(
        page_grown.len() > page_snapshot.len(),
        "append-only writes must grow the page ({} -> {})",
        page_snapshot.len(),
        page_grown.len(),
    );
    assert_eq!(
        &page_grown[..page_snapshot.len()],
        &page_snapshot[..],
        "previously written page bytes must be untouched (append-only)",
    );

    let tracker_grown = fs::read(&tracker_path).unwrap();
    assert!(
        tracker_grown.len() > tracker_snapshot.len(),
        "append-only writes must grow the tracker ({} -> {})",
        tracker_snapshot.len(),
        tracker_grown.len(),
    );
    assert_eq!(
        &tracker_grown[..tracker_snapshot.len()],
        &tracker_snapshot[..],
        "previously written tracker bytes must be untouched (append-only)",
    );
}

/// New mappings are appended right at the end of the tracker file, which always covers the
/// exact number of mappings.
#[test]
fn test_tracker_appends_new_mappings_at_end() {
    const ENTRY_SIZE: usize = TRACKER_ENTRY_SIZE as usize;

    let (dir, mut storage) = empty_storage_append_only();
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();
    let tracker_path = dir.path().join("log_tracker.dat");

    let first_batch = 10u32;
    let second_batch = 25u32;

    for point_offset in 0..first_batch {
        storage
            .put_value(point_offset, &random_payload(rng, 1), hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    let before = fs::read(&tracker_path).unwrap();
    assert_eq!(
        before.len(),
        first_batch as usize * ENTRY_SIZE,
        "file must grow to exactly the appended mappings",
    );

    for point_offset in first_batch..second_batch {
        storage
            .put_value(point_offset, &random_payload(rng, 1), hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    let after = fs::read(&tracker_path).unwrap();
    assert_eq!(
        after.len(),
        second_batch as usize * ENTRY_SIZE,
        "file must grow to exactly the appended mappings",
    );

    // The full prefix must be byte-for-byte untouched
    assert_eq!(
        after[..before.len()],
        before[..],
        "existing bytes must stay untouched",
    );
    assert!(
        after[before.len()..]
            .chunks(ENTRY_SIZE)
            .all(|entry| entry.iter().any(|&byte| byte != 0)),
        "new mappings must fill the entries right after the existing ones",
    );
}

/// A mapping append past the end of the file pads the write with zeroed (unmapped) entries
/// so the mapping lands at its correct place.
#[test]
fn test_tracker_pads_mapping_gap_with_zeroes() {
    const ENTRY_SIZE: usize = TRACKER_ENTRY_SIZE as usize;

    let (dir, mut storage) = empty_storage_append_only();
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();

    // Write points 0 and 3, skipping 1 and 2
    let payload_0 = random_payload(rng, 1);
    let payload_3 = random_payload(rng, 1);
    storage.put_value(0, &payload_0, hw_counter_ref).unwrap();
    storage.put_value(3, &payload_3, hw_counter_ref).unwrap();
    storage.flusher()().unwrap();

    // The file covers entries 0..=3 exactly; the skipped entries are zero
    let bytes = fs::read(dir.path().join("log_tracker.dat")).unwrap();
    assert_eq!(bytes.len(), 4 * ENTRY_SIZE);
    assert!(
        bytes[ENTRY_SIZE..3 * ENTRY_SIZE]
            .iter()
            .all(|&byte| byte == 0),
        "skipped entries must be zero-padded",
    );

    // The skipped points read as missing; the mapped ones round-trip
    assert!(
        storage
            .get_value::<Random>(1, &hw_counter)
            .unwrap()
            .is_none()
    );
    assert!(
        storage
            .get_value::<Random>(2, &hw_counter)
            .unwrap()
            .is_none()
    );
    assert_eq!(
        storage
            .get_value::<Random>(0, &hw_counter)
            .unwrap()
            .as_ref(),
        Some(&payload_0),
    );
    assert_eq!(
        storage
            .get_value::<Random>(3, &hw_counter)
            .unwrap()
            .as_ref(),
        Some(&payload_3),
    );

    // Same after reopen; the count is derived from the exact file length
    let path = dir.path().to_path_buf();
    drop(storage);
    let storage = Blobstore::<Payload>::open(MmapFs, path, Populate::No).unwrap();
    assert_eq!(storage.max_point_offset(), 4);
    assert!(
        storage
            .get_value::<Random>(1, &hw_counter)
            .unwrap()
            .is_none()
    );
    assert_eq!(
        storage
            .get_value::<Random>(3, &hw_counter)
            .unwrap()
            .as_ref(),
        Some(&payload_3),
    );
}

/// Values are packed back to back: each value starts at the byte right after the previous
/// value, without blocks or alignment, and the page file ends exactly at the last value.
#[test]
fn test_values_are_packed_back_to_back() {
    let (dir, mut storage) = empty_byte_storage(Compression::None);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    let num_values = 64u32;
    let value = |i: u32| vec![i as u8; 1 + (i as usize * 37) % 300];
    for point_offset in 0..num_values {
        storage
            .put_value(point_offset, &value(point_offset), hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    // Each value starts at the byte right after the previous value
    let mut expected_start = 0;
    for point_offset in 0..num_values {
        let pointer = storage.get_pointer(point_offset).unwrap();
        assert_eq!(pointer.page_id, 0);
        assert_eq!(
            u64::from(pointer.block_offset),
            expected_start,
            "value {point_offset} must start right after the previous one",
        );
        expected_start += u64::from(pointer.length);

        assert_eq!(
            storage
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(value(point_offset)),
        );
    }

    // The page file ends exactly at the last value, without trailing padding
    let last_pointer = storage.get_pointer(num_values - 1).unwrap();
    let last_end = u64::from(last_pointer.block_offset) + u64::from(last_pointer.length);
    let page_len = fs::metadata(dir.path().join("log_page_0.dat"))
        .unwrap()
        .len();
    assert_eq!(page_len, last_end);
    assert_eq!(storage.get_storage_size_bytes().unwrap() as u64, last_end);
}

/// Append-only mode never creates or reports the block flag files of the mutable mode.
#[test]
fn test_has_no_block_flag_files() {
    let (dir, mut storage) = empty_storage_append_only();
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();

    for point_offset in 0..32u32 {
        storage
            .put_value(point_offset, &random_payload(rng, 2), hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    // Not on disk...
    let on_disk: Vec<String> = fs::read_dir(dir.path())
        .unwrap()
        .map(|entry| entry.unwrap().file_name().to_string_lossy().into_owned())
        .collect();
    assert!(
        !on_disk
            .iter()
            .any(|name| name == "bitmask.dat" || name == "gaps.dat"),
        "append-only mode must not create block flag files, found {on_disk:?}",
    );

    // ...and not reported by files()
    let reported: Vec<String> = storage
        .files()
        .into_iter()
        .map(|path| path.file_name().unwrap().to_string_lossy().into_owned())
        .collect();
    assert!(
        !reported
            .iter()
            .any(|name| name == "bitmask.dat" || name == "gaps.dat"),
        "files() must not report block flag files, got {reported:?}",
    );
}

/// A flusher persists exactly the mappings that existed when it was created: values put
/// afterwards stay pending and are lost when reopening without another flush.
#[test]
fn test_flusher_persists_mappings_up_to_creation() {
    let (dir, mut storage) = empty_storage_append_only();
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();

    let payloads: Vec<_> = (0..5).map(|_| random_payload(rng, 1)).collect();
    for (point_offset, payload) in payloads.iter().enumerate().take(3) {
        storage
            .put_value(point_offset as u32, payload, hw_counter_ref)
            .unwrap();
    }

    let flusher = storage.flusher();

    for (point_offset, payload) in payloads.iter().enumerate().skip(3) {
        storage
            .put_value(point_offset as u32, payload, hw_counter_ref)
            .unwrap();
    }

    // The flusher only persists the values and mappings that existed when it was created
    flusher().unwrap();
    assert_eq!(tracker_file_len(&dir), 3 * TRACKER_ENTRY_SIZE);

    // The page file holds exactly the extent of the values covered by the flusher
    let covered_pointer = storage.get_pointer(2).unwrap();
    let covered_extent =
        u64::from(covered_pointer.block_offset) + u64::from(covered_pointer.length);
    assert_eq!(
        fs::metadata(dir.path().join("log_page_0.dat"))
            .unwrap()
            .len(),
        covered_extent,
    );

    // In this session all values are readable, the later ones from the in-memory buffers
    for (point_offset, payload) in payloads.iter().enumerate() {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset as u32, &hw_counter)
                .unwrap()
                .as_ref(),
            Some(payload),
        );
    }

    // On reopen, only the flushed mappings are left
    let path = dir.path().to_path_buf();
    drop(storage);
    let storage = Blobstore::<Payload>::open(MmapFs, path, Populate::No).unwrap();
    assert_eq!(storage.max_point_offset(), 3);
    for (point_offset, payload) in payloads.iter().enumerate() {
        let expected = (point_offset < 3).then_some(payload);
        assert_eq!(
            storage
                .get_value::<Random>(point_offset as u32, &hw_counter)
                .unwrap()
                .as_ref(),
            expected,
        );
    }
}

/// The two modes have deliberately distinct file names, so a config that claims the wrong
/// mode fails loudly instead of loading the incompatible file format of the other mode.
#[rstest::rstest]
#[case(Mode::Mutable, Mode::AppendOnly)]
#[case(Mode::AppendOnly, Mode::Mutable)]
fn test_open_wrong_mode_fails(#[case] created: Mode, #[case] tampered: Mode) {
    let dir = TempDir::new().unwrap();
    let path = dir.path().to_path_buf();

    let config = default_config(created);
    let mut storage = Blobstore::<Payload>::new(MmapFs, path.clone(), config).unwrap();
    let hw_counter = HardwareCounterCell::new();
    storage
        .put_value(
            0,
            &Payload::default(),
            hw_counter.ref_payload_io_write_counter(),
        )
        .unwrap();
    storage.flusher()().unwrap();
    drop(storage);

    // Tamper with the persisted mode, pointing it at the other mode
    let config_path = path.join(CONFIG_FILENAME);
    let config_json = fs::read_to_string(&config_path).unwrap();
    let mut config: serde_json::Map<String, serde_json::Value> =
        serde_json::from_str(&config_json).unwrap();
    let mode_name = match tampered {
        Mode::Mutable => "mutable",
        Mode::AppendOnly => "append_only",
    };
    config.insert("mode".to_string(), mode_name.into());
    fs::write(&config_path, serde_json::to_vec(&config).unwrap()).unwrap();

    // The other mode never finds its own files, so opening fails instead of misreading
    assert!(Blobstore::<Payload>::open(MmapFs, path.clone(), Populate::No).is_err());
    assert!(BlobstoreReader::<Payload, MmapFile>::open(&MmapFs, path, Populate::No).is_err());
}

/// Replaying puts of already persisted point offsets (e.g. a WAL redo after a crash where
/// the flush completed but was never acknowledged) is rejected without writing anything;
/// [`Blobstore::max_point_offset`] is the exact offset a replay must resume at.
#[test]
fn test_replayed_puts_leave_storage_intact() {
    let dir = TempDir::new().unwrap();
    let path = dir.path().to_path_buf();
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();

    let payloads: Vec<_> = (0..3).map(|_| random_payload(rng, 1)).collect();
    {
        let config = StorageConfig::AppendOnly(LogstoreConfig::DEFAULT);
        let mut storage = Blobstore::<Payload>::new(MmapFs, path.clone(), config).unwrap();
        for (point_offset, payload) in payloads.iter().enumerate() {
            storage
                .put_value(point_offset as u32, payload, hw_counter_ref)
                .unwrap();
        }
        storage.flusher()().unwrap();
    }

    // "Crash" and replay all operations against the reopened storage
    let mut storage = Blobstore::<Payload>::open(MmapFs, path, Populate::No).unwrap();
    let tracker_snapshot = fs::read(storage.files()[0].clone()).unwrap();
    let page_len = storage.get_storage_size_bytes().unwrap();

    let resume_at = storage.max_point_offset();
    assert_eq!(resume_at, 3);
    for (point_offset, payload) in payloads.iter().enumerate() {
        let err = storage
            .put_value(point_offset as u32, payload, hw_counter_ref)
            .unwrap_err();
        assert!(matches!(err, BlobstoreError::UnsupportedOperation { .. }));
    }

    // The rejected replays must not have appended any value data or mappings
    assert_eq!(storage.get_storage_size_bytes().unwrap(), page_len);
    storage.flusher()().unwrap();
    assert_eq!(
        fs::read(storage.files()[0].clone()).unwrap(),
        tracker_snapshot,
    );

    // The stored values are unaffected, and the replay resumes at the reported offset
    for (point_offset, payload) in payloads.iter().enumerate() {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset as u32, &hw_counter)
                .unwrap()
                .as_ref(),
            Some(payload),
        );
    }
    storage
        .put_value(resume_at, &random_payload(rng, 1), hw_counter_ref)
        .unwrap();
    assert_eq!(storage.max_point_offset(), 4);
}

/// The accepted crash case: a tracker file extended with zeroed bytes (e.g. the file length
/// was persisted before the entry bytes) counts as mappings that permanently read as `None`.
/// The storage must stay consistent and writable past them.
#[test]
fn test_zero_extended_tracker_reads_none() {
    let dir = TempDir::new().unwrap();
    let path = dir.path().to_path_buf();
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();

    let payloads: Vec<_> = (0..3).map(|_| random_payload(rng, 1)).collect();
    {
        let config = StorageConfig::AppendOnly(LogstoreConfig::DEFAULT);
        let mut storage = Blobstore::<Payload>::new(MmapFs, path.clone(), config).unwrap();
        for (point_offset, payload) in payloads.iter().enumerate() {
            storage
                .put_value(point_offset as u32, payload, hw_counter_ref)
                .unwrap();
        }
        storage.flusher()().unwrap();
    }

    // Simulate a crash mid flush that persisted the grown file length as zeroes
    let tracker_path = path.join("log_tracker.dat");
    let file = fs::OpenOptions::new()
        .write(true)
        .open(&tracker_path)
        .unwrap();
    file.set_len(5 * TRACKER_ENTRY_SIZE).unwrap();
    drop(file);

    // The zeroed entries count as mappings without a value
    let mut storage = Blobstore::<Payload>::open(MmapFs, path.clone(), Populate::No).unwrap();
    assert_eq!(storage.max_point_offset(), 5);
    assert!(
        storage
            .get_value::<Random>(3, &hw_counter)
            .unwrap()
            .is_none()
    );
    assert!(
        storage
            .get_value::<Random>(4, &hw_counter)
            .unwrap()
            .is_none()
    );

    // They can never be put again, the storage continues past them
    assert!(
        storage
            .put_value(3, &random_payload(rng, 1), hw_counter_ref)
            .is_err()
    );
    storage
        .put_value(5, &random_payload(rng, 1), hw_counter_ref)
        .unwrap();
    assert_eq!(storage.max_point_offset(), 6);
    storage.flusher()().unwrap();

    // Data before the zeroed entries is unaffected
    for (point_offset, payload) in payloads.iter().enumerate() {
        assert_eq!(
            storage
                .get_value::<Random>(point_offset as u32, &hw_counter)
                .unwrap()
                .as_ref(),
            Some(payload),
        );
    }

    // The reader agrees on the same view
    drop(storage);
    let reader = BlobstoreReader::<Payload, MmapFile>::open(&MmapFs, path, Populate::No).unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 6);
    assert!(
        reader
            .get_value::<Random>(4, &hw_counter)
            .unwrap()
            .is_none()
    );
}

/// The read-only reader must never modify the files: not on open (it must not truncate a
/// torn tracker tail), not on reads, and not on live reloads.
#[test]
fn test_reader_never_writes() {
    let dir = TempDir::new().unwrap();
    let path = dir.path().to_path_buf();
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();

    let payloads: Vec<_> = (0..5).map(|_| random_payload(rng, 1)).collect();
    {
        let config = StorageConfig::AppendOnly(LogstoreConfig::DEFAULT);
        let mut storage = Blobstore::<Payload>::new(MmapFs, path.clone(), config).unwrap();
        for (point_offset, payload) in payloads.iter().enumerate() {
            storage
                .put_value(point_offset as u32, payload, hw_counter_ref)
                .unwrap();
        }
        storage.flusher()().unwrap();
    }

    // Leave a torn trailing entry, as if a writer append was cut short
    let tracker_path = path.join("log_tracker.dat");
    let page_path = path.join("log_page_0.dat");
    {
        use std::io::Write as _;
        let mut file = fs::OpenOptions::new()
            .append(true)
            .open(&tracker_path)
            .unwrap();
        file.write_all(&[0xAA; 7]).unwrap();
    }

    let tracker_snapshot = fs::read(&tracker_path).unwrap();
    let page_snapshot = fs::read(&page_path).unwrap();

    // Open a reader and exercise every read path
    let mut reader =
        BlobstoreReader::<Payload, MmapFile>::open(&MmapFs, path, Populate::No).unwrap();
    assert_eq!(
        reader.max_point_offset().unwrap(),
        5,
        "torn tail must be ignored"
    );
    for (point_offset, payload) in payloads.iter().enumerate() {
        assert_eq!(
            reader
                .get_value::<Random>(point_offset as u32, &hw_counter)
                .unwrap()
                .as_ref(),
            Some(payload),
        );
    }
    let mut count = 0;
    reader
        .iter(
            u32::MAX,
            |_, _: Payload| {
                count += 1;
                Ok::<_, BlobstoreError>(true)
            },
            hw_counter.ref_payload_io_read_counter(),
        )
        .unwrap();
    assert_eq!(count, 5);
    reader.live_reload(&MmapFs).unwrap();
    reader.get_storage_size_bytes();
    reader.clear_cache().unwrap();
    drop(reader);

    // The reader must have left both files byte-for-byte untouched
    assert_eq!(fs::read(&tracker_path).unwrap(), tracker_snapshot);
    assert_eq!(fs::read(&page_path).unwrap(), page_snapshot);
}

/// Every reopen must expose exactly the flushed prefix: values flushed before are readable,
/// unflushed ones are gone, and the mapping count always matches the exact file length.
#[test]
fn test_reopen_always_exposes_flushed_prefix() {
    let dir = TempDir::new().unwrap();
    let path = dir.path().to_path_buf();
    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    let rng = &mut rand::make_rng::<rand::rngs::SmallRng>();

    let config = StorageConfig::AppendOnly(LogstoreConfig::DEFAULT);
    let mut storage = Blobstore::<Payload>::new(MmapFs, path.clone(), config).unwrap();

    // The values that must be visible after a reopen
    let mut flushed: Vec<Payload> = Vec::new();

    for round in 0..6 {
        // Put a batch at the next offsets; after a reopen unflushed offsets are reused
        let batch: Vec<_> = (0..3).map(|_| random_payload(rng, 1)).collect();
        for (index, payload) in batch.iter().enumerate() {
            let point_offset = flushed.len() as u32 + index as u32;
            storage
                .put_value(point_offset, payload, hw_counter_ref)
                .unwrap();
        }

        // Only flush every other round
        if round % 2 == 0 {
            storage.flusher()().unwrap();
            flushed.extend(batch);
        }

        // Every reopen must expose exactly the flushed values
        drop(storage);
        storage = Blobstore::<Payload>::open(MmapFs, path.clone(), Populate::No).unwrap();

        assert_eq!(storage.max_point_offset(), flushed.len() as u32);
        assert_eq!(
            fs::metadata(path.join("log_tracker.dat")).unwrap().len(),
            flushed.len() as u64 * TRACKER_ENTRY_SIZE,
        );

        // The page file holds exactly the flushed values, unflushed puts leave no bytes behind
        let flushed_extent = flushed
            .len()
            .checked_sub(1)
            .and_then(|last| storage.get_pointer(last as u32))
            .map_or(0, |pointer| {
                u64::from(pointer.block_offset) + u64::from(pointer.length)
            });
        assert_eq!(
            fs::metadata(path.join("log_page_0.dat")).unwrap().len(),
            flushed_extent,
            "the page file must hold exactly the flushed values",
        );

        for (point_offset, payload) in flushed.iter().enumerate() {
            assert_eq!(
                storage
                    .get_value::<Random>(point_offset as u32, &hw_counter)
                    .unwrap()
                    .as_ref(),
                Some(payload),
                "flushed value {point_offset} must be readable after reopen",
            );
        }
        assert!(
            storage
                .get_value::<Random>(flushed.len() as u32, &hw_counter)
                .unwrap()
                .is_none(),
            "unflushed values must be gone after reopen",
        );
    }
}

/// Create an empty append-only storage of raw byte values with a small page size, so a few
/// small values roll over to new pages.
fn small_page_storage(dir: &TempDir, page_size_bytes: usize) -> Blobstore<Vec<u8>> {
    let config = StorageConfig::AppendOnly(LogstoreConfig {
        page_capacity_bytes: page_size_bytes,
        compression: Compression::None,
    });
    Blobstore::new(MmapFs, dir.path().to_path_buf(), config).unwrap()
}

/// Once a page is full, the next value starts a new page: values are packed back to back
/// within a page, and a value that does not fit rolls over to a freshly created page file.
#[test]
fn test_full_page_rolls_over_to_new_page() {
    let dir = TempDir::new().unwrap();
    let mut storage = small_page_storage(&dir, 256);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    // Two 100 byte values fit in the first page, the third one starts the second page
    for point_offset in 0..5 {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 100], hw_counter_ref)
            .unwrap();
    }

    for (point_offset, page_id, offset) in
        [(0, 0, 0), (1, 0, 100), (2, 1, 0), (3, 1, 100), (4, 2, 0)]
    {
        let pointer = storage.get_pointer(point_offset).unwrap();
        assert_eq!(
            (pointer.page_id, pointer.block_offset),
            (page_id, offset),
            "value {point_offset} must land at page {page_id} offset {offset}",
        );
    }
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 5 * 100);

    // All values are readable, before and after a flush, and after a reopen
    let assert_all_readable = |storage: &Blobstore<Vec<u8>>| {
        for point_offset in 0..5 {
            assert_eq!(
                storage
                    .get_value::<Random>(point_offset, &hw_counter)
                    .unwrap(),
                Some(vec![point_offset as u8; 100]),
            );
        }
    };
    assert_all_readable(&storage);

    // A single flush lands the values buffered across the pages, each page file holds exactly
    // its values
    storage.flusher()().unwrap();
    assert_all_readable(&storage);
    for (page_id, len) in [(0u32, 200u64), (1, 200), (2, 100)] {
        assert_eq!(
            fs::metadata(dir.path().join(format!("log_page_{page_id}.dat")))
                .unwrap()
                .len(),
            len,
            "page {page_id} must hold exactly its values",
        );
    }

    // All page files are reported, in order
    let files = storage.files();
    let file_names: Vec<_> = files
        .iter()
        .map(|path| path.file_name().unwrap().to_string_lossy().into_owned())
        .collect();
    assert_eq!(
        file_names,
        [
            "log_tracker.dat",
            "log_page_0.dat",
            "log_page_1.dat",
            "log_page_2.dat",
            "config.json",
        ],
    );

    // Everything is still there after reopening, appends continue on the last page
    drop(storage);
    let mut storage =
        Blobstore::<Vec<u8>>::open(MmapFs, dir.path().to_path_buf(), Populate::No).unwrap();
    assert_all_readable(&storage);
    assert_eq!(storage.get_storage_size_bytes().unwrap(), 5 * 100);

    storage.put_value(5, &vec![5; 100], hw_counter_ref).unwrap();
    let pointer = storage.get_pointer(5).unwrap();
    assert_eq!((pointer.page_id, pointer.block_offset), (2, 100));
}

/// A value larger than the page size gets a page of its own: values never span pages, and the
/// next value starts yet another page.
#[test]
fn test_value_larger_than_page_gets_own_page() {
    let dir = TempDir::new().unwrap();
    let mut storage = small_page_storage(&dir, 256);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    let huge = (0..1000).map(|i| i as u8).collect::<Vec<u8>>();
    storage.put_value(0, &vec![1; 100], hw_counter_ref).unwrap();
    storage.put_value(1, &huge, hw_counter_ref).unwrap();
    storage.put_value(2, &vec![2; 100], hw_counter_ref).unwrap();
    storage.flusher()().unwrap();

    for (point_offset, page_id) in [(0, 0), (1, 1), (2, 2)] {
        let pointer = storage.get_pointer(point_offset).unwrap();
        assert_eq!((pointer.page_id, pointer.block_offset), (page_id, 0));
    }

    assert_eq!(
        fs::metadata(dir.path().join("log_page_1.dat"))
            .unwrap()
            .len(),
        huge.len() as u64,
        "the oversized value must get a page of its own",
    );

    assert_eq!(
        storage.get_value::<Random>(1, &hw_counter).unwrap(),
        Some(huge),
    );
    assert_eq!(
        storage.get_value::<Random>(2, &hw_counter).unwrap(),
        Some(vec![2; 100]),
    );
}

/// The reader reads values across all pages, and a live reload adopts page files that were
/// created after it opened the storage.
#[test]
fn test_reader_reads_across_pages_and_adopts_new_pages() {
    let dir = TempDir::new().unwrap();
    let mut storage = small_page_storage(&dir, 256);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    // Three values spanning two pages
    for point_offset in 0..3 {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 100], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    let mut reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 3);
    assert_eq!(reader.get_storage_size_bytes(), 3 * 100);
    for point_offset in 0..3 {
        assert_eq!(
            reader
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(vec![point_offset as u8; 100]),
        );
    }

    // Reader files match the writer files, including all pages
    let mut reader_files = reader.files();
    let mut writer_files = storage.files();
    reader_files.sort();
    writer_files.sort();
    assert_eq!(reader_files, writer_files);

    // The writer appends more values, rolling over to pages the reader has never seen
    for point_offset in 3..7 {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 100], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();

    reader.live_reload(&MmapFs).unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 7);
    assert_eq!(reader.get_storage_size_bytes(), 7 * 100);
    for point_offset in 0..7 {
        assert_eq!(
            reader
                .get_value::<Random>(point_offset, &hw_counter)
                .unwrap(),
            Some(vec![point_offset as u8; 100]),
            "value {point_offset} must be readable after the live reload",
        );
    }

    // Batched reads cross page boundaries too
    let mut collected = Vec::new();
    reader
        .read_values::<Random, _, BlobstoreError>(
            (0..7).map(|point_offset| (point_offset, point_offset)),
            |_, point_offset, value| {
                collected.push((point_offset, value.unwrap()));
                Ok(())
            },
            hw_counter.payload_io_read_counter(),
        )
        .unwrap();
    assert_eq!(collected.len(), 7);
    for (point_offset, value) in collected {
        assert_eq!(value, vec![point_offset as u8; 100]);
    }
}

/// Opening fails when mappings reference a page file that is missing, like after a partial
/// copy of the storage directory.
#[test]
fn test_open_rejects_missing_page_file() {
    let dir = TempDir::new().unwrap();
    let mut storage = small_page_storage(&dir, 256);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for point_offset in 0..5 {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 100], hw_counter_ref)
            .unwrap();
    }
    storage.flusher()().unwrap();
    drop(storage);

    // Remove a page in the middle, like a partial copy would
    fs::remove_file(dir.path().join("log_page_1.dat")).unwrap();

    assert!(Blobstore::<Vec<u8>>::open(MmapFs, dir.path().to_path_buf(), Populate::No).is_err());

    // The reader skips the open check, the dangling mapping fails on read
    let reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert!(reader.get_value::<Random>(4, &hw_counter).is_err());
}

/// A page rollover only creates the new, empty page file: the buffered values still land on
/// disk in a single append per page at the next flush.
#[test]
fn test_rollover_writes_no_value_data_before_flush() {
    let dir = TempDir::new().unwrap();
    let mut storage = small_page_storage(&dir, 256);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();
    for point_offset in 0..3 {
        storage
            .put_value(point_offset, &vec![point_offset as u8; 100], hw_counter_ref)
            .unwrap();
    }

    // The rollover created the second page file, but no value data is on disk yet
    for page_id in 0..2 {
        assert_eq!(
            fs::metadata(dir.path().join(format!("log_page_{page_id}.dat")))
                .unwrap()
                .len(),
            0,
            "no value data must land on disk before the flush",
        );
    }

    storage.flusher()().unwrap();
    assert_eq!(
        fs::metadata(dir.path().join("log_page_0.dat"))
            .unwrap()
            .len(),
        200,
    );
    assert_eq!(
        fs::metadata(dir.path().join("log_page_1.dat"))
            .unwrap()
            .len(),
        100,
    );
}

/// A reader that live-reloads between a page rollover and the following flush adopts the new,
/// still empty page. The previous page is then no longer the last one, but its late-flushed
/// tail must still become visible: the tracker mappings gained since the last reload tell the
/// reader which pages to reload.
#[test]
fn test_live_reload_sees_late_flushed_tail_of_rolled_over_page() {
    let dir = TempDir::new().unwrap();
    let mut storage = small_page_storage(&dir, 256);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    // One flushed value so the reader can open
    storage
        .put_value(0, &vec![0u8; 100], hw_counter_ref)
        .unwrap();
    storage.flusher()().unwrap();

    let mut reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();

    // Writer buffers a second value into page 0, then rolls over to page 1 (created on disk,
    // empty), all without flushing
    storage
        .put_value(1, &vec![1u8; 100], hw_counter_ref)
        .unwrap();
    storage
        .put_value(2, &vec![2u8; 100], hw_counter_ref)
        .unwrap();

    // Reader reloads in the rollover-to-flush window: it adopts the empty page 1, page 0 is no
    // longer the last page
    reader.live_reload(&MmapFs).unwrap();

    // The flush appends value 1 to page 0 and value 2 to page 1
    storage.flusher()().unwrap();

    // Reader reloads again: only the last page (1) is refreshed, page 0 stays stale
    reader.live_reload(&MmapFs).unwrap();

    assert_eq!(reader.max_point_offset().unwrap(), 3);
    assert_eq!(
        reader.get_value::<Random>(1, &hw_counter).unwrap(),
        Some(vec![1u8; 100]),
        "value 1 lives in page 0's late-flushed tail",
    );
    assert_eq!(
        reader.get_value::<Random>(2, &hw_counter).unwrap(),
        Some(vec![2u8; 100]),
    );
}

/// Counterexample check: a flusher created before a rollover grows only the old page. A reader
/// that opened during the rollover-to-flush window already holds the new page, still empty and
/// unchanged by this flush. The reload must still refresh the old page's late-flushed tail.
#[test]
fn test_live_reload_refreshes_old_page_behind_unchanged_empty_page() {
    let dir = TempDir::new().unwrap();
    let mut storage = small_page_storage(&dir, 256);

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    // One flushed value so the reader can open
    storage
        .put_value(0, &vec![0u8; 100], hw_counter_ref)
        .unwrap();
    storage.flusher()().unwrap();

    // Buffer a second value into page 0, capture a flusher BEFORE the rollover
    storage
        .put_value(1, &vec![1u8; 100], hw_counter_ref)
        .unwrap();
    let flusher = storage.flusher();

    // Rollover: page 1 is created on disk (empty), value 2 stays buffered for it
    storage
        .put_value(2, &vec![2u8; 100], hw_counter_ref)
        .unwrap();

    // Reader opens in the rollover-to-flush window: holds page 0 (100 bytes) and page 1 (empty)
    let mut reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();

    // The pre-rollover flusher appends value 1 to page 0 only; page 1 stays empty
    flusher().unwrap();

    reader.live_reload(&MmapFs).unwrap();

    assert_eq!(reader.max_point_offset().unwrap(), 2);
    assert_eq!(
        reader.get_value::<Random>(1, &hw_counter).unwrap(),
        Some(vec![1u8; 100]),
        "value 1 lives in page 0's late-flushed tail, behind the unchanged empty page 1",
    );
}

/// A live reload whose page reload fails must not publish the mappings it already observed:
/// they would reference value data the reader never loaded. The reader keeps serving its
/// pre-reload state, and a later reload picks the new mappings up once the pages load again.
///
/// Not run on Windows: the failure is injected by shrinking a page file out of band, which the
/// OS refuses while the reader holds it mapped ("cannot be performed on a file with a
/// user-mapped section open"). That is a limitation of the injection, not of the storage — its
/// own append path grows mapped pages on Windows fine. The logic under test is platform
/// independent and stays covered on the other targets.
#[cfg(not(windows))]
#[test]
fn test_failed_page_reload_does_not_publish_mappings() {
    let dir = TempDir::new().unwrap();
    let mut storage = small_page_storage(&dir, 256);
    let page_path = dir.path().join("log_page_0.dat");

    let hw_counter = HardwareCounterCell::new();
    let hw_counter_ref = hw_counter.ref_payload_io_write_counter();

    storage
        .put_value(0, &vec![0u8; 100], hw_counter_ref)
        .unwrap();
    storage.flusher()().unwrap();

    // Reader holds page 0 at 100 bytes and a single mapping
    let mut reader =
        BlobstoreReader::<Vec<u8>, MmapFile>::open(&MmapFs, dir.path().to_path_buf(), Populate::No)
            .unwrap();
    assert_eq!(reader.max_point_offset().unwrap(), 1);

    // Value 1 lands in page 0's tail, so the new mapping only resolves against the grown page
    storage
        .put_value(1, &vec![1u8; 100], hw_counter_ref)
        .unwrap();
    storage.flusher()().unwrap();

    // Make the page reload fail: the page appears shorter than what the reader already holds
    let page_bytes = fs::read(&page_path).unwrap();
    assert_eq!(page_bytes.len(), 200);
    fs::write(&page_path, &page_bytes[..50]).unwrap();

    reader
        .live_reload(&MmapFs)
        .expect_err("a page shorter than the one held must fail the reload");

    assert_eq!(
        reader.max_point_offset().unwrap(),
        1,
        "the observed mapping must stay unpublished, it references value data \
         that failed to load",
    );

    // Undo the sabotage: the same reader recovers on the next reload, nothing was lost
    fs::write(&page_path, &page_bytes).unwrap();
    reader.live_reload(&MmapFs).unwrap();

    assert_eq!(reader.max_point_offset().unwrap(), 2);
    assert_eq!(
        reader.get_value::<Random>(0, &hw_counter).unwrap(),
        Some(vec![0u8; 100]),
    );
    assert_eq!(
        reader.get_value::<Random>(1, &hw_counter).unwrap(),
        Some(vec![1u8; 100]),
    );
}
