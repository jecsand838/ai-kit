---
name: audit-workspace-test-coverage
description: "Use when performing a read-only Rurr workspace or subsystem audit for missing unit, integration, live, negative-path, facade, or Burr-parity test coverage before planning or implementation, including mapping current tests, docs, and gates to concrete coverage gaps. Do not use for fixing one failing test, direct bug-fix triage, or implementing changes."
---

# Audit Workspace Test Coverage

Use this skill when the user wants a read-only audit of where Rurr test coverage is thin, missing, mis-layered, or misaligned with current docs, gates, or Burr parity evidence.

## Quick start

Load, in order:

- `README.md`
- `docs/00_overview.md`
- `docs/03_test_plan.md`
- `docs/RURR_TEST_MATRIX.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`
- the relevant crate tests, live tests, oracle fixtures, and gate scripts
- the matching Burr source under `tools/burr_oracle/vendor/apache-burr/` when the audited behavior is parity-sensitive

Load these companion skills:

- `$use-rust-best-practices-testing`
- `$rurr-burr-source-parity-walk`

## When to use

Use it when the task:

- asks for a workspace-wide or subsystem-wide test coverage audit
- asks where unit, integration, live, negative-path, or facade coverage is missing
- asks whether current Rurr coverage matches the documented test plan, test matrix, or Burr-backed behavior
- needs a ranked finding list before planning or implementation starts

## Workflow

1. Inventory the current test surfaces and verification scripts by crate, behavior, and execution lane.
2. Compare the current tests against the documented test plan, matrix, and gate coverage.
3. Use Burr source and oracle evidence when needed to separate parity-critical gaps from Rurr-local implementation choices.
4. Identify missing or weak coverage by level, preferring the narrowest truthful test layer that can prove the behavior.
5. Route external/provider/backend behaviors without a named strict proof lane to `$audit-workspace-for-shims` instead of treating them as ordinary local coverage gaps.
6. Separate in-scope current gaps from intentionally deferred or explicitly out-of-scope surfaces.
7. Rank findings by regression risk, parity importance, and implementation leverage, then cite the evidence that supports each one.

## Output contract

Return:

- the affected behavior or subsystem
- the current evidence inspected
- the missing or weak coverage
- the recommended test level
- the likely proof target or file area
- the parity, gate, or environment constraint that matters
- a ranked priority or urgency signal
- whether the gap is in scope now or intentionally deferred

## Default rules

- Stay read-only and do not propose implementation as already complete.
- Prefer the narrowest test level that truthfully proves the behavior.
- Do not recommend fake or purely local tests as the authoritative proof for external/provider
  behavior when the workspace lacks a named strict proof lane; flag that as a proof-gap or shim
  audit candidate instead.
- Do not treat intentionally excluded matrix cells as parity regressions unless the project scope changed.
- Prefer cited source, test, and gate evidence over vague architectural memory.
- Call out uncertainty explicitly when Rurr and Burr evidence do not line up cleanly.

## Do not use this skill alone when

- the user wants the coverage findings turned into a concrete plan or implementation pass: also use `$expand-workspace-test-coverage`
- the user needs a disputed subsystem-level Burr comparison settled before the audit recommendation: also use `$rurr-burr-source-parity-walk`
- the user only needs closeout or gate selection after changes already exist: also use `$rurr-gate-closeout`
- the task is really one failing test or direct bug-fix triage: use the relevant subsystem guardrail skill and Rust testing guidance instead of this workspace audit
