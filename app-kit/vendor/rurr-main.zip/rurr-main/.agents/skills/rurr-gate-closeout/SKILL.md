---
name: rurr-gate-closeout
description: "Use when a Rurr change is already implemented and the task is to choose changed-file-aware verification gates, run structural completion checks, handle manifest or temp-index fallout, and produce a truthful closeout summary."
---

# Rurr Gate Closeout

Use this skill when the code changes already exist and the user needs the right verification stack, manifest handling, and final handoff summary.

## Quick start

Load, in order:

- `AGENTS.md`
- `README.md`
- `docs/00_overview.md`
- the approved plan or the actual changed files, if present

Use `$rurr-structural-completion-audit` first when the change was a cleanup, refactor, or parity-sensitive structural reduction.

Use `$rurr-skill-catalog-maintenance` when `.agents/skills` files changed.

Use these scripts as the primary closeout surface:

- `./scripts/check.sh`
- `./scripts/check_oracle.sh`
- `./scripts/check_competition.sh`
- `./scripts/check_live.sh`
- `./scripts/check_openai_live.sh`
- `./scripts/fix_manifest_freshness.sh`

Load compatibility docs only when the touched code is parity-sensitive:

- `docs/ARCHITECTURE_GUARDRAILS.md`
- `docs/compatibility/DIVERGENCES.md`
- `docs/compatibility/SEMANTICS.md`

## When to use

Use it when the task:

- asks which Rurr gates should run before handoff
- asks for changed-file-aware gate selection
- asks whether structural completion checks should run before final gates
- asks for manifest freshness or generated snapshot cleanup
- needs temp-index handling because new tracked files affect the publishable-source or private-git contract
- asks for a correct verification summary after implementation

## Workflow

1. Classify the touched code by subsystem, changed-file shape, and behavior risk.
2. Run or require structural completion checks for cleanup and parity-sensitive refactors.
3. Choose the smallest narrow gates that prove the change while still respecting repo policy.
4. Add the required repo acceptance gates for the affected surface, including the named strict
   live/backend/provider proof lane whenever external behavior or production fallback semantics changed.
5. Run `./scripts/fix_manifest_freshness.sh` if tracked-file changes make manifest freshness fail.
6. Use the temp-index flow when new tracked files affect private-git or publishable-source checks.
7. Report what ran, what was skipped, why it was skipped, and whether any blocker remains.

## Gate matrix

- Skills or docs only: validate touched skills with `quick_validate.py`, refresh manifests if needed, then run `./scripts/check.sh`.
- Proc macros: run `cargo test -q -p rurr-macros`, then `./scripts/check.sh`.
- Core streaming, lifecycle, tracking, or parallel runtime: run the narrow `rurr-core` tests, `./scripts/check.sh`, and `./scripts/check_competition.sh` when behavior comparison is affected.
- Burr oracle, goldens, or compatibility behavior: run `./scripts/check_oracle.sh` in addition to `./scripts/check.sh`.
- Live provider or integration code: run the named strict live/backend/provider proof lane, which
  usually includes `./scripts/check_live.sh`, in addition to relevant package gates.
- Private OpenAI streaming example or contract: run `./scripts/check_openai_live.sh`.

## Output contract

Return:

- the chosen gates and why each one was required
- the skipped gates and why each one was not required
- the structural completion checks and whether they passed
- whether manifest freshness or generated snapshots needed refresh
- whether temp-index or private-git handling was required
- whether the relevant strict live/backend/provider proof lane ran for any external-behavior change
- blockers or environment limits, if any
- the final closeout summary for handoff

## Default rules

- Run `./scripts/check.sh` before handoff unless the task is truly docs-only and the user explicitly waives gates.
- Treat oracle, competition, live, and OpenAI-live checks as additive lanes chosen by changed behavior, not by habit.
- Treat structural completion as a prerequisite for cleanup closeout, not a replacement for tests.
- Do not close out external/provider behavior changes on local-only tests when the workspace
  expects a named strict proof lane.
- Do not claim a gate passed unless it actually ran and finished successfully.
- Prefer the smallest truthful gate set during iteration, then the required final acceptance set at closeout.

## Do not use this skill alone when

- the user still needs approved delete-first refactor implementation: also use `$rurr-delete-first-refactor-plan` in implementation mode
- the user still needs a delete-first implementation plan: also use `$rurr-delete-first-refactor-plan`
- the user still needs a Burr comparison before deciding what may change: also use `$rurr-burr-source-parity-walk`
