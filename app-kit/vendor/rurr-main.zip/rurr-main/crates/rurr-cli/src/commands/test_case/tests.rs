use super::create;
use crate::TestCaseCreateArgs;
use indexmap::IndexMap;
use rurr_core::tracking::LocalTrackingClient;
use rurr_core::{
    register_field_serde, ApplicationBuilder, Condition, FunctionActionBuilder, State, Tracker,
    TrackerSpec, Transition,
};
use serde_json::{json, Value};
use std::fs;
use std::io;
use std::path::Path;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use tempfile::tempdir;

static UNIQUE_FIELD_COUNTER: AtomicUsize = AtomicUsize::new(0);

fn unique_field_name(prefix: &str) -> String {
    format!(
        "{prefix}_{}_{}",
        std::process::id(),
        UNIQUE_FIELD_COUNTER.fetch_add(1, Ordering::Relaxed)
    )
}

fn write_tracking_fixture(
    storage_root: &Path,
    project_name: &str,
    app_id: &str,
    action_name: &str,
    states: &[Value],
) {
    assert!(
        !states.is_empty(),
        "fixture helper requires at least one runtime state snapshot"
    );
    let scripted_states = states
        .iter()
        .map(|state| {
            let object = state
                .as_object()
                .expect("fixture runtime state should be a JSON object");
            State::new(
                object
                    .iter()
                    .map(|(key, value)| (key.clone(), value.clone()))
                    .collect::<IndexMap<String, Value>>(),
            )
        })
        .collect::<Vec<_>>();
    let writes = scripted_states
        .iter()
        .flat_map(|state| state.keys())
        .collect::<std::collections::BTreeSet<_>>()
        .into_iter()
        .collect::<Vec<_>>();

    let tracker = Arc::new(
        LocalTrackingClient::new(project_name, storage_root)
            .expect("tracking client should initialize"),
    );
    let tracker_trait: Arc<dyn Tracker> = tracker.clone();
    let scripted_states_for_action = scripted_states.clone();
    let action = FunctionActionBuilder::new()
        .writes(writes)
        .with_source_code(
            "fn write_tracking_fixture_action(state, _ctx) { let next_index = state.get(\"__SEQUENCE_ID\").and_then(Value::as_u64).map(|sequence_id| sequence_id as usize).unwrap_or(0); scripted_states_for_action.get(next_index).map(|state| state.get_all()).expect(\"fixture action should only be stepped for scripted states\") }",
        )
        .build_sync(move |state, _ctx| {
            let next_index = state
                .get("__SEQUENCE_ID")
                .and_then(Value::as_u64)
                .map(|sequence_id| sequence_id as usize)
                .unwrap_or(0);
            scripted_states_for_action
                .get(next_index)
                .map(|state| state.get_all())
                .expect("fixture action should only be stepped for scripted states")
        })
        .expect("fixture action should build");
    let mut app = ApplicationBuilder::new()
        .with_state(State::default())
        .expect("state should configure")
        .with_actions(vec![(action_name, action)])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            action_name,
            action_name,
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_entrypoint(action_name)
        .expect("entrypoint should configure")
        .with_identifiers(app_id, None, None)
        .expect("identifiers should configure")
        .with_tracker(TrackerSpec::provided(tracker_trait))
        .expect("tracker should configure")
        .build()
        .expect("application should build");
    tracker
        .register_application(app.uid(), app.partition_key(), app.graph(), None, None)
        .expect("registration should succeed");
    for _ in 0..scripted_states.len() {
        app.step(None).expect("step should succeed");
    }
}

#[test]
fn create_decodes_tracked_field_serde_payloads_before_emitting_fixture() {
    let storage_dir = tempdir().expect("storage dir should be created");
    let target_dir = tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("fixture.json");
    let field_name = unique_field_name("test_case_payload");
    register_field_serde(
        field_name.clone(),
        |value| {
            json!({
                "value": format!(
                    "serialized::{}",
                    value
                        .as_str()
                        .expect("field serializer should receive a string")
                )
            })
        },
        |value| {
            Value::String(
                value
                    .get("value")
                    .and_then(Value::as_str)
                    .expect("field payload should contain string value")
                    .replace("serialized::", ""),
            )
        },
    )
    .expect("field serde registration should succeed");

    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            json!({ field_name.clone(): "before" }),
            json!({ field_name.clone(): "after" }),
        ],
    );

    create(TestCaseCreateArgs {
        storage_dir: storage_dir.path().to_path_buf(),
        project_name: "demo_counter".to_string(),
        partition_key: None,
        app_id: "counter-app-0001".to_string(),
        sequence_id: 1,
        target_file_name: Some(fixture_path.clone()),
        action_name: None,
        serde_decoder: None,
        serde_decoder_arg: Vec::new(),
    })
    .expect("test-case create should succeed");

    let fixtures: Value =
        serde_json::from_str(&fs::read_to_string(&fixture_path).expect("fixture should exist"))
            .expect("fixture json should parse");
    let fixtures = fixtures
        .as_array()
        .expect("fixture file should contain an array");
    assert_eq!(fixtures.len(), 1);
    assert_eq!(
        fixtures[0]["input_state"],
        json!({ field_name.clone(): "before" })
    );
    assert_eq!(
        fixtures[0]["expected_state"],
        json!({ field_name: "after" })
    );
}

#[test]
fn create_fails_when_serialized_state_cannot_be_decoded() {
    let storage_dir = tempdir().expect("storage dir should be created");
    let target_dir = tempdir().expect("target dir should be created");
    let fixture_path = target_dir.path().join("fixture.json");
    write_tracking_fixture(
        storage_dir.path(),
        "demo_counter",
        "counter-app-0001",
        "counter",
        &[
            json!({
                "payload": "before"
            }),
            json!({
                "payload": {
                    "__burr_serde__": "missing_decode_handler",
                    "value": "test"
                }
            }),
        ],
    );

    let error = create(TestCaseCreateArgs {
        storage_dir: storage_dir.path().to_path_buf(),
        project_name: "demo_counter".to_string(),
        partition_key: None,
        app_id: "counter-app-0001".to_string(),
        sequence_id: 1,
        target_file_name: Some(fixture_path.clone()),
        action_name: None,
        serde_decoder: None,
        serde_decoder_arg: Vec::new(),
    })
    .expect_err("undecodable serialized state should fail");

    let error = error
        .downcast::<io::Error>()
        .expect("decode failures should surface as io::Error");
    assert_eq!(error.kind(), io::ErrorKind::InvalidData);
    assert!(
        error
            .to_string()
            .contains("no function registered for key: missing_decode_handler"),
        "expected missing deserializer error, got: {error}"
    );
    assert!(
        !fixture_path.exists(),
        "fixture file should not be created when decoding fails"
    );
}
