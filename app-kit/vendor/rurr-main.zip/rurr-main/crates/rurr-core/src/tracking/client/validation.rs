use super::*;

/// Returns whether a project name is valid for local tracking storage.
pub fn allowed_project_name(project_name: &str, on_windows: bool) -> bool {
    if project_name.is_empty() {
        return false;
    }
    project_name.chars().all(|ch| {
        ch.is_ascii_alphanumeric() || ch == '_' || ch == '-' || (!on_windows && ch == ':')
    })
}

pub(super) fn map_tracking_error(error: TrackingError) -> PersistenceError {
    match error {
        TrackingError::InvalidProjectName { .. }
        | TrackingError::InvalidAppId { .. }
        | TrackingError::UnsupportedLocalTrackerParam { .. }
        | TrackingError::InvalidLocalTrackerParamType { .. }
        | TrackingError::MissingS3TrackerConfig { .. }
        | TrackingError::MissingActionSource { .. }
        | TrackingError::MissingAppId { .. }
        | TrackingError::LockPoisoned { .. }
        | TrackingError::S3Transport { .. }
        | TrackingError::S3Layout { .. }
        | TrackingError::UnnamedAction
        | TrackingError::SerdeJson(_) => PersistenceError::UnsupportedOperation {
            operation: "local_tracking_client_operation",
        },
        TrackingError::Timestamp { operation, message } => {
            PersistenceError::InvalidTimestamp { operation, message }
        }
        TrackingError::Io(_) => PersistenceError::UnsupportedOperation {
            operation: "local_tracking_client_io",
        },
    }
}

pub(super) fn tracking_to_lifecycle_error(
    operation: &'static str,
    error: TrackingError,
) -> LifecycleError {
    LifecycleError::hook_failed(operation, error.to_string())
}

impl LocalTrackingClient {
    pub(super) fn validate_app_id(app_id: &str) -> Result<(), TrackingError> {
        rurr_tracking_store::anchored_fs::validate_path_segment(APP_ID_KIND, app_id).map_err(|_| {
            TrackingError::InvalidAppId {
                app_id: app_id.to_string(),
            }
        })
    }

    pub(super) fn map_invalid_app_id_for_load(error: TrackingError) -> PersistenceError {
        match error {
            TrackingError::InvalidAppId { .. } => PersistenceError::UnsupportedOperation {
                operation: "invalid_app_id",
            },
            other => map_tracking_error(other),
        }
    }
}
