use futures::{stream, Stream, StreamExt};

/// Adapts an iterator into a stream for async tests and helpers.
pub fn asyncify_iter<I>(iter: I) -> impl Stream<Item = I::Item>
where
    I: IntoIterator,
{
    stream::iter(iter)
}

/// Returns the provided stream unchanged.
pub fn asyncify_stream<S>(stream: S) -> S
where
    S: Stream,
{
    stream
}

/// Collects a stream into a vector.
///
/// This helper is intended for tests and outer API adapters. Core runtime
/// execution paths must not use it because streaming must remain lazy.
///
/// ```rust
/// use futures::stream;
/// use rurr_core::common::async_utils::{asyncify_iter, asyncify_stream, realize_stream};
///
/// # futures::executor::block_on(async {
/// let sync_items = realize_stream
///     (asyncify_iter(0..5)).await;
/// let async_items = realize_stream
///     (asyncify_stream(stream::iter(0..5))).await;
/// let empty_sync: Vec<i32> = realize_stream
///     (asyncify_iter(Vec::<i32>::new())).await;
/// let empty_async: Vec<i32> = realize_stream
///     (asyncify_stream(stream::empty::<i32>())).await;
///
/// assert_eq!(sync_items, vec![0, 1, 2, 3, 4]);
/// assert_eq!(async_items, vec![0, 1, 2, 3, 4]);
/// assert!(empty_sync.is_empty());
/// assert!(empty_async.is_empty());
/// # });
/// ```
pub async fn realize_stream<S>(stream: S) -> Vec<S::Item>
where
    S: Stream,
{
    stream.collect::<Vec<_>>().await
}
