use super::*;
use crate::contract::support::application::{
    assert_invalid_halt_actions, assert_no_execute_hooks, halt_after_terminal_tag,
    halt_before_terminal_tag, invalid_halt_options, streaming_halt_app, STREAM_HALT_ACTIONS,
};

async fn assert_stream_result_halt_after_tag_fast_forwards_to_tagged_target(mode: StreamMode) {
    let pre_calls = Arc::new(AtomicUsize::new(0));
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let mut app = streaming_halt_app(Arc::clone(&pre_calls), Arc::clone(&stream_calls), None);

    let (action, mut stream_result) = mode
        .stream_result(&mut app, halt_after_terminal_tag())
        .await
        .expect("stream_result should resolve tagged halt_after target");

    assert_eq!(action.name(), "stream");
    assert_eq!(pre_calls.load(Ordering::SeqCst), 1);
    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);

    let (terminal, state) = stream_result.get().await.expect("target should stream");
    assert_eq!(
        terminal.and_then(|item| item.get("count").cloned()),
        Some(json!(2))
    );
    assert_eq!(state.get("count"), Some(&json!(2)));
    assert_eq!(stream_calls.load(Ordering::SeqCst), 1);
}

async fn assert_stream_iterate_halt_after_tag_stops_after_tagged_step(mode: StreamMode) {
    let pre_calls = Arc::new(AtomicUsize::new(0));
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let mut app = streaming_halt_app(Arc::clone(&pre_calls), Arc::clone(&stream_calls), None);
    let mut iterate = mode
        .stream_iterate(&mut app, halt_after_terminal_tag())
        .await;

    {
        let (first, mut first_handle) = iterate
            .next_step()
            .await
            .expect("first next_step should succeed")
            .expect("first step should exist");
        assert_eq!(first, "pre");
        first_handle.get().await.expect("pre step should complete");
        assert_eq!(pre_calls.load(Ordering::SeqCst), 1);
    }

    {
        let (second, mut second_handle) = iterate
            .next_step()
            .await
            .expect("second next_step should succeed")
            .expect("tagged step should exist");
        assert_eq!(second, "stream");
        let (_terminal, state) = second_handle
            .get()
            .await
            .expect("tagged step should complete");
        assert_eq!(state.get("count"), Some(&json!(2)));
        assert_eq!(stream_calls.load(Ordering::SeqCst), 1);
    }

    assert!(
        iterate
            .next_step()
            .await
            .expect("post-halt next_step should succeed")
            .is_none(),
        "stream_iterate should stop after tagged halt_after target"
    );
}

async fn assert_stream_iterate_halt_before_tag_stops_without_starting_target(mode: StreamMode) {
    let pre_calls = Arc::new(AtomicUsize::new(0));
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let mut app = streaming_halt_app(Arc::clone(&pre_calls), Arc::clone(&stream_calls), None);
    let mut iterate = mode
        .stream_iterate(&mut app, halt_before_terminal_tag())
        .await;

    {
        let (first, mut first_handle) = iterate
            .next_step()
            .await
            .expect("first next_step should succeed")
            .expect("pre step should exist");
        assert_eq!(first, "pre");
        let (_terminal, state) = first_handle.get().await.expect("pre step should complete");
        assert_eq!(state.get("count"), Some(&json!(1)));
    }

    assert!(
        iterate
            .next_step()
            .await
            .expect("halt_before next_step should succeed")
            .is_none(),
        "stream_iterate should stop before tagged halt_before target"
    );
    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);
}

async fn assert_stream_result_unknown_halt_actions_fail_before_execution(mode: StreamMode) {
    let pre_calls = Arc::new(AtomicUsize::new(0));
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let hook_counts = Arc::new(hooks::StreamAbortHookCounts::default());
    let hooks = cases::counting_hooks(&hook_counts);
    let mut app = streaming_halt_app(
        Arc::clone(&pre_calls),
        Arc::clone(&stream_calls),
        Some(hooks),
    );

    let error = match mode.stream_result(&mut app, invalid_halt_options()).await {
        Ok((action, _)) => panic!(
            "unknown halt selectors should fail before stream_result execution, got {}",
            action.name()
        ),
        Err(error) => error,
    };

    assert_invalid_halt_actions(error, STREAM_HALT_ACTIONS);
    assert_eq!(pre_calls.load(Ordering::SeqCst), 0);
    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);
    assert_no_execute_hooks(&hook_counts);
}

async fn assert_stream_iterate_unknown_halt_actions_fail_on_first_next(mode: StreamMode) {
    let pre_calls = Arc::new(AtomicUsize::new(0));
    let stream_calls = Arc::new(AtomicUsize::new(0));
    let hook_counts = Arc::new(hooks::StreamAbortHookCounts::default());
    let hooks = cases::counting_hooks(&hook_counts);
    let mut app = streaming_halt_app(
        Arc::clone(&pre_calls),
        Arc::clone(&stream_calls),
        Some(hooks),
    );
    let mut iterate = mode.stream_iterate(&mut app, invalid_halt_options()).await;

    let error = match iterate.next_step().await {
        Ok(Some((action, _))) => {
            panic!("unknown halt selectors should fail before {action} executes")
        }
        Ok(None) => panic!("unknown halt selectors should fail instead of ending iteration"),
        Err(error) => error,
    };

    assert_invalid_halt_actions(error, STREAM_HALT_ACTIONS);
    assert_eq!(pre_calls.load(Ordering::SeqCst), 0);
    assert_eq!(stream_calls.load(Ordering::SeqCst), 0);
    assert_no_execute_hooks(&hook_counts);
}

sync_stream_cases! {
    stream_result_halt_after_tag_fast_forwards_to_tagged_target =>
        assert_stream_result_halt_after_tag_fast_forwards_to_tagged_target(StreamMode::Sync),
    stream_iterate_halt_after_tag_stops_after_tagged_step =>
        assert_stream_iterate_halt_after_tag_stops_after_tagged_step(StreamMode::Sync),
    stream_iterate_halt_before_tag_stops_without_starting_target =>
        assert_stream_iterate_halt_before_tag_stops_without_starting_target(StreamMode::Sync),
    stream_result_unknown_halt_actions_fail_before_execution =>
        assert_stream_result_unknown_halt_actions_fail_before_execution(StreamMode::Sync),
    stream_iterate_unknown_halt_actions_fail_on_first_next =>
        assert_stream_iterate_unknown_halt_actions_fail_on_first_next(StreamMode::Sync)
}

async_stream_cases! {
    astream_result_halt_after_tag_fast_forwards_to_tagged_target =>
        assert_stream_result_halt_after_tag_fast_forwards_to_tagged_target(StreamMode::Async),
    astream_iterate_halt_after_tag_stops_after_tagged_step =>
        assert_stream_iterate_halt_after_tag_stops_after_tagged_step(StreamMode::Async),
    astream_iterate_halt_before_tag_stops_without_starting_target =>
        assert_stream_iterate_halt_before_tag_stops_without_starting_target(StreamMode::Async),
    astream_result_unknown_halt_actions_fail_before_execution =>
        assert_stream_result_unknown_halt_actions_fail_before_execution(StreamMode::Async),
    astream_iterate_unknown_halt_actions_fail_on_first_next =>
        assert_stream_iterate_unknown_halt_actions_fail_on_first_next(StreamMode::Async)
}
