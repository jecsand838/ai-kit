use futures::StreamExt;
use indexmap::IndexMap;
use rurr_core::action::{
    boxed_local_async_stream, ActionContext, ActionError, ActionInputs, ActionResult, ActionTracer,
    LocalAction, LocalAsyncStreamOutput,
};
use rurr_core::application::ApplicationBuilder;
use rurr_core::graph::Transition;
use rurr_core::state::State;
use serde_json::{json, Value};
use std::cell::Cell;
use std::rc::Rc;

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
fn counter(state: &State, amount: i64) -> Result<ActionResult, ActionError> {
    let next = state.get("count").and_then(Value::as_i64).unwrap_or(0) + amount;
    let result = IndexMap::from([("count".to_string(), json!(next))]);
    Ok(ActionResult::new(result.clone(), result))
}

#[rurr_macros::action(reads = ["count"], writes = ["count"])]
async fn async_counter(state: &State, amount: i64) -> Result<ActionResult, ActionError> {
    tokio::task::yield_now().await;
    let next = state.get("count").and_then(Value::as_i64).unwrap_or(0) + amount;
    let result = IndexMap::from([("count".to_string(), json!(next))]);
    Ok(ActionResult::new(result.clone(), result))
}

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
fn streaming_counter(
    state: &State,
    amount: i64,
) -> Box<dyn Iterator<Item = rurr_core::action::StreamOutput>> {
    let next = state.get("count").and_then(Value::as_i64).unwrap_or(0) + amount;
    let intermediate = IndexMap::from([("count".to_string(), json!(next - 1))]);
    let item = IndexMap::from([("count".to_string(), json!(next))]);
    let final_state = state
        .update(IndexMap::from([("count".to_string(), json!(next))]))
        .expect("streaming action update should succeed");
    Box::new(vec![Ok((intermediate, None)), Ok((item, Some(final_state)))].into_iter())
}

#[rurr_macros::streaming_action(reads = ["count"], writes = ["count"])]
async fn async_streaming_counter(state: &State, amount: i64) -> LocalAsyncStreamOutput {
    let next = state.get("count").and_then(Value::as_i64).unwrap_or(0) + amount;
    let local_marker = Rc::new(Cell::new(next));
    tokio::task::yield_now().await;
    let item = IndexMap::from([("count".to_string(), json!(local_marker.get()))]);
    let final_state = state
        .update(IndexMap::from([(
            "count".to_string(),
            json!(local_marker.get()),
        )]))
        .expect("async streaming action update should succeed");
    let stream_marker = Rc::clone(&local_marker);
    boxed_local_async_stream(futures::stream::once(async move {
        tokio::task::yield_now().await;
        stream_marker.set(stream_marker.get());
        Ok((item, Some(final_state)))
    }))
}

#[rurr_macros::action(reads = ["count"], writes = ["count"], tags = ["macro", "probe"])]
fn metadata_probe(
    _state: &State,
    _ctx: &ActionContext,
    first: i64,
    second: String,
) -> Result<ActionResult, ActionError> {
    let _ = (first, second);
    Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
}

fn state_from_count(count: i64) -> State {
    State::new(IndexMap::from([("count".to_string(), json!(count))]))
}

fn inputs_with_amount(amount: i64) -> ActionInputs {
    IndexMap::from([("amount".to_string(), json!(amount))])
}

#[test]
fn sync_macro_action_runs_and_returns_writes() {
    let action = counter_action().expect("macro-generated action should build");
    let state = state_from_count(0);
    let result = action
        .run(
            &state,
            &ActionContext::new(inputs_with_amount(1), ActionTracer::default(), None),
        )
        .expect("sync macro action should run");

    assert_eq!(result.result().get("count"), Some(&json!(1)));
    assert_eq!(result.writes().get("count"), Some(&json!(1)));
}

#[tokio::test]
async fn async_macro_action_runs_via_run_async() {
    let action = async_counter_action().expect("macro-generated action should build");
    let state = state_from_count(0);
    let sync_error = action
        .run(
            &state,
            &ActionContext::new(inputs_with_amount(1), ActionTracer::default(), None),
        )
        .expect_err("async macro action run() should fail");
    assert_eq!(sync_error, ActionError::AsyncActionRequiresRunAsync);

    let result = action
        .run_async(
            &state,
            &ActionContext::new(inputs_with_amount(2), ActionTracer::default(), None),
        )
        .await
        .expect("async macro action run_async() should run");

    assert_eq!(result.result().get("count"), Some(&json!(2)));
    assert_eq!(result.writes().get("count"), Some(&json!(2)));
}

#[test]
fn macro_generated_action_with_name_is_single_assignment() {
    let named = counter_action()
        .expect("macro-generated action should build")
        .with_name("counter")
        .expect("first macro-generated name assignment should succeed");
    assert_eq!(named.name(), Some("counter"));

    let error = named
        .with_name("counter-again")
        .expect_err("macro-generated action should reject a second name");
    assert_eq!(
        error,
        ActionError::NameAlreadySet {
            current_name: "counter".to_string(),
            attempted_name: "counter-again".to_string(),
        }
    );
}

#[tokio::test]
async fn async_macro_action_stream_run_async_uses_one_shot_runtime_path() {
    let action = async_counter_action().expect("macro-generated action should build");
    let state = state_from_count(1);
    let mut stream = action.stream_run_async(
        state,
        ActionContext::new(inputs_with_amount(4), ActionTracer::default(), None),
    );

    let first = stream
        .next()
        .await
        .expect("one-shot stream should yield exactly one item")
        .expect("one-shot stream should succeed");
    let (result, next_state) = first;
    assert_eq!(result.get("count"), Some(&json!(5)));
    assert_eq!(
        next_state
            .as_ref()
            .expect("one-shot stream should include a terminal state")
            .get("count"),
        Some(&json!(5))
    );
    assert!(
        stream.next().await.is_none(),
        "one-shot runtime helper should not emit additional items"
    );
}

#[test]
fn sync_streaming_macro_action_run_drains_to_terminal_result() {
    let result = streaming_counter_action()
        .expect("macro-generated action should build")
        .run(
            &state_from_count(0),
            &ActionContext::new(inputs_with_amount(2), ActionTracer::default(), None),
        )
        .expect("streaming action run() should drain to the terminal result");

    assert_eq!(result.result().get("count"), Some(&json!(2)));
    assert_eq!(result.writes().get("count"), Some(&json!(2)));
}

#[tokio::test]
async fn async_streaming_macro_action_run_async_drains_non_send_stream_to_terminal_result() {
    let action = async_streaming_counter_action().expect("macro-generated action should build");
    let state = state_from_count(0);
    let ctx = ActionContext::new(inputs_with_amount(3), ActionTracer::default(), None);

    let run_error = action
        .run(&state, &ctx)
        .expect_err("async streaming action run() should require run_async()");
    assert_eq!(run_error, ActionError::AsyncActionRequiresRunAsync);

    let result = action
        .run_async(&state, &ctx)
        .await
        .expect("async streaming action run_async() should drain to terminal result");
    assert_eq!(result.result().get("count"), Some(&json!(3)));
    assert_eq!(result.writes().get("count"), Some(&json!(3)));
}

#[rurr_macros::action(reads = [], writes = [])]
fn source_probe(_state: &State, _ctx: &ActionContext) -> Result<ActionResult, ActionError> {
    let marker = "DISTINCTIVE_MARKER_ACTION_SOURCE_12345";
    let _ = marker;
    Ok(ActionResult::new(IndexMap::new(), IndexMap::new()))
}

#[test]
fn macro_generated_action_runs_through_application_step() {
    let mut app = ApplicationBuilder::new()
        .with_state(state_from_count(0))
        .expect("state should configure")
        .with_actions(vec![(
            "counter",
            counter_action().expect("macro-generated action should build"),
        )])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("application should build");

    let output = app
        .step(Some(IndexMap::from([("amount".to_string(), json!(1))])))
        .expect("step should succeed")
        .expect("step should produce output");

    assert_eq!(output.result.get("count"), Some(&json!(1)));
    assert_eq!(output.state.get("count"), Some(&json!(1)));
    assert_eq!(app.state().get("count"), Some(&json!(1)));
}

#[test]
fn macro_action_source_contains_function_body() {
    let action = source_probe_action().expect("macro-generated action should build");
    let source = action
        .source_code()
        .expect("macro-generated actions should embed source");
    assert!(
        source.contains("DISTINCTIVE_MARKER_ACTION_SOURCE_12345"),
        "macro-generated source should include the function body"
    );
}

#[test]
fn macro_generated_metadata_preserves_declared_ordering() {
    let action = metadata_probe_action().expect("macro-generated action should build");

    assert_eq!(action.reads(), &["count".to_string()]);
    assert_eq!(action.writes(), &["count".to_string()]);
    assert_eq!(action.tags(), &["macro".to_string(), "probe".to_string()]);
    assert_eq!(
        action.inputs(),
        &["first".to_string(), "second".to_string()]
    );
}
