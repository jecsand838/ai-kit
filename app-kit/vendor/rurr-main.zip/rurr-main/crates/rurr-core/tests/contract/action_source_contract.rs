use indexmap::IndexMap;
use rurr_core::action::{FunctionActionBuilder, LocalAction};
use rurr_core::parallelism::{CascadeMode, ParallelMap, ParallelTaskSource, RunnableGraph};
use rurr_core::state::State;
use std::sync::Arc;

#[test]
fn function_action_builder_source_override_is_used() {
    let action = FunctionActionBuilder::new()
        .with_source_code("fn synthetic_action() { /* source marker */ }")
        .build_sync(|_state, _ctx| IndexMap::new())
        .expect("function action should build");

    assert!(
        action
            .source_code()
            .is_some_and(|source| source.contains("source marker")),
        "function builder source override should be returned by Action::source_code"
    );
}

#[test]
fn parallel_map_source_override_is_used() {
    let action = ParallelMap::new(
        ParallelTaskSource::graphs(
            vec![RunnableGraph::new(
                Vec::new(),
                Vec::new(),
                Some("child".to_string()),
            )],
            Arc::new(|state: &State, _ctx| Ok(state.clone())),
        ),
        Vec::new(),
        Vec::new(),
        Vec::new(),
        CascadeMode::None,
    )
    .with_source_code("fn parallel(_state, _ctx) -> child_states { /* source marker */ }");

    assert!(
        action
            .source_code()
            .is_some_and(|source| source.contains("source marker")),
        "parallel source override should be returned by Action::source_code"
    );
}
