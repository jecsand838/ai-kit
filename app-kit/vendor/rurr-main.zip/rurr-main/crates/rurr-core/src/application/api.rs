use crate::action::api::ActionInputs;
use crate::application::session::{arun, astep, iterate, run, step, ExecutionSession};
use crate::application::streaming::{
    astream_iterate, astream_result, stream_iterate, stream_result, AStreamIterate, AStreamResult,
    StreamIterate, StreamResult,
};
use crate::application::{Application, ApplicationError, ExecutionOptions, RunOutput, StepOutput};
use crate::graph::GraphAction;

impl Application {
    /// Executes one synchronous step and returns its output when a step ran.
    ///
    /// The call reserves a sequence id for the selected action, applies the
    /// action transactionally, and commits state only after the action and
    /// lifecycle hooks complete. A `None` return means the graph had no next
    /// action to execute.
    pub fn step(
        &mut self,
        inputs: Option<ActionInputs>,
    ) -> Result<Option<StepOutput>, ApplicationError> {
        step(self, inputs)
    }

    /// Executes one asynchronous step and returns its output when a step ran.
    ///
    /// This is the async-lane counterpart to [`step`](Self::step). It drives
    /// async actions, async persistence, and async lifecycle hooks without
    /// mixing them into the sync execution path.
    pub async fn astep(
        &mut self,
        inputs: Option<ActionInputs>,
    ) -> Result<Option<StepOutput>, ApplicationError> {
        astep(self, inputs).await
    }

    /// Returns a synchronous execution session that advances one step at a
    /// time.
    ///
    /// The session borrows the application mutably, so no other execution API
    /// can advance the same application until the session is dropped.
    pub fn iterate(&mut self) -> ExecutionSession<'_> {
        iterate(self, ExecutionOptions::new())
    }

    /// Returns a synchronous execution session with explicit execution options.
    ///
    /// Runtime inputs and halt selectors are validated lazily when the session
    /// is first advanced. `@tag:<tag>` halt selectors are expanded against the
    /// graph once at that point, before any action body runs.
    pub fn iterate_with_options(&mut self, options: ExecutionOptions) -> ExecutionSession<'_> {
        iterate(self, options)
    }

    /// Runs the application to completion on the sync lane.
    ///
    /// This repeatedly executes sync steps until the graph reaches a terminal
    /// point or an error occurs.
    pub fn run(&mut self) -> Result<RunOutput, ApplicationError> {
        self.run_with_options(ExecutionOptions::new())
    }

    /// Runs the application to completion on the sync lane with explicit
    /// execution options.
    ///
    /// Halt selectors in `options` may be action names or `@tag:<tag>` values.
    /// Tags are expanded before the first step, unknown actions are reported as
    /// [`ApplicationError::InvalidHaltActions`], and unknown tags surface as
    /// [`crate::graph::GraphError::TagNotFound`].
    ///
    /// # Examples
    ///
    /// ```
    /// use indexmap::IndexMap;
    /// use rurr_core::{
    ///     ApplicationBuilder, Condition, ExecutionOptions, FunctionActionBuilder, Transition,
    /// };
    /// use serde_json::{json, Value};
    ///
    /// let first = FunctionActionBuilder::new().writes(["count"]).build_sync(|state, _ctx| {
    ///     let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
    ///     IndexMap::from([("count".to_string(), json!(count))])
    /// })?;
    /// let tagged = FunctionActionBuilder::new()
    ///     .reads(["count"])
    ///     .writes(["count"])
    ///     .tags(["checkpoint"])
    ///     .build_sync(|state, _ctx| {
    ///         let count = state.get("count").and_then(Value::as_i64).unwrap_or(0) + 1;
    ///         IndexMap::from([("count".to_string(), json!(count))])
    ///     })?;
    ///
    /// let mut app = ApplicationBuilder::new()
    ///     .with_actions(vec![("first", first), ("tagged", tagged)])?
    ///     .with_transitions(vec![Transition::new("first", "tagged", Condition::default())])?
    ///     .with_entrypoint("first")?
    ///     .build()?;
    ///
    /// let output = app.run_with_options(
    ///     ExecutionOptions::new().halt_after(["@tag:checkpoint"]),
    /// )?;
    /// assert_eq!(output.action.as_ref().map(|action| action.name()), Some("tagged"));
    /// assert_eq!(output.state.get("count"), Some(&json!(2)));
    /// # Ok::<(), rurr_core::ApplicationError>(())
    /// ```
    pub fn run_with_options(
        &mut self,
        options: ExecutionOptions,
    ) -> Result<RunOutput, ApplicationError> {
        run(self, options)
    }

    /// Runs the application to completion on the async lane.
    ///
    /// This repeatedly executes async-capable steps and awaits async lifecycle
    /// and persistence work before returning.
    pub async fn arun(&mut self) -> Result<RunOutput, ApplicationError> {
        self.arun_with_options(ExecutionOptions::new()).await
    }

    /// Runs the application to completion on the async lane with explicit
    /// execution options.
    ///
    /// Options have the same startup validation and halt-selector semantics as
    /// [`run_with_options`](Self::run_with_options), while action execution,
    /// persistence, and lifecycle hooks stay on the async lane.
    pub async fn arun_with_options(
        &mut self,
        options: ExecutionOptions,
    ) -> Result<RunOutput, ApplicationError> {
        arun(self, options).await
    }

    /// Returns a synchronous step-streaming session.
    ///
    /// The returned handle borrows the application and yields one streamed step
    /// at a time. Intermediate stream items stay uncommitted; terminal
    /// completion commits the step atomically.
    pub fn stream_iterate(&mut self) -> StreamIterate<'_> {
        stream_iterate(self, ExecutionOptions::new())
    }

    /// Returns a synchronous step-streaming session with explicit options.
    ///
    /// Halt controls are owned by the streaming session after startup. They do
    /// not require buffering streamed items and they are applied only at step
    /// boundaries: before a matching next action starts or after a matching
    /// step commits.
    pub fn stream_iterate_with_options(&mut self, options: ExecutionOptions) -> StreamIterate<'_> {
        stream_iterate(self, options)
    }

    /// Returns an asynchronous step-streaming session.
    ///
    /// Async stream handles are `#[must_use]` and provide explicit abort/get
    /// paths for async lifecycle finalization. Drop performs sync rollback only.
    pub async fn astream_iterate(&mut self) -> AStreamIterate<'_> {
        self.astream_iterate_with_options(ExecutionOptions::new())
            .await
    }

    /// Returns an asynchronous step-streaming session with explicit options.
    ///
    /// The async session resolves inputs and halt selectors before the first
    /// advancement, then preserves lazy streaming and explicit async
    /// completion/abort semantics for each yielded step handle.
    pub async fn astream_iterate_with_options(
        &mut self,
        options: ExecutionOptions,
    ) -> AStreamIterate<'_> {
        astream_iterate(self, options).await
    }

    /// Starts streaming result deltas for the next action on the sync lane.
    ///
    /// This is the Burr-style result-streaming API: callers receive the selected
    /// action preview plus a live stream of result deltas. State commits only
    /// when the stream reaches its terminal state.
    pub fn stream_result(&mut self) -> Result<(GraphAction, StreamResult<'_>), ApplicationError> {
        self.stream_result_with_options(ExecutionOptions::new())
    }

    /// Starts streaming result deltas for the next action on the sync lane with
    /// explicit options.
    ///
    /// `halt_after` selectors choose the result action after tag expansion. If
    /// no `halt_after` selector is supplied, the current Burr-style behavior is
    /// to stream the next result action. Fast-forward steps honor
    /// `halt_before` and `halt_after` without executing unknown or unvalidated
    /// targets.
    pub fn stream_result_with_options(
        &mut self,
        options: ExecutionOptions,
    ) -> Result<(GraphAction, StreamResult<'_>), ApplicationError> {
        stream_result(self, options)
    }

    /// Starts streaming result deltas for the next action on the async lane.
    ///
    /// Use [`AStreamResult::get`] to drain to completion or
    /// [`AStreamResult::abort`] when stopping early should run async abort
    /// hooks.
    pub async fn astream_result(
        &mut self,
    ) -> Result<(GraphAction, AStreamResult<'_>), ApplicationError> {
        self.astream_result_with_options(ExecutionOptions::new())
            .await
    }

    /// Starts streaming result deltas for the next action on the async lane
    /// with explicit options.
    ///
    /// This is the async counterpart to
    /// [`stream_result_with_options`](Self::stream_result_with_options): halt
    /// tags are resolved before streaming starts and async lifecycle
    /// finalization remains explicit through [`AStreamResult::get`] or
    /// [`AStreamResult::abort`].
    pub async fn astream_result_with_options(
        &mut self,
        options: ExecutionOptions,
    ) -> Result<(GraphAction, AStreamResult<'_>), ApplicationError> {
        astream_result(self, options).await
    }
}
