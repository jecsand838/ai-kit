use super::support::application::counter_action;
use crate::test_support::NonNegativeCountTypingSystem;
use rurr_core::action::Condition;
use rurr_core::application::{ApplicationBuilder, ApplicationError, ApplicationGraph};
use rurr_core::graph::Transition;
use rurr_core::state::{State, StateError, TypingSystem};
use rurr_persistence::{ApplicationPersistenceSpec, AsyncInMemoryPersister, StatePersisterSpec};
use rurr_testkit::application_fixture::{
    map_from_pairs, state_from_pairs, ApplicationFixtureBuilder,
};
use rurr_testkit::test_dir_for_test;
use serde_json::json;
use std::sync::Arc;

fn build_single_step_app() -> rurr_core::Application {
    ApplicationFixtureBuilder::single_action(
        state_from_pairs([("count", json!(0))]),
        "counter",
        counter_action(),
    )
    .expect("fixture builder should configure")
    .with_identifiers("inspect-app", Some("tenant-1".to_string()), None)
    .expect("identifiers should configure")
    .build()
    .expect("application should build")
}

fn build_two_step_app(state: State) -> rurr_core::Application {
    ApplicationFixtureBuilder::new(state)
        .expect("fixture builder should configure")
        .with_action("alpha", counter_action())
        .expect("alpha action should configure")
        .with_action("omega", counter_action())
        .expect("omega action should configure")
        .with_transitions(vec![Transition::new(
            "alpha",
            "omega",
            Condition::default(),
        )])
        .expect("transitions should configure")
        .with_entrypoint("alpha")
        .expect("entrypoint should configure")
        .with_identifiers("graph-app", Some("tenant-2".to_string()), None)
        .expect("identifiers should configure")
        .build()
        .expect("application should build")
}

fn build_unknown_prior_step_app() -> rurr_core::Application {
    ApplicationBuilder::new()
        .with_state(state_from_pairs([("__PRIOR_STEP", json!("missing"))]))
        .expect("state should configure")
        .with_actions(vec![("counter", counter_action())])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("application should build")
}

fn build_counter_state_app(state: State) -> rurr_core::Application {
    ApplicationBuilder::new()
        .with_state(state)
        .expect("state should configure")
        .with_actions(vec![("counter", counter_action())])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .build()
        .expect("application should build")
}

fn assert_graph_view(_graph: &ApplicationGraph) {}

#[test]
fn uid_sequence_id_and_context_reflect_state_meta() {
    let mut app = build_single_step_app();

    assert_eq!(app.uid(), "inspect-app");
    assert_eq!(app.sequence_id().expect("sequence_id should resolve"), None);

    let initial_context = app.context().expect("context should resolve");
    assert_eq!(initial_context.app_id, "inspect-app");
    assert_eq!(initial_context.partition_key.as_deref(), Some("tenant-1"));
    assert_eq!(initial_context.sequence_id, None);
    assert_eq!(initial_context.prior_step, None);

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(
        app.sequence_id().expect("sequence_id should resolve"),
        Some(0)
    );

    let committed_context = app.context().expect("context should resolve after step");
    assert_eq!(committed_context.sequence_id, Some(0));
    assert_eq!(committed_context.prior_step.as_deref(), Some("counter"));
}

#[test]
fn graph_returns_application_graph_view() {
    let app = build_two_step_app(State::default());

    assert_graph_view(app.graph());
    assert_eq!(app.graph().actions().len(), 2);
    assert_eq!(app.graph().transitions().len(), 1);
    assert_eq!(app.graph().entrypoint(), "alpha");
}

#[test]
fn has_next_action_tracks_terminality() {
    let mut app = build_single_step_app();

    assert!(app
        .has_next_action()
        .expect("initial next action lookup should succeed"));

    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert!(!app
        .has_next_action()
        .expect("terminal next action lookup should succeed"));
}

#[test]
fn has_next_action_errors_when_transition_resolution_fails() {
    let app = ApplicationBuilder::new()
        .with_state(state_from_pairs([("__PRIOR_STEP", json!("alpha"))]))
        .expect("state should configure")
        .with_actions(vec![
            ("alpha", counter_action()),
            ("omega", counter_action()),
        ])
        .expect("actions should configure")
        .with_transitions(vec![Transition::new(
            "alpha",
            "omega",
            Condition::expr("missing_key > 0"),
        )])
        .expect("transitions should configure")
        .with_entrypoint("alpha")
        .expect("entrypoint should configure")
        .build()
        .expect("application should build");

    assert!(matches!(
        app.has_next_action(),
        Err(ApplicationError::Graph(
            rurr_core::graph::GraphError::ConditionEvaluation { .. }
        ))
    ));
}

#[test]
fn has_next_action_errors_when_prior_step_is_unknown_action() {
    let app = build_unknown_prior_step_app();

    assert!(matches!(
        app.has_next_action(),
        Err(ApplicationError::Graph(
            rurr_core::graph::GraphError::ActionNotFound { action_name, .. }
        )) if action_name == "missing"
    ));
}

#[test]
fn context_errors_when_prior_step_is_unknown_action() {
    let app = build_unknown_prior_step_app();

    assert!(matches!(
        app.context(),
        Err(ApplicationError::Graph(
            rurr_core::graph::GraphError::ActionNotFound { action_name, .. }
        )) if action_name == "missing"
    ));
}

#[test]
fn reset_to_entrypoint_clears_prior_step_only() {
    let mut app = build_single_step_app();
    let _ = app
        .step(None)
        .expect("step should succeed")
        .expect("step should execute");

    assert_eq!(app.state().get("__PRIOR_STEP"), Some(&json!("counter")));
    assert_eq!(
        app.sequence_id().expect("sequence id should resolve"),
        Some(0)
    );

    app.reset_to_entrypoint()
        .expect("reset_to_entrypoint should succeed");

    assert!(!app.state().contains_key("__PRIOR_STEP"));
    assert_eq!(
        app.sequence_id().expect("sequence id should resolve"),
        Some(0)
    );
    assert_eq!(
        app.context().expect("context should resolve").prior_step,
        None
    );
    assert!(app
        .has_next_action()
        .expect("next action lookup should succeed after reset"));
}

#[test]
fn update_state_stamps_application_typing_system_onto_replacement_state() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(NonNegativeCountTypingSystem::default());
    let state = State::new(map_from_pairs([("count", json!(1))]))
        .with_typing_system(Arc::clone(&typing_system))
        .expect("typing system should attach");
    let mut app = build_counter_state_app(state);

    app.update_state(State::new(map_from_pairs([("count", json!(2))])))
        .expect("replacement state should validate through application typing");

    assert_eq!(app.state().get("count"), Some(&json!(2)));
    assert!(Arc::ptr_eq(app.state().typing_system(), &typing_system));
}

#[test]
fn update_state_rejects_invalid_typing_and_reserved_metadata() {
    let typing_system: Arc<dyn TypingSystem> = Arc::new(NonNegativeCountTypingSystem::default());
    let state = State::new(map_from_pairs([("count", json!(1))]))
        .with_typing_system(Arc::clone(&typing_system))
        .expect("typing system should attach");
    let mut app = build_counter_state_app(state);

    assert!(matches!(
        app.update_state(State::new(map_from_pairs([("count", json!(-1))]))),
        Err(ApplicationError::State(StateError::TypingSystem { .. }))
    ));

    let error = app
        .update_state(State::new(map_from_pairs([
            ("count", json!(1)),
            ("__SEQUENCE_ID", json!("bad")),
        ])))
        .expect_err("invalid __SEQUENCE_ID should be rejected");
    match error {
        ApplicationError::InvalidSequenceIdType { actual } => assert_eq!(actual, "string"),
        other => panic!("expected invalid sequence id error, got {other:?}"),
    }

    let error = app
        .update_state(State::new(map_from_pairs([
            ("count", json!(1)),
            ("__PRIOR_STEP", json!("missing")),
        ])))
        .expect_err("unknown __PRIOR_STEP should be rejected");
    assert!(matches!(
        error,
        ApplicationError::Graph(rurr_core::graph::GraphError::ActionNotFound {
            action_name,
            ..
        }) if action_name == "missing"
    ));
}

#[tokio::test]
async fn validate_correct_async_use_matches_sync_execution_guard() {
    let sync_app = build_single_step_app();
    sync_app
        .validate_correct_async_use()
        .expect("sync app should validate");

    let async_persister = Arc::new(AsyncInMemoryPersister::new());
    let async_app = ApplicationBuilder::new()
        .with_state(State::default())
        .expect("state should configure")
        .with_actions(vec![("counter", counter_action())])
        .expect("actions should configure")
        .with_transitions(Vec::<Transition>::new())
        .expect("transitions should configure")
        .with_entrypoint("counter")
        .expect("entrypoint should configure")
        .with_persistence_spec(
            ApplicationPersistenceSpec::new()
                .with_persister(StatePersisterSpec::async_persister(async_persister)),
        )
        .expect("async persistence should configure")
        .abuild()
        .await
        .expect("async application should build");

    assert!(matches!(
        async_app.validate_correct_async_use(),
        Err(ApplicationError::AsyncApplicationUsedSyncRun)
    ));
}

#[test]
fn visualize_matches_public_graph_view_output() {
    let app = build_two_step_app(State::default());
    let temp_root = test_dir_for_test().expect("temp dir should build");
    let output_path = temp_root.join("inspection_app");

    let app_dot = app
        .visualize(Some(output_path.as_path()), true)
        .expect("application visualize should succeed");
    let graph_dot = app
        .graph()
        .visualize(Some(output_path.as_path()), true)
        .expect("graph visualize should succeed");

    assert_eq!(app_dot, graph_dot);
    assert!(output_path.with_extension("dot").exists());
}
