use crate::value::{number_to_f64, NumberValue};
use crate::ExprError;
use std::cmp::Ordering;

pub(super) fn numeric_add(
    left: NumberValue,
    right: NumberValue,
) -> Result<crate::value::EvalValue, ExprError> {
    match (left, right) {
        (NumberValue::Int(a), NumberValue::Int(b)) => {
            let value = a.checked_add(b).ok_or(ExprError::IntegerOverflow)?;
            Ok(crate::value::EvalValue::Int(value))
        }
        _ => Ok(crate::value::EvalValue::Float(
            number_to_f64(left) + number_to_f64(right),
        )),
    }
}

pub(super) fn numeric_sub(
    left: NumberValue,
    right: NumberValue,
) -> Result<crate::value::EvalValue, ExprError> {
    match (left, right) {
        (NumberValue::Int(a), NumberValue::Int(b)) => {
            let value = a.checked_sub(b).ok_or(ExprError::IntegerOverflow)?;
            Ok(crate::value::EvalValue::Int(value))
        }
        _ => Ok(crate::value::EvalValue::Float(
            number_to_f64(left) - number_to_f64(right),
        )),
    }
}

pub(super) fn numeric_mul(
    left: NumberValue,
    right: NumberValue,
) -> Result<crate::value::EvalValue, ExprError> {
    match (left, right) {
        (NumberValue::Int(a), NumberValue::Int(b)) => {
            let value = a.checked_mul(b).ok_or(ExprError::IntegerOverflow)?;
            Ok(crate::value::EvalValue::Int(value))
        }
        _ => Ok(crate::value::EvalValue::Float(
            number_to_f64(left) * number_to_f64(right),
        )),
    }
}

pub(super) fn numeric_div(
    left: NumberValue,
    right: NumberValue,
) -> Result<crate::value::EvalValue, ExprError> {
    let denominator = number_to_f64(right);
    if denominator == 0.0 {
        return Err(ExprError::DivisionByZero);
    }
    let numerator = number_to_f64(left);
    Ok(crate::value::EvalValue::Float(numerator / denominator))
}

pub(super) fn numeric_floor_div(
    left: NumberValue,
    right: NumberValue,
) -> Result<crate::value::EvalValue, ExprError> {
    match (left, right) {
        (NumberValue::Int(a), NumberValue::Int(b)) => {
            if b == 0 {
                return Err(ExprError::DivisionByZero);
            }
            let quotient = a.checked_div(b).ok_or(ExprError::IntegerOverflow)?;
            let remainder = a.checked_rem(b).ok_or(ExprError::IntegerOverflow)?;
            let adjusted = if remainder != 0 && (remainder < 0) != (b < 0) {
                quotient.checked_sub(1).ok_or(ExprError::IntegerOverflow)?
            } else {
                quotient
            };
            Ok(crate::value::EvalValue::Int(adjusted))
        }
        (a, b) => {
            let denominator = number_to_f64(b);
            if denominator == 0.0 {
                return Err(ExprError::DivisionByZero);
            }
            let numerator = number_to_f64(a);
            Ok(crate::value::EvalValue::Float(
                (numerator / denominator).floor(),
            ))
        }
    }
}

pub(super) fn numeric_pow(
    left: NumberValue,
    right: NumberValue,
) -> Result<crate::value::EvalValue, ExprError> {
    match (left, right) {
        (NumberValue::Int(base), NumberValue::Int(exp)) if exp >= 0 => {
            let exponent = u32::try_from(exp).map_err(|_| ExprError::IntegerOverflow)?;
            let value = base
                .checked_pow(exponent)
                .ok_or(ExprError::IntegerOverflow)?;
            Ok(crate::value::EvalValue::Int(value))
        }
        (a, b) => {
            let base = number_to_f64(a);
            let exponent = number_to_f64(b);
            if base == 0.0 && exponent < 0.0 {
                return Err(ExprError::DivisionByZero);
            }
            Ok(crate::value::EvalValue::Float(base.powf(exponent)))
        }
    }
}

pub(super) fn numeric_mod(
    left: NumberValue,
    right: NumberValue,
) -> Result<crate::value::EvalValue, ExprError> {
    match (left, right) {
        (NumberValue::Int(a), NumberValue::Int(b)) => {
            let remainder = python_int_mod_checked(a, b)?;
            Ok(crate::value::EvalValue::Int(remainder))
        }
        (a, b) => {
            let left_value = number_to_f64(a);
            let right_value = number_to_f64(b);
            if right_value == 0.0 {
                return Err(ExprError::DivisionByZero);
            }
            let mut remainder = left_value % right_value;
            if remainder != 0.0 && (remainder.is_sign_negative() != right_value.is_sign_negative())
            {
                remainder += right_value;
            }
            Ok(crate::value::EvalValue::Float(remainder))
        }
    }
}

pub(super) fn python_int_mod_checked(a: i128, b: i128) -> Result<i128, ExprError> {
    if b == 0 {
        return Err(ExprError::DivisionByZero);
    }

    // Rust panics on i128::MIN % -1, while Python's modulo result is 0.
    if a == i128::MIN && b == -1 {
        return Ok(0);
    }

    let mut remainder = a.checked_rem(b).ok_or(ExprError::IntegerOverflow)?;
    if remainder != 0 && (remainder < 0) != (b < 0) {
        remainder = remainder.checked_add(b).ok_or(ExprError::IntegerOverflow)?;
    }
    Ok(remainder)
}

pub(super) fn numeric_cmp(left: NumberValue, right: NumberValue) -> Result<Ordering, ExprError> {
    match (left, right) {
        (NumberValue::Int(a), NumberValue::Int(b)) => Ok(a.cmp(&b)),
        (NumberValue::Float(a), NumberValue::Float(b)) => {
            a.partial_cmp(&b).ok_or_else(|| ExprError::TypeError {
                message: "cannot order NaN values".to_string(),
            })
        }
        (NumberValue::Int(a), NumberValue::Float(b)) => cmp_int_float(a, b),
        (NumberValue::Float(a), NumberValue::Int(b)) => cmp_int_float(b, a).map(Ordering::reverse),
    }
}

pub(super) fn numeric_equals(left: NumberValue, right: NumberValue) -> Result<bool, ExprError> {
    match (left, right) {
        (NumberValue::Int(a), NumberValue::Int(b)) => Ok(a == b),
        (NumberValue::Float(a), NumberValue::Float(b)) => {
            if a.is_nan() || b.is_nan() {
                Ok(false)
            } else {
                Ok(a == b)
            }
        }
        (NumberValue::Int(a), NumberValue::Float(b))
        | (NumberValue::Float(b), NumberValue::Int(a)) => {
            if b.is_nan() {
                return Ok(false);
            }
            cmp_int_float(a, b).map(|cmp| cmp == Ordering::Equal)
        }
    }
}

fn cmp_int_float(integer: i128, float: f64) -> Result<Ordering, ExprError> {
    if float.is_nan() {
        return Err(ExprError::TypeError {
            message: "cannot order NaN values".to_string(),
        });
    }

    if float.is_infinite() {
        return Ok(if float.is_sign_positive() {
            Ordering::Less
        } else {
            Ordering::Greater
        });
    }

    let bits = float.to_bits();
    let sign_negative = (bits >> 63) != 0;
    let exponent_bits = ((bits >> 52) & 0x7ff) as i32;
    let fraction = bits & ((1_u64 << 52) - 1);

    if exponent_bits == 0 && fraction == 0 {
        return Ok(integer.cmp(&0));
    }

    let (mantissa, exponent) = if exponent_bits == 0 {
        (fraction, -1074)
    } else {
        ((1_u64 << 52) | fraction, exponent_bits - 1075)
    };

    if exponent >= 0 {
        if exponent >= 127 {
            return Ok(if sign_negative {
                Ordering::Greater
            } else {
                Ordering::Less
            });
        }

        let signed_mantissa = if sign_negative {
            -i128::from(mantissa)
        } else {
            i128::from(mantissa)
        };

        let maybe_value = signed_mantissa.checked_shl(exponent as u32);
        return Ok(match maybe_value {
            Some(value) => integer.cmp(&value),
            None => {
                if sign_negative {
                    Ordering::Greater
                } else {
                    Ordering::Less
                }
            }
        });
    }

    let shift = (-exponent) as u32;
    let (integer_part_u64, has_fraction) = if shift >= 64 {
        (0_u64, mantissa != 0)
    } else {
        let remainder_mask = (1_u64 << shift) - 1;
        (mantissa >> shift, (mantissa & remainder_mask) != 0)
    };

    let integer_part = i128::from(integer_part_u64);
    if !sign_negative {
        return Ok(if has_fraction {
            if integer <= integer_part {
                Ordering::Less
            } else {
                Ordering::Greater
            }
        } else {
            integer.cmp(&integer_part)
        });
    }

    if !has_fraction {
        let value = -integer_part;
        return Ok(integer.cmp(&value));
    }

    let floor = -(integer_part + 1);
    let ceil = -integer_part;
    Ok(if integer <= floor {
        Ordering::Less
    } else if integer >= ceil {
        Ordering::Greater
    } else {
        Ordering::Less
    })
}
