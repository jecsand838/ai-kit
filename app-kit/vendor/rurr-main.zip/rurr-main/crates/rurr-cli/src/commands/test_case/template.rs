use rurr_tracking_store::tracking_repository::LocalTestCaseExtraction;
use std::path::Path;

pub(super) fn helper_template(path: Option<&Path>, extraction: &LocalTestCaseExtraction) -> String {
    let fixture_source = path
        .map(|value| value.display().to_string())
        .unwrap_or_else(|| "stdout".to_string());
    format!(
        "Test case template\n- Fixture source: {fixture_source}\n- Action under test: {}\n- Load `input_state` and `expected_state` from the generated fixture JSON.\n- Execute the action with `input_state`.\n- Compare the resulting state against `expected_state` using the assertion strategy that fits this action.",
        extraction.fixture.action
    )
}
