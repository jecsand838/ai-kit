mod support_common;
pub(crate) mod test_support {
    pub(crate) use crate::support_common::persistence::{
        with_async_initializer_spec, with_async_persister_spec, with_sync_initializer_spec,
        with_sync_persister_spec,
    };
    pub(crate) use crate::support_common::registry::{registry_test_guard, unique_registry_name};
}

mod e2e {
    mod end_to_end_smoke;
    mod integration_app_smoke;
    mod integration_backends_smoke;
    mod oracle_scenarios;
    mod support;
}
