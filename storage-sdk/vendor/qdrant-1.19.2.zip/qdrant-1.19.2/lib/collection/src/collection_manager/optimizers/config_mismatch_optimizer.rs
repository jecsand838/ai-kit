// Deprecated storage placement params (`on_disk`, `always_ram`, `on_disk_payload`) are still
// handled here for backward compatibility with the new `memory` parameter
#![allow(deprecated)]

/// Looks for segments having a mismatch between configured and actual parameters
///
/// For example, a user may change the HNSW parameters for a collection. A segment that was already
/// indexed with different parameters now has a mismatch. This segment should be optimized (and
/// indexed) again in order to update the effective configuration.
pub use shard::optimizers::config_mismatch_optimizer::ConfigMismatchOptimizer;

#[cfg(test)]
mod tests {
    use std::collections::HashMap;

    use itertools::Itertools;
    use segment::data_types::vectors::DEFAULT_VECTOR_NAME;
    use segment::entry::{ReadSegmentEntry, StorageSegmentEntry};
    use segment::id_tracker::IdTrackerFormat;
    use segment::segment_constructor::simple_segment_constructor::{VECTOR1_NAME, VECTOR2_NAME};
    use segment::types::{
        CompressionRatio, HnswConfig, HnswGlobalConfig, Indexes, Memory, ProductQuantization,
        ProductQuantizationConfig, QuantizationConfig, ScalarQuantizationConfig, ScalarType,
        SegmentConfig, VectorNameBuf,
    };
    use shard::operations::optimization::OptimizerThresholds;
    use shard::optimizers::config::{
        DenseVectorOptimizerConfig, SegmentOptimizerConfig, SparseVectorOptimizerConfig,
    };
    use shard::optimizers::segment_optimizer::SegmentOptimizer;
    use shard::segment_holder::locked::LockedSegmentHolder;
    use tempfile::Builder;

    use super::*;
    use crate::collection_manager::fixtures::{random_multi_vec_segment, random_segment};
    use crate::collection_manager::holders::segment_holder::SegmentHolder;
    use crate::collection_manager::optimizers::indexing_optimizer::IndexingOptimizer;

    fn dense_config(
        segment_config: &SegmentConfig,
        name: &str,
        on_disk: Option<bool>,
        hnsw_config: HnswConfig,
        quantization_config: Option<QuantizationConfig>,
    ) -> DenseVectorOptimizerConfig {
        let vector_data = &segment_config.vector_data[name];
        DenseVectorOptimizerConfig {
            size: vector_data.size,
            distance: vector_data.distance,
            on_disk,
            memory: None,
            hnsw_config,
            quantization_config,
            multivector_config: vector_data.multivector_config,
            datatype: vector_data.datatype,
        }
    }

    fn segment_optimizer_config(
        segment_config: &SegmentConfig,
        dense_overrides: &HashMap<VectorNameBuf, DenseVectorOptimizerConfig>,
    ) -> SegmentOptimizerConfig {
        let dense_vectors = segment_config
            .vector_data
            .keys()
            .map(|name| {
                let cfg = dense_overrides.get(name).cloned().unwrap_or_else(|| {
                    dense_config(segment_config, name, None, HnswConfig::default(), None)
                });
                (name.clone(), cfg)
            })
            .collect();

        let sparse_vectors = segment_config
            .sparse_vector_data
            .iter()
            .map(|(name, sparse_data)| {
                let cfg = SparseVectorOptimizerConfig {
                    memory: None,
                    on_disk: None,
                    full_scan_threshold: sparse_data.index.full_scan_threshold,
                    index_datatype: sparse_data.index.datatype,
                    storage_type: sparse_data.storage_type,
                    modifier: sparse_data.modifier,
                };
                (name.clone(), cfg)
            })
            .collect();

        SegmentOptimizerConfig {
            payload_storage_type: segment_config.payload_storage_type,
            id_tracker_memory: None,
            dense_vectors,
            sparse_vectors,
            live_vector_names: None,
        }
    }

    /// This test the config mismatch optimizer for a changed HNSW config
    ///
    /// It tests whether:
    /// - the condition check for HNSW mismatches works
    /// - optimized segments (and vector storages) use the updated configuration
    ///
    /// In short, this is what happens in this test:
    /// - create randomized segment as base
    /// - use indexing optimizer to build index for our segment
    /// - test config mismatch condition: should not trigger yet
    /// - change collection HNSW config
    /// - test config mismatch condition: should trigger due to HNSW change
    /// - optimize segment with config mismatch optimizer
    /// - assert segment uses changed configuration
    #[test]
    fn test_hnsw_config_mismatch() {
        // Collection configuration
        let (point_count, dim) = (1000, 10);
        let thresholds_config = OptimizerThresholds {
            max_segment_size_kb: usize::MAX,
            memmap_threshold_kb: usize::MAX,
            indexing_threshold_kb: 10,
            deferred_internal_id: None,
        };

        // Base segment
        let temp_dir = Builder::new().prefix("segment_temp_dir").tempdir().unwrap();
        let dir = Builder::new().prefix("segment_dir").tempdir().unwrap();
        let mut holder = SegmentHolder::default();

        let segment = random_segment(dir.path(), 100, point_count, dim as usize);
        let base_segment_config = segment.segment_config.clone();

        let segment_id = holder.add_new(segment);
        let locked_holder = LockedSegmentHolder::new(holder);

        let hnsw_config = HnswConfig {
            memory: None,
            m: 16,
            ef_construct: 100,
            full_scan_threshold: 10,
            max_indexing_threads: 0,
            on_disk: None,
            payload_m: None,
            inline_storage: None,
        };

        let mut dense_overrides = HashMap::new();
        dense_overrides.insert(
            VectorNameBuf::from(DEFAULT_VECTOR_NAME),
            dense_config(
                &base_segment_config,
                DEFAULT_VECTOR_NAME,
                None,
                hnsw_config,
                None,
            ),
        );
        let optimizer_config = segment_optimizer_config(&base_segment_config, &dense_overrides);

        // Optimizers used in test
        let index_optimizer = IndexingOptimizer::new(
            2,
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            optimizer_config.clone(),
            HnswGlobalConfig::default(),
        );
        let config_mismatch_optimizer = ConfigMismatchOptimizer::new(
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            optimizer_config,
            hnsw_config,
            HnswGlobalConfig::default(),
        );

        // Use indexing optimizer to build index for HNSW mismatch test
        let changed = index_optimizer.optimize_for_test(locked_holder.clone(), vec![segment_id]);
        assert!(changed > 0, "optimizer should have rebuilt this segment");
        assert!(
            locked_holder.read().get(segment_id).is_none(),
            "optimized segment should be gone",
        );
        assert_eq!(locked_holder.read().len(), 2, "index must be built");

        // Mismatch optimizer should not optimize yet, HNSW config is not changed yet
        let suggested_to_optimize =
            config_mismatch_optimizer.plan_optimizations_for_test(&locked_holder);
        assert_eq!(suggested_to_optimize.len(), 0);

        // Create changed HNSW config with other m/ef_construct value, update it in the optimizer
        let mut changed_hnsw_config = hnsw_config;
        changed_hnsw_config.m /= 2;
        changed_hnsw_config.ef_construct /= 5;

        dense_overrides.insert(
            VectorNameBuf::from(DEFAULT_VECTOR_NAME),
            dense_config(
                &base_segment_config,
                DEFAULT_VECTOR_NAME,
                None,
                changed_hnsw_config,
                None,
            ),
        );
        let changed_optimizer_config =
            segment_optimizer_config(&base_segment_config, &dense_overrides);
        let config_mismatch_optimizer = ConfigMismatchOptimizer::new(
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            changed_optimizer_config,
            changed_hnsw_config,
            HnswGlobalConfig::default(),
        );

        // Run mismatch optimizer again, make sure it optimizes now
        let suggested_to_optimize =
            config_mismatch_optimizer.plan_optimizations_for_test(&locked_holder);
        let suggested_to_optimize = suggested_to_optimize.into_iter().exactly_one().unwrap();
        assert_eq!(suggested_to_optimize.len(), 1);
        let changed = config_mismatch_optimizer
            .optimize_for_test(locked_holder.clone(), suggested_to_optimize);
        assert!(changed > 0, "optimizer should have rebuilt this segment");

        // Ensure new segment has changed HNSW config
        locked_holder
            .read()
            .iter_original()
            .map(|(_, segment)| segment.read())
            .filter(|segment| segment.total_point_count() > 0)
            .for_each(|segment| {
                assert_eq!(
                    segment.config().vector_data[DEFAULT_VECTOR_NAME].index,
                    Indexes::Hnsw(changed_hnsw_config),
                    "segment must be optimized with changed HNSW config",
                );
            });
    }

    /// This test the config mismatch optimizer for a changed vector specific HNSW config
    ///
    /// Similar to `test_hnsw_config_mismatch` but for multi vector segment with a vector specific
    /// change.
    ///
    /// It tests whether:
    /// - the condition check for HNSW mismatches works for a vector specific change
    /// - optimized segments (and vector storages) use the updated configuration
    ///
    /// In short, this is what happens in this test:
    /// - create randomized multi segment as base
    /// - use indexing optimizer to build index for our segment
    /// - test config mismatch condition: should not trigger yet
    /// - change HNSW config for vector2
    /// - test config mismatch condition: should trigger due to HNSW change
    /// - optimize segment with config mismatch optimizer
    /// - assert segment uses changed configuration
    #[test]
    fn test_hnsw_config_mismatch_vector_specific() {
        // Collection configuration
        let (point_count, vector1_dim, vector2_dim) = (1000, 10, 20);
        let thresholds_config = OptimizerThresholds {
            max_segment_size_kb: usize::MAX,
            memmap_threshold_kb: usize::MAX,
            indexing_threshold_kb: 10,
            deferred_internal_id: None,
        };

        // Base segment
        let temp_dir = Builder::new().prefix("segment_temp_dir").tempdir().unwrap();
        let dir = Builder::new().prefix("segment_dir").tempdir().unwrap();
        let mut holder = SegmentHolder::default();

        let segment = random_multi_vec_segment(
            dir.path(),
            100,
            point_count,
            vector1_dim as usize,
            vector2_dim as usize,
        );
        let base_segment_config = segment.segment_config.clone();

        let segment_id = holder.add_new(segment);
        let locked_holder = LockedSegmentHolder::new(holder);

        let hnsw_config_collection = HnswConfig {
            memory: None,
            m: 16,
            ef_construct: 100,
            full_scan_threshold: 10,
            max_indexing_threads: 0,
            on_disk: None,
            payload_m: None,
            inline_storage: None,
        };

        let mut hnsw_config_vector1 = hnsw_config_collection;
        hnsw_config_vector1.m = 10;
        hnsw_config_vector1.ef_construct = 40;
        hnsw_config_vector1.on_disk = Some(true);

        let hnsw_config_vector2 = hnsw_config_collection;

        let mut dense_overrides = HashMap::new();
        dense_overrides.insert(
            VectorNameBuf::from(VECTOR1_NAME),
            dense_config(
                &base_segment_config,
                VECTOR1_NAME,
                Some(true),
                hnsw_config_vector1,
                None,
            ),
        );
        dense_overrides.insert(
            VectorNameBuf::from(VECTOR2_NAME),
            dense_config(
                &base_segment_config,
                VECTOR2_NAME,
                None,
                hnsw_config_vector2,
                None,
            ),
        );
        let optimizer_config = segment_optimizer_config(&base_segment_config, &dense_overrides);

        // Optimizers used in test
        let index_optimizer = IndexingOptimizer::new(
            2,
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            optimizer_config.clone(),
            HnswGlobalConfig::default(),
        );
        let config_mismatch_optimizer = ConfigMismatchOptimizer::new(
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            optimizer_config,
            hnsw_config_collection,
            HnswGlobalConfig::default(),
        );

        // Use indexing optimizer to build index for HNSW mismatch test
        let changed = index_optimizer.optimize_for_test(locked_holder.clone(), vec![segment_id]);
        assert!(changed > 0, "optimizer should have rebuilt this segment");
        assert!(
            locked_holder.read().get(segment_id).is_none(),
            "optimized segment should be gone",
        );
        assert_eq!(locked_holder.read().len(), 2, "index must be built");

        // Mismatch optimizer should not optimize yet, HNSW config is not changed yet
        let suggested_to_optimize =
            config_mismatch_optimizer.plan_optimizations_for_test(&locked_holder);
        assert_eq!(suggested_to_optimize.len(), 0);

        let mut hnsw_config_vector2_changed = hnsw_config_collection;
        hnsw_config_vector2_changed.m = hnsw_config_vector1.m / 2;
        hnsw_config_vector2_changed.on_disk = Some(true);

        dense_overrides.insert(
            VectorNameBuf::from(VECTOR2_NAME),
            dense_config(
                &base_segment_config,
                VECTOR2_NAME,
                None,
                hnsw_config_vector2_changed,
                None,
            ),
        );
        let changed_optimizer_config =
            segment_optimizer_config(&base_segment_config, &dense_overrides);
        let config_mismatch_optimizer = ConfigMismatchOptimizer::new(
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            changed_optimizer_config,
            hnsw_config_collection,
            HnswGlobalConfig::default(),
        );

        // Run mismatch optimizer again, make sure it optimizes now
        let suggested_to_optimize =
            config_mismatch_optimizer.plan_optimizations_for_test(&locked_holder);
        let suggested_to_optimize = suggested_to_optimize.into_iter().exactly_one().unwrap();
        assert_eq!(suggested_to_optimize.len(), 1);
        let changed = config_mismatch_optimizer
            .optimize_for_test(locked_holder.clone(), suggested_to_optimize);
        assert!(changed > 0, "optimizer should have rebuilt this segment");

        // Ensure new segment has changed HNSW config
        locked_holder
            .read()
            .iter_original()
            .map(|(_, segment)| segment.read())
            .filter(|segment| segment.total_point_count() > 0)
            .for_each(|segment| {
                assert_eq!(
                    segment.config().vector_data[VECTOR1_NAME].index,
                    Indexes::Hnsw(hnsw_config_vector1),
                    "HNSW config of vector1 is not what we expect",
                );
                assert_eq!(
                    segment.config().vector_data[VECTOR2_NAME].index,
                    Indexes::Hnsw(hnsw_config_vector2_changed),
                    "HNSW config of vector2 is not what we expect",
                );
            });
    }

    /// This test the config mismatch optimizer for a changed vector specific HNSW config
    ///
    /// Similar to `test_hnsw_config_mismatch` but for multi vector segment with a vector specific
    /// change.
    ///
    /// It tests whether:
    /// - the condition check for HNSW mismatches works for a vector specific change
    /// - optimized segments (and vector storages) use the updated configuration
    ///
    /// In short, this is what happens in this test:
    /// - create randomized multi segment as base
    /// - use indexing optimizer to build index for our segment
    /// - test config mismatch condition: should not trigger yet
    /// - change HNSW config for vector2
    /// - test config mismatch condition: should trigger due to HNSW change
    /// - optimize segment with config mismatch optimizer
    /// - assert segment uses changed configuration
    #[test]
    fn test_quantization_config_mismatch_vector_specific() {
        // Collection configuration
        let (point_count, vector1_dim, vector2_dim) = (1000, 10, 20);
        let thresholds_config = OptimizerThresholds {
            max_segment_size_kb: usize::MAX,
            memmap_threshold_kb: usize::MAX,
            indexing_threshold_kb: 10,
            deferred_internal_id: None,
        };
        let quantization_config_vector1 =
            QuantizationConfig::Scalar(segment::types::ScalarQuantization {
                scalar: ScalarQuantizationConfig {
                    memory: None,
                    r#type: ScalarType::Int8,
                    quantile: Some(0.99),
                    always_ram: Some(true),
                },
            });

        // Base segment
        let temp_dir = Builder::new().prefix("segment_temp_dir").tempdir().unwrap();
        let dir = Builder::new().prefix("segment_dir").tempdir().unwrap();
        let mut holder = SegmentHolder::default();

        let segment = random_multi_vec_segment(
            dir.path(),
            100,
            point_count,
            vector1_dim as usize,
            vector2_dim as usize,
        );
        let base_segment_config = segment.segment_config.clone();

        let segment_id = holder.add_new(segment);
        let locked_holder = LockedSegmentHolder::new(holder);

        let quantization_config_collection =
            QuantizationConfig::Scalar(segment::types::ScalarQuantization {
                scalar: ScalarQuantizationConfig {
                    memory: None,
                    r#type: ScalarType::Int8,
                    quantile: Some(0.91),
                    always_ram: None,
                },
            });

        let mut dense_overrides = HashMap::new();
        dense_overrides.insert(
            VectorNameBuf::from(VECTOR1_NAME),
            dense_config(
                &base_segment_config,
                VECTOR1_NAME,
                None,
                HnswConfig::default(),
                Some(quantization_config_vector1.clone()),
            ),
        );
        dense_overrides.insert(
            VectorNameBuf::from(VECTOR2_NAME),
            dense_config(
                &base_segment_config,
                VECTOR2_NAME,
                None,
                HnswConfig::default(),
                Some(quantization_config_collection.clone()),
            ),
        );
        let optimizer_config = segment_optimizer_config(&base_segment_config, &dense_overrides);

        // Optimizers used in test
        let index_optimizer = IndexingOptimizer::new(
            2,
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            optimizer_config.clone(),
            HnswGlobalConfig::default(),
        );
        let config_mismatch_optimizer = ConfigMismatchOptimizer::new(
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            optimizer_config,
            Default::default(),
            HnswGlobalConfig::default(),
        );

        // Use indexing optimizer to build index for quantization mismatch test
        let changed = index_optimizer.optimize_for_test(locked_holder.clone(), vec![segment_id]);
        assert!(changed > 0, "optimizer should have rebuilt this segment");
        assert!(
            locked_holder.read().get(segment_id).is_none(),
            "optimized segment should be gone",
        );
        assert_eq!(locked_holder.read().len(), 2, "index must be built");

        // Mismatch optimizer should not optimize yet, quantization config is not changed yet
        let suggested_to_optimize =
            config_mismatch_optimizer.plan_optimizations_for_test(&locked_holder);
        assert_eq!(suggested_to_optimize.len(), 0);

        // Create changed quantization config for vector2, update it in the optimizer
        let quantization_config_vector2 = QuantizationConfig::Product(ProductQuantization {
            product: ProductQuantizationConfig {
                memory: None,
                compression: CompressionRatio::X32,
                always_ram: Some(true),
            },
        });
        dense_overrides.insert(
            VectorNameBuf::from(VECTOR2_NAME),
            dense_config(
                &base_segment_config,
                VECTOR2_NAME,
                None,
                HnswConfig::default(),
                Some(quantization_config_vector2.clone()),
            ),
        );
        let changed_optimizer_config =
            segment_optimizer_config(&base_segment_config, &dense_overrides);
        let config_mismatch_optimizer = ConfigMismatchOptimizer::new(
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            changed_optimizer_config,
            Default::default(),
            HnswGlobalConfig::default(),
        );

        // Run mismatch optimizer again, make sure it optimizes now
        let suggested_to_optimize =
            config_mismatch_optimizer.plan_optimizations_for_test(&locked_holder);
        let suggested_to_optimize = suggested_to_optimize.into_iter().exactly_one().unwrap();
        assert_eq!(suggested_to_optimize.len(), 1);
        let changed = config_mismatch_optimizer
            .optimize_for_test(locked_holder.clone(), suggested_to_optimize);
        assert!(changed > 0, "optimizer should have rebuilt this segment");

        // Ensure new segment has changed quantization config
        locked_holder
            .read()
            .iter_original()
            .map(|(_, segment)| segment.read())
            .filter(|segment| segment.total_point_count() > 0)
            .for_each(|segment| {
                assert_eq!(
                    segment.config().vector_data[VECTOR1_NAME].quantization_config,
                    Some(quantization_config_vector1.clone()),
                    "Quantization config of vector1 is not what we expect",
                );
                assert_eq!(
                    segment.config().vector_data[VECTOR2_NAME].quantization_config,
                    Some(quantization_config_vector2.clone()),
                    "Quantization config of vector2 is not what we expect",
                );
            });
    }
    /// Id tracker formats of the non-appendable segments in the holder, detected from their files
    fn indexed_id_tracker_formats(holder: &LockedSegmentHolder) -> Vec<IdTrackerFormat> {
        holder
            .read()
            .iter_original()
            .map(|(_, segment)| segment.read())
            .filter(|segment| !segment.config().is_appendable())
            .map(|segment| IdTrackerFormat::detect_local(&segment.data_path(), false))
            .collect()
    }

    /// The id tracker placement is a rebuild-requiring parameter: an indexed segment carries the
    /// tracker format in its files, so changing the requested placement must trigger the config
    /// mismatch optimizer exactly once, and the rebuilt segment must use the requested format.
    #[test]
    fn test_id_tracker_memory_mismatch() {
        let (point_count, dim) = (1000, 10);
        let thresholds_config = OptimizerThresholds {
            max_segment_size_kb: usize::MAX,
            memmap_threshold_kb: usize::MAX,
            indexing_threshold_kb: 10,
            deferred_internal_id: None,
        };

        let temp_dir = Builder::new().prefix("segment_temp_dir").tempdir().unwrap();
        let dir = Builder::new().prefix("segment_dir").tempdir().unwrap();
        let mut holder = SegmentHolder::default();

        let segment = random_segment(dir.path(), 100, point_count, dim as usize);
        let base_segment_config = segment.segment_config.clone();

        let segment_id = holder.add_new(segment);
        let locked_holder = LockedSegmentHolder::new(holder);

        let optimizer_config = segment_optimizer_config(&base_segment_config, &HashMap::new());
        let index_optimizer = IndexingOptimizer::new(
            2,
            thresholds_config,
            dir.path().to_owned(),
            temp_dir.path().to_owned(),
            optimizer_config.clone(),
            HnswGlobalConfig::default(),
        );
        let changed = index_optimizer.optimize_for_test(locked_holder.clone(), vec![segment_id]);
        assert!(changed > 0, "optimizer should have rebuilt this segment");

        let mismatch_optimizer = |id_tracker_memory| {
            ConfigMismatchOptimizer::new(
                thresholds_config,
                dir.path().to_owned(),
                temp_dir.path().to_owned(),
                SegmentOptimizerConfig {
                    id_tracker_memory,
                    ..optimizer_config.clone()
                },
                HnswConfig::default(),
                HnswGlobalConfig::default(),
            )
        };

        // Nothing requested: the deployment default (in-RAM tracker) is used and nothing is
        // planned. Requesting that same default explicitly must not plan a rebuild either.
        assert_eq!(
            indexed_id_tracker_formats(&locked_holder),
            vec![IdTrackerFormat::Immutable],
        );
        for memory in [None, Some(Memory::Pinned)] {
            let planned = mismatch_optimizer(memory).plan_optimizations_for_test(&locked_holder);
            assert!(
                planned.is_empty(),
                "{memory:?} must not plan a rebuild: {planned:?}"
            );
        }

        // Requesting the on-disk tracker rebuilds the segment into the disk format...
        let optimizer = mismatch_optimizer(Some(Memory::Cold));
        let suggested = optimizer
            .plan_optimizations_for_test(&locked_holder)
            .into_iter()
            .exactly_one()
            .unwrap();
        let changed = optimizer.optimize_for_test(locked_holder.clone(), suggested);
        assert!(changed > 0, "optimizer should have rebuilt this segment");
        assert_eq!(
            indexed_id_tracker_formats(&locked_holder),
            vec![IdTrackerFormat::Disk],
        );
        // ...and the rebuilt segment satisfies the request, so it is not planned again
        assert!(
            optimizer
                .plan_optimizations_for_test(&locked_holder)
                .is_empty()
        );

        // Switching back rebuilds into the in-RAM tracker
        let optimizer = mismatch_optimizer(Some(Memory::Pinned));
        let suggested = optimizer
            .plan_optimizations_for_test(&locked_holder)
            .into_iter()
            .exactly_one()
            .unwrap();
        let changed = optimizer.optimize_for_test(locked_holder.clone(), suggested);
        assert!(changed > 0, "optimizer should have rebuilt this segment");
        assert_eq!(
            indexed_id_tracker_formats(&locked_holder),
            vec![IdTrackerFormat::Immutable],
        );
    }
}
