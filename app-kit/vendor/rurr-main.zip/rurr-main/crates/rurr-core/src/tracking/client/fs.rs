use super::*;

fn expand_home(path: &Path) -> PathBuf {
    store_util::expand_home_path(path)
}

fn resolve_project_anchor(
    raw_storage_dir: &Path,
    project_id: &str,
) -> Result<store_util::anchored_fs::AnchoredDir, TrackingError> {
    let expanded_root = expand_home(raw_storage_dir);
    std::fs::create_dir_all(&expanded_root)?;
    let storage_root_anchor = store_util::anchored_fs::AnchoredDir::open(&expanded_root)?;
    storage_root_anchor
        .ensure_child_dir(STORAGE_ROOT_SCOPE, PROJECT_ID_KIND, project_id)
        .map_err(TrackingError::from)
}

impl LocalTrackingClient {
    /// Creates a local tracking client without custom serde parameters.
    ///
    /// The storage root is created if needed and pinned through the tracking
    /// store's anchored filesystem boundary. Application artifacts are written
    /// only after [`register_application`](Self::register_application) is
    /// called.
    pub fn new(
        project: impl Into<String>,
        storage_dir: impl AsRef<Path>,
    ) -> Result<Self, TrackingError> {
        Self::with_serde_kwargs(project, storage_dir, IndexMap::new())
    }

    /// Creates a local tracking client with custom serde parameters for persisted payloads.
    ///
    /// Unknown or malformed serde parameters are kept as explicit client state;
    /// they do not alter the required local artifact contract used by
    /// registration, tracking reads, or persistence resume.
    pub fn with_serde_kwargs(
        project: impl Into<String>,
        storage_dir: impl AsRef<Path>,
        serde_kwargs: IndexMap<String, Value>,
    ) -> Result<Self, TrackingError> {
        let project_id = project.into();
        if !allowed_project_name(&project_id, cfg!(windows)) {
            return Err(TrackingError::InvalidProjectName {
                project: project_id,
            });
        }

        let raw_storage_dir = storage_dir.as_ref().to_path_buf();
        let project_anchor = resolve_project_anchor(&raw_storage_dir, &project_id)?;

        Ok(Self {
            project_id,
            raw_storage_dir,
            project_anchor,
            serde_kwargs,
            lifecycle_log: TrackingLifecycleLog::new(),
            write_lock: Mutex::new(()),
        })
    }

    /// Returns the normalized project identifier used by this client.
    pub fn project_id(&self) -> &str {
        &self.project_id
    }

    /// Returns the resolved storage directory for this project.
    pub fn storage_dir(&self) -> &Path {
        self.project_anchor.display_path()
    }

    pub(super) fn project_anchor(&self) -> &store_util::anchored_fs::AnchoredDir {
        &self.project_anchor
    }

    /// Returns the serde keyword arguments attached to this client.
    pub fn serde_kwargs(&self) -> &IndexMap<String, Value> {
        &self.serde_kwargs
    }

    /// Creates a logically equivalent client that points at the same storage location.
    pub fn copy(&self) -> Result<Self, TrackingError> {
        Self::with_serde_kwargs(
            self.project_id.clone(),
            self.raw_storage_dir.clone(),
            self.serde_kwargs.clone(),
        )
    }

    pub(super) fn normalize_partition_key(partition_key: Option<&str>) -> String {
        store_util::normalize_partition_key(partition_key)
    }
}
