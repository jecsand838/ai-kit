use super::dir_errors::{
    anchored_dir_invalid_error, anchored_dir_listing_alias_error, anchored_dir_open_error,
    child_alias_error, child_directory_missing_error, child_non_directory_error, child_open_error,
};
use super::kernel::{self, DirectChildDirectoryMissingBehavior, DirectChildPathType};
use super::path::validate_path_segment;
use std::ffi::OsStr;
use std::io;
use std::path::{Path, PathBuf};
use std::sync::Arc;

#[derive(Debug, Clone)]
pub struct AnchoredDir {
    state: Arc<AnchoredDirState>,
}

#[derive(Debug)]
struct AnchoredDirState {
    display_path: PathBuf,
    source: AnchoredDirSource,
    handle: kernel::AnchoredDirectory,
}

#[derive(Debug, Clone)]
enum AnchoredDirSource {
    Root,
    Child { parent: AnchoredDir, raw: String },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(super) enum ExactChildDirectoryMissingBehavior {
    OptionalMissing,
    MustExist,
    CreateIfMissing,
}

impl AnchoredDir {
    pub fn open(path: impl AsRef<Path>) -> io::Result<Self> {
        let requested_path = path.as_ref();
        let display_path =
            std::fs::canonicalize(requested_path).map_err(|error| match error.kind() {
                io::ErrorKind::NotFound => io::Error::new(
                    io::ErrorKind::NotFound,
                    format!(
                        "open anchored directory '{}': {error}",
                        requested_path.display()
                    ),
                ),
                _ => anchored_dir_open_error(requested_path, error),
            })?;
        let handle = kernel::open_root_directory(&display_path)
            .map_err(|error| anchored_dir_open_error(requested_path, error))?;
        Ok(Self {
            state: Arc::new(AnchoredDirState {
                display_path,
                source: AnchoredDirSource::Root,
                handle,
            }),
        })
    }

    pub fn display_path(&self) -> &Path {
        &self.state.display_path
    }

    pub fn revalidate(&self) -> io::Result<()> {
        match &self.state.source {
            AnchoredDirSource::Root => {
                kernel::revalidate_root_directory(self.handle(), self.display_path())
                    .map_err(|_| anchored_dir_invalid_error(self.display_path()))
            }
            AnchoredDirSource::Child { parent, raw } => {
                parent.revalidate()?;
                kernel::revalidate_direct_child_directory(
                    parent.handle(),
                    self.handle(),
                    OsStr::new(raw),
                )
                .map_err(|_| anchored_dir_invalid_error(self.display_path()))
            }
        }
    }

    pub(crate) fn list_child_dirs(&self) -> io::Result<Vec<String>> {
        self.revalidate()?;
        let candidate_names =
            kernel::list_direct_child_directory_names(self.handle()).map_err(|error| {
                if error.kind() == io::ErrorKind::InvalidInput {
                    anchored_dir_listing_alias_error(self.display_path(), Path::new("<unknown>"))
                } else {
                    error
                }
            })?;
        self.revalidate()?;

        let mut entries = Vec::new();
        for candidate_name in candidate_names {
            let Ok(name) = candidate_name.into_string() else {
                continue;
            };
            match self.open_child_dir_if_present("anchored directory", "directory", &name) {
                Ok(Some(_anchor)) => entries.push(name),
                Ok(None) => {}
                Err(error) if error.kind() == io::ErrorKind::InvalidInput => {
                    self.revalidate()?;
                    return Err(error);
                }
                Err(error) => return Err(error),
            }
        }

        self.revalidate()?;
        Ok(entries)
    }

    pub fn open_child_dir_if_present(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<Option<Self>> {
        self.open_child_dir_with_behavior(
            scope_name,
            kind,
            raw,
            ExactChildDirectoryMissingBehavior::OptionalMissing,
        )
    }

    pub fn open_child_dir(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<Self> {
        self.open_child_dir_with_behavior(
            scope_name,
            kind,
            raw,
            ExactChildDirectoryMissingBehavior::MustExist,
        )?
        .ok_or_else(|| child_directory_missing_error(scope_name, kind, raw))
    }

    pub fn ensure_child_dir(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
    ) -> io::Result<Self> {
        self.open_child_dir_with_behavior(
            scope_name,
            kind,
            raw,
            ExactChildDirectoryMissingBehavior::CreateIfMissing,
        )?
        .ok_or_else(|| child_directory_missing_error(scope_name, kind, raw))
    }

    fn open_child_dir_with_behavior(
        &self,
        scope_name: &'static str,
        kind: &str,
        raw: &str,
        missing_behavior: ExactChildDirectoryMissingBehavior,
    ) -> io::Result<Option<Self>> {
        validate_path_segment(kind, raw)?;
        self.revalidate()?;

        let Some(handle) = kernel::open_direct_child_directory(
            self.handle(),
            OsStr::new(raw),
            missing_behavior.into_kernel(),
        )
        .map_err(|error| {
            map_child_directory_error(
                self.handle(),
                self.display_path(),
                scope_name,
                kind,
                raw,
                error,
            )
        })?
        else {
            return Ok(None);
        };

        Ok(Some(self.child_anchor(raw, handle)))
    }

    pub(super) fn handle(&self) -> &kernel::AnchoredDirectory {
        &self.state.handle
    }

    fn child_anchor(&self, raw: &str, handle: kernel::AnchoredDirectory) -> Self {
        Self {
            state: Arc::new(AnchoredDirState {
                display_path: self.display_path().join(raw),
                source: AnchoredDirSource::Child {
                    parent: self.clone(),
                    raw: raw.to_string(),
                },
                handle,
            }),
        }
    }
}

impl ExactChildDirectoryMissingBehavior {
    fn into_kernel(self) -> DirectChildDirectoryMissingBehavior {
        match self {
            Self::OptionalMissing => DirectChildDirectoryMissingBehavior::OptionalMissing,
            Self::MustExist => DirectChildDirectoryMissingBehavior::MustExist,
            Self::CreateIfMissing => DirectChildDirectoryMissingBehavior::CreateIfMissing,
        }
    }
}

fn map_child_directory_error(
    parent: &kernel::AnchoredDirectory,
    parent_display_path: &Path,
    scope_name: &'static str,
    kind: &str,
    raw: &str,
    error: io::Error,
) -> io::Error {
    match error.kind() {
        io::ErrorKind::NotFound => child_directory_missing_error(scope_name, kind, raw),
        io::ErrorKind::InvalidInput => {
            match kernel::inspect_direct_child(parent, OsStr::new(raw)) {
                Ok(Some(DirectChildPathType::Symlink)) => child_alias_error(scope_name, kind, raw),
                Ok(Some(DirectChildPathType::RegularFile | DirectChildPathType::Other)) => {
                    child_non_directory_error(scope_name, kind, raw)
                }
                _ => child_open_error(parent_display_path, kind, raw, error),
            }
        }
        _ => child_open_error(parent_display_path, kind, raw, error),
    }
}
