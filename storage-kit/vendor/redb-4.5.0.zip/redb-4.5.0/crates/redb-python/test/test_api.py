"""Example-based checks of the bindings."""

from __future__ import annotations

import _thread
import errno
import gc
import importlib.metadata
import math
import os
import threading
import time
from pathlib import Path

import pytest

import redb

USERS = redb.TableDefinition("users", redb.u64, redb.bytes)


def test_errors_form_a_flat_hierarchy() -> None:
    assert redb.Error.__bases__ == (Exception,)
    subclasses = [
        cls
        for cls in vars(redb).values()
        if isinstance(cls, type) and issubclass(cls, redb.Error)
    ]
    subclasses.remove(redb.Error)
    assert redb.Io in subclasses
    assert redb.TransactionCompleted in subclasses
    for cls in subclasses:
        assert cls.__bases__ == ((redb.Error, OSError) if cls is redb.Io else (redb.Error,))
        assert cls.__module__ == "redb"


def test_star_import_does_not_shadow_builtins() -> None:
    namespace: dict[str, object] = {}
    exec("from redb import *", namespace)
    for name in ("open", "str", "bytes", "bool"):
        assert name not in namespace
        assert hasattr(redb, name)
    assert namespace["Database"] is redb.Database
    assert namespace["u64"] is redb.u64


def test_version_is_the_package_version() -> None:
    assert redb.__version__ == importlib.metadata.version("redb")
    assert "__version__" not in redb.__all__


def test_table_definition() -> None:
    users = redb.TableDefinition("users", redb.u64, redb.bytes)
    assert users.name == "users"
    assert users.key_type is redb.Type.u64
    assert users.value_type is redb.bytes
    assert redb.TableDefinition("t", bytes, bytes).key_type is redb.bytes
    assert redb.TableDefinition("t", str, str).key_type is redb.str
    assert repr(users) == 'TableDefinition("users", redb.u64, redb.bytes)'
    with pytest.raises(TypeError, match="explicit width"):
        redb.TableDefinition("t", int, bytes)
    with pytest.raises(TypeError):
        redb.TableDefinition("t", "u64", bytes)
    with pytest.raises(ValueError):
        redb.TableDefinition("", bytes, bytes)


def test_create_new_database_creates_file(tmp_db_path: Path) -> None:
    redb.Database.create(str(tmp_db_path))
    assert tmp_db_path.is_file()
    assert tmp_db_path.stat().st_size > 0


def test_create_on_non_database_file_raises(tmp_db_path: Path) -> None:
    tmp_db_path.write_bytes(b"not a redb database, just some bytes")
    with pytest.raises(redb.Io):
        redb.Database.create(str(tmp_db_path))


def test_create_on_open_database_raises(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with pytest.raises(redb.DatabaseAlreadyOpen) as excinfo:
        redb.Database.create(str(tmp_db_path))
    assert "already open" in str(excinfo.value)
    del db


def test_open_requires_an_existing_database(tmp_db_path: Path) -> None:
    with pytest.raises(redb.Io):
        redb.Database.open(str(tmp_db_path))
    redb.Database.create(str(tmp_db_path))
    redb.Database.open(str(tmp_db_path))


def test_begin_write_commit(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write():
        pass


def test_begin_write_abort(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with pytest.raises(RuntimeError, match="rollback"):
        with db.begin_write():
            raise RuntimeError("rollback")


def test_completed_transaction_releases_database(tmp_db_path: Path) -> None:
    # After the `with` block exits, the transaction must drop its reference
    # to the Database so the underlying file lock is released. Otherwise
    # reopening the same path while a finalized transaction is still alive
    # would fail with DatabaseAlreadyOpen.
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        pass
    del db
    redb.Database.create(str(tmp_db_path))
    assert txn is not None  # keep the finalized txn alive past the reopen


def test_drop_unfinalized_transaction_does_not_deadlock(tmp_db_path: Path) -> None:
    # If an unfinalized transaction is the last owner of the Database,
    # dropping the transaction must release its writer slot before the
    # Database is finalized. Otherwise Database::drop's own begin_write()
    # would self-deadlock waiting for this writer.
    txn = redb.Database.create(str(tmp_db_path)).begin_write()
    del txn


def test_transaction_outlives_anonymous_database(tmp_db_path: Path) -> None:
    # The originating Database has no Python reference, only the
    # transaction does. The transaction must keep the Database alive,
    # otherwise Database.__del__ would block forever waiting for this
    # writer to finish.
    with redb.Database.create(str(tmp_db_path)).begin_write():
        pass


def test_reentering_finalized_transaction_raises(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    txn = db.begin_write()
    with txn:
        pass
    with pytest.raises(redb.TransactionCompleted):
        with txn:
            pass


def test_context_manager_aborts_on_exception(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    txn = db.begin_write()
    with pytest.raises(RuntimeError, match="boom"):
        with txn:
            raise RuntimeError("boom")
    # The transaction is finalized; re-entering must fail.
    with pytest.raises(redb.TransactionCompleted):
        with txn:
            pass


@pytest.mark.parametrize(
    "finish", [redb.WriteTransaction.commit, redb.WriteTransaction.abort]
)
def test_finished_transaction_is_completed(tmp_db_path: Path, finish) -> None:
    db = redb.Database.create(str(tmp_db_path))
    txn = db.begin_write()
    finish(txn)
    with pytest.raises(redb.TransactionCompleted):
        txn.commit()
    with pytest.raises(redb.TransactionCompleted):
        txn.abort()
    with pytest.raises(redb.TransactionCompleted):
        with txn:
            pass


def test_exit_after_explicit_finish_is_a_noop(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        txn.commit()
    with pytest.raises(RuntimeError, match="boom"):
        with db.begin_write() as txn:
            txn.abort()
            raise RuntimeError("boom")


def test_blocked_writer_releases_the_gil(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    txn = db.begin_write()
    done = threading.Event()

    def writer() -> None:
        with db.begin_write():
            pass
        done.set()

    thread = threading.Thread(target=writer)
    thread.start()
    # Blocked on our transaction; this would hang if it held the GIL
    assert not done.wait(0.05)
    txn.commit()
    thread.join(10)
    assert done.is_set()


def test_open_table(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        assert users.name == "users"
        assert len(users) == 0
        assert len(txn.open_table(USERS)) == 0
        # The same name with other types, created earlier in this transaction
        with pytest.raises(redb.TableTypeMismatch):
            txn.open_table(redb.TableDefinition("users", redb.bytes, redb.bytes))
    with pytest.raises(redb.TransactionCompleted):
        len(users)
    # ... and once the table exists in the database
    with db.begin_write() as txn:
        with pytest.raises(redb.TableTypeMismatch):
            txn.open_table(redb.TableDefinition("users", redb.bytes, redb.bytes))
        assert len(txn.open_table(USERS)) == 0


def test_table_keeps_its_transaction_alive(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    users = db.begin_write().open_table(USERS)
    assert len(users) == 0
    del users
    # Dropping the table dropped the transaction, which released the writer slot
    with db.begin_write():
        pass


def test_get_and_insert(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        assert users.get(1) is None
        assert users.insert(1, b"alice") is None
        assert users.insert(1, b"alicia") == b"alice"
        users[2] = bytearray(b"bob")
        assert users[2] == b"bob"
        assert len(users) == 2
        assert 1 in users
        assert 3 not in users
        with pytest.raises(KeyError):
            users[3]
        with pytest.raises(TypeError):
            users[b"1"] = b"x"
        with pytest.raises(TypeError):
            users[3] = "x"
        with pytest.raises(OverflowError):
            users[-1] = b"x"
    txn = db.begin_write()
    txn.open_table(USERS)[3] = b"carol"
    txn.abort()
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        assert users.get(1) == b"alicia"  # committed
        assert 3 not in users  # aborted


def test_read_transaction(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        txn.open_table(USERS)[1] = b"alice"
    read = db.begin_read()
    users = read.open_table(USERS)
    assert isinstance(users, redb.ReadOnlyTable)
    assert users.name == "users"
    assert len(users) == 1
    assert users.get(1) == users[1] == b"alice"
    assert 1 in users
    assert users.get(2) is None
    assert 2 not in users
    with pytest.raises(KeyError):
        users[2]
    with pytest.raises(AttributeError):
        users.insert(2, b"bob")
    with pytest.raises(redb.TableDoesNotExist):
        read.open_table(redb.TableDefinition("missing", redb.u64, redb.bytes))
    # A snapshot: a later commit is invisible to it, and visible to a later read
    with db.begin_write() as txn:
        txn.open_table(USERS)[2] = b"bob"
    assert 2 not in users
    assert 2 in db.begin_read().open_table(USERS)
    # Closing is refused while a table is alive, and the table stays usable
    with pytest.raises(redb.ReadTransactionStillInUse):
        read.close()
    assert users[1] == b"alice"
    del users
    gc.collect()
    read.close()
    with pytest.raises(redb.TransactionCompleted):
        read.open_table(USERS)
    with db.begin_read() as read:
        users = read.open_table(USERS)
    assert users[1] == b"alice"  # the table outlives the block
    # ... and the Database object, which it keeps open: the file stays locked until it goes
    del db, read
    gc.collect()
    assert users[1] == b"alice"
    with pytest.raises(redb.DatabaseAlreadyOpen):
        redb.Database.open(str(tmp_db_path))
    del users
    gc.collect()
    redb.Database.open(str(tmp_db_path))


def test_first_and_last(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        assert users.first() is None
        assert users.last() is None
        for key in (3, 1, 2):
            users[key] = str(key).encode()
        assert users.first() == (1, b"1")
        assert users.last() == (3, b"3")
    users = db.begin_read().open_table(USERS)
    assert users.first() == (1, b"1")
    assert users.last() == (3, b"3")


def test_ranges(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        for key in (3, 1, 2):
            users[key] = str(key).encode()
    users = db.begin_read().open_table(USERS)
    assert list(users) == [(1, b"1"), (2, b"2"), (3, b"3")]
    assert list(users.range(2)) == [(2, b"2"), (3, b"3")]
    assert list(users.range(None, 2)) == [(1, b"1")]
    assert list(users.range(1, 3, reverse=True)) == [(2, b"2"), (1, b"1")]
    assert list(users.range(5, 1)) == []
    with pytest.raises(TypeError):
        users.range(b"1")
    entries = iter(users)
    del users, db
    gc.collect()
    # The iterator keeps the snapshot alive, and the Database open, until it goes
    assert next(entries) == (1, b"1")
    with pytest.raises(redb.DatabaseAlreadyOpen):
        redb.Database.open(str(tmp_db_path))
    del entries
    gc.collect()
    redb.Database.open(str(tmp_db_path))


def test_live_ranges(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        assert list(users) == []
        for key in (3, 1, 2):
            users[key] = str(key).encode()
        assert list(users) == [(1, b"1"), (2, b"2"), (3, b"3")]
        assert list(users.range(2, reverse=True)) == [(3, b"3"), (2, b"2")]
        assert list(users.range(None, 3)) == [(1, b"1"), (2, b"2")]
        with pytest.raises(TypeError):
            users.range(b"1")
        # A longer scan, seeking the table again for each entry
        for key in range(4, 100):
            users[key] = b"x"
        assert [key for key, _ in users] == list(range(1, 100))
        assert [key for key, _ in users.range(10, 50, reverse=True)] == list(range(49, 9, -1))
    # Finishing the transaction ends an iteration too
    txn = db.begin_write()
    entries = iter(txn.open_table(USERS))
    assert next(entries) == (1, b"1")
    txn.abort()
    with pytest.raises(redb.TransactionCompleted):
        next(entries)


def test_changes_end_iteration(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        for key in (1, 2, 3):
            users[key] = b"x"
        # Changing the table ends an iteration over it, as with a dict
        entries = iter(users)
        assert next(entries) == (1, b"x")
        users[4] = b"x"
        with pytest.raises(redb.TableChangedDuringIteration, match="changed during iteration"):
            next(entries)
        # ... but an exhausted iteration stays exhausted
        entries = iter(users)
        assert len(list(entries)) == 4
        users[4] = b"four"
        assert next(entries, None) is None
        # A table of the same transaction is not affected by changes to another
        others = txn.open_table(redb.TableDefinition("others", redb.u64, redb.bytes))
        entries = iter(users)
        others[1] = b"x"
        assert next(entries) == (1, b"x")


def test_removal(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        for key in range(1, 7):
            users[key] = str(key).encode()
        assert users.remove(1) == b"1"
        assert users.remove(1) is None
        del users[2]
        with pytest.raises(KeyError):
            del users[2]
        assert users.pop_first() == (3, b"3")
        assert users.pop_last() == (6, b"6")
        assert list(users) == [(4, b"4"), (5, b"5")]
        # Removing ends an iteration, like inserting
        entries = iter(users)
        assert users.pop_first() == (4, b"4")
        with pytest.raises(redb.TableChangedDuringIteration, match="changed during iteration"):
            next(entries)
        assert users.pop_last() == (5, b"5")
        assert users.pop_first() is None
        assert users.pop_last() is None
        assert len(users) == 0
        with pytest.raises(TypeError):
            users.remove(b"1")


def test_retain(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        users[5] = b"5"
        for key in range(10, 20):
            users[key] = b"x"
        users.retain(lambda key, value: key >= 10 or value == b"never")
        assert [key for key, _ in users] == list(range(10, 20))

        # A predicate's exception propagates once redb is done: the entries rejected before it
        # are gone, the rest stayed
        def picky(key: int, _: bytes) -> bool:
            if key == 15:
                raise ValueError("no")
            return key > 15

        with pytest.raises(ValueError, match="no"):
            users.retain(picky)
        assert [key for key, _ in users] == [15, 16, 17, 18, 19]
        # A predicate cannot use the table it is filtering, which would wait for itself
        with pytest.raises(redb.TransactionInUse, match="in use"):
            users.retain(lambda key, _: key in users)
        assert [key for key, _ in users] == [15, 16, 17, 18, 19]
        users.retain(lambda key, value: False)
        assert len(users) == 0


def test_concurrency_modes(tmp_db_path: Path) -> None:
    assert redb.SingleWriter is redb.ConcurrencyMode.SingleWriter
    assert redb.MultiWriter is redb.ConcurrencyMode.MultiWriter
    # One writer at a time by default, whatever mode the second one asks for
    db = redb.Database.create(str(tmp_db_path))
    with pytest.raises(redb.DatabaseAlreadyOpen):
        redb.Database.open(str(tmp_db_path), concurrency=redb.MultiWriter)
    del db
    # Any number of writers in MultiWriter mode; each sees the others' commits
    first = redb.Database.open(str(tmp_db_path), concurrency=redb.MultiWriter)
    second = redb.Database.open(str(tmp_db_path), concurrency=redb.MultiWriter)
    with first.begin_write() as txn:
        txn.open_table(USERS)[1] = b"alice"
    assert second.begin_read().open_table(USERS)[1] == b"alice"
    with second.begin_write() as txn:
        txn.open_table(USERS)[2] = b"bob"
    assert first.begin_read().open_table(USERS)[2] == b"bob"
    with pytest.raises(redb.DatabaseAlreadyOpen):
        redb.Database.open(str(tmp_db_path))  # a single writer cannot join them
    with pytest.raises(TypeError):
        redb.Database.open(str(tmp_db_path), concurrency="MultiWriter")


def test_open_read_only(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        txn.open_table(USERS)[1] = b"alice"
    # A reader opens alongside the writer and follows its commits
    reader = redb.Database.open_read_only(str(tmp_db_path))
    assert isinstance(reader, redb.ReadOnlyDatabase)
    assert reader.begin_read().open_table(USERS)[1] == b"alice"
    with db.begin_write() as txn:
        txn.open_table(USERS)[2] = b"bob"
    assert reader.begin_read().open_table(USERS)[2] == b"bob"
    with pytest.raises(AttributeError):
        reader.begin_write()
    # The read transaction keeps the reader's database alive, as with a Database
    users = reader.begin_read().open_table(USERS)
    del reader, db
    gc.collect()
    assert users[1] == b"alice"
    del users
    gc.collect()
    # A reader follows a writer in either mode
    writer = redb.Database.open(str(tmp_db_path), concurrency=redb.MultiWriter)
    reader = redb.Database.open_read_only(str(tmp_db_path))
    with writer.begin_write() as txn:
        txn.open_table(USERS)[3] = b"carol"
    assert reader.begin_read().open_table(USERS)[3] == b"carol"


def test_table_management(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    groups = redb.TableDefinition("groups", redb.u64, redb.bytes)
    people = redb.TableDefinition("people", redb.u64, redb.bytes)
    with db.begin_write() as txn:
        assert txn.list_tables() == []
        txn.open_table(USERS)[1] = b"alice"
        txn.open_table(groups)
        assert txn.list_tables() == ["groups", "users"]
    with db.begin_write() as txn:
        # A table goes by its definition or by its name, as list_tables gives it
        txn.rename_table(USERS, people)
        assert txn.list_tables() == ["groups", "people"]
        assert txn.open_table(people)[1] == b"alice"
        with pytest.raises(redb.TableExists):
            txn.rename_table("groups", "people")
        with pytest.raises(redb.TableDoesNotExist):
            txn.rename_table("users", "members")
        assert txn.delete_table("groups") is True
        assert txn.delete_table(groups) is False
        with pytest.raises(TypeError):
            txn.delete_table(3)
        with pytest.raises(ValueError):
            txn.delete_table("")
    read = db.begin_read()
    assert read.list_tables() == ["people"]
    with pytest.raises(redb.TableDoesNotExist):
        read.open_table(USERS)
    # A Table object is its name's binding: a range over a deleted table ends, and the object
    # raises, rather than creating the table again, until a table has its name
    with db.begin_write() as txn:
        table = txn.open_table(people)
        entries = iter(table)
        txn.delete_table(people)
        with pytest.raises(redb.TableChangedDuringIteration):
            next(entries)
        for use in (lambda: len(table), lambda: 1 in table, lambda: table.insert(3, b"carol")):
            with pytest.raises(redb.TableDoesNotExist):
                use()
        assert txn.list_tables() == []
        # A range over the name a table is renamed to ends as well, the object of that name is
        # bound to the renamed table, and the object of the old name raises
        old_name = txn.open_table(groups)
        old_name[2] = b"bob"
        entries = iter(table)
        txn.rename_table(groups, people)
        with pytest.raises(redb.TableChangedDuringIteration):
            next(entries)
        assert table[2] == b"bob"
        with pytest.raises(redb.TableDoesNotExist):
            old_name.get(2)
    assert db.begin_read().list_tables() == ["people"]


def test_str_type(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        names = txn.open_table(redb.TableDefinition("names", redb.str, str))
        names["b"] = "bee"
        names["a"] = "ay"
        names["\u00e9"] = "e acute"
        # Sorted by code point, which is how redb orders the UTF-8
        assert list(names) == [("a", "ay"), ("b", "bee"), ("\u00e9", "e acute")]
        assert names.get("a") == "ay"
        assert names.get("c") is None
        with pytest.raises(TypeError, match="expected str, got bytes"):
            names[b"a"] = "x"
        with pytest.raises(TypeError):
            names.get(1)
        with pytest.raises(UnicodeEncodeError):
            names["\ud800"] = "a lone surrogate has no UTF-8"


def test_i64_and_bool_types(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        flags = txn.open_table(redb.TableDefinition("flags", redb.i64, bool))
        for key in (2**63 - 1, 0, -1, -(2**63)):
            flags[key] = key >= 0
        # Signed order, not the order of the bytes
        assert list(flags) == [(-(2**63), False), (-1, False), (0, True), (2**63 - 1, True)]
        assert flags[-1] is False
        with pytest.raises(OverflowError):
            flags[2**63] = True
        with pytest.raises(TypeError):
            flags["1"] = True
        with pytest.raises(TypeError, match="expected bool, got int"):
            flags[1] = 1
        # Nor is a bool an int, though Python has it subclass int
        with pytest.raises(TypeError, match="expected int, got bool"):
            flags[True] = True
        for i, int_type in enumerate((redb.u64, redb.i64, redb.u128, redb.i128)):
            ints = txn.open_table(redb.TableDefinition(f"ints{i}", int_type, int_type))
            with pytest.raises(TypeError, match="expected int, got bool"):
                ints[True] = 1
            with pytest.raises(TypeError, match="expected int, got bool"):
                ints[1] = False
            with pytest.raises(TypeError, match="expected int, got bool"):
                ints.get(False)
        # bool is a key type too, as in redb
        seen = txn.open_table(redb.TableDefinition("seen", redb.bool, redb.u64))
        seen[True] = 1
        seen[False] = 0
        assert list(seen) == [(False, 0), (True, 1)]


def test_u128_i128_and_f64_types(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        wide = txn.open_table(redb.TableDefinition("wide", redb.i128, redb.u128))
        wide[2**127 - 1] = 0
        wide[-(2**127)] = 2**128 - 1
        assert list(wide) == [(-(2**127), 2**128 - 1), (2**127 - 1, 0)]
        with pytest.raises(OverflowError):
            wide[2**127] = 0
        with pytest.raises(OverflowError):
            wide[0] = -1
        # f64 is a value type alone, as in redb, which gives floats no order
        readings = txn.open_table(redb.TableDefinition("readings", redb.u64, float))
        readings[1] = 0.5
        readings[2] = float("-inf")
        readings[3] = 7  # converted as float() would
        readings[4] = float("nan")
        assert list(readings)[:3] == [(1, 0.5), (2, float("-inf")), (3, 7.0)]
        assert math.isnan(readings[4])
        with pytest.raises(TypeError):
            readings[5] = "0.5"
        # A bool is no float either, as it is no int
        with pytest.raises(TypeError, match="expected float, got bool"):
            readings[5] = True
        assert 5 not in readings
    with pytest.raises(TypeError, match="f64 cannot be a key"):
        redb.TableDefinition("t", float, redb.u64)


def test_maintenance(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path), cache_size=4 * 1024 * 1024)
    with db.begin_write() as txn:
        users = txn.open_table(USERS)
        for key in range(2000):
            users[key] = bytes(1000)
    with db.begin_write() as txn:
        txn.delete_table(USERS)
    before = tmp_db_path.stat().st_size
    assert db.check_integrity() is True
    assert db.compact() is True
    assert tmp_db_path.stat().st_size < before
    assert db.compact() is False
    # Neither runs while a transaction is alive
    read = db.begin_read()
    with pytest.raises(redb.TransactionInProgress):
        db.compact()
    with pytest.raises(redb.TransactionInProgress):
        db.check_integrity()
    read.close()
    assert db.check_integrity() is True
    # Nor while another thread waits to begin one: that thread waits for this one's transaction
    txn = db.begin_write()
    waiting = threading.Thread(target=lambda: db.begin_write().abort())
    waiting.start()
    time.sleep(0.2)
    with pytest.raises(redb.TransactionInProgress):
        db.compact()
    txn.abort()
    waiting.join()
    assert db.compact() is False
    reader = redb.Database.open_read_only(str(tmp_db_path), cache_size=1024 * 1024)
    assert reader.begin_read().list_tables() == []


def test_savepoints(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        txn.open_table(USERS)[1] = b"alice"
    with db.begin_write() as txn:
        first = txn.persistent_savepoint()
        txn.open_table(USERS)[2] = b"bob"
        with pytest.raises(redb.InvalidSavepoint):
            txn.persistent_savepoint()  # too late once a table has been opened
    with db.begin_write() as txn:
        second = txn.persistent_savepoint()
        assert txn.list_persistent_savepoints() == [first, second]
        users = txn.open_table(USERS)
        del users[1]
        entries = iter(users)
        later = txn.open_table(redb.TableDefinition("later", redb.u64, redb.u64))
        later[1] = 1
        txn.restore_savepoint(first)
        # Every table is as it was then, the ranges over them end, and later savepoints are gone
        with pytest.raises(redb.TableChangedDuringIteration):
            next(entries)
        assert dict(users) == {1: b"alice"}
        assert txn.list_persistent_savepoints() == [first]
        # A table the savepoint did not have is gone, and its object raises rather than creating it
        with pytest.raises(redb.TableDoesNotExist):
            1 in later
        assert txn.list_tables() == ["users"]
    assert dict(db.begin_read().open_table(USERS)) == {1: b"alice"}
    with db.begin_write() as txn:
        with pytest.raises(redb.InvalidSavepoint):
            txn.restore_savepoint(second)
        assert txn.delete_persistent_savepoint(first) is True
        assert txn.delete_persistent_savepoint(first) is False
        assert txn.list_persistent_savepoints() == []


def test_close(tmp_db_path: Path) -> None:
    path = str(tmp_db_path)
    with redb.Database.create(path) as db:
        with db.begin_write() as txn:
            txn.open_table(USERS)[1] = b"alice"
    for use in (db.begin_write, db.begin_read, db.compact, db.check_integrity, db.__enter__):
        with pytest.raises(redb.DatabaseClosed):
            use()
    db.close()  # closing again does nothing
    # Closed, the file is free to open again, and a with block closes it on an exception too
    with pytest.raises(ValueError):
        with redb.Database.open(path) as db:
            raise ValueError
    with pytest.raises(redb.DatabaseClosed):
        db.begin_read()

    # What was opened to read from it can no longer read the file, but can still be exited. What
    # it has already loaded may still be returned, so the table is large enough that a lookup,
    # and the rest of an iteration, need pages it has not
    deep = redb.TableDefinition("deep", redb.u64, redb.u64)
    with redb.Database.open(path) as db, db.begin_write() as txn:
        table = txn.open_table(deep)
        for i in range(10_000):
            table[i] = i
    for open_db in (redb.Database.open, redb.Database.open_read_only):
        db = open_db(path)
        with db.begin_read() as read:
            table = read.open_table(deep)
            entries = iter(table)
            db.close()
            with pytest.raises(redb.DatabaseClosed):
                table[5_000]
            with pytest.raises(redb.DatabaseClosed):
                for _ in entries:
                    pass
            for use in (read.list_tables, lambda: read.open_table(USERS)):
                with pytest.raises(redb.DatabaseClosed):
                    use()

    # An open write transaction keeps the file open until it ends, which the close reports,
    # though the database is closed all the same
    db = redb.Database.open(path)
    txn = db.begin_write()
    with pytest.raises(redb.TransactionInProgress):
        db.close()
    with pytest.raises(redb.DatabaseClosed):
        db.begin_read()
    db.close()
    with pytest.raises(redb.DatabaseAlreadyOpen):
        redb.Database.open(path)
    txn.open_table(USERS)[2] = b"bob"
    txn.commit()
    # as it does once its database object is gone, rather than closed
    txn = redb.Database.open(path).begin_write()
    with pytest.raises(redb.DatabaseAlreadyOpen):
        redb.Database.open(path)
    txn.open_table(USERS)[3] = b"carol"
    txn.commit()
    with redb.Database.open_read_only(path) as reader:
        assert dict(reader.begin_read().open_table(USERS)) == {
            1: b"alice",
            2: b"bob",
            3: b"carol",
        }
    for use in (reader.begin_read, reader.__enter__):
        with pytest.raises(redb.DatabaseClosed):
            use()
    reader.close()


def test_with_block_keeps_its_exception(tmp_db_path: Path) -> None:
    # A write transaction still open defers the close, which leaving the block does not report
    # in place of the exception leaving it
    path = str(tmp_db_path)
    with pytest.raises(ValueError):
        with redb.Database.create(path) as db:
            txn = db.begin_write()
            raise ValueError
    # Closed all the same, and the file released once the transaction ends
    with pytest.raises(redb.DatabaseClosed):
        db.begin_read()
    txn.abort()
    # Without an exception, the deferred close is still reported
    with pytest.raises(redb.TransactionInProgress):
        with redb.Database.open(path) as db:
            txn = db.begin_write()
    txn.abort()
    redb.Database.open(path).close()


@pytest.mark.skipif(not Path("/proc/locks").exists(), reason="reads Linux's /proc/locks")
def test_close_releases_the_file(tmp_db_path: Path) -> None:
    path = str(tmp_db_path)
    with redb.Database.create(path) as db, db.begin_write() as txn:
        txn.open_table(USERS)[1] = b"alice"

    def locks() -> int:
        inode = os.stat(path).st_ino
        with open("/proc/locks") as held:
            return sum(f":{inode} " in line for line in held)

    # Even while what was opened to read from it is still referenced
    for open_db in (redb.Database.open, redb.Database.open_read_only):
        db = open_db(path)
        read = db.begin_read()
        table = read.open_table(USERS)
        entries = iter(table)
        assert locks() > 0
        db.close()
        assert locks() == 0
        del read, table, entries


def test_reads_during_maintenance(tmp_db_path: Path) -> None:
    # Reads go on while another thread tries to compact, which their transaction makes refuse
    db = redb.Database.create(str(tmp_db_path))
    with db.begin_write() as txn:
        txn.open_table(USERS)[1] = b"alice"
    table = db.begin_read().open_table(USERS)
    stop = threading.Event()

    def maintain() -> None:
        while not stop.is_set():
            try:
                db.compact()
            except redb.TransactionInProgress:
                pass

    maintainer = threading.Thread(target=maintain)
    maintainer.start()
    try:
        for _ in range(10_000):
            assert len(table) == 1
    finally:
        stop.set()
        maintainer.join()


def test_begin_write_waits_for_another_writer(tmp_db_path: Path) -> None:
    db = redb.Database.create(str(tmp_db_path))
    started = threading.Event()

    def write() -> None:
        with db.begin_write() as txn:
            started.set()
            time.sleep(0.2)
            txn.open_table(USERS)[1] = b"alice"

    writer = threading.Thread(target=write)
    writer.start()
    started.wait()
    # Waits for the other thread's transaction, then sees what it committed
    with db.begin_write() as txn:
        assert dict(txn.open_table(USERS)) == {1: b"alice"}
    writer.join()


def test_begin_write_wait_can_be_interrupted(tmp_db_path: Path) -> None:
    # As a second begin_write() on this thread waits forever, for a transaction only this thread
    # can end: re-running `txn = db.begin_write()` in a notebook, say. Ctrl-C ends the wait
    db = redb.Database.create(str(tmp_db_path))
    txn = db.begin_write()
    interrupt = threading.Timer(0.2, _thread.interrupt_main)
    interrupt.start()
    try:
        with pytest.raises(KeyboardInterrupt):
            db.begin_write()
    finally:
        interrupt.cancel()
    txn.abort()
    db.begin_write().abort()

def test_open_functions(tmp_db_path: Path) -> None:
    # open() does not create. A redb.Io is an OSError too, with the OS error number
    with pytest.raises(redb.Io) as raised:
        redb.open(str(tmp_db_path))
    assert isinstance(raised.value, OSError)
    assert raised.value.errno == errno.ENOENT
    db = redb.Database.create(str(tmp_db_path), concurrency=redb.MultiWriter)
    with db.begin_write() as txn:
        txn.open_table(USERS)[1] = b"alice"
    writer = redb.open(str(tmp_db_path), concurrency=redb.MultiWriter, cache_size=1024 * 1024)
    assert isinstance(writer, redb.Database)
    assert writer.begin_read().open_table(USERS)[1] == b"alice"
    reader = redb.open_read_only(str(tmp_db_path), cache_size=1024 * 1024)
    assert isinstance(reader, redb.ReadOnlyDatabase)
    assert reader.begin_read().open_table(USERS)[1] == b"alice"
