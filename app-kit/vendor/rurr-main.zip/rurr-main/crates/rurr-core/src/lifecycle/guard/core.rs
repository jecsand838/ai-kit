use crate::lifecycle::LifecycleError;

pub(super) fn finish_sync_once(
    closed: &mut bool,
    finish_sync: impl FnOnce() -> Result<(), LifecycleError>,
) -> Result<(), LifecycleError> {
    if *closed {
        return Ok(());
    }
    *closed = true;
    finish_sync()
}
