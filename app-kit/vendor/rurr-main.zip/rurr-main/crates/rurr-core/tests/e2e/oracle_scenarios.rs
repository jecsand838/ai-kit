use rurr_oracle_test_support::{oracle_scenarios, run_oracle_scenario};
use rurr_testkit::tracking_fixture::artifacts::{project_app_dir, read_jsonl};
use serde_json::Value;
use std::collections::BTreeSet;
use std::env;
use std::fs;
use std::path::PathBuf;

const SCENARIO_FILTER_ENV: &str = "RURR_ORACLE_SCENARIO_IDS";
const ORACLE_OUTPUT_ROOT_ENV: &str = "RURR_ORACLE_OUTPUT_ROOT";
const MISSING_OUTPUT_ROOT_MESSAGE: &str = "RURR_ORACLE_OUTPUT_ROOT must be set for oracle_scenarios::; run via tools/burr_oracle/run_rurr_scenarios.py or ./scripts/check_oracle.sh";

fn output_root() -> PathBuf {
    output_root_from_env().unwrap_or_else(|error| panic!("{error}"))
}

fn output_root_from_env() -> Result<PathBuf, String> {
    match env::var_os(ORACLE_OUTPUT_ROOT_ENV) {
        Some(value) if !value.is_empty() => Ok(PathBuf::from(value)),
        _ => Err(MISSING_OUTPUT_ROOT_MESSAGE.to_string()),
    }
}

fn scenario_root(scenario_id: &str) -> PathBuf {
    output_root().join(scenario_id)
}

fn app_dir(scenario_id: &str, project: &str, app_id: &str) -> PathBuf {
    project_app_dir(&scenario_root(scenario_id), project, app_id)
}

fn assert_tracking_tree(scenario_id: &str, project: &str, app_id: &str, expects_children: bool) {
    let app_dir = app_dir(scenario_id, project, app_id);
    assert!(
        app_dir.exists(),
        "expected app dir at {}",
        app_dir.display()
    );
    assert!(
        app_dir.join("graph.json").exists(),
        "missing graph.json for {scenario_id}"
    );
    assert!(
        app_dir.join("metadata.json").exists(),
        "missing metadata.json for {scenario_id}"
    );
    assert!(
        app_dir.join("log.jsonl").exists(),
        "missing log.jsonl for {scenario_id}"
    );
    let children_path = app_dir.join("children.jsonl");
    assert_eq!(
        children_path.exists(),
        expects_children,
        "children.jsonl presence mismatch for {scenario_id}"
    );
}

fn assert_sqlite_resume_invariants(scenario_id: &str, project: &str, app_id: &str) {
    let scenario_root = scenario_root(scenario_id);
    let app_dir = app_dir(scenario_id, project, app_id);
    let db_path = scenario_root.join("oracle_state.db");
    assert!(
        db_path.exists(),
        "missing sqlite persistence file for {scenario_id}"
    );

    let committed_entries: Vec<Value> = read_jsonl(&app_dir.join("log.jsonl"))
        .into_iter()
        .filter(|entry| entry.get("type").and_then(Value::as_str) == Some("end_entry"))
        .collect();
    let committed_sequence_ids: Vec<i64> = committed_entries
        .iter()
        .map(|entry| {
            entry
                .get("sequence_id")
                .and_then(Value::as_i64)
                .expect("end_entry sequence_id should be an integer")
        })
        .collect();
    assert_eq!(
        committed_sequence_ids,
        vec![0, 1],
        "sqlite resume should commit sequence ids [0, 1]"
    );

    let final_count = committed_entries
        .last()
        .and_then(|entry| entry.get("state"))
        .and_then(Value::as_object)
        .and_then(|state| state.get("count"))
        .and_then(Value::as_i64)
        .expect("final end_entry state.count should be an integer");
    assert_eq!(
        final_count, 2,
        "sqlite resume should continue from persisted state"
    );
}

fn assert_scenario_invariants(scenario_id: &str, project: &str, app_id: &str) {
    if scenario_id == "07_sqlite_persistence_resume" {
        assert_sqlite_resume_invariants(scenario_id, project, app_id)
    }
}

fn selected_oracle_scenarios() -> Vec<&'static rurr_oracle_test_support::BurrOracleScenario> {
    let Some(raw_filter) = env::var(SCENARIO_FILTER_ENV).ok() else {
        return oracle_scenarios().iter().collect();
    };

    let selected_ids: BTreeSet<String> = raw_filter
        .split(',')
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(str::to_string)
        .collect();
    if selected_ids.is_empty() {
        return oracle_scenarios().iter().collect();
    }

    let scenarios: Vec<_> = oracle_scenarios()
        .iter()
        .filter(|definition| selected_ids.contains(definition.id.as_str()))
        .collect();
    let matched_ids: BTreeSet<_> = scenarios
        .iter()
        .map(|definition| definition.id.as_str().to_string())
        .collect();
    let missing_ids: Vec<_> = selected_ids.difference(&matched_ids).cloned().collect();
    assert!(
        missing_ids.is_empty(),
        "unknown oracle scenario ids in {SCENARIO_FILTER_ENV}: {missing_ids:?}"
    );

    scenarios
}

#[test]
fn oracle_scenarios_write_tracking_artifacts_to_requested_root() {
    if env::var_os(ORACLE_OUTPUT_ROOT_ENV).is_none() {
        return;
    }

    let root = output_root();
    if root.exists() {
        fs::remove_dir_all(&root).expect("oracle output root should reset");
    }
    fs::create_dir_all(&root).expect("oracle output root should exist");

    for definition in selected_oracle_scenarios() {
        let scenario_id = definition.id.as_str();
        let project = definition.project.as_str();
        let app_id = definition.app_id.as_str();
        let expects_children = definition.expects_children_file;
        let _ = run_oracle_scenario(definition, &root).expect("scenario should run");
        assert_tracking_tree(scenario_id, project, app_id, expects_children);
        assert_scenario_invariants(scenario_id, project, app_id);
    }
}

#[cfg(test)]
mod tests {
    use super::output_root_from_env;
    use std::ffi::OsString;
    use std::path::PathBuf;
    use std::sync::Mutex;

    static ORACLE_ENV_LOCK: Mutex<()> = Mutex::new(());

    fn with_oracle_env<const N: usize, F>(vars: [(&str, Option<&str>); N], test: F)
    where
        F: FnOnce(),
    {
        let _guard = ORACLE_ENV_LOCK
            .lock()
            .expect("oracle env test lock should not be poisoned");
        let saved: Vec<(String, Option<OsString>)> = vars
            .iter()
            .map(|(key, _)| ((*key).to_string(), std::env::var_os(key)))
            .collect();

        for (key, value) in vars {
            match value {
                Some(value) => std::env::set_var(key, value),
                None => std::env::remove_var(key),
            }
        }

        let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(test));

        for (key, value) in saved {
            match value {
                Some(value) => std::env::set_var(key, value),
                None => std::env::remove_var(key),
            }
        }

        if let Err(payload) = result {
            std::panic::resume_unwind(payload);
        }
    }

    #[test]
    fn output_root_requires_explicit_env() {
        with_oracle_env([("RURR_ORACLE_OUTPUT_ROOT", None)], || {
            let error = match output_root_from_env() {
                Ok(root) => panic!("missing RURR_ORACLE_OUTPUT_ROOT should fail: {root:?}"),
                Err(error) => error,
            };
            assert!(
                error.contains("RURR_ORACLE_OUTPUT_ROOT"),
                "unexpected missing-output-root error: {error}"
            );
        });
    }

    #[test]
    fn output_root_accepts_explicit_env_path() {
        with_oracle_env(
            [("RURR_ORACLE_OUTPUT_ROOT", Some("/tmp/rurr-oracle-root"))],
            || {
                assert_eq!(
                    output_root_from_env().expect("explicit oracle output root should parse"),
                    PathBuf::from("/tmp/rurr-oracle-root")
                );
            },
        );
    }
}
